﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 Unity.XR.CoreUtils.XROrigin Unity.XR.CoreUtils.ARTrackablesParentTransformChangedEventArgs::get_Origin()
extern void ARTrackablesParentTransformChangedEventArgs_get_Origin_m91D7C3638FBF94D468AD4467ABB2EC9500753F25 (void);
// 0x00000002 UnityEngine.Transform Unity.XR.CoreUtils.ARTrackablesParentTransformChangedEventArgs::get_TrackablesParent()
extern void ARTrackablesParentTransformChangedEventArgs_get_TrackablesParent_m89F1B7B428A07F5142AEC2BF32A83B35B52C0425 (void);
// 0x00000003 System.Void Unity.XR.CoreUtils.ARTrackablesParentTransformChangedEventArgs::.ctor(Unity.XR.CoreUtils.XROrigin,UnityEngine.Transform)
extern void ARTrackablesParentTransformChangedEventArgs__ctor_m46B5D18DF81A7296E36E37917E69AB9E748B6278 (void);
// 0x00000004 System.Boolean Unity.XR.CoreUtils.ARTrackablesParentTransformChangedEventArgs::Equals(Unity.XR.CoreUtils.ARTrackablesParentTransformChangedEventArgs)
extern void ARTrackablesParentTransformChangedEventArgs_Equals_m8CAA7BD42F09BF7349818EF3166792652FB9F4AE (void);
// 0x00000005 System.Boolean Unity.XR.CoreUtils.ARTrackablesParentTransformChangedEventArgs::Equals(System.Object)
extern void ARTrackablesParentTransformChangedEventArgs_Equals_mE6F5F659DD06166ACDDCE62B0652F014568D003B (void);
// 0x00000006 System.Int32 Unity.XR.CoreUtils.ARTrackablesParentTransformChangedEventArgs::GetHashCode()
extern void ARTrackablesParentTransformChangedEventArgs_GetHashCode_mA5FDE9D7D0F5F079886AA4C5DF806E082C725161 (void);
// 0x00000007 System.Boolean Unity.XR.CoreUtils.ARTrackablesParentTransformChangedEventArgs::op_Equality(Unity.XR.CoreUtils.ARTrackablesParentTransformChangedEventArgs,Unity.XR.CoreUtils.ARTrackablesParentTransformChangedEventArgs)
extern void ARTrackablesParentTransformChangedEventArgs_op_Equality_mF3CCF808B9E2F13DECF746856561F0FBB9F67D73 (void);
// 0x00000008 System.Boolean Unity.XR.CoreUtils.ARTrackablesParentTransformChangedEventArgs::op_Inequality(Unity.XR.CoreUtils.ARTrackablesParentTransformChangedEventArgs,Unity.XR.CoreUtils.ARTrackablesParentTransformChangedEventArgs)
extern void ARTrackablesParentTransformChangedEventArgs_op_Inequality_mDF5363BA1D4063FAE987EA2DDF7379BC102C800F (void);
// 0x00000009 System.Void Unity.XR.CoreUtils.ReadOnlyAttribute::.ctor()
extern void ReadOnlyAttribute__ctor_m13C3453A8526FBD0C9F45B0F0539CE1208546815 (void);
// 0x0000000A System.String Unity.XR.CoreUtils.ScriptableSettingsPathAttribute::get_Path()
extern void ScriptableSettingsPathAttribute_get_Path_mC767AB284DF1262E0EAA6AA36628A4A9035B646F (void);
// 0x0000000B System.Void Unity.XR.CoreUtils.ScriptableSettingsPathAttribute::.ctor(System.String)
extern void ScriptableSettingsPathAttribute__ctor_mC942C941C139A27C8B05E732EF21E6E2FFF9E808 (void);
// 0x0000000C UnityEngine.Bounds Unity.XR.CoreUtils.BoundsUtils::GetBounds(System.Collections.Generic.List`1<UnityEngine.GameObject>)
extern void BoundsUtils_GetBounds_m10F7E25BCAEDF9C9F6C88F2371DE95492CD00F0C (void);
// 0x0000000D UnityEngine.Bounds Unity.XR.CoreUtils.BoundsUtils::GetBounds(UnityEngine.Transform[])
extern void BoundsUtils_GetBounds_m05F2E93FF84428AEBECEE046972706A03DAEF0CA (void);
// 0x0000000E UnityEngine.Bounds Unity.XR.CoreUtils.BoundsUtils::GetBounds(UnityEngine.Transform)
extern void BoundsUtils_GetBounds_m37581B4C0428FBB171251D77E1148B8DD8733FD5 (void);
// 0x0000000F UnityEngine.Bounds Unity.XR.CoreUtils.BoundsUtils::GetBounds(System.Collections.Generic.List`1<UnityEngine.Renderer>)
extern void BoundsUtils_GetBounds_m9CF444D9E9C0B2BB61ECAC1457CB3E2FE64E858F (void);
// 0x00000010 UnityEngine.Bounds Unity.XR.CoreUtils.BoundsUtils::GetBounds(System.Collections.Generic.List`1<T>)
// 0x00000011 UnityEngine.Bounds Unity.XR.CoreUtils.BoundsUtils::GetBounds(System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern void BoundsUtils_GetBounds_m111209CDC60D1529A15E20EC7D6C9311959AC075 (void);
// 0x00000012 System.Void Unity.XR.CoreUtils.BoundsUtils::.cctor()
extern void BoundsUtils__cctor_m0BF977E144962DF016A62C9A2BB566975B5ECFDB (void);
// 0x00000013 THostType[] Unity.XR.CoreUtils.IComponentHost`1::get_HostedComponents()
// 0x00000014 System.Void Unity.XR.CoreUtils.CachedComponentFilter`2::.ctor(TRootType,Unity.XR.CoreUtils.CachedSearchType,System.Boolean)
// 0x00000015 System.Void Unity.XR.CoreUtils.CachedComponentFilter`2::.ctor(TFilterType[],System.Boolean)
// 0x00000016 System.Void Unity.XR.CoreUtils.CachedComponentFilter`2::StoreMatchingComponents(System.Collections.Generic.List`1<TChildType>)
// 0x00000017 TChildType[] Unity.XR.CoreUtils.CachedComponentFilter`2::GetMatchingComponents()
// 0x00000018 System.Void Unity.XR.CoreUtils.CachedComponentFilter`2::FilteredCopyToMaster(System.Boolean)
// 0x00000019 System.Void Unity.XR.CoreUtils.CachedComponentFilter`2::FilteredCopyToMaster(System.Boolean,TRootType)
// 0x0000001A System.Void Unity.XR.CoreUtils.CachedComponentFilter`2::Dispose(System.Boolean)
// 0x0000001B System.Void Unity.XR.CoreUtils.CachedComponentFilter`2::Dispose()
// 0x0000001C System.Void Unity.XR.CoreUtils.CachedComponentFilter`2::.cctor()
// 0x0000001D TCollection Unity.XR.CoreUtils.CollectionPool`2::GetCollection()
// 0x0000001E System.Void Unity.XR.CoreUtils.CollectionPool`2::RecycleCollection(TCollection)
// 0x0000001F System.Void Unity.XR.CoreUtils.CollectionPool`2::.cctor()
// 0x00000020 T Unity.XR.CoreUtils.ComponentUtils`1::GetComponent(UnityEngine.GameObject)
// 0x00000021 T Unity.XR.CoreUtils.ComponentUtils`1::GetComponentInChildren(UnityEngine.GameObject)
// 0x00000022 System.Void Unity.XR.CoreUtils.ComponentUtils`1::.cctor()
// 0x00000023 T Unity.XR.CoreUtils.ComponentUtils::GetOrAddIf(UnityEngine.GameObject,System.Boolean)
// 0x00000024 System.Void Unity.XR.CoreUtils.EnumValues`1::.cctor()
// 0x00000025 System.Boolean Unity.XR.CoreUtils.BoundsExtensions::ContainsCompletely(UnityEngine.Bounds,UnityEngine.Bounds)
extern void BoundsExtensions_ContainsCompletely_m8602D6C63C6E5394D5AC7AA833A1456DAB5888B9 (void);
// 0x00000026 System.Single Unity.XR.CoreUtils.CameraExtensions::GetVerticalFieldOfView(UnityEngine.Camera,System.Single)
extern void CameraExtensions_GetVerticalFieldOfView_m0C6216CB884E1D5A1678998B9566FAC91F28BBAC (void);
// 0x00000027 System.Single Unity.XR.CoreUtils.CameraExtensions::GetHorizontalFieldOfView(UnityEngine.Camera)
extern void CameraExtensions_GetHorizontalFieldOfView_m852B8A5A60F036F8E09D3EEA5D572432D48041E6 (void);
// 0x00000028 System.Single Unity.XR.CoreUtils.CameraExtensions::GetVerticalOrthographicSize(UnityEngine.Camera,System.Single)
extern void CameraExtensions_GetVerticalOrthographicSize_mB1A0C96B45B45EF1C369AE8189F096731FF8D27E (void);
// 0x00000029 System.String Unity.XR.CoreUtils.CollectionExtensions::Stringify(System.Collections.Generic.ICollection`1<T>)
// 0x0000002A System.Void Unity.XR.CoreUtils.CollectionExtensions::.cctor()
extern void CollectionExtensions__cctor_m257181DE1D15E554336D452F505895F1A918C83A (void);
// 0x0000002B System.Collections.Generic.KeyValuePair`2<TKey,TValue> Unity.XR.CoreUtils.DictionaryExtensions::First(System.Collections.Generic.Dictionary`2<TKey,TValue>)
// 0x0000002C System.Void Unity.XR.CoreUtils.GameObjectExtensions::SetHideFlagsRecursively(UnityEngine.GameObject,UnityEngine.HideFlags)
extern void GameObjectExtensions_SetHideFlagsRecursively_m1D9800818E28035945B29B26AC7369B456B9C67A (void);
// 0x0000002D System.Void Unity.XR.CoreUtils.GameObjectExtensions::AddToHideFlagsRecursively(UnityEngine.GameObject,UnityEngine.HideFlags)
extern void GameObjectExtensions_AddToHideFlagsRecursively_m2FF5C9D0FCCE193AA290E4E52213C66A1E9CE696 (void);
// 0x0000002E System.Void Unity.XR.CoreUtils.GameObjectExtensions::SetLayerRecursively(UnityEngine.GameObject,System.Int32)
extern void GameObjectExtensions_SetLayerRecursively_mEBBB0450F5DEC5C505CA9892F981AAF6BAF5463B (void);
// 0x0000002F System.Void Unity.XR.CoreUtils.GameObjectExtensions::SetLayerAndAddToHideFlagsRecursively(UnityEngine.GameObject,System.Int32,UnityEngine.HideFlags)
extern void GameObjectExtensions_SetLayerAndAddToHideFlagsRecursively_m4369A5EF54EDC5DA66C4B08227DF55D625F7C75C (void);
// 0x00000030 System.Void Unity.XR.CoreUtils.GameObjectExtensions::SetLayerAndHideFlagsRecursively(UnityEngine.GameObject,System.Int32,UnityEngine.HideFlags)
extern void GameObjectExtensions_SetLayerAndHideFlagsRecursively_m6736B901E74C100814C434157BECB79514F16D40 (void);
// 0x00000031 System.Void Unity.XR.CoreUtils.GameObjectExtensions::SetRunInEditModeRecursively(UnityEngine.GameObject,System.Boolean)
extern void GameObjectExtensions_SetRunInEditModeRecursively_mFB07A0BA8EEA6EFE90ED5B8737F1AEDA6EBB6B42 (void);
// 0x00000032 System.Void Unity.XR.CoreUtils.GuidExtensions::Decompose(System.Guid,System.UInt64&,System.UInt64&)
extern void GuidExtensions_Decompose_m574442B0FAF7CFEE4BA0BAF8209F51308C04B80C (void);
// 0x00000033 System.Void Unity.XR.CoreUtils.HashSetExtensions::ExceptWithNonAlloc(System.Collections.Generic.HashSet`1<T>,System.Collections.Generic.HashSet`1<T>)
// 0x00000034 T Unity.XR.CoreUtils.HashSetExtensions::First(System.Collections.Generic.HashSet`1<T>)
// 0x00000035 System.Int32 Unity.XR.CoreUtils.LayerMaskExtensions::GetFirstLayerIndex(UnityEngine.LayerMask)
extern void LayerMaskExtensions_GetFirstLayerIndex_m2C0A16C506E5B9C5B08F4D1332361E9A513EE75A (void);
// 0x00000036 System.Boolean Unity.XR.CoreUtils.LayerMaskExtensions::Contains(UnityEngine.LayerMask,System.Int32)
extern void LayerMaskExtensions_Contains_m4EB2480554BA1EEF78C3A4F6165AA2F1D8FD7D0D (void);
// 0x00000037 System.Collections.Generic.List`1<T> Unity.XR.CoreUtils.ListExtensions::Fill(System.Collections.Generic.List`1<T>,System.Int32)
// 0x00000038 System.Void Unity.XR.CoreUtils.ListExtensions::EnsureCapacity(System.Collections.Generic.List`1<T>,System.Int32)
// 0x00000039 UnityEngine.Pose Unity.XR.CoreUtils.PoseExtensions::ApplyOffsetTo(UnityEngine.Pose,UnityEngine.Pose)
extern void PoseExtensions_ApplyOffsetTo_mCA13DA87F5C4587B48E0DE3C8ECAC514581D5C60 (void);
// 0x0000003A UnityEngine.Vector3 Unity.XR.CoreUtils.PoseExtensions::ApplyOffsetTo(UnityEngine.Pose,UnityEngine.Vector3)
extern void PoseExtensions_ApplyOffsetTo_mE34A80DDB3E3303D6B03ECCEAF86155D132B522A (void);
// 0x0000003B UnityEngine.Vector3 Unity.XR.CoreUtils.PoseExtensions::ApplyInverseOffsetTo(UnityEngine.Pose,UnityEngine.Vector3)
extern void PoseExtensions_ApplyInverseOffsetTo_m19A415A1473DDF2B68FB83D306656910E72C9D3B (void);
// 0x0000003C UnityEngine.Quaternion Unity.XR.CoreUtils.QuaternionExtensions::ConstrainYaw(UnityEngine.Quaternion)
extern void QuaternionExtensions_ConstrainYaw_m8564D6572C5D7169E9B48DEACBBA8E93EDBFABE7 (void);
// 0x0000003D UnityEngine.Quaternion Unity.XR.CoreUtils.QuaternionExtensions::ConstrainYawNormalized(UnityEngine.Quaternion)
extern void QuaternionExtensions_ConstrainYawNormalized_m59E7A2BE631745700E7A9E71A4C30A2CE916B0E7 (void);
// 0x0000003E UnityEngine.Quaternion Unity.XR.CoreUtils.QuaternionExtensions::ConstrainYawPitchNormalized(UnityEngine.Quaternion)
extern void QuaternionExtensions_ConstrainYawPitchNormalized_m61F4789E8A9D6483B1490765F2886E8C329C9269 (void);
// 0x0000003F System.String Unity.XR.CoreUtils.StringExtensions::FirstToUpper(System.String)
extern void StringExtensions_FirstToUpper_m23B2D0DD59B91DD88571C96B8268E3368E9DAA3F (void);
// 0x00000040 System.String Unity.XR.CoreUtils.StringExtensions::InsertSpacesBetweenWords(System.String)
extern void StringExtensions_InsertSpacesBetweenWords_m007D0DB6D7C0BBD89819F00D407B8ECF3BCA23E0 (void);
// 0x00000041 System.Void Unity.XR.CoreUtils.StringExtensions::.cctor()
extern void StringExtensions__cctor_m938B8A990F47C7F8D7FD8E368AE024FA6F222966 (void);
// 0x00000042 UnityEngine.Pose Unity.XR.CoreUtils.TransformExtensions::GetLocalPose(UnityEngine.Transform)
extern void TransformExtensions_GetLocalPose_m8094B038D295D5EC653A1809E984A1426044CD88 (void);
// 0x00000043 UnityEngine.Pose Unity.XR.CoreUtils.TransformExtensions::GetWorldPose(UnityEngine.Transform)
extern void TransformExtensions_GetWorldPose_m9D21B0564EA540CF54C761F9C73F77F37F146D4D (void);
// 0x00000044 System.Void Unity.XR.CoreUtils.TransformExtensions::SetLocalPose(UnityEngine.Transform,UnityEngine.Pose)
extern void TransformExtensions_SetLocalPose_m76856288B34BC31E5AC19D86AFFFF17E607F6BC0 (void);
// 0x00000045 System.Void Unity.XR.CoreUtils.TransformExtensions::SetWorldPose(UnityEngine.Transform,UnityEngine.Pose)
extern void TransformExtensions_SetWorldPose_mBE5770AE0BD22C934198C8B2CF8DB9E165D758B2 (void);
// 0x00000046 UnityEngine.Pose Unity.XR.CoreUtils.TransformExtensions::TransformPose(UnityEngine.Transform,UnityEngine.Pose)
extern void TransformExtensions_TransformPose_mFEB5D4C90DD8CA9ABDB23FA5F6EB0D8F9DFEB0C0 (void);
// 0x00000047 UnityEngine.Pose Unity.XR.CoreUtils.TransformExtensions::InverseTransformPose(UnityEngine.Transform,UnityEngine.Pose)
extern void TransformExtensions_InverseTransformPose_m02C4C15F207035129435CABAE86BA9EA5786734B (void);
// 0x00000048 UnityEngine.Ray Unity.XR.CoreUtils.TransformExtensions::InverseTransformRay(UnityEngine.Transform,UnityEngine.Ray)
extern void TransformExtensions_InverseTransformRay_mBDA961A6DF20D7FE3EC7438973AD25CBC3DF8051 (void);
// 0x00000049 System.Void Unity.XR.CoreUtils.TypeExtensions::GetAssignableTypes(System.Type,System.Collections.Generic.List`1<System.Type>,System.Func`2<System.Type,System.Boolean>)
extern void TypeExtensions_GetAssignableTypes_mDCA9CD5F98812F50A9EFBE266D307629B45832B5 (void);
// 0x0000004A System.Void Unity.XR.CoreUtils.TypeExtensions::GetImplementationsOfInterface(System.Type,System.Collections.Generic.List`1<System.Type>)
extern void TypeExtensions_GetImplementationsOfInterface_m1F0A81C1CAD8A5749BA8855E9F3F9D825FF425BC (void);
// 0x0000004B System.Void Unity.XR.CoreUtils.TypeExtensions::GetExtensionsOfClass(System.Type,System.Collections.Generic.List`1<System.Type>)
extern void TypeExtensions_GetExtensionsOfClass_m6F971E2D8B286DA6E1C9F0F5ECDFF295779E9EF3 (void);
// 0x0000004C System.Void Unity.XR.CoreUtils.TypeExtensions::GetGenericInterfaces(System.Type,System.Type,System.Collections.Generic.List`1<System.Type>)
extern void TypeExtensions_GetGenericInterfaces_m233AE28D855F5100DE0A3579E8738358AD361255 (void);
// 0x0000004D System.Reflection.PropertyInfo Unity.XR.CoreUtils.TypeExtensions::GetPropertyRecursively(System.Type,System.String,System.Reflection.BindingFlags)
extern void TypeExtensions_GetPropertyRecursively_mFBCE55028E50841DE712128781E0CA5775112668 (void);
// 0x0000004E System.Reflection.FieldInfo Unity.XR.CoreUtils.TypeExtensions::GetFieldRecursively(System.Type,System.String,System.Reflection.BindingFlags)
extern void TypeExtensions_GetFieldRecursively_m8F1731890D1467E55C1FD6CC9F8E806529495623 (void);
// 0x0000004F System.Void Unity.XR.CoreUtils.TypeExtensions::GetFieldsRecursively(System.Type,System.Collections.Generic.List`1<System.Reflection.FieldInfo>,System.Reflection.BindingFlags)
extern void TypeExtensions_GetFieldsRecursively_m546320169FEE9DADA681AEB3373B3CA694695813 (void);
// 0x00000050 System.Void Unity.XR.CoreUtils.TypeExtensions::GetPropertiesRecursively(System.Type,System.Collections.Generic.List`1<System.Reflection.PropertyInfo>,System.Reflection.BindingFlags)
extern void TypeExtensions_GetPropertiesRecursively_m5DC5DBFB2A1E6BDDF7B5D0FDE7F3B9D3A73F5808 (void);
// 0x00000051 System.Void Unity.XR.CoreUtils.TypeExtensions::GetInterfaceFieldsFromClasses(System.Collections.Generic.IEnumerable`1<System.Type>,System.Collections.Generic.List`1<System.Reflection.FieldInfo>,System.Collections.Generic.List`1<System.Type>,System.Reflection.BindingFlags)
extern void TypeExtensions_GetInterfaceFieldsFromClasses_m4DB43352F2A2D34D587D98C73BA21E57AF9EDAF0 (void);
// 0x00000052 TAttribute Unity.XR.CoreUtils.TypeExtensions::GetAttribute(System.Type,System.Boolean)
// 0x00000053 System.Void Unity.XR.CoreUtils.TypeExtensions::IsDefinedGetInheritedTypes(System.Type,System.Collections.Generic.List`1<System.Type>)
// 0x00000054 System.Reflection.FieldInfo Unity.XR.CoreUtils.TypeExtensions::GetFieldInTypeOrBaseType(System.Type,System.String)
extern void TypeExtensions_GetFieldInTypeOrBaseType_m551CF2E4240A813ADB5C4BE26867BE3C544642E8 (void);
// 0x00000055 System.String Unity.XR.CoreUtils.TypeExtensions::GetNameWithGenericArguments(System.Type)
extern void TypeExtensions_GetNameWithGenericArguments_m00A7B891B4CF156A0FD941E913171754067BA821 (void);
// 0x00000056 System.String Unity.XR.CoreUtils.TypeExtensions::GetNameWithFullGenericArguments(System.Type)
extern void TypeExtensions_GetNameWithFullGenericArguments_mA28CDBF80811149115DEAFC7C9C11F839A94650E (void);
// 0x00000057 System.String Unity.XR.CoreUtils.TypeExtensions::GetFullNameWithGenericArguments(System.Type)
extern void TypeExtensions_GetFullNameWithGenericArguments_m219B2A27B25E9E6A80A3B748329329D5763EFB5F (void);
// 0x00000058 System.String Unity.XR.CoreUtils.TypeExtensions::GetFullNameWithGenericArgumentsInternal(System.Type)
extern void TypeExtensions_GetFullNameWithGenericArgumentsInternal_mCA07B472A237A063651781A95F761E1873123358 (void);
// 0x00000059 System.Boolean Unity.XR.CoreUtils.TypeExtensions::IsAssignableFromOrSubclassOf(System.Type,System.Type)
extern void TypeExtensions_IsAssignableFromOrSubclassOf_mBD6A28891E5ABA30A7AFE9FFFEF1810E248ECAB7 (void);
// 0x0000005A System.Reflection.MethodInfo Unity.XR.CoreUtils.TypeExtensions::GetMethodRecursively(System.Type,System.String,System.Reflection.BindingFlags)
extern void TypeExtensions_GetMethodRecursively_mE590CEF50FB0D2A536FC82AFD542F2EA568AF567 (void);
// 0x0000005B System.Void Unity.XR.CoreUtils.TypeExtensions::.cctor()
extern void TypeExtensions__cctor_mA8563E03790781B4336379A74E5C0725E08FB55C (void);
// 0x0000005C System.Void Unity.XR.CoreUtils.TypeExtensions/<>c__DisplayClass2_0::.ctor()
extern void U3CU3Ec__DisplayClass2_0__ctor_m503826A926363EA4EAF9A0DE52DA34382B75C925 (void);
// 0x0000005D System.Void Unity.XR.CoreUtils.TypeExtensions/<>c__DisplayClass2_0::<GetAssignableTypes>b__0(System.Type)
extern void U3CU3Ec__DisplayClass2_0_U3CGetAssignableTypesU3Eb__0_m605F61DF1647ACBAF3D37F9AB38C2478C6BC5E57 (void);
// 0x0000005E UnityEngine.Vector2 Unity.XR.CoreUtils.Vector2Extensions::Inverse(UnityEngine.Vector2)
extern void Vector2Extensions_Inverse_m53BC362EF0D505A5D44464DC72C689F8F77283DE (void);
// 0x0000005F System.Single Unity.XR.CoreUtils.Vector2Extensions::MinComponent(UnityEngine.Vector2)
extern void Vector2Extensions_MinComponent_mD48D421FB5DCC40C53CFBBA645B0BA02BFFA0A65 (void);
// 0x00000060 System.Single Unity.XR.CoreUtils.Vector2Extensions::MaxComponent(UnityEngine.Vector2)
extern void Vector2Extensions_MaxComponent_mFB94549B6163A31AABD5A610CF4E496CE23B5F1D (void);
// 0x00000061 UnityEngine.Vector2 Unity.XR.CoreUtils.Vector2Extensions::Abs(UnityEngine.Vector2)
extern void Vector2Extensions_Abs_m224ED011C4857D0EE79CFC9C71DEDB3D792C9ABE (void);
// 0x00000062 UnityEngine.Vector3 Unity.XR.CoreUtils.Vector3Extensions::Inverse(UnityEngine.Vector3)
extern void Vector3Extensions_Inverse_mE160B5FA7953B8897A11937CBC7B632B61668E3A (void);
// 0x00000063 System.Single Unity.XR.CoreUtils.Vector3Extensions::MinComponent(UnityEngine.Vector3)
extern void Vector3Extensions_MinComponent_m13370F40717B0926B26745E7586F770E1DC22C00 (void);
// 0x00000064 System.Single Unity.XR.CoreUtils.Vector3Extensions::MaxComponent(UnityEngine.Vector3)
extern void Vector3Extensions_MaxComponent_m7F7CEF38DB40E4C1B2203D821FBFFC085DE7C696 (void);
// 0x00000065 UnityEngine.Vector3 Unity.XR.CoreUtils.Vector3Extensions::Abs(UnityEngine.Vector3)
extern void Vector3Extensions_Abs_m5546503290D009FF363F2C5279A502B749F92AC1 (void);
// 0x00000066 System.Void Unity.XR.CoreUtils.GameObjectUtils::add_GameObjectInstantiated(System.Action`1<UnityEngine.GameObject>)
extern void GameObjectUtils_add_GameObjectInstantiated_m052A1ABEF1010C4E9D9288CE7ADDBE0095F010B4 (void);
// 0x00000067 System.Void Unity.XR.CoreUtils.GameObjectUtils::remove_GameObjectInstantiated(System.Action`1<UnityEngine.GameObject>)
extern void GameObjectUtils_remove_GameObjectInstantiated_m22490A7BA15C1DF76100AE542585E32F1C4CEF69 (void);
// 0x00000068 UnityEngine.GameObject Unity.XR.CoreUtils.GameObjectUtils::Create()
extern void GameObjectUtils_Create_mC589C5D5A81BF0A64CBD7EB0470CA4C2A484FA79 (void);
// 0x00000069 UnityEngine.GameObject Unity.XR.CoreUtils.GameObjectUtils::Create(System.String)
extern void GameObjectUtils_Create_m62DFB2CA101FC3E009EF8DDCED70711BEE1C2EF2 (void);
// 0x0000006A UnityEngine.GameObject Unity.XR.CoreUtils.GameObjectUtils::Instantiate(UnityEngine.GameObject,UnityEngine.Transform,System.Boolean)
extern void GameObjectUtils_Instantiate_mC01BADA88B24537F04AB71DFE14E6B77C0E5DB96 (void);
// 0x0000006B UnityEngine.GameObject Unity.XR.CoreUtils.GameObjectUtils::Instantiate(UnityEngine.GameObject,UnityEngine.Vector3,UnityEngine.Quaternion)
extern void GameObjectUtils_Instantiate_m0DA555EA05C419981D74FCC1FE602D125FA11133 (void);
// 0x0000006C UnityEngine.GameObject Unity.XR.CoreUtils.GameObjectUtils::Instantiate(UnityEngine.GameObject,UnityEngine.Transform,UnityEngine.Vector3,UnityEngine.Quaternion)
extern void GameObjectUtils_Instantiate_m485AC32BF5A5CFBAB6AF5A905B02F89AF3D29933 (void);
// 0x0000006D UnityEngine.GameObject Unity.XR.CoreUtils.GameObjectUtils::CloneWithHideFlags(UnityEngine.GameObject,UnityEngine.Transform)
extern void GameObjectUtils_CloneWithHideFlags_mEF25DF8A4E9122B0F354867F757B58F7E7CABA25 (void);
// 0x0000006E System.Void Unity.XR.CoreUtils.GameObjectUtils::CopyHideFlagsRecursively(UnityEngine.GameObject,UnityEngine.GameObject)
extern void GameObjectUtils_CopyHideFlagsRecursively_m980DBD37550E928E6A0605B88C3BA824BC16871E (void);
// 0x0000006F T Unity.XR.CoreUtils.GameObjectUtils::ExhaustiveComponentSearch(UnityEngine.GameObject)
// 0x00000070 T Unity.XR.CoreUtils.GameObjectUtils::ExhaustiveTaggedComponentSearch(UnityEngine.GameObject,System.String)
// 0x00000071 T Unity.XR.CoreUtils.GameObjectUtils::GetComponentInScene(UnityEngine.SceneManagement.Scene)
// 0x00000072 System.Void Unity.XR.CoreUtils.GameObjectUtils::GetComponentsInScene(UnityEngine.SceneManagement.Scene,System.Collections.Generic.List`1<T>,System.Boolean)
// 0x00000073 T Unity.XR.CoreUtils.GameObjectUtils::GetComponentInActiveScene()
// 0x00000074 System.Void Unity.XR.CoreUtils.GameObjectUtils::GetComponentsInActiveScene(System.Collections.Generic.List`1<T>,System.Boolean)
// 0x00000075 System.Void Unity.XR.CoreUtils.GameObjectUtils::GetComponentsInAllScenes(System.Collections.Generic.List`1<T>,System.Boolean)
// 0x00000076 System.Void Unity.XR.CoreUtils.GameObjectUtils::GetChildGameObjects(UnityEngine.GameObject,System.Collections.Generic.List`1<UnityEngine.GameObject>)
extern void GameObjectUtils_GetChildGameObjects_m8B12380F88912399A4E85B23DD1B738DA30C60B8 (void);
// 0x00000077 UnityEngine.GameObject Unity.XR.CoreUtils.GameObjectUtils::GetNamedChild(UnityEngine.GameObject,System.String)
extern void GameObjectUtils_GetNamedChild_mA76A1E5EF192028632794E5DC04EECC349853BC2 (void);
// 0x00000078 System.Void Unity.XR.CoreUtils.GameObjectUtils::.cctor()
extern void GameObjectUtils__cctor_m3C64181578FAFAD75EF878775ED6530721BB807B (void);
// 0x00000079 System.Void Unity.XR.CoreUtils.GameObjectUtils/<>c__DisplayClass20_0::.ctor()
extern void U3CU3Ec__DisplayClass20_0__ctor_mB1AF49A2B6F9488132A2E8939817133973337254 (void);
// 0x0000007A System.Boolean Unity.XR.CoreUtils.GameObjectUtils/<>c__DisplayClass20_0::<GetNamedChild>b__0(UnityEngine.Transform)
extern void U3CU3Ec__DisplayClass20_0_U3CGetNamedChildU3Eb__0_m7B07F30C4FDAF96F9DF2B6864BF3E6810BDA8271 (void);
// 0x0000007B System.Boolean Unity.XR.CoreUtils.GeometryUtils::FindClosestEdge(System.Collections.Generic.List`1<UnityEngine.Vector3>,UnityEngine.Vector3,UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void GeometryUtils_FindClosestEdge_m0F7FD65B046CE54774B01E431D40AFE6072EF310 (void);
// 0x0000007C UnityEngine.Vector3 Unity.XR.CoreUtils.GeometryUtils::PointOnOppositeSideOfPolygon(System.Collections.Generic.List`1<UnityEngine.Vector3>,UnityEngine.Vector3)
extern void GeometryUtils_PointOnOppositeSideOfPolygon_m191912ABDDB24465677D144BC5EE8C6F7B5503F8 (void);
// 0x0000007D System.Void Unity.XR.CoreUtils.GeometryUtils::TriangulatePolygon(System.Collections.Generic.List`1<System.Int32>,System.Int32,System.Boolean)
extern void GeometryUtils_TriangulatePolygon_m924E2453CFA1358CFC0B85862F00BCF56B855B9D (void);
// 0x0000007E System.Boolean Unity.XR.CoreUtils.GeometryUtils::ClosestTimesOnTwoLines(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,System.Single&,System.Single&,System.Double)
extern void GeometryUtils_ClosestTimesOnTwoLines_m883D01C52ED19A788A5232DBDE726A7079C03A00 (void);
// 0x0000007F System.Boolean Unity.XR.CoreUtils.GeometryUtils::ClosestTimesOnTwoLinesXZ(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,System.Single&,System.Single&,System.Double)
extern void GeometryUtils_ClosestTimesOnTwoLinesXZ_m9F62C077493CBE8B706A6A8B75950685990C9D92 (void);
// 0x00000080 System.Boolean Unity.XR.CoreUtils.GeometryUtils::ClosestPointsOnTwoLineSegments(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3&,UnityEngine.Vector3&,System.Double)
extern void GeometryUtils_ClosestPointsOnTwoLineSegments_m6BC887D811464AF1B74FE9B18E52667C7CF8337E (void);
// 0x00000081 UnityEngine.Vector3 Unity.XR.CoreUtils.GeometryUtils::ClosestPointOnLineSegment(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void GeometryUtils_ClosestPointOnLineSegment_m0A225333430C44FEF56DC2AEBC5B5F64D0C1C271 (void);
// 0x00000082 System.Void Unity.XR.CoreUtils.GeometryUtils::ClosestPolygonApproach(System.Collections.Generic.List`1<UnityEngine.Vector3>,System.Collections.Generic.List`1<UnityEngine.Vector3>,UnityEngine.Vector3&,UnityEngine.Vector3&,System.Single)
extern void GeometryUtils_ClosestPolygonApproach_m438A3196B7478B0AB9C6B81B41BA2DA33943C9B4 (void);
// 0x00000083 System.Boolean Unity.XR.CoreUtils.GeometryUtils::PointInPolygon(UnityEngine.Vector3,System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern void GeometryUtils_PointInPolygon_m99BAD947FC3B8AFBEB500E10BD4D56EA69BEAB48 (void);
// 0x00000084 System.Boolean Unity.XR.CoreUtils.GeometryUtils::PointInPolygon3D(UnityEngine.Vector3,System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern void GeometryUtils_PointInPolygon3D_m5BD04A6C9E23B2568A416825BCCBBCE2571BAAE4 (void);
// 0x00000085 UnityEngine.Vector3 Unity.XR.CoreUtils.GeometryUtils::ProjectPointOnPlane(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void GeometryUtils_ProjectPointOnPlane_mECE172615E445977F6FC1E80D228ACB663079CFE (void);
// 0x00000086 System.Boolean Unity.XR.CoreUtils.GeometryUtils::ConvexHull2D(System.Collections.Generic.List`1<UnityEngine.Vector3>,System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern void GeometryUtils_ConvexHull2D_mD5960873113EBFE9F6A6ACC2D47EE1154F73F335 (void);
// 0x00000087 UnityEngine.Vector3 Unity.XR.CoreUtils.GeometryUtils::PolygonCentroid2D(System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern void GeometryUtils_PolygonCentroid2D_m2516A07125F2809AA5C7F8C7EB5C5E11334A680F (void);
// 0x00000088 UnityEngine.Vector2 Unity.XR.CoreUtils.GeometryUtils::OrientedMinimumBoundingBox2D(System.Collections.Generic.List`1<UnityEngine.Vector3>,UnityEngine.Vector3[])
extern void GeometryUtils_OrientedMinimumBoundingBox2D_mF8D0B3C51697E90590EA880AE50089D03D1B022D (void);
// 0x00000089 System.Void Unity.XR.CoreUtils.GeometryUtils::RotateCalipers(UnityEngine.Vector3,System.Collections.Generic.List`1<UnityEngine.Vector3>,System.Int32&,System.Int32&,System.Int32&,System.Int32&,UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void GeometryUtils_RotateCalipers_m8D4357E76037BED2CA3C53394BE6A5B4614EF16E (void);
// 0x0000008A UnityEngine.Quaternion Unity.XR.CoreUtils.GeometryUtils::RotationForBox(UnityEngine.Vector3[])
extern void GeometryUtils_RotationForBox_mAE65F788A071112CC5A8482EDC6C20778E9BBA45 (void);
// 0x0000008B System.Single Unity.XR.CoreUtils.GeometryUtils::ConvexPolygonArea(System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern void GeometryUtils_ConvexPolygonArea_m822057386EA7F103805E769EB1C8C245B024289B (void);
// 0x0000008C System.Boolean Unity.XR.CoreUtils.GeometryUtils::PolygonInPolygon(System.Collections.Generic.List`1<UnityEngine.Vector3>,System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern void GeometryUtils_PolygonInPolygon_m0F03C275DD603611951CF393F912B37C41B62194 (void);
// 0x0000008D System.Boolean Unity.XR.CoreUtils.GeometryUtils::PolygonsWithinRange(System.Collections.Generic.List`1<UnityEngine.Vector3>,System.Collections.Generic.List`1<UnityEngine.Vector3>,System.Single)
extern void GeometryUtils_PolygonsWithinRange_m427FF406477F28960C31E413547C83E5E0ED95EA (void);
// 0x0000008E System.Boolean Unity.XR.CoreUtils.GeometryUtils::PolygonsWithinSqRange(System.Collections.Generic.List`1<UnityEngine.Vector3>,System.Collections.Generic.List`1<UnityEngine.Vector3>,System.Single)
extern void GeometryUtils_PolygonsWithinSqRange_mEC2539F5CF1FF9F569E1FA97FF2DEDD99312E4D9 (void);
// 0x0000008F System.Boolean Unity.XR.CoreUtils.GeometryUtils::PointOnPolygonBoundsXZ(UnityEngine.Vector3,System.Collections.Generic.List`1<UnityEngine.Vector3>,System.Single)
extern void GeometryUtils_PointOnPolygonBoundsXZ_m52429F42CD1E0C1A1769F35F3A535FA63EF9560C (void);
// 0x00000090 System.Boolean Unity.XR.CoreUtils.GeometryUtils::PointOnLineSegmentXZ(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void GeometryUtils_PointOnLineSegmentXZ_m5B56E6ABEC3867132E38F599417909928FD5F63B (void);
// 0x00000091 UnityEngine.Quaternion Unity.XR.CoreUtils.GeometryUtils::NormalizeRotationKeepingUp(UnityEngine.Quaternion)
extern void GeometryUtils_NormalizeRotationKeepingUp_mE3B160896A4ECBBE1841D3DAFF2AFB00A6536EC7 (void);
// 0x00000092 UnityEngine.Pose Unity.XR.CoreUtils.GeometryUtils::PolygonUVPoseFromPlanePose(UnityEngine.Pose)
extern void GeometryUtils_PolygonUVPoseFromPlanePose_m1FFC85683F3E494C8AF6DC2F2F2BB4773341B7CF (void);
// 0x00000093 UnityEngine.Vector2 Unity.XR.CoreUtils.GeometryUtils::PolygonVertexToUV(UnityEngine.Vector3,UnityEngine.Pose,UnityEngine.Pose)
extern void GeometryUtils_PolygonVertexToUV_m30385D80574DDB089A90FC8C4FE306F1E92A4963 (void);
// 0x00000094 System.Void Unity.XR.CoreUtils.GeometryUtils::.cctor()
extern void GeometryUtils__cctor_mBD458259FCFC5DC054BE45C6C3B27F0C1ADD52E3 (void);
// 0x00000095 System.Guid Unity.XR.CoreUtils.GuidUtil::Compose(System.UInt64,System.UInt64)
extern void GuidUtil_Compose_m944D3327AACECCAFEBF84434875B2F25D84F08A1 (void);
// 0x00000096 System.Int32 Unity.XR.CoreUtils.HashCodeUtil::Combine(System.Int32,System.Int32)
extern void HashCodeUtil_Combine_m0947FF25308C4EAF03F04A09D0C9037371E09E80 (void);
// 0x00000097 System.Int32 Unity.XR.CoreUtils.HashCodeUtil::ReferenceHash(System.Object)
extern void HashCodeUtil_ReferenceHash_m5A135DC218865E418D3965B2A432A0B649DD9863 (void);
// 0x00000098 System.Int32 Unity.XR.CoreUtils.HashCodeUtil::Combine(System.Int32,System.Int32,System.Int32)
extern void HashCodeUtil_Combine_mD0D5C6E0B1628514717AF46ECCCCA4859B96D00B (void);
// 0x00000099 System.Int32 Unity.XR.CoreUtils.HashCodeUtil::Combine(System.Int32,System.Int32,System.Int32,System.Int32)
extern void HashCodeUtil_Combine_mFA75BDAA1FC48B90D8E0AB405C62303DBBD4581A (void);
// 0x0000009A System.Int32 Unity.XR.CoreUtils.HashCodeUtil::Combine(System.Int32,System.Int32,System.Int32,System.Int32,System.Int32)
extern void HashCodeUtil_Combine_m17C420993EDFFC48138CF88B9340E323CDC04971 (void);
// 0x0000009B System.Int32 Unity.XR.CoreUtils.HashCodeUtil::Combine(System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32)
extern void HashCodeUtil_Combine_m301D9F4956E4E0689E28466F9DBD3097E12377C6 (void);
// 0x0000009C System.Int32 Unity.XR.CoreUtils.HashCodeUtil::Combine(System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32)
extern void HashCodeUtil_Combine_mB38F06ABAA3544284AABF914BF1A71C223B95962 (void);
// 0x0000009D System.Int32 Unity.XR.CoreUtils.HashCodeUtil::Combine(System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32)
extern void HashCodeUtil_Combine_mDD784B4B8DA3E8E85409D0B1E5917CBD04E99A0F (void);
// 0x0000009E UnityEngine.Material Unity.XR.CoreUtils.MaterialUtils::GetMaterialClone(UnityEngine.Renderer)
extern void MaterialUtils_GetMaterialClone_m68A92B332B1F70DBFB060E6A1D94F7737DF0FCEA (void);
// 0x0000009F UnityEngine.Material Unity.XR.CoreUtils.MaterialUtils::GetMaterialClone(UnityEngine.UI.Graphic)
extern void MaterialUtils_GetMaterialClone_mA94F9D8F608583D66873B90FC8882D2C0B599B0B (void);
// 0x000000A0 UnityEngine.Material[] Unity.XR.CoreUtils.MaterialUtils::CloneMaterials(UnityEngine.Renderer)
extern void MaterialUtils_CloneMaterials_m9C01FBDB4ACCE10E4669FAEF40DB52AEB9EFE3B7 (void);
// 0x000000A1 UnityEngine.Color Unity.XR.CoreUtils.MaterialUtils::HexToColor(System.String)
extern void MaterialUtils_HexToColor_m77731B12379E6649A606A3E5EC0F5F605C1EF82D (void);
// 0x000000A2 UnityEngine.Color Unity.XR.CoreUtils.MaterialUtils::HueShift(UnityEngine.Color,System.Single)
extern void MaterialUtils_HueShift_m586EED57859021FD4B833D9B1EC807B0CB41C543 (void);
// 0x000000A3 System.Void Unity.XR.CoreUtils.MaterialUtils::AddMaterial(UnityEngine.Renderer,UnityEngine.Material)
extern void MaterialUtils_AddMaterial_m8D5AC0C461F8871D0B92A14F4155712603D48558 (void);
// 0x000000A4 System.Boolean Unity.XR.CoreUtils.MathUtility::Approximately(System.Single,System.Single)
extern void MathUtility_Approximately_mC00DCCF291254BB5A0C520C72DCE947CFD24027F (void);
// 0x000000A5 System.Boolean Unity.XR.CoreUtils.MathUtility::ApproximatelyZero(System.Single)
extern void MathUtility_ApproximatelyZero_m0AEEA4272884D94792C421437D6B33E855A9EAC3 (void);
// 0x000000A6 System.Double Unity.XR.CoreUtils.MathUtility::Clamp(System.Double,System.Double,System.Double)
extern void MathUtility_Clamp_mA99290C9D58013CAF3678DCB4B61733605B69FD6 (void);
// 0x000000A7 System.Double Unity.XR.CoreUtils.MathUtility::ShortestAngleDistance(System.Double,System.Double,System.Double,System.Double)
extern void MathUtility_ShortestAngleDistance_mDFAF87293BB54EEBFF3E447B93106099B58AD115 (void);
// 0x000000A8 System.Single Unity.XR.CoreUtils.MathUtility::ShortestAngleDistance(System.Single,System.Single,System.Single,System.Single)
extern void MathUtility_ShortestAngleDistance_m066BF9C53CB54D202F6AA5D2DA2A1A63B0751002 (void);
// 0x000000A9 System.Boolean Unity.XR.CoreUtils.MathUtility::IsUndefined(System.Single)
extern void MathUtility_IsUndefined_mABAEA7E225419EDC5724013C966A72990F6B4D81 (void);
// 0x000000AA System.Boolean Unity.XR.CoreUtils.MathUtility::IsAxisAligned(UnityEngine.Vector3)
extern void MathUtility_IsAxisAligned_m98EED90876AAD328355727B63E61E78B35C53966 (void);
// 0x000000AB System.Boolean Unity.XR.CoreUtils.MathUtility::IsPositivePowerOfTwo(System.Int32)
extern void MathUtility_IsPositivePowerOfTwo_m304DAA2534245F76DC7D1C06C294EB81914AA92E (void);
// 0x000000AC System.Int32 Unity.XR.CoreUtils.MathUtility::FirstActiveFlagIndex(System.Int32)
extern void MathUtility_FirstActiveFlagIndex_m442F051A99C230A5110B67F95C57D5F6B5A6A564 (void);
// 0x000000AD System.Void Unity.XR.CoreUtils.MathUtility::.cctor()
extern void MathUtility__cctor_m0CB7256F9451DC9BF10245417E2967937099B8C1 (void);
// 0x000000AE System.Void Unity.XR.CoreUtils.NativeArrayUtils::EnsureCapacity(Unity.Collections.NativeArray`1<T>&,System.Int32,Unity.Collections.Allocator,Unity.Collections.NativeArrayOptions)
// 0x000000AF T Unity.XR.CoreUtils.ObjectPool`1::Get()
// 0x000000B0 System.Void Unity.XR.CoreUtils.ObjectPool`1::Recycle(T)
// 0x000000B1 System.Void Unity.XR.CoreUtils.ObjectPool`1::ClearInstance(T)
// 0x000000B2 System.Void Unity.XR.CoreUtils.ObjectPool`1::.ctor()
// 0x000000B3 System.Action`1<Unity.XR.CoreUtils.OnDestroyNotifier> Unity.XR.CoreUtils.OnDestroyNotifier::get_Destroyed()
extern void OnDestroyNotifier_get_Destroyed_m089279C60BA06F3BA1D78A8350ECE9882BD77603 (void);
// 0x000000B4 System.Void Unity.XR.CoreUtils.OnDestroyNotifier::set_Destroyed(System.Action`1<Unity.XR.CoreUtils.OnDestroyNotifier>)
extern void OnDestroyNotifier_set_Destroyed_m3C67D583F4CB4AD07A5BE88ED107C951E708A2B9 (void);
// 0x000000B5 System.Void Unity.XR.CoreUtils.OnDestroyNotifier::OnDestroy()
extern void OnDestroyNotifier_OnDestroy_m2253AFC37FC6668700F1E10857B730F60567DF90 (void);
// 0x000000B6 System.Void Unity.XR.CoreUtils.OnDestroyNotifier::.ctor()
extern void OnDestroyNotifier__ctor_mD07E187557F7C3C49B5DA9056AEED330FDAAF1E8 (void);
// 0x000000B7 System.Reflection.Assembly[] Unity.XR.CoreUtils.ReflectionUtils::GetCachedAssemblies()
extern void ReflectionUtils_GetCachedAssemblies_mFA5CFFF4F0396CC5CA42BD4F5C21D2229F1B7E09 (void);
// 0x000000B8 System.Collections.Generic.List`1<System.Type[]> Unity.XR.CoreUtils.ReflectionUtils::GetCachedTypesPerAssembly()
extern void ReflectionUtils_GetCachedTypesPerAssembly_m81A925E95978B8751FFB105CD0A9237F294CA2E4 (void);
// 0x000000B9 System.Collections.Generic.List`1<System.Collections.Generic.Dictionary`2<System.String,System.Type>> Unity.XR.CoreUtils.ReflectionUtils::GetCachedAssemblyTypeMaps()
extern void ReflectionUtils_GetCachedAssemblyTypeMaps_mB48977E26D388015D118C4A82BE2068B11D98A24 (void);
// 0x000000BA System.Void Unity.XR.CoreUtils.ReflectionUtils::PreWarmTypeCache()
extern void ReflectionUtils_PreWarmTypeCache_m8AC4BF054B608BA881C418D0E829DBBF1902B874 (void);
// 0x000000BB System.Void Unity.XR.CoreUtils.ReflectionUtils::ForEachAssembly(System.Action`1<System.Reflection.Assembly>)
extern void ReflectionUtils_ForEachAssembly_mF85A97A715CCD86A9CD68D3D11D6A285258B5BE6 (void);
// 0x000000BC System.Void Unity.XR.CoreUtils.ReflectionUtils::ForEachType(System.Action`1<System.Type>)
extern void ReflectionUtils_ForEachType_mA3DB0898D45683B95E26F13BDD7C597FF26CA678 (void);
// 0x000000BD System.Type Unity.XR.CoreUtils.ReflectionUtils::FindType(System.Func`2<System.Type,System.Boolean>)
extern void ReflectionUtils_FindType_mD9508F7DFEF76E5084E5E418BDF0D0734A3FE9E8 (void);
// 0x000000BE System.Type Unity.XR.CoreUtils.ReflectionUtils::FindTypeByFullName(System.String)
extern void ReflectionUtils_FindTypeByFullName_m868706D2196F7C456F726A7D26DEA58576D0607C (void);
// 0x000000BF System.Void Unity.XR.CoreUtils.ReflectionUtils::FindTypesBatch(System.Collections.Generic.List`1<System.Func`2<System.Type,System.Boolean>>,System.Collections.Generic.List`1<System.Type>)
extern void ReflectionUtils_FindTypesBatch_mD81222465D7879A0376D0253ED8388C27539EFD0 (void);
// 0x000000C0 System.Void Unity.XR.CoreUtils.ReflectionUtils::FindTypesByFullNameBatch(System.Collections.Generic.List`1<System.String>,System.Collections.Generic.List`1<System.Type>)
extern void ReflectionUtils_FindTypesByFullNameBatch_m35F35B17DF07A1D0C08E938AA515CAEC22803B17 (void);
// 0x000000C1 System.Type Unity.XR.CoreUtils.ReflectionUtils::FindTypeInAssemblyByFullName(System.String,System.String)
extern void ReflectionUtils_FindTypeInAssemblyByFullName_m343EF2C30AC810A3CF5389C9B28A26D6CA00D79F (void);
// 0x000000C2 System.String Unity.XR.CoreUtils.ReflectionUtils::NicifyVariableName(System.String)
extern void ReflectionUtils_NicifyVariableName_mB470A0AD683A6974EB0CFB903AFE1CE4E1B4C98C (void);
// 0x000000C3 T Unity.XR.CoreUtils.ScriptableSettings`1::get_Instance()
// 0x000000C4 T Unity.XR.CoreUtils.ScriptableSettings`1::CreateAndLoad()
// 0x000000C5 System.Void Unity.XR.CoreUtils.ScriptableSettings`1::.ctor()
// 0x000000C6 Unity.XR.CoreUtils.ScriptableSettingsBase Unity.XR.CoreUtils.ScriptableSettingsBase::GetInstanceByType(System.Type)
extern void ScriptableSettingsBase_GetInstanceByType_m082559541F19F255E6A4C91E1808E355367E55D9 (void);
// 0x000000C7 System.Void Unity.XR.CoreUtils.ScriptableSettingsBase::Awake()
extern void ScriptableSettingsBase_Awake_mBDD42FA0D36730C98E0E480E8E1C4E711A96B7C6 (void);
// 0x000000C8 System.Void Unity.XR.CoreUtils.ScriptableSettingsBase::OnEnable()
extern void ScriptableSettingsBase_OnEnable_m0157D649A6242B26149407B9B55F14985BCD4BAF (void);
// 0x000000C9 System.Void Unity.XR.CoreUtils.ScriptableSettingsBase::OnLoaded()
extern void ScriptableSettingsBase_OnLoaded_mBB3F1122638C208CA6F9E3EE0D70A86701401563 (void);
// 0x000000CA System.Boolean Unity.XR.CoreUtils.ScriptableSettingsBase::ValidatePath(System.String,System.String&)
extern void ScriptableSettingsBase_ValidatePath_m9B51B04EF0B066FF036F49CDCFA4CB524CA3133D (void);
// 0x000000CB System.Void Unity.XR.CoreUtils.ScriptableSettingsBase::.ctor()
extern void ScriptableSettingsBase__ctor_mA76719D647AA7F514E58FE1571177FFA8440F558 (void);
// 0x000000CC System.Void Unity.XR.CoreUtils.ScriptableSettingsBase::.cctor()
extern void ScriptableSettingsBase__cctor_m99ADDDFCCBDEC3690A29BAFC740443E0E7541FC2 (void);
// 0x000000CD System.Void Unity.XR.CoreUtils.ScriptableSettingsBase`1::.ctor()
// 0x000000CE System.Void Unity.XR.CoreUtils.ScriptableSettingsBase`1::Save(System.String)
// 0x000000CF System.String Unity.XR.CoreUtils.ScriptableSettingsBase`1::GetFilePath()
// 0x000000D0 System.Void Unity.XR.CoreUtils.ScriptableSettingsBase`1::.cctor()
// 0x000000D1 Unity.XR.CoreUtils.SerializableGuid Unity.XR.CoreUtils.SerializableGuid::get_Empty()
extern void SerializableGuid_get_Empty_m1A9A12E7D3B2FAD8E7C7C35A36D85BEDDED35069 (void);
// 0x000000D2 System.Guid Unity.XR.CoreUtils.SerializableGuid::get_Guid()
extern void SerializableGuid_get_Guid_m4122C089FF196FE3C90C3EC44B1B6C30A4BBCB49 (void);
// 0x000000D3 System.Void Unity.XR.CoreUtils.SerializableGuid::.ctor(System.UInt64,System.UInt64)
extern void SerializableGuid__ctor_mCB52F194155784E55FC04EEB9A5F086FE6F3EFF2 (void);
// 0x000000D4 System.Int32 Unity.XR.CoreUtils.SerializableGuid::GetHashCode()
extern void SerializableGuid_GetHashCode_mF9A1263046263FEC8529C736D400C3ADC2280ACA (void);
// 0x000000D5 System.Boolean Unity.XR.CoreUtils.SerializableGuid::Equals(System.Object)
extern void SerializableGuid_Equals_mCE9639B13AA49783B83F2803220A7C839735515D (void);
// 0x000000D6 System.String Unity.XR.CoreUtils.SerializableGuid::ToString()
extern void SerializableGuid_ToString_m0575B5BD028C35F5919D6696BD12AB2EDADF1E70 (void);
// 0x000000D7 System.String Unity.XR.CoreUtils.SerializableGuid::ToString(System.String)
extern void SerializableGuid_ToString_m2C4DBE079278618D23A8CD447C60763AC240361E (void);
// 0x000000D8 System.String Unity.XR.CoreUtils.SerializableGuid::ToString(System.String,System.IFormatProvider)
extern void SerializableGuid_ToString_mD57FADE1F89584D3F52212B039B903A5AAC8EAEA (void);
// 0x000000D9 System.Boolean Unity.XR.CoreUtils.SerializableGuid::Equals(Unity.XR.CoreUtils.SerializableGuid)
extern void SerializableGuid_Equals_m336B71967347FB7BD21D01C6EC949404D0BCAEB9 (void);
// 0x000000DA System.Boolean Unity.XR.CoreUtils.SerializableGuid::op_Equality(Unity.XR.CoreUtils.SerializableGuid,Unity.XR.CoreUtils.SerializableGuid)
extern void SerializableGuid_op_Equality_mA907EC50AE9646DF51C07188B4BFFC32C98A8113 (void);
// 0x000000DB System.Boolean Unity.XR.CoreUtils.SerializableGuid::op_Inequality(Unity.XR.CoreUtils.SerializableGuid,Unity.XR.CoreUtils.SerializableGuid)
extern void SerializableGuid_op_Inequality_m36E6F893FFD471F9C4B84E303F75463E257FDE1A (void);
// 0x000000DC System.Void Unity.XR.CoreUtils.SerializableGuid::.cctor()
extern void SerializableGuid__cctor_mD06800C1475E7298510597BD6C79C775B6214BDF (void);
// 0x000000DD Unity.XR.CoreUtils.SerializableGuid Unity.XR.CoreUtils.SerializableGuidUtil::Create(System.Guid)
extern void SerializableGuidUtil_Create_m389FF23480B573CB25590AE4BB6AE643419AED35 (void);
// 0x000000DE System.Void Unity.XR.CoreUtils.TextureUtils::RenderTextureToTexture2D(UnityEngine.RenderTexture,UnityEngine.Texture2D)
extern void TextureUtils_RenderTextureToTexture2D_m8BF334459E1E7BFB55895E612BB168C17DE8AEC8 (void);
// 0x000000DF System.Void Unity.XR.CoreUtils.UndoBlock::.ctor(System.String,System.Boolean)
extern void UndoBlock__ctor_mDAEDEB99D66092E46FB17AEDF712B864B0414CB3 (void);
// 0x000000E0 System.Void Unity.XR.CoreUtils.UndoBlock::RegisterCreatedObject(UnityEngine.Object)
extern void UndoBlock_RegisterCreatedObject_m98FC5C9CF54100F6D841E05D0939FD39E6D8444B (void);
// 0x000000E1 System.Void Unity.XR.CoreUtils.UndoBlock::RecordObject(UnityEngine.Object)
extern void UndoBlock_RecordObject_m452F0C62E711962689F7B7749CE464B7B6A3ABA7 (void);
// 0x000000E2 System.Void Unity.XR.CoreUtils.UndoBlock::SetTransformParent(UnityEngine.Transform,UnityEngine.Transform)
extern void UndoBlock_SetTransformParent_m99B405AD156DC20AAC3BE18D9168D20A039785EF (void);
// 0x000000E3 T Unity.XR.CoreUtils.UndoBlock::AddComponent(UnityEngine.GameObject)
// 0x000000E4 System.Void Unity.XR.CoreUtils.UndoBlock::Dispose(System.Boolean)
extern void UndoBlock_Dispose_m2768E03B14C160E718D182B4ED9E50A0F8BA6548 (void);
// 0x000000E5 System.Void Unity.XR.CoreUtils.UndoBlock::Dispose()
extern void UndoBlock_Dispose_mD20DB28590E9B55E8263B57D90A83E6A98E0D0E3 (void);
// 0x000000E6 System.Void Unity.XR.CoreUtils.UnityObjectUtils::Destroy(UnityEngine.Object,System.Boolean)
extern void UnityObjectUtils_Destroy_m652743F6965ED233E31D06DE55F5A135D78BE273 (void);
// 0x000000E7 T Unity.XR.CoreUtils.UnityObjectUtils::ConvertUnityObjectToType(UnityEngine.Object)
// 0x000000E8 System.Void Unity.XR.CoreUtils.UnityObjectUtils::RemoveDestroyedObjects(System.Collections.Generic.List`1<T>)
// 0x000000E9 System.Void Unity.XR.CoreUtils.UnityObjectUtils::RemoveDestroyedKeys(System.Collections.Generic.Dictionary`2<TKey,TValue>)
// 0x000000EA System.Void Unity.XR.CoreUtils.XRLoggingUtils::.cctor()
extern void XRLoggingUtils__cctor_m78EF4A6674C3E0F19EC5CD93B76ED220D13FF410 (void);
// 0x000000EB System.Void Unity.XR.CoreUtils.XRLoggingUtils::Log(System.String,UnityEngine.Object)
extern void XRLoggingUtils_Log_m66A906911E0BE114EC6820892B66F17C2A11984F (void);
// 0x000000EC System.Void Unity.XR.CoreUtils.XRLoggingUtils::LogWarning(System.String,UnityEngine.Object)
extern void XRLoggingUtils_LogWarning_mD34C4BA6428AED50B0602A6CE1FC52C18AF29169 (void);
// 0x000000ED System.Void Unity.XR.CoreUtils.XRLoggingUtils::LogError(System.String,UnityEngine.Object)
extern void XRLoggingUtils_LogError_mB11021B876C5F8758EC630CCD0E3814BB8DD7E79 (void);
// 0x000000EE System.Void Unity.XR.CoreUtils.XRLoggingUtils::LogException(System.Exception,UnityEngine.Object)
extern void XRLoggingUtils_LogException_m8ABDC360F58C6524F9452989EFD6EA1514764E73 (void);
// 0x000000EF UnityEngine.Camera Unity.XR.CoreUtils.XROrigin::get_Camera()
extern void XROrigin_get_Camera_m8959027D616F5BD9AEAE3E41ADEE23BBC2CE3629 (void);
// 0x000000F0 System.Void Unity.XR.CoreUtils.XROrigin::set_Camera(UnityEngine.Camera)
extern void XROrigin_set_Camera_m4C858ED48CE3A20504A55FAA1A24FE05D1CC450B (void);
// 0x000000F1 UnityEngine.Transform Unity.XR.CoreUtils.XROrigin::get_TrackablesParent()
extern void XROrigin_get_TrackablesParent_m6F7933DF03A5376C31D328F865F77D28EEC18E9C (void);
// 0x000000F2 System.Void Unity.XR.CoreUtils.XROrigin::set_TrackablesParent(UnityEngine.Transform)
extern void XROrigin_set_TrackablesParent_m2E813980627386E9DE2EA90D39FEEFAF80F31BC5 (void);
// 0x000000F3 System.Void Unity.XR.CoreUtils.XROrigin::add_TrackablesParentTransformChanged(System.Action`1<Unity.XR.CoreUtils.ARTrackablesParentTransformChangedEventArgs>)
extern void XROrigin_add_TrackablesParentTransformChanged_m04D2A05E3000931435B7F4CAC332E0EC2693B1EF (void);
// 0x000000F4 System.Void Unity.XR.CoreUtils.XROrigin::remove_TrackablesParentTransformChanged(System.Action`1<Unity.XR.CoreUtils.ARTrackablesParentTransformChangedEventArgs>)
extern void XROrigin_remove_TrackablesParentTransformChanged_m5517FF0B97A3705A7F03F8E42092165C6666163C (void);
// 0x000000F5 UnityEngine.GameObject Unity.XR.CoreUtils.XROrigin::get_Origin()
extern void XROrigin_get_Origin_mCE6A3B327ACE6FAEDCC67A9DC952FEED191C26B6 (void);
// 0x000000F6 System.Void Unity.XR.CoreUtils.XROrigin::set_Origin(UnityEngine.GameObject)
extern void XROrigin_set_Origin_m832CE9176B8C54EDC64059AFC67807EFE078249E (void);
// 0x000000F7 UnityEngine.GameObject Unity.XR.CoreUtils.XROrigin::get_CameraFloorOffsetObject()
extern void XROrigin_get_CameraFloorOffsetObject_m24DB58FD33D0D5436DC3A6F023D8780C1B82FD07 (void);
// 0x000000F8 System.Void Unity.XR.CoreUtils.XROrigin::set_CameraFloorOffsetObject(UnityEngine.GameObject)
extern void XROrigin_set_CameraFloorOffsetObject_m3182CAC8A600DB7EF22432EA3B71BF76A21C4839 (void);
// 0x000000F9 Unity.XR.CoreUtils.XROrigin/TrackingOriginMode Unity.XR.CoreUtils.XROrigin::get_RequestedTrackingOriginMode()
extern void XROrigin_get_RequestedTrackingOriginMode_m8475634D9A0C8ECA371A3F2EC216A55F7D2F2D3C (void);
// 0x000000FA System.Void Unity.XR.CoreUtils.XROrigin::set_RequestedTrackingOriginMode(Unity.XR.CoreUtils.XROrigin/TrackingOriginMode)
extern void XROrigin_set_RequestedTrackingOriginMode_m3B166DBAA7C7B18C63EBEA83A308911C094DF554 (void);
// 0x000000FB System.Single Unity.XR.CoreUtils.XROrigin::get_CameraYOffset()
extern void XROrigin_get_CameraYOffset_m223B472CA64A210F0F315A503FF621A6C74EC2A3 (void);
// 0x000000FC System.Void Unity.XR.CoreUtils.XROrigin::set_CameraYOffset(System.Single)
extern void XROrigin_set_CameraYOffset_mE11AF77FBC8B774E6CED34B10960AC9F747B67D1 (void);
// 0x000000FD UnityEngine.XR.TrackingOriginModeFlags Unity.XR.CoreUtils.XROrigin::get_CurrentTrackingOriginMode()
extern void XROrigin_get_CurrentTrackingOriginMode_m3117576FC85371E692EFFA853AF5297CEF150589 (void);
// 0x000000FE System.Void Unity.XR.CoreUtils.XROrigin::set_CurrentTrackingOriginMode(UnityEngine.XR.TrackingOriginModeFlags)
extern void XROrigin_set_CurrentTrackingOriginMode_mD2DF2D77407214FFDBED47C114DB0C1348C4F84E (void);
// 0x000000FF UnityEngine.Vector3 Unity.XR.CoreUtils.XROrigin::get_OriginInCameraSpacePos()
extern void XROrigin_get_OriginInCameraSpacePos_mF8CAAA59DDF4635AD3D7B1237B0742AA9BE283E6 (void);
// 0x00000100 UnityEngine.Vector3 Unity.XR.CoreUtils.XROrigin::get_CameraInOriginSpacePos()
extern void XROrigin_get_CameraInOriginSpacePos_m6646CE94E1798A767E559EB1D785D00AE8C68EB1 (void);
// 0x00000101 System.Single Unity.XR.CoreUtils.XROrigin::get_CameraInOriginSpaceHeight()
extern void XROrigin_get_CameraInOriginSpaceHeight_m1DC15C0A56A969838A827F425ABBED375751BFC5 (void);
// 0x00000102 System.Void Unity.XR.CoreUtils.XROrigin::MoveOffsetHeight()
extern void XROrigin_MoveOffsetHeight_m6336FBEAEA9FA0742D0B1740E2316A9CABDAA7AF (void);
// 0x00000103 System.Void Unity.XR.CoreUtils.XROrigin::MoveOffsetHeight(System.Single)
extern void XROrigin_MoveOffsetHeight_mF0B8B1C8D45F9EF0D2DD9534B443D6EC2A9FC248 (void);
// 0x00000104 System.Void Unity.XR.CoreUtils.XROrigin::TryInitializeCamera()
extern void XROrigin_TryInitializeCamera_mA9C7C0C6C44A0694CDA78FD55D1952E9506717C3 (void);
// 0x00000105 System.Boolean Unity.XR.CoreUtils.XROrigin::SetupCamera()
extern void XROrigin_SetupCamera_mE5719DCA5F732BE1D7BA0F543C614851A9D43655 (void);
// 0x00000106 System.Boolean Unity.XR.CoreUtils.XROrigin::SetupCamera(UnityEngine.XR.XRInputSubsystem)
extern void XROrigin_SetupCamera_mB2D4BC328855A681FAE0D20BB2011E44C98A0E89 (void);
// 0x00000107 System.Collections.IEnumerator Unity.XR.CoreUtils.XROrigin::RepeatInitializeCamera()
extern void XROrigin_RepeatInitializeCamera_mB5CEC27430D87F2017CFD3DAEC8275D68D71F319 (void);
// 0x00000108 System.Void Unity.XR.CoreUtils.XROrigin::OnInputSubsystemTrackingOriginUpdated(UnityEngine.XR.XRInputSubsystem)
extern void XROrigin_OnInputSubsystemTrackingOriginUpdated_m1D58DF267E36A73C5C5C5E155284D64D83810FD9 (void);
// 0x00000109 System.Boolean Unity.XR.CoreUtils.XROrigin::RotateAroundCameraUsingOriginUp(System.Single)
extern void XROrigin_RotateAroundCameraUsingOriginUp_m42AE0DFCFBA84AC3CBAAB74D78FB1EA361102EA2 (void);
// 0x0000010A System.Boolean Unity.XR.CoreUtils.XROrigin::RotateAroundCameraPosition(UnityEngine.Vector3,System.Single)
extern void XROrigin_RotateAroundCameraPosition_m7E496775B85028CDE1EDA5DFEFC36350F371AA59 (void);
// 0x0000010B System.Boolean Unity.XR.CoreUtils.XROrigin::MatchOriginUp(UnityEngine.Vector3)
extern void XROrigin_MatchOriginUp_m21E7F97625F9C616B757226DB083A8FE00297D1C (void);
// 0x0000010C System.Boolean Unity.XR.CoreUtils.XROrigin::MatchOriginUpCameraForward(UnityEngine.Vector3,UnityEngine.Vector3)
extern void XROrigin_MatchOriginUpCameraForward_m8D6A19292733DBEA380BF94DF74A6F9BC33E1F90 (void);
// 0x0000010D System.Boolean Unity.XR.CoreUtils.XROrigin::MatchOriginUpOriginForward(UnityEngine.Vector3,UnityEngine.Vector3)
extern void XROrigin_MatchOriginUpOriginForward_m6BB0CD69861590B4CA6F850D6824A47B37D2D5D3 (void);
// 0x0000010E System.Boolean Unity.XR.CoreUtils.XROrigin::MoveCameraToWorldLocation(UnityEngine.Vector3)
extern void XROrigin_MoveCameraToWorldLocation_m7AA0DF514F9F8E9E68541C314FAB868D043E5B4D (void);
// 0x0000010F System.Void Unity.XR.CoreUtils.XROrigin::Awake()
extern void XROrigin_Awake_mFC495553BD50D97BCE9BB513A9B2D4C2262B21A0 (void);
// 0x00000110 UnityEngine.Pose Unity.XR.CoreUtils.XROrigin::GetCameraOriginPose()
extern void XROrigin_GetCameraOriginPose_m8FBEAA33C27E17B6F461C20C6E53B51E6CDAFFCB (void);
// 0x00000111 System.Void Unity.XR.CoreUtils.XROrigin::OnEnable()
extern void XROrigin_OnEnable_mFD45AFA9DDB9FE432E6037D592DCEDBD28DF3ECA (void);
// 0x00000112 System.Void Unity.XR.CoreUtils.XROrigin::OnDisable()
extern void XROrigin_OnDisable_m26B6FCDEAC250714CDEAC57039B8ADE42B1B411C (void);
// 0x00000113 System.Void Unity.XR.CoreUtils.XROrigin::OnBeforeRender()
extern void XROrigin_OnBeforeRender_m4D292D007D30840EE0BBEE60BB1EF3E1FB3DF018 (void);
// 0x00000114 System.Void Unity.XR.CoreUtils.XROrigin::OnValidate()
extern void XROrigin_OnValidate_m26B16F4C6A9414A815BDED9E3C3075C9AA2E2AD3 (void);
// 0x00000115 System.Void Unity.XR.CoreUtils.XROrigin::Start()
extern void XROrigin_Start_m7F0D352F4EBEC07BE7C779E8B2997E6121C2E445 (void);
// 0x00000116 System.Void Unity.XR.CoreUtils.XROrigin::OnDestroy()
extern void XROrigin_OnDestroy_m90EB715086F324C473AA55917913EF5F130ED2DE (void);
// 0x00000117 System.Void Unity.XR.CoreUtils.XROrigin::.ctor()
extern void XROrigin__ctor_mD5AE064CEEF8128D772FABADBA6CDC2993C8079A (void);
// 0x00000118 System.Void Unity.XR.CoreUtils.XROrigin::.cctor()
extern void XROrigin__cctor_m52D9B7F5BC6700D7A13BE015B26DE8301823F5D7 (void);
// 0x00000119 System.Boolean Unity.XR.CoreUtils.XROrigin::<OnValidate>g__IsModeStale|60_0()
extern void XROrigin_U3COnValidateU3Eg__IsModeStaleU7C60_0_mB0B1ACE8BD4524258867625EA557440EF4CA5C30 (void);
// 0x0000011A System.Void Unity.XR.CoreUtils.XROrigin/<RepeatInitializeCamera>d__47::.ctor(System.Int32)
extern void U3CRepeatInitializeCameraU3Ed__47__ctor_m4DDEE160B15B4151C0EEAF03C247E9B6074EDAA7 (void);
// 0x0000011B System.Void Unity.XR.CoreUtils.XROrigin/<RepeatInitializeCamera>d__47::System.IDisposable.Dispose()
extern void U3CRepeatInitializeCameraU3Ed__47_System_IDisposable_Dispose_mB76482534CA269711B97E1A92426942F49B50712 (void);
// 0x0000011C System.Boolean Unity.XR.CoreUtils.XROrigin/<RepeatInitializeCamera>d__47::MoveNext()
extern void U3CRepeatInitializeCameraU3Ed__47_MoveNext_m6A8892F7FD505B6C9BCB3F9E25004D5F9926DE55 (void);
// 0x0000011D System.Object Unity.XR.CoreUtils.XROrigin/<RepeatInitializeCamera>d__47::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CRepeatInitializeCameraU3Ed__47_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m4F74CCBBEC8FCC379C32EBD2E402CB25B2340E49 (void);
// 0x0000011E System.Void Unity.XR.CoreUtils.XROrigin/<RepeatInitializeCamera>d__47::System.Collections.IEnumerator.Reset()
extern void U3CRepeatInitializeCameraU3Ed__47_System_Collections_IEnumerator_Reset_m21DFF34B3C0E1070227FB042DBDA80CFF6B3158E (void);
// 0x0000011F System.Object Unity.XR.CoreUtils.XROrigin/<RepeatInitializeCamera>d__47::System.Collections.IEnumerator.get_Current()
extern void U3CRepeatInitializeCameraU3Ed__47_System_Collections_IEnumerator_get_Current_m3C55C0A18DF81F6CA8467B7D48E81AE6C69B835C (void);
// 0x00000120 System.Void Unity.XR.CoreUtils.GUI.EnumDisplayAttribute::.ctor(System.Object[])
extern void EnumDisplayAttribute__ctor_mA3848EC7E676432BB6BF008C27E7E2C2B63A576A (void);
// 0x00000121 System.Void Unity.XR.CoreUtils.GUI.FlagsPropertyAttribute::.ctor()
extern void FlagsPropertyAttribute__ctor_mB1E45E123C188E357A1FB8D6FA2ADD9182A9D034 (void);
static Il2CppMethodPointer s_methodPointers[289] = 
{
	ARTrackablesParentTransformChangedEventArgs_get_Origin_m91D7C3638FBF94D468AD4467ABB2EC9500753F25,
	ARTrackablesParentTransformChangedEventArgs_get_TrackablesParent_m89F1B7B428A07F5142AEC2BF32A83B35B52C0425,
	ARTrackablesParentTransformChangedEventArgs__ctor_m46B5D18DF81A7296E36E37917E69AB9E748B6278,
	ARTrackablesParentTransformChangedEventArgs_Equals_m8CAA7BD42F09BF7349818EF3166792652FB9F4AE,
	ARTrackablesParentTransformChangedEventArgs_Equals_mE6F5F659DD06166ACDDCE62B0652F014568D003B,
	ARTrackablesParentTransformChangedEventArgs_GetHashCode_mA5FDE9D7D0F5F079886AA4C5DF806E082C725161,
	ARTrackablesParentTransformChangedEventArgs_op_Equality_mF3CCF808B9E2F13DECF746856561F0FBB9F67D73,
	ARTrackablesParentTransformChangedEventArgs_op_Inequality_mDF5363BA1D4063FAE987EA2DDF7379BC102C800F,
	ReadOnlyAttribute__ctor_m13C3453A8526FBD0C9F45B0F0539CE1208546815,
	ScriptableSettingsPathAttribute_get_Path_mC767AB284DF1262E0EAA6AA36628A4A9035B646F,
	ScriptableSettingsPathAttribute__ctor_mC942C941C139A27C8B05E732EF21E6E2FFF9E808,
	BoundsUtils_GetBounds_m10F7E25BCAEDF9C9F6C88F2371DE95492CD00F0C,
	BoundsUtils_GetBounds_m05F2E93FF84428AEBECEE046972706A03DAEF0CA,
	BoundsUtils_GetBounds_m37581B4C0428FBB171251D77E1148B8DD8733FD5,
	BoundsUtils_GetBounds_m9CF444D9E9C0B2BB61ECAC1457CB3E2FE64E858F,
	NULL,
	BoundsUtils_GetBounds_m111209CDC60D1529A15E20EC7D6C9311959AC075,
	BoundsUtils__cctor_m0BF977E144962DF016A62C9A2BB566975B5ECFDB,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	BoundsExtensions_ContainsCompletely_m8602D6C63C6E5394D5AC7AA833A1456DAB5888B9,
	CameraExtensions_GetVerticalFieldOfView_m0C6216CB884E1D5A1678998B9566FAC91F28BBAC,
	CameraExtensions_GetHorizontalFieldOfView_m852B8A5A60F036F8E09D3EEA5D572432D48041E6,
	CameraExtensions_GetVerticalOrthographicSize_mB1A0C96B45B45EF1C369AE8189F096731FF8D27E,
	NULL,
	CollectionExtensions__cctor_m257181DE1D15E554336D452F505895F1A918C83A,
	NULL,
	GameObjectExtensions_SetHideFlagsRecursively_m1D9800818E28035945B29B26AC7369B456B9C67A,
	GameObjectExtensions_AddToHideFlagsRecursively_m2FF5C9D0FCCE193AA290E4E52213C66A1E9CE696,
	GameObjectExtensions_SetLayerRecursively_mEBBB0450F5DEC5C505CA9892F981AAF6BAF5463B,
	GameObjectExtensions_SetLayerAndAddToHideFlagsRecursively_m4369A5EF54EDC5DA66C4B08227DF55D625F7C75C,
	GameObjectExtensions_SetLayerAndHideFlagsRecursively_m6736B901E74C100814C434157BECB79514F16D40,
	GameObjectExtensions_SetRunInEditModeRecursively_mFB07A0BA8EEA6EFE90ED5B8737F1AEDA6EBB6B42,
	GuidExtensions_Decompose_m574442B0FAF7CFEE4BA0BAF8209F51308C04B80C,
	NULL,
	NULL,
	LayerMaskExtensions_GetFirstLayerIndex_m2C0A16C506E5B9C5B08F4D1332361E9A513EE75A,
	LayerMaskExtensions_Contains_m4EB2480554BA1EEF78C3A4F6165AA2F1D8FD7D0D,
	NULL,
	NULL,
	PoseExtensions_ApplyOffsetTo_mCA13DA87F5C4587B48E0DE3C8ECAC514581D5C60,
	PoseExtensions_ApplyOffsetTo_mE34A80DDB3E3303D6B03ECCEAF86155D132B522A,
	PoseExtensions_ApplyInverseOffsetTo_m19A415A1473DDF2B68FB83D306656910E72C9D3B,
	QuaternionExtensions_ConstrainYaw_m8564D6572C5D7169E9B48DEACBBA8E93EDBFABE7,
	QuaternionExtensions_ConstrainYawNormalized_m59E7A2BE631745700E7A9E71A4C30A2CE916B0E7,
	QuaternionExtensions_ConstrainYawPitchNormalized_m61F4789E8A9D6483B1490765F2886E8C329C9269,
	StringExtensions_FirstToUpper_m23B2D0DD59B91DD88571C96B8268E3368E9DAA3F,
	StringExtensions_InsertSpacesBetweenWords_m007D0DB6D7C0BBD89819F00D407B8ECF3BCA23E0,
	StringExtensions__cctor_m938B8A990F47C7F8D7FD8E368AE024FA6F222966,
	TransformExtensions_GetLocalPose_m8094B038D295D5EC653A1809E984A1426044CD88,
	TransformExtensions_GetWorldPose_m9D21B0564EA540CF54C761F9C73F77F37F146D4D,
	TransformExtensions_SetLocalPose_m76856288B34BC31E5AC19D86AFFFF17E607F6BC0,
	TransformExtensions_SetWorldPose_mBE5770AE0BD22C934198C8B2CF8DB9E165D758B2,
	TransformExtensions_TransformPose_mFEB5D4C90DD8CA9ABDB23FA5F6EB0D8F9DFEB0C0,
	TransformExtensions_InverseTransformPose_m02C4C15F207035129435CABAE86BA9EA5786734B,
	TransformExtensions_InverseTransformRay_mBDA961A6DF20D7FE3EC7438973AD25CBC3DF8051,
	TypeExtensions_GetAssignableTypes_mDCA9CD5F98812F50A9EFBE266D307629B45832B5,
	TypeExtensions_GetImplementationsOfInterface_m1F0A81C1CAD8A5749BA8855E9F3F9D825FF425BC,
	TypeExtensions_GetExtensionsOfClass_m6F971E2D8B286DA6E1C9F0F5ECDFF295779E9EF3,
	TypeExtensions_GetGenericInterfaces_m233AE28D855F5100DE0A3579E8738358AD361255,
	TypeExtensions_GetPropertyRecursively_mFBCE55028E50841DE712128781E0CA5775112668,
	TypeExtensions_GetFieldRecursively_m8F1731890D1467E55C1FD6CC9F8E806529495623,
	TypeExtensions_GetFieldsRecursively_m546320169FEE9DADA681AEB3373B3CA694695813,
	TypeExtensions_GetPropertiesRecursively_m5DC5DBFB2A1E6BDDF7B5D0FDE7F3B9D3A73F5808,
	TypeExtensions_GetInterfaceFieldsFromClasses_m4DB43352F2A2D34D587D98C73BA21E57AF9EDAF0,
	NULL,
	NULL,
	TypeExtensions_GetFieldInTypeOrBaseType_m551CF2E4240A813ADB5C4BE26867BE3C544642E8,
	TypeExtensions_GetNameWithGenericArguments_m00A7B891B4CF156A0FD941E913171754067BA821,
	TypeExtensions_GetNameWithFullGenericArguments_mA28CDBF80811149115DEAFC7C9C11F839A94650E,
	TypeExtensions_GetFullNameWithGenericArguments_m219B2A27B25E9E6A80A3B748329329D5763EFB5F,
	TypeExtensions_GetFullNameWithGenericArgumentsInternal_mCA07B472A237A063651781A95F761E1873123358,
	TypeExtensions_IsAssignableFromOrSubclassOf_mBD6A28891E5ABA30A7AFE9FFFEF1810E248ECAB7,
	TypeExtensions_GetMethodRecursively_mE590CEF50FB0D2A536FC82AFD542F2EA568AF567,
	TypeExtensions__cctor_mA8563E03790781B4336379A74E5C0725E08FB55C,
	U3CU3Ec__DisplayClass2_0__ctor_m503826A926363EA4EAF9A0DE52DA34382B75C925,
	U3CU3Ec__DisplayClass2_0_U3CGetAssignableTypesU3Eb__0_m605F61DF1647ACBAF3D37F9AB38C2478C6BC5E57,
	Vector2Extensions_Inverse_m53BC362EF0D505A5D44464DC72C689F8F77283DE,
	Vector2Extensions_MinComponent_mD48D421FB5DCC40C53CFBBA645B0BA02BFFA0A65,
	Vector2Extensions_MaxComponent_mFB94549B6163A31AABD5A610CF4E496CE23B5F1D,
	Vector2Extensions_Abs_m224ED011C4857D0EE79CFC9C71DEDB3D792C9ABE,
	Vector3Extensions_Inverse_mE160B5FA7953B8897A11937CBC7B632B61668E3A,
	Vector3Extensions_MinComponent_m13370F40717B0926B26745E7586F770E1DC22C00,
	Vector3Extensions_MaxComponent_m7F7CEF38DB40E4C1B2203D821FBFFC085DE7C696,
	Vector3Extensions_Abs_m5546503290D009FF363F2C5279A502B749F92AC1,
	GameObjectUtils_add_GameObjectInstantiated_m052A1ABEF1010C4E9D9288CE7ADDBE0095F010B4,
	GameObjectUtils_remove_GameObjectInstantiated_m22490A7BA15C1DF76100AE542585E32F1C4CEF69,
	GameObjectUtils_Create_mC589C5D5A81BF0A64CBD7EB0470CA4C2A484FA79,
	GameObjectUtils_Create_m62DFB2CA101FC3E009EF8DDCED70711BEE1C2EF2,
	GameObjectUtils_Instantiate_mC01BADA88B24537F04AB71DFE14E6B77C0E5DB96,
	GameObjectUtils_Instantiate_m0DA555EA05C419981D74FCC1FE602D125FA11133,
	GameObjectUtils_Instantiate_m485AC32BF5A5CFBAB6AF5A905B02F89AF3D29933,
	GameObjectUtils_CloneWithHideFlags_mEF25DF8A4E9122B0F354867F757B58F7E7CABA25,
	GameObjectUtils_CopyHideFlagsRecursively_m980DBD37550E928E6A0605B88C3BA824BC16871E,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	GameObjectUtils_GetChildGameObjects_m8B12380F88912399A4E85B23DD1B738DA30C60B8,
	GameObjectUtils_GetNamedChild_mA76A1E5EF192028632794E5DC04EECC349853BC2,
	GameObjectUtils__cctor_m3C64181578FAFAD75EF878775ED6530721BB807B,
	U3CU3Ec__DisplayClass20_0__ctor_mB1AF49A2B6F9488132A2E8939817133973337254,
	U3CU3Ec__DisplayClass20_0_U3CGetNamedChildU3Eb__0_m7B07F30C4FDAF96F9DF2B6864BF3E6810BDA8271,
	GeometryUtils_FindClosestEdge_m0F7FD65B046CE54774B01E431D40AFE6072EF310,
	GeometryUtils_PointOnOppositeSideOfPolygon_m191912ABDDB24465677D144BC5EE8C6F7B5503F8,
	GeometryUtils_TriangulatePolygon_m924E2453CFA1358CFC0B85862F00BCF56B855B9D,
	GeometryUtils_ClosestTimesOnTwoLines_m883D01C52ED19A788A5232DBDE726A7079C03A00,
	GeometryUtils_ClosestTimesOnTwoLinesXZ_m9F62C077493CBE8B706A6A8B75950685990C9D92,
	GeometryUtils_ClosestPointsOnTwoLineSegments_m6BC887D811464AF1B74FE9B18E52667C7CF8337E,
	GeometryUtils_ClosestPointOnLineSegment_m0A225333430C44FEF56DC2AEBC5B5F64D0C1C271,
	GeometryUtils_ClosestPolygonApproach_m438A3196B7478B0AB9C6B81B41BA2DA33943C9B4,
	GeometryUtils_PointInPolygon_m99BAD947FC3B8AFBEB500E10BD4D56EA69BEAB48,
	GeometryUtils_PointInPolygon3D_m5BD04A6C9E23B2568A416825BCCBBCE2571BAAE4,
	GeometryUtils_ProjectPointOnPlane_mECE172615E445977F6FC1E80D228ACB663079CFE,
	GeometryUtils_ConvexHull2D_mD5960873113EBFE9F6A6ACC2D47EE1154F73F335,
	GeometryUtils_PolygonCentroid2D_m2516A07125F2809AA5C7F8C7EB5C5E11334A680F,
	GeometryUtils_OrientedMinimumBoundingBox2D_mF8D0B3C51697E90590EA880AE50089D03D1B022D,
	GeometryUtils_RotateCalipers_m8D4357E76037BED2CA3C53394BE6A5B4614EF16E,
	GeometryUtils_RotationForBox_mAE65F788A071112CC5A8482EDC6C20778E9BBA45,
	GeometryUtils_ConvexPolygonArea_m822057386EA7F103805E769EB1C8C245B024289B,
	GeometryUtils_PolygonInPolygon_m0F03C275DD603611951CF393F912B37C41B62194,
	GeometryUtils_PolygonsWithinRange_m427FF406477F28960C31E413547C83E5E0ED95EA,
	GeometryUtils_PolygonsWithinSqRange_mEC2539F5CF1FF9F569E1FA97FF2DEDD99312E4D9,
	GeometryUtils_PointOnPolygonBoundsXZ_m52429F42CD1E0C1A1769F35F3A535FA63EF9560C,
	GeometryUtils_PointOnLineSegmentXZ_m5B56E6ABEC3867132E38F599417909928FD5F63B,
	GeometryUtils_NormalizeRotationKeepingUp_mE3B160896A4ECBBE1841D3DAFF2AFB00A6536EC7,
	GeometryUtils_PolygonUVPoseFromPlanePose_m1FFC85683F3E494C8AF6DC2F2F2BB4773341B7CF,
	GeometryUtils_PolygonVertexToUV_m30385D80574DDB089A90FC8C4FE306F1E92A4963,
	GeometryUtils__cctor_mBD458259FCFC5DC054BE45C6C3B27F0C1ADD52E3,
	GuidUtil_Compose_m944D3327AACECCAFEBF84434875B2F25D84F08A1,
	HashCodeUtil_Combine_m0947FF25308C4EAF03F04A09D0C9037371E09E80,
	HashCodeUtil_ReferenceHash_m5A135DC218865E418D3965B2A432A0B649DD9863,
	HashCodeUtil_Combine_mD0D5C6E0B1628514717AF46ECCCCA4859B96D00B,
	HashCodeUtil_Combine_mFA75BDAA1FC48B90D8E0AB405C62303DBBD4581A,
	HashCodeUtil_Combine_m17C420993EDFFC48138CF88B9340E323CDC04971,
	HashCodeUtil_Combine_m301D9F4956E4E0689E28466F9DBD3097E12377C6,
	HashCodeUtil_Combine_mB38F06ABAA3544284AABF914BF1A71C223B95962,
	HashCodeUtil_Combine_mDD784B4B8DA3E8E85409D0B1E5917CBD04E99A0F,
	MaterialUtils_GetMaterialClone_m68A92B332B1F70DBFB060E6A1D94F7737DF0FCEA,
	MaterialUtils_GetMaterialClone_mA94F9D8F608583D66873B90FC8882D2C0B599B0B,
	MaterialUtils_CloneMaterials_m9C01FBDB4ACCE10E4669FAEF40DB52AEB9EFE3B7,
	MaterialUtils_HexToColor_m77731B12379E6649A606A3E5EC0F5F605C1EF82D,
	MaterialUtils_HueShift_m586EED57859021FD4B833D9B1EC807B0CB41C543,
	MaterialUtils_AddMaterial_m8D5AC0C461F8871D0B92A14F4155712603D48558,
	MathUtility_Approximately_mC00DCCF291254BB5A0C520C72DCE947CFD24027F,
	MathUtility_ApproximatelyZero_m0AEEA4272884D94792C421437D6B33E855A9EAC3,
	MathUtility_Clamp_mA99290C9D58013CAF3678DCB4B61733605B69FD6,
	MathUtility_ShortestAngleDistance_mDFAF87293BB54EEBFF3E447B93106099B58AD115,
	MathUtility_ShortestAngleDistance_m066BF9C53CB54D202F6AA5D2DA2A1A63B0751002,
	MathUtility_IsUndefined_mABAEA7E225419EDC5724013C966A72990F6B4D81,
	MathUtility_IsAxisAligned_m98EED90876AAD328355727B63E61E78B35C53966,
	MathUtility_IsPositivePowerOfTwo_m304DAA2534245F76DC7D1C06C294EB81914AA92E,
	MathUtility_FirstActiveFlagIndex_m442F051A99C230A5110B67F95C57D5F6B5A6A564,
	MathUtility__cctor_m0CB7256F9451DC9BF10245417E2967937099B8C1,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	OnDestroyNotifier_get_Destroyed_m089279C60BA06F3BA1D78A8350ECE9882BD77603,
	OnDestroyNotifier_set_Destroyed_m3C67D583F4CB4AD07A5BE88ED107C951E708A2B9,
	OnDestroyNotifier_OnDestroy_m2253AFC37FC6668700F1E10857B730F60567DF90,
	OnDestroyNotifier__ctor_mD07E187557F7C3C49B5DA9056AEED330FDAAF1E8,
	ReflectionUtils_GetCachedAssemblies_mFA5CFFF4F0396CC5CA42BD4F5C21D2229F1B7E09,
	ReflectionUtils_GetCachedTypesPerAssembly_m81A925E95978B8751FFB105CD0A9237F294CA2E4,
	ReflectionUtils_GetCachedAssemblyTypeMaps_mB48977E26D388015D118C4A82BE2068B11D98A24,
	ReflectionUtils_PreWarmTypeCache_m8AC4BF054B608BA881C418D0E829DBBF1902B874,
	ReflectionUtils_ForEachAssembly_mF85A97A715CCD86A9CD68D3D11D6A285258B5BE6,
	ReflectionUtils_ForEachType_mA3DB0898D45683B95E26F13BDD7C597FF26CA678,
	ReflectionUtils_FindType_mD9508F7DFEF76E5084E5E418BDF0D0734A3FE9E8,
	ReflectionUtils_FindTypeByFullName_m868706D2196F7C456F726A7D26DEA58576D0607C,
	ReflectionUtils_FindTypesBatch_mD81222465D7879A0376D0253ED8388C27539EFD0,
	ReflectionUtils_FindTypesByFullNameBatch_m35F35B17DF07A1D0C08E938AA515CAEC22803B17,
	ReflectionUtils_FindTypeInAssemblyByFullName_m343EF2C30AC810A3CF5389C9B28A26D6CA00D79F,
	ReflectionUtils_NicifyVariableName_mB470A0AD683A6974EB0CFB903AFE1CE4E1B4C98C,
	NULL,
	NULL,
	NULL,
	ScriptableSettingsBase_GetInstanceByType_m082559541F19F255E6A4C91E1808E355367E55D9,
	ScriptableSettingsBase_Awake_mBDD42FA0D36730C98E0E480E8E1C4E711A96B7C6,
	ScriptableSettingsBase_OnEnable_m0157D649A6242B26149407B9B55F14985BCD4BAF,
	ScriptableSettingsBase_OnLoaded_mBB3F1122638C208CA6F9E3EE0D70A86701401563,
	ScriptableSettingsBase_ValidatePath_m9B51B04EF0B066FF036F49CDCFA4CB524CA3133D,
	ScriptableSettingsBase__ctor_mA76719D647AA7F514E58FE1571177FFA8440F558,
	ScriptableSettingsBase__cctor_m99ADDDFCCBDEC3690A29BAFC740443E0E7541FC2,
	NULL,
	NULL,
	NULL,
	NULL,
	SerializableGuid_get_Empty_m1A9A12E7D3B2FAD8E7C7C35A36D85BEDDED35069,
	SerializableGuid_get_Guid_m4122C089FF196FE3C90C3EC44B1B6C30A4BBCB49,
	SerializableGuid__ctor_mCB52F194155784E55FC04EEB9A5F086FE6F3EFF2,
	SerializableGuid_GetHashCode_mF9A1263046263FEC8529C736D400C3ADC2280ACA,
	SerializableGuid_Equals_mCE9639B13AA49783B83F2803220A7C839735515D,
	SerializableGuid_ToString_m0575B5BD028C35F5919D6696BD12AB2EDADF1E70,
	SerializableGuid_ToString_m2C4DBE079278618D23A8CD447C60763AC240361E,
	SerializableGuid_ToString_mD57FADE1F89584D3F52212B039B903A5AAC8EAEA,
	SerializableGuid_Equals_m336B71967347FB7BD21D01C6EC949404D0BCAEB9,
	SerializableGuid_op_Equality_mA907EC50AE9646DF51C07188B4BFFC32C98A8113,
	SerializableGuid_op_Inequality_m36E6F893FFD471F9C4B84E303F75463E257FDE1A,
	SerializableGuid__cctor_mD06800C1475E7298510597BD6C79C775B6214BDF,
	SerializableGuidUtil_Create_m389FF23480B573CB25590AE4BB6AE643419AED35,
	TextureUtils_RenderTextureToTexture2D_m8BF334459E1E7BFB55895E612BB168C17DE8AEC8,
	UndoBlock__ctor_mDAEDEB99D66092E46FB17AEDF712B864B0414CB3,
	UndoBlock_RegisterCreatedObject_m98FC5C9CF54100F6D841E05D0939FD39E6D8444B,
	UndoBlock_RecordObject_m452F0C62E711962689F7B7749CE464B7B6A3ABA7,
	UndoBlock_SetTransformParent_m99B405AD156DC20AAC3BE18D9168D20A039785EF,
	NULL,
	UndoBlock_Dispose_m2768E03B14C160E718D182B4ED9E50A0F8BA6548,
	UndoBlock_Dispose_mD20DB28590E9B55E8263B57D90A83E6A98E0D0E3,
	UnityObjectUtils_Destroy_m652743F6965ED233E31D06DE55F5A135D78BE273,
	NULL,
	NULL,
	NULL,
	XRLoggingUtils__cctor_m78EF4A6674C3E0F19EC5CD93B76ED220D13FF410,
	XRLoggingUtils_Log_m66A906911E0BE114EC6820892B66F17C2A11984F,
	XRLoggingUtils_LogWarning_mD34C4BA6428AED50B0602A6CE1FC52C18AF29169,
	XRLoggingUtils_LogError_mB11021B876C5F8758EC630CCD0E3814BB8DD7E79,
	XRLoggingUtils_LogException_m8ABDC360F58C6524F9452989EFD6EA1514764E73,
	XROrigin_get_Camera_m8959027D616F5BD9AEAE3E41ADEE23BBC2CE3629,
	XROrigin_set_Camera_m4C858ED48CE3A20504A55FAA1A24FE05D1CC450B,
	XROrigin_get_TrackablesParent_m6F7933DF03A5376C31D328F865F77D28EEC18E9C,
	XROrigin_set_TrackablesParent_m2E813980627386E9DE2EA90D39FEEFAF80F31BC5,
	XROrigin_add_TrackablesParentTransformChanged_m04D2A05E3000931435B7F4CAC332E0EC2693B1EF,
	XROrigin_remove_TrackablesParentTransformChanged_m5517FF0B97A3705A7F03F8E42092165C6666163C,
	XROrigin_get_Origin_mCE6A3B327ACE6FAEDCC67A9DC952FEED191C26B6,
	XROrigin_set_Origin_m832CE9176B8C54EDC64059AFC67807EFE078249E,
	XROrigin_get_CameraFloorOffsetObject_m24DB58FD33D0D5436DC3A6F023D8780C1B82FD07,
	XROrigin_set_CameraFloorOffsetObject_m3182CAC8A600DB7EF22432EA3B71BF76A21C4839,
	XROrigin_get_RequestedTrackingOriginMode_m8475634D9A0C8ECA371A3F2EC216A55F7D2F2D3C,
	XROrigin_set_RequestedTrackingOriginMode_m3B166DBAA7C7B18C63EBEA83A308911C094DF554,
	XROrigin_get_CameraYOffset_m223B472CA64A210F0F315A503FF621A6C74EC2A3,
	XROrigin_set_CameraYOffset_mE11AF77FBC8B774E6CED34B10960AC9F747B67D1,
	XROrigin_get_CurrentTrackingOriginMode_m3117576FC85371E692EFFA853AF5297CEF150589,
	XROrigin_set_CurrentTrackingOriginMode_mD2DF2D77407214FFDBED47C114DB0C1348C4F84E,
	XROrigin_get_OriginInCameraSpacePos_mF8CAAA59DDF4635AD3D7B1237B0742AA9BE283E6,
	XROrigin_get_CameraInOriginSpacePos_m6646CE94E1798A767E559EB1D785D00AE8C68EB1,
	XROrigin_get_CameraInOriginSpaceHeight_m1DC15C0A56A969838A827F425ABBED375751BFC5,
	XROrigin_MoveOffsetHeight_m6336FBEAEA9FA0742D0B1740E2316A9CABDAA7AF,
	XROrigin_MoveOffsetHeight_mF0B8B1C8D45F9EF0D2DD9534B443D6EC2A9FC248,
	XROrigin_TryInitializeCamera_mA9C7C0C6C44A0694CDA78FD55D1952E9506717C3,
	XROrigin_SetupCamera_mE5719DCA5F732BE1D7BA0F543C614851A9D43655,
	XROrigin_SetupCamera_mB2D4BC328855A681FAE0D20BB2011E44C98A0E89,
	XROrigin_RepeatInitializeCamera_mB5CEC27430D87F2017CFD3DAEC8275D68D71F319,
	XROrigin_OnInputSubsystemTrackingOriginUpdated_m1D58DF267E36A73C5C5C5E155284D64D83810FD9,
	XROrigin_RotateAroundCameraUsingOriginUp_m42AE0DFCFBA84AC3CBAAB74D78FB1EA361102EA2,
	XROrigin_RotateAroundCameraPosition_m7E496775B85028CDE1EDA5DFEFC36350F371AA59,
	XROrigin_MatchOriginUp_m21E7F97625F9C616B757226DB083A8FE00297D1C,
	XROrigin_MatchOriginUpCameraForward_m8D6A19292733DBEA380BF94DF74A6F9BC33E1F90,
	XROrigin_MatchOriginUpOriginForward_m6BB0CD69861590B4CA6F850D6824A47B37D2D5D3,
	XROrigin_MoveCameraToWorldLocation_m7AA0DF514F9F8E9E68541C314FAB868D043E5B4D,
	XROrigin_Awake_mFC495553BD50D97BCE9BB513A9B2D4C2262B21A0,
	XROrigin_GetCameraOriginPose_m8FBEAA33C27E17B6F461C20C6E53B51E6CDAFFCB,
	XROrigin_OnEnable_mFD45AFA9DDB9FE432E6037D592DCEDBD28DF3ECA,
	XROrigin_OnDisable_m26B6FCDEAC250714CDEAC57039B8ADE42B1B411C,
	XROrigin_OnBeforeRender_m4D292D007D30840EE0BBEE60BB1EF3E1FB3DF018,
	XROrigin_OnValidate_m26B16F4C6A9414A815BDED9E3C3075C9AA2E2AD3,
	XROrigin_Start_m7F0D352F4EBEC07BE7C779E8B2997E6121C2E445,
	XROrigin_OnDestroy_m90EB715086F324C473AA55917913EF5F130ED2DE,
	XROrigin__ctor_mD5AE064CEEF8128D772FABADBA6CDC2993C8079A,
	XROrigin__cctor_m52D9B7F5BC6700D7A13BE015B26DE8301823F5D7,
	XROrigin_U3COnValidateU3Eg__IsModeStaleU7C60_0_mB0B1ACE8BD4524258867625EA557440EF4CA5C30,
	U3CRepeatInitializeCameraU3Ed__47__ctor_m4DDEE160B15B4151C0EEAF03C247E9B6074EDAA7,
	U3CRepeatInitializeCameraU3Ed__47_System_IDisposable_Dispose_mB76482534CA269711B97E1A92426942F49B50712,
	U3CRepeatInitializeCameraU3Ed__47_MoveNext_m6A8892F7FD505B6C9BCB3F9E25004D5F9926DE55,
	U3CRepeatInitializeCameraU3Ed__47_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m4F74CCBBEC8FCC379C32EBD2E402CB25B2340E49,
	U3CRepeatInitializeCameraU3Ed__47_System_Collections_IEnumerator_Reset_m21DFF34B3C0E1070227FB042DBDA80CFF6B3158E,
	U3CRepeatInitializeCameraU3Ed__47_System_Collections_IEnumerator_get_Current_m3C55C0A18DF81F6CA8467B7D48E81AE6C69B835C,
	EnumDisplayAttribute__ctor_mA3848EC7E676432BB6BF008C27E7E2C2B63A576A,
	FlagsPropertyAttribute__ctor_mB1E45E123C188E357A1FB8D6FA2ADD9182A9D034,
};
extern void ARTrackablesParentTransformChangedEventArgs_get_Origin_m91D7C3638FBF94D468AD4467ABB2EC9500753F25_AdjustorThunk (void);
extern void ARTrackablesParentTransformChangedEventArgs_get_TrackablesParent_m89F1B7B428A07F5142AEC2BF32A83B35B52C0425_AdjustorThunk (void);
extern void ARTrackablesParentTransformChangedEventArgs__ctor_m46B5D18DF81A7296E36E37917E69AB9E748B6278_AdjustorThunk (void);
extern void ARTrackablesParentTransformChangedEventArgs_Equals_m8CAA7BD42F09BF7349818EF3166792652FB9F4AE_AdjustorThunk (void);
extern void ARTrackablesParentTransformChangedEventArgs_Equals_mE6F5F659DD06166ACDDCE62B0652F014568D003B_AdjustorThunk (void);
extern void ARTrackablesParentTransformChangedEventArgs_GetHashCode_mA5FDE9D7D0F5F079886AA4C5DF806E082C725161_AdjustorThunk (void);
extern void SerializableGuid_get_Guid_m4122C089FF196FE3C90C3EC44B1B6C30A4BBCB49_AdjustorThunk (void);
extern void SerializableGuid__ctor_mCB52F194155784E55FC04EEB9A5F086FE6F3EFF2_AdjustorThunk (void);
extern void SerializableGuid_GetHashCode_mF9A1263046263FEC8529C736D400C3ADC2280ACA_AdjustorThunk (void);
extern void SerializableGuid_Equals_mCE9639B13AA49783B83F2803220A7C839735515D_AdjustorThunk (void);
extern void SerializableGuid_ToString_m0575B5BD028C35F5919D6696BD12AB2EDADF1E70_AdjustorThunk (void);
extern void SerializableGuid_ToString_m2C4DBE079278618D23A8CD447C60763AC240361E_AdjustorThunk (void);
extern void SerializableGuid_ToString_mD57FADE1F89584D3F52212B039B903A5AAC8EAEA_AdjustorThunk (void);
extern void SerializableGuid_Equals_m336B71967347FB7BD21D01C6EC949404D0BCAEB9_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[14] = 
{
	{ 0x06000001, ARTrackablesParentTransformChangedEventArgs_get_Origin_m91D7C3638FBF94D468AD4467ABB2EC9500753F25_AdjustorThunk },
	{ 0x06000002, ARTrackablesParentTransformChangedEventArgs_get_TrackablesParent_m89F1B7B428A07F5142AEC2BF32A83B35B52C0425_AdjustorThunk },
	{ 0x06000003, ARTrackablesParentTransformChangedEventArgs__ctor_m46B5D18DF81A7296E36E37917E69AB9E748B6278_AdjustorThunk },
	{ 0x06000004, ARTrackablesParentTransformChangedEventArgs_Equals_m8CAA7BD42F09BF7349818EF3166792652FB9F4AE_AdjustorThunk },
	{ 0x06000005, ARTrackablesParentTransformChangedEventArgs_Equals_mE6F5F659DD06166ACDDCE62B0652F014568D003B_AdjustorThunk },
	{ 0x06000006, ARTrackablesParentTransformChangedEventArgs_GetHashCode_mA5FDE9D7D0F5F079886AA4C5DF806E082C725161_AdjustorThunk },
	{ 0x060000D2, SerializableGuid_get_Guid_m4122C089FF196FE3C90C3EC44B1B6C30A4BBCB49_AdjustorThunk },
	{ 0x060000D3, SerializableGuid__ctor_mCB52F194155784E55FC04EEB9A5F086FE6F3EFF2_AdjustorThunk },
	{ 0x060000D4, SerializableGuid_GetHashCode_mF9A1263046263FEC8529C736D400C3ADC2280ACA_AdjustorThunk },
	{ 0x060000D5, SerializableGuid_Equals_mCE9639B13AA49783B83F2803220A7C839735515D_AdjustorThunk },
	{ 0x060000D6, SerializableGuid_ToString_m0575B5BD028C35F5919D6696BD12AB2EDADF1E70_AdjustorThunk },
	{ 0x060000D7, SerializableGuid_ToString_m2C4DBE079278618D23A8CD447C60763AC240361E_AdjustorThunk },
	{ 0x060000D8, SerializableGuid_ToString_mD57FADE1F89584D3F52212B039B903A5AAC8EAEA_AdjustorThunk },
	{ 0x060000D9, SerializableGuid_Equals_m336B71967347FB7BD21D01C6EC949404D0BCAEB9_AdjustorThunk },
};
static const int32_t s_InvokerIndices[289] = 
{
	6569,
	6569,
	2870,
	4304,
	4427,
	6536,
	9348,
	9348,
	6698,
	6569,
	5261,
	10572,
	10572,
	10572,
	10572,
	0,
	10572,
	11833,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	9358,
	9512,
	10939,
	9512,
	0,
	11833,
	0,
	9769,
	9769,
	9769,
	8824,
	8824,
	9780,
	8772,
	0,
	0,
	10656,
	9409,
	0,
	0,
	9285,
	9566,
	9566,
	10860,
	10860,
	10860,
	10821,
	10821,
	11833,
	10847,
	10847,
	9776,
	9776,
	9284,
	9284,
	9291,
	8837,
	9775,
	9775,
	8837,
	8466,
	8466,
	8835,
	8835,
	8118,
	0,
	0,
	9255,
	10821,
	10821,
	10821,
	10821,
	9423,
	8466,
	11833,
	6698,
	5261,
	10983,
	10943,
	10943,
	10983,
	10991,
	10944,
	10944,
	10991,
	11016,
	11016,
	11786,
	10821,
	8469,
	8477,
	7932,
	9255,
	9775,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	9775,
	9255,
	11833,
	6698,
	4427,
	8001,
	9565,
	8826,
	7051,
	7051,
	7051,
	8611,
	7624,
	9480,
	9480,
	8611,
	9423,
	10988,
	9550,
	6894,
	10859,
	10939,
	9423,
	8548,
	8548,
	8560,
	8009,
	10860,
	10848,
	8607,
	11833,
	9091,
	9137,
	10657,
	8348,
	7738,
	7233,
	7091,
	7018,
	6967,
	10821,
	10821,
	10821,
	10576,
	9048,
	9775,
	9452,
	10900,
	8304,
	7697,
	8015,
	10900,
	10904,
	10892,
	10652,
	11833,
	0,
	0,
	0,
	0,
	0,
	6569,
	5261,
	6698,
	6698,
	11786,
	11786,
	11786,
	11833,
	11016,
	11016,
	10821,
	10821,
	9775,
	9775,
	9255,
	10821,
	0,
	0,
	0,
	10821,
	6698,
	6698,
	6698,
	9415,
	6698,
	11833,
	0,
	0,
	0,
	0,
	11815,
	6516,
	2831,
	6536,
	4427,
	6569,
	3939,
	1946,
	4475,
	9449,
	9449,
	11833,
	10929,
	9775,
	2878,
	5261,
	5261,
	2870,
	0,
	5305,
	6698,
	9780,
	0,
	0,
	0,
	11833,
	9775,
	9775,
	9775,
	9775,
	6569,
	5261,
	6569,
	5261,
	5261,
	5261,
	6569,
	5261,
	6569,
	5261,
	6536,
	5230,
	6628,
	5316,
	6536,
	5230,
	6687,
	6687,
	6628,
	6698,
	5316,
	6698,
	6618,
	4427,
	6569,
	5261,
	4482,
	2156,
	4542,
	2157,
	2157,
	4542,
	6698,
	6580,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	11833,
	6618,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	5261,
	6698,
};
static const Il2CppTokenRangePair s_rgctxIndices[31] = 
{
	{ 0x02000008, { 9, 36 } },
	{ 0x02000009, { 50, 10 } },
	{ 0x0200000A, { 60, 7 } },
	{ 0x0200000C, { 70, 3 } },
	{ 0x02000027, { 124, 8 } },
	{ 0x0200002A, { 132, 8 } },
	{ 0x0200002C, { 140, 3 } },
	{ 0x06000010, { 0, 9 } },
	{ 0x06000016, { 45, 3 } },
	{ 0x06000017, { 48, 2 } },
	{ 0x06000023, { 67, 3 } },
	{ 0x06000029, { 73, 7 } },
	{ 0x0600002B, { 80, 5 } },
	{ 0x06000033, { 85, 7 } },
	{ 0x06000034, { 92, 5 } },
	{ 0x06000037, { 97, 3 } },
	{ 0x06000038, { 100, 3 } },
	{ 0x06000052, { 103, 2 } },
	{ 0x06000053, { 105, 1 } },
	{ 0x0600006F, { 106, 3 } },
	{ 0x06000070, { 109, 4 } },
	{ 0x06000071, { 113, 2 } },
	{ 0x06000072, { 115, 3 } },
	{ 0x06000073, { 118, 1 } },
	{ 0x06000074, { 119, 1 } },
	{ 0x06000075, { 120, 1 } },
	{ 0x060000AE, { 121, 3 } },
	{ 0x060000E3, { 143, 1 } },
	{ 0x060000E7, { 144, 3 } },
	{ 0x060000E8, { 147, 12 } },
	{ 0x060000E9, { 159, 19 } },
};
extern const uint32_t g_rgctx_List_1_t136A6C6B5EC53EA8D66AAEB1DEFD962D0DA896C2;
extern const uint32_t g_rgctx_List_1_get_Count_m0B52C9762B5E096B5DBF28DE5BAC894576A5359F;
extern const uint32_t g_rgctx_List_1_get_Item_m83431F2443B49D03ABBDFD0B9436108945430BD3;
extern const uint32_t g_rgctx_T_t7C578F20D13F35AAFBCF247B40B400009C322147;
extern const uint32_t g_rgctx_List_1_GetEnumerator_m194C680CA7435F2ECC13EEA76156433FAA62FE38;
extern const uint32_t g_rgctx_Enumerator_get_Current_m73AF270F0B90063B7D22D1858060F1430482A33F;
extern const uint32_t g_rgctx_Enumerator_MoveNext_m46D18068D2784C1B337734514724158FE57F72C3;
extern const uint32_t g_rgctx_Enumerator_t1C16C75B6731EB9351E069C30FB34CB6D7F540DE;
extern const Il2CppRGCTXConstrainedData g_rgctx_Enumerator_t1C16C75B6731EB9351E069C30FB34CB6D7F540DE_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7;
extern const uint32_t g_rgctx_CollectionPool_2_GetCollection_m62AA8CC882F20DB7A4AC7E7BBC50AFD02833BEEB;
extern const uint32_t g_rgctx_CollectionPool_2_t2C0DCF5057B08AC0F5DB722C839462FEF51BFEAD;
extern const uint32_t g_rgctx_CachedComponentFilter_2_t9F8A204056C7ADFA3FEE14185E9809F71EF8A08D;
extern const uint32_t g_rgctx_List_1_t9AF37C3E2C8C126C11D7049DDC09B8E0BBAE9759;
extern const uint32_t g_rgctx_List_1_Clear_mACFA586E5760FDE83B64D12AAEF38CD91A728D3C;
extern const uint32_t g_rgctx_List_1_t61181A9947613C3F281DF80BA625509AA7E74F55;
extern const uint32_t g_rgctx_List_1_Clear_mAB8BDB60AB3CC53A60FD25D85F531BB8CB6D43C6;
extern const uint32_t g_rgctx_TRootType_t910BC4159BB09B9D00748EC9ADB2989D8716C49B;
extern const uint32_t g_rgctx_Component_GetComponents_TisTFilterType_t97AEC65DAC31E6678DDCC177826654855EACF00D_m6E9A3A3028BF0B0CDC8CD78D02ED6C82E826F1EE;
extern const uint32_t g_rgctx_Component_GetComponents_TisIComponentHost_1_tA12DEBF9CE24B4B00569BE0B05ACE7313BE48BE5_m81542E7C98D5FBEF31F86153A195BB0B354B8C8F;
extern const uint32_t g_rgctx_CachedComponentFilter_2_FilteredCopyToMaster_m2386A9F34B100F38467DE115873885ADD89EAD79;
extern const uint32_t g_rgctx_Component_GetComponent_TisTRootType_t910BC4159BB09B9D00748EC9ADB2989D8716C49B_m83293055964329E704ED89A867E25E2106DE8E0A;
extern const uint32_t g_rgctx_Component_GetComponentsInChildren_TisTFilterType_t97AEC65DAC31E6678DDCC177826654855EACF00D_m3109DEB726B3576676D4EC51E97DC8FF8ABCC0F0;
extern const uint32_t g_rgctx_Component_GetComponentsInChildren_TisIComponentHost_1_tA12DEBF9CE24B4B00569BE0B05ACE7313BE48BE5_m29164B92B6E9D1EB5723ABA8B96875CF49C2C3BE;
extern const uint32_t g_rgctx_CachedComponentFilter_2_FilteredCopyToMaster_m7B5B4F055B9931A2C0C2AE0AEC982DFFBD34C3D8;
extern const uint32_t g_rgctx_List_1_AddRange_mC80E41BA137AB9F0EC203DF0F940EC3C82987936;
extern const uint32_t g_rgctx_List_1_GetEnumerator_m679654554DB147BDFCF1E91E617B328F657A893D;
extern const uint32_t g_rgctx_Enumerator_get_Current_m471D625245C210ED91FFF6AEDC3784E3EBD4ABB8;
extern const uint32_t g_rgctx_TFilterType_t97AEC65DAC31E6678DDCC177826654855EACF00D;
extern const uint32_t g_rgctx_Enumerator_MoveNext_m3ABFE069A9E1558B09EEC9C0E2DA8308A51E1947;
extern const uint32_t g_rgctx_Enumerator_t7B0C9571E0436FAA1EA471B6C3A06646C63A5D7C;
extern const Il2CppRGCTXConstrainedData g_rgctx_Enumerator_t7B0C9571E0436FAA1EA471B6C3A06646C63A5D7C_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7;
extern const uint32_t g_rgctx_List_1_GetEnumerator_m7B360F10AE8B6D5ED85E1F16DB3F7ADDE66E8E9C;
extern const uint32_t g_rgctx_Enumerator_get_Current_mE6349DD576C5B011ED61C6823E508CFD29A408C9;
extern const uint32_t g_rgctx_IComponentHost_1_tA12DEBF9CE24B4B00569BE0B05ACE7313BE48BE5;
extern const uint32_t g_rgctx_IComponentHost_1_get_HostedComponents_m15DDAE0C1C748DC60E690170F3DB1E7D19AC31D4;
extern const uint32_t g_rgctx_Enumerator_MoveNext_m7344872DED954C2545F737B598CB080BC42915C1;
extern const uint32_t g_rgctx_Enumerator_tB79AB7811E4322036E517CFDE47CECF915D264CB;
extern const Il2CppRGCTXConstrainedData g_rgctx_Enumerator_tB79AB7811E4322036E517CFDE47CECF915D264CB_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7;
extern const uint32_t g_rgctx_List_1_Add_mCC8A03F7974CF02D55A967B083314EA97C96B0F0;
extern const uint32_t g_rgctx_Component_GetComponentInParent_TisTRootType_t910BC4159BB09B9D00748EC9ADB2989D8716C49B_m2057D84D1F3A9E019502E52A97CFB6EB63453183;
extern const uint32_t g_rgctx_CollectionPool_2_RecycleCollection_m7287087B0F19C50B784B74DDE8EC4E770D77C893;
extern const uint32_t g_rgctx_CachedComponentFilter_2_t9F8A204056C7ADFA3FEE14185E9809F71EF8A08D;
extern const uint32_t g_rgctx_CachedComponentFilter_2_Dispose_m6985F60F6DA08FCAA1A8BDCA4175A7BA3BD5AB26;
extern const uint32_t g_rgctx_List_1__ctor_mFC93005A5929DF1A79B7E82E5FD2139B3C31F8CF;
extern const uint32_t g_rgctx_List_1__ctor_m984AD4D9554EDBD0107844807DCE4CD02A034CAE;
extern const uint32_t g_rgctx_TChildType_tFF64304C428176EEF3D952C5BF5B304E6C037C15;
extern const uint32_t g_rgctx_List_1_tA09CE31C69889D2D9E3A38B5F93D6F009435D74C;
extern const uint32_t g_rgctx_List_1_Add_m69CC62EBF39467FE829750C35A541CADE5621ED7;
extern const uint32_t g_rgctx_TChildType_tDB5A61C14076E62C581848EE0EF222299125AB48;
extern const uint32_t g_rgctx_TChildTypeU5BU5D_t6E57A1410F370E60D591E10B591CCD7D8C9CE568;
extern const uint32_t g_rgctx_CollectionPool_2_t68DF8F721A9F6123977FB5B6431DA91C34DFD0BB;
extern const uint32_t g_rgctx_Queue_1_t3D3BF26F8B19065723D95A73E53AD2CAE0AC4B63;
extern const uint32_t g_rgctx_Queue_1_get_Count_m66B2C1C20E7AB4AA180ED67D71C0A287F3FA68FD;
extern const uint32_t g_rgctx_Activator_CreateInstance_TisTCollection_t3FA83A93ECEA0B573846FDDE8363A05B096ED4C9_mBD0B06C81F7C749B1E550AE733901A56C628367F;
extern const uint32_t g_rgctx_Queue_1_Dequeue_m23E76365C777909D787ABB1250CD1FC4A8D38CD0;
extern const uint32_t g_rgctx_TCollection_t3FA83A93ECEA0B573846FDDE8363A05B096ED4C9;
extern const uint32_t g_rgctx_ICollection_1_tE2A5FFDF9E3C3532B4ED69AA4762C8CEF888EFDA;
extern const Il2CppRGCTXConstrainedData g_rgctx_TCollection_t3FA83A93ECEA0B573846FDDE8363A05B096ED4C9_ICollection_1_Clear_m6229909D33A9019717CFE81A4C3C14BA9C88FB94;
extern const uint32_t g_rgctx_Queue_1_Enqueue_m85E59BEC1FAAF18CD2210EDAE91CE7B4B9B18A4C;
extern const uint32_t g_rgctx_Queue_1__ctor_mCB5166A5B4CE3A8BEFDD90E87D4EB107C2F2F241;
extern const uint32_t g_rgctx_ComponentUtils_1_tAA8BF3405715E21D43CFF82D83EB7807F33E3FCC;
extern const uint32_t g_rgctx_GameObject_GetComponents_TisT_tFE377E9CC4A5268EDB3EE76BBD1B6D96EDA722CA_m74D025D8361FDA40C95A23BFE328BAA8DEB002AF;
extern const uint32_t g_rgctx_List_1_t208EB6C1A24250C383C9964B4FEEE5929A530429;
extern const uint32_t g_rgctx_List_1_get_Count_m013C936A0C8FA975ACFA6D40274B9AFAC3324D90;
extern const uint32_t g_rgctx_List_1_get_Item_m43C2FE32C769744AC1B03610DAE93B4AE74B2E53;
extern const uint32_t g_rgctx_GameObject_GetComponentsInChildren_TisT_tFE377E9CC4A5268EDB3EE76BBD1B6D96EDA722CA_m484E91C37A39BBF417EEEB6092F6CD6B6280C22F;
extern const uint32_t g_rgctx_List_1__ctor_m587DBDF688F570E926A3A31F59C250E33B14466F;
extern const uint32_t g_rgctx_GameObject_GetComponent_TisT_t0D67C692906C80053FBABC5F0C493280D362D061_m10527F4B25F6E9F8C3BB4C07411CC8779D10ACB0;
extern const uint32_t g_rgctx_T_t0D67C692906C80053FBABC5F0C493280D362D061;
extern const uint32_t g_rgctx_GameObject_AddComponent_TisT_t0D67C692906C80053FBABC5F0C493280D362D061_m5AAA4E17290A1D49C1D23F8BDCAC291C4FEDDFB0;
extern const uint32_t g_rgctx_T_tDF94EB564F474BFE34322C8863A95353618C4056;
extern const uint32_t g_rgctx_TU5BU5D_t51738BF475F285E3A65084DBF8471615191ED234;
extern const uint32_t g_rgctx_EnumValues_1_tB582F27FFA983E40792E29F0E6C6286A981F941F;
extern const uint32_t g_rgctx_ICollection_1_tBBA3E6FE5D37CA89114DC9313970140B7C248083;
extern const uint32_t g_rgctx_ICollection_1_get_Count_mC66937F2E53682842CFFE58013256230CEFA06FB;
extern const uint32_t g_rgctx_IEnumerable_1_tBE98F4C7157A17E8A1FC0F9E691ED6B63E825F57;
extern const uint32_t g_rgctx_IEnumerable_1_GetEnumerator_mCA5446209B3FF8E68E38B7EFCAB95317A40EF7F2;
extern const uint32_t g_rgctx_IEnumerator_1_t2A2BB3906B3CADDCDAAEDC8F5CD863952CE8C3A2;
extern const uint32_t g_rgctx_IEnumerator_1_get_Current_m66B635511D04F1AEBE32574A3312F4C778DBBDB7;
extern const uint32_t g_rgctx_T_t1719D024780C8522A8B3C67CF519B8E01936BCA2;
extern const uint32_t g_rgctx_Dictionary_2_t09BA95F6BF612375C01A9087D7510CB4B6B6FB02;
extern const uint32_t g_rgctx_Dictionary_2_GetEnumerator_mF58172FF9D69A4718E429B3DA9A2D079F476B1DF;
extern const uint32_t g_rgctx_Enumerator_MoveNext_mA5508A7CC8E8B985BAAE0E2ECF7398084C2FEDC0;
extern const uint32_t g_rgctx_Enumerator_get_Current_m4EBCB084C8C4BA1F0D020D2446E1C8ECAE583E1C;
extern const uint32_t g_rgctx_Enumerator_Dispose_m934B55E93BD0E1B9C2079C1F8805B4E421D1853D;
extern const uint32_t g_rgctx_HashSet_1_tD57AD09827AB3FBAFADD0099DC1B0746347888AF;
extern const uint32_t g_rgctx_HashSet_1_GetEnumerator_m7D86136DC16D1E1D2568ED156B59412B15E3DA39;
extern const uint32_t g_rgctx_Enumerator_get_Current_m679631ED9B8C9083F1DAC438F97184663D5627FE;
extern const uint32_t g_rgctx_HashSet_1_Remove_m99BAB4BBB5FCC070F1E63539A63980C61501AB09;
extern const uint32_t g_rgctx_Enumerator_MoveNext_m038EA8A735A59DC7E75EADE4A973835C909FBA2A;
extern const uint32_t g_rgctx_Enumerator_t47D9633859A7B729BC42A6432A66CFCD40B22B1C;
extern const Il2CppRGCTXConstrainedData g_rgctx_Enumerator_t47D9633859A7B729BC42A6432A66CFCD40B22B1C_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7;
extern const uint32_t g_rgctx_HashSet_1_tADFA9E366635766FA8B5C64BA8DF952A2AA6BAA7;
extern const uint32_t g_rgctx_HashSet_1_GetEnumerator_m138EEDBA1759E6E360346CDC4F1F9F4814DC06B9;
extern const uint32_t g_rgctx_Enumerator_MoveNext_m42061844369D209B4EC2FBA65EBD58E058941DA5;
extern const uint32_t g_rgctx_Enumerator_get_Current_m974198F4D3850445F607CC3FFE0A96BF60B7F406;
extern const uint32_t g_rgctx_Enumerator_Dispose_m3F1FEEDDDB15DB468F4AFED3067937D09A73F50A;
extern const uint32_t g_rgctx_Activator_CreateInstance_TisT_t03A7DF331A62704F4C709524AB955247F406B635_m898D9E8D0EC77E6D787032E7666FC714609C3FA7;
extern const uint32_t g_rgctx_List_1_tF95BA7784DB57B6DD8B9D21CDF9D95B4DA676904;
extern const uint32_t g_rgctx_List_1_Add_m53ABD8D82A15312EBBC54427B10E97B44A329DD9;
extern const uint32_t g_rgctx_List_1_tB80F3889249B846990D14F2DFF47D6109A506E25;
extern const uint32_t g_rgctx_List_1_get_Capacity_mA2E41432246A864C5B0BD0C65521F3856BE3A9C8;
extern const uint32_t g_rgctx_List_1_set_Capacity_m859939D8754C427E5F144CF3C8B45B272679AB87;
extern const uint32_t g_rgctx_TAttribute_t57548C8B54ADE9F6B62DE18403CDFEF1632D8D70;
extern const uint32_t g_rgctx_TAttribute_t57548C8B54ADE9F6B62DE18403CDFEF1632D8D70;
extern const uint32_t g_rgctx_TAttribute_t6A351DD6FED9BEE8D7B2C56467FE2B19D8D8585D;
extern const uint32_t g_rgctx_GameObject_GetComponentInChildren_TisT_tE011F873178A408ECF4F6A876D636DF6347F3B47_m7BDCF7C67B54168EBB9DD9045E6919D3934DC100;
extern const uint32_t g_rgctx_T_tE011F873178A408ECF4F6A876D636DF6347F3B47;
extern const uint32_t g_rgctx_Object_FindObjectOfType_TisT_tE011F873178A408ECF4F6A876D636DF6347F3B47_mDC5677E088645F9435672A7FF28B74C629CC59A6;
extern const uint32_t g_rgctx_GameObject_GetComponentsInChildren_TisT_t3A784F37D03862EF8F54D38F8F303DACEDD81070_mC40A724286B91487E0184049AD6183A54394FE24;
extern const uint32_t g_rgctx_T_t3A784F37D03862EF8F54D38F8F303DACEDD81070;
extern const uint32_t g_rgctx_GameObject_GetComponent_TisT_t3A784F37D03862EF8F54D38F8F303DACEDD81070_m003693C123FFFC885A1BFBDFD3F5F905AB47147B;
extern const uint32_t g_rgctx_Object_FindObjectOfType_TisT_t3A784F37D03862EF8F54D38F8F303DACEDD81070_m5A875963D8B6411AEF55EF1ECAC591E60982B1C6;
extern const uint32_t g_rgctx_GameObject_GetComponentInChildren_TisT_t498586F0EF6784CE9521E80D659A1EC4F9DAF69B_m399FDEBB438A052001FBA6DDA35CFE4316F83F93;
extern const uint32_t g_rgctx_T_t498586F0EF6784CE9521E80D659A1EC4F9DAF69B;
extern const uint32_t g_rgctx_GameObject_GetComponentsInChildren_TisT_tD4571279E318B28AB8F4A8AB2F0A8DAD3B806E4E_m7FB48716F68ED16709A62FE04EEBA85ECDDDA357;
extern const uint32_t g_rgctx_List_1_t13FD9EF583DAC56510A13085C3D0DEFF4ABE0163;
extern const uint32_t g_rgctx_List_1_AddRange_m14F164EC754CCFC897233742F24032CC586EA242;
extern const uint32_t g_rgctx_GameObjectUtils_GetComponentInScene_TisT_t9695B0A9D8A733A130AFB118E36F90A5999D6447_m3752F715901D20522D1274B873DDD36E0ACBE04A;
extern const uint32_t g_rgctx_GameObjectUtils_GetComponentsInScene_TisT_t6B6807F079C7104A85D2C0DBC6B55F8BBB2266F4_mDF618C95A3E865F73DD07B13B836BAE12B6D3B62;
extern const uint32_t g_rgctx_GameObjectUtils_GetComponentsInScene_TisT_tD699C7D9D7C8D23D17C3473CAB9BC416241FAF79_m6DA50793EF56D19F8FBB05669DBE32C82DCA9F28;
extern const uint32_t g_rgctx_NativeArray_1_Dispose_mFA9E49EBE29D76C5CC4F6AF89A1C99BCC5E8F807;
extern const uint32_t g_rgctx_NativeArray_1_t18ED7CCED341EC3D7FCB63E800366327B0580C1F;
extern const uint32_t g_rgctx_NativeArray_1__ctor_mFA8064634E6EBB7621DE6C9CC0B37CB95A174B57;
extern const uint32_t g_rgctx_Queue_1_t13A6260A2FD5C8157AB33D16FA42FCEB72240B06;
extern const uint32_t g_rgctx_Queue_1_get_Count_m098FC3C80525E22BF08BBC7A5DFFAE46B2167907;
extern const uint32_t g_rgctx_Queue_1_Dequeue_m51B578D46AECA36CF999B147DFDEED63CC77016C;
extern const uint32_t g_rgctx_Activator_CreateInstance_TisT_t6817021F4A7EAA4D352F23CF91779E4891FAC71D_m7C6DD59DCCF8FAD87DCD2DA3105CD65424B75C18;
extern const uint32_t g_rgctx_ObjectPool_1_tD19C2A9E2ED973F7475DA6B78193D5917B0DCE88;
extern const uint32_t g_rgctx_ObjectPool_1_ClearInstance_m2FB8C52A61FCC751DC7F22FA968D7DCBA45DF29F;
extern const uint32_t g_rgctx_Queue_1_Enqueue_mD46AE6D92A1DCC609D60D353D71C80E297BDB8FE;
extern const uint32_t g_rgctx_Queue_1__ctor_m77EF736B080DD9B6616CCD6E44B468CD1DD2D593;
extern const uint32_t g_rgctx_ScriptableSettingsBase_1_tCC1B8E644A002165B9D289E629ACBCC8B5204C02;
extern const uint32_t g_rgctx_T_tD75C904482F31E0C214186BAFACA01AAB4FBF363;
extern const uint32_t g_rgctx_ScriptableSettings_1_CreateAndLoad_m2EDBA665001FF4299EE657B3C1894F8058C623CB;
extern const uint32_t g_rgctx_ScriptableSettings_1_tEBDCEA06A56D935B7439A14F8513ACB8C0A9324C;
extern const uint32_t g_rgctx_ScriptableSettingsBase_1_GetFilePath_m244E3E208D7A2BC4C596185AC9D6FE21D70C23C7;
extern const uint32_t g_rgctx_ScriptableObject_CreateInstance_TisT_tD75C904482F31E0C214186BAFACA01AAB4FBF363_m85F0865C5F95DB0E84C77BC6844EE97C6B6A353B;
extern const uint32_t g_rgctx_ScriptableSettingsBase_1_Save_m11628EF4A57C395C7E5A131FB57C63F99B0400BF;
extern const uint32_t g_rgctx_ScriptableSettingsBase_1__ctor_m656DFE56F50E42B3AFC0966AF2DB4C079F87C944;
extern const uint32_t g_rgctx_ScriptableSettingsBase_1_t38EEBDA86A8D7AAF469BF841A8F15D5C1B343D6C;
extern const uint32_t g_rgctx_T_t2D4A2C3F601E1DE59938CB9FE4D7055ACC03CB49;
extern const uint32_t g_rgctx_T_t2D4A2C3F601E1DE59938CB9FE4D7055ACC03CB49;
extern const uint32_t g_rgctx_GameObject_AddComponent_TisT_t0573350EC878887841167DA02B13BF9E339E364F_m3CC0FBC349CDAE4079FB63629746D012DABBC633;
extern const uint32_t g_rgctx_T_tC0030B04C7A2D4622AC81EC96505385B58AFFF63;
extern const uint32_t g_rgctx_GameObject_GetComponent_TisT_tC0030B04C7A2D4622AC81EC96505385B58AFFF63_mDEA99B19A4938AB4E238F0CB176737DD22ECC702;
extern const uint32_t g_rgctx_Component_GetComponent_TisT_tC0030B04C7A2D4622AC81EC96505385B58AFFF63_mAEBC74D0B6F23051457E11646EA36F9D6F7C08F3;
extern const uint32_t g_rgctx_CollectionPool_2_GetCollection_mFACB1227D81EE7893CDE25CA64566ACCB5FEBEE8;
extern const uint32_t g_rgctx_CollectionPool_2_tC3E61FA69806DF5FA3DDD025644BCFDAA2C23353;
extern const uint32_t g_rgctx_List_1_t8383F8BEECB75BF70BB411C136C8179E34286D8E;
extern const uint32_t g_rgctx_List_1_GetEnumerator_mF31DB752CD484D63E0F5D1D30E587D318BAF551E;
extern const uint32_t g_rgctx_Enumerator_get_Current_m82BADC24ED5B3611F7513614C0910FD560A73091;
extern const uint32_t g_rgctx_T_tBBBE52C3C2742E9C03E67DB0095BB29C00214457;
extern const uint32_t g_rgctx_List_1_Add_mCBB2B5B27E550FDA0A4EC5539A75CC1FA9A1D8B9;
extern const uint32_t g_rgctx_Enumerator_MoveNext_mD7B6B8F9F8B56A9FEB9C7968B36A1B947370980F;
extern const uint32_t g_rgctx_Enumerator_t4ED09183E855AB2F38AAF033FC6172CB3A0A66A4;
extern const Il2CppRGCTXConstrainedData g_rgctx_Enumerator_t4ED09183E855AB2F38AAF033FC6172CB3A0A66A4_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7;
extern const uint32_t g_rgctx_List_1_Remove_mE7EE147EBFF27EACBC4BB0BA2B9F4E752918DC9D;
extern const uint32_t g_rgctx_CollectionPool_2_RecycleCollection_mAD3A410923DBA05CF42D7D22DB5012844E3AD8E7;
extern const uint32_t g_rgctx_CollectionPool_2_GetCollection_m57965D3DB65C01805188EF09B1F86BE445477971;
extern const uint32_t g_rgctx_CollectionPool_2_tE6222BC73D1BD57B6036CBC60A08B48F50E49862;
extern const uint32_t g_rgctx_Dictionary_2_tA045B77988CDC5629C320AEF7943AA07D8819550;
extern const uint32_t g_rgctx_Dictionary_2_GetEnumerator_m48628F67876A8C4B723F1D8C0A7397CDED99AF05;
extern const uint32_t g_rgctx_Enumerator_get_Current_mB012F336D51E3CBF8A0F029882F5B32AB1449864;
extern const uint32_t g_rgctx_KeyValuePair_2_get_Key_m0C153F0308143DA08A8BBC22E15803C0D601A009;
extern const uint32_t g_rgctx_TKey_t61648F1BA22185879A9692328C8D74405AEC2480;
extern const uint32_t g_rgctx_List_1_t8D05945719C5D40B30D99882FF49833281BC8860;
extern const uint32_t g_rgctx_List_1_Add_mBFDC233069FDDDDADCD7A04D1800B3FAFF5DE8F0;
extern const uint32_t g_rgctx_Enumerator_MoveNext_mF872DDB078667D5BE0E4677DC666CDF107EEB41B;
extern const uint32_t g_rgctx_Enumerator_tE81BED011F0DBDB4F2EFFA0D19A6B53F116A78B8;
extern const Il2CppRGCTXConstrainedData g_rgctx_Enumerator_tE81BED011F0DBDB4F2EFFA0D19A6B53F116A78B8_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7;
extern const uint32_t g_rgctx_List_1_GetEnumerator_mA553AFFE584C4C1C4E8F6BB7B2957B2109C41DED;
extern const uint32_t g_rgctx_Enumerator_get_Current_m646A8134FEE0338FBC09BC2F42725BA99E7B6F6C;
extern const uint32_t g_rgctx_Dictionary_2_Remove_m5570991B107C82B3E61F637B202C7DE703B5E568;
extern const uint32_t g_rgctx_Enumerator_MoveNext_m89874E375B7CF0D5F33D6CA462864BF1EEC3B566;
extern const uint32_t g_rgctx_Enumerator_t051FB00CE2D0096E938C74EDF2CF40ABD53D7E66;
extern const Il2CppRGCTXConstrainedData g_rgctx_Enumerator_t051FB00CE2D0096E938C74EDF2CF40ABD53D7E66_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7;
extern const uint32_t g_rgctx_CollectionPool_2_RecycleCollection_m91035B80A8EF837111C2D8CF0FDAC140BBD16711;
static const Il2CppRGCTXDefinition s_rgctxValues[178] = 
{
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_t136A6C6B5EC53EA8D66AAEB1DEFD962D0DA896C2 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Count_m0B52C9762B5E096B5DBF28DE5BAC894576A5359F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Item_m83431F2443B49D03ABBDFD0B9436108945430BD3 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t7C578F20D13F35AAFBCF247B40B400009C322147 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_GetEnumerator_m194C680CA7435F2ECC13EEA76156433FAA62FE38 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_get_Current_m73AF270F0B90063B7D22D1858060F1430482A33F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_MoveNext_m46D18068D2784C1B337734514724158FE57F72C3 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Enumerator_t1C16C75B6731EB9351E069C30FB34CB6D7F540DE },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_Enumerator_t1C16C75B6731EB9351E069C30FB34CB6D7F540DE_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_CollectionPool_2_GetCollection_m62AA8CC882F20DB7A4AC7E7BBC50AFD02833BEEB },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_CollectionPool_2_t2C0DCF5057B08AC0F5DB722C839462FEF51BFEAD },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_CachedComponentFilter_2_t9F8A204056C7ADFA3FEE14185E9809F71EF8A08D },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_t9AF37C3E2C8C126C11D7049DDC09B8E0BBAE9759 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Clear_mACFA586E5760FDE83B64D12AAEF38CD91A728D3C },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_t61181A9947613C3F281DF80BA625509AA7E74F55 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Clear_mAB8BDB60AB3CC53A60FD25D85F531BB8CB6D43C6 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TRootType_t910BC4159BB09B9D00748EC9ADB2989D8716C49B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Component_GetComponents_TisTFilterType_t97AEC65DAC31E6678DDCC177826654855EACF00D_m6E9A3A3028BF0B0CDC8CD78D02ED6C82E826F1EE },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Component_GetComponents_TisIComponentHost_1_tA12DEBF9CE24B4B00569BE0B05ACE7313BE48BE5_m81542E7C98D5FBEF31F86153A195BB0B354B8C8F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_CachedComponentFilter_2_FilteredCopyToMaster_m2386A9F34B100F38467DE115873885ADD89EAD79 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Component_GetComponent_TisTRootType_t910BC4159BB09B9D00748EC9ADB2989D8716C49B_m83293055964329E704ED89A867E25E2106DE8E0A },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Component_GetComponentsInChildren_TisTFilterType_t97AEC65DAC31E6678DDCC177826654855EACF00D_m3109DEB726B3576676D4EC51E97DC8FF8ABCC0F0 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Component_GetComponentsInChildren_TisIComponentHost_1_tA12DEBF9CE24B4B00569BE0B05ACE7313BE48BE5_m29164B92B6E9D1EB5723ABA8B96875CF49C2C3BE },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_CachedComponentFilter_2_FilteredCopyToMaster_m7B5B4F055B9931A2C0C2AE0AEC982DFFBD34C3D8 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_AddRange_mC80E41BA137AB9F0EC203DF0F940EC3C82987936 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_GetEnumerator_m679654554DB147BDFCF1E91E617B328F657A893D },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_get_Current_m471D625245C210ED91FFF6AEDC3784E3EBD4ABB8 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TFilterType_t97AEC65DAC31E6678DDCC177826654855EACF00D },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_MoveNext_m3ABFE069A9E1558B09EEC9C0E2DA8308A51E1947 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Enumerator_t7B0C9571E0436FAA1EA471B6C3A06646C63A5D7C },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_Enumerator_t7B0C9571E0436FAA1EA471B6C3A06646C63A5D7C_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_GetEnumerator_m7B360F10AE8B6D5ED85E1F16DB3F7ADDE66E8E9C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_get_Current_mE6349DD576C5B011ED61C6823E508CFD29A408C9 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IComponentHost_1_tA12DEBF9CE24B4B00569BE0B05ACE7313BE48BE5 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IComponentHost_1_get_HostedComponents_m15DDAE0C1C748DC60E690170F3DB1E7D19AC31D4 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_MoveNext_m7344872DED954C2545F737B598CB080BC42915C1 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Enumerator_tB79AB7811E4322036E517CFDE47CECF915D264CB },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_Enumerator_tB79AB7811E4322036E517CFDE47CECF915D264CB_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Add_mCC8A03F7974CF02D55A967B083314EA97C96B0F0 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Component_GetComponentInParent_TisTRootType_t910BC4159BB09B9D00748EC9ADB2989D8716C49B_m2057D84D1F3A9E019502E52A97CFB6EB63453183 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_CollectionPool_2_RecycleCollection_m7287087B0F19C50B784B74DDE8EC4E770D77C893 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_CachedComponentFilter_2_t9F8A204056C7ADFA3FEE14185E9809F71EF8A08D },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_CachedComponentFilter_2_Dispose_m6985F60F6DA08FCAA1A8BDCA4175A7BA3BD5AB26 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1__ctor_mFC93005A5929DF1A79B7E82E5FD2139B3C31F8CF },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1__ctor_m984AD4D9554EDBD0107844807DCE4CD02A034CAE },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TChildType_tFF64304C428176EEF3D952C5BF5B304E6C037C15 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_tA09CE31C69889D2D9E3A38B5F93D6F009435D74C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Add_m69CC62EBF39467FE829750C35A541CADE5621ED7 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TChildType_tDB5A61C14076E62C581848EE0EF222299125AB48 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TChildTypeU5BU5D_t6E57A1410F370E60D591E10B591CCD7D8C9CE568 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_CollectionPool_2_t68DF8F721A9F6123977FB5B6431DA91C34DFD0BB },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Queue_1_t3D3BF26F8B19065723D95A73E53AD2CAE0AC4B63 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Queue_1_get_Count_m66B2C1C20E7AB4AA180ED67D71C0A287F3FA68FD },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Activator_CreateInstance_TisTCollection_t3FA83A93ECEA0B573846FDDE8363A05B096ED4C9_mBD0B06C81F7C749B1E550AE733901A56C628367F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Queue_1_Dequeue_m23E76365C777909D787ABB1250CD1FC4A8D38CD0 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TCollection_t3FA83A93ECEA0B573846FDDE8363A05B096ED4C9 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ICollection_1_tE2A5FFDF9E3C3532B4ED69AA4762C8CEF888EFDA },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_TCollection_t3FA83A93ECEA0B573846FDDE8363A05B096ED4C9_ICollection_1_Clear_m6229909D33A9019717CFE81A4C3C14BA9C88FB94 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Queue_1_Enqueue_m85E59BEC1FAAF18CD2210EDAE91CE7B4B9B18A4C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Queue_1__ctor_mCB5166A5B4CE3A8BEFDD90E87D4EB107C2F2F241 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ComponentUtils_1_tAA8BF3405715E21D43CFF82D83EB7807F33E3FCC },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_GameObject_GetComponents_TisT_tFE377E9CC4A5268EDB3EE76BBD1B6D96EDA722CA_m74D025D8361FDA40C95A23BFE328BAA8DEB002AF },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_t208EB6C1A24250C383C9964B4FEEE5929A530429 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Count_m013C936A0C8FA975ACFA6D40274B9AFAC3324D90 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Item_m43C2FE32C769744AC1B03610DAE93B4AE74B2E53 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_GameObject_GetComponentsInChildren_TisT_tFE377E9CC4A5268EDB3EE76BBD1B6D96EDA722CA_m484E91C37A39BBF417EEEB6092F6CD6B6280C22F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1__ctor_m587DBDF688F570E926A3A31F59C250E33B14466F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_GameObject_GetComponent_TisT_t0D67C692906C80053FBABC5F0C493280D362D061_m10527F4B25F6E9F8C3BB4C07411CC8779D10ACB0 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t0D67C692906C80053FBABC5F0C493280D362D061 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_GameObject_AddComponent_TisT_t0D67C692906C80053FBABC5F0C493280D362D061_m5AAA4E17290A1D49C1D23F8BDCAC291C4FEDDFB0 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_T_tDF94EB564F474BFE34322C8863A95353618C4056 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TU5BU5D_t51738BF475F285E3A65084DBF8471615191ED234 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_EnumValues_1_tB582F27FFA983E40792E29F0E6C6286A981F941F },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ICollection_1_tBBA3E6FE5D37CA89114DC9313970140B7C248083 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ICollection_1_get_Count_mC66937F2E53682842CFFE58013256230CEFA06FB },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IEnumerable_1_tBE98F4C7157A17E8A1FC0F9E691ED6B63E825F57 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IEnumerable_1_GetEnumerator_mCA5446209B3FF8E68E38B7EFCAB95317A40EF7F2 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IEnumerator_1_t2A2BB3906B3CADDCDAAEDC8F5CD863952CE8C3A2 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IEnumerator_1_get_Current_m66B635511D04F1AEBE32574A3312F4C778DBBDB7 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t1719D024780C8522A8B3C67CF519B8E01936BCA2 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Dictionary_2_t09BA95F6BF612375C01A9087D7510CB4B6B6FB02 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2_GetEnumerator_mF58172FF9D69A4718E429B3DA9A2D079F476B1DF },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_MoveNext_mA5508A7CC8E8B985BAAE0E2ECF7398084C2FEDC0 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_get_Current_m4EBCB084C8C4BA1F0D020D2446E1C8ECAE583E1C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_Dispose_m934B55E93BD0E1B9C2079C1F8805B4E421D1853D },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_HashSet_1_tD57AD09827AB3FBAFADD0099DC1B0746347888AF },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_HashSet_1_GetEnumerator_m7D86136DC16D1E1D2568ED156B59412B15E3DA39 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_get_Current_m679631ED9B8C9083F1DAC438F97184663D5627FE },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_HashSet_1_Remove_m99BAB4BBB5FCC070F1E63539A63980C61501AB09 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_MoveNext_m038EA8A735A59DC7E75EADE4A973835C909FBA2A },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Enumerator_t47D9633859A7B729BC42A6432A66CFCD40B22B1C },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_Enumerator_t47D9633859A7B729BC42A6432A66CFCD40B22B1C_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_HashSet_1_tADFA9E366635766FA8B5C64BA8DF952A2AA6BAA7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_HashSet_1_GetEnumerator_m138EEDBA1759E6E360346CDC4F1F9F4814DC06B9 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_MoveNext_m42061844369D209B4EC2FBA65EBD58E058941DA5 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_get_Current_m974198F4D3850445F607CC3FFE0A96BF60B7F406 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_Dispose_m3F1FEEDDDB15DB468F4AFED3067937D09A73F50A },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Activator_CreateInstance_TisT_t03A7DF331A62704F4C709524AB955247F406B635_m898D9E8D0EC77E6D787032E7666FC714609C3FA7 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_tF95BA7784DB57B6DD8B9D21CDF9D95B4DA676904 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Add_m53ABD8D82A15312EBBC54427B10E97B44A329DD9 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_tB80F3889249B846990D14F2DFF47D6109A506E25 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Capacity_mA2E41432246A864C5B0BD0C65521F3856BE3A9C8 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_set_Capacity_m859939D8754C427E5F144CF3C8B45B272679AB87 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_TAttribute_t57548C8B54ADE9F6B62DE18403CDFEF1632D8D70 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TAttribute_t57548C8B54ADE9F6B62DE18403CDFEF1632D8D70 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_TAttribute_t6A351DD6FED9BEE8D7B2C56467FE2B19D8D8585D },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_GameObject_GetComponentInChildren_TisT_tE011F873178A408ECF4F6A876D636DF6347F3B47_m7BDCF7C67B54168EBB9DD9045E6919D3934DC100 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_tE011F873178A408ECF4F6A876D636DF6347F3B47 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Object_FindObjectOfType_TisT_tE011F873178A408ECF4F6A876D636DF6347F3B47_mDC5677E088645F9435672A7FF28B74C629CC59A6 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_GameObject_GetComponentsInChildren_TisT_t3A784F37D03862EF8F54D38F8F303DACEDD81070_mC40A724286B91487E0184049AD6183A54394FE24 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t3A784F37D03862EF8F54D38F8F303DACEDD81070 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_GameObject_GetComponent_TisT_t3A784F37D03862EF8F54D38F8F303DACEDD81070_m003693C123FFFC885A1BFBDFD3F5F905AB47147B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Object_FindObjectOfType_TisT_t3A784F37D03862EF8F54D38F8F303DACEDD81070_m5A875963D8B6411AEF55EF1ECAC591E60982B1C6 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_GameObject_GetComponentInChildren_TisT_t498586F0EF6784CE9521E80D659A1EC4F9DAF69B_m399FDEBB438A052001FBA6DDA35CFE4316F83F93 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t498586F0EF6784CE9521E80D659A1EC4F9DAF69B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_GameObject_GetComponentsInChildren_TisT_tD4571279E318B28AB8F4A8AB2F0A8DAD3B806E4E_m7FB48716F68ED16709A62FE04EEBA85ECDDDA357 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_t13FD9EF583DAC56510A13085C3D0DEFF4ABE0163 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_AddRange_m14F164EC754CCFC897233742F24032CC586EA242 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_GameObjectUtils_GetComponentInScene_TisT_t9695B0A9D8A733A130AFB118E36F90A5999D6447_m3752F715901D20522D1274B873DDD36E0ACBE04A },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_GameObjectUtils_GetComponentsInScene_TisT_t6B6807F079C7104A85D2C0DBC6B55F8BBB2266F4_mDF618C95A3E865F73DD07B13B836BAE12B6D3B62 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_GameObjectUtils_GetComponentsInScene_TisT_tD699C7D9D7C8D23D17C3473CAB9BC416241FAF79_m6DA50793EF56D19F8FBB05669DBE32C82DCA9F28 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_NativeArray_1_Dispose_mFA9E49EBE29D76C5CC4F6AF89A1C99BCC5E8F807 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_NativeArray_1_t18ED7CCED341EC3D7FCB63E800366327B0580C1F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_NativeArray_1__ctor_mFA8064634E6EBB7621DE6C9CC0B37CB95A174B57 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Queue_1_t13A6260A2FD5C8157AB33D16FA42FCEB72240B06 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Queue_1_get_Count_m098FC3C80525E22BF08BBC7A5DFFAE46B2167907 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Queue_1_Dequeue_m51B578D46AECA36CF999B147DFDEED63CC77016C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Activator_CreateInstance_TisT_t6817021F4A7EAA4D352F23CF91779E4891FAC71D_m7C6DD59DCCF8FAD87DCD2DA3105CD65424B75C18 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ObjectPool_1_tD19C2A9E2ED973F7475DA6B78193D5917B0DCE88 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_ClearInstance_m2FB8C52A61FCC751DC7F22FA968D7DCBA45DF29F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Queue_1_Enqueue_mD46AE6D92A1DCC609D60D353D71C80E297BDB8FE },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Queue_1__ctor_m77EF736B080DD9B6616CCD6E44B468CD1DD2D593 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ScriptableSettingsBase_1_tCC1B8E644A002165B9D289E629ACBCC8B5204C02 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_tD75C904482F31E0C214186BAFACA01AAB4FBF363 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ScriptableSettings_1_CreateAndLoad_m2EDBA665001FF4299EE657B3C1894F8058C623CB },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ScriptableSettings_1_tEBDCEA06A56D935B7439A14F8513ACB8C0A9324C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ScriptableSettingsBase_1_GetFilePath_m244E3E208D7A2BC4C596185AC9D6FE21D70C23C7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ScriptableObject_CreateInstance_TisT_tD75C904482F31E0C214186BAFACA01AAB4FBF363_m85F0865C5F95DB0E84C77BC6844EE97C6B6A353B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ScriptableSettingsBase_1_Save_m11628EF4A57C395C7E5A131FB57C63F99B0400BF },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ScriptableSettingsBase_1__ctor_m656DFE56F50E42B3AFC0966AF2DB4C079F87C944 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ScriptableSettingsBase_1_t38EEBDA86A8D7AAF469BF841A8F15D5C1B343D6C },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t2D4A2C3F601E1DE59938CB9FE4D7055ACC03CB49 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_T_t2D4A2C3F601E1DE59938CB9FE4D7055ACC03CB49 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_GameObject_AddComponent_TisT_t0573350EC878887841167DA02B13BF9E339E364F_m3CC0FBC349CDAE4079FB63629746D012DABBC633 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_tC0030B04C7A2D4622AC81EC96505385B58AFFF63 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_GameObject_GetComponent_TisT_tC0030B04C7A2D4622AC81EC96505385B58AFFF63_mDEA99B19A4938AB4E238F0CB176737DD22ECC702 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Component_GetComponent_TisT_tC0030B04C7A2D4622AC81EC96505385B58AFFF63_mAEBC74D0B6F23051457E11646EA36F9D6F7C08F3 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_CollectionPool_2_GetCollection_mFACB1227D81EE7893CDE25CA64566ACCB5FEBEE8 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_CollectionPool_2_tC3E61FA69806DF5FA3DDD025644BCFDAA2C23353 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_t8383F8BEECB75BF70BB411C136C8179E34286D8E },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_GetEnumerator_mF31DB752CD484D63E0F5D1D30E587D318BAF551E },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_get_Current_m82BADC24ED5B3611F7513614C0910FD560A73091 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_tBBBE52C3C2742E9C03E67DB0095BB29C00214457 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Add_mCBB2B5B27E550FDA0A4EC5539A75CC1FA9A1D8B9 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_MoveNext_mD7B6B8F9F8B56A9FEB9C7968B36A1B947370980F },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Enumerator_t4ED09183E855AB2F38AAF033FC6172CB3A0A66A4 },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_Enumerator_t4ED09183E855AB2F38AAF033FC6172CB3A0A66A4_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Remove_mE7EE147EBFF27EACBC4BB0BA2B9F4E752918DC9D },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_CollectionPool_2_RecycleCollection_mAD3A410923DBA05CF42D7D22DB5012844E3AD8E7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_CollectionPool_2_GetCollection_m57965D3DB65C01805188EF09B1F86BE445477971 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_CollectionPool_2_tE6222BC73D1BD57B6036CBC60A08B48F50E49862 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Dictionary_2_tA045B77988CDC5629C320AEF7943AA07D8819550 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2_GetEnumerator_m48628F67876A8C4B723F1D8C0A7397CDED99AF05 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_get_Current_mB012F336D51E3CBF8A0F029882F5B32AB1449864 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_KeyValuePair_2_get_Key_m0C153F0308143DA08A8BBC22E15803C0D601A009 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TKey_t61648F1BA22185879A9692328C8D74405AEC2480 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_t8D05945719C5D40B30D99882FF49833281BC8860 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Add_mBFDC233069FDDDDADCD7A04D1800B3FAFF5DE8F0 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_MoveNext_mF872DDB078667D5BE0E4677DC666CDF107EEB41B },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Enumerator_tE81BED011F0DBDB4F2EFFA0D19A6B53F116A78B8 },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_Enumerator_tE81BED011F0DBDB4F2EFFA0D19A6B53F116A78B8_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_GetEnumerator_mA553AFFE584C4C1C4E8F6BB7B2957B2109C41DED },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_get_Current_m646A8134FEE0338FBC09BC2F42725BA99E7B6F6C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2_Remove_m5570991B107C82B3E61F637B202C7DE703B5E568 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_MoveNext_m89874E375B7CF0D5F33D6CA462864BF1EEC3B566 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Enumerator_t051FB00CE2D0096E938C74EDF2CF40ABD53D7E66 },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_Enumerator_t051FB00CE2D0096E938C74EDF2CF40ABD53D7E66_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_CollectionPool_2_RecycleCollection_m91035B80A8EF837111C2D8CF0FDAC140BBD16711 },
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_Unity_XR_CoreUtils_CodeGenModule;
const Il2CppCodeGenModule g_Unity_XR_CoreUtils_CodeGenModule = 
{
	"Unity.XR.CoreUtils.dll",
	289,
	s_methodPointers,
	14,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	31,
	s_rgctxIndices,
	178,
	s_rgctxValues,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
