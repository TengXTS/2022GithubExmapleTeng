﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Boolean UnityEngine.XR.Interaction.Toolkit.CanSelectMultipleAttribute::get_allowMultiple()
extern void CanSelectMultipleAttribute_get_allowMultiple_m8557815228A36EA8FB99C86FC9E7E0854C6568EB (void);
// 0x00000002 System.Void UnityEngine.XR.Interaction.Toolkit.CanSelectMultipleAttribute::.ctor(System.Boolean)
extern void CanSelectMultipleAttribute__ctor_m65A147231626A91AD8D6C66A80723EA6795FD1CF (void);
// 0x00000003 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_positionAction()
extern void ActionBasedController_get_positionAction_m754BEEC79908AD0B05827F441039715F3FF9F40A (void);
// 0x00000004 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_positionAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_set_positionAction_m1E352B658F8756D78E7BC0FED74834AE22EBBB29 (void);
// 0x00000005 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_rotationAction()
extern void ActionBasedController_get_rotationAction_m418204140263364B58561E704F5D97DF648E1B9A (void);
// 0x00000006 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_rotationAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_set_rotationAction_mBD9206C9F2B73E15CD85A95C59FE348AE3914C2B (void);
// 0x00000007 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_trackingStateAction()
extern void ActionBasedController_get_trackingStateAction_m7E3164EA6486DC1176AC983954B65B93805C9951 (void);
// 0x00000008 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_trackingStateAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_set_trackingStateAction_m377F19A22AA7DF326781E8E171E5391F79F5C5D8 (void);
// 0x00000009 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_selectAction()
extern void ActionBasedController_get_selectAction_mB7F0F7A3FDA18D5753FFC539AB4D9A9451C78C3C (void);
// 0x0000000A System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_selectAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_set_selectAction_mB210DAA27E0F045CEBDEEDA584B3EBC7BAC99246 (void);
// 0x0000000B UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_selectActionValue()
extern void ActionBasedController_get_selectActionValue_mC1D5E27D1EC30E1A31954815CF60DEE165C24704 (void);
// 0x0000000C System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_selectActionValue(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_set_selectActionValue_mB6B34DA26D1D3BCE3B4761F8F3E9630D1B7EF0F8 (void);
// 0x0000000D UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_activateAction()
extern void ActionBasedController_get_activateAction_mD97B355F98BF302391A562F2A661DB97CA72C845 (void);
// 0x0000000E System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_activateAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_set_activateAction_m62C67F63B2B8F3404F7B2909FD9D84A0101FD515 (void);
// 0x0000000F UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_activateActionValue()
extern void ActionBasedController_get_activateActionValue_mDC487447CFEBCBC00EC988EF0B88DC9F4AE23FE5 (void);
// 0x00000010 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_activateActionValue(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_set_activateActionValue_mD3449A9AD114DFBE8A6413BCA0C44D946CEB64A9 (void);
// 0x00000011 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_uiPressAction()
extern void ActionBasedController_get_uiPressAction_m289E3CE312A085905B6E5257933CC65971F39E6D (void);
// 0x00000012 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_uiPressAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_set_uiPressAction_mB2A8DC81210F16A6CA03E647CB0159B5F298F2AB (void);
// 0x00000013 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_uiPressActionValue()
extern void ActionBasedController_get_uiPressActionValue_mAA7085044BE279673714B48D92937AE5DBF96757 (void);
// 0x00000014 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_uiPressActionValue(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_set_uiPressActionValue_m357BB1F6FE310478FCBFB670421AFFF368864DCD (void);
// 0x00000015 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_hapticDeviceAction()
extern void ActionBasedController_get_hapticDeviceAction_m673A63E53DBBD8F2DF95E73F656DAA5889C3C016 (void);
// 0x00000016 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_hapticDeviceAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_set_hapticDeviceAction_m0EAD0A6F262DEB2F94203889133180E40533B524 (void);
// 0x00000017 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_rotateAnchorAction()
extern void ActionBasedController_get_rotateAnchorAction_m585FB8A85651CB53058D262F356FFDB555C0434D (void);
// 0x00000018 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_rotateAnchorAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_set_rotateAnchorAction_mABD5D53EFC70CDDC035E88760CB12E7A34DB0AA3 (void);
// 0x00000019 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_translateAnchorAction()
extern void ActionBasedController_get_translateAnchorAction_m43AB9FEF504B78C5397B53170D59FF8B3F28D688 (void);
// 0x0000001A System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_translateAnchorAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_set_translateAnchorAction_m56A78271FB3AE8400BC0417F24DBCEB9007C9626 (void);
// 0x0000001B System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::OnEnable()
extern void ActionBasedController_OnEnable_mA6D2EAC1A7A285B0AA3A5DF7635A333127931AEC (void);
// 0x0000001C System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::OnDisable()
extern void ActionBasedController_OnDisable_m1FF4C941BD3FC5F660A32CDDC627F65EA0F24BC1 (void);
// 0x0000001D System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::UpdateTrackingInput(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void ActionBasedController_UpdateTrackingInput_m7E685CC1E2820C31654BAF8B78059B576BF96C0A (void);
// 0x0000001E System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::UpdateInput(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void ActionBasedController_UpdateInput_m50BC27AA49CD78DA5BBABDA13B7B14885A78351E (void);
// 0x0000001F System.Boolean UnityEngine.XR.Interaction.Toolkit.ActionBasedController::IsPressed(UnityEngine.InputSystem.InputAction)
extern void ActionBasedController_IsPressed_m4BC91FBF17261111A6546341A6ABFCC656473E49 (void);
// 0x00000020 System.Single UnityEngine.XR.Interaction.Toolkit.ActionBasedController::ReadValue(UnityEngine.InputSystem.InputAction)
extern void ActionBasedController_ReadValue_mA23FF5B4D8BA41D21380CE793203BB92F36B1C7C (void);
// 0x00000021 System.Boolean UnityEngine.XR.Interaction.Toolkit.ActionBasedController::SendHapticImpulse(System.Single,System.Single)
extern void ActionBasedController_SendHapticImpulse_mEEAB1C22F0D5D99C809709F1983D16B05E15A182 (void);
// 0x00000022 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::EnableAllDirectActions()
extern void ActionBasedController_EnableAllDirectActions_m0C45E546471C3183F092CCB85D51C009E6D6A803 (void);
// 0x00000023 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::DisableAllDirectActions()
extern void ActionBasedController_DisableAllDirectActions_mADDBCFCAC755FAC913EFDDF983FC1D7266FEF253 (void);
// 0x00000024 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::SetInputActionProperty(UnityEngine.InputSystem.InputActionProperty&,UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_SetInputActionProperty_m999355F89D6CDA8327F99C4F721F6BE5104C5313 (void);
// 0x00000025 System.Boolean UnityEngine.XR.Interaction.Toolkit.ActionBasedController::IsDisabledReferenceAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedController_IsDisabledReferenceAction_m4153A76E0C89C388E5247ED98AB95E98C6855B51 (void);
// 0x00000026 System.Single UnityEngine.XR.Interaction.Toolkit.ActionBasedController::get_buttonPressPoint()
extern void ActionBasedController_get_buttonPressPoint_mC0CF59C4782CC5610D006923A7290BEB7C1FB7EB (void);
// 0x00000027 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::set_buttonPressPoint(System.Single)
extern void ActionBasedController_set_buttonPressPoint_m0BCF0E785363E6F25CA2D6102593A08FDC188845 (void);
// 0x00000028 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedController::.ctor()
extern void ActionBasedController__ctor_m601BEF4C957FC4FD1641271BB7D7DA5542419DE6 (void);
// 0x00000029 UnityEngine.XR.Interaction.Toolkit.XRBaseController/UpdateType UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_updateTrackingType()
extern void XRBaseController_get_updateTrackingType_m9F99E1E98DB2D0E33A8CF4D83D8FC0FBA112216D (void);
// 0x0000002A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_updateTrackingType(UnityEngine.XR.Interaction.Toolkit.XRBaseController/UpdateType)
extern void XRBaseController_set_updateTrackingType_mE5401B9A9B1A2D46C588C0FC8EAC7EABA89A3F2B (void);
// 0x0000002B System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_enableInputTracking()
extern void XRBaseController_get_enableInputTracking_mCB03DA4E1BF7E6E77A7BC359A166E7FD09CDD0F5 (void);
// 0x0000002C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_enableInputTracking(System.Boolean)
extern void XRBaseController_set_enableInputTracking_m19387852D9C6A0869AA04A4BD6A4E5F9F5111858 (void);
// 0x0000002D System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_enableInputActions()
extern void XRBaseController_get_enableInputActions_m4E285A2F619049FF60318453228523C193C9E8CE (void);
// 0x0000002E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_enableInputActions(System.Boolean)
extern void XRBaseController_set_enableInputActions_m74E6BEA651230890AF81718CE1E25FF030592BFA (void);
// 0x0000002F UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_modelPrefab()
extern void XRBaseController_get_modelPrefab_m8F3104181B37688F66D3C71F6AE871F1E8576A58 (void);
// 0x00000030 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_modelPrefab(UnityEngine.Transform)
extern void XRBaseController_set_modelPrefab_m78555A9D2D46FFDF2303E9927F725686BD8D6BAC (void);
// 0x00000031 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_modelParent()
extern void XRBaseController_get_modelParent_m759C95F1FA9D11AF1A380B9F16438A41DA409AEF (void);
// 0x00000032 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_modelParent(UnityEngine.Transform)
extern void XRBaseController_set_modelParent_m5CA5FB47E54C33F02BCEB1501298B7DB22589112 (void);
// 0x00000033 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_model()
extern void XRBaseController_get_model_m8E9DD91990CD87A6B4AF13DB6C3EA06EB5A3A5C0 (void);
// 0x00000034 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_model(UnityEngine.Transform)
extern void XRBaseController_set_model_mEECED3A71604C4CC57B821D6311E8C229EDD8C5D (void);
// 0x00000035 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_animateModel()
extern void XRBaseController_get_animateModel_m18E1D1CC94513D87FC19213F418BFD5E8D052E5A (void);
// 0x00000036 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_animateModel(System.Boolean)
extern void XRBaseController_set_animateModel_m38D1A893585B1C56FE91E1076BBDEDEF0705BABB (void);
// 0x00000037 System.String UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_modelSelectTransition()
extern void XRBaseController_get_modelSelectTransition_mD242ED880A0434C2D5B308E0FDFDC36539D006DA (void);
// 0x00000038 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_modelSelectTransition(System.String)
extern void XRBaseController_set_modelSelectTransition_m2FE46551D42B6EA02B416551BD40548733A274D0 (void);
// 0x00000039 System.String UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_modelDeSelectTransition()
extern void XRBaseController_get_modelDeSelectTransition_mB5029F76300D9665584B3C2367F271A8AF985E40 (void);
// 0x0000003A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_modelDeSelectTransition(System.String)
extern void XRBaseController_set_modelDeSelectTransition_m03973FE1F5AC9A5D8C498262251D6985F40B71D5 (void);
// 0x0000003B System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_hideControllerModel()
extern void XRBaseController_get_hideControllerModel_m49B1EE19937162AA4F16AC81832210BD248A5B1A (void);
// 0x0000003C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_hideControllerModel(System.Boolean)
extern void XRBaseController_set_hideControllerModel_mC89F417807EF5C8E4D787AE69746FF81B1C3EF3A (void);
// 0x0000003D UnityEngine.XR.Interaction.Toolkit.InteractionState UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_selectInteractionState()
extern void XRBaseController_get_selectInteractionState_m607E98EBB0AA181459CF4165499F84BEFC49B53A (void);
// 0x0000003E UnityEngine.XR.Interaction.Toolkit.InteractionState UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_activateInteractionState()
extern void XRBaseController_get_activateInteractionState_m93E7F1F64049D215C2CCDB11C0567D07C349DC41 (void);
// 0x0000003F UnityEngine.XR.Interaction.Toolkit.InteractionState UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_uiPressInteractionState()
extern void XRBaseController_get_uiPressInteractionState_mB07F0309336EA4A99D5FD150A6FD76A7F6FA417F (void);
// 0x00000040 UnityEngine.XR.Interaction.Toolkit.XRControllerState UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_currentControllerState()
extern void XRBaseController_get_currentControllerState_mA9E97CEA72CB7A87F1A5D78A6F214A4879F43F6F (void);
// 0x00000041 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_currentControllerState(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void XRBaseController_set_currentControllerState_mDD2F323DD62343478F9B924018187AB5CF3AFE7D (void);
// 0x00000042 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::Awake()
extern void XRBaseController_Awake_m969CBFCD5A52E263BFD8D37F85600F2BBF0D8C59 (void);
// 0x00000043 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::OnEnable()
extern void XRBaseController_OnEnable_mF366667E8E73F4917E9E08DE2C1431E3FB1194B4 (void);
// 0x00000044 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::OnDisable()
extern void XRBaseController_OnDisable_m15F25B1E176A7DEE509BBFE7F360EBE7E3338167 (void);
// 0x00000045 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::Update()
extern void XRBaseController_Update_m1954F912B6A6C56E2BB39D582EDEEB80DF1DE7F4 (void);
// 0x00000046 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::SetupModel()
extern void XRBaseController_SetupModel_mA383D4BFA4B75F134FB3FB7A584F159803327D52 (void);
// 0x00000047 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::SetupControllerState()
extern void XRBaseController_SetupControllerState_mAB522AB27E4F8ED391B88158F498DF62BD8C9C74 (void);
// 0x00000048 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.XRBaseController::GetModelPrefab()
extern void XRBaseController_GetModelPrefab_m7E27A0C2202581E1C33524E9E8BD9CA7763545A4 (void);
// 0x00000049 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::UpdateController()
extern void XRBaseController_UpdateController_mD419ABCB5D7D017EAFC69E08AEE961B1DF708222 (void);
// 0x0000004A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::OnBeforeRender()
extern void XRBaseController_OnBeforeRender_mA8D54A70D64EFD4DE2EA3F61B3F08BAE32FE2529 (void);
// 0x0000004B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::ApplyControllerState(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase,UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void XRBaseController_ApplyControllerState_m812F8B210953E22C782D0EF934FF734E3FBEF1D9 (void);
// 0x0000004C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::UpdateTrackingInput(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void XRBaseController_UpdateTrackingInput_mCC0333C7F9A8781D9CA01FF18E2314D6E7F1282F (void);
// 0x0000004D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::UpdateInput(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void XRBaseController_UpdateInput_m4132D572C76473379C969E65AC2AD05CE34AA8C4 (void);
// 0x0000004E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::UpdateControllerModelAnimation()
extern void XRBaseController_UpdateControllerModelAnimation_m510A87EA3FED6C9DE4CF132FE5819DBCC9B61666 (void);
// 0x0000004F System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseController::SendHapticImpulse(System.Single,System.Single)
extern void XRBaseController_SendHapticImpulse_m7DBFA2261E7FCEA7930852ACE307C77A691528A1 (void);
// 0x00000050 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseController::GetControllerState(UnityEngine.XR.Interaction.Toolkit.XRControllerState&)
extern void XRBaseController_GetControllerState_m4E08576FDD9FAB931643EE136053BCECAD1C9F0A (void);
// 0x00000051 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::SetControllerState(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void XRBaseController_SetControllerState_mD0E3F48F2F9337A923E61125272D10043B72A463 (void);
// 0x00000052 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_modelTransform()
extern void XRBaseController_get_modelTransform_m2B451BBC8FBF5A268C9A68D1B74B9C5F904DD976 (void);
// 0x00000053 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_modelTransform(UnityEngine.Transform)
extern void XRBaseController_set_modelTransform_m00F2D5ED969A73D258AC5378B18B7A56C8163A7E (void);
// 0x00000054 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_anchorControlDeadzone()
extern void XRBaseController_get_anchorControlDeadzone_m554D8D27AB3CCB197125C4F102959286DBFF231E (void);
// 0x00000055 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_anchorControlDeadzone(System.Single)
extern void XRBaseController_set_anchorControlDeadzone_m68BDD2E6B5959DD97FEDF6E033DF52AE532B2233 (void);
// 0x00000056 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseController::get_anchorControlOffAxisDeadzone()
extern void XRBaseController_get_anchorControlOffAxisDeadzone_mE5D5AD2AD1F00DCF9B04FFFFC7C83492B386C3A3 (void);
// 0x00000057 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::set_anchorControlOffAxisDeadzone(System.Single)
extern void XRBaseController_set_anchorControlOffAxisDeadzone_mFCBD92C990571310E6ED383E782B92B869604B24 (void);
// 0x00000058 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseController::.ctor()
extern void XRBaseController__ctor_mAB469A8A2B478CC37F1BA0BEE00D7ED28C1CAA30 (void);
// 0x00000059 UnityEngine.XR.XRNode UnityEngine.XR.Interaction.Toolkit.XRController::get_controllerNode()
extern void XRController_get_controllerNode_m84357B5F8DB7E0E61C12C8E89BC0F8CEBE1B0ED4 (void);
// 0x0000005A System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_controllerNode(UnityEngine.XR.XRNode)
extern void XRController_set_controllerNode_mDB11A0BBD405A0D024AB926F6A50861D389A041F (void);
// 0x0000005B UnityEngine.XR.Interaction.Toolkit.InputHelpers/Button UnityEngine.XR.Interaction.Toolkit.XRController::get_selectUsage()
extern void XRController_get_selectUsage_mC9C45D97DA3FFD0DC5F43E5A5D5EAD8722FF7DCD (void);
// 0x0000005C System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_selectUsage(UnityEngine.XR.Interaction.Toolkit.InputHelpers/Button)
extern void XRController_set_selectUsage_m233DAAF98F5F3C531B58B672A6490C2A9C88FD84 (void);
// 0x0000005D UnityEngine.XR.Interaction.Toolkit.InputHelpers/Button UnityEngine.XR.Interaction.Toolkit.XRController::get_activateUsage()
extern void XRController_get_activateUsage_m8937EBF3E85592AFDF8766495B307364628CE0D9 (void);
// 0x0000005E System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_activateUsage(UnityEngine.XR.Interaction.Toolkit.InputHelpers/Button)
extern void XRController_set_activateUsage_mEE163A312869B64527AC02F402AB892D16B85A5E (void);
// 0x0000005F UnityEngine.XR.Interaction.Toolkit.InputHelpers/Button UnityEngine.XR.Interaction.Toolkit.XRController::get_uiPressUsage()
extern void XRController_get_uiPressUsage_m20022FE68843065176BCB5351BE67A9C1F5AACC7 (void);
// 0x00000060 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_uiPressUsage(UnityEngine.XR.Interaction.Toolkit.InputHelpers/Button)
extern void XRController_set_uiPressUsage_m949C86B998663FDAC3F9240A0D5B0B58166AF7F8 (void);
// 0x00000061 System.Single UnityEngine.XR.Interaction.Toolkit.XRController::get_axisToPressThreshold()
extern void XRController_get_axisToPressThreshold_m7D44CA04CC3C10786D7B0EBA8D648CD1284B3B06 (void);
// 0x00000062 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_axisToPressThreshold(System.Single)
extern void XRController_set_axisToPressThreshold_m85BAAE24786C4715C2FE76D4826275E2A573FBF2 (void);
// 0x00000063 UnityEngine.XR.Interaction.Toolkit.InputHelpers/Button UnityEngine.XR.Interaction.Toolkit.XRController::get_rotateObjectLeft()
extern void XRController_get_rotateObjectLeft_m4445D21E8199AEEF3260128685D574EAABBE56F3 (void);
// 0x00000064 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_rotateObjectLeft(UnityEngine.XR.Interaction.Toolkit.InputHelpers/Button)
extern void XRController_set_rotateObjectLeft_m7A196512A1AC2E46B1F42144E63BCE8689B26EED (void);
// 0x00000065 UnityEngine.XR.Interaction.Toolkit.InputHelpers/Button UnityEngine.XR.Interaction.Toolkit.XRController::get_rotateObjectRight()
extern void XRController_get_rotateObjectRight_mE8E05BF5562681EEF2C644361981E49AC3F21B72 (void);
// 0x00000066 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_rotateObjectRight(UnityEngine.XR.Interaction.Toolkit.InputHelpers/Button)
extern void XRController_set_rotateObjectRight_mE04DC79D754449C284B945F82366F65089852279 (void);
// 0x00000067 UnityEngine.XR.Interaction.Toolkit.InputHelpers/Button UnityEngine.XR.Interaction.Toolkit.XRController::get_moveObjectIn()
extern void XRController_get_moveObjectIn_mE1BC59DD9456484BFC945802712B1AAF4C471FD6 (void);
// 0x00000068 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_moveObjectIn(UnityEngine.XR.Interaction.Toolkit.InputHelpers/Button)
extern void XRController_set_moveObjectIn_m81CCDBB1F3518D5560A426B33CA415F402106875 (void);
// 0x00000069 UnityEngine.XR.Interaction.Toolkit.InputHelpers/Button UnityEngine.XR.Interaction.Toolkit.XRController::get_moveObjectOut()
extern void XRController_get_moveObjectOut_m5B470BCB70F62E72DEEBAA4ED362DAC82ACA8B81 (void);
// 0x0000006A System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_moveObjectOut(UnityEngine.XR.Interaction.Toolkit.InputHelpers/Button)
extern void XRController_set_moveObjectOut_m7C4D09527C06F337AEEC1BDBBB25DA561A354AC6 (void);
// 0x0000006B UnityEngine.Experimental.XR.Interaction.BasePoseProvider UnityEngine.XR.Interaction.Toolkit.XRController::get_poseProvider()
extern void XRController_get_poseProvider_mA193852B0920865CDE7C09390C45F35F5AA7D0F9 (void);
// 0x0000006C System.Void UnityEngine.XR.Interaction.Toolkit.XRController::set_poseProvider(UnityEngine.Experimental.XR.Interaction.BasePoseProvider)
extern void XRController_set_poseProvider_mC33BCBD2433BADEE7A111854FAD953AD13060515 (void);
// 0x0000006D UnityEngine.XR.InputDevice UnityEngine.XR.Interaction.Toolkit.XRController::get_inputDevice()
extern void XRController_get_inputDevice_m584AA43BBBC4CD0FAD047217DDB64DCD35281389 (void);
// 0x0000006E System.Void UnityEngine.XR.Interaction.Toolkit.XRController::UpdateTrackingInput(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void XRController_UpdateTrackingInput_m8990DE6A19F455C9069E94FE1269BA8FF0E0B1C3 (void);
// 0x0000006F System.Void UnityEngine.XR.Interaction.Toolkit.XRController::UpdateInput(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void XRController_UpdateInput_m5A3EA9E142CF530241D40B8C2BCC9FE25AD81CE2 (void);
// 0x00000070 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRController::IsPressed(UnityEngine.XR.Interaction.Toolkit.InputHelpers/Button)
extern void XRController_IsPressed_mB6EFB2C76C05ABE3C3714249935F74C059C07452 (void);
// 0x00000071 System.Single UnityEngine.XR.Interaction.Toolkit.XRController::ReadValue(UnityEngine.XR.Interaction.Toolkit.InputHelpers/Button)
extern void XRController_ReadValue_mF1FB601A4147C4FF73F0C43F4684429B081B9CE9 (void);
// 0x00000072 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRController::SendHapticImpulse(System.Single,System.Single)
extern void XRController_SendHapticImpulse_m0E806AA5D00ACD79FB676FD683C078154D53C2E7 (void);
// 0x00000073 System.Void UnityEngine.XR.Interaction.Toolkit.XRController::.ctor()
extern void XRController__ctor_mFD260BA76E7F67E04FD4BB87FF0503D56B711901 (void);
// 0x00000074 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_playOnStart()
extern void XRControllerRecorder_get_playOnStart_m0C823A5F4D18A82823F2C79719E6601E6F9DC49C (void);
// 0x00000075 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::set_playOnStart(System.Boolean)
extern void XRControllerRecorder_set_playOnStart_m5DF305E21C59E009B87D156A611A5C91FB8F976A (void);
// 0x00000076 UnityEngine.XR.Interaction.Toolkit.XRControllerRecording UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_recording()
extern void XRControllerRecorder_get_recording_m227AE5B7CCEB3345DDBACF67A9EEE84CFD092443 (void);
// 0x00000077 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::set_recording(UnityEngine.XR.Interaction.Toolkit.XRControllerRecording)
extern void XRControllerRecorder_set_recording_mC5826AC9954858BF14E8AF98A358864AE8635623 (void);
// 0x00000078 UnityEngine.XR.Interaction.Toolkit.XRBaseController UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_xrController()
extern void XRControllerRecorder_get_xrController_m025A4175322862B5FDA4D1F03256DA247A490657 (void);
// 0x00000079 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::set_xrController(UnityEngine.XR.Interaction.Toolkit.XRBaseController)
extern void XRControllerRecorder_set_xrController_mAAEB712272CC24019A7773E0A552EA3564C77A82 (void);
// 0x0000007A System.Boolean UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_isRecording()
extern void XRControllerRecorder_get_isRecording_m8CA5F5A62CB1285F3F9974829D992176F21AD956 (void);
// 0x0000007B System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::set_isRecording(System.Boolean)
extern void XRControllerRecorder_set_isRecording_m40043115D1978067B1795B259119EA846AAD28D6 (void);
// 0x0000007C System.Boolean UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_isPlaying()
extern void XRControllerRecorder_get_isPlaying_m2D33C6F89A6AB582F6FC5B8C4F9666E703F0A8FB (void);
// 0x0000007D System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::set_isPlaying(System.Boolean)
extern void XRControllerRecorder_set_isPlaying_m80CCEA22180D5AC8C51BB30360B10BA88B622110 (void);
// 0x0000007E System.Double UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_currentTime()
extern void XRControllerRecorder_get_currentTime_mE4A76107CD1AAB706A5FE618B23D18FD8E2DEDB6 (void);
// 0x0000007F System.Double UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_duration()
extern void XRControllerRecorder_get_duration_m0A4C7407B5BC633DF8DF24BED50A263838219B5F (void);
// 0x00000080 System.Single UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::get_recordingStartTime()
extern void XRControllerRecorder_get_recordingStartTime_m11FF7EB2618B66213B259CB000F6282ED8A24C5D (void);
// 0x00000081 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::set_recordingStartTime(System.Single)
extern void XRControllerRecorder_set_recordingStartTime_mE03290CF98AB070C1705EFF8B1E13867D892501C (void);
// 0x00000082 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::Awake()
extern void XRControllerRecorder_Awake_m06542BF05267DC192672EFD27D48C1FFD898D273 (void);
// 0x00000083 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::Update()
extern void XRControllerRecorder_Update_m6E884E4CB3B7E3EE972D0E64044C9B4AA2BE409C (void);
// 0x00000084 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::OnDestroy()
extern void XRControllerRecorder_OnDestroy_m9B30F6533FD2B2D1EB26AED12CECAA5444108780 (void);
// 0x00000085 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::ResetPlayback()
extern void XRControllerRecorder_ResetPlayback_mC5BAE715DEDFCF3C3A969120D3CBC9C855DAB427 (void);
// 0x00000086 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::UpdatePlaybackTime(System.Double)
extern void XRControllerRecorder_UpdatePlaybackTime_mE78B41A2B3BD2F26A7FDD8CA936E1AD3C8763605 (void);
// 0x00000087 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::GetControllerState(UnityEngine.XR.Interaction.Toolkit.XRControllerState&)
extern void XRControllerRecorder_GetControllerState_mE1E333D3C4C2B941326B34B15840448CBEC47DAC (void);
// 0x00000088 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecorder::.ctor()
extern void XRControllerRecorder__ctor_mF15646BC8E7B61EB36596FF3919DBFB59DE3E524 (void);
// 0x00000089 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRControllerState> UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::get_frames()
extern void XRControllerRecording_get_frames_m006772DE1B30E70E1CF387541325D606A522ADF7 (void);
// 0x0000008A System.Double UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::get_duration()
extern void XRControllerRecording_get_duration_mC79AA5413F875C410E85E4EB41B61481BD3A7DB1 (void);
// 0x0000008B System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::UnityEngine.ISerializationCallbackReceiver.OnBeforeSerialize()
extern void XRControllerRecording_UnityEngine_ISerializationCallbackReceiver_OnBeforeSerialize_m870556D9C38001EA0B00217F8C5F3F1B78B9053B (void);
// 0x0000008C System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::UnityEngine.ISerializationCallbackReceiver.OnAfterDeserialize()
extern void XRControllerRecording_UnityEngine_ISerializationCallbackReceiver_OnAfterDeserialize_m64A30D5EDC2A6884764202CF81A92623D8A39F50 (void);
// 0x0000008D System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::AddRecordingFrame(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void XRControllerRecording_AddRecordingFrame_mCE544FC7E7DEF6934204D64455922C9428E2C1C3 (void);
// 0x0000008E System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::AddRecordingFrameNonAlloc(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void XRControllerRecording_AddRecordingFrameNonAlloc_m701C354DBBE731AFF29167FE5EFA180B58729300 (void);
// 0x0000008F System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::InitRecording()
extern void XRControllerRecording_InitRecording_m47C1F6C9469FF38363164ACDD851F0BA9B5359AE (void);
// 0x00000090 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::SaveRecording()
extern void XRControllerRecording_SaveRecording_mAE299C7A3EB90C171CB33054E739D10643000DCC (void);
// 0x00000091 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::AddRecordingFrame(System.Double,UnityEngine.Vector3,UnityEngine.Quaternion,System.Boolean,System.Boolean,System.Boolean)
extern void XRControllerRecording_AddRecordingFrame_m6AF90EC7798B6BC3323F01D69F8D7D44F28F8E9C (void);
// 0x00000092 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerRecording::.ctor()
extern void XRControllerRecording__ctor_m97867E991DC4EEE6E2ADFA828EEAD91AD7FE2B96 (void);
// 0x00000093 System.Single UnityEngine.XR.Interaction.Toolkit.InteractionState::get_value()
extern void InteractionState_get_value_mD1E8048CF73C1EBD045C1F2598CB8D4300291F89 (void);
// 0x00000094 System.Void UnityEngine.XR.Interaction.Toolkit.InteractionState::set_value(System.Single)
extern void InteractionState_set_value_m99DCAF279B4C23C1D2690616B6D8E5C9D9CA46BD (void);
// 0x00000095 System.Boolean UnityEngine.XR.Interaction.Toolkit.InteractionState::get_active()
extern void InteractionState_get_active_m1E069A7D42F19F587B2F384A8EFB9A3D6EDE8E31 (void);
// 0x00000096 System.Void UnityEngine.XR.Interaction.Toolkit.InteractionState::set_active(System.Boolean)
extern void InteractionState_set_active_mA48D0212ED136A9EDB38879A4B1D3A4DB3DB78F3 (void);
// 0x00000097 System.Boolean UnityEngine.XR.Interaction.Toolkit.InteractionState::get_activatedThisFrame()
extern void InteractionState_get_activatedThisFrame_m512E1A559B40E19753A0D9F666B3BB44C8BCC6DA (void);
// 0x00000098 System.Void UnityEngine.XR.Interaction.Toolkit.InteractionState::set_activatedThisFrame(System.Boolean)
extern void InteractionState_set_activatedThisFrame_mEF19740F5C82F14B507A05C0CD746BE6E0B703F3 (void);
// 0x00000099 System.Boolean UnityEngine.XR.Interaction.Toolkit.InteractionState::get_deactivatedThisFrame()
extern void InteractionState_get_deactivatedThisFrame_m9C1D440D21737F44E68D853F0934B0102A87470F (void);
// 0x0000009A System.Void UnityEngine.XR.Interaction.Toolkit.InteractionState::set_deactivatedThisFrame(System.Boolean)
extern void InteractionState_set_deactivatedThisFrame_mA0DCE61AC5D7E1124AA742288C6543419984D786 (void);
// 0x0000009B System.Void UnityEngine.XR.Interaction.Toolkit.InteractionState::SetFrameState(System.Boolean)
extern void InteractionState_SetFrameState_m7DF731F357512FDD2952CCEB5F2BDCA64FDE4535 (void);
// 0x0000009C System.Void UnityEngine.XR.Interaction.Toolkit.InteractionState::SetFrameState(System.Boolean,System.Single)
extern void InteractionState_SetFrameState_mFD251DE03E6724F0D133CC5D16543BC560D54674 (void);
// 0x0000009D System.Void UnityEngine.XR.Interaction.Toolkit.InteractionState::SetFrameDependent(System.Boolean)
extern void InteractionState_SetFrameDependent_mA78B0D0627754F8D1B5405695155862AB8EA9B0B (void);
// 0x0000009E System.Void UnityEngine.XR.Interaction.Toolkit.InteractionState::ResetFrameDependent()
extern void InteractionState_ResetFrameDependent_mE6F39B9BB60334F9652E917EC843F188E54F4F5F (void);
// 0x0000009F System.Boolean UnityEngine.XR.Interaction.Toolkit.InteractionState::get_deActivatedThisFrame()
extern void InteractionState_get_deActivatedThisFrame_mFD3F769CA4FC43468E7736C83142E27C96252B70 (void);
// 0x000000A0 System.Void UnityEngine.XR.Interaction.Toolkit.InteractionState::set_deActivatedThisFrame(System.Boolean)
extern void InteractionState_set_deActivatedThisFrame_m46FBAA1B24DF5B3E7C3865DBBBB500A9D3B22E6F (void);
// 0x000000A1 System.Void UnityEngine.XR.Interaction.Toolkit.InteractionState::Reset()
extern void InteractionState_Reset_m3D7F3D026CC49E00BD95858EE7AE95A0B8923B2F (void);
// 0x000000A2 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerState::.ctor(System.Double,UnityEngine.Vector3,UnityEngine.Quaternion,UnityEngine.XR.InputTrackingState)
extern void XRControllerState__ctor_mBF6971311B10D4A0D6F8EBE3FED5F51CE342469E (void);
// 0x000000A3 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerState::.ctor()
extern void XRControllerState__ctor_m807A8F212CB98DEC9EAB4A04AC25953D0A3298C6 (void);
// 0x000000A4 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerState::.ctor(UnityEngine.XR.Interaction.Toolkit.XRControllerState)
extern void XRControllerState__ctor_m55DAF7C31D41E5FE77C74DCE9F162B8FECE32535 (void);
// 0x000000A5 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerState::.ctor(System.Double,UnityEngine.Vector3,UnityEngine.Quaternion,UnityEngine.XR.InputTrackingState,System.Boolean,System.Boolean,System.Boolean)
extern void XRControllerState__ctor_mD257D8EF23D4A9C190DA834DFD6461C206D77893 (void);
// 0x000000A6 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerState::.ctor(System.Double,UnityEngine.Vector3,UnityEngine.Quaternion,UnityEngine.XR.InputTrackingState,System.Boolean,System.Boolean,System.Boolean,System.Single,System.Single,System.Single)
extern void XRControllerState__ctor_mE3A66949F7E69179EC8FE9D642E8A06C3C475F0D (void);
// 0x000000A7 System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerState::ResetFrameDependentStates()
extern void XRControllerState_ResetFrameDependentStates_m15DFF7131ACB5EF2CA0067EBEE0322C2A7594E5C (void);
// 0x000000A8 System.String UnityEngine.XR.Interaction.Toolkit.XRControllerState::ToString()
extern void XRControllerState_ToString_m994EFC44E2FDFEA49883AB914489166E2C75D103 (void);
// 0x000000A9 UnityEngine.SpatialTracking.PoseDataFlags UnityEngine.XR.Interaction.Toolkit.XRControllerState::get_poseDataFlags()
extern void XRControllerState_get_poseDataFlags_mB1583388E8CEDF58B2109D3DC1684E26FC0B2371 (void);
// 0x000000AA System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerState::set_poseDataFlags(UnityEngine.SpatialTracking.PoseDataFlags)
extern void XRControllerState_set_poseDataFlags_m52A1E2271B7F9D409501D6961A547484BBF6F916 (void);
// 0x000000AB System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerState::.ctor(System.Double,UnityEngine.Vector3,UnityEngine.Quaternion,System.Boolean,System.Boolean,System.Boolean)
extern void XRControllerState__ctor_mEC6732F822B7072790CD4DD0BFA45C1EDB966BE1 (void);
// 0x000000AC System.Void UnityEngine.XR.Interaction.Toolkit.XRControllerState::ResetInputs()
extern void XRControllerState_ResetInputs_m1F0BC0DC4AB6908D37DB1C0612334C401AB472C1 (void);
// 0x000000AD UnityEngine.XR.Interaction.Toolkit.ActivateEvent UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractable::get_activated()
// 0x000000AE UnityEngine.XR.Interaction.Toolkit.DeactivateEvent UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractable::get_deactivated()
// 0x000000AF System.Void UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractable::OnActivated(UnityEngine.XR.Interaction.Toolkit.ActivateEventArgs)
// 0x000000B0 System.Void UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractable::OnDeactivated(UnityEngine.XR.Interaction.Toolkit.DeactivateEventArgs)
// 0x000000B1 UnityEngine.XR.Interaction.Toolkit.HoverEnterEvent UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable::get_firstHoverEntered()
// 0x000000B2 UnityEngine.XR.Interaction.Toolkit.HoverExitEvent UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable::get_lastHoverExited()
// 0x000000B3 UnityEngine.XR.Interaction.Toolkit.HoverEnterEvent UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable::get_hoverEntered()
// 0x000000B4 UnityEngine.XR.Interaction.Toolkit.HoverExitEvent UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable::get_hoverExited()
// 0x000000B5 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor> UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable::get_interactorsHovering()
// 0x000000B6 System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable::get_isHovered()
// 0x000000B7 System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable::IsHoverableBy(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor)
// 0x000000B8 System.Void UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable::OnHoverEntering(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
// 0x000000B9 System.Void UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable::OnHoverEntered(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
// 0x000000BA System.Void UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable::OnHoverExiting(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
// 0x000000BB System.Void UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable::OnHoverExited(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
// 0x000000BC UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor UnityEngine.XR.Interaction.Toolkit.XRHoverInteractableExtensions::GetOldestInteractorHovering(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable)
extern void XRHoverInteractableExtensions_GetOldestInteractorHovering_m78EDB4DFD4C3FB1C7B6C2963F17FA38EB2E85BDA (void);
// 0x000000BD System.Void UnityEngine.XR.Interaction.Toolkit.IXRInteractable::add_registered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs>)
// 0x000000BE System.Void UnityEngine.XR.Interaction.Toolkit.IXRInteractable::remove_registered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs>)
// 0x000000BF System.Void UnityEngine.XR.Interaction.Toolkit.IXRInteractable::add_unregistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs>)
// 0x000000C0 System.Void UnityEngine.XR.Interaction.Toolkit.IXRInteractable::remove_unregistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs>)
// 0x000000C1 UnityEngine.XR.Interaction.Toolkit.InteractionLayerMask UnityEngine.XR.Interaction.Toolkit.IXRInteractable::get_interactionLayers()
// 0x000000C2 System.Collections.Generic.List`1<UnityEngine.Collider> UnityEngine.XR.Interaction.Toolkit.IXRInteractable::get_colliders()
// 0x000000C3 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.IXRInteractable::get_transform()
// 0x000000C4 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.IXRInteractable::GetAttachTransform(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
// 0x000000C5 System.Void UnityEngine.XR.Interaction.Toolkit.IXRInteractable::OnRegistered(UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs)
// 0x000000C6 System.Void UnityEngine.XR.Interaction.Toolkit.IXRInteractable::OnUnregistered(UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs)
// 0x000000C7 System.Void UnityEngine.XR.Interaction.Toolkit.IXRInteractable::ProcessInteractable(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
// 0x000000C8 System.Single UnityEngine.XR.Interaction.Toolkit.IXRInteractable::GetDistanceSqrToInteractor(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
// 0x000000C9 UnityEngine.XR.Interaction.Toolkit.SelectEnterEvent UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable::get_firstSelectEntered()
// 0x000000CA UnityEngine.XR.Interaction.Toolkit.SelectExitEvent UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable::get_lastSelectExited()
// 0x000000CB UnityEngine.XR.Interaction.Toolkit.SelectEnterEvent UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable::get_selectEntered()
// 0x000000CC UnityEngine.XR.Interaction.Toolkit.SelectExitEvent UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable::get_selectExited()
// 0x000000CD System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor> UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable::get_interactorsSelecting()
// 0x000000CE UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable::get_firstInteractorSelecting()
// 0x000000CF System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable::get_isSelected()
// 0x000000D0 UnityEngine.XR.Interaction.Toolkit.InteractableSelectMode UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable::get_selectMode()
// 0x000000D1 System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable::IsSelectableBy(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor)
// 0x000000D2 UnityEngine.Pose UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable::GetAttachPoseOnSelect(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor)
// 0x000000D3 UnityEngine.Pose UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable::GetLocalAttachPoseOnSelect(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor)
// 0x000000D4 System.Void UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable::OnSelectEntering(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
// 0x000000D5 System.Void UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable::OnSelectEntered(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
// 0x000000D6 System.Void UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable::OnSelectExiting(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
// 0x000000D7 System.Void UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable::OnSelectExited(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
// 0x000000D8 UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor UnityEngine.XR.Interaction.Toolkit.XRSelectInteractableExtensions::GetOldestInteractorSelecting(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRSelectInteractableExtensions_GetOldestInteractorSelecting_m0F5900227EA241C238F920E82466EBF2C58E2353 (void);
// 0x000000D9 UnityEngine.Color UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::get_tintColor()
extern void XRTintInteractableVisual_get_tintColor_m7145A02A74CA838BA4E26C27D3BD19FAFE9A97DD (void);
// 0x000000DA System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::set_tintColor(UnityEngine.Color)
extern void XRTintInteractableVisual_set_tintColor_m9176AD56D30555DEA395383ACB8E3C414E31B5B6 (void);
// 0x000000DB System.Boolean UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::get_tintOnHover()
extern void XRTintInteractableVisual_get_tintOnHover_mA5876B3A6E8C2A963DDBD277990EA2BC29C68005 (void);
// 0x000000DC System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::set_tintOnHover(System.Boolean)
extern void XRTintInteractableVisual_set_tintOnHover_m1C4F777A50BCE43EBF27E15317D136A113A310FF (void);
// 0x000000DD System.Boolean UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::get_tintOnSelection()
extern void XRTintInteractableVisual_get_tintOnSelection_m3109785F8A57BDDDB0F142DD3EA0D6175EADBCF6 (void);
// 0x000000DE System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::set_tintOnSelection(System.Boolean)
extern void XRTintInteractableVisual_set_tintOnSelection_mF5A91D7A962B054C86582BDA6DEAB386653FD26F (void);
// 0x000000DF System.Collections.Generic.List`1<UnityEngine.Renderer> UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::get_tintRenderers()
extern void XRTintInteractableVisual_get_tintRenderers_mD935957D5B0A06D2655ED25C11EF48B2C8AE1660 (void);
// 0x000000E0 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::set_tintRenderers(System.Collections.Generic.List`1<UnityEngine.Renderer>)
extern void XRTintInteractableVisual_set_tintRenderers_m344D4CC07935107654296040A65B34319A2771B7 (void);
// 0x000000E1 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::Awake()
extern void XRTintInteractableVisual_Awake_mDB09588103934C4AFDBC7B65CA067081474554C4 (void);
// 0x000000E2 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::OnDestroy()
extern void XRTintInteractableVisual_OnDestroy_m93FC361530B8D707FEC9EE4A7CFCB65823CE1354 (void);
// 0x000000E3 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::SetTint(System.Boolean)
extern void XRTintInteractableVisual_SetTint_mD984003D236126213968A3D3D12D6F512D3D7965 (void);
// 0x000000E4 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::GetEmissionEnabled()
extern void XRTintInteractableVisual_GetEmissionEnabled_mBF0C94BD63AA1FD8F49D7E62F8DDFEB9946BF060 (void);
// 0x000000E5 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::OnFirstHoverEntered(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRTintInteractableVisual_OnFirstHoverEntered_mA73FE7C7D9F0ACCD8D947D03D1198A6532B55A4E (void);
// 0x000000E6 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::OnLastHoverExited(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRTintInteractableVisual_OnLastHoverExited_mC9165137EBEE7376A08B0A52DB79E49684D67CC2 (void);
// 0x000000E7 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::OnFirstSelectEntered(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRTintInteractableVisual_OnFirstSelectEntered_mBB5A687D94FF00306D27F567BE96E3B1B0A2947F (void);
// 0x000000E8 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::OnLastSelectExited(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRTintInteractableVisual_OnLastSelectExited_mFB4CF802302907392AEF24F321617A23EC9D5464 (void);
// 0x000000E9 System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::.ctor()
extern void XRTintInteractableVisual__ctor_m8B9A445C3C83B1EA59E4DE857976EEDE5F7362B5 (void);
// 0x000000EA System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual::.cctor()
extern void XRTintInteractableVisual__cctor_mABB60E7166727237AC7B7995178BBD8233D6BB2C (void);
// 0x000000EB System.Void UnityEngine.XR.Interaction.Toolkit.XRTintInteractableVisual/ShaderPropertyLookup::.cctor()
extern void ShaderPropertyLookup__cctor_m7734229F68E5BB46CACB9D0122197FFD341A734C (void);
// 0x000000EC System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::add_registered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs>)
extern void XRBaseInteractable_add_registered_m09346541B23553255EBD6BB26163560597EA8B7E (void);
// 0x000000ED System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::remove_registered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs>)
extern void XRBaseInteractable_remove_registered_mE2FE41CD4B24E3ACD9B2F85E28CAAF6B7BEF8439 (void);
// 0x000000EE System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::add_unregistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs>)
extern void XRBaseInteractable_add_unregistered_m76DE4D9CF32C801E4C78BE10C2B5FE00969ED072 (void);
// 0x000000EF System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::remove_unregistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs>)
extern void XRBaseInteractable_remove_unregistered_mC96DEF6108477652E9EFF7D09BB8BAA69893D00D (void);
// 0x000000F0 UnityEngine.XR.Interaction.Toolkit.XRInteractionManager UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_interactionManager()
extern void XRBaseInteractable_get_interactionManager_m1BF21BCF113132237CB3D85E8DBD6DA30CE1D78E (void);
// 0x000000F1 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_interactionManager(UnityEngine.XR.Interaction.Toolkit.XRInteractionManager)
extern void XRBaseInteractable_set_interactionManager_mCCFE5F459938E450DC09E1DAFA066F225658A996 (void);
// 0x000000F2 System.Collections.Generic.List`1<UnityEngine.Collider> UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_colliders()
extern void XRBaseInteractable_get_colliders_m7E5D104638AC4B5E5C77D40094AA52B9ABEB32FB (void);
// 0x000000F3 UnityEngine.XR.Interaction.Toolkit.InteractionLayerMask UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_interactionLayers()
extern void XRBaseInteractable_get_interactionLayers_mEC1D65D0D0A1AF16FD395579E18942DB4D421363 (void);
// 0x000000F4 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_interactionLayers(UnityEngine.XR.Interaction.Toolkit.InteractionLayerMask)
extern void XRBaseInteractable_set_interactionLayers_mC6A6EAEF851239E9090EBE58388B3BB263517830 (void);
// 0x000000F5 UnityEngine.XR.Interaction.Toolkit.InteractableSelectMode UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_selectMode()
extern void XRBaseInteractable_get_selectMode_m21EADCACAC064B501A96C9CD7CAA1440B7C06B30 (void);
// 0x000000F6 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_selectMode(UnityEngine.XR.Interaction.Toolkit.InteractableSelectMode)
extern void XRBaseInteractable_set_selectMode_m44F4C7BA37A6FF9A9F46A6B8494173089CD1D132 (void);
// 0x000000F7 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_customReticle()
extern void XRBaseInteractable_get_customReticle_mA9B2BFF7868C4730592B791EC85496C34976590A (void);
// 0x000000F8 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_customReticle(UnityEngine.GameObject)
extern void XRBaseInteractable_set_customReticle_m1620568983D26FCAE38E32CD2DABF946E9DB3EF2 (void);
// 0x000000F9 UnityEngine.XR.Interaction.Toolkit.HoverEnterEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_firstHoverEntered()
extern void XRBaseInteractable_get_firstHoverEntered_m45486072B947B2E93C0F330FCB737647A168CCA3 (void);
// 0x000000FA System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_firstHoverEntered(UnityEngine.XR.Interaction.Toolkit.HoverEnterEvent)
extern void XRBaseInteractable_set_firstHoverEntered_m3EBADB826862699D8645E43A325248C2C1B431D2 (void);
// 0x000000FB UnityEngine.XR.Interaction.Toolkit.HoverExitEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_lastHoverExited()
extern void XRBaseInteractable_get_lastHoverExited_mAED97F9ECA09E7A8E2B3D380BB4FB68F64E8B7D4 (void);
// 0x000000FC System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_lastHoverExited(UnityEngine.XR.Interaction.Toolkit.HoverExitEvent)
extern void XRBaseInteractable_set_lastHoverExited_mA4F9C29CBE698E53210844755E640FFC07E4FB5F (void);
// 0x000000FD UnityEngine.XR.Interaction.Toolkit.HoverEnterEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_hoverEntered()
extern void XRBaseInteractable_get_hoverEntered_m49384274F14DF80AC8FEFC1D214B7ACD41C67FB5 (void);
// 0x000000FE System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_hoverEntered(UnityEngine.XR.Interaction.Toolkit.HoverEnterEvent)
extern void XRBaseInteractable_set_hoverEntered_m3B4406A5E1BB6A1E8A0A3613D28BDA0FE6A0B967 (void);
// 0x000000FF UnityEngine.XR.Interaction.Toolkit.HoverExitEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_hoverExited()
extern void XRBaseInteractable_get_hoverExited_m6A0E55603A368A85D086A00AEFD032A434CF6162 (void);
// 0x00000100 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_hoverExited(UnityEngine.XR.Interaction.Toolkit.HoverExitEvent)
extern void XRBaseInteractable_set_hoverExited_mF9EA4EAE648FE9D90E6C560C827F0E6038AEAF83 (void);
// 0x00000101 UnityEngine.XR.Interaction.Toolkit.SelectEnterEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_firstSelectEntered()
extern void XRBaseInteractable_get_firstSelectEntered_m8BC5CDD83B7BCC0E1F0F1ADCA3225C8170DED77D (void);
// 0x00000102 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_firstSelectEntered(UnityEngine.XR.Interaction.Toolkit.SelectEnterEvent)
extern void XRBaseInteractable_set_firstSelectEntered_m2E0ABC1E23403073B3FB8491325D6FD7851F9EDC (void);
// 0x00000103 UnityEngine.XR.Interaction.Toolkit.SelectExitEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_lastSelectExited()
extern void XRBaseInteractable_get_lastSelectExited_m513D028F328E1A7D31A7D6D2889D295553AC4504 (void);
// 0x00000104 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_lastSelectExited(UnityEngine.XR.Interaction.Toolkit.SelectExitEvent)
extern void XRBaseInteractable_set_lastSelectExited_m431E670D452B60AE0F865A6D9A8629008496A4BE (void);
// 0x00000105 UnityEngine.XR.Interaction.Toolkit.SelectEnterEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_selectEntered()
extern void XRBaseInteractable_get_selectEntered_m1E5439CAE1D95FDB7D60F14D919E739435F2C341 (void);
// 0x00000106 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_selectEntered(UnityEngine.XR.Interaction.Toolkit.SelectEnterEvent)
extern void XRBaseInteractable_set_selectEntered_m1306AE4FA060099D107FCA958522CED90E38BF00 (void);
// 0x00000107 UnityEngine.XR.Interaction.Toolkit.SelectExitEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_selectExited()
extern void XRBaseInteractable_get_selectExited_m35974CB2AD2FB38B4B093DC75D2917A1D321AFA6 (void);
// 0x00000108 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_selectExited(UnityEngine.XR.Interaction.Toolkit.SelectExitEvent)
extern void XRBaseInteractable_set_selectExited_m2DDAC89B52DCC5A862C066C035C91E7601C0FB15 (void);
// 0x00000109 UnityEngine.XR.Interaction.Toolkit.ActivateEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_activated()
extern void XRBaseInteractable_get_activated_mA303C37F9F4F7C8F5E8830DD0A60735A1FD7A71F (void);
// 0x0000010A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_activated(UnityEngine.XR.Interaction.Toolkit.ActivateEvent)
extern void XRBaseInteractable_set_activated_mD2514AF9C22F727130054BF404A8B45F86E185B8 (void);
// 0x0000010B UnityEngine.XR.Interaction.Toolkit.DeactivateEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_deactivated()
extern void XRBaseInteractable_get_deactivated_m9A80B739218EFA7D495859A22B3010D6EA5552D5 (void);
// 0x0000010C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_deactivated(UnityEngine.XR.Interaction.Toolkit.DeactivateEvent)
extern void XRBaseInteractable_set_deactivated_mC6C62FF411F15BB078D13656120B2A2ADACE11C0 (void);
// 0x0000010D System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor> UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_interactorsHovering()
extern void XRBaseInteractable_get_interactorsHovering_m59A8081C49E99C1C9D50C84BF1438EDE2B823295 (void);
// 0x0000010E System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_isHovered()
extern void XRBaseInteractable_get_isHovered_m365DB744ECBAB53AD4A489F6EBA5360DF993FB1E (void);
// 0x0000010F System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor> UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_interactorsSelecting()
extern void XRBaseInteractable_get_interactorsSelecting_m4B5A53704757881608DB333C792979DDE0EF3473 (void);
// 0x00000110 UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_firstInteractorSelecting()
extern void XRBaseInteractable_get_firstInteractorSelecting_m4DB61C389039768C7BB8B4A9C46974D7C7CEF015 (void);
// 0x00000111 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_firstInteractorSelecting(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor)
extern void XRBaseInteractable_set_firstInteractorSelecting_m63956885FE6D8E0C7788252DBDA2B59694741E76 (void);
// 0x00000112 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_isSelected()
extern void XRBaseInteractable_get_isSelected_m48487E7F2E3E1EDB6D9B6985FF146020F628B3CE (void);
// 0x00000113 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::Reset()
extern void XRBaseInteractable_Reset_m1CFAA75E8F77AB5E11B2DE07BD3969BEAA2B8A0D (void);
// 0x00000114 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::Awake()
extern void XRBaseInteractable_Awake_m0F05BB9C7C9315AD7A6FA1654A50612AFB5D8EA0 (void);
// 0x00000115 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnEnable()
extern void XRBaseInteractable_OnEnable_m7BE7345371D6ED1B91C5EC90CDF8F34CE11E3366 (void);
// 0x00000116 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnDisable()
extern void XRBaseInteractable_OnDisable_mB02958BFFAFF6C61A9FABE1D80056C3ABDCAB243 (void);
// 0x00000117 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnDestroy()
extern void XRBaseInteractable_OnDestroy_mEB434BB14A20C725528F9A1A0F04E70DED3D2B4F (void);
// 0x00000118 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::FindCreateInteractionManager()
extern void XRBaseInteractable_FindCreateInteractionManager_m7D14F62C6263BF91A05088C5A4389F3AC79A1AA7 (void);
// 0x00000119 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::RegisterWithInteractionManager()
extern void XRBaseInteractable_RegisterWithInteractionManager_m811463136B69D370F00869171BE8E55D625DA2D8 (void);
// 0x0000011A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::UnregisterWithInteractionManager()
extern void XRBaseInteractable_UnregisterWithInteractionManager_mF1741B78B8865667C57556AB492ACE8CEF13017D (void);
// 0x0000011B UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::GetAttachTransform(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
extern void XRBaseInteractable_GetAttachTransform_m49E682DC33A9B633B38300722D3A1F539B3AE8FE (void);
// 0x0000011C UnityEngine.Pose UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::GetAttachPoseOnSelect(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor)
extern void XRBaseInteractable_GetAttachPoseOnSelect_m4443BA2DC8FC267988EC9ABADC3A9EA19465CB51 (void);
// 0x0000011D UnityEngine.Pose UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::GetLocalAttachPoseOnSelect(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor)
extern void XRBaseInteractable_GetLocalAttachPoseOnSelect_mFE2982B558239FAB820826B9DD44F73B4A5AEA00 (void);
// 0x0000011E System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::GetDistanceSqrToInteractor(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
extern void XRBaseInteractable_GetDistanceSqrToInteractor_m52F94F37A4FD3F5ECB7A6CB8A10BCD0F5A7B7128 (void);
// 0x0000011F System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::IsHoverableBy(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor)
extern void XRBaseInteractable_IsHoverableBy_mA746CF4F19A39315495C004ED35EF6AF75AA8429 (void);
// 0x00000120 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::IsSelectableBy(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor)
extern void XRBaseInteractable_IsSelectableBy_mB736F5FFEBCD5B29610E94980C7E8D2B4058A9CB (void);
// 0x00000121 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::AttachCustomReticle(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
extern void XRBaseInteractable_AttachCustomReticle_m5209EEF1D09AA44CB21A97F65FD84861C6CE0719 (void);
// 0x00000122 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::RemoveCustomReticle(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
extern void XRBaseInteractable_RemoveCustomReticle_m3773C9455009E0875257C3EFA4B1578855D564B4 (void);
// 0x00000123 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::CaptureAttachPose(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor)
extern void XRBaseInteractable_CaptureAttachPose_m1E96A11AE3119F0183F1A34117A52DEB0EC12F49 (void);
// 0x00000124 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::ProcessInteractable(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRBaseInteractable_ProcessInteractable_mD5D51C6B4F6673EE9380C4EA707DA67F7CF8B0F2 (void);
// 0x00000125 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::UnityEngine.XR.Interaction.Toolkit.IXRInteractable.OnRegistered(UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs)
extern void XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRInteractable_OnRegistered_mC957784F3672267038E0CE90F5A3DCE0739DB63F (void);
// 0x00000126 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::UnityEngine.XR.Interaction.Toolkit.IXRInteractable.OnUnregistered(UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs)
extern void XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRInteractable_OnUnregistered_m317A9269A7185732331ED6205C97BC0698E1B431 (void);
// 0x00000127 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractable.OnActivated(UnityEngine.XR.Interaction.Toolkit.ActivateEventArgs)
extern void XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRActivateInteractable_OnActivated_m77041A7F42D5CBAD509C60285E84CF0B45CBA183 (void);
// 0x00000128 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractable.OnDeactivated(UnityEngine.XR.Interaction.Toolkit.DeactivateEventArgs)
extern void XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRActivateInteractable_OnDeactivated_mA6117AC7A9583AEB7E561093C734AACCE04FBC23 (void);
// 0x00000129 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable.IsHoverableBy(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor)
extern void XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRHoverInteractable_IsHoverableBy_m71F62341E08547B200BF655868174572BECE047C (void);
// 0x0000012A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable.OnHoverEntering(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRHoverInteractable_OnHoverEntering_m542D7F2636927C72158456381632E25DB7034C59 (void);
// 0x0000012B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable.OnHoverEntered(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRHoverInteractable_OnHoverEntered_m56B5D09532D66BED3EB655F7989BA3434C5D57AF (void);
// 0x0000012C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable.OnHoverExiting(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRHoverInteractable_OnHoverExiting_m8D6E79B614A6E1901D6D7C5578730501CDBAC064 (void);
// 0x0000012D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable.OnHoverExited(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRHoverInteractable_OnHoverExited_m3C98A50682BB75E4A991E6F56B7F99A07270949A (void);
// 0x0000012E System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable.IsSelectableBy(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor)
extern void XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRSelectInteractable_IsSelectableBy_m7E9ABF5FF8039EB88287F833495D86930BBA3CF3 (void);
// 0x0000012F System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable.OnSelectEntering(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRSelectInteractable_OnSelectEntering_m366007321636CDD4FA2266137A1B1F5E822717D4 (void);
// 0x00000130 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable.OnSelectEntered(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRSelectInteractable_OnSelectEntered_m02789F82FAD64B8DCBB7115AC76E5D39D75B9682 (void);
// 0x00000131 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable.OnSelectExiting(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRSelectInteractable_OnSelectExiting_mC3E2FD987AEF56E2859EFC3AAC4609D7F18ABF22 (void);
// 0x00000132 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable.OnSelectExited(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRSelectInteractable_OnSelectExited_m5CF609325B7E322A004AA92D9232C1AB9FD0F945 (void);
// 0x00000133 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnRegistered(UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs)
extern void XRBaseInteractable_OnRegistered_mA848DE6637488E5C5CBB998C7D1B7187A197081E (void);
// 0x00000134 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnUnregistered(UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs)
extern void XRBaseInteractable_OnUnregistered_m0F4657C75F7D6BD9E3503E6CB04AD4235A7C8733 (void);
// 0x00000135 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnHoverEntering(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRBaseInteractable_OnHoverEntering_m91511B5EC9D4C94BF629F4CE9C48165B919B89AD (void);
// 0x00000136 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnHoverEntered(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRBaseInteractable_OnHoverEntered_m640C05A966C7FBCFBBE06A528FD67B3E4417D8B9 (void);
// 0x00000137 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnHoverExiting(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRBaseInteractable_OnHoverExiting_m2CB16CAD51B6CE0C92C4378C9ACB5AE628B45260 (void);
// 0x00000138 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnHoverExited(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRBaseInteractable_OnHoverExited_m151F89528B26490399D2A7A3F468DD021D6DD295 (void);
// 0x00000139 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectEntering(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRBaseInteractable_OnSelectEntering_mA92C356B0CBA88075ED772C00D6D7B53FED2AA93 (void);
// 0x0000013A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectEntered(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRBaseInteractable_OnSelectEntered_m548EC86DEEF771E952DFC75BAE8EA5C27E441C5C (void);
// 0x0000013B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectExiting(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRBaseInteractable_OnSelectExiting_m4F97E28A978DC4A5B7B843CA0FDAAFA9640F72F3 (void);
// 0x0000013C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectExited(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRBaseInteractable_OnSelectExited_m0D5AEB82DE37B8584A97A262468AF59B70A5568C (void);
// 0x0000013D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnActivated(UnityEngine.XR.Interaction.Toolkit.ActivateEventArgs)
extern void XRBaseInteractable_OnActivated_mF584BF76F2FE64DB21A707C4FDBBEA7885D6524C (void);
// 0x0000013E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnDeactivated(UnityEngine.XR.Interaction.Toolkit.DeactivateEventArgs)
extern void XRBaseInteractable_OnDeactivated_m3A86068F620BFE049FCF5D0712CDC3A2819F1577 (void);
// 0x0000013F UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_interactionLayerMask()
extern void XRBaseInteractable_get_interactionLayerMask_m88A182317E350501A4A982352B416F61E4C42D71 (void);
// 0x00000140 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_interactionLayerMask(UnityEngine.LayerMask)
extern void XRBaseInteractable_set_interactionLayerMask_m9DA83A873E341FD33AF6889A7DDFD95FAE03D3D1 (void);
// 0x00000141 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onFirstHoverEntered()
extern void XRBaseInteractable_get_onFirstHoverEntered_m8BB778DBC5BEF3D02A69D508153913D7B263DAFF (void);
// 0x00000142 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onFirstHoverEntered(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onFirstHoverEntered_mBC020593B115AA187F6CF97F1997BB55FC7F6BA8 (void);
// 0x00000143 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onLastHoverExited()
extern void XRBaseInteractable_get_onLastHoverExited_m8C95DAD155571E0196F07CD6DAD18E9A3D73900A (void);
// 0x00000144 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onLastHoverExited(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onLastHoverExited_mF9ABD3DB3A133C39D0271D726EB925541D695EAA (void);
// 0x00000145 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onHoverEntered()
extern void XRBaseInteractable_get_onHoverEntered_mFF277C048C0AC263D36E6028C09BD6A096816EA5 (void);
// 0x00000146 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onHoverEntered(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onHoverEntered_m7D3FA0366F1B3063C1078D5D6CB8CCF4009FA839 (void);
// 0x00000147 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onHoverExited()
extern void XRBaseInteractable_get_onHoverExited_m7AFF158F1499360FBF4334F07FB2394CF7D0C67A (void);
// 0x00000148 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onHoverExited(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onHoverExited_m190E015CDAF3D90EDA68CC35A182D8818340B439 (void);
// 0x00000149 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onSelectEntered()
extern void XRBaseInteractable_get_onSelectEntered_m3AF1E23061186454C8CD5233921F4FC6C3780A37 (void);
// 0x0000014A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onSelectEntered(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onSelectEntered_mC6060A43303B6BED1FE9083E85BED946EB23FABE (void);
// 0x0000014B UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onSelectExited()
extern void XRBaseInteractable_get_onSelectExited_m8024BC6BA704E0465A0DA3BAE263C18CEB74F142 (void);
// 0x0000014C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onSelectExited(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onSelectExited_m792ADF3DA24E5F2E77D1B091D60DDCAF75C7A099 (void);
// 0x0000014D UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onSelectCanceled()
extern void XRBaseInteractable_get_onSelectCanceled_mEEF8B7DC54AACFDEE8592736105501B5B5DB9AE4 (void);
// 0x0000014E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onSelectCanceled(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onSelectCanceled_m06133B21C01B4B19CB4D8D8FCA893E6286152F26 (void);
// 0x0000014F UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onActivate()
extern void XRBaseInteractable_get_onActivate_m1D3C7DF34FE13FCCB1E912EFB16C418C14825CE5 (void);
// 0x00000150 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onActivate(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onActivate_m1D7B1CD39B70B34EEC637AD5EEB6368500440285 (void);
// 0x00000151 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onDeactivate()
extern void XRBaseInteractable_get_onDeactivate_m1847E4D28A1DCD913BB256DAF5E0AD7941C1519C (void);
// 0x00000152 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_onDeactivate(UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent)
extern void XRBaseInteractable_set_onDeactivate_m63B2A481DFC3B6F21F27143B978896123698AB6D (void);
// 0x00000153 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onFirstHoverEnter()
extern void XRBaseInteractable_get_onFirstHoverEnter_mA09216C44D0C76CAB339483EAAD4D02A27BED0DC (void);
// 0x00000154 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onHoverEnter()
extern void XRBaseInteractable_get_onHoverEnter_m01071D5812EA0B89F558C77BA43FAFDEB51BACD9 (void);
// 0x00000155 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onHoverExit()
extern void XRBaseInteractable_get_onHoverExit_m8F78D5AFD6F310F4E1BFE4E6C9C6C8FC01701960 (void);
// 0x00000156 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onLastHoverExit()
extern void XRBaseInteractable_get_onLastHoverExit_mCFC12B17916FCC5FF167E9A730AF3B85D66B17C1 (void);
// 0x00000157 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onSelectEnter()
extern void XRBaseInteractable_get_onSelectEnter_m1FD30C7BD9A91AD63C3645CCFD3C6DE3CFA59E99 (void);
// 0x00000158 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onSelectExit()
extern void XRBaseInteractable_get_onSelectExit_m7CE4A2E3F926261A864CEB8C565046345A687C83 (void);
// 0x00000159 UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_onSelectCancel()
extern void XRBaseInteractable_get_onSelectCancel_m21F0114EFE5248D836F9E91D72C133FF220917D8 (void);
// 0x0000015A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnHoverEntering(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnHoverEntering_mC7AE47E988E9FDE228CF21D37CBFA01B8D0D2647 (void);
// 0x0000015B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnHoverEntered(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnHoverEntered_mDEBCCB9316DD58BE33D7BE24474BE879C7874AB4 (void);
// 0x0000015C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnHoverExiting(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnHoverExiting_m50CC99BF19E96C3CAFDAB799A7A4A157899FB2F6 (void);
// 0x0000015D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnHoverExited(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnHoverExited_m9804823A7EC919D6E8AF56EA07F2C9D38A75DF1E (void);
// 0x0000015E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectEntering(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnSelectEntering_m8F7D6BCD011845DB205C19A5EF2888BC2498AD3C (void);
// 0x0000015F System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectEntered(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnSelectEntered_mFBD06824A89594F0777D691A5A62775C1F908F2D (void);
// 0x00000160 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectExiting(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnSelectExiting_m66D3F2D1F00CCA02FFD0D023BE7AD9D0CA9057AA (void);
// 0x00000161 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectExited(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnSelectExited_mE701B8C24D777780E087CBC1BA70DEA5E0C9811C (void);
// 0x00000162 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectCanceling(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnSelectCanceling_m480CD53FAD683DF9A1CAAED37DEF2C715EAA36CA (void);
// 0x00000163 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnSelectCanceled(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnSelectCanceled_m2F45D168F919DB89F4B099F769640D5950080C42 (void);
// 0x00000164 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnActivate(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnActivate_mE1DEF5C544A8DDA4CDC2F8791A2F3A45E419BF44 (void);
// 0x00000165 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::OnDeactivate(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_OnDeactivate_mB2EAE293AC23EE6D075E6FCBCA1C4C619B00459B (void);
// 0x00000166 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::GetDistanceSqrToInteractor(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_GetDistanceSqrToInteractor_m0D4E455457E95DDDB45146E260EDA9C3A56D5BEF (void);
// 0x00000167 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::AttachCustomReticle(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_AttachCustomReticle_m350001A881BA032E9D9B7D6BA5986EE59E5F1DD2 (void);
// 0x00000168 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::RemoveCustomReticle(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_RemoveCustomReticle_m332B9551BADA33D8E2BCF9A1A52F97854E30A762 (void);
// 0x00000169 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor> UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_hoveringInteractors()
extern void XRBaseInteractable_get_hoveringInteractors_mE0B8E9F9A3CFC8FE238AF4148B9B467DEA95F7C7 (void);
// 0x0000016A UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::get_selectingInteractor()
extern void XRBaseInteractable_get_selectingInteractor_mDA5536E167016B048166B2DC5061AE3F752B115A (void);
// 0x0000016B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::set_selectingInteractor(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_set_selectingInteractor_mDDD4EEC6E146FFDAAB2727A52EA9B99660665CEB (void);
// 0x0000016C System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::IsHoverableBy(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_IsHoverableBy_m7F71CC4449838B94CFC6E7C3834FA0613B0B331F (void);
// 0x0000016D System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::IsSelectableBy(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRBaseInteractable_IsSelectableBy_mB86D990CC7B0D23A8FADA53DF1DF05A2A0905B56 (void);
// 0x0000016E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::.ctor()
extern void XRBaseInteractable__ctor_m0B36974579D0C9F2799C4C5DE77B136C291247F4 (void);
// 0x0000016F UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable::UnityEngine.XR.Interaction.Toolkit.IXRInteractable.get_transform()
extern void XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRInteractable_get_transform_m6A2A880913D12F5EC5E0C9A1D2E34D3517687F44 (void);
// 0x00000170 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_attachTransform()
extern void XRGrabInteractable_get_attachTransform_m30CDBF31508E618FE793B016216943805111DA12 (void);
// 0x00000171 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_attachTransform(UnityEngine.Transform)
extern void XRGrabInteractable_set_attachTransform_mB9E32067852B3E793C78488AFF113E217D8DA148 (void);
// 0x00000172 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_attachEaseInTime()
extern void XRGrabInteractable_get_attachEaseInTime_mEC2614EA89075DA4BE757331DFAE3B022991B71C (void);
// 0x00000173 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_attachEaseInTime(System.Single)
extern void XRGrabInteractable_set_attachEaseInTime_mBF3660E565944E6282C82A0E37E5735294A7A122 (void);
// 0x00000174 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable/MovementType UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_movementType()
extern void XRGrabInteractable_get_movementType_m5BEBCC2DE7D252FF0829FA0213B9F615A06B3CD8 (void);
// 0x00000175 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_movementType(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable/MovementType)
extern void XRGrabInteractable_set_movementType_m2F7742535D1427EAAFF3B18C3AA2871B730C07FC (void);
// 0x00000176 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_velocityDamping()
extern void XRGrabInteractable_get_velocityDamping_mE46219AFCC01851337A04ED9D87ECE992E059A86 (void);
// 0x00000177 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_velocityDamping(System.Single)
extern void XRGrabInteractable_set_velocityDamping_m08C1E8BC409C1333A2CED17BAAEFED45A64044E5 (void);
// 0x00000178 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_velocityScale()
extern void XRGrabInteractable_get_velocityScale_m788546BF2A3482AF4416A827F713058344B58A13 (void);
// 0x00000179 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_velocityScale(System.Single)
extern void XRGrabInteractable_set_velocityScale_m948FA5A69546C471440956A464E6AC3808A6AC0E (void);
// 0x0000017A System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_angularVelocityDamping()
extern void XRGrabInteractable_get_angularVelocityDamping_m6F0E8F58F03E925D9C40AD45FB6B5F3BAF8B6D27 (void);
// 0x0000017B System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_angularVelocityDamping(System.Single)
extern void XRGrabInteractable_set_angularVelocityDamping_mE759FB87B43922C160ED2F6C753BD42CDE2C1D54 (void);
// 0x0000017C System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_angularVelocityScale()
extern void XRGrabInteractable_get_angularVelocityScale_m5F0D67D74CD6D8CAC7BF4A168C478B48E4E7E0F3 (void);
// 0x0000017D System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_angularVelocityScale(System.Single)
extern void XRGrabInteractable_set_angularVelocityScale_m8B15F58CD5A6869542CFFE7BD213E5C0F26D6D7F (void);
// 0x0000017E System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_trackPosition()
extern void XRGrabInteractable_get_trackPosition_mAAD71450024A7E9E1DE556E266078694D60FB192 (void);
// 0x0000017F System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_trackPosition(System.Boolean)
extern void XRGrabInteractable_set_trackPosition_m53B90FBE1263F72AAEBCF8EB68757B696647124B (void);
// 0x00000180 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_smoothPosition()
extern void XRGrabInteractable_get_smoothPosition_mA778146AB6B8BD121D8110E96FEBCC4EE24BB7CF (void);
// 0x00000181 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_smoothPosition(System.Boolean)
extern void XRGrabInteractable_set_smoothPosition_m57E1B2429E52B0F1A64E9133A3B01EE68761EFA5 (void);
// 0x00000182 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_smoothPositionAmount()
extern void XRGrabInteractable_get_smoothPositionAmount_m8FD0547FE5BA607EADD209476A80D0976D122912 (void);
// 0x00000183 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_smoothPositionAmount(System.Single)
extern void XRGrabInteractable_set_smoothPositionAmount_mA4027D3BE5609C429F404DEFCDF6F0B06F917289 (void);
// 0x00000184 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_tightenPosition()
extern void XRGrabInteractable_get_tightenPosition_mAEBB39CB11C030CC4FCFF5E8765A382508B07852 (void);
// 0x00000185 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_tightenPosition(System.Single)
extern void XRGrabInteractable_set_tightenPosition_mAABADE03ED7294B614068F11599066287EDE6DB2 (void);
// 0x00000186 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_trackRotation()
extern void XRGrabInteractable_get_trackRotation_m60327C0792A4F7BCD7283BBF3D0EEE053A5DEF34 (void);
// 0x00000187 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_trackRotation(System.Boolean)
extern void XRGrabInteractable_set_trackRotation_m627BD2250CB0C69A40C506C66A253C8070B70590 (void);
// 0x00000188 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_smoothRotation()
extern void XRGrabInteractable_get_smoothRotation_mECC92250F9BD027AA23154241C8062012A908A51 (void);
// 0x00000189 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_smoothRotation(System.Boolean)
extern void XRGrabInteractable_set_smoothRotation_mD20170A4C093858570941B43FB85E48A2F833A2A (void);
// 0x0000018A System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_smoothRotationAmount()
extern void XRGrabInteractable_get_smoothRotationAmount_m3FE8A7855076EB44F8906E3D3412717600446EEB (void);
// 0x0000018B System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_smoothRotationAmount(System.Single)
extern void XRGrabInteractable_set_smoothRotationAmount_m4DA12E0C6AF5665EDBAB8D09C83B6751D9543C2F (void);
// 0x0000018C System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_tightenRotation()
extern void XRGrabInteractable_get_tightenRotation_m0D5412A278006818760D40E18FE69EB43D2B64C5 (void);
// 0x0000018D System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_tightenRotation(System.Single)
extern void XRGrabInteractable_set_tightenRotation_m70C50B7C7F323EA9DD3317C323CEE04569D1D41D (void);
// 0x0000018E System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_throwOnDetach()
extern void XRGrabInteractable_get_throwOnDetach_mD4EA5FEF8B8C3D95111703FCA580153A9A2557A7 (void);
// 0x0000018F System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_throwOnDetach(System.Boolean)
extern void XRGrabInteractable_set_throwOnDetach_m555DCA298C7DC53FBA4AE199AECDE27483B1630A (void);
// 0x00000190 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_throwSmoothingDuration()
extern void XRGrabInteractable_get_throwSmoothingDuration_mB4D0AAA91F0945294AF817EC515F498B997C1DE6 (void);
// 0x00000191 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_throwSmoothingDuration(System.Single)
extern void XRGrabInteractable_set_throwSmoothingDuration_m140C2316786CAAC8B30DC82261A384A1DAAB4419 (void);
// 0x00000192 UnityEngine.AnimationCurve UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_throwSmoothingCurve()
extern void XRGrabInteractable_get_throwSmoothingCurve_mD38081AF8BD606F87FC0C854A78DEE6DB1AF83AF (void);
// 0x00000193 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_throwSmoothingCurve(UnityEngine.AnimationCurve)
extern void XRGrabInteractable_set_throwSmoothingCurve_m1CAE7417FA52E9601B515D3275A6AE446ED4085B (void);
// 0x00000194 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_throwVelocityScale()
extern void XRGrabInteractable_get_throwVelocityScale_mD00F6AD657B58D3174CB2173F15540D321E736BE (void);
// 0x00000195 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_throwVelocityScale(System.Single)
extern void XRGrabInteractable_set_throwVelocityScale_m9181485F86E64F8EEAFA281024F08AC050ABD37D (void);
// 0x00000196 System.Single UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_throwAngularVelocityScale()
extern void XRGrabInteractable_get_throwAngularVelocityScale_mD2CB0703E07A5B03B6733F29780CFF96E02CEB56 (void);
// 0x00000197 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_throwAngularVelocityScale(System.Single)
extern void XRGrabInteractable_set_throwAngularVelocityScale_m56068620501DAA582DFE9B9A88370F78C4A54895 (void);
// 0x00000198 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_forceGravityOnDetach()
extern void XRGrabInteractable_get_forceGravityOnDetach_m3FFD2461924750484E894E5C0813BDE0D6BCB19C (void);
// 0x00000199 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_forceGravityOnDetach(System.Boolean)
extern void XRGrabInteractable_set_forceGravityOnDetach_m65EA1CF74E61CA70088E884C4CA8460D1C8B9D68 (void);
// 0x0000019A System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_retainTransformParent()
extern void XRGrabInteractable_get_retainTransformParent_mC1801D384D9CEFA8B04F692D8D5A772C55309238 (void);
// 0x0000019B System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_retainTransformParent(System.Boolean)
extern void XRGrabInteractable_set_retainTransformParent_m7E0FE171CA7C1D127C848A84183E9EA85F548579 (void);
// 0x0000019C UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable/AttachPointCompatibilityMode UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_attachPointCompatibilityMode()
extern void XRGrabInteractable_get_attachPointCompatibilityMode_m5AB593A3EEA6EBA3C0C88FA93B43D7F5A230CF82 (void);
// 0x0000019D System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_attachPointCompatibilityMode(UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable/AttachPointCompatibilityMode)
extern void XRGrabInteractable_set_attachPointCompatibilityMode_mED5BBBDE2845C3F6E9F561CECE0E6147A5A7E7E5 (void);
// 0x0000019E System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::Awake()
extern void XRGrabInteractable_Awake_m891664C7C2647A8A7CE5DE52F137573CD8F708C8 (void);
// 0x0000019F System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::ProcessInteractable(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRGrabInteractable_ProcessInteractable_m65B864C1FB5251D0A7AD42154BEF07ED41CB5A2E (void);
// 0x000001A0 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::GetAttachTransform(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
extern void XRGrabInteractable_GetAttachTransform_m5370DCC9CA70440E39B0D76A60E0AD15E1ED6A10 (void);
// 0x000001A1 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::GetWorldAttachPosition(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
extern void XRGrabInteractable_GetWorldAttachPosition_m58476328ACE5B1C72B0B436F4EC8CFE340742BCC (void);
// 0x000001A2 UnityEngine.Quaternion UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::GetWorldAttachRotation(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
extern void XRGrabInteractable_GetWorldAttachRotation_m99C8927648DF18E004950AB2CEE0FB9E09B2254E (void);
// 0x000001A3 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::UpdateTarget(UnityEngine.XR.Interaction.Toolkit.IXRInteractor,System.Single)
extern void XRGrabInteractable_UpdateTarget_m50F47D017722FDA5D89B9E766EFA0BF48E44800B (void);
// 0x000001A4 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::PerformInstantaneousUpdate(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRGrabInteractable_PerformInstantaneousUpdate_m3E31C1D2DFA918157194820C45B66B868C67838D (void);
// 0x000001A5 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::PerformKinematicUpdate(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRGrabInteractable_PerformKinematicUpdate_mC6BE984E8D18107E077BD78F5E50371A2D888FFE (void);
// 0x000001A6 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::PerformVelocityTrackingUpdate(System.Single,UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRGrabInteractable_PerformVelocityTrackingUpdate_m2CFE4053D531708CD3596A05964D83726198A699 (void);
// 0x000001A7 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::UpdateInteractorLocalPose(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
extern void XRGrabInteractable_UpdateInteractorLocalPose_mD06AE482BE26FBE58CB58E234653650F6B8647F9 (void);
// 0x000001A8 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::UpdateInteractorLocalPoseLegacy(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
extern void XRGrabInteractable_UpdateInteractorLocalPoseLegacy_mF76A525301DFE4E43DC5C657663E8D06B72DE38C (void);
// 0x000001A9 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::UpdateCurrentMovementType()
extern void XRGrabInteractable_UpdateCurrentMovementType_m97D4A5723DEFAAB9CA9B4B87852C61F770CF7C41 (void);
// 0x000001AA System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::OnSelectEntering(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRGrabInteractable_OnSelectEntering_m61F7528D64DC4008194F74434CCBB07118F65230 (void);
// 0x000001AB System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::OnSelectExiting(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRGrabInteractable_OnSelectExiting_mF52B6F4DD6BAC23E34610E8394768B08510F7A65 (void);
// 0x000001AC System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::Grab()
extern void XRGrabInteractable_Grab_m3C68C5A2882F938DE4B3C62B6B97EDFBA45D8A42 (void);
// 0x000001AD System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::Drop()
extern void XRGrabInteractable_Drop_mE90A72FE9E8B6307A9BA5F41D4A7449689D7F070 (void);
// 0x000001AE System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::Detach()
extern void XRGrabInteractable_Detach_m17458B5384D1105B5755C5532A3C61DC157FC1E4 (void);
// 0x000001AF System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::SetupRigidbodyGrab(UnityEngine.Rigidbody)
extern void XRGrabInteractable_SetupRigidbodyGrab_m2884D7EA52F22582579C52C0215508352F56A5EB (void);
// 0x000001B0 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::SetupRigidbodyDrop(UnityEngine.Rigidbody)
extern void XRGrabInteractable_SetupRigidbodyDrop_mDBFA76F417BE6263209BC1674E9AAD1AE7F8E18A (void);
// 0x000001B1 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::SmoothVelocityStart(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
extern void XRGrabInteractable_SmoothVelocityStart_mCE0F6FDC648B61FDD3AE901034CFA97F63711CFF (void);
// 0x000001B2 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::SmoothVelocityEnd()
extern void XRGrabInteractable_SmoothVelocityEnd_mC8629B7FB83D124BE434ED9BC3B4ECEF21D7A634 (void);
// 0x000001B3 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::SmoothVelocityUpdate(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
extern void XRGrabInteractable_SmoothVelocityUpdate_mA1B2C1123B5893B84AA3BA15CF257DEA49A3230B (void);
// 0x000001B4 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::GetSmoothedVelocityValue(UnityEngine.Vector3[])
extern void XRGrabInteractable_GetSmoothedVelocityValue_m08790F7834347E5567A1627A61BDDC44371D8B79 (void);
// 0x000001B5 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::OnBeginTeleportation(UnityEngine.XR.Interaction.Toolkit.LocomotionSystem)
extern void XRGrabInteractable_OnBeginTeleportation_m7F32F8600E5C4E7317678E06AD051A696716AF29 (void);
// 0x000001B6 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::OnEndTeleportation(UnityEngine.XR.Interaction.Toolkit.LocomotionSystem)
extern void XRGrabInteractable_OnEndTeleportation_mE0B5FBF6F683CAF439009618A1ED794BBFC2C40B (void);
// 0x000001B7 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::SetTeleportationProvider(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
extern void XRGrabInteractable_SetTeleportationProvider_m4AF65996EAD55190DCCD0F72DEC974FE2D45DC0C (void);
// 0x000001B8 System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::ClearTeleportationProvider()
extern void XRGrabInteractable_ClearTeleportationProvider_m03849DF083EF6A4C10826CF61808EB7DF3015F1E (void);
// 0x000001B9 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::get_gravityOnDetach()
extern void XRGrabInteractable_get_gravityOnDetach_m53B8CC5440249181806F01AC0008B4BDC629D564 (void);
// 0x000001BA System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::set_gravityOnDetach(System.Boolean)
extern void XRGrabInteractable_set_gravityOnDetach_m5E8D301416F2D440EF9685A6EB1A166C5B528DCD (void);
// 0x000001BB System.Void UnityEngine.XR.Interaction.Toolkit.XRGrabInteractable::.ctor()
extern void XRGrabInteractable__ctor_mF1FA77294880EFA9C7C840025B207B80327B5E2E (void);
// 0x000001BC System.Void UnityEngine.XR.Interaction.Toolkit.XRSimpleInteractable::.ctor()
extern void XRSimpleInteractable__ctor_m8AC8AD7F6792CC5A7A7D7FB4F78FF415C3EBE412 (void);
// 0x000001BD System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractor::get_shouldActivate()
// 0x000001BE System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractor::get_shouldDeactivate()
// 0x000001BF System.Void UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractor::GetActivateTargets(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractable>)
// 0x000001C0 UnityEngine.XR.Interaction.Toolkit.HoverEnterEvent UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor::get_hoverEntered()
// 0x000001C1 UnityEngine.XR.Interaction.Toolkit.HoverExitEvent UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor::get_hoverExited()
// 0x000001C2 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable> UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor::get_interactablesHovered()
// 0x000001C3 System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor::get_hasHover()
// 0x000001C4 System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor::get_isHoverActive()
// 0x000001C5 System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor::CanHover(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable)
// 0x000001C6 System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor::IsHovering(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable)
// 0x000001C7 System.Void UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor::OnHoverEntering(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
// 0x000001C8 System.Void UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor::OnHoverEntered(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
// 0x000001C9 System.Void UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor::OnHoverExiting(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
// 0x000001CA System.Void UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor::OnHoverExited(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
// 0x000001CB UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable UnityEngine.XR.Interaction.Toolkit.XRHoverInteractorExtensions::GetOldestInteractableHovered(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor)
extern void XRHoverInteractorExtensions_GetOldestInteractableHovered_m0011D51EF6150DDF195BCF11A461CA7C7E36AC95 (void);
// 0x000001CC System.Void UnityEngine.XR.Interaction.Toolkit.IXRInteractor::add_registered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs>)
// 0x000001CD System.Void UnityEngine.XR.Interaction.Toolkit.IXRInteractor::remove_registered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs>)
// 0x000001CE System.Void UnityEngine.XR.Interaction.Toolkit.IXRInteractor::add_unregistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs>)
// 0x000001CF System.Void UnityEngine.XR.Interaction.Toolkit.IXRInteractor::remove_unregistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs>)
// 0x000001D0 UnityEngine.XR.Interaction.Toolkit.InteractionLayerMask UnityEngine.XR.Interaction.Toolkit.IXRInteractor::get_interactionLayers()
// 0x000001D1 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.IXRInteractor::get_transform()
// 0x000001D2 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.IXRInteractor::GetAttachTransform(UnityEngine.XR.Interaction.Toolkit.IXRInteractable)
// 0x000001D3 System.Void UnityEngine.XR.Interaction.Toolkit.IXRInteractor::GetValidTargets(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>)
// 0x000001D4 System.Void UnityEngine.XR.Interaction.Toolkit.IXRInteractor::OnRegistered(UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs)
// 0x000001D5 System.Void UnityEngine.XR.Interaction.Toolkit.IXRInteractor::OnUnregistered(UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs)
// 0x000001D6 System.Void UnityEngine.XR.Interaction.Toolkit.IXRInteractor::PreprocessInteractor(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
// 0x000001D7 System.Void UnityEngine.XR.Interaction.Toolkit.IXRInteractor::ProcessInteractor(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
// 0x000001D8 UnityEngine.XR.Interaction.Toolkit.SelectEnterEvent UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor::get_selectEntered()
// 0x000001D9 UnityEngine.XR.Interaction.Toolkit.SelectExitEvent UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor::get_selectExited()
// 0x000001DA System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable> UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor::get_interactablesSelected()
// 0x000001DB UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor::get_firstInteractableSelected()
// 0x000001DC System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor::get_hasSelection()
// 0x000001DD System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor::get_isSelectActive()
// 0x000001DE System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor::get_keepSelectedTargetValid()
// 0x000001DF System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor::CanSelect(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
// 0x000001E0 System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor::IsSelecting(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
// 0x000001E1 UnityEngine.Pose UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor::GetAttachPoseOnSelect(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
// 0x000001E2 UnityEngine.Pose UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor::GetLocalAttachPoseOnSelect(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
// 0x000001E3 System.Void UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor::OnSelectEntering(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
// 0x000001E4 System.Void UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor::OnSelectEntered(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
// 0x000001E5 System.Void UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor::OnSelectExiting(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
// 0x000001E6 System.Void UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor::OnSelectExited(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
// 0x000001E7 UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable UnityEngine.XR.Interaction.Toolkit.XRSelectInteractorExtensions::GetOldestInteractableSelected(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor)
extern void XRSelectInteractorExtensions_GetOldestInteractableSelected_mF66A05C14A9DE3239C35811C64B45F948027C1BB (void);
// 0x000001E8 System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRCustomReticleProvider::AttachCustomReticle(UnityEngine.GameObject)
// 0x000001E9 System.Boolean UnityEngine.XR.Interaction.Toolkit.IXRCustomReticleProvider::RemoveCustomReticle()
// 0x000001EA System.Boolean UnityEngine.XR.Interaction.Toolkit.ILineRenderable::GetLinePoints(UnityEngine.Vector3[]&,System.Int32&)
// 0x000001EB System.Boolean UnityEngine.XR.Interaction.Toolkit.ILineRenderable::TryGetHitInfo(UnityEngine.Vector3&,UnityEngine.Vector3&,System.Int32&,System.Boolean&)
// 0x000001EC System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_lineWidth()
extern void XRInteractorLineVisual_get_lineWidth_mC66DEB8990FD9B4CF139D780AD8A34DF24073006 (void);
// 0x000001ED System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_lineWidth(System.Single)
extern void XRInteractorLineVisual_set_lineWidth_mC8C31FBE1FE050131E9792159DD896C8D3A52EEA (void);
// 0x000001EE System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_overrideInteractorLineLength()
extern void XRInteractorLineVisual_get_overrideInteractorLineLength_m8FD4941CD7331917A96A976DDB88F41C2DDE6110 (void);
// 0x000001EF System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_overrideInteractorLineLength(System.Boolean)
extern void XRInteractorLineVisual_set_overrideInteractorLineLength_mF10463355C64CBC15A9C7E5270BC5E95D622BED4 (void);
// 0x000001F0 System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_lineLength()
extern void XRInteractorLineVisual_get_lineLength_mF289A3460D8301793BEF729484143404F75A7D86 (void);
// 0x000001F1 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_lineLength(System.Single)
extern void XRInteractorLineVisual_set_lineLength_mE0287680765071A6C6CACF55CC00C788F15227A4 (void);
// 0x000001F2 UnityEngine.AnimationCurve UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_widthCurve()
extern void XRInteractorLineVisual_get_widthCurve_m52EEDF8BF50C0A203FC3516E0B3470D84F7A8EE1 (void);
// 0x000001F3 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_widthCurve(UnityEngine.AnimationCurve)
extern void XRInteractorLineVisual_set_widthCurve_m9205EE7C93071DF058F8295E9ADE28B6C09303EF (void);
// 0x000001F4 UnityEngine.Gradient UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_validColorGradient()
extern void XRInteractorLineVisual_get_validColorGradient_m9434069D6C9A901BF72B9D69FCCE4A2C64CD1773 (void);
// 0x000001F5 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_validColorGradient(UnityEngine.Gradient)
extern void XRInteractorLineVisual_set_validColorGradient_m415ED2CD0EAAA98AC12DD33CB94585431BF8C33E (void);
// 0x000001F6 UnityEngine.Gradient UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_invalidColorGradient()
extern void XRInteractorLineVisual_get_invalidColorGradient_m6ED840748037F2F909CDC705494911A4B9018065 (void);
// 0x000001F7 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_invalidColorGradient(UnityEngine.Gradient)
extern void XRInteractorLineVisual_set_invalidColorGradient_mC9811AD5025321389532F87AB6D2DB290CE7C8CC (void);
// 0x000001F8 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_smoothMovement()
extern void XRInteractorLineVisual_get_smoothMovement_m44CC8A971593A3C530E455EFD934747263A19EDC (void);
// 0x000001F9 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_smoothMovement(System.Boolean)
extern void XRInteractorLineVisual_set_smoothMovement_m3210C5D1C1D8844E4FFA068C02DC906B2AB9AB1D (void);
// 0x000001FA System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_followTightness()
extern void XRInteractorLineVisual_get_followTightness_mF291BEE16CB0E85D2C2B166A0A642C56559F9E68 (void);
// 0x000001FB System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_followTightness(System.Single)
extern void XRInteractorLineVisual_set_followTightness_m09DA58E8B8C498C829A8717A2C74745F9C554934 (void);
// 0x000001FC System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_snapThresholdDistance()
extern void XRInteractorLineVisual_get_snapThresholdDistance_mB8B92692CA9B7BD325B92D0CF6815F99ED086E7E (void);
// 0x000001FD System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_snapThresholdDistance(System.Single)
extern void XRInteractorLineVisual_set_snapThresholdDistance_mB08404B9F3F837F682EA6D98FCFA394F91E1843D (void);
// 0x000001FE UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_reticle()
extern void XRInteractorLineVisual_get_reticle_m57552D0FBC2DBD6E01F7AD606089AA22A23692CE (void);
// 0x000001FF System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_reticle(UnityEngine.GameObject)
extern void XRInteractorLineVisual_set_reticle_mC92C09611BD59AED2A6C2AF4EDAF652FBC49C5FA (void);
// 0x00000200 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::get_stopLineAtFirstRaycastHit()
extern void XRInteractorLineVisual_get_stopLineAtFirstRaycastHit_m15AFD0CA4A48A925A8E06BDBB29D2AC2A684D748 (void);
// 0x00000201 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::set_stopLineAtFirstRaycastHit(System.Boolean)
extern void XRInteractorLineVisual_set_stopLineAtFirstRaycastHit_m53BA2377E3DB8165FE607FEB7136247C9959A8E8 (void);
// 0x00000202 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::Reset()
extern void XRInteractorLineVisual_Reset_mA291A2E1BED3CA4495D2A929C005F1A38D178D90 (void);
// 0x00000203 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::OnValidate()
extern void XRInteractorLineVisual_OnValidate_m5519F1A09A4153A774D16C58182336690020869C (void);
// 0x00000204 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::Awake()
extern void XRInteractorLineVisual_Awake_m77305D94E957AD6CF69A7BC730B4F92DC3CFB517 (void);
// 0x00000205 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::OnEnable()
extern void XRInteractorLineVisual_OnEnable_m5D548C8CA44E0E0B7AE1132C742DE744CF400D68 (void);
// 0x00000206 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::OnDisable()
extern void XRInteractorLineVisual_OnDisable_mCBCB4335BC723A056EECFC3D19A558E607ECE039 (void);
// 0x00000207 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::ClearLineRenderer()
extern void XRInteractorLineVisual_ClearLineRenderer_m242175B37ABB851CD251CC210D76E9E08AB9C193 (void);
// 0x00000208 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::OnBeforeRenderLineVisual()
extern void XRInteractorLineVisual_OnBeforeRenderLineVisual_mA41C9082D06B12685562CCE56869BE4A96047EAD (void);
// 0x00000209 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::UpdateLineVisual()
extern void XRInteractorLineVisual_UpdateLineVisual_mC96D44DF8210C4DA7798E624D7C66E8AC5B92DAB (void);
// 0x0000020A System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::UpdateSettings()
extern void XRInteractorLineVisual_UpdateSettings_m10E249F2316A569DBC57D4C08031E8F69669B366 (void);
// 0x0000020B System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::TryFindLineRenderer()
extern void XRInteractorLineVisual_TryFindLineRenderer_m2D0483568BBD97EA9AFC9B7929D125DADA198996 (void);
// 0x0000020C System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::AttachCustomReticle(UnityEngine.GameObject)
extern void XRInteractorLineVisual_AttachCustomReticle_m8DFF54A19EFBFD619DDA97203AEC5600B40627D7 (void);
// 0x0000020D System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::RemoveCustomReticle()
extern void XRInteractorLineVisual_RemoveCustomReticle_m7CFD61BE14E5772CD3C4A412DE448759207805BF (void);
// 0x0000020E System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorLineVisual::.ctor()
extern void XRInteractorLineVisual__ctor_m3CECB46C4CF6AC1348F592782FCE02796FD3E6BD (void);
// 0x0000020F System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_maxRaycastDistance()
extern void XRInteractorReticleVisual_get_maxRaycastDistance_m0FD2FEFC00DA86D8705DF03E73E096C98F8DD058 (void);
// 0x00000210 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_maxRaycastDistance(System.Single)
extern void XRInteractorReticleVisual_set_maxRaycastDistance_mA1FBCA332ED7360D1734F395ECFB90B2256583E4 (void);
// 0x00000211 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_reticlePrefab()
extern void XRInteractorReticleVisual_get_reticlePrefab_mBB69BAB72702482A8AC57BD25E116C431A3C4C5A (void);
// 0x00000212 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_reticlePrefab(UnityEngine.GameObject)
extern void XRInteractorReticleVisual_set_reticlePrefab_m2BD3DB77D1EF17C12BD3D6D28409C985286918A3 (void);
// 0x00000213 System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_prefabScalingFactor()
extern void XRInteractorReticleVisual_get_prefabScalingFactor_mB4A095DDFBA3D749250B79569C42AD3C10577866 (void);
// 0x00000214 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_prefabScalingFactor(System.Single)
extern void XRInteractorReticleVisual_set_prefabScalingFactor_mF74606716AE1299FAFA92079E80D5197B645BC09 (void);
// 0x00000215 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_undoDistanceScaling()
extern void XRInteractorReticleVisual_get_undoDistanceScaling_m450794F3C5F483111F630A22F930FFDAF8DF5B89 (void);
// 0x00000216 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_undoDistanceScaling(System.Boolean)
extern void XRInteractorReticleVisual_set_undoDistanceScaling_m7422EBDE0C8DD4445A1521525B788225E4AC524E (void);
// 0x00000217 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_alignPrefabWithSurfaceNormal()
extern void XRInteractorReticleVisual_get_alignPrefabWithSurfaceNormal_mEEC5EAE1BF7EB9CD093B4415A65343E3FB834062 (void);
// 0x00000218 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_alignPrefabWithSurfaceNormal(System.Boolean)
extern void XRInteractorReticleVisual_set_alignPrefabWithSurfaceNormal_m09059A5FFB442A0F4A701739CCF357B8A262AA83 (void);
// 0x00000219 System.Single UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_endpointSmoothingTime()
extern void XRInteractorReticleVisual_get_endpointSmoothingTime_m8779A5AB66B68F55F8194389C925F560DE8BC238 (void);
// 0x0000021A System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_endpointSmoothingTime(System.Single)
extern void XRInteractorReticleVisual_set_endpointSmoothingTime_m781E3AB98270AF8B7D42BDFE4A6F23B57AEB4E85 (void);
// 0x0000021B System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_drawWhileSelecting()
extern void XRInteractorReticleVisual_get_drawWhileSelecting_mBACBD95DF4DE19EA9A3D8978BF4D95BB80172A02 (void);
// 0x0000021C System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_drawWhileSelecting(System.Boolean)
extern void XRInteractorReticleVisual_set_drawWhileSelecting_m7B84B25405BF25A2C77397FCF1F996FB469D4BD8 (void);
// 0x0000021D UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_raycastMask()
extern void XRInteractorReticleVisual_get_raycastMask_m8A22B285C9A9CBAEB134E219FE1683A8DFFD265C (void);
// 0x0000021E System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_raycastMask(UnityEngine.LayerMask)
extern void XRInteractorReticleVisual_set_raycastMask_m51DCD3AD0249E5E2BDF29CA73E8F3A2BE2D630ED (void);
// 0x0000021F System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::get_reticleActive()
extern void XRInteractorReticleVisual_get_reticleActive_m7FF0E330C5E1795C6FB323708A57E4923B1C3ED4 (void);
// 0x00000220 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::set_reticleActive(System.Boolean)
extern void XRInteractorReticleVisual_set_reticleActive_m9AEE679F93F9047FAFA1636B67A6B440F9540120 (void);
// 0x00000221 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::Awake()
extern void XRInteractorReticleVisual_Awake_m620E8256EF9B9B4B09390D28D28D3C8B4FE5CC5F (void);
// 0x00000222 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::Update()
extern void XRInteractorReticleVisual_Update_m9D4213458FF15F09611139B92EA47EB5BA330E9F (void);
// 0x00000223 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::OnDestroy()
extern void XRInteractorReticleVisual_OnDestroy_mFF1FE79C0D5AE2CF54460A0802F7856D297DBAE6 (void);
// 0x00000224 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::SetupReticlePrefab()
extern void XRInteractorReticleVisual_SetupReticlePrefab_m26AA753B23AC0A8C795B7A94A73DFF24505CFCA0 (void);
// 0x00000225 UnityEngine.RaycastHit UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::FindClosestHit(UnityEngine.RaycastHit[],System.Int32)
extern void XRInteractorReticleVisual_FindClosestHit_m356DB666879D2014B1D186186BCD457E88AD9A0F (void);
// 0x00000226 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::TryGetRaycastPoint(UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void XRInteractorReticleVisual_TryGetRaycastPoint_mECBDD69BC9BBC77A819B785FE2F3BC8CDDE88BD6 (void);
// 0x00000227 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::UpdateReticleTarget()
extern void XRInteractorReticleVisual_UpdateReticleTarget_mB09856FE0B6930BFAA966A3CE60216B878ABCC1C (void);
// 0x00000228 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::ActivateReticleAtTarget()
extern void XRInteractorReticleVisual_ActivateReticleAtTarget_m18AB75BF534986A02656F869C547CFA417C60B38 (void);
// 0x00000229 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::OnSelectEntered(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRInteractorReticleVisual_OnSelectEntered_m11BE97991A944F1054E59CB0053DF6CBE271E876 (void);
// 0x0000022A System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorReticleVisual::.ctor()
extern void XRInteractorReticleVisual__ctor_m23E64B7C8027F35967D8B9ACF59D0F4241E1A5D1 (void);
// 0x0000022B UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor/InputTriggerType UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_selectActionTrigger()
extern void XRBaseControllerInteractor_get_selectActionTrigger_mCB494C7BA0CBE50A36F058E35AA3AC521C9D2010 (void);
// 0x0000022C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_selectActionTrigger(UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor/InputTriggerType)
extern void XRBaseControllerInteractor_set_selectActionTrigger_mED28C90236E93293019D4F9132AA5C3447861A88 (void);
// 0x0000022D System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hideControllerOnSelect()
extern void XRBaseControllerInteractor_get_hideControllerOnSelect_mCB86A19F5DE0AC8188C31E241C9C64929FBE55DB (void);
// 0x0000022E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hideControllerOnSelect(System.Boolean)
extern void XRBaseControllerInteractor_set_hideControllerOnSelect_mDD43C12E034AAEBCFA01E370A2C76B102B4FDEA5 (void);
// 0x0000022F System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_allowHoveredActivate()
extern void XRBaseControllerInteractor_get_allowHoveredActivate_m7604FF7BA4C2AEA53DA917D94ACDE4FEE3413254 (void);
// 0x00000230 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_allowHoveredActivate(System.Boolean)
extern void XRBaseControllerInteractor_set_allowHoveredActivate_m132E0D5D79F38485EABB97AA1ABF6F556F4878DC (void);
// 0x00000231 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnSelectEntered()
extern void XRBaseControllerInteractor_get_playAudioClipOnSelectEntered_mA25EB8261F66A5B079F07F645221E8B3FE5D4222 (void);
// 0x00000232 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playAudioClipOnSelectEntered(System.Boolean)
extern void XRBaseControllerInteractor_set_playAudioClipOnSelectEntered_m4760D4496FA93D12EEAE3422AC0261EDA9670CCC (void);
// 0x00000233 UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_audioClipForOnSelectEntered()
extern void XRBaseControllerInteractor_get_audioClipForOnSelectEntered_m9A0E4824ADDE03866B16524FC3D340870FD775AD (void);
// 0x00000234 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_audioClipForOnSelectEntered(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_audioClipForOnSelectEntered_mEECB50AAC1E0AB695CFF9DA8F0BD892CDD40097C (void);
// 0x00000235 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnSelectExited()
extern void XRBaseControllerInteractor_get_playAudioClipOnSelectExited_m8978833C86F99CE7FCA7139CAB2545D180AF2D2A (void);
// 0x00000236 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playAudioClipOnSelectExited(System.Boolean)
extern void XRBaseControllerInteractor_set_playAudioClipOnSelectExited_mE581F3D4F87EC98324A80BFFC1E525288A3FF013 (void);
// 0x00000237 UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_audioClipForOnSelectExited()
extern void XRBaseControllerInteractor_get_audioClipForOnSelectExited_m7A09420C644DCACE326E4B5C4F8E33598B34E582 (void);
// 0x00000238 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_audioClipForOnSelectExited(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_audioClipForOnSelectExited_mE281ED7816675A52713088BF97DA0EBBAD0E8D28 (void);
// 0x00000239 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnSelectCanceled()
extern void XRBaseControllerInteractor_get_playAudioClipOnSelectCanceled_m9B0E43785F6CB9F5DB69298C306CBB4EE2A7E905 (void);
// 0x0000023A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playAudioClipOnSelectCanceled(System.Boolean)
extern void XRBaseControllerInteractor_set_playAudioClipOnSelectCanceled_m2D966F1B89C15EB331693675D157DB8F02107C4F (void);
// 0x0000023B UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_audioClipForOnSelectCanceled()
extern void XRBaseControllerInteractor_get_audioClipForOnSelectCanceled_mC30675A1F8E48AB1E7E59BE9B2C2224E9DBAADA6 (void);
// 0x0000023C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_audioClipForOnSelectCanceled(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_audioClipForOnSelectCanceled_m857146DE36A5B510D2B58D84AA7A35314663D2ED (void);
// 0x0000023D System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnHoverEntered()
extern void XRBaseControllerInteractor_get_playAudioClipOnHoverEntered_m248DA5BCC9CD1489BD8B8B953A7D5CC4C38E47A7 (void);
// 0x0000023E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playAudioClipOnHoverEntered(System.Boolean)
extern void XRBaseControllerInteractor_set_playAudioClipOnHoverEntered_m01F4ED76F62B831613D0B48FC2F60AF0C887B820 (void);
// 0x0000023F UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_audioClipForOnHoverEntered()
extern void XRBaseControllerInteractor_get_audioClipForOnHoverEntered_m7684A91511FDC02358D565E70D77D8AA668302FE (void);
// 0x00000240 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_audioClipForOnHoverEntered(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_audioClipForOnHoverEntered_mF7613F7A75BEC20FD6B0D1FCDC67E274323A1D5E (void);
// 0x00000241 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnHoverExited()
extern void XRBaseControllerInteractor_get_playAudioClipOnHoverExited_m83B5234181B9A0907F021DB9015040164444DAED (void);
// 0x00000242 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playAudioClipOnHoverExited(System.Boolean)
extern void XRBaseControllerInteractor_set_playAudioClipOnHoverExited_m714CBC8F50386871D88B28F32EE34DBAD4261DB3 (void);
// 0x00000243 UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_audioClipForOnHoverExited()
extern void XRBaseControllerInteractor_get_audioClipForOnHoverExited_mC30E51B5B790343F3BB6C1148CFE24E54E7F6441 (void);
// 0x00000244 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_audioClipForOnHoverExited(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_audioClipForOnHoverExited_m59986DCCE208E7BEA8BD31DBA4A3964DE11FFB37 (void);
// 0x00000245 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnHoverCanceled()
extern void XRBaseControllerInteractor_get_playAudioClipOnHoverCanceled_m6051B977A9F4670C29EBC513283929514B1831B9 (void);
// 0x00000246 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playAudioClipOnHoverCanceled(System.Boolean)
extern void XRBaseControllerInteractor_set_playAudioClipOnHoverCanceled_mADA799753DF5F279D0EDE9BB3638CE374E333B50 (void);
// 0x00000247 UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_audioClipForOnHoverCanceled()
extern void XRBaseControllerInteractor_get_audioClipForOnHoverCanceled_mEA9C59A47E3515B85662AFD5CF75F4533DCF0D4E (void);
// 0x00000248 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_audioClipForOnHoverCanceled(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_audioClipForOnHoverCanceled_mB4DAAC7B829DF82466BBDFC3F62CFCFD5CAABC86 (void);
// 0x00000249 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnSelectEntered()
extern void XRBaseControllerInteractor_get_playHapticsOnSelectEntered_m763E2EACB3F0DF0A325955B34F5CB6D8245C3297 (void);
// 0x0000024A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playHapticsOnSelectEntered(System.Boolean)
extern void XRBaseControllerInteractor_set_playHapticsOnSelectEntered_m9043BA2D99CA2B7FE73151960CC6BED3CB020CD3 (void);
// 0x0000024B System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticSelectEnterIntensity()
extern void XRBaseControllerInteractor_get_hapticSelectEnterIntensity_m0FF641A19A017CCDF39CF27C03C21FA0EBAAE4BF (void);
// 0x0000024C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticSelectEnterIntensity(System.Single)
extern void XRBaseControllerInteractor_set_hapticSelectEnterIntensity_mD2058A1D3EF40199553E39913BC96A2D3173E316 (void);
// 0x0000024D System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticSelectEnterDuration()
extern void XRBaseControllerInteractor_get_hapticSelectEnterDuration_m5D86D1C7E863D394013AA5026B4DF510619E3080 (void);
// 0x0000024E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticSelectEnterDuration(System.Single)
extern void XRBaseControllerInteractor_set_hapticSelectEnterDuration_mBE46CFDFDA52329BF3F57ABAACBCD51490E4B5B7 (void);
// 0x0000024F System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnSelectExited()
extern void XRBaseControllerInteractor_get_playHapticsOnSelectExited_m5DF2C108759F681632FB85E5759C03AF358BE2E8 (void);
// 0x00000250 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playHapticsOnSelectExited(System.Boolean)
extern void XRBaseControllerInteractor_set_playHapticsOnSelectExited_m5C407F2EA7D8F76210B7998B246F8B20D68C781B (void);
// 0x00000251 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticSelectExitIntensity()
extern void XRBaseControllerInteractor_get_hapticSelectExitIntensity_m5D338D33D49AE3C99E877044F3319579330FB43E (void);
// 0x00000252 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticSelectExitIntensity(System.Single)
extern void XRBaseControllerInteractor_set_hapticSelectExitIntensity_m8F08D58A280BB703BA2C63F31A01B4DF0B2D76C8 (void);
// 0x00000253 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticSelectExitDuration()
extern void XRBaseControllerInteractor_get_hapticSelectExitDuration_mC00C544D1B360C6FBC4A75191F567FC9D951F3D4 (void);
// 0x00000254 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticSelectExitDuration(System.Single)
extern void XRBaseControllerInteractor_set_hapticSelectExitDuration_mF00BEBE636025202D9BC741CF99D8FE6C58A307A (void);
// 0x00000255 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnSelectCanceled()
extern void XRBaseControllerInteractor_get_playHapticsOnSelectCanceled_m0DD4D8C866C5D6A76ADC095FF8B08CB0FDB9C1E2 (void);
// 0x00000256 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playHapticsOnSelectCanceled(System.Boolean)
extern void XRBaseControllerInteractor_set_playHapticsOnSelectCanceled_m1DBDB0A623D1494C686696EE84CF18C122C7A1D6 (void);
// 0x00000257 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticSelectCancelIntensity()
extern void XRBaseControllerInteractor_get_hapticSelectCancelIntensity_mE45AB9D6F0067C2F67F0C5B97EE7BD309ADAE335 (void);
// 0x00000258 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticSelectCancelIntensity(System.Single)
extern void XRBaseControllerInteractor_set_hapticSelectCancelIntensity_m266CC7DFA9CC8FCBFCF298B6848E2E768CFDFC39 (void);
// 0x00000259 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticSelectCancelDuration()
extern void XRBaseControllerInteractor_get_hapticSelectCancelDuration_mF8B7CAC67A9EE3D6D64D20E6323F5D0CC831E9FB (void);
// 0x0000025A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticSelectCancelDuration(System.Single)
extern void XRBaseControllerInteractor_set_hapticSelectCancelDuration_mE64EC55CEA68B7114131D806148141CBA194E7F3 (void);
// 0x0000025B System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnHoverEntered()
extern void XRBaseControllerInteractor_get_playHapticsOnHoverEntered_m57462B71C4340F341140AD5A58BEC7E3A1D79445 (void);
// 0x0000025C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playHapticsOnHoverEntered(System.Boolean)
extern void XRBaseControllerInteractor_set_playHapticsOnHoverEntered_m12E6BC09757083BDF6D39B833A9779AFE885573D (void);
// 0x0000025D System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticHoverEnterIntensity()
extern void XRBaseControllerInteractor_get_hapticHoverEnterIntensity_m1B4750EDF0745C988ADFD452CD6E779990EC6FD3 (void);
// 0x0000025E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticHoverEnterIntensity(System.Single)
extern void XRBaseControllerInteractor_set_hapticHoverEnterIntensity_m131FB945810E77EDD595B895F852C94A4714632C (void);
// 0x0000025F System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticHoverEnterDuration()
extern void XRBaseControllerInteractor_get_hapticHoverEnterDuration_mA6332338614A3D81A71A009F49D2FB022A8A786D (void);
// 0x00000260 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticHoverEnterDuration(System.Single)
extern void XRBaseControllerInteractor_set_hapticHoverEnterDuration_mE52A2F51917C3EFC6169939DAE3F6B9DA48AF515 (void);
// 0x00000261 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnHoverExited()
extern void XRBaseControllerInteractor_get_playHapticsOnHoverExited_m3D5ED4BE8757E3370A596A37B80A38F2342859D6 (void);
// 0x00000262 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playHapticsOnHoverExited(System.Boolean)
extern void XRBaseControllerInteractor_set_playHapticsOnHoverExited_m7FAE85CA6C4C385561BC7685F0D088715BD91996 (void);
// 0x00000263 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticHoverExitIntensity()
extern void XRBaseControllerInteractor_get_hapticHoverExitIntensity_mE1535489AC6AE761EC64383CFABDBA56FB870E5F (void);
// 0x00000264 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticHoverExitIntensity(System.Single)
extern void XRBaseControllerInteractor_set_hapticHoverExitIntensity_mB28A46AC3432AFA77B81CEA82F8151ADD384B353 (void);
// 0x00000265 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticHoverExitDuration()
extern void XRBaseControllerInteractor_get_hapticHoverExitDuration_mD994A2439337F73FEFE0D09A05CF9348F248924D (void);
// 0x00000266 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticHoverExitDuration(System.Single)
extern void XRBaseControllerInteractor_set_hapticHoverExitDuration_mF6BF30CBFCFB3638D9AA1D485C09DCD3B9B8B41F (void);
// 0x00000267 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnHoverCanceled()
extern void XRBaseControllerInteractor_get_playHapticsOnHoverCanceled_mC74AAD7E966F17AE8BF854CA2B62A92B263C3A90 (void);
// 0x00000268 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_playHapticsOnHoverCanceled(System.Boolean)
extern void XRBaseControllerInteractor_set_playHapticsOnHoverCanceled_mA18876593E753602FE5850BAB137312BF5682EE3 (void);
// 0x00000269 System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticHoverCancelIntensity()
extern void XRBaseControllerInteractor_get_hapticHoverCancelIntensity_m52902A33C06EDF8A34EA08C96CE82A06A026E25A (void);
// 0x0000026A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticHoverCancelIntensity(System.Single)
extern void XRBaseControllerInteractor_set_hapticHoverCancelIntensity_m3A6C9F831690E4583B11239162412185DC086E84 (void);
// 0x0000026B System.Single UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_hapticHoverCancelDuration()
extern void XRBaseControllerInteractor_get_hapticHoverCancelDuration_mA72726302124D5EACA9468D2C8BE5BEBBF3B7047 (void);
// 0x0000026C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_hapticHoverCancelDuration(System.Single)
extern void XRBaseControllerInteractor_set_hapticHoverCancelDuration_m9CFC0A57C66CC443D8505E4C14B12EBE72461FE4 (void);
// 0x0000026D System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_allowActivate()
extern void XRBaseControllerInteractor_get_allowActivate_m18841206E1DAB3E556D6543DC77C28B68ACFDECC (void);
// 0x0000026E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_allowActivate(System.Boolean)
extern void XRBaseControllerInteractor_set_allowActivate_m5567F89005093B2E724BD91B90A68AD8A907FDB0 (void);
// 0x0000026F UnityEngine.XR.Interaction.Toolkit.XRBaseController UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_xrController()
extern void XRBaseControllerInteractor_get_xrController_m3BBC15462D296ED35A6F2E87D290B86BF9216650 (void);
// 0x00000270 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_xrController(UnityEngine.XR.Interaction.Toolkit.XRBaseController)
extern void XRBaseControllerInteractor_set_xrController_m23CD933EEC980FBEEDA28EB1F6A16B7D7900D454 (void);
// 0x00000271 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::Awake()
extern void XRBaseControllerInteractor_Awake_m56049D4907C4F717D23E1125B0A889C03B1BC2C7 (void);
// 0x00000272 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::PreprocessInteractor(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRBaseControllerInteractor_PreprocessInteractor_m35D8EFA87BBD74851FA55C0CB992C673F75A3BC3 (void);
// 0x00000273 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::ProcessInteractor(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRBaseControllerInteractor_ProcessInteractor_m7C0801EA3674FB041D39591839085D70CCBD2924 (void);
// 0x00000274 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::SendActivateEvent(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractable>)
extern void XRBaseControllerInteractor_SendActivateEvent_m1CCDC1F6AF37B0CA504BA32566BCB1F937AE0E55 (void);
// 0x00000275 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::SendDeactivateEvent(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractable>)
extern void XRBaseControllerInteractor_SendDeactivateEvent_mAF2DA1D5D44D2F945BBFC4FDAB8434AA54380A70 (void);
// 0x00000276 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_isSelectActive()
extern void XRBaseControllerInteractor_get_isSelectActive_mD2A0FEDFB804B2D728DDDAFD14A36F4CC7DDB0DB (void);
// 0x00000277 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_isUISelectActive()
extern void XRBaseControllerInteractor_get_isUISelectActive_m0161BBF0121D3B3C388D07CD8BA284CC2D30B081 (void);
// 0x00000278 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_shouldActivate()
extern void XRBaseControllerInteractor_get_shouldActivate_m1614B653063CAAE5F92978BE2EC718F06C568CBE (void);
// 0x00000279 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_shouldDeactivate()
extern void XRBaseControllerInteractor_get_shouldDeactivate_m4C899A54579C59F177468F043318D3A486445A3A (void);
// 0x0000027A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::GetActivateTargets(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractable>)
extern void XRBaseControllerInteractor_GetActivateTargets_mC085A4C633558C4664682DE73936BDE993CE10EA (void);
// 0x0000027B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::OnSelectEntering(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRBaseControllerInteractor_OnSelectEntering_mC2F8B79C49F40CCD49B2E2D3619958CBBE193778 (void);
// 0x0000027C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::OnSelectExiting(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRBaseControllerInteractor_OnSelectExiting_mA62F40FAA1C318A29C57208462E5B84707EB58B4 (void);
// 0x0000027D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::OnHoverEntering(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRBaseControllerInteractor_OnHoverEntering_m9D888FB65519609A49AD2668FE3DE65D396F9194 (void);
// 0x0000027E System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::OnHoverExiting(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRBaseControllerInteractor_OnHoverExiting_mD0013FAB461685432BA128724E05FE16381DF569 (void);
// 0x0000027F System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::SendHapticImpulse(System.Single,System.Single)
extern void XRBaseControllerInteractor_SendHapticImpulse_m3FB94421656EEEFB493079ECF9A835ED76A16FFF (void);
// 0x00000280 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::PlayAudio(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_PlayAudio_m810ABE116A0AA27D131791151F15B1D93C066F40 (void);
// 0x00000281 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::CreateEffectsAudioSource()
extern void XRBaseControllerInteractor_CreateEffectsAudioSource_m5DD59A4BB8EB6CBBBC5E30CA7FA3ECA04BBC592C (void);
// 0x00000282 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::HandleSelecting()
extern void XRBaseControllerInteractor_HandleSelecting_mEE385E75B21EB5525DCAF6CD7FB476DC1DD6BE48 (void);
// 0x00000283 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::HandleDeselecting()
extern void XRBaseControllerInteractor_HandleDeselecting_m082894DDF402A43720079B75502722B21086FAFF (void);
// 0x00000284 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnSelectEnter()
extern void XRBaseControllerInteractor_get_playAudioClipOnSelectEnter_mA27A80951779A122CB4338EEEB98A313E0E81DBC (void);
// 0x00000285 UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_audioClipForOnSelectEnter()
extern void XRBaseControllerInteractor_get_audioClipForOnSelectEnter_m028B5FD8F656B98DF97A43F876EC707BB085D091 (void);
// 0x00000286 UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_AudioClipForOnSelectEnter()
extern void XRBaseControllerInteractor_get_AudioClipForOnSelectEnter_m3EE95869C8606934182F99711B7CA63C7D7FE918 (void);
// 0x00000287 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_AudioClipForOnSelectEnter(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_AudioClipForOnSelectEnter_m847AA895C79DD6D13400B10779513E6054C690ED (void);
// 0x00000288 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnSelectExit()
extern void XRBaseControllerInteractor_get_playAudioClipOnSelectExit_m1AB9FE4B8D5504AF267A51A9CCB1E7995E1F6FEA (void);
// 0x00000289 UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_audioClipForOnSelectExit()
extern void XRBaseControllerInteractor_get_audioClipForOnSelectExit_m6048BBDA543298D2490A743C755F528F067838EA (void);
// 0x0000028A UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_AudioClipForOnSelectExit()
extern void XRBaseControllerInteractor_get_AudioClipForOnSelectExit_m172979B3FCB857AF4FED242D0CD05DBFC9EF7AFA (void);
// 0x0000028B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_AudioClipForOnSelectExit(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_AudioClipForOnSelectExit_mF02E062055BC554990E931D86D826AAD1D48DDDB (void);
// 0x0000028C System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnHoverEnter()
extern void XRBaseControllerInteractor_get_playAudioClipOnHoverEnter_m76E47B225A881B6A5A929987FEC2A2AE8FBD253C (void);
// 0x0000028D UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_audioClipForOnHoverEnter()
extern void XRBaseControllerInteractor_get_audioClipForOnHoverEnter_mA2EE38C5F2DBA8ACDF60C67DE4A54E0364704121 (void);
// 0x0000028E UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_AudioClipForOnHoverEnter()
extern void XRBaseControllerInteractor_get_AudioClipForOnHoverEnter_m262D11C7E2816D16EAD0BD618287FD2052C35BE1 (void);
// 0x0000028F System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_AudioClipForOnHoverEnter(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_AudioClipForOnHoverEnter_mB0EB82559130360882514F049D607BBDB787CE81 (void);
// 0x00000290 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playAudioClipOnHoverExit()
extern void XRBaseControllerInteractor_get_playAudioClipOnHoverExit_m8FFE6D35DA39106CE854A790C58DFB395D81FF5B (void);
// 0x00000291 UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_audioClipForOnHoverExit()
extern void XRBaseControllerInteractor_get_audioClipForOnHoverExit_mBBF425B63F214550CA43A5B36583CC3F5BF93A0C (void);
// 0x00000292 UnityEngine.AudioClip UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_AudioClipForOnHoverExit()
extern void XRBaseControllerInteractor_get_AudioClipForOnHoverExit_m3A8E9280F3A45698DC4BBD3CC90762AC22523DCC (void);
// 0x00000293 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::set_AudioClipForOnHoverExit(UnityEngine.AudioClip)
extern void XRBaseControllerInteractor_set_AudioClipForOnHoverExit_m25E6581419E3218E15E16690611B66FCB5FC69C6 (void);
// 0x00000294 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnSelectEnter()
extern void XRBaseControllerInteractor_get_playHapticsOnSelectEnter_mFC4B1C291125623DAE52E2BE3BEADD322755BD97 (void);
// 0x00000295 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnSelectExit()
extern void XRBaseControllerInteractor_get_playHapticsOnSelectExit_m4B750C6EF6E0790E1970F807B337950B55998B81 (void);
// 0x00000296 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_playHapticsOnHoverEnter()
extern void XRBaseControllerInteractor_get_playHapticsOnHoverEnter_m06B9BC3E4A5A964BA88A6C2A890C8BAE02F57596 (void);
// 0x00000297 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable> UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::get_validTargets()
extern void XRBaseControllerInteractor_get_validTargets_m93BDD6EAE63E4178772D16B4ECBCE42E23325C2E (void);
// 0x00000298 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::.ctor()
extern void XRBaseControllerInteractor__ctor_m3389EC35F9C9C32149307AEEAF3A39C93A652AC5 (void);
// 0x00000299 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::.cctor()
extern void XRBaseControllerInteractor__cctor_m1AFAC1ADC99B0B69BD8785469D92DB472B25C31C (void);
// 0x0000029A UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor::UnityEngine.XR.Interaction.Toolkit.IXRInteractor.get_transform()
extern void XRBaseControllerInteractor_UnityEngine_XR_Interaction_Toolkit_IXRInteractor_get_transform_m0D684F19C850A054FF77B58331DB7662A9EB35B2 (void);
// 0x0000029B System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor/<>c::.cctor()
extern void U3CU3Ec__cctor_m5C794AE4E6AEE87AC9AB5CE584C0DEC7AAE0841A (void);
// 0x0000029C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor/<>c::.ctor()
extern void U3CU3Ec__ctor_mDB687ED85F378EB8ADF03F88D91757B797AF8EA7 (void);
// 0x0000029D UnityEngine.XR.Interaction.Toolkit.ActivateEventArgs UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor/<>c::<.ctor>b__208_0()
extern void U3CU3Ec_U3C_ctorU3Eb__208_0_m4FCDF50D009FCF86BB98AB312E9A24FD673ECDC8 (void);
// 0x0000029E UnityEngine.XR.Interaction.Toolkit.DeactivateEventArgs UnityEngine.XR.Interaction.Toolkit.XRBaseControllerInteractor/<>c::<.ctor>b__208_1()
extern void U3CU3Ec_U3C_ctorU3Eb__208_1_m132BEE78FD9C2A71D6A610372D21E0E392860AF6 (void);
// 0x0000029F System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::add_registered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs>)
extern void XRBaseInteractor_add_registered_mDFEA7418891929970CAD59F5A51E8F98123F172B (void);
// 0x000002A0 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::remove_registered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs>)
extern void XRBaseInteractor_remove_registered_mF2A497E4857266A8B3D61DB0F02F79C7337D838E (void);
// 0x000002A1 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::add_unregistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs>)
extern void XRBaseInteractor_add_unregistered_mDEED3743311D18B0748940FF13BF76722A6723A8 (void);
// 0x000002A2 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::remove_unregistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs>)
extern void XRBaseInteractor_remove_unregistered_m21B916157AF57EC9F79BBF8A7BB027351A880E2C (void);
// 0x000002A3 UnityEngine.XR.Interaction.Toolkit.XRInteractionManager UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_interactionManager()
extern void XRBaseInteractor_get_interactionManager_mD7FB7431097431DD95D2333E58A5052DF106E09F (void);
// 0x000002A4 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_interactionManager(UnityEngine.XR.Interaction.Toolkit.XRInteractionManager)
extern void XRBaseInteractor_set_interactionManager_m3B0BFBBFE80325CF8837DFC31B61E907710554AA (void);
// 0x000002A5 UnityEngine.XR.Interaction.Toolkit.InteractionLayerMask UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_interactionLayers()
extern void XRBaseInteractor_get_interactionLayers_m83DCB38A70922078AEBD323EBD7EDBEB6A70D00D (void);
// 0x000002A6 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_interactionLayers(UnityEngine.XR.Interaction.Toolkit.InteractionLayerMask)
extern void XRBaseInteractor_set_interactionLayers_mA988AF491A54DB866194C07D5E374780543B77D8 (void);
// 0x000002A7 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_attachTransform()
extern void XRBaseInteractor_get_attachTransform_m704C74165ED1463CF8B79670066472AE4BD33482 (void);
// 0x000002A8 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_attachTransform(UnityEngine.Transform)
extern void XRBaseInteractor_set_attachTransform_mA8DC6CAE14C3CAEDF3A8A9F23EC5DD5D533F7D56 (void);
// 0x000002A9 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_keepSelectedTargetValid()
extern void XRBaseInteractor_get_keepSelectedTargetValid_m76A234A876F9418E93317B3068157B6AE5D9674A (void);
// 0x000002AA System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_keepSelectedTargetValid(System.Boolean)
extern void XRBaseInteractor_set_keepSelectedTargetValid_m1DA1CA84FCA03C3FF7B9A4A7868DFAA2068B0033 (void);
// 0x000002AB UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_startingSelectedInteractable()
extern void XRBaseInteractor_get_startingSelectedInteractable_m0A551AC3C85D5B2EC353B2161A02CC2BCF888BAF (void);
// 0x000002AC System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_startingSelectedInteractable(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_set_startingSelectedInteractable_m875C82466909DF095E03CE0F3E3376CFF7BF24C9 (void);
// 0x000002AD UnityEngine.XR.Interaction.Toolkit.HoverEnterEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_hoverEntered()
extern void XRBaseInteractor_get_hoverEntered_m15CE707680BD64D93BD6F923CC1F431860ACA98D (void);
// 0x000002AE System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_hoverEntered(UnityEngine.XR.Interaction.Toolkit.HoverEnterEvent)
extern void XRBaseInteractor_set_hoverEntered_m076D53344B91F828218086BAD2C12C085C5D37C9 (void);
// 0x000002AF UnityEngine.XR.Interaction.Toolkit.HoverExitEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_hoverExited()
extern void XRBaseInteractor_get_hoverExited_m56584228DB8A08A444922894BC6988171F306178 (void);
// 0x000002B0 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_hoverExited(UnityEngine.XR.Interaction.Toolkit.HoverExitEvent)
extern void XRBaseInteractor_set_hoverExited_m880D6DFBF560D779430A6200270395C076EE05D3 (void);
// 0x000002B1 UnityEngine.XR.Interaction.Toolkit.SelectEnterEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_selectEntered()
extern void XRBaseInteractor_get_selectEntered_m49681B23359BF5E9E0C3F69040D0C1567A528EC3 (void);
// 0x000002B2 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_selectEntered(UnityEngine.XR.Interaction.Toolkit.SelectEnterEvent)
extern void XRBaseInteractor_set_selectEntered_mB607AC59A9E90460E22969EE3BAB1D14C567303C (void);
// 0x000002B3 UnityEngine.XR.Interaction.Toolkit.SelectExitEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_selectExited()
extern void XRBaseInteractor_get_selectExited_m2B4FA666B95E8DF09EB6D92ACEDB892BFF375384 (void);
// 0x000002B4 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_selectExited(UnityEngine.XR.Interaction.Toolkit.SelectExitEvent)
extern void XRBaseInteractor_set_selectExited_mEC821344C8B82E21C6224FFBB03D23C7D097D271 (void);
// 0x000002B5 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_allowHover()
extern void XRBaseInteractor_get_allowHover_m357ADDB98144E2F7F866B103035C2A35BE27E776 (void);
// 0x000002B6 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_allowHover(System.Boolean)
extern void XRBaseInteractor_set_allowHover_m1BCBF8BEFBF5043EFCC4EF41489AED8233C953AD (void);
// 0x000002B7 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_allowSelect()
extern void XRBaseInteractor_get_allowSelect_m0EA6D2C7201E691481A8FFA9F415623F632A1741 (void);
// 0x000002B8 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_allowSelect(System.Boolean)
extern void XRBaseInteractor_set_allowSelect_mE1104EAFC8D63D651C5461949D3ACB4C7C0353A2 (void);
// 0x000002B9 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_isPerformingManualInteraction()
extern void XRBaseInteractor_get_isPerformingManualInteraction_mB89C10BD1B4884EE369A46CC0D145B780B385A86 (void);
// 0x000002BA System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable> UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_interactablesHovered()
extern void XRBaseInteractor_get_interactablesHovered_mBC239352EDAB9F297C3E88EFF08EC5D4EC4AA43A (void);
// 0x000002BB System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_hasHover()
extern void XRBaseInteractor_get_hasHover_mD3BEFFEC29767CA2E4DC8C118803F9FE522FC5B3 (void);
// 0x000002BC System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable> UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_interactablesSelected()
extern void XRBaseInteractor_get_interactablesSelected_mD1EBA5422B2A291EF032106674611CCDACC62270 (void);
// 0x000002BD UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_firstInteractableSelected()
extern void XRBaseInteractor_get_firstInteractableSelected_m26779B4796BA51429DE9B5F34EB69BB4C02C48AF (void);
// 0x000002BE System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_firstInteractableSelected(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRBaseInteractor_set_firstInteractableSelected_mD8E07F7A066965269176D5A61F3240A6D733357A (void);
// 0x000002BF System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_hasSelection()
extern void XRBaseInteractor_get_hasSelection_mDC47E8BD0F4498E27BD041B52008C36AD09583B1 (void);
// 0x000002C0 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::Reset()
extern void XRBaseInteractor_Reset_m7ACAE4DF6A1A8F7E4DD6BC0A4D5645DC11D240C7 (void);
// 0x000002C1 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::Awake()
extern void XRBaseInteractor_Awake_m6C75157E01BD94FADF8EC1815E1202CB615DD88E (void);
// 0x000002C2 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnEnable()
extern void XRBaseInteractor_OnEnable_m65BC403EF883EFD685764D768F787C11F8906BDD (void);
// 0x000002C3 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnDisable()
extern void XRBaseInteractor_OnDisable_mA7C2B26F5887ECF0E95A964759EE035800B40D6E (void);
// 0x000002C4 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::Start()
extern void XRBaseInteractor_Start_m1FBD6D21C76646104BF949DD673C5319C3AD4970 (void);
// 0x000002C5 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnDestroy()
extern void XRBaseInteractor_OnDestroy_m9B3CE432DC24BE6ED8985CE17BF5EBDC5DBEA02C (void);
// 0x000002C6 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::GetAttachTransform(UnityEngine.XR.Interaction.Toolkit.IXRInteractable)
extern void XRBaseInteractor_GetAttachTransform_m116EB7BBA8EF9EAAD2C044726DC10F88B632D5BE (void);
// 0x000002C7 UnityEngine.Pose UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::GetAttachPoseOnSelect(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRBaseInteractor_GetAttachPoseOnSelect_mA3CADA2CF3873F38794DF86EDCF10D1EDD7D6E3B (void);
// 0x000002C8 UnityEngine.Pose UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::GetLocalAttachPoseOnSelect(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRBaseInteractor_GetLocalAttachPoseOnSelect_mE54064C64C854AB01AA234E026DC97686BACD37A (void);
// 0x000002C9 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::GetValidTargets(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>)
extern void XRBaseInteractor_GetValidTargets_mB24AEE297EE623EB57A903520BA832326A7DF1B1 (void);
// 0x000002CA System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::FindCreateInteractionManager()
extern void XRBaseInteractor_FindCreateInteractionManager_mD1E7D03121B1D9946933705229C54F4F22506A58 (void);
// 0x000002CB System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::RegisterWithInteractionManager()
extern void XRBaseInteractor_RegisterWithInteractionManager_m4C35108B7708D2123C20B5E3515FF93870302F4A (void);
// 0x000002CC System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::UnregisterWithInteractionManager()
extern void XRBaseInteractor_UnregisterWithInteractionManager_m456B9BEBB2209C64758A7D821AFBF090041E656B (void);
// 0x000002CD System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_isHoverActive()
extern void XRBaseInteractor_get_isHoverActive_m91F8634F4F3B4BB0F54BEC2546B98AC2C4ECB357 (void);
// 0x000002CE System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_isSelectActive()
extern void XRBaseInteractor_get_isSelectActive_m56CB9182C9F3FD3012F7C13B2F02C8B3969B1039 (void);
// 0x000002CF System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::CanHover(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable)
extern void XRBaseInteractor_CanHover_mE4BFF4D695C12708D5544781C80A499EF3DCF8F1 (void);
// 0x000002D0 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::CanSelect(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRBaseInteractor_CanSelect_m857FE99BC5AAAD3DC5245EF8F0D77B32E87A2C31 (void);
// 0x000002D1 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::IsHovering(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable)
extern void XRBaseInteractor_IsHovering_m55FB787EEE350276EEA14DAD207CC480E50922BF (void);
// 0x000002D2 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::IsSelecting(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRBaseInteractor_IsSelecting_m3B428FEC36DAE9F97CCC2987B72D9F706CD8CE62 (void);
// 0x000002D3 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::IsHovering(UnityEngine.XR.Interaction.Toolkit.IXRInteractable)
extern void XRBaseInteractor_IsHovering_m3D8CA61660A77820B30C03D47C42D21E99E389E6 (void);
// 0x000002D4 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::IsSelecting(UnityEngine.XR.Interaction.Toolkit.IXRInteractable)
extern void XRBaseInteractor_IsSelecting_mA346D7D3004F15BF9D982B4F8D1E3A45F078ADB5 (void);
// 0x000002D5 System.Nullable`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable/MovementType> UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_selectedInteractableMovementTypeOverride()
extern void XRBaseInteractor_get_selectedInteractableMovementTypeOverride_m1E0E40901DE181CE04985FF5626CD59AA5D10FDA (void);
// 0x000002D6 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::CaptureAttachPose(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRBaseInteractor_CaptureAttachPose_mDBE1D76673D032F2C1EEBBE7B2D65E976CD6B471 (void);
// 0x000002D7 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::PreprocessInteractor(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRBaseInteractor_PreprocessInteractor_mF1F270D70D1E2F39E36486B92D6E1E44255F6ED4 (void);
// 0x000002D8 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::ProcessInteractor(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRBaseInteractor_ProcessInteractor_mCA4F4CDFE9578064E85EEA274098EDAE7E9E27BC (void);
// 0x000002D9 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::UnityEngine.XR.Interaction.Toolkit.IXRInteractor.OnRegistered(UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs)
extern void XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRInteractor_OnRegistered_m34EAB9F9D1C38DF1390A49955087E32F8BEA4171 (void);
// 0x000002DA System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::UnityEngine.XR.Interaction.Toolkit.IXRInteractor.OnUnregistered(UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs)
extern void XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRInteractor_OnUnregistered_m44641B37B1BEB0A9867536930C20F6EDBEDDC578 (void);
// 0x000002DB System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor.CanHover(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable)
extern void XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRHoverInteractor_CanHover_m067F71B53F2F5A51A65E742FA87A9D952382C312 (void);
// 0x000002DC System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor.OnHoverEntering(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRHoverInteractor_OnHoverEntering_m36F164B4EB67530252354129C857484DF82287A1 (void);
// 0x000002DD System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor.OnHoverEntered(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRHoverInteractor_OnHoverEntered_m8673D1EBE4CBE66030CEB1817494A7673C767AB9 (void);
// 0x000002DE System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor.OnHoverExiting(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRHoverInteractor_OnHoverExiting_m3792F6819F7835D23D739B70CF7B3E43F8499C45 (void);
// 0x000002DF System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor.OnHoverExited(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRHoverInteractor_OnHoverExited_mFB7411803014DDC82F60D0EE75EFDA827A4641BC (void);
// 0x000002E0 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor.CanSelect(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRSelectInteractor_CanSelect_m8D3B9E08C4F360BE69CF45ABE3412932D89B5063 (void);
// 0x000002E1 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor.OnSelectEntering(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRSelectInteractor_OnSelectEntering_m1A29BD94DB518DEACEB24E373A5E70AD5CD75D63 (void);
// 0x000002E2 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor.OnSelectEntered(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRSelectInteractor_OnSelectEntered_m223DD16423E761FA865023F1FF0AECC510ED2CA3 (void);
// 0x000002E3 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor.OnSelectExiting(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRSelectInteractor_OnSelectExiting_mE4828A2B54422D1339F0B79094CEDE6A6FBFD063 (void);
// 0x000002E4 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor.OnSelectExited(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRSelectInteractor_OnSelectExited_m5A144267275180DC7F69468A3AB233CFEF0F0482 (void);
// 0x000002E5 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnRegistered(UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs)
extern void XRBaseInteractor_OnRegistered_m1BB39FA738FF1BFA87EB9ACB9D091D2C0FF8F67A (void);
// 0x000002E6 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnUnregistered(UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs)
extern void XRBaseInteractor_OnUnregistered_mA14336625DC266534FFF8056AB2655A817D1B778 (void);
// 0x000002E7 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnHoverEntering(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRBaseInteractor_OnHoverEntering_m2A2499BDF0F89D2714BA789EE9A20675474A69C7 (void);
// 0x000002E8 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnHoverEntered(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRBaseInteractor_OnHoverEntered_m78767217DB9B63C9574E796C58F65C5EA2E908A6 (void);
// 0x000002E9 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnHoverExiting(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRBaseInteractor_OnHoverExiting_m52628FF618019474078CB02DDF2F49711FAA810E (void);
// 0x000002EA System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnHoverExited(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRBaseInteractor_OnHoverExited_m4939A4A5FF0A6139436EF0742C04CE7EC65E33D6 (void);
// 0x000002EB System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnSelectEntering(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRBaseInteractor_OnSelectEntering_m3EA6F5821354FC822F71995CE161471F39F150A9 (void);
// 0x000002EC System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnSelectEntered(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRBaseInteractor_OnSelectEntered_mB8E77D8ECF4F1E05EACC983AB4ADC30A7436E9D8 (void);
// 0x000002ED System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnSelectExiting(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRBaseInteractor_OnSelectExiting_m7725B69F454CC0A648E0B60AB5E18CBE5787F0AF (void);
// 0x000002EE System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnSelectExited(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRBaseInteractor_OnSelectExited_mF549A06BF8301DC612AA2514EC4C781869DAC0E5 (void);
// 0x000002EF System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::StartManualInteraction(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRBaseInteractor_StartManualInteraction_mB19DA7DD686B95D10F99BA7D8A10D1499B724039 (void);
// 0x000002F0 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::EndManualInteraction()
extern void XRBaseInteractor_EndManualInteraction_mFAC265C520AD30A85A7C4522772C22EDB4C9518B (void);
// 0x000002F1 UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_interactionLayerMask()
extern void XRBaseInteractor_get_interactionLayerMask_mA396D79861729A68EEB8C025A947071E948B6CF1 (void);
// 0x000002F2 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_interactionLayerMask(UnityEngine.LayerMask)
extern void XRBaseInteractor_set_interactionLayerMask_m1737C7588EE2CBD195D86719BE2510B508D6776D (void);
// 0x000002F3 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_enableInteractions()
extern void XRBaseInteractor_get_enableInteractions_m67A61D810107BF13A42C8261A47454B84678E874 (void);
// 0x000002F4 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_enableInteractions(System.Boolean)
extern void XRBaseInteractor_set_enableInteractions_m74617749137DB759AA43C023634C1F23D32DF712 (void);
// 0x000002F5 UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_onHoverEntered()
extern void XRBaseInteractor_get_onHoverEntered_mA449A72C5F366C8BB222D6262D5127D61D3F10AC (void);
// 0x000002F6 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_onHoverEntered(UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent)
extern void XRBaseInteractor_set_onHoverEntered_m08FBEB36390D812631ABC807B8587D0C4C842DA2 (void);
// 0x000002F7 UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_onHoverExited()
extern void XRBaseInteractor_get_onHoverExited_m0DDF2121B99C14B9AF139D7FF4B27D9F7C1398C3 (void);
// 0x000002F8 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_onHoverExited(UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent)
extern void XRBaseInteractor_set_onHoverExited_mEF0748AC36F7BA764AA9C09509BA95DB2CBEE67C (void);
// 0x000002F9 UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_onSelectEntered()
extern void XRBaseInteractor_get_onSelectEntered_m238310EE85C99FE578B38F20895C83365184E69E (void);
// 0x000002FA System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_onSelectEntered(UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent)
extern void XRBaseInteractor_set_onSelectEntered_m0BFFBB5D6C943205F9B3D2DA4184353D3120662A (void);
// 0x000002FB UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_onSelectExited()
extern void XRBaseInteractor_get_onSelectExited_m29B6A63775E3A7E3F0C8881D4BB6194F059780C4 (void);
// 0x000002FC System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_onSelectExited(UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent)
extern void XRBaseInteractor_set_onSelectExited_mCF801299B6060B380B394E13494C0A49F558FA31 (void);
// 0x000002FD UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_onHoverEnter()
extern void XRBaseInteractor_get_onHoverEnter_m1DC8B81FA2FEC784301933C81822B13823386EF0 (void);
// 0x000002FE UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_onHoverExit()
extern void XRBaseInteractor_get_onHoverExit_m8C280AC6F90D71F321757C994D1E01D9E61BE429 (void);
// 0x000002FF UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_onSelectEnter()
extern void XRBaseInteractor_get_onSelectEnter_m0CEDEDB2FAC2877CD60B1407BA2A4C79A7D2DF75 (void);
// 0x00000300 UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_onSelectExit()
extern void XRBaseInteractor_get_onSelectExit_m23C9C661A20C668B2EB73FA878BDFA2641A09977 (void);
// 0x00000301 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnHoverEntering(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_OnHoverEntering_m53C199DBE536D343E946E44574A2E020C08EE690 (void);
// 0x00000302 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnHoverEntered(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_OnHoverEntered_mEB7BD83EA335C9CAE1224FA8301A92ED6209256D (void);
// 0x00000303 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnHoverExiting(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_OnHoverExiting_m34E59BB6AC0126095917BE5796E6B6912E0345D6 (void);
// 0x00000304 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnHoverExited(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_OnHoverExited_mA4685CA32D22F19E62B69473771C77F32605B992 (void);
// 0x00000305 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnSelectEntering(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_OnSelectEntering_m163C97B729A7F45EA303E24EAAFC6E03730048F7 (void);
// 0x00000306 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnSelectEntered(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_OnSelectEntered_m28C75857F4107F32CFD49D47BE284A0C7F3B3E9D (void);
// 0x00000307 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnSelectExiting(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_OnSelectExiting_m4CA8911663511BDECB64BE2CAFF7D04AAFF002AB (void);
// 0x00000308 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::OnSelectExited(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_OnSelectExited_mF49B11491BA75211E785DE4DF3EF21155D12EE95 (void);
// 0x00000309 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_selectTarget()
extern void XRBaseInteractor_get_selectTarget_m2888C3BFA4B168C6DDD37CAC1A999BEF406596E4 (void);
// 0x0000030A System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::set_selectTarget(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_set_selectTarget_m91662B5B6BFF86231E8A5D2D1DB4248D621EE38B (void);
// 0x0000030B System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable> UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_hoverTargets()
extern void XRBaseInteractor_get_hoverTargets_mE8E85B88E7C55FD9B89CCDECAB26FFF81C6A33AA (void);
// 0x0000030C System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::GetHoverTargets(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRBaseInteractor_GetHoverTargets_m97B6CFE8D71144CF21C4D470482DAB9101D4AA35 (void);
// 0x0000030D System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::GetValidTargets(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRBaseInteractor_GetValidTargets_mCBA71C2416753720B26909D52E2B91F61D9F7CBD (void);
// 0x0000030E System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::CanHover(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_CanHover_m937BB7BEF8BD5FAD64BFAE799C9A7B749B5BBA19 (void);
// 0x0000030F System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::CanSelect(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_CanSelect_m55EAA2676B54657E1BBA826503EC7886802041DA (void);
// 0x00000310 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::get_requireSelectExclusive()
extern void XRBaseInteractor_get_requireSelectExclusive_m954D86172595A6FEB6FC427F2E29BCDAFED636F9 (void);
// 0x00000311 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::StartManualInteraction(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRBaseInteractor_StartManualInteraction_mD772BD84B374A52F64A5BE7C92C1D9CE62AB0ACF (void);
// 0x00000312 System.Void UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::.ctor()
extern void XRBaseInteractor__ctor_mCEB69DD262DE1CF1951979855AFC2FEEC41806FE (void);
// 0x00000313 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor::UnityEngine.XR.Interaction.Toolkit.IXRInteractor.get_transform()
extern void XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRInteractor_get_transform_mE7E88B629F433D7A1FC24827D99A50FBECDCAA1D (void);
// 0x00000314 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable> UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::get_unsortedValidTargets()
extern void XRDirectInteractor_get_unsortedValidTargets_m3F187FD1D01B26250B2BE851DCD1AE186D7C3B5F (void);
// 0x00000315 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::Awake()
extern void XRDirectInteractor_Awake_mB51788F86E4C2D7C55F00477E3F5E5588D7BDF65 (void);
// 0x00000316 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::Start()
extern void XRDirectInteractor_Start_m3C997ED103F1B5ECA652552D6DCC984898B0AE5E (void);
// 0x00000317 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::OnTriggerEnter(UnityEngine.Collider)
extern void XRDirectInteractor_OnTriggerEnter_m3D9CCA2EED4E0AA34A0BE36DE7599FF6348FC9F6 (void);
// 0x00000318 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::OnTriggerStay(UnityEngine.Collider)
extern void XRDirectInteractor_OnTriggerStay_mEE525A746196804F4A7E66C5A72807B66E91950A (void);
// 0x00000319 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::OnTriggerExit(UnityEngine.Collider)
extern void XRDirectInteractor_OnTriggerExit_m5C355D85FAE1ED7E7FE8E4A22168B81DD50FB8D0 (void);
// 0x0000031A System.Collections.IEnumerator UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::UpdateCollidersAfterOnTriggerStay()
extern void XRDirectInteractor_UpdateCollidersAfterOnTriggerStay_mFB001408D287F1B2C2D25AAB0294916FAA7EB2A5 (void);
// 0x0000031B System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::ProcessInteractor(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRDirectInteractor_ProcessInteractor_mCFC6F659CE3B3CB8E61651E9C445AB2A7FDEEA50 (void);
// 0x0000031C System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::ValidateTriggerCollider()
extern void XRDirectInteractor_ValidateTriggerCollider_mBA36322C35D0D862DC3BBB4589E327539EE57DAA (void);
// 0x0000031D System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::GetValidTargets(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>)
extern void XRDirectInteractor_GetValidTargets_mA400D3C7DA91720BCD4ED266D4C904C830ADE99E (void);
// 0x0000031E System.Boolean UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::CanHover(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable)
extern void XRDirectInteractor_CanHover_mA55E90FBCC4617EBCA46DE2C95A1D1494EEC6C17 (void);
// 0x0000031F System.Boolean UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::CanSelect(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRDirectInteractor_CanSelect_mC3B39DC4FEE142197D08FE0236BDF3893621A6B7 (void);
// 0x00000320 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::OnRegistered(UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs)
extern void XRDirectInteractor_OnRegistered_m4C60146C4CA689769D38EAFB32C3EB477BC34E13 (void);
// 0x00000321 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::OnUnregistered(UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs)
extern void XRDirectInteractor_OnUnregistered_m8FB63736F9FCF0593AB7DCE2FEFE18F50188D436 (void);
// 0x00000322 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::OnInteractableRegistered(UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs)
extern void XRDirectInteractor_OnInteractableRegistered_m1E2ACA6632D19A7684383401D04969214102195C (void);
// 0x00000323 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::OnInteractableUnregistered(UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs)
extern void XRDirectInteractor_OnInteractableUnregistered_mC33CD46EFB5E5617B9B1EB93596928F9FD0C6429 (void);
// 0x00000324 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::OnContactAdded(UnityEngine.XR.Interaction.Toolkit.IXRInteractable)
extern void XRDirectInteractor_OnContactAdded_m790E0C50C4A81E54CC96E91DB14466423F821702 (void);
// 0x00000325 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::OnContactRemoved(UnityEngine.XR.Interaction.Toolkit.IXRInteractable)
extern void XRDirectInteractor_OnContactRemoved_m6B6012C3F5264D3D55E701B25838C6FE89AC3156 (void);
// 0x00000326 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::CanHover(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRDirectInteractor_CanHover_mDEA26F94E9C64C3EB89A0AEB805856FDE0DA7A41 (void);
// 0x00000327 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::CanSelect(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRDirectInteractor_CanSelect_m5E29D77F0A224AEC11AAD270A566C9C417B32DF3 (void);
// 0x00000328 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::.ctor()
extern void XRDirectInteractor__ctor_mD3BF236502DEBCF85593CEF7F585F787AE08E4A2 (void);
// 0x00000329 System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor::.cctor()
extern void XRDirectInteractor__cctor_m2FA03D795AC5902AB95B581382D4E8BF5B2D1F5F (void);
// 0x0000032A System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor/<UpdateCollidersAfterOnTriggerStay>d__11::.ctor(System.Int32)
extern void U3CUpdateCollidersAfterOnTriggerStayU3Ed__11__ctor_m31DF5879A500B55F9C0B6E6C09554979D09371B2 (void);
// 0x0000032B System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor/<UpdateCollidersAfterOnTriggerStay>d__11::System.IDisposable.Dispose()
extern void U3CUpdateCollidersAfterOnTriggerStayU3Ed__11_System_IDisposable_Dispose_mA7A1F4A04B1EF73D60B837F3F314F9E5D5739F37 (void);
// 0x0000032C System.Boolean UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor/<UpdateCollidersAfterOnTriggerStay>d__11::MoveNext()
extern void U3CUpdateCollidersAfterOnTriggerStayU3Ed__11_MoveNext_m17CD9ECB3FD5F8D87F55991A7F6D7909640F50F1 (void);
// 0x0000032D System.Object UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor/<UpdateCollidersAfterOnTriggerStay>d__11::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CUpdateCollidersAfterOnTriggerStayU3Ed__11_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mD2AF0E969EDB30FA9AD8D8272E0B3D7CFF771AA6 (void);
// 0x0000032E System.Void UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor/<UpdateCollidersAfterOnTriggerStay>d__11::System.Collections.IEnumerator.Reset()
extern void U3CUpdateCollidersAfterOnTriggerStayU3Ed__11_System_Collections_IEnumerator_Reset_m1000802674DC352AEFEB54E3F6DF8324E2438759 (void);
// 0x0000032F System.Object UnityEngine.XR.Interaction.Toolkit.XRDirectInteractor/<UpdateCollidersAfterOnTriggerStay>d__11::System.Collections.IEnumerator.get_Current()
extern void U3CUpdateCollidersAfterOnTriggerStayU3Ed__11_System_Collections_IEnumerator_get_Current_mF4EF99BD0B0D5A4C69ECE072388316561645A550 (void);
// 0x00000330 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/LineType UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_lineType()
extern void XRRayInteractor_get_lineType_mCE9C5CDA4DF31B8C3425D5F8050707655D36745B (void);
// 0x00000331 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_lineType(UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/LineType)
extern void XRRayInteractor_set_lineType_m0D312CD7538192F49A152DBCB266E4D9AECEF677 (void);
// 0x00000332 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_blendVisualLinePoints()
extern void XRRayInteractor_get_blendVisualLinePoints_m45738324AB95BBFEAEAD7236861C8FA7B7C23B3A (void);
// 0x00000333 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_blendVisualLinePoints(System.Boolean)
extern void XRRayInteractor_set_blendVisualLinePoints_m564BB6E62C7C182A06B40591FA3E660F4E064EE6 (void);
// 0x00000334 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_maxRaycastDistance()
extern void XRRayInteractor_get_maxRaycastDistance_m1069A3FBFC0A89685DB6E46A1F31D4F089303FEB (void);
// 0x00000335 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_maxRaycastDistance(System.Single)
extern void XRRayInteractor_set_maxRaycastDistance_m63BCDCD92B9E27CB3B967D7942B38DE5B60B26C1 (void);
// 0x00000336 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_rayOriginTransform()
extern void XRRayInteractor_get_rayOriginTransform_m1E25B9D203ABF076A179802DC530B2A3137232F2 (void);
// 0x00000337 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_rayOriginTransform(UnityEngine.Transform)
extern void XRRayInteractor_set_rayOriginTransform_m615A2661622EC41AC56242329D3ED7AC681AB289 (void);
// 0x00000338 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_referenceFrame()
extern void XRRayInteractor_get_referenceFrame_mDA09B1E0E001EFE89607F065B032F92729B5323D (void);
// 0x00000339 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_referenceFrame(UnityEngine.Transform)
extern void XRRayInteractor_set_referenceFrame_m7AF2D18BEB12CE4C215AF25D53970778E02D9B53 (void);
// 0x0000033A System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_velocity()
extern void XRRayInteractor_get_velocity_mC30B6466EDEA67F4CB76157FBE64DC9721A4609F (void);
// 0x0000033B System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_velocity(System.Single)
extern void XRRayInteractor_set_velocity_mCCF6C243466B1646E2C08915D3315F22BA4CFCED (void);
// 0x0000033C System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_acceleration()
extern void XRRayInteractor_get_acceleration_m795393467FD40A04E5BFD13A8A35F05C9AAF0493 (void);
// 0x0000033D System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_acceleration(System.Single)
extern void XRRayInteractor_set_acceleration_m5FD2D0617C088F3829D1569DD40B8ADF8FE74FBA (void);
// 0x0000033E System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_additionalGroundHeight()
extern void XRRayInteractor_get_additionalGroundHeight_m82BE02908177DB7B59DE24D22D5E51350F18E7D3 (void);
// 0x0000033F System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_additionalGroundHeight(System.Single)
extern void XRRayInteractor_set_additionalGroundHeight_mE2977A1FD487B14A4FEB971A26F030F95C1816B6 (void);
// 0x00000340 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_additionalFlightTime()
extern void XRRayInteractor_get_additionalFlightTime_mA73DCAC70D780715D3C79888D97BE7BC52FA145E (void);
// 0x00000341 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_additionalFlightTime(System.Single)
extern void XRRayInteractor_set_additionalFlightTime_m439C1605D143999EC6124A6650F2EC40E786BDE7 (void);
// 0x00000342 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_endPointDistance()
extern void XRRayInteractor_get_endPointDistance_mC3B7A8459DA824BCEE794196532AD07494B44704 (void);
// 0x00000343 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_endPointDistance(System.Single)
extern void XRRayInteractor_set_endPointDistance_m824F8D5F8D12D185A5E0DB9C333B19BD8DB92399 (void);
// 0x00000344 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_endPointHeight()
extern void XRRayInteractor_get_endPointHeight_m2BF3923091F4C4C2C7F8DB03973E192EBAB5D994 (void);
// 0x00000345 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_endPointHeight(System.Single)
extern void XRRayInteractor_set_endPointHeight_m3D1E99D32A678C433AFE0DD335308301669FAF1F (void);
// 0x00000346 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_controlPointDistance()
extern void XRRayInteractor_get_controlPointDistance_m943999A8F649AC0EB624C41C43B7CB65E712D399 (void);
// 0x00000347 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_controlPointDistance(System.Single)
extern void XRRayInteractor_set_controlPointDistance_m167046E23C6C56911AF5D1791DA6AAE7B8B044CD (void);
// 0x00000348 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_controlPointHeight()
extern void XRRayInteractor_get_controlPointHeight_m22D1E8077AADC14CD6B5BEADBB3218B0D5A9D11A (void);
// 0x00000349 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_controlPointHeight(System.Single)
extern void XRRayInteractor_set_controlPointHeight_m75D2883EEB5BB7E457B6C7118A4277E4D1D76F28 (void);
// 0x0000034A System.Int32 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_sampleFrequency()
extern void XRRayInteractor_get_sampleFrequency_m84137E62F2F5D869D915166F5C9CAC51279C333A (void);
// 0x0000034B System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_sampleFrequency(System.Int32)
extern void XRRayInteractor_set_sampleFrequency_mEA325242F6BD6109D4A66BD383373898EED50483 (void);
// 0x0000034C UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/HitDetectionType UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_hitDetectionType()
extern void XRRayInteractor_get_hitDetectionType_m56489A2A9D1D4B46E76AB06B1BBBAD0B64DE5712 (void);
// 0x0000034D System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_hitDetectionType(UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/HitDetectionType)
extern void XRRayInteractor_set_hitDetectionType_m1344C3C4EF7FD5AD4460680D9272C15E1DC6FEC4 (void);
// 0x0000034E System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_sphereCastRadius()
extern void XRRayInteractor_get_sphereCastRadius_mB224B23B50CADB816FF38A8BB8E61E2F1E574CF6 (void);
// 0x0000034F System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_sphereCastRadius(System.Single)
extern void XRRayInteractor_set_sphereCastRadius_m125335531C37195BA247DC1319ED3BF2035461A7 (void);
// 0x00000350 UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_raycastMask()
extern void XRRayInteractor_get_raycastMask_m02C2CE6B9DAFA5AC0B6FE84A580AC7269A989C36 (void);
// 0x00000351 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_raycastMask(UnityEngine.LayerMask)
extern void XRRayInteractor_set_raycastMask_m9584267773FB9BEBD2F0D530461BAFD4772B15D6 (void);
// 0x00000352 UnityEngine.QueryTriggerInteraction UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_raycastTriggerInteraction()
extern void XRRayInteractor_get_raycastTriggerInteraction_m958C93F2AF2B349DAA54FBF3F36EA1584E5F1122 (void);
// 0x00000353 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_raycastTriggerInteraction(UnityEngine.QueryTriggerInteraction)
extern void XRRayInteractor_set_raycastTriggerInteraction_mA28B34B3E8AF9E8F1EEBE58A2603AC584C135D0C (void);
// 0x00000354 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_hitClosestOnly()
extern void XRRayInteractor_get_hitClosestOnly_m805AF397E71FE0E26E22DB3BC2C16E667B30EA3A (void);
// 0x00000355 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_hitClosestOnly(System.Boolean)
extern void XRRayInteractor_set_hitClosestOnly_m7C2D5C87EE3BF70943827C44A3D2DE87C0F949F9 (void);
// 0x00000356 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_hoverToSelect()
extern void XRRayInteractor_get_hoverToSelect_m8E990754FB4491BA0083639F657F31268EB553EC (void);
// 0x00000357 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_hoverToSelect(System.Boolean)
extern void XRRayInteractor_set_hoverToSelect_m768C5E42FE973AF304BB107647E20822FF575473 (void);
// 0x00000358 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_hoverTimeToSelect()
extern void XRRayInteractor_get_hoverTimeToSelect_m5823C8CA027B591248F80778E536BCBA72225106 (void);
// 0x00000359 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_hoverTimeToSelect(System.Single)
extern void XRRayInteractor_set_hoverTimeToSelect_mD9161C16F6EDBB1CDCDD6DAAC043365B86AF1573 (void);
// 0x0000035A System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_enableUIInteraction()
extern void XRRayInteractor_get_enableUIInteraction_m50E1F190769782C0B3A07186CCB377C1CACD052B (void);
// 0x0000035B System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_enableUIInteraction(System.Boolean)
extern void XRRayInteractor_set_enableUIInteraction_mD9CCCEBED6763F747B471C754B0E59C6B2EEC66A (void);
// 0x0000035C System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_allowAnchorControl()
extern void XRRayInteractor_get_allowAnchorControl_m51594FACBD4A49AAFC7353F65ED8240F4646ADEF (void);
// 0x0000035D System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_allowAnchorControl(System.Boolean)
extern void XRRayInteractor_set_allowAnchorControl_mDCA19C625E5D567B4D8BE11B600B8B6D90FA2789 (void);
// 0x0000035E System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_useForceGrab()
extern void XRRayInteractor_get_useForceGrab_m7D8E5B79255A824D546B669F39D505CF87925A56 (void);
// 0x0000035F System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_useForceGrab(System.Boolean)
extern void XRRayInteractor_set_useForceGrab_m32748F17CD4BCDA71BFE9306D9973C7307769E60 (void);
// 0x00000360 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_rotateSpeed()
extern void XRRayInteractor_get_rotateSpeed_m537E0014CB47BBA3E12B33472F4529332EFA83AC (void);
// 0x00000361 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_rotateSpeed(System.Single)
extern void XRRayInteractor_set_rotateSpeed_m0EEA37A30E60ABF0C9B10ACEB3566A88465E16DF (void);
// 0x00000362 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_translateSpeed()
extern void XRRayInteractor_get_translateSpeed_mE5950FBE32CE216680DFDD6FAE859092A379CCEB (void);
// 0x00000363 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_translateSpeed(System.Single)
extern void XRRayInteractor_set_translateSpeed_m2BE27E2DAEC0D40F829FD5AAEC11070DB16300C0 (void);
// 0x00000364 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_anchorRotateReferenceFrame()
extern void XRRayInteractor_get_anchorRotateReferenceFrame_m3C17045FE587675A05CDFE73D981F4AFA23E9B12 (void);
// 0x00000365 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_anchorRotateReferenceFrame(UnityEngine.Transform)
extern void XRRayInteractor_set_anchorRotateReferenceFrame_m56F0F8C1CAF3C0EC632929B038483AAEDDB10348 (void);
// 0x00000366 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_angle()
extern void XRRayInteractor_get_angle_mAF632F8978FF0387DC7A9EA05267D893BC2A160E (void);
// 0x00000367 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_effectiveRayOrigin()
extern void XRRayInteractor_get_effectiveRayOrigin_m55B8E8E664761C5362A94336DF2F67F58CFC9052 (void);
// 0x00000368 System.Int32 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_closestAnyHitIndex()
extern void XRRayInteractor_get_closestAnyHitIndex_m6C80C28C657B13EE96C321CB596F2737B842C65D (void);
// 0x00000369 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::OnValidate()
extern void XRRayInteractor_OnValidate_mE0D577E74BEDFBAB060630783AD10D294D42F505 (void);
// 0x0000036A System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::Awake()
extern void XRRayInteractor_Awake_mD4EAAAFECF93D0F4D662C08087D24EAB6B21B109 (void);
// 0x0000036B System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::OnEnable()
extern void XRRayInteractor_OnEnable_m2C9F1F1C87F0A767AEA9DF2BCF3407F37A4991B2 (void);
// 0x0000036C System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::OnDisable()
extern void XRRayInteractor_OnDisable_m4DECBE5770DA2751AF8D08D070FC861BC7FD668C (void);
// 0x0000036D System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::OnDrawGizmosSelected()
extern void XRRayInteractor_OnDrawGizmosSelected_mD67B665592054CCE75AB58A57481A4A0540B9333 (void);
// 0x0000036E System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::DrawQuadraticBezierGizmo(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void XRRayInteractor_DrawQuadraticBezierGizmo_m16828B1E1140B9E9832F4BA6FA33329DA38BB512 (void);
// 0x0000036F System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::FindReferenceFrame()
extern void XRRayInteractor_FindReferenceFrame_m4844393D835BDEE5F527C4AED3A6255D2F06C37D (void);
// 0x00000370 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::CreateRayOrigin()
extern void XRRayInteractor_CreateRayOrigin_m2A57C20C49A3F578A70090642855EAF8D4D1AF2E (void);
// 0x00000371 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::FindOrCreateXRUIInputModule()
extern void XRRayInteractor_FindOrCreateXRUIInputModule_mE330D81A83210C2997D860F4D419B39E048ABCC4 (void);
// 0x00000372 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::RegisterWithXRUIInputModule()
extern void XRRayInteractor_RegisterWithXRUIInputModule_m2EE92ABC9177938118467CD455670533AA6DC486 (void);
// 0x00000373 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::UnregisterFromXRUIInputModule()
extern void XRRayInteractor_UnregisterFromXRUIInputModule_mE6AA25434D584A533536DB30CAF6C491AD45633A (void);
// 0x00000374 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::RegisterOrUnregisterXRUIInputModule()
extern void XRRayInteractor_RegisterOrUnregisterXRUIInputModule_mF6580068667EE3E5AB1FC12112DB39B359BC3A95 (void);
// 0x00000375 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::GetLinePoints(UnityEngine.Vector3[]&,System.Int32&)
extern void XRRayInteractor_GetLinePoints_m0A66C8DAE1B16CC5A34788E2112AA3D5FCB2D5DA (void);
// 0x00000376 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::EnsureCapacity(UnityEngine.Vector3[]&,System.Int32)
extern void XRRayInteractor_EnsureCapacity_mE8E8D17AD034BD24C158A6EDC7A7949DEA20D731 (void);
// 0x00000377 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TryGetHitInfo(UnityEngine.Vector3&,UnityEngine.Vector3&,System.Int32&,System.Boolean&)
extern void XRRayInteractor_TryGetHitInfo_mCC8B3B99CCA30572E3B29C7E9C019BD79E8B99BE (void);
// 0x00000378 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::UpdateUIModel(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel&)
extern void XRRayInteractor_UpdateUIModel_m9D7E4BFD4DDC1932D8F70BCECF4708B9E10B3FE2 (void);
// 0x00000379 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TryGetUIModel(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel&)
extern void XRRayInteractor_TryGetUIModel_m5A62C29FAE2BFE162FF9FB1B81C79D273CDCCD58 (void);
// 0x0000037A System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TryGetCurrent3DRaycastHit(UnityEngine.RaycastHit&)
extern void XRRayInteractor_TryGetCurrent3DRaycastHit_m3B0B4ECA2D4B2786F08B42F1BA327D63706BB060 (void);
// 0x0000037B System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TryGetCurrent3DRaycastHit(UnityEngine.RaycastHit&,System.Int32&)
extern void XRRayInteractor_TryGetCurrent3DRaycastHit_mAA8EF4BE6DC36D08FBB27625B19932826D1EEBEF (void);
// 0x0000037C System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TryGetCurrentUIRaycastResult(UnityEngine.EventSystems.RaycastResult&)
extern void XRRayInteractor_TryGetCurrentUIRaycastResult_m51500817ADD5ED072A6AB56F324BC3F501DEFDF4 (void);
// 0x0000037D System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TryGetCurrentUIRaycastResult(UnityEngine.EventSystems.RaycastResult&,System.Int32&)
extern void XRRayInteractor_TryGetCurrentUIRaycastResult_m291ECE81D6B7582175946E2E70A31E6C88D7E132 (void);
// 0x0000037E System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TryGetCurrentRaycast(System.Nullable`1<UnityEngine.RaycastHit>&,System.Int32&,System.Nullable`1<UnityEngine.EventSystems.RaycastResult>&,System.Int32&,System.Boolean&)
extern void XRRayInteractor_TryGetCurrentRaycast_mF6C0E3DE22A6CF5FD8777CC2837C3F79E215E5F3 (void);
// 0x0000037F System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::UpdateBezierControlPoints()
extern void XRRayInteractor_UpdateBezierControlPoints_m32476399E92C7D1118FD71446BC47906508685DD (void);
// 0x00000380 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::SampleQuadraticBezierPoint(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void XRRayInteractor_SampleQuadraticBezierPoint_m90C9882FEC10F1EE9925A4637CEDFCD4D3443F81 (void);
// 0x00000381 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::SampleCubicBezierPoint(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void XRRayInteractor_SampleCubicBezierPoint_mD49879E296C290AFD84AC71CFB66C3AA83708095 (void);
// 0x00000382 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::ElevateQuadraticToCubicBezier(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void XRRayInteractor_ElevateQuadraticToCubicBezier_m93EB3858AEB9EB176CE5EB9F34B1B2DF3A77930F (void);
// 0x00000383 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::SampleProjectilePoint(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void XRRayInteractor_SampleProjectilePoint_m805B768AC3DEA5EB8116CDD8FFF24924894A4896 (void);
// 0x00000384 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::CalculateProjectileParameters(UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&,System.Single&)
extern void XRRayInteractor_CalculateProjectileParameters_m0C33EABD7A60F32DB66E3C569E9D8A7F1CE76F82 (void);
// 0x00000385 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TryRead2DAxis(UnityEngine.InputSystem.InputAction,UnityEngine.Vector2&)
extern void XRRayInteractor_TryRead2DAxis_m0411C43079185297C2BA4986DCEFBD2572F7C18E (void);
// 0x00000386 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::RotateAnchor(UnityEngine.Transform,System.Single)
extern void XRRayInteractor_RotateAnchor_m6CA24C650C70FCCC35CDDFDF07E8912C61005CA6 (void);
// 0x00000387 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TranslateAnchor(UnityEngine.Transform,UnityEngine.Transform,System.Single)
extern void XRRayInteractor_TranslateAnchor_m491B098760F389BB13DD7660C75A3D3F3A8873B7 (void);
// 0x00000388 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::PreprocessInteractor(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRRayInteractor_PreprocessInteractor_m02BC9E78B3F2B6B2890980388E0E955D80FDF010 (void);
// 0x00000389 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::ProcessInteractor(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRRayInteractor_ProcessInteractor_mB44555B7A4E1A1B9C1DB59F45685CC43119DD0E2 (void);
// 0x0000038A System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::GetValidTargets(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>)
extern void XRRayInteractor_GetValidTargets_mA53EDC8BC750BD42FF2CAB4DC6A84D7E2405048E (void);
// 0x0000038B System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::UpdateSamplePoints(System.Int32,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/SamplePoint>)
extern void XRRayInteractor_UpdateSamplePoints_mDEDA5492A7F0C1E613C0F72F733D8919FD4F2012 (void);
// 0x0000038C System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::UpdateRaycastHits()
extern void XRRayInteractor_UpdateRaycastHits_m196A1AFACB4DAAE67BE11459AC4D80BA2CA04951 (void);
// 0x0000038D System.Int32 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::CheckCollidersBetweenPoints(UnityEngine.Vector3,UnityEngine.Vector3)
extern void XRRayInteractor_CheckCollidersBetweenPoints_m855D3B039C534E465B3FEF624D8CFBC8DA588843 (void);
// 0x0000038E System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::UpdateUIHitIndex()
extern void XRRayInteractor_UpdateUIHitIndex_m2A351D458844411CC5C147083FCDB32FD8EB1526 (void);
// 0x0000038F System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::CreateBezierCurve(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/SamplePoint>,System.Int32,UnityEngine.Vector3[])
extern void XRRayInteractor_CreateBezierCurve_mBF1A2D289709988BB88B6D5860AEF2B7132AE25D (void);
// 0x00000390 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_isSelectActive()
extern void XRRayInteractor_get_isSelectActive_m206586FAAB8EC9DA9B38230E326249258C7AAF37 (void);
// 0x00000391 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::CanHover(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable)
extern void XRRayInteractor_CanHover_m83C4143E4713D800E3650921204058CD0E29A597 (void);
// 0x00000392 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::CanSelect(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRRayInteractor_CanSelect_m6C48CE11344832B567F42EC86397252B83030D87 (void);
// 0x00000393 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::OnSelectEntering(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRRayInteractor_OnSelectEntering_mB2B1497AA544B96A53440D9049B554C9FA44D4AA (void);
// 0x00000394 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::OnSelectExiting(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRRayInteractor_OnSelectExiting_m83151373B9CB8001E3EE4A79DF2151D3B4197458 (void);
// 0x00000395 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::RestoreAttachTransform()
extern void XRRayInteractor_RestoreAttachTransform_m6C4F246238BB5DF30C37D3F35C03CFC55D3534F3 (void);
// 0x00000396 System.Int32 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::SanitizeSampleFrequency(System.Int32)
extern void XRRayInteractor_SanitizeSampleFrequency_mF485E0CCC8D8E8E919B358A9C49BCC689A1528EA (void);
// 0x00000397 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_Velocity()
extern void XRRayInteractor_get_Velocity_mCD63C7939FBB4BA47614FA62F4DECF7C5D44A120 (void);
// 0x00000398 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_Velocity(System.Single)
extern void XRRayInteractor_set_Velocity_mB55BCA00A7DF34D49D13A83D4662B21E7E4BA88B (void);
// 0x00000399 System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_Acceleration()
extern void XRRayInteractor_get_Acceleration_m26D3B9D340ECB09BC42A91A1440DDE91ADFCCD65 (void);
// 0x0000039A System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_Acceleration(System.Single)
extern void XRRayInteractor_set_Acceleration_m3D085078F4375C5BA693CA1E935D11FB3B109B4F (void);
// 0x0000039B System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_AdditionalFlightTime()
extern void XRRayInteractor_get_AdditionalFlightTime_mF3106B8247839BE357F725AE725C39B8FA1A1F15 (void);
// 0x0000039C System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_AdditionalFlightTime(System.Single)
extern void XRRayInteractor_set_AdditionalFlightTime_m17B9E6D48289E2D0E87D821DBEA0D40DBC17963E (void);
// 0x0000039D System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_Angle()
extern void XRRayInteractor_get_Angle_mB917C6D7C9B61C705326E9C9C3F5E9C065AB790C (void);
// 0x0000039E UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::get_originalAttachTransform()
extern void XRRayInteractor_get_originalAttachTransform_m878213826A5E8E8D42D348256F47AA993B52B57C (void);
// 0x0000039F System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::set_originalAttachTransform(UnityEngine.Transform)
extern void XRRayInteractor_set_originalAttachTransform_m628968BCB4571B08EC03FE401AFC37A326F80F4B (void);
// 0x000003A0 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::GetLinePoints(UnityEngine.Vector3[]&,System.Int32&,System.Int32)
extern void XRRayInteractor_GetLinePoints_m28A2F91AC58CDF03D4AAAACA499798D4E886221E (void);
// 0x000003A1 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::TryGetHitInfo(UnityEngine.Vector3&,UnityEngine.Vector3&,System.Int32&,System.Boolean&,System.Int32)
extern void XRRayInteractor_TryGetHitInfo_m6B340EAA6F108EDC34C2004028CD87D0D0B93F98 (void);
// 0x000003A2 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::GetCurrentRaycastHit(UnityEngine.RaycastHit&)
extern void XRRayInteractor_GetCurrentRaycastHit_mDCBAE2A7314764499EF43F973CFA848C7A2E6D67 (void);
// 0x000003A3 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::CanHover(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRRayInteractor_CanHover_m716D573DEC49A14606C4FD31B2DE42AE30BA0AD9 (void);
// 0x000003A4 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::CanSelect(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRRayInteractor_CanSelect_m916F1D170407BF398BBC3CAD1FCD1458AC76E297 (void);
// 0x000003A5 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::.ctor()
extern void XRRayInteractor__ctor_mC79035FCCEC9CAAA160A4834B82D3E09C3423138 (void);
// 0x000003A6 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor::.cctor()
extern void XRRayInteractor__cctor_m72311321B348BBFD73F73E61B25A439AAA11B624 (void);
// 0x000003A7 System.Int32 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/RaycastHitComparer::Compare(UnityEngine.RaycastHit,UnityEngine.RaycastHit)
extern void RaycastHitComparer_Compare_mEF9D90C17CB04E5FE07303C5F8D4FC0F992FE8E1 (void);
// 0x000003A8 System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/RaycastHitComparer::.ctor()
extern void RaycastHitComparer__ctor_mF4CD20A7FEB0D6BE43809FAA21EC3EE87798A8C2 (void);
// 0x000003A9 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/SamplePoint::get_position()
extern void SamplePoint_get_position_mF9D3DAA244F75823D675144E555BEAC9776CC8E6 (void);
// 0x000003AA System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/SamplePoint::set_position(UnityEngine.Vector3)
extern void SamplePoint_set_position_m7DB8D7915D8C065E2138825C1ECF29460A450633 (void);
// 0x000003AB System.Single UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/SamplePoint::get_parameter()
extern void SamplePoint_get_parameter_m3B1DB18CF168339E8153E33E2FC87983549940BB (void);
// 0x000003AC System.Void UnityEngine.XR.Interaction.Toolkit.XRRayInteractor/SamplePoint::set_parameter(System.Single)
extern void SamplePoint_set_parameter_mBEAD6B1E02633C8CA26116F89AFDCBC10D3273F3 (void);
// 0x000003AD System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_showInteractableHoverMeshes()
extern void XRSocketInteractor_get_showInteractableHoverMeshes_mA13C3376AE7EC382FC9D3FE3D40F2CF937069C60 (void);
// 0x000003AE System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::set_showInteractableHoverMeshes(System.Boolean)
extern void XRSocketInteractor_set_showInteractableHoverMeshes_m272B2E3F1A0DE579705D7E0D449D20567FCEC515 (void);
// 0x000003AF UnityEngine.Material UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_interactableHoverMeshMaterial()
extern void XRSocketInteractor_get_interactableHoverMeshMaterial_m4F7DC269C114A9B2D8AE22A3D0B0CF503D77BB12 (void);
// 0x000003B0 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::set_interactableHoverMeshMaterial(UnityEngine.Material)
extern void XRSocketInteractor_set_interactableHoverMeshMaterial_m9228A178C2C0EFAB69382C078B599FC0229EC1C7 (void);
// 0x000003B1 UnityEngine.Material UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_interactableCantHoverMeshMaterial()
extern void XRSocketInteractor_get_interactableCantHoverMeshMaterial_m7D51DD8B38B538CECE017115519004783602E2CA (void);
// 0x000003B2 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::set_interactableCantHoverMeshMaterial(UnityEngine.Material)
extern void XRSocketInteractor_set_interactableCantHoverMeshMaterial_m6B60D3C1A552AA62352EF47F6120599A0E05A27D (void);
// 0x000003B3 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_socketActive()
extern void XRSocketInteractor_get_socketActive_m279A07381397CFA72029326EC820EDDC35C18410 (void);
// 0x000003B4 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::set_socketActive(System.Boolean)
extern void XRSocketInteractor_set_socketActive_m63F82455B5998A4A68851C3CD6864147E6FDE95A (void);
// 0x000003B5 System.Single UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_interactableHoverScale()
extern void XRSocketInteractor_get_interactableHoverScale_m5915E69E6876CA574F17EFA91DE62C8913690AD5 (void);
// 0x000003B6 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::set_interactableHoverScale(System.Single)
extern void XRSocketInteractor_set_interactableHoverScale_m633D3EE46EEC77B3ED8C642ADCB782E4273D81E2 (void);
// 0x000003B7 System.Single UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_recycleDelayTime()
extern void XRSocketInteractor_get_recycleDelayTime_mE91A9F5EC67DDF587F5B93ADA2470289534E7A9D (void);
// 0x000003B8 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::set_recycleDelayTime(System.Single)
extern void XRSocketInteractor_set_recycleDelayTime_m8CF70510C2980DBEBD33DC01851EA17989D0EA06 (void);
// 0x000003B9 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable> UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_unsortedValidTargets()
extern void XRSocketInteractor_get_unsortedValidTargets_m4791BE8637A59493A2F196731269FE9FBE2F43D8 (void);
// 0x000003BA System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::Awake()
extern void XRSocketInteractor_Awake_m728DB8B4F55AFA12CC3D687C2110F2BC78291B55 (void);
// 0x000003BB System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::Start()
extern void XRSocketInteractor_Start_mD0A89E30DF8007E31B271E1846F6C6847D3CD59D (void);
// 0x000003BC System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnTriggerEnter(UnityEngine.Collider)
extern void XRSocketInteractor_OnTriggerEnter_m13762BE126D57C1CC81D8C80222B48ED2554C73F (void);
// 0x000003BD System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnTriggerStay(UnityEngine.Collider)
extern void XRSocketInteractor_OnTriggerStay_mBD77351B76D9187648140A5F06229FF680D992CC (void);
// 0x000003BE System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnTriggerExit(UnityEngine.Collider)
extern void XRSocketInteractor_OnTriggerExit_m370FE0D3027D577166A1C89B7156AC423943F2B3 (void);
// 0x000003BF System.Collections.IEnumerator UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::UpdateCollidersAfterOnTriggerStay()
extern void XRSocketInteractor_UpdateCollidersAfterOnTriggerStay_mE2762B59E6A798AADD446169E4E6EB2C719C7637 (void);
// 0x000003C0 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::ProcessInteractor(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRSocketInteractor_ProcessInteractor_mF5DFFB7FEC471C2783C6D58161C3B8135D6D2928 (void);
// 0x000003C1 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::CreateDefaultHoverMaterials()
extern void XRSocketInteractor_CreateDefaultHoverMaterials_m9A28D7BBCF909D05A6DBC5DC58FF5E162A12748D (void);
// 0x000003C2 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::SetMaterialFade(UnityEngine.Material,UnityEngine.Color)
extern void XRSocketInteractor_SetMaterialFade_m512ACFE82C5B051448A4B5B737686BE919545B17 (void);
// 0x000003C3 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnHoverEntering(UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRSocketInteractor_OnHoverEntering_mC37B527C1D74305B6CFD2DC256750559431111CE (void);
// 0x000003C4 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnHoverExiting(UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRSocketInteractor_OnHoverExiting_mB74BF3AF6152D71F3FF0BB3B20133A89829625C4 (void);
// 0x000003C5 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnSelectExiting(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRSocketInteractor_OnSelectExiting_m31DFB98912AA8B4C3CDAE3BD1DC34319882550C7 (void);
// 0x000003C6 UnityEngine.Matrix4x4 UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::GetHoverMeshMatrix(UnityEngine.XR.Interaction.Toolkit.IXRInteractable,UnityEngine.MeshFilter,System.Single)
extern void XRSocketInteractor_GetHoverMeshMatrix_m01CF4E9023D39BD70A32749885212E6BF37523AE (void);
// 0x000003C7 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::InverseTransformDirection(UnityEngine.Pose,UnityEngine.Vector3)
extern void XRSocketInteractor_InverseTransformDirection_mA06E0ABA71FEB0A1E836636DA931DFEF8A9472EF (void);
// 0x000003C8 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::DrawHoveredInteractables()
extern void XRSocketInteractor_DrawHoveredInteractables_m3FBB4ABEA1AA9F751AF7DE4F988BCA1F676705F0 (void);
// 0x000003C9 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::GetValidTargets(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>)
extern void XRSocketInteractor_GetValidTargets_mE2F539502B602807FC850F4EE596AF5AA34260F7 (void);
// 0x000003CA System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_isHoverActive()
extern void XRSocketInteractor_get_isHoverActive_m8D9CD29DF67452E89C121AFA36726CC067C870C3 (void);
// 0x000003CB System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_isSelectActive()
extern void XRSocketInteractor_get_isSelectActive_m639D46E618AE693D40C7F9EBCE756204E9A7BDD1 (void);
// 0x000003CC System.Nullable`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable/MovementType> UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_selectedInteractableMovementTypeOverride()
extern void XRSocketInteractor_get_selectedInteractableMovementTypeOverride_mC823C78833056F46E2F1ED83D10AC621408E6270 (void);
// 0x000003CD System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::CanHover(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable)
extern void XRSocketInteractor_CanHover_mC11E4C207BD6D5C2436146D6730190861E82F460 (void);
// 0x000003CE System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::get_isHoverRecycleAllowed()
extern void XRSocketInteractor_get_isHoverRecycleAllowed_mB3F7E667E924A3EE7BD763A62B0ECDBE788041BB (void);
// 0x000003CF System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::CanSelect(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRSocketInteractor_CanSelect_mDF980B26B103D799D1D7A775B6F7B7BCAE1753D1 (void);
// 0x000003D0 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::ShouldDrawHoverMesh(UnityEngine.MeshFilter,UnityEngine.Renderer,UnityEngine.Camera)
extern void XRSocketInteractor_ShouldDrawHoverMesh_m804C0F4ACE8D7225A0AC0FCF769FE724747B3445 (void);
// 0x000003D1 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnRegistered(UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs)
extern void XRSocketInteractor_OnRegistered_mDA4725A07484B6E5B652271481629A503410A6FE (void);
// 0x000003D2 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnUnregistered(UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs)
extern void XRSocketInteractor_OnUnregistered_m692446CD32442D8402070097B53C708E4B8E9493 (void);
// 0x000003D3 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnInteractableRegistered(UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs)
extern void XRSocketInteractor_OnInteractableRegistered_m9F6CFAEE4375AFD39BB7E6118FDD5A1D35A89C57 (void);
// 0x000003D4 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnInteractableUnregistered(UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs)
extern void XRSocketInteractor_OnInteractableUnregistered_m8B22001876BF4F03AC42C85F5B0E5E13E9A8A602 (void);
// 0x000003D5 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnContactAdded(UnityEngine.XR.Interaction.Toolkit.IXRInteractable)
extern void XRSocketInteractor_OnContactAdded_mFB2698788AF6FF8A135AFF77141E8F3300D66094 (void);
// 0x000003D6 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::OnContactRemoved(UnityEngine.XR.Interaction.Toolkit.IXRInteractable)
extern void XRSocketInteractor_OnContactRemoved_mB0529B0AAE3A02A975B24614DBC21B379CB23CAD (void);
// 0x000003D7 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::CanHover(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRSocketInteractor_CanHover_mD06D9A7A3E164FE555F88B874F8FD5412E178C52 (void);
// 0x000003D8 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::CanSelect(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRSocketInteractor_CanSelect_m3EC7D7A0594FB1F3E602DAD01E1DD8A3DE323BC5 (void);
// 0x000003D9 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::.ctor()
extern void XRSocketInteractor__ctor_m5976C30C655C920BB7D715E7703471C2695DC48B (void);
// 0x000003DA System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor::.cctor()
extern void XRSocketInteractor__cctor_mDCA455BA7F7550272F36D6936329DF647F5B9154 (void);
// 0x000003DB System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor/ShaderPropertyLookup::.cctor()
extern void ShaderPropertyLookup__cctor_m1A59E24DA3A24CE183DF3916009DE66C992A5A6C (void);
// 0x000003DC System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor/<UpdateCollidersAfterOnTriggerStay>d__38::.ctor(System.Int32)
extern void U3CUpdateCollidersAfterOnTriggerStayU3Ed__38__ctor_m6E5C86A23AD575C538B8349A7C97D790B44D6190 (void);
// 0x000003DD System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor/<UpdateCollidersAfterOnTriggerStay>d__38::System.IDisposable.Dispose()
extern void U3CUpdateCollidersAfterOnTriggerStayU3Ed__38_System_IDisposable_Dispose_m35DB36F4FD9BAE666D067BABF4DA9CF7801AFD2D (void);
// 0x000003DE System.Boolean UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor/<UpdateCollidersAfterOnTriggerStay>d__38::MoveNext()
extern void U3CUpdateCollidersAfterOnTriggerStayU3Ed__38_MoveNext_m89AB7549E7DD618512E2A8F916364BE317FB9B1B (void);
// 0x000003DF System.Object UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor/<UpdateCollidersAfterOnTriggerStay>d__38::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CUpdateCollidersAfterOnTriggerStayU3Ed__38_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mA53C39E84D14DC4A3BE1AC43AAFB7A8AE7D3AFED (void);
// 0x000003E0 System.Void UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor/<UpdateCollidersAfterOnTriggerStay>d__38::System.Collections.IEnumerator.Reset()
extern void U3CUpdateCollidersAfterOnTriggerStayU3Ed__38_System_Collections_IEnumerator_Reset_m286FBDD6AE03892803862915F5E2B23AF55BBD7A (void);
// 0x000003E1 System.Object UnityEngine.XR.Interaction.Toolkit.XRSocketInteractor/<UpdateCollidersAfterOnTriggerStay>d__38::System.Collections.IEnumerator.get_Current()
extern void U3CUpdateCollidersAfterOnTriggerStayU3Ed__38_System_Collections_IEnumerator_get_Current_mB7B81869F309CE1962760101F8247DC63334C5FB (void);
// 0x000003E2 System.Int32 UnityEngine.XR.Interaction.Toolkit.InteractionLayerMask::op_Implicit(UnityEngine.XR.Interaction.Toolkit.InteractionLayerMask)
extern void InteractionLayerMask_op_Implicit_m08C4E510BDA50EADE9029D9FF0D811ED7E1C8DB7 (void);
// 0x000003E3 UnityEngine.XR.Interaction.Toolkit.InteractionLayerMask UnityEngine.XR.Interaction.Toolkit.InteractionLayerMask::op_Implicit(System.Int32)
extern void InteractionLayerMask_op_Implicit_m0CA28CDA57CD4D9EE8A9881078BD4546D0D93F26 (void);
// 0x000003E4 System.Int32 UnityEngine.XR.Interaction.Toolkit.InteractionLayerMask::get_value()
extern void InteractionLayerMask_get_value_m1DE10E281BAC55AC711581379777370B8D0EF4AF (void);
// 0x000003E5 System.Void UnityEngine.XR.Interaction.Toolkit.InteractionLayerMask::set_value(System.Int32)
extern void InteractionLayerMask_set_value_m59C5C67FB2CC2DCC65CD752B56F3B74E229899E4 (void);
// 0x000003E6 System.String UnityEngine.XR.Interaction.Toolkit.InteractionLayerMask::LayerToName(System.Int32)
extern void InteractionLayerMask_LayerToName_m41AB95A8FBC26C037B4A245D22B01CAD3094D8F6 (void);
// 0x000003E7 System.Int32 UnityEngine.XR.Interaction.Toolkit.InteractionLayerMask::NameToLayer(System.String)
extern void InteractionLayerMask_NameToLayer_m66F30E9BE29227B5430F9351ECB47FBA2B186A0B (void);
// 0x000003E8 System.Int32 UnityEngine.XR.Interaction.Toolkit.InteractionLayerMask::GetMask(System.String[])
extern void InteractionLayerMask_GetMask_mCC20AFA8EF6565328C4F137F19E2F20740A6D4A9 (void);
// 0x000003E9 System.Void UnityEngine.XR.Interaction.Toolkit.InteractionLayerMask::OnAfterDeserialize()
extern void InteractionLayerMask_OnAfterDeserialize_m3FDFE3DE357CFE1B8558ED7BDEC7DF4542BE4C58 (void);
// 0x000003EA System.Void UnityEngine.XR.Interaction.Toolkit.InteractionLayerMask::OnBeforeSerialize()
extern void InteractionLayerMask_OnBeforeSerialize_m673AD8B8D37CF455D65F3D6D3C8AE04C0C68D901 (void);
// 0x000003EB System.String UnityEngine.XR.Interaction.Toolkit.InteractionLayerSettings::GetLayerNameAt(System.Int32)
extern void InteractionLayerSettings_GetLayerNameAt_m94BF99E7DE7503FB3FBF45A46BBFAF639D98B645 (void);
// 0x000003EC System.Int32 UnityEngine.XR.Interaction.Toolkit.InteractionLayerSettings::GetLayer(System.String)
extern void InteractionLayerSettings_GetLayer_m2185EA5B60D38B1FC61C94A23525C38D7C198363 (void);
// 0x000003ED System.Void UnityEngine.XR.Interaction.Toolkit.InteractionLayerSettings::GetLayerNamesAndValues(System.Collections.Generic.List`1<System.String>,System.Collections.Generic.List`1<System.Int32>)
extern void InteractionLayerSettings_GetLayerNamesAndValues_mDA223C0C1FD17B21EF0229E8025CD306935189E3 (void);
// 0x000003EE System.Void UnityEngine.XR.Interaction.Toolkit.InteractionLayerSettings::OnBeforeSerialize()
extern void InteractionLayerSettings_OnBeforeSerialize_m8FB5F44C3F90306B0D6F8730A7C536BB83B78B86 (void);
// 0x000003EF System.Void UnityEngine.XR.Interaction.Toolkit.InteractionLayerSettings::OnAfterDeserialize()
extern void InteractionLayerSettings_OnAfterDeserialize_m25C6D4D26CCB1151473724E4651617B54ABFD4AF (void);
// 0x000003F0 System.Void UnityEngine.XR.Interaction.Toolkit.InteractionLayerSettings::.ctor()
extern void InteractionLayerSettings__ctor_mCF7AF5E963C37818AF6B842DAC8D013882DA21CE (void);
// 0x000003F1 UnityEngine.XR.Interaction.Toolkit.IXRInteractor UnityEngine.XR.Interaction.Toolkit.BaseInteractionEventArgs::get_interactorObject()
extern void BaseInteractionEventArgs_get_interactorObject_mDC483F1AAA1267A774B677E14189A3EDD1040864 (void);
// 0x000003F2 System.Void UnityEngine.XR.Interaction.Toolkit.BaseInteractionEventArgs::set_interactorObject(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
extern void BaseInteractionEventArgs_set_interactorObject_mAFCA4A8A7569428E3B2ADDBBCA1B98EE9D54B1D1 (void);
// 0x000003F3 UnityEngine.XR.Interaction.Toolkit.IXRInteractable UnityEngine.XR.Interaction.Toolkit.BaseInteractionEventArgs::get_interactableObject()
extern void BaseInteractionEventArgs_get_interactableObject_m26541C3E132246CFFA125A00BB3605DB8E3F72D3 (void);
// 0x000003F4 System.Void UnityEngine.XR.Interaction.Toolkit.BaseInteractionEventArgs::set_interactableObject(UnityEngine.XR.Interaction.Toolkit.IXRInteractable)
extern void BaseInteractionEventArgs_set_interactableObject_m666E479700814D51AB92B1A2279D30B7D91117D9 (void);
// 0x000003F5 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor UnityEngine.XR.Interaction.Toolkit.BaseInteractionEventArgs::get_interactor()
extern void BaseInteractionEventArgs_get_interactor_mE0AC419B526DA1A39B56DA244258474047DD0176 (void);
// 0x000003F6 System.Void UnityEngine.XR.Interaction.Toolkit.BaseInteractionEventArgs::set_interactor(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void BaseInteractionEventArgs_set_interactor_mD8877C3687E32637F0E1F67F83B4B0B8AF91C649 (void);
// 0x000003F7 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable UnityEngine.XR.Interaction.Toolkit.BaseInteractionEventArgs::get_interactable()
extern void BaseInteractionEventArgs_get_interactable_mE03A040C395B75F0EB35E1CE5371458C1345BD45 (void);
// 0x000003F8 System.Void UnityEngine.XR.Interaction.Toolkit.BaseInteractionEventArgs::set_interactable(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void BaseInteractionEventArgs_set_interactable_m2F82CCB58107BAB47A77981E751779A7A4FA3266 (void);
// 0x000003F9 System.Void UnityEngine.XR.Interaction.Toolkit.BaseInteractionEventArgs::.ctor()
extern void BaseInteractionEventArgs__ctor_mFBE9F5A938004146A92AFBA8FC7382B4CE7F7995 (void);
// 0x000003FA System.Void UnityEngine.XR.Interaction.Toolkit.TeleportingEvent::.ctor()
extern void TeleportingEvent__ctor_m6500A5219DA0E3B6C0BD6B6FBA212E6968AAB2AD (void);
// 0x000003FB UnityEngine.XR.Interaction.Toolkit.TeleportRequest UnityEngine.XR.Interaction.Toolkit.TeleportingEventArgs::get_teleportRequest()
extern void TeleportingEventArgs_get_teleportRequest_m826263B8C3497EDADB982081053273A9F35AA73E (void);
// 0x000003FC System.Void UnityEngine.XR.Interaction.Toolkit.TeleportingEventArgs::set_teleportRequest(UnityEngine.XR.Interaction.Toolkit.TeleportRequest)
extern void TeleportingEventArgs_set_teleportRequest_m7689B96CF5C675E696667AD065575DBE5EB41A0D (void);
// 0x000003FD System.Void UnityEngine.XR.Interaction.Toolkit.TeleportingEventArgs::.ctor()
extern void TeleportingEventArgs__ctor_m99DD9DD2A593D6838DAF382428A3FC9DB4352C92 (void);
// 0x000003FE System.Void UnityEngine.XR.Interaction.Toolkit.HoverEnterEvent::.ctor()
extern void HoverEnterEvent__ctor_mBA15FC5A5D70A50E4508C1AD60B798C433520D5C (void);
// 0x000003FF UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs::get_interactorObject()
extern void HoverEnterEventArgs_get_interactorObject_m9735CAB1FCE64F6DD65498458C582463A0FB5D19 (void);
// 0x00000400 System.Void UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs::set_interactorObject(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor)
extern void HoverEnterEventArgs_set_interactorObject_m938429D32D4E2C1771EDA7A6FFAE91F6928946B2 (void);
// 0x00000401 UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs::get_interactableObject()
extern void HoverEnterEventArgs_get_interactableObject_mF3402C9ABF2BBFBABE7847BD3F97DA76DBB047E0 (void);
// 0x00000402 System.Void UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs::set_interactableObject(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable)
extern void HoverEnterEventArgs_set_interactableObject_mF7B2CDEFA249D49A8C9CD38D4880843D30EF3B7D (void);
// 0x00000403 UnityEngine.XR.Interaction.Toolkit.XRInteractionManager UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs::get_manager()
extern void HoverEnterEventArgs_get_manager_m7BF0809EFB35384B071E9F1749BD918F9B8EF9C4 (void);
// 0x00000404 System.Void UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs::set_manager(UnityEngine.XR.Interaction.Toolkit.XRInteractionManager)
extern void HoverEnterEventArgs_set_manager_m158A6A9C6E07649471E84928B795E07528C824AF (void);
// 0x00000405 System.Void UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs::.ctor()
extern void HoverEnterEventArgs__ctor_m64B2FD3D0E28418D562AB3E809D4D41FB73B61F5 (void);
// 0x00000406 System.Void UnityEngine.XR.Interaction.Toolkit.HoverExitEvent::.ctor()
extern void HoverExitEvent__ctor_mC6DCAF3BA7DD1BF2D25E0E94D1DFDF8BB69F6599 (void);
// 0x00000407 UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs::get_interactorObject()
extern void HoverExitEventArgs_get_interactorObject_m0018175DBF0540C147451C1E11B5EE5DA64CB150 (void);
// 0x00000408 System.Void UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs::set_interactorObject(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor)
extern void HoverExitEventArgs_set_interactorObject_mCABC016A89E81C1CB36A8B1EBE4E8B6CCCD69ED7 (void);
// 0x00000409 UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs::get_interactableObject()
extern void HoverExitEventArgs_get_interactableObject_mE6E7CF97FC9B0F33216BC872B5574A5D367E654C (void);
// 0x0000040A System.Void UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs::set_interactableObject(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable)
extern void HoverExitEventArgs_set_interactableObject_m12E7E0DCFCBF9A059844083C911DC1CADF177F52 (void);
// 0x0000040B UnityEngine.XR.Interaction.Toolkit.XRInteractionManager UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs::get_manager()
extern void HoverExitEventArgs_get_manager_mFDACB06544FBF52A43FB64EC4BCDCFAEAB40AAC0 (void);
// 0x0000040C System.Void UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs::set_manager(UnityEngine.XR.Interaction.Toolkit.XRInteractionManager)
extern void HoverExitEventArgs_set_manager_mA18E069893E2011A5DC128198EBA4E504D7F8D3C (void);
// 0x0000040D System.Boolean UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs::get_isCanceled()
extern void HoverExitEventArgs_get_isCanceled_mCD404A43E8B419E9C4A66AE69F74CBF4840B80FF (void);
// 0x0000040E System.Void UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs::set_isCanceled(System.Boolean)
extern void HoverExitEventArgs_set_isCanceled_mD30ECFAFDE30B96DB1C4BA30800D72D6CC31218C (void);
// 0x0000040F System.Void UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs::.ctor()
extern void HoverExitEventArgs__ctor_mE583F8ECA5AA5CD5766A4819840CF8AA29473223 (void);
// 0x00000410 System.Void UnityEngine.XR.Interaction.Toolkit.SelectEnterEvent::.ctor()
extern void SelectEnterEvent__ctor_mBD914CC3077CB09488C19CB000BF84A8CF4075FA (void);
// 0x00000411 UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs::get_interactorObject()
extern void SelectEnterEventArgs_get_interactorObject_m97F5CFDD451F9E85F5B92FD2B3E668A43B1C146C (void);
// 0x00000412 System.Void UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs::set_interactorObject(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor)
extern void SelectEnterEventArgs_set_interactorObject_mD6F6E386DB5DEEEB5D8E10D39781726C63CD5C3F (void);
// 0x00000413 UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs::get_interactableObject()
extern void SelectEnterEventArgs_get_interactableObject_m1BF44240E99A894B17EE07BBBC4B6AA6D1058DD2 (void);
// 0x00000414 System.Void UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs::set_interactableObject(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void SelectEnterEventArgs_set_interactableObject_m47DD9FF8C3D93D8DE88E40EAA071D11DDBFC0718 (void);
// 0x00000415 UnityEngine.XR.Interaction.Toolkit.XRInteractionManager UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs::get_manager()
extern void SelectEnterEventArgs_get_manager_m26C686181BAFB4304EBA14BEDB47C75D9826B7E4 (void);
// 0x00000416 System.Void UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs::set_manager(UnityEngine.XR.Interaction.Toolkit.XRInteractionManager)
extern void SelectEnterEventArgs_set_manager_mAB91B3764075B4953BBEED2CFDAC395CC624C7D9 (void);
// 0x00000417 System.Void UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs::.ctor()
extern void SelectEnterEventArgs__ctor_mE74661F8720305C7C924ADBA1766057084A1D264 (void);
// 0x00000418 System.Void UnityEngine.XR.Interaction.Toolkit.SelectExitEvent::.ctor()
extern void SelectExitEvent__ctor_m3F1845BDE2ADD85BE5B34309656DE33AB8BE65AC (void);
// 0x00000419 UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs::get_interactorObject()
extern void SelectExitEventArgs_get_interactorObject_m395880E1D46E6008A4AA90836393E4F1E39CAAA3 (void);
// 0x0000041A System.Void UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs::set_interactorObject(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor)
extern void SelectExitEventArgs_set_interactorObject_m5C1FF7816358E5BCB016ED0C7DCA5725C6BAA8F3 (void);
// 0x0000041B UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs::get_interactableObject()
extern void SelectExitEventArgs_get_interactableObject_mDF1FCDA090159514365D791FB3DFA9A7CFE634B6 (void);
// 0x0000041C System.Void UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs::set_interactableObject(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void SelectExitEventArgs_set_interactableObject_mED2657D7556DD5E69DEBC70668C9A47C7444954C (void);
// 0x0000041D UnityEngine.XR.Interaction.Toolkit.XRInteractionManager UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs::get_manager()
extern void SelectExitEventArgs_get_manager_m0EC8623D5F0EF3296433E5F3E2FD0F6F3D42B387 (void);
// 0x0000041E System.Void UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs::set_manager(UnityEngine.XR.Interaction.Toolkit.XRInteractionManager)
extern void SelectExitEventArgs_set_manager_m041398DAAD78BF90C51FA159C8213120F25A0D88 (void);
// 0x0000041F System.Boolean UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs::get_isCanceled()
extern void SelectExitEventArgs_get_isCanceled_m4C9FCCB6A51201B8728DAF9BA356BB589A149FF7 (void);
// 0x00000420 System.Void UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs::set_isCanceled(System.Boolean)
extern void SelectExitEventArgs_set_isCanceled_mCD4C4244EBD5D443FD62B581F29FF05B2751AF42 (void);
// 0x00000421 System.Void UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs::.ctor()
extern void SelectExitEventArgs__ctor_mF2917F17EA7F2AD8B1698AE1E4D5C3B9F0225A69 (void);
// 0x00000422 System.Void UnityEngine.XR.Interaction.Toolkit.ActivateEvent::.ctor()
extern void ActivateEvent__ctor_mE03DD9A189FB311D8AC4BD2C02D4E5E29C66CFA3 (void);
// 0x00000423 UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractor UnityEngine.XR.Interaction.Toolkit.ActivateEventArgs::get_interactorObject()
extern void ActivateEventArgs_get_interactorObject_mCE290719C5F47593EA43F4B6D015BD62D9886E1D (void);
// 0x00000424 System.Void UnityEngine.XR.Interaction.Toolkit.ActivateEventArgs::set_interactorObject(UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractor)
extern void ActivateEventArgs_set_interactorObject_m2E18040B549E170B89EA2E4CB67E840BC02FB3BA (void);
// 0x00000425 UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractable UnityEngine.XR.Interaction.Toolkit.ActivateEventArgs::get_interactableObject()
extern void ActivateEventArgs_get_interactableObject_m4C814BF602A7E2B5043E1EB1B817D64BCDD5EA1A (void);
// 0x00000426 System.Void UnityEngine.XR.Interaction.Toolkit.ActivateEventArgs::set_interactableObject(UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractable)
extern void ActivateEventArgs_set_interactableObject_m199252718AAFBFEF9360F92A3CEA925584B1CD53 (void);
// 0x00000427 System.Void UnityEngine.XR.Interaction.Toolkit.ActivateEventArgs::.ctor()
extern void ActivateEventArgs__ctor_m0F13A7B797CD0F08C6C81FA05374157ED0174798 (void);
// 0x00000428 System.Void UnityEngine.XR.Interaction.Toolkit.DeactivateEvent::.ctor()
extern void DeactivateEvent__ctor_m35BFEF1CB25E0CEE6C6D7D6A06B70EB9D9B141E1 (void);
// 0x00000429 UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractor UnityEngine.XR.Interaction.Toolkit.DeactivateEventArgs::get_interactorObject()
extern void DeactivateEventArgs_get_interactorObject_m8469FB820E50EC9170BB9C503EE34577D8DAB537 (void);
// 0x0000042A System.Void UnityEngine.XR.Interaction.Toolkit.DeactivateEventArgs::set_interactorObject(UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractor)
extern void DeactivateEventArgs_set_interactorObject_m441ECC2F19258EF07AA11FBAE0BF0C147DE32332 (void);
// 0x0000042B UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractable UnityEngine.XR.Interaction.Toolkit.DeactivateEventArgs::get_interactableObject()
extern void DeactivateEventArgs_get_interactableObject_mF441ABDF82A16D6182D9DF8B7DC01E2B04DB1926 (void);
// 0x0000042C System.Void UnityEngine.XR.Interaction.Toolkit.DeactivateEventArgs::set_interactableObject(UnityEngine.XR.Interaction.Toolkit.IXRActivateInteractable)
extern void DeactivateEventArgs_set_interactableObject_m32D35955F889F3E9337B58CA5E489D7E20321772 (void);
// 0x0000042D System.Void UnityEngine.XR.Interaction.Toolkit.DeactivateEventArgs::.ctor()
extern void DeactivateEventArgs__ctor_m7CBB9F171A35CB64534F7B9306D93F337FD2582C (void);
// 0x0000042E UnityEngine.XR.Interaction.Toolkit.XRInteractionManager UnityEngine.XR.Interaction.Toolkit.BaseRegistrationEventArgs::get_manager()
extern void BaseRegistrationEventArgs_get_manager_m84ED1D40C6386160D7158A59481F70348DD48413 (void);
// 0x0000042F System.Void UnityEngine.XR.Interaction.Toolkit.BaseRegistrationEventArgs::set_manager(UnityEngine.XR.Interaction.Toolkit.XRInteractionManager)
extern void BaseRegistrationEventArgs_set_manager_mDCA0E4515B5577A245206663B79F1BD793865AA5 (void);
// 0x00000430 System.Void UnityEngine.XR.Interaction.Toolkit.BaseRegistrationEventArgs::.ctor()
extern void BaseRegistrationEventArgs__ctor_m161AA13E866857D922FA734ECFC87A1A3915D681 (void);
// 0x00000431 UnityEngine.XR.Interaction.Toolkit.IXRInteractor UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs::get_interactorObject()
extern void InteractorRegisteredEventArgs_get_interactorObject_m3E9876ECB8E6998EBFBA8A28CC57E70B77A84A1C (void);
// 0x00000432 System.Void UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs::set_interactorObject(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
extern void InteractorRegisteredEventArgs_set_interactorObject_m0796FE5FD1653517D293F08CEC51B21B2051C557 (void);
// 0x00000433 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs::get_interactor()
extern void InteractorRegisteredEventArgs_get_interactor_m5941F52A62289266C834D92590783488A171FAD8 (void);
// 0x00000434 System.Void UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs::set_interactor(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void InteractorRegisteredEventArgs_set_interactor_mC7D4F7F96D374D0689576F9781A8059692A21B17 (void);
// 0x00000435 System.Void UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs::.ctor()
extern void InteractorRegisteredEventArgs__ctor_m1CEEB1E90C5E36396D47DEE555CA51EAF67E51A4 (void);
// 0x00000436 UnityEngine.XR.Interaction.Toolkit.IXRInteractable UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs::get_interactableObject()
extern void InteractableRegisteredEventArgs_get_interactableObject_m895A23B809D8B0DA415F16C644A4A4B93A8EB87A (void);
// 0x00000437 System.Void UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs::set_interactableObject(UnityEngine.XR.Interaction.Toolkit.IXRInteractable)
extern void InteractableRegisteredEventArgs_set_interactableObject_m0986611CA5A508142C0416D8EB09C0893916E3FC (void);
// 0x00000438 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs::get_interactable()
extern void InteractableRegisteredEventArgs_get_interactable_m8E24757B1B66EF6ED74A2BCC89A63E10364E7C6E (void);
// 0x00000439 System.Void UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs::set_interactable(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void InteractableRegisteredEventArgs_set_interactable_m8FAF324ECEAFDB5BD64BE2D71A991B9A3FDACBB4 (void);
// 0x0000043A System.Void UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs::.ctor()
extern void InteractableRegisteredEventArgs__ctor_m822E9B17C5624FD5DAC56EDDB45B0BBC559ED753 (void);
// 0x0000043B UnityEngine.XR.Interaction.Toolkit.IXRInteractor UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs::get_interactorObject()
extern void InteractorUnregisteredEventArgs_get_interactorObject_m6CC2A62AD00F985B8AF1E3EAC388F17966ED20B8 (void);
// 0x0000043C System.Void UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs::set_interactorObject(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
extern void InteractorUnregisteredEventArgs_set_interactorObject_m0D221058BC2E3F511EC39CECF4C26BB5A5A57FB0 (void);
// 0x0000043D UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs::get_interactor()
extern void InteractorUnregisteredEventArgs_get_interactor_m850F10AA69039103E6E674733DB4CA93C4369E65 (void);
// 0x0000043E System.Void UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs::set_interactor(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void InteractorUnregisteredEventArgs_set_interactor_m06E8669E5C820661A28255E6983ECD6FE607B4E9 (void);
// 0x0000043F System.Void UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs::.ctor()
extern void InteractorUnregisteredEventArgs__ctor_m4A66D6EAF8334F6DB39B8C23D81FF3641910F98F (void);
// 0x00000440 UnityEngine.XR.Interaction.Toolkit.IXRInteractable UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs::get_interactableObject()
extern void InteractableUnregisteredEventArgs_get_interactableObject_m741DCCDBE1F7476E90F779B28768D86CD0BD02D0 (void);
// 0x00000441 System.Void UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs::set_interactableObject(UnityEngine.XR.Interaction.Toolkit.IXRInteractable)
extern void InteractableUnregisteredEventArgs_set_interactableObject_mAD6A4A7E4190275B129316D796F2DFA1396E68C1 (void);
// 0x00000442 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs::get_interactable()
extern void InteractableUnregisteredEventArgs_get_interactable_m6B266EFCEBB22E4EE3F3E1F86E9D3D2E6F9BCA05 (void);
// 0x00000443 System.Void UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs::set_interactable(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void InteractableUnregisteredEventArgs_set_interactable_m0433D6227E005137B947C8C68C7131B2D3F7E1BF (void);
// 0x00000444 System.Void UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs::.ctor()
extern void InteractableUnregisteredEventArgs__ctor_m06876C6525B6E04247181AE3D01F172CD6CF8A9E (void);
// 0x00000445 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractableEvent::.ctor()
extern void XRInteractableEvent__ctor_mDDC1471E4ABA20B7E264547F4C6AF92D00FA373A (void);
// 0x00000446 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractorEvent::.ctor()
extern void XRInteractorEvent__ctor_m1A2EDF11BD3670B83606D8416ECB4F84E55A31EE (void);
// 0x00000447 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::add_interactorRegistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs>)
extern void XRInteractionManager_add_interactorRegistered_m326A4E8AB1DF06624D008EDC28711341CD3D8F1A (void);
// 0x00000448 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::remove_interactorRegistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs>)
extern void XRInteractionManager_remove_interactorRegistered_mF08538A5559BA84629940B3810F00DA55C01D259 (void);
// 0x00000449 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::add_interactorUnregistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs>)
extern void XRInteractionManager_add_interactorUnregistered_m40D6A12AB95F14CF45A3EB93D5FEBFDBC240D712 (void);
// 0x0000044A System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::remove_interactorUnregistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs>)
extern void XRInteractionManager_remove_interactorUnregistered_mC0AD12A62B1B527063B721395A2B252B91CAE5F8 (void);
// 0x0000044B System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::add_interactableRegistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs>)
extern void XRInteractionManager_add_interactableRegistered_mA988BE3542F18F59BD66F16017DF19153DA7CF3F (void);
// 0x0000044C System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::remove_interactableRegistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs>)
extern void XRInteractionManager_remove_interactableRegistered_mE2A574D88B059A17C482B057CFB632446D6537D1 (void);
// 0x0000044D System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::add_interactableUnregistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs>)
extern void XRInteractionManager_add_interactableUnregistered_mF868D7595D14DDA38D60F61249878B9E0E261E36 (void);
// 0x0000044E System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::remove_interactableUnregistered(System.Action`1<UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs>)
extern void XRInteractionManager_remove_interactableUnregistered_mC4F1CD6073FFE6B6AB221522A1BEBE2CEE0E93E5 (void);
// 0x0000044F System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRInteractionManager> UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::get_activeInteractionManagers()
extern void XRInteractionManager_get_activeInteractionManagers_m5A2A2413296876F10164C973358D57FA2B3EB1E5 (void);
// 0x00000450 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::OnEnable()
extern void XRInteractionManager_OnEnable_mC89EE86392CA1087C5C2D541F90A3FA9C521AA72 (void);
// 0x00000451 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::OnDisable()
extern void XRInteractionManager_OnDisable_m411C689A20C051276331AC5492824BA02891271D (void);
// 0x00000452 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::Update()
extern void XRInteractionManager_Update_m69F79C2139BBB77F7079EBFA048C66D60F7768C8 (void);
// 0x00000453 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::LateUpdate()
extern void XRInteractionManager_LateUpdate_m5E2F8CF6300555B49625C955FA50C05528E28012 (void);
// 0x00000454 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::FixedUpdate()
extern void XRInteractionManager_FixedUpdate_m194833B9D47F1CF8AD543BDA15F619BFC9E80522 (void);
// 0x00000455 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::OnBeforeRender()
extern void XRInteractionManager_OnBeforeRender_m58B0EE0C78D17A8A707D7CCE3FE52B17799551CD (void);
// 0x00000456 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::PreprocessInteractors(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRInteractionManager_PreprocessInteractors_mB5B20D909FC78305180D0AD985239DC506735349 (void);
// 0x00000457 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ProcessInteractors(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRInteractionManager_ProcessInteractors_mC790B832EAC50F9C9FFDAB2559C8BD417D46E489 (void);
// 0x00000458 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ProcessInteractables(UnityEngine.XR.Interaction.Toolkit.XRInteractionUpdateOrder/UpdatePhase)
extern void XRInteractionManager_ProcessInteractables_mC4E0C4ACA409D4912EFBE9FFFF146AE817AC7961 (void);
// 0x00000459 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::RegisterInteractor(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
extern void XRInteractionManager_RegisterInteractor_m8C87B8F7F17EBD37E43D42A0C2620E147273AF5F (void);
// 0x0000045A System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::OnRegistered(UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs)
extern void XRInteractionManager_OnRegistered_m052F72C1CDD636EF1D93079185870F2B24D2DB02 (void);
// 0x0000045B System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::UnregisterInteractor(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
extern void XRInteractionManager_UnregisterInteractor_mDCA3EEA2C6C8C699E227F782012B9B1541D3E303 (void);
// 0x0000045C System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::OnUnregistered(UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs)
extern void XRInteractionManager_OnUnregistered_m9396BB503AB65E22DDA0B45A8F22095B2F15B79E (void);
// 0x0000045D System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::RegisterInteractable(UnityEngine.XR.Interaction.Toolkit.IXRInteractable)
extern void XRInteractionManager_RegisterInteractable_m9515894CC5AE623DB9CFD0EC915A0EB8FE240A61 (void);
// 0x0000045E System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::OnRegistered(UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs)
extern void XRInteractionManager_OnRegistered_mAB7EE4460DCF09AF516883DCF9680B185A9CEDE7 (void);
// 0x0000045F System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::UnregisterInteractable(UnityEngine.XR.Interaction.Toolkit.IXRInteractable)
extern void XRInteractionManager_UnregisterInteractable_m7DCFBDBCAE2547B55467306C3A3543FECB276656 (void);
// 0x00000460 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::OnUnregistered(UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs)
extern void XRInteractionManager_OnUnregistered_m4B2BACB59BFB2070B6A8EE045CA4347557D6ED45 (void);
// 0x00000461 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::GetRegisteredInteractors(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractor>)
extern void XRInteractionManager_GetRegisteredInteractors_m10AC6F729264FDD9B6323C7643C2744E08327613 (void);
// 0x00000462 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::GetRegisteredInteractables(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>)
extern void XRInteractionManager_GetRegisteredInteractables_m5255C91F428D890463EC1FDC3273425FC82A2679 (void);
// 0x00000463 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::IsRegistered(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
extern void XRInteractionManager_IsRegistered_mF4665ACA0886A1A9A487DFCC217910F4F9037D52 (void);
// 0x00000464 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::IsRegistered(UnityEngine.XR.Interaction.Toolkit.IXRInteractable)
extern void XRInteractionManager_IsRegistered_mB4839EFE423FAED99D27FDB6764841406FA485B3 (void);
// 0x00000465 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::TryGetInteractableForCollider(UnityEngine.Collider,UnityEngine.XR.Interaction.Toolkit.IXRInteractable&)
extern void XRInteractionManager_TryGetInteractableForCollider_mB5101149B97FD28DFBA42F84643F8549DDB5E607 (void);
// 0x00000466 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::GetValidTargets(UnityEngine.XR.Interaction.Toolkit.IXRInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>)
extern void XRInteractionManager_GetValidTargets_m2466547EA6CE2E4DF08784B06C05D9CEBF4CDA7C (void);
// 0x00000467 System.Int32 UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::RemoveAllUnregistered(UnityEngine.XR.Interaction.Toolkit.XRInteractionManager,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>)
extern void XRInteractionManager_RemoveAllUnregistered_m49A04CA0816252EFDBD5A183CC04CF250574299A (void);
// 0x00000468 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ClearInteractorSelection(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>)
extern void XRInteractionManager_ClearInteractorSelection_mB789D725484039BB950C19F9B9331F396CE2C90B (void);
// 0x00000469 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ClearInteractorSelectionInternal(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>)
extern void XRInteractionManager_ClearInteractorSelectionInternal_m3310F9804E31A21A99B7AF471033858320381E53 (void);
// 0x0000046A System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::CancelInteractorSelection(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor)
extern void XRInteractionManager_CancelInteractorSelection_mC4602F60D28368A064C9245C55316091FF8C4CB4 (void);
// 0x0000046B System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::CancelInteractorSelectionInternal(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor)
extern void XRInteractionManager_CancelInteractorSelectionInternal_mA0AA3511DE00DA2208184D1E1AFB19362E66B310 (void);
// 0x0000046C System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::CancelInteractableSelection(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRInteractionManager_CancelInteractableSelection_m7500B2BBDA9BF8D3F3F13B1562FE0276F5F1F18B (void);
// 0x0000046D System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::CancelInteractableSelectionInternal(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRInteractionManager_CancelInteractableSelectionInternal_mFF3CC0C7309D5B5EA8C15F51B0B389EAE2D589AC (void);
// 0x0000046E System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ClearInteractorHover(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>)
extern void XRInteractionManager_ClearInteractorHover_mA70FFCE292B94A7B0C956D4783F89879A46415C2 (void);
// 0x0000046F System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ClearInteractorHoverInternal(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRInteractionManager_ClearInteractorHoverInternal_m1FDD875CA52E7B681BB601E5B9F415591391CD53 (void);
// 0x00000470 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::CancelInteractorHover(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor)
extern void XRInteractionManager_CancelInteractorHover_m5D264DEC8ADE1699F64A48D2103F70A8A57DFFEE (void);
// 0x00000471 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::CancelInteractorHoverInternal(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor)
extern void XRInteractionManager_CancelInteractorHoverInternal_m040DAF03B7D617F528881C5F09F204A0224374AA (void);
// 0x00000472 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::CancelInteractableHover(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable)
extern void XRInteractionManager_CancelInteractableHover_m465C60DD72290629AE5A72FA6D7C1CE628ECA958 (void);
// 0x00000473 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::CancelInteractableHoverInternal(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable)
extern void XRInteractionManager_CancelInteractableHoverInternal_m48DF98EA13ACFA3F445A2335590D7F2AE27E1E75 (void);
// 0x00000474 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectEnter(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor,UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRInteractionManager_SelectEnter_mF8B22B192B55DA4E15F7716A3731768EB52F2AA3 (void);
// 0x00000475 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectEnterInternal(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor,UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRInteractionManager_SelectEnterInternal_m0E03175D0A8B4187C1E03A5E63149888EAE90A96 (void);
// 0x00000476 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectExit(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor,UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRInteractionManager_SelectExit_m5580A661ABC461675C2165F10CD4BB487DA9E115 (void);
// 0x00000477 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectExitInternal(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor,UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRInteractionManager_SelectExitInternal_m5C44EAA94101D3E89B79DA54E1D4CB0E2E75F388 (void);
// 0x00000478 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectCancel(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor,UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRInteractionManager_SelectCancel_m8EB7643E80920812BBADA58F9A2E590380E359CD (void);
// 0x00000479 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectCancelInternal(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor,UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRInteractionManager_SelectCancelInternal_m1310F0C8B5464357CEF28D5ACC8D3654ED2901D9 (void);
// 0x0000047A System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverEnter(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor,UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable)
extern void XRInteractionManager_HoverEnter_m85C0AAF57022AFB537F4EC3466A0DE17255FC77D (void);
// 0x0000047B System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverEnterInternal(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor,UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable)
extern void XRInteractionManager_HoverEnterInternal_mABA0AF49B01D92FA3280DA2C5D06C4299351E1B0 (void);
// 0x0000047C System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverExit(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor,UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable)
extern void XRInteractionManager_HoverExit_m6A17CAE72E9E759090CFDF4945658DE1F2CAB353 (void);
// 0x0000047D System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverExitInternal(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor,UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable)
extern void XRInteractionManager_HoverExitInternal_mA04E07537F5432EDA074C978EDD03995FA7F650A (void);
// 0x0000047E System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverCancel(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor,UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable)
extern void XRInteractionManager_HoverCancel_mF8AFE99481CCD532A3AE04D9656C03DB6512B944 (void);
// 0x0000047F System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverCancelInternal(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor,UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable)
extern void XRInteractionManager_HoverCancelInternal_mE3A078E4359E689692560B16A80F08B569BE9E6D (void);
// 0x00000480 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectEnter(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor,UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable,UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRInteractionManager_SelectEnter_m43375FE6AB714D1892E58E47D35B86B69D21E009 (void);
// 0x00000481 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectEnterInternal(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor,UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable,UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRInteractionManager_SelectEnterInternal_mE9A3C30C0E7FB661C1F9CBFD8B5625DC073E799C (void);
// 0x00000482 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectExit(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor,UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable,UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRInteractionManager_SelectExit_mA05F49C3A13F5EA4E31277F0EDCD62FD9B847E73 (void);
// 0x00000483 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectExitInternal(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor,UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable,UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRInteractionManager_SelectExitInternal_m2EF03B4FF4EACFA7AAD582F36A2B7E6F6781A65B (void);
// 0x00000484 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverEnter(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor,UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable,UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRInteractionManager_HoverEnter_mA15A2FBE71141DE2B305D1E359C53D570959B01A (void);
// 0x00000485 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverEnterInternal(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor,UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable,UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRInteractionManager_HoverEnterInternal_mE2801FEEA5F1CEAAC6F8408D2FE83C7488AB6B05 (void);
// 0x00000486 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverExit(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor,UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable,UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRInteractionManager_HoverExit_m5BE01EDFAF1F7376931F89ED09F48851F9FAE22E (void);
// 0x00000487 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverExitInternal(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor,UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractable,UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRInteractionManager_HoverExitInternal_m3EEFFA9BFEC5D1FAB7922B50013E69B652EC6C45 (void);
// 0x00000488 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::InteractorSelectValidTargets(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>)
extern void XRInteractionManager_InteractorSelectValidTargets_m74CC380537EBFDA2F2DC005767F586D3B3B3A48D (void);
// 0x00000489 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::InteractorSelectValidTargetsInternal(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRInteractionManager_InteractorSelectValidTargetsInternal_m48BB2DDD65BE3AB16D4CC34AEC143C1C387B04F8 (void);
// 0x0000048A System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::InteractorHoverValidTargets(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>)
extern void XRInteractionManager_InteractorHoverValidTargets_mD5B7DCE67E8AD408AE3B20C234905C7BB207482B (void);
// 0x0000048B System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::InteractorHoverValidTargetsInternal(UnityEngine.XR.Interaction.Toolkit.IXRHoverInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRInteractionManager_InteractorHoverValidTargetsInternal_m8203987A0F3C52AD1A1515AF74B2AA6F187603AB (void);
// 0x0000048C System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ResolveExistingSelect(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractor,UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRInteractionManager_ResolveExistingSelect_mDA56D2DF7249BA2C008BCE9D3400E8F60D7BBA69 (void);
// 0x0000048D System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HasInteractionLayerOverlap(UnityEngine.XR.Interaction.Toolkit.IXRInteractor,UnityEngine.XR.Interaction.Toolkit.IXRInteractable)
extern void XRInteractionManager_HasInteractionLayerOverlap_m5239C2DF235560F65C389F4C7ABD977C9BFE614E (void);
// 0x0000048E System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ExitInteractableSelection(UnityEngine.XR.Interaction.Toolkit.IXRSelectInteractable)
extern void XRInteractionManager_ExitInteractableSelection_mC77FA22A8A7087E937A4B92CF616D412E7AE299D (void);
// 0x0000048F System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::FlushRegistration()
extern void XRInteractionManager_FlushRegistration_mD3A98438B16A1A1CF88A66E6935578619C60251A (void);
// 0x00000490 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::GetOfType(System.Collections.Generic.List`1<TSource>,System.Collections.Generic.List`1<TDestination>)
// 0x00000491 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::RegisterInteractor(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRInteractionManager_RegisterInteractor_m291902066C1A64C6CD0D0557B831990414E0CBDA (void);
// 0x00000492 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::UnregisterInteractor(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRInteractionManager_UnregisterInteractor_mCFC04749344C221B072AEA031A03E71187F1C238 (void);
// 0x00000493 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::RegisterInteractable(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_RegisterInteractable_m47116DD86C0C734E3E9646AB2AA85DB74113F37C (void);
// 0x00000494 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::UnregisterInteractable(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_UnregisterInteractable_mA97A2CFE958FB7F05A6F9E57B2EF10315A3480CC (void);
// 0x00000495 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::GetRegisteredInteractors(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor>)
extern void XRInteractionManager_GetRegisteredInteractors_m0380C9C368C156CA43AF42C0591E1DE07CB5D675 (void);
// 0x00000496 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::GetRegisteredInteractables(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRInteractionManager_GetRegisteredInteractables_mDFF6CDD0AF4CFE2C1AA54011D5F42C7CEE1FE532 (void);
// 0x00000497 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::IsRegistered(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRInteractionManager_IsRegistered_mF3B3EB4CB278C9BCF8589AFE0EB3A416EEBB6CF2 (void);
// 0x00000498 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::IsRegistered(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_IsRegistered_m65C28B573DBC80DE8DBD06206B7F9AC60E3E4C6F (void);
// 0x00000499 UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::TryGetInteractableForCollider(UnityEngine.Collider)
extern void XRInteractionManager_TryGetInteractableForCollider_mBAA4EBFE6CEB2D28B1EDE2C333CFED8A3ED4709D (void);
// 0x0000049A UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::GetInteractableForCollider(UnityEngine.Collider)
extern void XRInteractionManager_GetInteractableForCollider_m546BE05EAB715F319718D1A173325A8EE87EAD25 (void);
// 0x0000049B System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::GetColliderToInteractableMap(System.Collections.Generic.Dictionary`2<UnityEngine.Collider,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>&)
extern void XRInteractionManager_GetColliderToInteractableMap_mB5A3282DA7AB1E69B50E94C768A6EF7914C15478 (void);
// 0x0000049C System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable> UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::GetValidTargets(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRInteractionManager_GetValidTargets_m682F8B8F1BB671DADE1CC90A262ECEBDBA3DD49C (void);
// 0x0000049D System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ForceSelect(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_ForceSelect_m80E8A7B047D0665E564212CF8D0362A5E7DB26A7 (void);
// 0x0000049E System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ClearInteractorSelection(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRInteractionManager_ClearInteractorSelection_mB18301D8B367C0EC84A5F10C2E41AFB0BF77A2F9 (void);
// 0x0000049F System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::CancelInteractorSelection(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRInteractionManager_CancelInteractorSelection_m43232207EDF5EF8FF4063F3B7865639C64014A87 (void);
// 0x000004A0 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::CancelInteractableSelection(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_CancelInteractableSelection_mC6D2D4BB81E6540886DA49A7A67EA14E2EC680C4 (void);
// 0x000004A1 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::ClearInteractorHover(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRInteractionManager_ClearInteractorHover_m9D87C101D59A96346A0A735EB244433ABA3DB556 (void);
// 0x000004A2 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::CancelInteractorHover(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor)
extern void XRInteractionManager_CancelInteractorHover_m5B85342A7F9360C9482A771DD5D73FA620AEF7F0 (void);
// 0x000004A3 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::CancelInteractableHover(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_CancelInteractableHover_m0B6B797908BA79D6626DE41951C13EB85F09143F (void);
// 0x000004A4 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_SelectEnter_mD730B42373CC3C4A71B53BB79EDEF0B9598D96C2 (void);
// 0x000004A5 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_SelectExit_mFFB8E8B5FC957BCF99BC2F4D007643A416FE71D8 (void);
// 0x000004A6 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectCancel(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_SelectCancel_m68A36B47E48F294ADC6128D763EDC9F3D73266BD (void);
// 0x000004A7 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_HoverEnter_m11CCF7D0EECDE1D6F8F6E1B7EF5730806D6A1B1E (void);
// 0x000004A8 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_HoverExit_m6880CADA950FEAC8F7B6027D78189BA787AB9458 (void);
// 0x000004A9 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverCancel(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable)
extern void XRInteractionManager_HoverCancel_m57F0EB47090B391FA9AEA4E2BBB417C6CC93C9F0 (void);
// 0x000004AA System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable,UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void XRInteractionManager_SelectEnter_m9F21AB38B8090B0D2EEDCBCB24A6BF83F53F4011 (void);
// 0x000004AB System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::SelectExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable,UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void XRInteractionManager_SelectExit_mFF618D4F47C3CCDF4BBC7FB78D7DF57A980DE8C7 (void);
// 0x000004AC System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverEnter(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable,UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs)
extern void XRInteractionManager_HoverEnter_m3E7765D447A8F4CCF1F731EA850AA85644609E21 (void);
// 0x000004AD System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::HoverExit(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable,UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs)
extern void XRInteractionManager_HoverExit_m99E3E05573C2F4438E51A209934BB5EF4510AB59 (void);
// 0x000004AE System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::InteractorSelectValidTargets(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRInteractionManager_InteractorSelectValidTargets_m53D39B4C1EC70D1F918D5C10BA27D3088B6ED7F3 (void);
// 0x000004AF System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::InteractorHoverValidTargets(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseInteractable>)
extern void XRInteractionManager_InteractorHoverValidTargets_mA35E677C2AD9CED7637B75A1753BE0DF8CF84630 (void);
// 0x000004B0 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::.ctor()
extern void XRInteractionManager__ctor_m33B9DE751643CC7A9CDCA18704DD2CFC8C2A47BA (void);
// 0x000004B1 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager::.cctor()
extern void XRInteractionManager__cctor_m8FACD8A6CE2EFF761C03AB0A86DAAEC8417F50D6 (void);
// 0x000004B2 System.Collections.Generic.List`1<T> UnityEngine.XR.Interaction.Toolkit.XRInteractionManager/RegistrationList`1::get_registeredSnapshot()
// 0x000004B3 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractionManager/RegistrationList`1::IsRegistered(T)
// 0x000004B4 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractionManager/RegistrationList`1::IsStillRegistered(T)
// 0x000004B5 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractionManager/RegistrationList`1::Register(T)
// 0x000004B6 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRInteractionManager/RegistrationList`1::Unregister(T)
// 0x000004B7 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager/RegistrationList`1::Flush()
// 0x000004B8 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager/RegistrationList`1::GetRegisteredItems(System.Collections.Generic.List`1<T>)
// 0x000004B9 System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager/RegistrationList`1::EnsureCapacity(System.Collections.Generic.List`1<T>,System.Int32)
// 0x000004BA System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager/RegistrationList`1::.ctor()
// 0x000004BB System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager/<>c::.cctor()
extern void U3CU3Ec__cctor_mF43E7E4E77ED998249A496778372159A22783920 (void);
// 0x000004BC System.Void UnityEngine.XR.Interaction.Toolkit.XRInteractionManager/<>c::.ctor()
extern void U3CU3Ec__ctor_m0B1FCFBA75EAE8D29D2D4BE3567A2C4B299A3857 (void);
// 0x000004BD UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs UnityEngine.XR.Interaction.Toolkit.XRInteractionManager/<>c::<.ctor>b__143_0()
extern void U3CU3Ec_U3C_ctorU3Eb__143_0_mC261DA412A44037B60CA1234E47AC0D768881C67 (void);
// 0x000004BE UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs UnityEngine.XR.Interaction.Toolkit.XRInteractionManager/<>c::<.ctor>b__143_1()
extern void U3CU3Ec_U3C_ctorU3Eb__143_1_m76CA5C4990FD08FF3FF21DA3E8CD85604F7F2F30 (void);
// 0x000004BF UnityEngine.XR.Interaction.Toolkit.HoverEnterEventArgs UnityEngine.XR.Interaction.Toolkit.XRInteractionManager/<>c::<.ctor>b__143_2()
extern void U3CU3Ec_U3C_ctorU3Eb__143_2_mAF90E6B53C81EAE2CBC8C0DB5D3C63E27BC9A3E0 (void);
// 0x000004C0 UnityEngine.XR.Interaction.Toolkit.HoverExitEventArgs UnityEngine.XR.Interaction.Toolkit.XRInteractionManager/<>c::<.ctor>b__143_3()
extern void U3CU3Ec_U3C_ctorU3Eb__143_3_m2E12920EB733B1D61405C6A44B8A7E5DFD226AB6 (void);
// 0x000004C1 UnityEngine.XR.Interaction.Toolkit.InteractorRegisteredEventArgs UnityEngine.XR.Interaction.Toolkit.XRInteractionManager/<>c::<.ctor>b__143_4()
extern void U3CU3Ec_U3C_ctorU3Eb__143_4_m7B8F529C669EB8EC0113ECF6C6A382010E1464FE (void);
// 0x000004C2 UnityEngine.XR.Interaction.Toolkit.InteractorUnregisteredEventArgs UnityEngine.XR.Interaction.Toolkit.XRInteractionManager/<>c::<.ctor>b__143_5()
extern void U3CU3Ec_U3C_ctorU3Eb__143_5_m3B897464528D51EFB1F67F1ADD963F76DCDD5C6D (void);
// 0x000004C3 UnityEngine.XR.Interaction.Toolkit.InteractableRegisteredEventArgs UnityEngine.XR.Interaction.Toolkit.XRInteractionManager/<>c::<.ctor>b__143_6()
extern void U3CU3Ec_U3C_ctorU3Eb__143_6_mB0A321045292EDFA888CB76107E1F611C1B4E273 (void);
// 0x000004C4 UnityEngine.XR.Interaction.Toolkit.InteractableUnregisteredEventArgs UnityEngine.XR.Interaction.Toolkit.XRInteractionManager/<>c::<.ctor>b__143_7()
extern void U3CU3Ec_U3C_ctorU3Eb__143_7_m56BC24B08723AD31FAC4F591C5EDEC1701549E5F (void);
// 0x000004C5 UnityEngine.XR.Interaction.Toolkit.LocomotionProvider UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::get_locomotionProvider()
extern void CharacterControllerDriver_get_locomotionProvider_m832426BACE3C1BDC3018D7B1DA87F33ADF3EF7A6 (void);
// 0x000004C6 System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::set_locomotionProvider(UnityEngine.XR.Interaction.Toolkit.LocomotionProvider)
extern void CharacterControllerDriver_set_locomotionProvider_mC5E56C97BBC05EE1ECCC28088B49A3EBB1B05A3A (void);
// 0x000004C7 System.Single UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::get_minHeight()
extern void CharacterControllerDriver_get_minHeight_m26E0DDB8EC35F9568751F364BBADFA5EBF84B706 (void);
// 0x000004C8 System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::set_minHeight(System.Single)
extern void CharacterControllerDriver_set_minHeight_m04B4E59CC6A1CA42E3A6F7CBD114D3D13019E938 (void);
// 0x000004C9 System.Single UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::get_maxHeight()
extern void CharacterControllerDriver_get_maxHeight_mA992C84A42D96607A5AED26E850C4B3D8092A0D5 (void);
// 0x000004CA System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::set_maxHeight(System.Single)
extern void CharacterControllerDriver_set_maxHeight_m756CD8A723605CFCEEC322AE624E694F33441DFE (void);
// 0x000004CB Unity.XR.CoreUtils.XROrigin UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::get_xrOrigin()
extern void CharacterControllerDriver_get_xrOrigin_m20D41C4839F146E7CB2B1AC9E2D9D2CE968B49FD (void);
// 0x000004CC UnityEngine.CharacterController UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::get_characterController()
extern void CharacterControllerDriver_get_characterController_m0CFBBECC5698525CC38657D490F6B1FD36E5F325 (void);
// 0x000004CD System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::Awake()
extern void CharacterControllerDriver_Awake_m20B28E81716B563EC32B5EC3A7A387C492E8F213 (void);
// 0x000004CE System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::OnEnable()
extern void CharacterControllerDriver_OnEnable_m701B823C384A3331E6F7FB701607672BAA7ADC3D (void);
// 0x000004CF System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::OnDisable()
extern void CharacterControllerDriver_OnDisable_mD76F600A9E78338A2CF7027C625958C27B61A2DD (void);
// 0x000004D0 System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::Start()
extern void CharacterControllerDriver_Start_mB21C2A78801CA14CCA3ABF9E8ACB412626846670 (void);
// 0x000004D1 System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::UpdateCharacterController()
extern void CharacterControllerDriver_UpdateCharacterController_mD0DBBA9B0393708F017DCF4305245307011A6760 (void);
// 0x000004D2 System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::Subscribe(UnityEngine.XR.Interaction.Toolkit.LocomotionProvider)
extern void CharacterControllerDriver_Subscribe_mD02046724D31A50E465795C29C463F8F42E35565 (void);
// 0x000004D3 System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::Unsubscribe(UnityEngine.XR.Interaction.Toolkit.LocomotionProvider)
extern void CharacterControllerDriver_Unsubscribe_m9EACB74F852F90A861C7983CDFB425F5B99DFC14 (void);
// 0x000004D4 System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::SetupCharacterController()
extern void CharacterControllerDriver_SetupCharacterController_m3259E81F5099D6F5A91D23EC016C25FD173547A0 (void);
// 0x000004D5 System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::OnBeginLocomotion(UnityEngine.XR.Interaction.Toolkit.LocomotionSystem)
extern void CharacterControllerDriver_OnBeginLocomotion_m524111528FE7083D44800E28EA2CCA0C7F4CFC6C (void);
// 0x000004D6 System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::OnEndLocomotion(UnityEngine.XR.Interaction.Toolkit.LocomotionSystem)
extern void CharacterControllerDriver_OnEndLocomotion_m0FAAE4B4A7D0B5B4DF84D04C8AF737D78C92EB7B (void);
// 0x000004D7 UnityEngine.XR.Interaction.Toolkit.XRRig UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::get_xrRig()
extern void CharacterControllerDriver_get_xrRig_m511BE884B2E3510BD714FF7C3FF5EA5332EAE0A4 (void);
// 0x000004D8 System.Void UnityEngine.XR.Interaction.Toolkit.CharacterControllerDriver::.ctor()
extern void CharacterControllerDriver__ctor_m51FA99929552C3ADB304E663BEC0C528C701E386 (void);
// 0x000004D9 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousMoveProvider::get_leftHandMoveAction()
extern void ActionBasedContinuousMoveProvider_get_leftHandMoveAction_m1A3CE1F7AFE741716F8CABEE541C67DE5E16C64B (void);
// 0x000004DA System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousMoveProvider::set_leftHandMoveAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedContinuousMoveProvider_set_leftHandMoveAction_m2F74B31226292DBBF6932160F6DB596217E8028F (void);
// 0x000004DB UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousMoveProvider::get_rightHandMoveAction()
extern void ActionBasedContinuousMoveProvider_get_rightHandMoveAction_m798EAE65B649189963A7A35D4084FE9B28618490 (void);
// 0x000004DC System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousMoveProvider::set_rightHandMoveAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedContinuousMoveProvider_set_rightHandMoveAction_mF39B0E3E9C73287445C2D48CC10B89EDD1593D01 (void);
// 0x000004DD System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousMoveProvider::OnEnable()
extern void ActionBasedContinuousMoveProvider_OnEnable_mA9B8E570972B0F2F18EAAC3F64A94616C7ED1AC5 (void);
// 0x000004DE System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousMoveProvider::OnDisable()
extern void ActionBasedContinuousMoveProvider_OnDisable_mC6999757EB98EB241640A71ED8C9CB52C850F065 (void);
// 0x000004DF UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousMoveProvider::ReadInput()
extern void ActionBasedContinuousMoveProvider_ReadInput_m06114221CD3B7CC7998B19DEE88DAC1C9B6B057E (void);
// 0x000004E0 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousMoveProvider::SetInputActionProperty(UnityEngine.InputSystem.InputActionProperty&,UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedContinuousMoveProvider_SetInputActionProperty_m372EC1CCE4169CE641FD0DCBEE996DF11C35148C (void);
// 0x000004E1 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousMoveProvider::.ctor()
extern void ActionBasedContinuousMoveProvider__ctor_m1310A2218E70F36811987629965EF7BC0F356583 (void);
// 0x000004E2 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousTurnProvider::get_leftHandTurnAction()
extern void ActionBasedContinuousTurnProvider_get_leftHandTurnAction_m5BCCB053D1B00DC263CD37DC0C3C696BADE74AC5 (void);
// 0x000004E3 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousTurnProvider::set_leftHandTurnAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedContinuousTurnProvider_set_leftHandTurnAction_mDD02C10E24CE3DD53AE203369CC2B3C4F71F0E2B (void);
// 0x000004E4 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousTurnProvider::get_rightHandTurnAction()
extern void ActionBasedContinuousTurnProvider_get_rightHandTurnAction_m2146FD4E90F61AA61299F06966E0B320C7C5B0B6 (void);
// 0x000004E5 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousTurnProvider::set_rightHandTurnAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedContinuousTurnProvider_set_rightHandTurnAction_mE42B3483F0532A56D4E23F3A89F98F1B242F5247 (void);
// 0x000004E6 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousTurnProvider::OnEnable()
extern void ActionBasedContinuousTurnProvider_OnEnable_m44BA623643961E42C10CE7B5FD41AD08CC8D9E89 (void);
// 0x000004E7 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousTurnProvider::OnDisable()
extern void ActionBasedContinuousTurnProvider_OnDisable_m956FFE42EF85B4C43C2B2CE858676B8F0247069F (void);
// 0x000004E8 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousTurnProvider::ReadInput()
extern void ActionBasedContinuousTurnProvider_ReadInput_mD48398B9672DFD785926FB6B3B45EF799D6730FA (void);
// 0x000004E9 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousTurnProvider::SetInputActionProperty(UnityEngine.InputSystem.InputActionProperty&,UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedContinuousTurnProvider_SetInputActionProperty_m9DDF18609BB9EC477E7DC06DE67B3AB94A443977 (void);
// 0x000004EA System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedContinuousTurnProvider::.ctor()
extern void ActionBasedContinuousTurnProvider__ctor_mA0E25E1DE63BFF2460D4A9BDF269A4A576D2635B (void);
// 0x000004EB System.Single UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::get_moveSpeed()
extern void ContinuousMoveProviderBase_get_moveSpeed_m00ACE6C470CA370D6C6FEE014B6BF2D14C451DD5 (void);
// 0x000004EC System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::set_moveSpeed(System.Single)
extern void ContinuousMoveProviderBase_set_moveSpeed_m6BC9C1AF5A210F6F2DCA2A40172B75C5F779C395 (void);
// 0x000004ED System.Boolean UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::get_enableStrafe()
extern void ContinuousMoveProviderBase_get_enableStrafe_m9758D9CDEB6112A8394AED688394C9FF8306E392 (void);
// 0x000004EE System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::set_enableStrafe(System.Boolean)
extern void ContinuousMoveProviderBase_set_enableStrafe_mE7F22E383EA4CE1CAB919EF4FCF5E90E219A0DB4 (void);
// 0x000004EF System.Boolean UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::get_useGravity()
extern void ContinuousMoveProviderBase_get_useGravity_mA8680EF757EDE40AA7C53DA4B22A78DE0AE9625D (void);
// 0x000004F0 System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::set_useGravity(System.Boolean)
extern void ContinuousMoveProviderBase_set_useGravity_mB589343669C70EAAFD0C7E679F82A97AFEA223E8 (void);
// 0x000004F1 UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase/GravityApplicationMode UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::get_gravityApplicationMode()
extern void ContinuousMoveProviderBase_get_gravityApplicationMode_m006349EFCBDFB54D975269A4CDA53DF65D172A39 (void);
// 0x000004F2 System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::set_gravityApplicationMode(UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase/GravityApplicationMode)
extern void ContinuousMoveProviderBase_set_gravityApplicationMode_m0F358A25FD462AF9ED298DFB66F70C38856E7A66 (void);
// 0x000004F3 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::get_forwardSource()
extern void ContinuousMoveProviderBase_get_forwardSource_mCA2A40CF7B059F8096B8DA7EE022417D5E9AA89A (void);
// 0x000004F4 System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::set_forwardSource(UnityEngine.Transform)
extern void ContinuousMoveProviderBase_set_forwardSource_mA1CBEB304ED21A5E919AEDBC38CAD176E23C9195 (void);
// 0x000004F5 System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::Update()
extern void ContinuousMoveProviderBase_Update_m0A8CFF12DE7E3239FAAC9EB63A53577E4C44242E (void);
// 0x000004F6 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::ReadInput()
// 0x000004F7 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::ComputeDesiredMove(UnityEngine.Vector2)
extern void ContinuousMoveProviderBase_ComputeDesiredMove_mDB77C9D41306941782F36D150B7CD774E1E3A702 (void);
// 0x000004F8 System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::MoveRig(UnityEngine.Vector3)
extern void ContinuousMoveProviderBase_MoveRig_m3793312F1A333B733E60E373DED0938CC8BF5DF2 (void);
// 0x000004F9 System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::FindCharacterController()
extern void ContinuousMoveProviderBase_FindCharacterController_m55140569E91D84284B2CC949BDBEB4A162F1B1CB (void);
// 0x000004FA System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousMoveProviderBase::.ctor()
extern void ContinuousMoveProviderBase__ctor_m1AB119E41778C58681F1785ECE37EF8270A24EA0 (void);
// 0x000004FB System.Single UnityEngine.XR.Interaction.Toolkit.ContinuousTurnProviderBase::get_turnSpeed()
extern void ContinuousTurnProviderBase_get_turnSpeed_mE485FB7889080A4924E65F7A3B5BDB73C53F96E0 (void);
// 0x000004FC System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousTurnProviderBase::set_turnSpeed(System.Single)
extern void ContinuousTurnProviderBase_set_turnSpeed_m0AB633C39385D76B8E67AC90B437C1B52D1B3E11 (void);
// 0x000004FD System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousTurnProviderBase::Update()
extern void ContinuousTurnProviderBase_Update_mDB0CEC76A176AF26216BFA5EA9F1E22A5D0CE9DF (void);
// 0x000004FE UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.ContinuousTurnProviderBase::ReadInput()
// 0x000004FF System.Single UnityEngine.XR.Interaction.Toolkit.ContinuousTurnProviderBase::GetTurnAmount(UnityEngine.Vector2)
extern void ContinuousTurnProviderBase_GetTurnAmount_mD19AF31C63223D9F9721D757C7A32FD1D0F674BC (void);
// 0x00000500 System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousTurnProviderBase::TurnRig(System.Single)
extern void ContinuousTurnProviderBase_TurnRig_mA600D2931DEB1C2D38A61A1E909412AB89230B48 (void);
// 0x00000501 System.Void UnityEngine.XR.Interaction.Toolkit.ContinuousTurnProviderBase::.ctor()
extern void ContinuousTurnProviderBase__ctor_mA41947ADBB4D280EC0EAB152CA5653FE7315B606 (void);
// 0x00000502 UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider/InputAxes UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::get_inputBinding()
extern void DeviceBasedContinuousMoveProvider_get_inputBinding_mDDE00466CC8BCE56238FD5430A3692F3506DF11C (void);
// 0x00000503 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::set_inputBinding(UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider/InputAxes)
extern void DeviceBasedContinuousMoveProvider_set_inputBinding_mDC6908FBDCCD7D6085F21A9AD01765D8F02767D2 (void);
// 0x00000504 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseController> UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::get_controllers()
extern void DeviceBasedContinuousMoveProvider_get_controllers_m34D4DC4440DF930E318BDE0E66A03B51D79C0CFD (void);
// 0x00000505 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::set_controllers(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseController>)
extern void DeviceBasedContinuousMoveProvider_set_controllers_mA94C7B5930A60D1467ACC361DB69CD62A8D2A8D0 (void);
// 0x00000506 System.Single UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::get_deadzoneMin()
extern void DeviceBasedContinuousMoveProvider_get_deadzoneMin_mA570A98208C7C9C2F0F9553A3EEBC6554FB4FF8C (void);
// 0x00000507 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::set_deadzoneMin(System.Single)
extern void DeviceBasedContinuousMoveProvider_set_deadzoneMin_m574BE6DBF774C842B818DB774A273314E8612872 (void);
// 0x00000508 System.Single UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::get_deadzoneMax()
extern void DeviceBasedContinuousMoveProvider_get_deadzoneMax_m63750776276B2BF5FDD2646BDE427803D7AB9AA0 (void);
// 0x00000509 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::set_deadzoneMax(System.Single)
extern void DeviceBasedContinuousMoveProvider_set_deadzoneMax_m95781010EFD332ADAF75E1102DFC21DF2F7DFBCE (void);
// 0x0000050A UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::ReadInput()
extern void DeviceBasedContinuousMoveProvider_ReadInput_m8D4042FC29FAF250497C4B79E492ECFB215ABC7B (void);
// 0x0000050B UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::GetDeadzoneAdjustedValue(UnityEngine.Vector2)
extern void DeviceBasedContinuousMoveProvider_GetDeadzoneAdjustedValue_m90BE91A308931611184788A6B87DA7F4C0BE8606 (void);
// 0x0000050C System.Single UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::GetDeadzoneAdjustedValue(System.Single)
extern void DeviceBasedContinuousMoveProvider_GetDeadzoneAdjustedValue_m6E80A90408CDC315BCAEB19795923D3D0F848B42 (void);
// 0x0000050D System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::.ctor()
extern void DeviceBasedContinuousMoveProvider__ctor_m109CBDC9183E36A999EAC8C21A85D86D509A9447 (void);
// 0x0000050E System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousMoveProvider::.cctor()
extern void DeviceBasedContinuousMoveProvider__cctor_m2373127C6AB1D6B7FF0072834CFA95CE71EAA730 (void);
// 0x0000050F UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider/InputAxes UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::get_inputBinding()
extern void DeviceBasedContinuousTurnProvider_get_inputBinding_mBA9F1D47A5C8A8393289615FD0EDCD198DBC2F53 (void);
// 0x00000510 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::set_inputBinding(UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider/InputAxes)
extern void DeviceBasedContinuousTurnProvider_set_inputBinding_m4E9EAF677F30334229F46D1E119B8989429039BC (void);
// 0x00000511 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseController> UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::get_controllers()
extern void DeviceBasedContinuousTurnProvider_get_controllers_m99326439026E816417E91F15A5AC84DF591EED14 (void);
// 0x00000512 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::set_controllers(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseController>)
extern void DeviceBasedContinuousTurnProvider_set_controllers_m8A2E5DFDBE6134F9B799766B202A40D21A54F2F0 (void);
// 0x00000513 System.Single UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::get_deadzoneMin()
extern void DeviceBasedContinuousTurnProvider_get_deadzoneMin_m556117BFD91F788969FA0298E0375B320C3EF63E (void);
// 0x00000514 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::set_deadzoneMin(System.Single)
extern void DeviceBasedContinuousTurnProvider_set_deadzoneMin_mB4A38EC2A8DED4650164207B05F85CA7FF9C3E94 (void);
// 0x00000515 System.Single UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::get_deadzoneMax()
extern void DeviceBasedContinuousTurnProvider_get_deadzoneMax_m28ACEABA4A3ABEE45EE29EB6EAB86CDC98CF53F3 (void);
// 0x00000516 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::set_deadzoneMax(System.Single)
extern void DeviceBasedContinuousTurnProvider_set_deadzoneMax_m9C5632D1323033930E2FB374446B836947945099 (void);
// 0x00000517 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::ReadInput()
extern void DeviceBasedContinuousTurnProvider_ReadInput_m5BFBB8DE35D3636C1782543CB9400233B133C895 (void);
// 0x00000518 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::GetDeadzoneAdjustedValue(UnityEngine.Vector2)
extern void DeviceBasedContinuousTurnProvider_GetDeadzoneAdjustedValue_m7330A75975136CD9152900A65A8A4813D5C69870 (void);
// 0x00000519 System.Single UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::GetDeadzoneAdjustedValue(System.Single)
extern void DeviceBasedContinuousTurnProvider_GetDeadzoneAdjustedValue_m0359AEBBAEA030B13719A3A3084FDC1EF6535D3F (void);
// 0x0000051A System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::.ctor()
extern void DeviceBasedContinuousTurnProvider__ctor_m383D3502C281C05B920D91A2CE3348AB590544B9 (void);
// 0x0000051B System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedContinuousTurnProvider::.cctor()
extern void DeviceBasedContinuousTurnProvider__cctor_m6B2BF6C886E964D6806976950276810976E291D0 (void);
// 0x0000051C System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::add_beginLocomotion(System.Action`1<UnityEngine.XR.Interaction.Toolkit.LocomotionSystem>)
extern void LocomotionProvider_add_beginLocomotion_mE886C8B4354EE712934C278A497C77834B4754F0 (void);
// 0x0000051D System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::remove_beginLocomotion(System.Action`1<UnityEngine.XR.Interaction.Toolkit.LocomotionSystem>)
extern void LocomotionProvider_remove_beginLocomotion_mBACFA0AD5B200C844F3B0191C9312813F4696CD0 (void);
// 0x0000051E System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::add_endLocomotion(System.Action`1<UnityEngine.XR.Interaction.Toolkit.LocomotionSystem>)
extern void LocomotionProvider_add_endLocomotion_mB5BE7BC07AD5A5A22A5CAD63540D2A0D6D698606 (void);
// 0x0000051F System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::remove_endLocomotion(System.Action`1<UnityEngine.XR.Interaction.Toolkit.LocomotionSystem>)
extern void LocomotionProvider_remove_endLocomotion_mC78E210D6096F0D694ADB7108AE7AA2132923B0D (void);
// 0x00000520 UnityEngine.XR.Interaction.Toolkit.LocomotionSystem UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::get_system()
extern void LocomotionProvider_get_system_m2FFD680EAEA3837BF1BE61B34DB6685118760D94 (void);
// 0x00000521 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::set_system(UnityEngine.XR.Interaction.Toolkit.LocomotionSystem)
extern void LocomotionProvider_set_system_m356CEE71E1057AAD0A615898E7E92A89E2E4664C (void);
// 0x00000522 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::Awake()
extern void LocomotionProvider_Awake_mDB71AC0528310B8B6A57E0D5D0C6E54C0E0E22EB (void);
// 0x00000523 System.Boolean UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::CanBeginLocomotion()
extern void LocomotionProvider_CanBeginLocomotion_m3DE86A342E4B792E125FE73F2FE933BE99EDA9F0 (void);
// 0x00000524 System.Boolean UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::BeginLocomotion()
extern void LocomotionProvider_BeginLocomotion_mFB221E462FEC6E933C9161E30271678311D1AAEF (void);
// 0x00000525 System.Boolean UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::EndLocomotion()
extern void LocomotionProvider_EndLocomotion_m64CC4C14527FF9F8D2956159425A2208E4612ECB (void);
// 0x00000526 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::add_startLocomotion(System.Action`1<UnityEngine.XR.Interaction.Toolkit.LocomotionSystem>)
extern void LocomotionProvider_add_startLocomotion_m788F6350336CBB47917142134CDFAE7CB268A6E7 (void);
// 0x00000527 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::remove_startLocomotion(System.Action`1<UnityEngine.XR.Interaction.Toolkit.LocomotionSystem>)
extern void LocomotionProvider_remove_startLocomotion_mF92BE5D2EBCDA9D120F5A743CB63D42C368267EC (void);
// 0x00000528 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionProvider::.ctor()
extern void LocomotionProvider__ctor_m402BA4925BA100FA69742DD86D76BA0ECB39C7E7 (void);
// 0x00000529 System.Single UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::get_timeout()
extern void LocomotionSystem_get_timeout_mFD09A2DD790389F19DBF9721011D7D905CE36F2E (void);
// 0x0000052A System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::set_timeout(System.Single)
extern void LocomotionSystem_set_timeout_m7B3F1CA7FEADE7103002DDBA0580B08A7E86FE3F (void);
// 0x0000052B Unity.XR.CoreUtils.XROrigin UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::get_xrOrigin()
extern void LocomotionSystem_get_xrOrigin_m06C2599D9739A71562F0F3DD27BC57BCC18F3EF7 (void);
// 0x0000052C System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::set_xrOrigin(Unity.XR.CoreUtils.XROrigin)
extern void LocomotionSystem_set_xrOrigin_mCBC0B979D95B8DB1086C505645AE0BD97DCE3016 (void);
// 0x0000052D System.Boolean UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::get_busy()
extern void LocomotionSystem_get_busy_m28D47236EB8305F858FAA903E490FF1F9D678A9F (void);
// 0x0000052E System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::Awake()
extern void LocomotionSystem_Awake_m6A110BC4319FBEC64AD112B130CC3DDAA2B04D14 (void);
// 0x0000052F System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::Update()
extern void LocomotionSystem_Update_m0E0FE862254C451ADBEFE63756E120C6C57E1159 (void);
// 0x00000530 UnityEngine.XR.Interaction.Toolkit.RequestResult UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::RequestExclusiveOperation(UnityEngine.XR.Interaction.Toolkit.LocomotionProvider)
extern void LocomotionSystem_RequestExclusiveOperation_m38B962B56859A1978AC995893D7FD9C7CEB0A0F1 (void);
// 0x00000531 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::ResetExclusivity()
extern void LocomotionSystem_ResetExclusivity_m25A6EA802DDFDAF8A1FE6C59FB85C66F58A55DDE (void);
// 0x00000532 UnityEngine.XR.Interaction.Toolkit.RequestResult UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::FinishExclusiveOperation(UnityEngine.XR.Interaction.Toolkit.LocomotionProvider)
extern void LocomotionSystem_FinishExclusiveOperation_mE60B5D19065E9DC6F76357B21942126ED8383644 (void);
// 0x00000533 UnityEngine.XR.Interaction.Toolkit.XRRig UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::get_xrRig()
extern void LocomotionSystem_get_xrRig_m66C8141D2D2FACDEC33DB82CAC8ED5278DEEDDE1 (void);
// 0x00000534 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::set_xrRig(UnityEngine.XR.Interaction.Toolkit.XRRig)
extern void LocomotionSystem_set_xrRig_m582AE29CF788F3FA6E544A852CE884CEDFC50A80 (void);
// 0x00000535 System.Boolean UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::get_Busy()
extern void LocomotionSystem_get_Busy_m43E2C5C416E56C27D9079BE43A58E31C9131B1E7 (void);
// 0x00000536 System.Void UnityEngine.XR.Interaction.Toolkit.LocomotionSystem::.ctor()
extern void LocomotionSystem__ctor_mB37629153362E038054DC424AC2748E8F3CFA8E4 (void);
// 0x00000537 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedSnapTurnProvider::get_leftHandSnapTurnAction()
extern void ActionBasedSnapTurnProvider_get_leftHandSnapTurnAction_m080880500C2C7AF09C16DD9E3AD8987FF54F41B8 (void);
// 0x00000538 System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedSnapTurnProvider::set_leftHandSnapTurnAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedSnapTurnProvider_set_leftHandSnapTurnAction_m593DEF28D9A4AC170EF9CECD72A4CCC39FC1F18A (void);
// 0x00000539 UnityEngine.InputSystem.InputActionProperty UnityEngine.XR.Interaction.Toolkit.ActionBasedSnapTurnProvider::get_rightHandSnapTurnAction()
extern void ActionBasedSnapTurnProvider_get_rightHandSnapTurnAction_mB7D3DC36F102F0B0B144A7E66DBD6D8E99DC6D11 (void);
// 0x0000053A System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedSnapTurnProvider::set_rightHandSnapTurnAction(UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedSnapTurnProvider_set_rightHandSnapTurnAction_m6909A7D5317BC44B3B6FC8A2C86D1ABF1CA3B6EF (void);
// 0x0000053B System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedSnapTurnProvider::OnEnable()
extern void ActionBasedSnapTurnProvider_OnEnable_mB974392761A9F3507B232702D0974A3B620F0CFD (void);
// 0x0000053C System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedSnapTurnProvider::OnDisable()
extern void ActionBasedSnapTurnProvider_OnDisable_m50B8D2411258F6363F6167D2706A42FA2A0EDC20 (void);
// 0x0000053D UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.ActionBasedSnapTurnProvider::ReadInput()
extern void ActionBasedSnapTurnProvider_ReadInput_mB3F4758285A8867A4564A78CCEEC422FBCB4356B (void);
// 0x0000053E System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedSnapTurnProvider::SetInputActionProperty(UnityEngine.InputSystem.InputActionProperty&,UnityEngine.InputSystem.InputActionProperty)
extern void ActionBasedSnapTurnProvider_SetInputActionProperty_mC9D57A366A4C04274E9FAB6B9E46E383A2B96FCC (void);
// 0x0000053F System.Void UnityEngine.XR.Interaction.Toolkit.ActionBasedSnapTurnProvider::.ctor()
extern void ActionBasedSnapTurnProvider__ctor_m2DD0B1A6EBB603FA40E193EC764E68047A24059C (void);
// 0x00000540 UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider/InputAxes UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider::get_turnUsage()
extern void DeviceBasedSnapTurnProvider_get_turnUsage_m13EA8E1F1E0D250A1CA79550A71D0C3567AFF9BC (void);
// 0x00000541 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider::set_turnUsage(UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider/InputAxes)
extern void DeviceBasedSnapTurnProvider_set_turnUsage_m862FDD3D55F0C49AAB990906404ADE4902DFDD95 (void);
// 0x00000542 System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseController> UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider::get_controllers()
extern void DeviceBasedSnapTurnProvider_get_controllers_m0BAA48EADCBCD01F05ADEC2320DF14C5582ED437 (void);
// 0x00000543 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider::set_controllers(System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.XRBaseController>)
extern void DeviceBasedSnapTurnProvider_set_controllers_m1D926F8431A5DFC4D68B7219763D82FCCFF7C905 (void);
// 0x00000544 System.Single UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider::get_deadZone()
extern void DeviceBasedSnapTurnProvider_get_deadZone_m5BD8B17BD1FFDA15FBF13CE57B6B228183FC224D (void);
// 0x00000545 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider::set_deadZone(System.Single)
extern void DeviceBasedSnapTurnProvider_set_deadZone_m1F0A53F7076A009D8C97B244C0F86F99EAE941EA (void);
// 0x00000546 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider::ReadInput()
extern void DeviceBasedSnapTurnProvider_ReadInput_m8032A60D620CC1F500C253C42BD42B3D298BE2F0 (void);
// 0x00000547 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider::.ctor()
extern void DeviceBasedSnapTurnProvider__ctor_m3BF22C66539C00C07B72AFD688BC9EDBC006A66E (void);
// 0x00000548 System.Void UnityEngine.XR.Interaction.Toolkit.DeviceBasedSnapTurnProvider::.cctor()
extern void DeviceBasedSnapTurnProvider__cctor_mAC0B8900E5AC49A44914C6F2DBB283CE5FE8BC46 (void);
// 0x00000549 System.Single UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::get_turnAmount()
extern void SnapTurnProviderBase_get_turnAmount_m1A71B1F663BBA314E04F40A87F976E65C585329A (void);
// 0x0000054A System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::set_turnAmount(System.Single)
extern void SnapTurnProviderBase_set_turnAmount_m7CF964B94A1EF781ED3318E924FD1F6E60BBD959 (void);
// 0x0000054B System.Single UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::get_debounceTime()
extern void SnapTurnProviderBase_get_debounceTime_mBE1DB957DE0AEFDA923ADF4F60749AAB5777D112 (void);
// 0x0000054C System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::set_debounceTime(System.Single)
extern void SnapTurnProviderBase_set_debounceTime_mF1EC6DC3B36931E6DDD9A9A7837794DDDE35DF80 (void);
// 0x0000054D System.Boolean UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::get_enableTurnLeftRight()
extern void SnapTurnProviderBase_get_enableTurnLeftRight_m305A42F82C0DA2E59ED427C612B31714110C3A6B (void);
// 0x0000054E System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::set_enableTurnLeftRight(System.Boolean)
extern void SnapTurnProviderBase_set_enableTurnLeftRight_mA12C92CD143D8DBCE0CB8C9B1AD5D1221BC62513 (void);
// 0x0000054F System.Boolean UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::get_enableTurnAround()
extern void SnapTurnProviderBase_get_enableTurnAround_mBDD9557E4365D79557C02612DB6211CEC921F0B1 (void);
// 0x00000550 System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::set_enableTurnAround(System.Boolean)
extern void SnapTurnProviderBase_set_enableTurnAround_m7F986600E4931C3157B0C68C6C3F484969FB0033 (void);
// 0x00000551 System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::Update()
extern void SnapTurnProviderBase_Update_m5A976A8A283FD65E2D7D7D5B0CDD8C908811ACBB (void);
// 0x00000552 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::ReadInput()
// 0x00000553 System.Single UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::GetTurnAmount(UnityEngine.Vector2)
extern void SnapTurnProviderBase_GetTurnAmount_m8ED0772ED87A2E33FA68B280111BBC1688D215C3 (void);
// 0x00000554 System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::StartTurn(System.Single)
extern void SnapTurnProviderBase_StartTurn_m8050D3721A33C34B57752916F121AC72754B6390 (void);
// 0x00000555 System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::FakeStartTurn(System.Boolean)
extern void SnapTurnProviderBase_FakeStartTurn_m7E059AB0072FC7622EFA51DADA5A4290975A3814 (void);
// 0x00000556 System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::FakeStartTurnAround()
extern void SnapTurnProviderBase_FakeStartTurnAround_m8C6CA0D15294B087F3B93488549801E48916CD76 (void);
// 0x00000557 System.Void UnityEngine.XR.Interaction.Toolkit.SnapTurnProviderBase::.ctor()
extern void SnapTurnProviderBase__ctor_m962618BDF42FF3FCDB3D8816C9ADDA6E18304F7D (void);
// 0x00000558 UnityEngine.XR.Interaction.Toolkit.TeleportationProvider UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::get_teleportationProvider()
extern void BaseTeleportationInteractable_get_teleportationProvider_m9B53CC4903106CE7C0DA0F861BB22ED63AAD076F (void);
// 0x00000559 System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::set_teleportationProvider(UnityEngine.XR.Interaction.Toolkit.TeleportationProvider)
extern void BaseTeleportationInteractable_set_teleportationProvider_m10689329CEEDA0CECFC6C6DE42FEC5F402726CED (void);
// 0x0000055A UnityEngine.XR.Interaction.Toolkit.MatchOrientation UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::get_matchOrientation()
extern void BaseTeleportationInteractable_get_matchOrientation_mB4CE35CEB0A0206457993CB28A618F300E4BC03D (void);
// 0x0000055B System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::set_matchOrientation(UnityEngine.XR.Interaction.Toolkit.MatchOrientation)
extern void BaseTeleportationInteractable_set_matchOrientation_mD9AD6D9C7CD63E80BDAFB6D6AC229531671960D9 (void);
// 0x0000055C UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable/TeleportTrigger UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::get_teleportTrigger()
extern void BaseTeleportationInteractable_get_teleportTrigger_m875F50A1066F596DA0CB800997B84B4A0F8B1A94 (void);
// 0x0000055D System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::set_teleportTrigger(UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable/TeleportTrigger)
extern void BaseTeleportationInteractable_set_teleportTrigger_m456E07E992D4B82240DC266B240D46E12F3FB55A (void);
// 0x0000055E UnityEngine.XR.Interaction.Toolkit.TeleportingEvent UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::get_teleporting()
extern void BaseTeleportationInteractable_get_teleporting_mA6FB2E68A293161C7032494906520E47B6B5A84E (void);
// 0x0000055F System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::set_teleporting(UnityEngine.XR.Interaction.Toolkit.TeleportingEvent)
extern void BaseTeleportationInteractable_set_teleporting_m5B4EC45250271E70D9E1735D2E69A1B7F760D011 (void);
// 0x00000560 System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::Awake()
extern void BaseTeleportationInteractable_Awake_mC0C13EE138834FD575C21D6CA01E1FC07F701600 (void);
// 0x00000561 System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::Reset()
extern void BaseTeleportationInteractable_Reset_mAA6ED9E19696086C7036357A04DAD5C5E8A10438 (void);
// 0x00000562 System.Boolean UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::GenerateTeleportRequest(UnityEngine.XR.Interaction.Toolkit.IXRInteractor,UnityEngine.RaycastHit,UnityEngine.XR.Interaction.Toolkit.TeleportRequest&)
extern void BaseTeleportationInteractable_GenerateTeleportRequest_m70FFEB12F9E0DEB0391C867E5740C656FA01E31A (void);
// 0x00000563 System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::SendTeleportRequest(UnityEngine.XR.Interaction.Toolkit.IXRInteractor)
extern void BaseTeleportationInteractable_SendTeleportRequest_m050DF693E20FB0FA6A6C51314336ABEB736C973D (void);
// 0x00000564 System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::OnSelectEntered(UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs)
extern void BaseTeleportationInteractable_OnSelectEntered_m0FD58F8C469202E81555C08B4362E2D23B620676 (void);
// 0x00000565 System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::OnSelectExited(UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs)
extern void BaseTeleportationInteractable_OnSelectExited_m104024A13FA59E4110738133C4FB571DB6607E83 (void);
// 0x00000566 System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::OnActivated(UnityEngine.XR.Interaction.Toolkit.ActivateEventArgs)
extern void BaseTeleportationInteractable_OnActivated_m3519F32AD8EF48DEA2DC762AA0203AC2CA2BF9E7 (void);
// 0x00000567 System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::OnDeactivated(UnityEngine.XR.Interaction.Toolkit.DeactivateEventArgs)
extern void BaseTeleportationInteractable_OnDeactivated_mCC3F748F7269D8A30EED80532E054CF274283D4E (void);
// 0x00000568 System.Boolean UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::GenerateTeleportRequest(UnityEngine.XR.Interaction.Toolkit.XRBaseInteractor,UnityEngine.RaycastHit,UnityEngine.XR.Interaction.Toolkit.TeleportRequest&)
extern void BaseTeleportationInteractable_GenerateTeleportRequest_mB9FB5D40C078FF126CDFD19CECB2C3DC8E6FA7A5 (void);
// 0x00000569 System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable::.ctor()
extern void BaseTeleportationInteractable__ctor_m03523AE1E1C51AF0E9B210844669220113406EE7 (void);
// 0x0000056A System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable/<>c::.cctor()
extern void U3CU3Ec__cctor_m46A80D0E445DDDCE7FCCCECA8DA2D02050A4247D (void);
// 0x0000056B System.Void UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable/<>c::.ctor()
extern void U3CU3Ec__ctor_m7D71BA0703858033BED989B6EE9B928786F3640B (void);
// 0x0000056C UnityEngine.XR.Interaction.Toolkit.TeleportingEventArgs UnityEngine.XR.Interaction.Toolkit.BaseTeleportationInteractable/<>c::<.ctor>b__27_0()
extern void U3CU3Ec_U3C_ctorU3Eb__27_0_m5B232FEC2B244B7B1F264DC2EB9C282BABE65962 (void);
// 0x0000056D UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.TeleportationAnchor::get_teleportAnchorTransform()
extern void TeleportationAnchor_get_teleportAnchorTransform_m0711868C6E4463287017D36942E8A5C03122A435 (void);
// 0x0000056E System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationAnchor::set_teleportAnchorTransform(UnityEngine.Transform)
extern void TeleportationAnchor_set_teleportAnchorTransform_m00BFEA234630A95B4B9BE291610D89DC72EB9A5F (void);
// 0x0000056F System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationAnchor::OnValidate()
extern void TeleportationAnchor_OnValidate_m7D4D44B9600ADB0E40D31F2D7AE24DBADC1036E5 (void);
// 0x00000570 System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationAnchor::Reset()
extern void TeleportationAnchor_Reset_m4EEAE41C190D2626B1A9F01A946CFD7E58E90B1F (void);
// 0x00000571 System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationAnchor::OnDrawGizmos()
extern void TeleportationAnchor_OnDrawGizmos_m5D8C112B038BBB334829CE1185DB35C0C45B925D (void);
// 0x00000572 System.Boolean UnityEngine.XR.Interaction.Toolkit.TeleportationAnchor::GenerateTeleportRequest(UnityEngine.XR.Interaction.Toolkit.IXRInteractor,UnityEngine.RaycastHit,UnityEngine.XR.Interaction.Toolkit.TeleportRequest&)
extern void TeleportationAnchor_GenerateTeleportRequest_mC00CA4094040F51A2B40D1E154B7F2443089046B (void);
// 0x00000573 System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationAnchor::.ctor()
extern void TeleportationAnchor__ctor_m8645304E8AFD708D9BF3C8E3B8D2F64F9CEBA427 (void);
// 0x00000574 System.Boolean UnityEngine.XR.Interaction.Toolkit.TeleportationArea::GenerateTeleportRequest(UnityEngine.XR.Interaction.Toolkit.IXRInteractor,UnityEngine.RaycastHit,UnityEngine.XR.Interaction.Toolkit.TeleportRequest&)
extern void TeleportationArea_GenerateTeleportRequest_m316BFEC3E6F188832FEB7FE20F4B3953A454A990 (void);
// 0x00000575 System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationArea::.ctor()
extern void TeleportationArea__ctor_mBD0DD39D29BA373207C79E8600D8F183D3E14EFB (void);
// 0x00000576 UnityEngine.XR.Interaction.Toolkit.TeleportRequest UnityEngine.XR.Interaction.Toolkit.TeleportationProvider::get_currentRequest()
extern void TeleportationProvider_get_currentRequest_m0CCE6B6BE488A506F4FD398A18C8D0450ED6C39B (void);
// 0x00000577 System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationProvider::set_currentRequest(UnityEngine.XR.Interaction.Toolkit.TeleportRequest)
extern void TeleportationProvider_set_currentRequest_m109FD936C57760C70C312B799E6AD6D7651B0581 (void);
// 0x00000578 System.Boolean UnityEngine.XR.Interaction.Toolkit.TeleportationProvider::get_validRequest()
extern void TeleportationProvider_get_validRequest_m083A1AF44E1AD7BD791A2B599216067B94D65788 (void);
// 0x00000579 System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationProvider::set_validRequest(System.Boolean)
extern void TeleportationProvider_set_validRequest_m539A9FBCF21BBCE6062D888442666D0679B27B0D (void);
// 0x0000057A System.Boolean UnityEngine.XR.Interaction.Toolkit.TeleportationProvider::QueueTeleportRequest(UnityEngine.XR.Interaction.Toolkit.TeleportRequest)
extern void TeleportationProvider_QueueTeleportRequest_mE1D319B5F451A6AD4CC2749D9B4CF6763E67A278 (void);
// 0x0000057B System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationProvider::Update()
extern void TeleportationProvider_Update_mF3A1A890CCFF2A42AC886504065D4F503E22C88D (void);
// 0x0000057C System.Void UnityEngine.XR.Interaction.Toolkit.TeleportationProvider::.ctor()
extern void TeleportationProvider__ctor_mE4031FC9A5B03DA60B3C68E52F39D0F721C3C2ED (void);
// 0x0000057D System.Void UnityEngine.XR.Interaction.Toolkit.GizmoHelpers::DrawWirePlaneOriented(UnityEngine.Vector3,UnityEngine.Quaternion,System.Single)
extern void GizmoHelpers_DrawWirePlaneOriented_m601D38814CCE4734D7248C027878AC09610001FA (void);
// 0x0000057E System.Void UnityEngine.XR.Interaction.Toolkit.GizmoHelpers::DrawWireCubeOriented(UnityEngine.Vector3,UnityEngine.Quaternion,System.Single)
extern void GizmoHelpers_DrawWireCubeOriented_mB0B3D31FD9FCEFEC22AFB3B26E9AA374BB918730 (void);
// 0x0000057F System.Void UnityEngine.XR.Interaction.Toolkit.GizmoHelpers::DrawAxisArrows(UnityEngine.Transform,System.Single)
extern void GizmoHelpers_DrawAxisArrows_m2E693699692850260E01A003FDE03C207C04804F (void);
// 0x00000580 System.Boolean UnityEngine.XR.Interaction.Toolkit.InputHelpers::IsPressed(UnityEngine.XR.InputDevice,UnityEngine.XR.Interaction.Toolkit.InputHelpers/Button,System.Boolean&,System.Single)
extern void InputHelpers_IsPressed_mD0516F35AE1B3765A098C89EDBC1E5F1E68144E2 (void);
// 0x00000581 System.Boolean UnityEngine.XR.Interaction.Toolkit.InputHelpers::TryReadSingleValue(UnityEngine.XR.InputDevice,UnityEngine.XR.Interaction.Toolkit.InputHelpers/Button,System.Single&)
extern void InputHelpers_TryReadSingleValue_m658270EEE0C9578ECB0A21556A09347DA3813051 (void);
// 0x00000582 System.Void UnityEngine.XR.Interaction.Toolkit.InputHelpers::.cctor()
extern void InputHelpers__cctor_m9959AB7052F722A32BD5C0F5065FB1D0E0383C5F (void);
// 0x00000583 System.Void UnityEngine.XR.Interaction.Toolkit.InputHelpers/ButtonInfo::.ctor(System.String,UnityEngine.XR.Interaction.Toolkit.InputHelpers/ButtonReadType)
extern void ButtonInfo__ctor_m3478ACD7B8502B0839AAA54A15EC75CE3A5A2A69 (void);
// 0x00000584 System.Void UnityEngine.XR.Interaction.Toolkit.SortingHelpers::Sort(System.Collections.Generic.IList`1<T>,System.Collections.Generic.IComparer`1<T>)
// 0x00000585 System.Void UnityEngine.XR.Interaction.Toolkit.SortingHelpers::SortByDistanceToInteractor(UnityEngine.XR.Interaction.Toolkit.IXRInteractor,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>)
extern void SortingHelpers_SortByDistanceToInteractor_mE70C409D7B9650D23AA37C83DCF4457385716D5C (void);
// 0x00000586 System.Int32 UnityEngine.XR.Interaction.Toolkit.SortingHelpers::InteractableDistanceComparison(UnityEngine.XR.Interaction.Toolkit.IXRInteractable,UnityEngine.XR.Interaction.Toolkit.IXRInteractable)
extern void SortingHelpers_InteractableDistanceComparison_m6AF8D736AF5F182F7A0FC8A6A8ED662D57B136B3 (void);
// 0x00000587 System.Void UnityEngine.XR.Interaction.Toolkit.SortingHelpers::.cctor()
extern void SortingHelpers__cctor_m5B6BEBB684FF311488D74E34B93688E9AE00BCE2 (void);
// 0x00000588 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::Awake()
extern void XRRig_Awake_m4C54DB98C4E12B1283219E8DB8F7649E8B02E9D3 (void);
// 0x00000589 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.XRRig::get_rig()
extern void XRRig_get_rig_mE186F9F6B042C09CA316CFB7137A8CC44D49A573 (void);
// 0x0000058A System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::set_rig(UnityEngine.GameObject)
extern void XRRig_set_rig_m3EB7C0D9BD2B867ACF1E100075E0C0BB467FCF95 (void);
// 0x0000058B UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.XRRig::get_cameraGameObject()
extern void XRRig_get_cameraGameObject_m599F292919A35F8427477F95D733377B56C43A73 (void);
// 0x0000058C System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::set_cameraGameObject(UnityEngine.GameObject)
extern void XRRig_set_cameraGameObject_m68EB375A3940A631155A30F1E85E712B5CCF73FC (void);
// 0x0000058D UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.XRRig::get_cameraFloorOffsetObject()
extern void XRRig_get_cameraFloorOffsetObject_m1218E7E974839EBB80C129E4611301124283D235 (void);
// 0x0000058E System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::set_cameraFloorOffsetObject(UnityEngine.GameObject)
extern void XRRig_set_cameraFloorOffsetObject_mC072D15643C2FCF1B004A287E0663BA6DBAED604 (void);
// 0x0000058F Unity.XR.CoreUtils.XROrigin/TrackingOriginMode UnityEngine.XR.Interaction.Toolkit.XRRig::get_requestedTrackingOriginMode()
extern void XRRig_get_requestedTrackingOriginMode_mC13FB64E7EA0423190E238CE2163B7D563FAAB15 (void);
// 0x00000590 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::set_requestedTrackingOriginMode(Unity.XR.CoreUtils.XROrigin/TrackingOriginMode)
extern void XRRig_set_requestedTrackingOriginMode_mEAB738898E3E74A6D0E6BF897DF7AC9A0C94C86B (void);
// 0x00000591 System.Single UnityEngine.XR.Interaction.Toolkit.XRRig::get_cameraYOffset()
extern void XRRig_get_cameraYOffset_m671108AC8E1F340886A0B37C38155586F3499B84 (void);
// 0x00000592 System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::set_cameraYOffset(System.Single)
extern void XRRig_set_cameraYOffset_m289E1253EB6C747D6D221881829D5E88874BC810 (void);
// 0x00000593 UnityEngine.XR.TrackingOriginModeFlags UnityEngine.XR.Interaction.Toolkit.XRRig::get_currentTrackingOriginMode()
extern void XRRig_get_currentTrackingOriginMode_m4E0D1ECA3BB9564009C4ADC500DDF4FCC2D0182B (void);
// 0x00000594 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRRig::get_rigInCameraSpacePos()
extern void XRRig_get_rigInCameraSpacePos_m504AE7211B9F2359312069B68DD810C00F04F578 (void);
// 0x00000595 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.XRRig::get_cameraInRigSpacePos()
extern void XRRig_get_cameraInRigSpacePos_mA397E5CCFBED6DB8DE87BE51E2C2CA686604B72E (void);
// 0x00000596 System.Single UnityEngine.XR.Interaction.Toolkit.XRRig::get_cameraInRigSpaceHeight()
extern void XRRig_get_cameraInRigSpaceHeight_m9ED1541D7D6485281124CE4EC109D826851BC575 (void);
// 0x00000597 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::RotateAroundCameraUsingRigUp(System.Single)
extern void XRRig_RotateAroundCameraUsingRigUp_mE9DB5E392764B04743D17BC410E1DB5D37A10CC2 (void);
// 0x00000598 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::MatchRigUp(UnityEngine.Vector3)
extern void XRRig_MatchRigUp_m02778B1BD71CC152FF1A66B7C448E1DED5464744 (void);
// 0x00000599 System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::MatchRigUpCameraForward(UnityEngine.Vector3,UnityEngine.Vector3)
extern void XRRig_MatchRigUpCameraForward_m0C2B0CEA4D62279A7E2D370B072996F8418D550E (void);
// 0x0000059A System.Boolean UnityEngine.XR.Interaction.Toolkit.XRRig::MatchRigUpRigForward(UnityEngine.Vector3,UnityEngine.Vector3)
extern void XRRig_MatchRigUpRigForward_m94F4910B4B27AAFD942946712A4098567C93A982 (void);
// 0x0000059B System.Void UnityEngine.XR.Interaction.Toolkit.XRRig::.ctor()
extern void XRRig__ctor_mCE1DD53EEE749B4BD2C5914BF5BA8E8B3C60334F (void);
// 0x0000059C System.Reflection.Assembly[] UnityEngine.XR.Interaction.Toolkit.Utilities.ReflectionUtils::GetCachedAssemblies()
extern void ReflectionUtils_GetCachedAssemblies_m7FA5BB9EF7E5293063433F744CB3586F7AFA6428 (void);
// 0x0000059D System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.ReflectionUtils::ForEachAssembly(System.Action`1<System.Reflection.Assembly>)
extern void ReflectionUtils_ForEachAssembly_m108C85DFA4980EC7F46536EC674ECD022ACACBF8 (void);
// 0x0000059E T UnityEngine.XR.Interaction.Toolkit.Utilities.ScriptableSettings`1::get_instance()
// 0x0000059F T UnityEngine.XR.Interaction.Toolkit.Utilities.ScriptableSettings`1::CreateAndLoad()
// 0x000005A0 System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.ScriptableSettings`1::.ctor()
// 0x000005A1 System.String UnityEngine.XR.Interaction.Toolkit.Utilities.ScriptableSettingsPathAttribute::get_path()
extern void ScriptableSettingsPathAttribute_get_path_m5865F5A04288486F58C11373396761B338174198 (void);
// 0x000005A2 System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.ScriptableSettingsPathAttribute::set_path(System.String)
extern void ScriptableSettingsPathAttribute_set_path_mE3FFB7D573FE8B57A1B80EF5E4CB3C75B05196DE (void);
// 0x000005A3 System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.ScriptableSettingsPathAttribute::.ctor(System.String)
extern void ScriptableSettingsPathAttribute__ctor_m8D9F1CDF5EA8280EEE13866B9126505637E25F2C (void);
// 0x000005A4 TAttribute UnityEngine.XR.Interaction.Toolkit.Utilities.TypeExtensions::GetAttribute(System.Type,System.Boolean)
// 0x000005A5 System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.TriggerContactMonitor::add_contactAdded(System.Action`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>)
extern void TriggerContactMonitor_add_contactAdded_m625E817F417893FC68A1F1230B6684C66E588FA4 (void);
// 0x000005A6 System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.TriggerContactMonitor::remove_contactAdded(System.Action`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>)
extern void TriggerContactMonitor_remove_contactAdded_m76CB17DF8810E065275C5E9B2935F9D708EDF128 (void);
// 0x000005A7 System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.TriggerContactMonitor::add_contactRemoved(System.Action`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>)
extern void TriggerContactMonitor_add_contactRemoved_mD880723A00B23F29E938E6009F27EA66B3D4D8AB (void);
// 0x000005A8 System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.TriggerContactMonitor::remove_contactRemoved(System.Action`1<UnityEngine.XR.Interaction.Toolkit.IXRInteractable>)
extern void TriggerContactMonitor_remove_contactRemoved_m9BFD21EB12A28EBF40681B392E6FD85EBD118E91 (void);
// 0x000005A9 UnityEngine.XR.Interaction.Toolkit.XRInteractionManager UnityEngine.XR.Interaction.Toolkit.Utilities.TriggerContactMonitor::get_interactionManager()
extern void TriggerContactMonitor_get_interactionManager_m962AC519D6229441CA8EB1F2703A6B653E0B9B1F (void);
// 0x000005AA System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.TriggerContactMonitor::set_interactionManager(UnityEngine.XR.Interaction.Toolkit.XRInteractionManager)
extern void TriggerContactMonitor_set_interactionManager_m43C96CAC16C5FEB57406D67B68065078FC50D4FC (void);
// 0x000005AB System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.TriggerContactMonitor::AddCollider(UnityEngine.Collider)
extern void TriggerContactMonitor_AddCollider_m90B52CC8A482935FE03014BA709AFED8C1A91210 (void);
// 0x000005AC System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.TriggerContactMonitor::RemoveCollider(UnityEngine.Collider)
extern void TriggerContactMonitor_RemoveCollider_mAD618FBAD24B9791B2613A2792CA5C846F2C23D4 (void);
// 0x000005AD System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.TriggerContactMonitor::ResolveUnassociatedColliders()
extern void TriggerContactMonitor_ResolveUnassociatedColliders_m2790DF3456DEC8F2EDC7DF84EA7B64E169E68F87 (void);
// 0x000005AE System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.TriggerContactMonitor::ResolveUnassociatedColliders(UnityEngine.XR.Interaction.Toolkit.IXRInteractable)
extern void TriggerContactMonitor_ResolveUnassociatedColliders_m1C1F8ACFAB59B76652A5321395085C18EED3B54B (void);
// 0x000005AF System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.TriggerContactMonitor::UpdateStayedColliders(System.Collections.Generic.List`1<UnityEngine.Collider>)
extern void TriggerContactMonitor_UpdateStayedColliders_mD2E17848428F8EC2F39855829EC043AAEFC9FB97 (void);
// 0x000005B0 System.Boolean UnityEngine.XR.Interaction.Toolkit.Utilities.TriggerContactMonitor::IsContacting(UnityEngine.XR.Interaction.Toolkit.IXRInteractable)
extern void TriggerContactMonitor_IsContacting_mDB8343D7E36539EE8B60D596DCDC4C5E2830BB76 (void);
// 0x000005B1 System.Boolean UnityEngine.XR.Interaction.Toolkit.Utilities.TriggerContactMonitor::IsDestroyed(UnityEngine.Collider)
extern void TriggerContactMonitor_IsDestroyed_m80DA0F1122E5C8E582379C7C615523BB6C704616 (void);
// 0x000005B2 System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.TriggerContactMonitor::.ctor()
extern void TriggerContactMonitor__ctor_m1F4312F4BFDBF70D5B3B9434FF5D32A276A1EE7A (void);
// 0x000005B3 System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.TriggerContactMonitor::.cctor()
extern void TriggerContactMonitor__cctor_m1B2BD458E5A92A64C930FECE6203F8BB05A7FE18 (void);
// 0x000005B4 UnityEngine.XR.Interaction.Toolkit.Utilities.Internal.ScriptableSettingsBase UnityEngine.XR.Interaction.Toolkit.Utilities.Internal.ScriptableSettingsBase::GetInstanceByType(System.Type)
extern void ScriptableSettingsBase_GetInstanceByType_m5AF034F9E4B889F925DC9239130754FA177C7064 (void);
// 0x000005B5 System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.Internal.ScriptableSettingsBase::Awake()
extern void ScriptableSettingsBase_Awake_m2772A5D5F973FCB0E4006C4BC41294A9F311201B (void);
// 0x000005B6 System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.Internal.ScriptableSettingsBase::OnEnable()
extern void ScriptableSettingsBase_OnEnable_m8D424C36FE448222EA165B6F21C11CAA745DCED2 (void);
// 0x000005B7 System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.Internal.ScriptableSettingsBase::OnLoaded()
extern void ScriptableSettingsBase_OnLoaded_m6B90F5D2D4DE34897AF0D5ECC7FD4C6C058EB488 (void);
// 0x000005B8 System.Boolean UnityEngine.XR.Interaction.Toolkit.Utilities.Internal.ScriptableSettingsBase::ValidatePath(System.String,System.String&)
extern void ScriptableSettingsBase_ValidatePath_m3AD32CF41B1CB8D5259C4F8F6E762C8ECF7FB13A (void);
// 0x000005B9 System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.Internal.ScriptableSettingsBase::.ctor()
extern void ScriptableSettingsBase__ctor_m8ACABB98DE308D194D6A46B945F11DAD0EF18D2F (void);
// 0x000005BA System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.Internal.ScriptableSettingsBase::.cctor()
extern void ScriptableSettingsBase__cctor_m3A85C7078B4A36668F4BFF7CC9027311C7EE9916 (void);
// 0x000005BB System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.Internal.ScriptableSettingsBase`1::.ctor()
// 0x000005BC System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.Internal.ScriptableSettingsBase`1::Save(System.String)
// 0x000005BD System.String UnityEngine.XR.Interaction.Toolkit.Utilities.Internal.ScriptableSettingsBase`1::GetFilePath()
// 0x000005BE System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.Internal.ScriptableSettingsBase`1::.cctor()
// 0x000005BF System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.Pooling.LinkedPool`1::.ctor(System.Func`1<T>,System.Action`1<T>,System.Action`1<T>,System.Action`1<T>,System.Boolean,System.Int32)
// 0x000005C0 System.Int32 UnityEngine.XR.Interaction.Toolkit.Utilities.Pooling.LinkedPool`1::get_countInactive()
// 0x000005C1 System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.Pooling.LinkedPool`1::set_countInactive(System.Int32)
// 0x000005C2 T UnityEngine.XR.Interaction.Toolkit.Utilities.Pooling.LinkedPool`1::Get()
// 0x000005C3 UnityEngine.XR.Interaction.Toolkit.Utilities.Pooling.PooledObject`1<T> UnityEngine.XR.Interaction.Toolkit.Utilities.Pooling.LinkedPool`1::Get(T&)
// 0x000005C4 System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.Pooling.LinkedPool`1::Release(T)
// 0x000005C5 System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.Pooling.LinkedPool`1::Clear()
// 0x000005C6 System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.Pooling.LinkedPool`1::Dispose()
// 0x000005C7 System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.Pooling.LinkedPool`1/LinkedPoolItem::.ctor()
// 0x000005C8 System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.Pooling.PooledObject`1::.ctor(T,UnityEngine.XR.Interaction.Toolkit.Utilities.Pooling.LinkedPool`1<T>)
// 0x000005C9 System.Void UnityEngine.XR.Interaction.Toolkit.Utilities.Pooling.PooledObject`1::System.IDisposable.Dispose()
// 0x000005CA UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel::get_leftStick()
extern void GamepadModel_get_leftStick_m05E487F6B1C65806FA9B5657564D00249B6A3556 (void);
// 0x000005CB System.Void UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel::set_leftStick(UnityEngine.Vector2)
extern void GamepadModel_set_leftStick_m8579917EDFBF3F998A18240C454FED95E50E1587 (void);
// 0x000005CC UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel::get_dpad()
extern void GamepadModel_get_dpad_m302B674C6D8AF62092807DAEAAA44AC3992510F1 (void);
// 0x000005CD System.Void UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel::set_dpad(UnityEngine.Vector2)
extern void GamepadModel_set_dpad_m39D1B66AF19424C3A1308577EC7108024DA21963 (void);
// 0x000005CE System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel::get_submitButtonDown()
extern void GamepadModel_get_submitButtonDown_m37C632D27087A446184DEBFF8EEE2E8BCCF8575D (void);
// 0x000005CF System.Void UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel::set_submitButtonDown(System.Boolean)
extern void GamepadModel_set_submitButtonDown_m23F72A7B2DF8A8808F6889A1E98BD8931ED3458B (void);
// 0x000005D0 UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel::get_submitButtonDelta()
extern void GamepadModel_get_submitButtonDelta_m0EE8DBF1F060C7B0607127FB6AB4E892EC61A611 (void);
// 0x000005D1 System.Void UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel::set_submitButtonDelta(UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState)
extern void GamepadModel_set_submitButtonDelta_m9B1EDCDDB54FF0F21E0EF2341EDEC78E4E54A884 (void);
// 0x000005D2 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel::get_cancelButtonDown()
extern void GamepadModel_get_cancelButtonDown_m086620B25E1BF6CC385D240CD48CD0DB55D360B9 (void);
// 0x000005D3 System.Void UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel::set_cancelButtonDown(System.Boolean)
extern void GamepadModel_set_cancelButtonDown_mF13195D2D11D9371BDC1310B58075B7D93626F84 (void);
// 0x000005D4 UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel::get_cancelButtonDelta()
extern void GamepadModel_get_cancelButtonDelta_m2F7BF6DD3A971F5122856813E3CD13BF868D24DA (void);
// 0x000005D5 System.Void UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel::set_cancelButtonDelta(UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState)
extern void GamepadModel_set_cancelButtonDelta_mD4ED8E73A3D8A53E2F8241D31131022FBFB0373B (void);
// 0x000005D6 UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel/ImplementationData UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel::get_implementationData()
extern void GamepadModel_get_implementationData_mF118CFCAE36CE8BAF659D32D26B3EFB160A3B3BF (void);
// 0x000005D7 System.Void UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel::set_implementationData(UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel/ImplementationData)
extern void GamepadModel_set_implementationData_mF30CAE55823B11E6951323F6839D519CE2E5EBA9 (void);
// 0x000005D8 System.Void UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel::Reset()
extern void GamepadModel_Reset_m028796E2B92E78CF1E054A7D97CDF42A9A2AC815 (void);
// 0x000005D9 System.Void UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel::OnFrameFinished()
extern void GamepadModel_OnFrameFinished_m2F0775532D18EB593DA0D2D8E1DC025A82C82AD5 (void);
// 0x000005DA System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel/ImplementationData::get_consecutiveMoveCount()
extern void ImplementationData_get_consecutiveMoveCount_mA3B5FF3A4D9BBBFD14CBAEF381A3B09245136BF5 (void);
// 0x000005DB System.Void UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel/ImplementationData::set_consecutiveMoveCount(System.Int32)
extern void ImplementationData_set_consecutiveMoveCount_m91D6C0702BD7F193B029443EB3CFFE3400A873AA (void);
// 0x000005DC UnityEngine.EventSystems.MoveDirection UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel/ImplementationData::get_lastMoveDirection()
extern void ImplementationData_get_lastMoveDirection_m70CE1DDAEBA14387D27273E11B5C55CD9CA5DD3A (void);
// 0x000005DD System.Void UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel/ImplementationData::set_lastMoveDirection(UnityEngine.EventSystems.MoveDirection)
extern void ImplementationData_set_lastMoveDirection_m25C3B0B1B7CCA64B134D4C830A3F29098A0CE90A (void);
// 0x000005DE System.Single UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel/ImplementationData::get_lastMoveTime()
extern void ImplementationData_get_lastMoveTime_mE68BD5B91C6F28F0EAF230142A28241181A177F5 (void);
// 0x000005DF System.Void UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel/ImplementationData::set_lastMoveTime(System.Single)
extern void ImplementationData_set_lastMoveTime_m204AECF315C9F05B23A27749531D8D43A0825084 (void);
// 0x000005E0 System.Void UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel/ImplementationData::Reset()
extern void ImplementationData_Reset_m6952C9AE850B2D99257334E837C9A923C39867AD (void);
// 0x000005E1 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::get_move()
extern void JoystickModel_get_move_mB60103AA953140276E6BDBFF9E2674048B666B81 (void);
// 0x000005E2 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::set_move(UnityEngine.Vector2)
extern void JoystickModel_set_move_m84DB43EE4C57318CE0B7FFC8416A6E9DC7DEDEFD (void);
// 0x000005E3 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::get_hat()
extern void JoystickModel_get_hat_m60938F380B439629A5D0E69A9CD0B24812951CC3 (void);
// 0x000005E4 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::set_hat(UnityEngine.Vector2)
extern void JoystickModel_set_hat_mEEFA4CAF09C6DE4B0B10287C9D2276E8D180F232 (void);
// 0x000005E5 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::get_submitButtonDown()
extern void JoystickModel_get_submitButtonDown_m2C594CD060FC1467793EB7D04F3A356D3FF5215F (void);
// 0x000005E6 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::set_submitButtonDown(System.Boolean)
extern void JoystickModel_set_submitButtonDown_m972C04699F6CF1AE3EF76B94B9F303D508345596 (void);
// 0x000005E7 UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::get_submitButtonDelta()
extern void JoystickModel_get_submitButtonDelta_m012B855F15407CE39563A2465270BFE766488E7A (void);
// 0x000005E8 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::set_submitButtonDelta(UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState)
extern void JoystickModel_set_submitButtonDelta_mBCE238395763AD138FBF5CAD201B57F4AAF0A838 (void);
// 0x000005E9 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::get_cancelButtonDown()
extern void JoystickModel_get_cancelButtonDown_m0D382FCC9FD1D913786C962041D034B0A93FABDA (void);
// 0x000005EA System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::set_cancelButtonDown(System.Boolean)
extern void JoystickModel_set_cancelButtonDown_mF5A043FAAB87DC5964D93A18CF3D643600009BEA (void);
// 0x000005EB UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::get_cancelButtonDelta()
extern void JoystickModel_get_cancelButtonDelta_m51F7C586967ECC22CE4DA5F81255F83347A71E9E (void);
// 0x000005EC System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::set_cancelButtonDelta(UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState)
extern void JoystickModel_set_cancelButtonDelta_m508A4F611F64F834D6EDB84B6539F80FAD1F98DE (void);
// 0x000005ED UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel/ImplementationData UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::get_implementationData()
extern void JoystickModel_get_implementationData_mE5B08F7B50DD4815D1930845A677CB4620467160 (void);
// 0x000005EE System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::set_implementationData(UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel/ImplementationData)
extern void JoystickModel_set_implementationData_m1654E5AEE33F55136D14F090EC47DF7E5C097C39 (void);
// 0x000005EF System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::Reset()
extern void JoystickModel_Reset_mAFDFEBC8EA109267A0A16C62033097C38AB9849E (void);
// 0x000005F0 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel::OnFrameFinished()
extern void JoystickModel_OnFrameFinished_mEF369FFD6CC791F3E9EE01510F1B07356D28A804 (void);
// 0x000005F1 System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel/ImplementationData::get_consecutiveMoveCount()
extern void ImplementationData_get_consecutiveMoveCount_mB600F1F6A45941D8114E410D6014964554D7ADEC (void);
// 0x000005F2 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel/ImplementationData::set_consecutiveMoveCount(System.Int32)
extern void ImplementationData_set_consecutiveMoveCount_mE564012624169F567A720A33E73AA649FD164198 (void);
// 0x000005F3 UnityEngine.EventSystems.MoveDirection UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel/ImplementationData::get_lastMoveDirection()
extern void ImplementationData_get_lastMoveDirection_m5795BF4D421FE58497DF6E154592CCC66CA43018 (void);
// 0x000005F4 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel/ImplementationData::set_lastMoveDirection(UnityEngine.EventSystems.MoveDirection)
extern void ImplementationData_set_lastMoveDirection_mE7B0C290F1AB9C8C30172606E3B05C9A9EE0B59B (void);
// 0x000005F5 System.Single UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel/ImplementationData::get_lastMoveTime()
extern void ImplementationData_get_lastMoveTime_mFEE11CE8F3FFDD639707E8064EA99CCD64F5C99F (void);
// 0x000005F6 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel/ImplementationData::set_lastMoveTime(System.Single)
extern void ImplementationData_set_lastMoveTime_m008BD50A07C1403D58D895BE67A571FF72C914D4 (void);
// 0x000005F7 System.Void UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel/ImplementationData::Reset()
extern void ImplementationData_Reset_m140D036D05B8FF021576CAABBCC5DC942AC9C079 (void);
// 0x000005F8 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::get_isDown()
extern void MouseButtonModel_get_isDown_m6D25D5D7BE9E1781DF3B00F4C0ADD0942F7A0A8C (void);
// 0x000005F9 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::set_isDown(System.Boolean)
extern void MouseButtonModel_set_isDown_mF109D7F287B91F942F835520CB7B67EC131A9EC0 (void);
// 0x000005FA UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::get_lastFrameDelta()
extern void MouseButtonModel_get_lastFrameDelta_mF2AC9472F0D1F820ED76F1D6F759B84B97E3842E (void);
// 0x000005FB System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::set_lastFrameDelta(UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState)
extern void MouseButtonModel_set_lastFrameDelta_m760052CA3C1CA5CE93AA226D9F6D7D46023D5346 (void);
// 0x000005FC System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::Reset()
extern void MouseButtonModel_Reset_m04966A9974669AFD8314FF5D8DA61B0AA13D8808 (void);
// 0x000005FD System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::OnFrameFinished()
extern void MouseButtonModel_OnFrameFinished_m3AA8EAB2730BD77885C53B5127E65FBADC09DF89 (void);
// 0x000005FE System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::CopyTo(UnityEngine.EventSystems.PointerEventData)
extern void MouseButtonModel_CopyTo_mE192240DC4F3852B78A43812C3273BE692F95B04 (void);
// 0x000005FF System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel::CopyFrom(UnityEngine.EventSystems.PointerEventData)
extern void MouseButtonModel_CopyFrom_mDB836BEC9F0538CD4C75CC917EA71A474279B1E6 (void);
// 0x00000600 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::get_isDragging()
extern void ImplementationData_get_isDragging_m4342CE900F2E1C5F378AAF38248795FDB757278A (void);
// 0x00000601 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::set_isDragging(System.Boolean)
extern void ImplementationData_set_isDragging_m23603F83850AE86ED35D0A35EA577A51A5934912 (void);
// 0x00000602 System.Single UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::get_pressedTime()
extern void ImplementationData_get_pressedTime_m6BB28908890AC2AA318371062BD0B1825AD011A0 (void);
// 0x00000603 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::set_pressedTime(System.Single)
extern void ImplementationData_set_pressedTime_m08CE027B7019E15F97EC2997A310D2E26B2B688A (void);
// 0x00000604 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::get_pressedPosition()
extern void ImplementationData_get_pressedPosition_m68E4FD86C4F9EC5B81D3A15A9ED5776642075218 (void);
// 0x00000605 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::set_pressedPosition(UnityEngine.Vector2)
extern void ImplementationData_set_pressedPosition_m1402B47299E1C642D94FAF5AA83750DCBC61FA10 (void);
// 0x00000606 UnityEngine.EventSystems.RaycastResult UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::get_pressedRaycast()
extern void ImplementationData_get_pressedRaycast_mBDF58873A81E64D77396EEDD9BA9FDE899807683 (void);
// 0x00000607 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::set_pressedRaycast(UnityEngine.EventSystems.RaycastResult)
extern void ImplementationData_set_pressedRaycast_m3FEA7BEBCA8A181BCBA546A396608AD05E719314 (void);
// 0x00000608 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::get_pressedGameObject()
extern void ImplementationData_get_pressedGameObject_mED5188E469B0B53324D43C84CDC4092BFE81802B (void);
// 0x00000609 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::set_pressedGameObject(UnityEngine.GameObject)
extern void ImplementationData_set_pressedGameObject_m43A6B848D7254A1A27999F73ACDEAFC53B69A6E5 (void);
// 0x0000060A UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::get_pressedGameObjectRaw()
extern void ImplementationData_get_pressedGameObjectRaw_mE114B4837644AF9AA92C0AB5952ACC15385A8E35 (void);
// 0x0000060B System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::set_pressedGameObjectRaw(UnityEngine.GameObject)
extern void ImplementationData_set_pressedGameObjectRaw_mBF3547F3629CF684A4151F0EB8EDC49AA6C85D6E (void);
// 0x0000060C UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::get_draggedGameObject()
extern void ImplementationData_get_draggedGameObject_m5AABEB516101C86E6A8E7243C2E12B3BD2DDE43E (void);
// 0x0000060D System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::set_draggedGameObject(UnityEngine.GameObject)
extern void ImplementationData_set_draggedGameObject_m9992F3D5D397185C774C37867A18FED90348B6F6 (void);
// 0x0000060E System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel/ImplementationData::Reset()
extern void ImplementationData_Reset_mE8D9F86E602D177FCA6FEC7F0F8279D9EA08F60F (void);
// 0x0000060F System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_pointerId()
extern void MouseModel_get_pointerId_m4093B901532AE29AF876BDE011E97CDB75B19A48 (void);
// 0x00000610 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_changedThisFrame()
extern void MouseModel_get_changedThisFrame_m9FA4FB5A8C2561339EA712BBD12468ADF6B31500 (void);
// 0x00000611 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_changedThisFrame(System.Boolean)
extern void MouseModel_set_changedThisFrame_m654FCF5EE83F82EEFF6939869044FE1781239014 (void);
// 0x00000612 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_position()
extern void MouseModel_get_position_m7E6304F677CAB4B807B518B947B95AA63A2BE95A (void);
// 0x00000613 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_position(UnityEngine.Vector2)
extern void MouseModel_set_position_mF52DACDB97F269AEC85646486093D6A135C5E509 (void);
// 0x00000614 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_deltaPosition()
extern void MouseModel_get_deltaPosition_m343DD465AA88D7C5DE2A2E8A48CC3645434F70FF (void);
// 0x00000615 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_deltaPosition(UnityEngine.Vector2)
extern void MouseModel_set_deltaPosition_mF4C0644A65E3E98A9A397643D0E006B9187654DA (void);
// 0x00000616 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_scrollDelta()
extern void MouseModel_get_scrollDelta_mE5D60044DDB3DC20CB2660C371DCF359DE7B19E0 (void);
// 0x00000617 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_scrollDelta(UnityEngine.Vector2)
extern void MouseModel_set_scrollDelta_m107437C513BD8F66EFDE6160EF224FEC6DA1F7A9 (void);
// 0x00000618 UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_leftButton()
extern void MouseModel_get_leftButton_m4E4FEAA3354E2243FC862B4E1212D8C372B399A0 (void);
// 0x00000619 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_leftButton(UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel)
extern void MouseModel_set_leftButton_mDFA9E10E68EC1E60BDAA76BEC99F128F69B0272A (void);
// 0x0000061A System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_leftButtonPressed(System.Boolean)
extern void MouseModel_set_leftButtonPressed_mF1308166818C7AE8C3083EAE08FF32B24C8DDBF1 (void);
// 0x0000061B UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_rightButton()
extern void MouseModel_get_rightButton_m847C28E359189D4A2D4E39F0F5D3CC9943D5E624 (void);
// 0x0000061C System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_rightButton(UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel)
extern void MouseModel_set_rightButton_m41EB3062E8E1FD0F92D648F5591DBCE675E81FDF (void);
// 0x0000061D System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_rightButtonPressed(System.Boolean)
extern void MouseModel_set_rightButtonPressed_m87EF490742E8A801BBAB04A32A4B868C7E6031AE (void);
// 0x0000061E UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::get_middleButton()
extern void MouseModel_get_middleButton_m8997BE389494AA17D6BF696BDF1E4889A68EA3C1 (void);
// 0x0000061F System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_middleButton(UnityEngine.XR.Interaction.Toolkit.UI.MouseButtonModel)
extern void MouseModel_set_middleButton_m528B124FF921B92CD25CD2EE623D97B8DE01C318 (void);
// 0x00000620 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::set_middleButtonPressed(System.Boolean)
extern void MouseModel_set_middleButtonPressed_mF1E5EA114314006CDD15F484FCE7450F3D3B0A39 (void);
// 0x00000621 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::.ctor(System.Int32)
extern void MouseModel__ctor_m63009692E802DED0663F43C9C8C5190FF33C8573 (void);
// 0x00000622 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::OnFrameFinished()
extern void MouseModel_OnFrameFinished_m3C72244B03A8536965118B81CB098E355CCAE12D (void);
// 0x00000623 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::CopyTo(UnityEngine.EventSystems.PointerEventData)
extern void MouseModel_CopyTo_m783AAB4CDC5D0569D63B7DCDFFDD13E6219AA8BA (void);
// 0x00000624 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel::CopyFrom(UnityEngine.EventSystems.PointerEventData)
extern void MouseModel_CopyFrom_m7B8817A31CE42B0A96A5FAD2B93DEF906E4E1055 (void);
// 0x00000625 System.Collections.Generic.List`1<UnityEngine.GameObject> UnityEngine.XR.Interaction.Toolkit.UI.MouseModel/InternalData::get_hoverTargets()
extern void InternalData_get_hoverTargets_m7B27E64A82CB4C34D900E18D81B2BDCE8336EA4C (void);
// 0x00000626 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel/InternalData::set_hoverTargets(System.Collections.Generic.List`1<UnityEngine.GameObject>)
extern void InternalData_set_hoverTargets_m0EBDF30E6181C88E401E66EF7241F8C206B88360 (void);
// 0x00000627 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.MouseModel/InternalData::get_pointerTarget()
extern void InternalData_get_pointerTarget_m4C93CAD2F36BD7E897463C1C3DE6BD07B741BF06 (void);
// 0x00000628 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel/InternalData::set_pointerTarget(UnityEngine.GameObject)
extern void InternalData_set_pointerTarget_mC6341AA6C2995C1E180BA15AE61884C000F6D89C (void);
// 0x00000629 System.Void UnityEngine.XR.Interaction.Toolkit.UI.MouseModel/InternalData::Reset()
extern void InternalData_Reset_m285105197FFE5EC122647161C449132D50E4472F (void);
// 0x0000062A System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::get_pointerId()
extern void TouchModel_get_pointerId_mEF567A1F3619C12F6519E4A6335E47BEC45F3D6A (void);
// 0x0000062B UnityEngine.TouchPhase UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::get_selectPhase()
extern void TouchModel_get_selectPhase_m8EF259C3B4DE6A8B17699E796E4294405E07450D (void);
// 0x0000062C System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::set_selectPhase(UnityEngine.TouchPhase)
extern void TouchModel_set_selectPhase_m20B064E217FF3B1FC1D408A613E37D482B7ABFE7 (void);
// 0x0000062D UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::get_selectDelta()
extern void TouchModel_get_selectDelta_mE61F993C8533C9E3BBEB2BDBDC65DB68D19C15C5 (void);
// 0x0000062E System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::set_selectDelta(UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState)
extern void TouchModel_set_selectDelta_m78599CB986783C0797E2C4DFF21B3C41062E29BD (void);
// 0x0000062F System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::get_changedThisFrame()
extern void TouchModel_get_changedThisFrame_mAF76A9DB5F6F80A8BE56ADB2BDD35E55A5BE717B (void);
// 0x00000630 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::set_changedThisFrame(System.Boolean)
extern void TouchModel_set_changedThisFrame_m6F51A89025E6D541FAD0C743D409CA10F0981ECF (void);
// 0x00000631 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::get_position()
extern void TouchModel_get_position_m6D3991EE4E0BD3CF7D530F9BDCB34804A21C431F (void);
// 0x00000632 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::set_position(UnityEngine.Vector2)
extern void TouchModel_set_position_mCC5A8772603B39F6EB6440B5592AA3FCB813D908 (void);
// 0x00000633 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::get_deltaPosition()
extern void TouchModel_get_deltaPosition_m8F1A9044D3FFE83FA0E82B3D6268829F6DD2A5CD (void);
// 0x00000634 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::set_deltaPosition(UnityEngine.Vector2)
extern void TouchModel_set_deltaPosition_m347C7275855704F7257AADD47BCABBBEA82F5499 (void);
// 0x00000635 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::.ctor(System.Int32)
extern void TouchModel__ctor_m7DCCF8284C173C8BD0BE01B0CD15F912C15FEF4B (void);
// 0x00000636 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::Reset()
extern void TouchModel_Reset_m23AF647E5BDA070B4FAF70877E2A5932D5235454 (void);
// 0x00000637 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::OnFrameFinished()
extern void TouchModel_OnFrameFinished_m4FD14ED5AF9964A444CD372A80B81ED55671FEF2 (void);
// 0x00000638 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::CopyTo(UnityEngine.EventSystems.PointerEventData)
extern void TouchModel_CopyTo_mDDC9DCAA045380589E0325B4D8D272E419D4A75C (void);
// 0x00000639 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel::CopyFrom(UnityEngine.EventSystems.PointerEventData)
extern void TouchModel_CopyFrom_m6727074A88A573B3B5A696C9BAC2EE03F1FD70FF (void);
// 0x0000063A System.Collections.Generic.List`1<UnityEngine.GameObject> UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::get_hoverTargets()
extern void ImplementationData_get_hoverTargets_m4291FA348576902BD6421C43CEF21005B42DDEA2 (void);
// 0x0000063B System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::set_hoverTargets(System.Collections.Generic.List`1<UnityEngine.GameObject>)
extern void ImplementationData_set_hoverTargets_mA2493C8E719D7734B4B52E0224B269C9265795FE (void);
// 0x0000063C UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::get_pointerTarget()
extern void ImplementationData_get_pointerTarget_m1B2B7AB756D7AB58E4DDD61724B28C5BEA7ED45F (void);
// 0x0000063D System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::set_pointerTarget(UnityEngine.GameObject)
extern void ImplementationData_set_pointerTarget_m0D4C6DE0126FB9B434079FB0191701AE39D11CFA (void);
// 0x0000063E System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::get_isDragging()
extern void ImplementationData_get_isDragging_mA2CDC9BC26BCAE431DC2D5556C26C4081C0120EC (void);
// 0x0000063F System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::set_isDragging(System.Boolean)
extern void ImplementationData_set_isDragging_mF4D332D1A15D3A25CA9DCD01FA66D1DD3509053A (void);
// 0x00000640 System.Single UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::get_pressedTime()
extern void ImplementationData_get_pressedTime_m72D41F1D9D6D5374145B9EA73D48DD514DF57FD8 (void);
// 0x00000641 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::set_pressedTime(System.Single)
extern void ImplementationData_set_pressedTime_m1DD37E6DF363A9D52AAB0DF5D41FA85D480412AB (void);
// 0x00000642 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::get_pressedPosition()
extern void ImplementationData_get_pressedPosition_m521F6BF90F71F5364A9D3C9A7DBEC1B3263C2410 (void);
// 0x00000643 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::set_pressedPosition(UnityEngine.Vector2)
extern void ImplementationData_set_pressedPosition_mE0AE62062AD3BB0B3F91FC5A0A72C984838BB6A8 (void);
// 0x00000644 UnityEngine.EventSystems.RaycastResult UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::get_pressedRaycast()
extern void ImplementationData_get_pressedRaycast_m449154600AFBECB2454BE161E4F2D8E1C64E2725 (void);
// 0x00000645 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::set_pressedRaycast(UnityEngine.EventSystems.RaycastResult)
extern void ImplementationData_set_pressedRaycast_mD8206A598973DF87B20BDBBEC8E6E470D7EDC8FB (void);
// 0x00000646 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::get_pressedGameObject()
extern void ImplementationData_get_pressedGameObject_m1C35ACFE7671A98B1BE4C9E63F99DE6F26F5A701 (void);
// 0x00000647 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::set_pressedGameObject(UnityEngine.GameObject)
extern void ImplementationData_set_pressedGameObject_m0B1B3517DF2991D515A6EE42D9A4E1EEB0F3D1A8 (void);
// 0x00000648 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::get_pressedGameObjectRaw()
extern void ImplementationData_get_pressedGameObjectRaw_m9ACBBB249DE666C8A4FC22EF9D2738F7769ABC26 (void);
// 0x00000649 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::set_pressedGameObjectRaw(UnityEngine.GameObject)
extern void ImplementationData_set_pressedGameObjectRaw_m53BFBDBF206350007C3B16570C0D1D1017B4478F (void);
// 0x0000064A UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::get_draggedGameObject()
extern void ImplementationData_get_draggedGameObject_mE3FA41A9E5B1A53CE2D810ECB6F70E931C8C24D2 (void);
// 0x0000064B System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::set_draggedGameObject(UnityEngine.GameObject)
extern void ImplementationData_set_draggedGameObject_m6E44F10143BEC035EA6D122100AE0E331D40EF45 (void);
// 0x0000064C System.Void UnityEngine.XR.Interaction.Toolkit.UI.TouchModel/ImplementationData::Reset()
extern void ImplementationData_Reset_mCC0BA6F7121A295E5A12ED99C63C2A644C4CBD2D (void);
// 0x0000064D System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::.ctor(UnityEngine.EventSystems.EventSystem)
extern void TrackedDeviceEventData__ctor_m84DA911667F1B78CAA3C828871BA1C0E6B472513 (void);
// 0x0000064E System.Collections.Generic.List`1<UnityEngine.Vector3> UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::get_rayPoints()
extern void TrackedDeviceEventData_get_rayPoints_m634507CA62EF8BCFC3A5F1B7F1DE107480FBFE7D (void);
// 0x0000064F System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::set_rayPoints(System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern void TrackedDeviceEventData_set_rayPoints_m50DE65136BB92487876DC7FA3E8FD98AB95CDE04 (void);
// 0x00000650 System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::get_rayHitIndex()
extern void TrackedDeviceEventData_get_rayHitIndex_mF78EEEBC65BFB650372F8AE3736CC747A852D857 (void);
// 0x00000651 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::set_rayHitIndex(System.Int32)
extern void TrackedDeviceEventData_set_rayHitIndex_m1DBE5C18ABAC0E5B241D10DB6164A391F37D5AF7 (void);
// 0x00000652 UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::get_layerMask()
extern void TrackedDeviceEventData_get_layerMask_m4A2A83C58E6B60DC4ED886236CCB760E70D610DD (void);
// 0x00000653 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::set_layerMask(UnityEngine.LayerMask)
extern void TrackedDeviceEventData_set_layerMask_mE98A92C0797C746EE0692EA41121D862C279D76F (void);
// 0x00000654 UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractor UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData::get_interactor()
extern void TrackedDeviceEventData_get_interactor_mAB97D54909C335DE1C55CE0DA071DB1B078320EC (void);
// 0x00000655 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::get_ignoreReversedGraphics()
extern void TrackedDeviceGraphicRaycaster_get_ignoreReversedGraphics_m67397D0EDB5E58DAC62754B97DCBBFD8006F6217 (void);
// 0x00000656 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::set_ignoreReversedGraphics(System.Boolean)
extern void TrackedDeviceGraphicRaycaster_set_ignoreReversedGraphics_mEDEF9B517AC5D2C807DBAEA30B38A45631AF4244 (void);
// 0x00000657 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::get_checkFor2DOcclusion()
extern void TrackedDeviceGraphicRaycaster_get_checkFor2DOcclusion_m4A896F3482512E5F84E842FD81344FD376F16483 (void);
// 0x00000658 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::set_checkFor2DOcclusion(System.Boolean)
extern void TrackedDeviceGraphicRaycaster_set_checkFor2DOcclusion_m090F9DC270B6D82514EAA8D3EFE270A342CE8959 (void);
// 0x00000659 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::get_checkFor3DOcclusion()
extern void TrackedDeviceGraphicRaycaster_get_checkFor3DOcclusion_m81B936C36E3939FE427C0F83828AB40F25DCDE46 (void);
// 0x0000065A System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::set_checkFor3DOcclusion(System.Boolean)
extern void TrackedDeviceGraphicRaycaster_set_checkFor3DOcclusion_m9B197AC3C42575A001DC499159F4B012BA4B80B1 (void);
// 0x0000065B UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::get_blockingMask()
extern void TrackedDeviceGraphicRaycaster_get_blockingMask_m04A970E664E86282B4FA8F768E3FD57CECAE22B9 (void);
// 0x0000065C System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::set_blockingMask(UnityEngine.LayerMask)
extern void TrackedDeviceGraphicRaycaster_set_blockingMask_m7D7EC827BFCFAC1C8FEDC12D8B7FD47A596A758E (void);
// 0x0000065D UnityEngine.QueryTriggerInteraction UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::get_raycastTriggerInteraction()
extern void TrackedDeviceGraphicRaycaster_get_raycastTriggerInteraction_m5B3AE66C78F898828750D70E7C248E3DD314B2FF (void);
// 0x0000065E System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::set_raycastTriggerInteraction(UnityEngine.QueryTriggerInteraction)
extern void TrackedDeviceGraphicRaycaster_set_raycastTriggerInteraction_m59A653ECE711A18DD756571637443BBC14CE9C44 (void);
// 0x0000065F UnityEngine.Camera UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::get_eventCamera()
extern void TrackedDeviceGraphicRaycaster_get_eventCamera_m8B52EB17FFC37F45CF8145AB861936BA6466FB73 (void);
// 0x00000660 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::Raycast(UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void TrackedDeviceGraphicRaycaster_Raycast_m67913B9B94A5A1B9077CC201F6EB3963F1C5D819 (void);
// 0x00000661 UnityEngine.Canvas UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::get_canvas()
extern void TrackedDeviceGraphicRaycaster_get_canvas_mAD7A34E53FB188AC4DA28255C022DAFCBBA5613D (void);
// 0x00000662 UnityEngine.RaycastHit UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::FindClosestHit(UnityEngine.RaycastHit[],System.Int32)
extern void TrackedDeviceGraphicRaycaster_FindClosestHit_m90A61B47165A9C072BB7879FE72753C87EF62497 (void);
// 0x00000663 UnityEngine.RaycastHit2D UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::FindClosestHit(UnityEngine.RaycastHit2D[],System.Int32)
extern void TrackedDeviceGraphicRaycaster_FindClosestHit_mFDC5F6850B9AE7BE705AC95267570FF2F4344467 (void);
// 0x00000664 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::PerformRaycasts(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void TrackedDeviceGraphicRaycaster_PerformRaycasts_mFCEEBBF50B3116C9783A46D8A99F138FB7C788A2 (void);
// 0x00000665 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::PerformRaycast(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.LayerMask,UnityEngine.Camera,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void TrackedDeviceGraphicRaycaster_PerformRaycast_mF146A36CF05B6428122C843316097970AD82732C (void);
// 0x00000666 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::SortedRaycastGraphics(UnityEngine.Canvas,UnityEngine.Ray,System.Single,UnityEngine.LayerMask,UnityEngine.Camera,System.Collections.Generic.List`1<UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitData>)
extern void TrackedDeviceGraphicRaycaster_SortedRaycastGraphics_m5C36293D866172FE0B49DFADCFDF0A5391525803 (void);
// 0x00000667 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::RayIntersectsRectTransform(UnityEngine.RectTransform,UnityEngine.Vector4,UnityEngine.Ray,UnityEngine.Vector3&,System.Single&)
extern void TrackedDeviceGraphicRaycaster_RayIntersectsRectTransform_mBF69EFB476321A58716B6C97F21E2CBA3EF6D030 (void);
// 0x00000668 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::GetRectTransformWorldCorners(UnityEngine.RectTransform,UnityEngine.Vector4,UnityEngine.Vector3[])
extern void TrackedDeviceGraphicRaycaster_GetRectTransformWorldCorners_m96C108FD9826453DD7E5E870CE97272F07431633 (void);
// 0x00000669 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::.ctor()
extern void TrackedDeviceGraphicRaycaster__ctor_m171C45F821562D30B97D90B0258CC906FD837972 (void);
// 0x0000066A System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster::.cctor()
extern void TrackedDeviceGraphicRaycaster__cctor_m47A6ED8F4ADEBAC44E2F35E923D467EB7D23FBCF (void);
// 0x0000066B System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitData::.ctor(UnityEngine.UI.Graphic,UnityEngine.Vector3,UnityEngine.Vector2,System.Single,System.Int32)
extern void RaycastHitData__ctor_m46C10CA0C3686A7DFC808CC5E995563E3E6E0900 (void);
// 0x0000066C UnityEngine.UI.Graphic UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitData::get_graphic()
extern void RaycastHitData_get_graphic_mD7D675E65B6B19526DEC71B273334796C44D7B88 (void);
// 0x0000066D UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitData::get_worldHitPosition()
extern void RaycastHitData_get_worldHitPosition_mA36CED27016B4C803EE9129A379C1052152D15F2 (void);
// 0x0000066E UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitData::get_screenPosition()
extern void RaycastHitData_get_screenPosition_mAAA69CF11624FC7EA8667F228C640DEFCD6FB2AB (void);
// 0x0000066F System.Single UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitData::get_distance()
extern void RaycastHitData_get_distance_mC2299A0A61CCB9C17D93D532D8DE4109C8291EC0 (void);
// 0x00000670 System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitData::get_displayIndex()
extern void RaycastHitData_get_displayIndex_mA3B5A6BD21766DBCE8EA33251BF23FDE7DFE0C50 (void);
// 0x00000671 System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitComparer::Compare(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitData,UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitData)
extern void RaycastHitComparer_Compare_mCC40F8BCA5482E5FB84B5F53618FE0885B8B8A31 (void);
// 0x00000672 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceGraphicRaycaster/RaycastHitComparer::.ctor()
extern void RaycastHitComparer__ctor_m3738852194278662207000E744F68BCA0B6C5C59 (void);
// 0x00000673 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_implementationData()
extern void TrackedDeviceModel_get_implementationData_m95202DC252DDE53560803CED892DDD834686B749 (void);
// 0x00000674 System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_pointerId()
extern void TrackedDeviceModel_get_pointerId_m7AEFEA8657A653D0968500004E01A9B8672464DD (void);
// 0x00000675 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_select()
extern void TrackedDeviceModel_get_select_mF73B603383F4D45021CD0AAFC29324A54AC8D55D (void);
// 0x00000676 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_select(System.Boolean)
extern void TrackedDeviceModel_set_select_m9513F69D1C9E4B312EC23820BFC81CA7030E6F02 (void);
// 0x00000677 UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_selectDelta()
extern void TrackedDeviceModel_get_selectDelta_m3F6B5717A4F6C2DC505EA92A11846820A14B35FC (void);
// 0x00000678 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_selectDelta(UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState)
extern void TrackedDeviceModel_set_selectDelta_m61649F57176681CCBD64C07F4A4F0F3974DECE4C (void);
// 0x00000679 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_changedThisFrame()
extern void TrackedDeviceModel_get_changedThisFrame_m4C3C35C841B822ABB3D5DEE90F26FA74D8EE9FE1 (void);
// 0x0000067A System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_changedThisFrame(System.Boolean)
extern void TrackedDeviceModel_set_changedThisFrame_mDE51F8C5DC3A66BA3F13B32F0CEE792E9FF7C1AB (void);
// 0x0000067B UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_position()
extern void TrackedDeviceModel_get_position_mA1B101753B4DE6F7142EE4DB49487104019DF4BE (void);
// 0x0000067C System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_position(UnityEngine.Vector3)
extern void TrackedDeviceModel_set_position_mDB462484180081FA49D38E28ACAE1772E8F11442 (void);
// 0x0000067D UnityEngine.Quaternion UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_orientation()
extern void TrackedDeviceModel_get_orientation_m870C73AC6F4686930F729F7BDBF5812D7BB0CBCA (void);
// 0x0000067E System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_orientation(UnityEngine.Quaternion)
extern void TrackedDeviceModel_set_orientation_m1A0A17586D375B499F224DECEC2BB19721EF05FA (void);
// 0x0000067F System.Collections.Generic.List`1<UnityEngine.Vector3> UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_raycastPoints()
extern void TrackedDeviceModel_get_raycastPoints_m3087C3A9A899CDA89FABE930AB7CD63A9856E07B (void);
// 0x00000680 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_raycastPoints(System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern void TrackedDeviceModel_set_raycastPoints_m582BE854A82211D8DC757CF5A79445D1DC464C3A (void);
// 0x00000681 UnityEngine.EventSystems.RaycastResult UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_currentRaycast()
extern void TrackedDeviceModel_get_currentRaycast_mAF58714250F6AB9E34888B19F2449EF2D0FA94E4 (void);
// 0x00000682 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_currentRaycast(UnityEngine.EventSystems.RaycastResult)
extern void TrackedDeviceModel_set_currentRaycast_mB605A8C85EFDAEDC5D8A39468CD0933E54F50C73 (void);
// 0x00000683 System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_currentRaycastEndpointIndex()
extern void TrackedDeviceModel_get_currentRaycastEndpointIndex_m2CF4F264EBDDE6EAE7285ED58636F55FB1FCAA9C (void);
// 0x00000684 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_currentRaycastEndpointIndex(System.Int32)
extern void TrackedDeviceModel_set_currentRaycastEndpointIndex_m590E66F5A9635363FE8E140E0F9CC28328AEC2E1 (void);
// 0x00000685 UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_raycastLayerMask()
extern void TrackedDeviceModel_get_raycastLayerMask_mB1E60DDB72A91FD2A65B00356D485513174C60AF (void);
// 0x00000686 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_raycastLayerMask(UnityEngine.LayerMask)
extern void TrackedDeviceModel_set_raycastLayerMask_m15984C257F236CA50C3131EE3A6AA7814BAB715B (void);
// 0x00000687 UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_scrollDelta()
extern void TrackedDeviceModel_get_scrollDelta_mCADE5E90334C1EE03593B0BCB7E21D55D2098E87 (void);
// 0x00000688 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_scrollDelta(UnityEngine.Vector2)
extern void TrackedDeviceModel_set_scrollDelta_m961E99EA067FBCA97B2E8BC805BF1D608DF95014 (void);
// 0x00000689 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::.ctor(System.Int32)
extern void TrackedDeviceModel__ctor_m2128F49761ECD982EEC5C86F0B18C9991A3ADE2E (void);
// 0x0000068A System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::Reset(System.Boolean)
extern void TrackedDeviceModel_Reset_m29196B36856087C2404D20AF734005C0BB6B0AA9 (void);
// 0x0000068B System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::OnFrameFinished()
extern void TrackedDeviceModel_OnFrameFinished_m0CB3B1A5BB3236A786E674AEE6E740951AC59184 (void);
// 0x0000068C System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::CopyTo(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData)
extern void TrackedDeviceModel_CopyTo_m077D1C3D2AB67EE3E95101C04E8ABDFD5D82D56B (void);
// 0x0000068D System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::CopyFrom(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData)
extern void TrackedDeviceModel_CopyFrom_m2A29E70045067F467379D43A4AFB7CDCAFC1786B (void);
// 0x0000068E UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_invalid()
extern void TrackedDeviceModel_get_invalid_mD252CC40ED4B59DC50948450945B0894FBE5419D (void);
// 0x0000068F System.Single UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::get_maxRaycastDistance()
extern void TrackedDeviceModel_get_maxRaycastDistance_m7D59D0EB9A5D126EB753972241962421E4A41E7A (void);
// 0x00000690 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::set_maxRaycastDistance(System.Single)
extern void TrackedDeviceModel_set_maxRaycastDistance_m6EC3C19F85D167D4BFC03883616522D37BFB2648 (void);
// 0x00000691 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel::.cctor()
extern void TrackedDeviceModel__cctor_mA5735BEC35DB568F5706065BFE19119D36E234A7 (void);
// 0x00000692 System.Collections.Generic.List`1<UnityEngine.GameObject> UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::get_hoverTargets()
extern void ImplementationData_get_hoverTargets_m49C9E4E462CC1064607FA5A3BA0EF5AB0360EE0D (void);
// 0x00000693 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::set_hoverTargets(System.Collections.Generic.List`1<UnityEngine.GameObject>)
extern void ImplementationData_set_hoverTargets_mCD8DCF11D40DAC82195A1724F2BA0D85FF57E70C (void);
// 0x00000694 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::get_pointerTarget()
extern void ImplementationData_get_pointerTarget_mB2D4D091AC3BC5E937FB7252047DA33AC409FAEB (void);
// 0x00000695 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::set_pointerTarget(UnityEngine.GameObject)
extern void ImplementationData_set_pointerTarget_m6A49B7736E5B50E934D4D998648ED2AB2D69C582 (void);
// 0x00000696 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::get_isDragging()
extern void ImplementationData_get_isDragging_mEE3BF283FC9C5235D15708D18BE89E06319F781D (void);
// 0x00000697 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::set_isDragging(System.Boolean)
extern void ImplementationData_set_isDragging_m315511026FE53448151B19E47E4902F90E819BC2 (void);
// 0x00000698 System.Single UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::get_pressedTime()
extern void ImplementationData_get_pressedTime_m154FBADD86CD746C703BF37003C64C428CADAC35 (void);
// 0x00000699 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::set_pressedTime(System.Single)
extern void ImplementationData_set_pressedTime_m0EB8960EE81F4D82A71AAC719999CE01D64DCDA6 (void);
// 0x0000069A UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::get_position()
extern void ImplementationData_get_position_m421FC9657A48CBED5AD985B2D7905BF7B06CA446 (void);
// 0x0000069B System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::set_position(UnityEngine.Vector2)
extern void ImplementationData_set_position_m82C559B25F9B9515CCAE8FA900B78A2072CD3F7E (void);
// 0x0000069C UnityEngine.Vector2 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::get_pressedPosition()
extern void ImplementationData_get_pressedPosition_mE3E33C31F62A5ABF18461C479CA7DA9D8DB32262 (void);
// 0x0000069D System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::set_pressedPosition(UnityEngine.Vector2)
extern void ImplementationData_set_pressedPosition_m9BBCEC0224F0FCB1572F06B61A01074A0CAD5DCA (void);
// 0x0000069E UnityEngine.EventSystems.RaycastResult UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::get_pressedRaycast()
extern void ImplementationData_get_pressedRaycast_mA355A412C26FAB49EA39F4DEFDA824465DFDE48E (void);
// 0x0000069F System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::set_pressedRaycast(UnityEngine.EventSystems.RaycastResult)
extern void ImplementationData_set_pressedRaycast_mB79CE5436DFBFAB118F234D25B7D49E72582D9EB (void);
// 0x000006A0 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::get_pressedGameObject()
extern void ImplementationData_get_pressedGameObject_m81DA354AA04B9531100A8C8C6A61100493115CF5 (void);
// 0x000006A1 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::set_pressedGameObject(UnityEngine.GameObject)
extern void ImplementationData_set_pressedGameObject_mF87125F8EFFBE3ED0609B5C67EA86704715996FE (void);
// 0x000006A2 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::get_pressedGameObjectRaw()
extern void ImplementationData_get_pressedGameObjectRaw_mE9702863BC33793FB5DE550F0789A9058F369A2C (void);
// 0x000006A3 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::set_pressedGameObjectRaw(UnityEngine.GameObject)
extern void ImplementationData_set_pressedGameObjectRaw_m3AEB4F85F771C297EAE30B1CAAFDD990446624B4 (void);
// 0x000006A4 UnityEngine.GameObject UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::get_draggedGameObject()
extern void ImplementationData_get_draggedGameObject_mBD53214AA566627B15D7EA5F6080758FF95C1848 (void);
// 0x000006A5 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::set_draggedGameObject(UnityEngine.GameObject)
extern void ImplementationData_set_draggedGameObject_m977BE3A90025D2F50AC30A321D30245423B9CA6A (void);
// 0x000006A6 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel/ImplementationData::Reset()
extern void ImplementationData_Reset_m78CB6F5BD992AECD4D7D58E5880CFC0DF4DBBC55 (void);
// 0x000006A7 UnityEngine.QueryTriggerInteraction UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster::get_raycastTriggerInteraction()
extern void TrackedDevicePhysicsRaycaster_get_raycastTriggerInteraction_m9E934B1D2880B5AF17B565D8574F9CA2699EA7E6 (void);
// 0x000006A8 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster::set_raycastTriggerInteraction(UnityEngine.QueryTriggerInteraction)
extern void TrackedDevicePhysicsRaycaster_set_raycastTriggerInteraction_mEF929F720FD15B157653827D6EBB0D4E6C61F006 (void);
// 0x000006A9 UnityEngine.LayerMask UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster::get_eventMask()
extern void TrackedDevicePhysicsRaycaster_get_eventMask_mB75E7F77242C64D1B41710EBE3B8C6395A34F38B (void);
// 0x000006AA System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster::set_eventMask(UnityEngine.LayerMask)
extern void TrackedDevicePhysicsRaycaster_set_eventMask_m13F16E19AB895BD2B44805043676FD67CF691C8A (void);
// 0x000006AB System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster::get_maxRayIntersections()
extern void TrackedDevicePhysicsRaycaster_get_maxRayIntersections_mEE9EB9579C61CA31869B544DBE855DE6A3D2C902 (void);
// 0x000006AC System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster::set_maxRayIntersections(System.Int32)
extern void TrackedDevicePhysicsRaycaster_set_maxRayIntersections_mA7EE3F4A79BC6CB7C1B1BE49668506AF255C5C4E (void);
// 0x000006AD UnityEngine.Camera UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster::get_eventCamera()
extern void TrackedDevicePhysicsRaycaster_get_eventCamera_mF1AF235906E16B8D61A1BD240AB1CAC1233BB553 (void);
// 0x000006AE System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster::SetEventCamera(UnityEngine.Camera)
extern void TrackedDevicePhysicsRaycaster_SetEventCamera_m109CC7E7D596F53719E1AB06CFBF28A0A380921C (void);
// 0x000006AF System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster::Raycast(UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void TrackedDevicePhysicsRaycaster_Raycast_m0BFFAA0821C6C57A8C3EC44211EB88DC761F472E (void);
// 0x000006B0 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster::Awake()
extern void TrackedDevicePhysicsRaycaster_Awake_mC3C96AE1AC1C7A2B2DB4A901EA0ADEFBE448C995 (void);
// 0x000006B1 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster::PerformRaycasts(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void TrackedDevicePhysicsRaycaster_PerformRaycasts_m86E342C9D8A61B890C0909381DE96566125257E7 (void);
// 0x000006B2 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster::PerformRaycast(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.LayerMask,UnityEngine.Camera,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void TrackedDevicePhysicsRaycaster_PerformRaycast_m20052CC3DBF3C62D0A7705DF04CDEE6CFCF763FD (void);
// 0x000006B3 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster::.ctor()
extern void TrackedDevicePhysicsRaycaster__ctor_m604E49C73D48122271025602D10B9890B12AD0D0 (void);
// 0x000006B4 System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster/RaycastHitArraySegment::get_count()
extern void RaycastHitArraySegment_get_count_m5BBA6588A64FF768F053CCFF5D6E6ACA65F9DB4D (void);
// 0x000006B5 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster/RaycastHitArraySegment::set_count(System.Int32)
extern void RaycastHitArraySegment_set_count_m914E21014BA452D837B277FC9088881160F7AE1D (void);
// 0x000006B6 UnityEngine.RaycastHit UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster/RaycastHitArraySegment::get_Current()
extern void RaycastHitArraySegment_get_Current_mECA5B92CC673BB2BCED92B7F5E82075A17A800C8 (void);
// 0x000006B7 System.Object UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster/RaycastHitArraySegment::System.Collections.IEnumerator.get_Current()
extern void RaycastHitArraySegment_System_Collections_IEnumerator_get_Current_m2AAD9444FCF9F4F1813B275122B187EAE922DE79 (void);
// 0x000006B8 System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster/RaycastHitArraySegment::.ctor(UnityEngine.RaycastHit[],System.Int32)
extern void RaycastHitArraySegment__ctor_m1EA0C75F9B3A4AD6EEEA6EBB5D9926EC57FF0B01 (void);
// 0x000006B9 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster/RaycastHitArraySegment::MoveNext()
extern void RaycastHitArraySegment_MoveNext_m714394CDED45A30BEB73086BC42576E6AE231D95 (void);
// 0x000006BA System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster/RaycastHitArraySegment::Reset()
extern void RaycastHitArraySegment_Reset_mA0FABB4A4E7AD22B6E83C3248A9D57EAFF1490EB (void);
// 0x000006BB System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster/RaycastHitArraySegment::Dispose()
extern void RaycastHitArraySegment_Dispose_m10C35FE8B7DCC03C144372A085EC2025D07C85ED (void);
// 0x000006BC System.Collections.Generic.IEnumerator`1<UnityEngine.RaycastHit> UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster/RaycastHitArraySegment::GetEnumerator()
extern void RaycastHitArraySegment_GetEnumerator_mC9D09D2871FFB820FB5496456E5649B01594A0F7 (void);
// 0x000006BD System.Collections.IEnumerator UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster/RaycastHitArraySegment::System.Collections.IEnumerable.GetEnumerator()
extern void RaycastHitArraySegment_System_Collections_IEnumerable_GetEnumerator_m5681610A873C7C0B3659BB929E4241B5796322D2 (void);
// 0x000006BE System.Int32 UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster/RaycastHitComparer::Compare(UnityEngine.RaycastHit,UnityEngine.RaycastHit)
extern void RaycastHitComparer_Compare_mBC14B5D686F0C0E6D85AD46FEFD965E6001E3A8D (void);
// 0x000006BF System.Void UnityEngine.XR.Interaction.Toolkit.UI.TrackedDevicePhysicsRaycaster/RaycastHitComparer::.ctor()
extern void RaycastHitComparer__ctor_m25412161F14970521D7D85A4DD8BAE3C18AC4CC0 (void);
// 0x000006C0 System.Single UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::get_clickSpeed()
extern void UIInputModule_get_clickSpeed_mA97C1FD6A500C3EBA907A6C79EF59112B02BB894 (void);
// 0x000006C1 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::set_clickSpeed(System.Single)
extern void UIInputModule_set_clickSpeed_mFF1C7BD7B5FCB5274D85BB7C4AFEB9B025F491C4 (void);
// 0x000006C2 System.Single UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::get_moveDeadzone()
extern void UIInputModule_get_moveDeadzone_mFB3CDD0FC69E6DFAF3ABDE5DD44D19C24B6D2104 (void);
// 0x000006C3 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::set_moveDeadzone(System.Single)
extern void UIInputModule_set_moveDeadzone_mE56FF053ABB13F67F0162D3A825D1B25A0707398 (void);
// 0x000006C4 System.Single UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::get_repeatDelay()
extern void UIInputModule_get_repeatDelay_mD2B5AF5E141A0C82768461C6A7012004443ED934 (void);
// 0x000006C5 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::set_repeatDelay(System.Single)
extern void UIInputModule_set_repeatDelay_m7F75D6EC2C48820238C441AE06D527275019286D (void);
// 0x000006C6 System.Single UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::get_repeatRate()
extern void UIInputModule_get_repeatRate_m159C95DF8BA72BA67569F6B9A3B379976B14F4B4 (void);
// 0x000006C7 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::set_repeatRate(System.Single)
extern void UIInputModule_set_repeatRate_mFFE6FB4FB6C1D8BA45707D9C5F4D79C82E673A52 (void);
// 0x000006C8 System.Single UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::get_trackedDeviceDragThresholdMultiplier()
extern void UIInputModule_get_trackedDeviceDragThresholdMultiplier_mFD629D1343B6CE4DC2DE135F17C3032A342A9D2A (void);
// 0x000006C9 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::set_trackedDeviceDragThresholdMultiplier(System.Single)
extern void UIInputModule_set_trackedDeviceDragThresholdMultiplier_m229733B6750687F4B2F730F0ABB0C8B92214CD62 (void);
// 0x000006CA UnityEngine.Camera UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::get_uiCamera()
extern void UIInputModule_get_uiCamera_mE7FE3483DD96250D5E9C4EEA0E4ADD4FAC1E7647 (void);
// 0x000006CB System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::set_uiCamera(UnityEngine.Camera)
extern void UIInputModule_set_uiCamera_m37C392685DE455B9197AC432551BA808A1A9001D (void);
// 0x000006CC System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::Update()
extern void UIInputModule_Update_m7D6322B0FDDFDE7B1E82943EFBD2C2E6BE70F100 (void);
// 0x000006CD System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::DoProcess()
extern void UIInputModule_DoProcess_m2F3415E90165B1AF36AA82DE27C23B2A9EBBE47C (void);
// 0x000006CE System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::Process()
extern void UIInputModule_Process_m5F41F23491E526BA70E4980C0143A020D9E0B5AA (void);
// 0x000006CF System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::SendUpdateEventToSelectedObject()
extern void UIInputModule_SendUpdateEventToSelectedObject_m7DD6DD3839C2A33F9D34A11A8643D193DBE8268B (void);
// 0x000006D0 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::IsPointerOverGameObject(System.Int32)
extern void UIInputModule_IsPointerOverGameObject_mDED22CBFD2207F371923EB30699528F09B4C1790 (void);
// 0x000006D1 UnityEngine.EventSystems.RaycastResult UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::PerformRaycast(UnityEngine.EventSystems.PointerEventData)
extern void UIInputModule_PerformRaycast_m4716E7450EC96B541A924BB1DC20E58B2F159B28 (void);
// 0x000006D2 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessMouse(UnityEngine.XR.Interaction.Toolkit.UI.MouseModel&)
extern void UIInputModule_ProcessMouse_mF90F8EA789274FCD298E5ED801EE9675A9E3EEA4 (void);
// 0x000006D3 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessMouseMovement(UnityEngine.EventSystems.PointerEventData)
extern void UIInputModule_ProcessMouseMovement_m8654AF723206F8BE52803F57801811E4B54E9E41 (void);
// 0x000006D4 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessMouseButton(UnityEngine.XR.Interaction.Toolkit.UI.ButtonDeltaState,UnityEngine.EventSystems.PointerEventData)
extern void UIInputModule_ProcessMouseButton_mCD0F73EA5A20835EE50E9F238E2BDA4865B0F391 (void);
// 0x000006D5 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessMouseButtonDrag(UnityEngine.EventSystems.PointerEventData,System.Single)
extern void UIInputModule_ProcessMouseButtonDrag_m768E9FBBC339845C4E7849C71B86D14DEB91F141 (void);
// 0x000006D6 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessMouseScroll(UnityEngine.EventSystems.PointerEventData)
extern void UIInputModule_ProcessMouseScroll_m8A93D635F089F339891607F19D746BA4DB11452F (void);
// 0x000006D7 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessTouch(UnityEngine.XR.Interaction.Toolkit.UI.TouchModel&)
extern void UIInputModule_ProcessTouch_m6E005B10690A60C60030CCB1803BA683337224FE (void);
// 0x000006D8 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessTrackedDevice(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel&,System.Boolean)
extern void UIInputModule_ProcessTrackedDevice_m82718A0C6C9B13B6FEAC0967D3DBAC75BD3C5E86 (void);
// 0x000006D9 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessGamepad(UnityEngine.XR.Interaction.Toolkit.UI.GamepadModel&)
extern void UIInputModule_ProcessGamepad_m4CAB4ED476E35FF67CF895157F3DDA8DDC456AB9 (void);
// 0x000006DA System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::ProcessJoystick(UnityEngine.XR.Interaction.Toolkit.UI.JoystickModel&)
extern void UIInputModule_ProcessJoystick_m0AC925B34544FA77F96A55E284B516410D30D8FF (void);
// 0x000006DB System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::RemovePointerEventData(System.Int32)
extern void UIInputModule_RemovePointerEventData_m0F281258935D22628B31140F4578DD54F6CED2A7 (void);
// 0x000006DC UnityEngine.EventSystems.PointerEventData UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::GetOrCreateCachedPointerEvent(System.Int32)
extern void UIInputModule_GetOrCreateCachedPointerEvent_m2A3C1845504FDFCDE1AE2BDDF396ED6DD279BBCA (void);
// 0x000006DD UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceEventData UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::GetOrCreateCachedTrackedDeviceEvent(System.Int32)
extern void UIInputModule_GetOrCreateCachedTrackedDeviceEvent_m50DEA6D9F60E668D14EBAA52D247CBB9B138C4BC (void);
// 0x000006DE UnityEngine.EventSystems.AxisEventData UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::GetOrCreateCachedAxisEvent()
extern void UIInputModule_GetOrCreateCachedAxisEvent_m0BA809D7FFB01FB16E1D388DE8C9C3E920BE95B9 (void);
// 0x000006DF System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::add_finalizeRaycastResults(System.Action`2<UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>>)
extern void UIInputModule_add_finalizeRaycastResults_m284F9F3718129B2D178D831C1334A8EF0F22205F (void);
// 0x000006E0 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::remove_finalizeRaycastResults(System.Action`2<UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>>)
extern void UIInputModule_remove_finalizeRaycastResults_m869EE6506EF67AE07A6FB1DCA5BF0EB862CB50A9 (void);
// 0x000006E1 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::add_pointerEnter(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_add_pointerEnter_mC2952CF870EDCC16D60CBAFDC20C2B617FF1F9F6 (void);
// 0x000006E2 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::remove_pointerEnter(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_remove_pointerEnter_m732BEA4FDE353F48038A2A2AA275EDD73B853D46 (void);
// 0x000006E3 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::add_pointerExit(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_add_pointerExit_m72DBA62BD601A3517C3AF34693641CEF292C07B4 (void);
// 0x000006E4 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::remove_pointerExit(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_remove_pointerExit_mA5248639F07AECDDADC478FED718014D6C79CC41 (void);
// 0x000006E5 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::add_pointerDown(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_add_pointerDown_m9173418E3433ACBF1E748369DDDFB71A3B9F2D13 (void);
// 0x000006E6 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::remove_pointerDown(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_remove_pointerDown_m25D2DAB8B81DCC5BC70F49CB92B83290A045EC4B (void);
// 0x000006E7 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::add_pointerUp(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_add_pointerUp_m2A53C7E0EDC56ECCD5E7E9DEDE13FC3C0B13E839 (void);
// 0x000006E8 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::remove_pointerUp(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_remove_pointerUp_m1208A993218A61396EA4AA9C573D3D1917A8FE5C (void);
// 0x000006E9 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::add_pointerClick(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_add_pointerClick_mD5B1AFA7ACF6EBF0E061EF6BE18DF2063B010F67 (void);
// 0x000006EA System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::remove_pointerClick(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_remove_pointerClick_m243047A5B5D18CD7C176D87E8E57E20520701850 (void);
// 0x000006EB System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::add_initializePotentialDrag(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_add_initializePotentialDrag_m7806CE850913CAECF12C3E1F2F5D7CC4B2A690F3 (void);
// 0x000006EC System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::remove_initializePotentialDrag(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_remove_initializePotentialDrag_mEEF545F889D9C81BA1D0EDA0B57B7DB9CC37794C (void);
// 0x000006ED System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::add_beginDrag(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_add_beginDrag_mAA5E03401ECB3A89C93EA86353CB8E704803B8EC (void);
// 0x000006EE System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::remove_beginDrag(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_remove_beginDrag_m31368ACAD0CC7C4F356F89ED70089D21DCD90AC1 (void);
// 0x000006EF System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::add_drag(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_add_drag_mE60899C9ECF48D389A7B258F9F1C78D14685541E (void);
// 0x000006F0 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::remove_drag(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_remove_drag_mCD37C151704D73D698AFBD3CE9B18A427908F517 (void);
// 0x000006F1 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::add_endDrag(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_add_endDrag_m193A9FD0DAF60C9C0D57A16A2C919930CA0F8A67 (void);
// 0x000006F2 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::remove_endDrag(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_remove_endDrag_mCA258F00211C2E70081D50B908A691FCC868AAD2 (void);
// 0x000006F3 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::add_drop(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_add_drop_m6E8254ABE1D0826375B88DED6743659D6F8CFE52 (void);
// 0x000006F4 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::remove_drop(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_remove_drop_m239EB803ED8DBC0D4E2F3E43CBBD243CA947506C (void);
// 0x000006F5 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::add_scroll(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_add_scroll_m19016175E3F43A156EF4221210E524B5DB274443 (void);
// 0x000006F6 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::remove_scroll(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.PointerEventData>)
extern void UIInputModule_remove_scroll_m52E356A774F8B0685F0FAFF6D312E0B116720BE9 (void);
// 0x000006F7 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::add_updateSelected(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.BaseEventData>)
extern void UIInputModule_add_updateSelected_m8AEC6AD19A00852977CDFD6EF6C39BFF4A19A1C7 (void);
// 0x000006F8 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::remove_updateSelected(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.BaseEventData>)
extern void UIInputModule_remove_updateSelected_m5D17BA3093E9705FB538F0940BEF379998C78CEB (void);
// 0x000006F9 System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::add_move(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.AxisEventData>)
extern void UIInputModule_add_move_m97DF584BF7ED6BBF2FC0FDD60551B656C08B722E (void);
// 0x000006FA System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::remove_move(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.AxisEventData>)
extern void UIInputModule_remove_move_m012D47230F257F7F7D0A04CE4B03FD46927CB97C (void);
// 0x000006FB System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::add_submit(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.BaseEventData>)
extern void UIInputModule_add_submit_mDFA87455410A48B770FF3835B588956822394A10 (void);
// 0x000006FC System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::remove_submit(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.BaseEventData>)
extern void UIInputModule_remove_submit_m4982C6B93ADAF49EFC6DA6D609BA6F33B352084D (void);
// 0x000006FD System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::add_cancel(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.BaseEventData>)
extern void UIInputModule_add_cancel_m8F9F7D7D7FE1845910BE00593D06FCF8A7B15623 (void);
// 0x000006FE System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::remove_cancel(System.Action`2<UnityEngine.GameObject,UnityEngine.EventSystems.BaseEventData>)
extern void UIInputModule_remove_cancel_mBD92353A869FE561F961AC8821BACEC2DE87FD92 (void);
// 0x000006FF System.Void UnityEngine.XR.Interaction.Toolkit.UI.UIInputModule::.ctor()
extern void UIInputModule__ctor_mF6B661E76FF09FEC44404BA11DD54F8D3E2FB827 (void);
// 0x00000700 System.Void UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractor::UpdateUIModel(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel&)
// 0x00000701 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractor::TryGetUIModel(UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel&)
// 0x00000702 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::get_enableXRInput()
extern void XRUIInputModule_get_enableXRInput_mEF148C23548DFE6B9CFBEA481D9C5C6E9B997D96 (void);
// 0x00000703 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::set_enableXRInput(System.Boolean)
extern void XRUIInputModule_set_enableXRInput_mA67F93E18007DC7053BC83C68689F2E64DC64F4D (void);
// 0x00000704 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::get_enableMouseInput()
extern void XRUIInputModule_get_enableMouseInput_m3984250F9A4B5401DC7ABACF1E96107B93FDEA81 (void);
// 0x00000705 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::set_enableMouseInput(System.Boolean)
extern void XRUIInputModule_set_enableMouseInput_mF931954CCC642A69E354CED3C5888394B38289DE (void);
// 0x00000706 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::get_enableTouchInput()
extern void XRUIInputModule_get_enableTouchInput_m421820762C081C055B51C4BB1EE8B840DF7FE6EA (void);
// 0x00000707 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::set_enableTouchInput(System.Boolean)
extern void XRUIInputModule_set_enableTouchInput_mD9C65CAEA46CA87A96674571B348F4F93E4F429F (void);
// 0x00000708 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::get_enableGamepadInput()
extern void XRUIInputModule_get_enableGamepadInput_mA340B34F91FBE777897271181E25E579F7D2FF6E (void);
// 0x00000709 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::set_enableGamepadInput(System.Boolean)
extern void XRUIInputModule_set_enableGamepadInput_m433C31F6C28BD03A1030B76EB111C146928219EE (void);
// 0x0000070A System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::get_enableJoystickInput()
extern void XRUIInputModule_get_enableJoystickInput_m05ECF1903097F7E4C2405A877E0C0960AA0E757F (void);
// 0x0000070B System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::set_enableJoystickInput(System.Boolean)
extern void XRUIInputModule_set_enableJoystickInput_mB2C7A5D5AB89AB9C1D1C7A6C7B6DBDF87D09CC83 (void);
// 0x0000070C System.String UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::get_horizontalAxis()
extern void XRUIInputModule_get_horizontalAxis_m18B8523D5ED51B8F96F57D5B315F000A409C3496 (void);
// 0x0000070D System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::set_horizontalAxis(System.String)
extern void XRUIInputModule_set_horizontalAxis_m961D5E18A5814D94963FE46BC6D44A6D8E3D9543 (void);
// 0x0000070E System.String UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::get_verticalAxis()
extern void XRUIInputModule_get_verticalAxis_m62A0C0D3EA3024694A70767019804CE6F9931985 (void);
// 0x0000070F System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::set_verticalAxis(System.String)
extern void XRUIInputModule_set_verticalAxis_m8CED8D229193C44F9B7998D2DB1B8BC685E244C3 (void);
// 0x00000710 System.String UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::get_submitButton()
extern void XRUIInputModule_get_submitButton_m335DDEC0D182813E8F46F64EC703036D8A765C92 (void);
// 0x00000711 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::set_submitButton(System.String)
extern void XRUIInputModule_set_submitButton_m238B5E49DC52E8B0FE34DEB1179FA3C914500D87 (void);
// 0x00000712 System.String UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::get_cancelButton()
extern void XRUIInputModule_get_cancelButton_mF18097E9E5A4CFF4F42EB1775C6A09E1CF7B8088 (void);
// 0x00000713 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::set_cancelButton(System.String)
extern void XRUIInputModule_set_cancelButton_mFB2DDF6699839CB2340B9B8A8D15F7A9863790CA (void);
// 0x00000714 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::OnEnable()
extern void XRUIInputModule_OnEnable_mB938D9A55AF66EDC8A3384F357ADAEC6B3EA1431 (void);
// 0x00000715 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::OnDisable()
extern void XRUIInputModule_OnDisable_m95329A7D7D20015E4E4475FFFD074A902606BEF8 (void);
// 0x00000716 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::RegisterInteractor(UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractor)
extern void XRUIInputModule_RegisterInteractor_m5A17069C7410839807F8EB0E5E7FF2D438F7A55B (void);
// 0x00000717 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::UnregisterInteractor(UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractor)
extern void XRUIInputModule_UnregisterInteractor_mE078BB0F40BF245171F44E7629A853FA08CAB0B5 (void);
// 0x00000718 UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractor UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::GetInteractor(System.Int32)
extern void XRUIInputModule_GetInteractor_mBBAF268AB57CAB8CB6390D339B7D5A5893CEF747 (void);
// 0x00000719 System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::GetTrackedDeviceModel(UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractor,UnityEngine.XR.Interaction.Toolkit.UI.TrackedDeviceModel&)
extern void XRUIInputModule_GetTrackedDeviceModel_m85E330D47C648609FA20F173C8C036E3DF280875 (void);
// 0x0000071A System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::DoProcess()
extern void XRUIInputModule_DoProcess_m3E40FE8EB0244A2390709FCE793271DD8AFB60DF (void);
// 0x0000071B System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::ProcessMouse()
extern void XRUIInputModule_ProcessMouse_mD684700E9D27203EE72E7DE93F773DF887050EA6 (void);
// 0x0000071C System.Boolean UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::ProcessTouches()
extern void XRUIInputModule_ProcessTouches_m5803B279A332A189EF841756931CF463879E516C (void);
// 0x0000071D System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::ProcessGamepad()
extern void XRUIInputModule_ProcessGamepad_m0D8E15D91A8781985480A739B3900A1E307AD205 (void);
// 0x0000071E System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::ProcessJoystick()
extern void XRUIInputModule_ProcessJoystick_m8B718A243731D7E32AAFD357C9CD0D936F405EAA (void);
// 0x0000071F System.Single UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::get_maxRaycastDistance()
extern void XRUIInputModule_get_maxRaycastDistance_m87049643E3AE060060068D25BD71D5ECE14EBA7B (void);
// 0x00000720 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::set_maxRaycastDistance(System.Single)
extern void XRUIInputModule_set_maxRaycastDistance_mA769014A0999A1B5DB9AEFCC70FC58AE2DF49A4A (void);
// 0x00000721 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule::.ctor()
extern void XRUIInputModule__ctor_mE15B70D3CE192C4622EE2144530F98F6E0CA0829 (void);
// 0x00000722 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule/RegisteredInteractor::.ctor(UnityEngine.XR.Interaction.Toolkit.UI.IUIInteractor,System.Int32)
extern void RegisteredInteractor__ctor_m6F1AB931437F1F9ACEC036DF8D35D6F5615109BF (void);
// 0x00000723 System.Void UnityEngine.XR.Interaction.Toolkit.UI.XRUIInputModule/RegisteredTouch::.ctor(UnityEngine.Touch,System.Int32)
extern void RegisteredTouch__ctor_mEAB697F13AE6A0335886FE62EF14C790C9077324 (void);
// 0x00000724 UnityEngine.XR.Interaction.Toolkit.Inputs.Cardinal UnityEngine.XR.Interaction.Toolkit.Inputs.CardinalUtility::GetNearestCardinal(UnityEngine.Vector2)
extern void CardinalUtility_GetNearestCardinal_m6761662410E5FAE1002827B1863A7A2871B85734 (void);
// 0x00000725 System.Collections.Generic.List`1<UnityEngine.InputSystem.InputActionAsset> UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionManager::get_actionAssets()
extern void InputActionManager_get_actionAssets_mB7B35CC08659DF051DE9FC4968B973BF399CDEFF (void);
// 0x00000726 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionManager::set_actionAssets(System.Collections.Generic.List`1<UnityEngine.InputSystem.InputActionAsset>)
extern void InputActionManager_set_actionAssets_mE9347456325C863ED670FA7FE43AC34B273B3397 (void);
// 0x00000727 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionManager::OnEnable()
extern void InputActionManager_OnEnable_m1EC5781A35CBB463796556D6F6AFFD4E1D1A0342 (void);
// 0x00000728 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionManager::OnDisable()
extern void InputActionManager_OnDisable_mB8DA0A993A336F3873BD3201922B4047DECECA3E (void);
// 0x00000729 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionManager::EnableInput()
extern void InputActionManager_EnableInput_mD7F60DE6CB14A163521E0A08A37791C98381FA2B (void);
// 0x0000072A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionManager::DisableInput()
extern void InputActionManager_DisableInput_m90B494A96DAFD272A29A9EEB5073AE96906007E9 (void);
// 0x0000072B System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionManager::.ctor()
extern void InputActionManager__ctor_mA44CD5855DA22DBF1F8B99A9A4361BAD30D66C94 (void);
// 0x0000072C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionPropertyExtensions::EnableDirectAction(UnityEngine.InputSystem.InputActionProperty)
extern void InputActionPropertyExtensions_EnableDirectAction_mA8846AAA44837965CF99FD82C518A86D6479AB46 (void);
// 0x0000072D System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionPropertyExtensions::DisableDirectAction(UnityEngine.InputSystem.InputActionProperty)
extern void InputActionPropertyExtensions_DisableDirectAction_m9699BBB4F5F25E03534B2C4A346DC52D2FEE30A7 (void);
// 0x0000072E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.SimulatedInputLayoutLoader::.cctor()
extern void SimulatedInputLayoutLoader__cctor_m50660E669D07DD504B791EC6A2FB38A36A4DC8C6 (void);
// 0x0000072F System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.SimulatedInputLayoutLoader::Initialize()
extern void SimulatedInputLayoutLoader_Initialize_mCF21EB8EADAB5BE96981379B22B44E89B3CE54A6 (void);
// 0x00000730 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.SimulatedInputLayoutLoader::RegisterInputLayouts()
extern void SimulatedInputLayoutLoader_RegisterInputLayouts_mCE7E28444FE451126299C16F63F416BD8D230888 (void);
// 0x00000731 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_keyboardXTranslateAction()
extern void XRDeviceSimulator_get_keyboardXTranslateAction_m366F9B6E96C557A7B1CAB51FB10C4E2DA1692D51 (void);
// 0x00000732 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_keyboardXTranslateAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_keyboardXTranslateAction_m89EC0F9C42104BEDA69AC8AE8BF9B964FE0E241E (void);
// 0x00000733 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_keyboardYTranslateAction()
extern void XRDeviceSimulator_get_keyboardYTranslateAction_m4E77F2AAB63C5BD5C2131A852D37E7D1EFD0A377 (void);
// 0x00000734 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_keyboardYTranslateAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_keyboardYTranslateAction_m920064BC3FE9EF16B702E479D99D39FF3BEB1186 (void);
// 0x00000735 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_keyboardZTranslateAction()
extern void XRDeviceSimulator_get_keyboardZTranslateAction_mBA7240AF7BF6271D5B6B0B635F041A86DB82199A (void);
// 0x00000736 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_keyboardZTranslateAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_keyboardZTranslateAction_mD0AC287DDFF9F7D339C4760191ED53C51BBE178D (void);
// 0x00000737 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_manipulateLeftAction()
extern void XRDeviceSimulator_get_manipulateLeftAction_mF13D03BDD3B1691F40956156E6C00F12A381B7DF (void);
// 0x00000738 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_manipulateLeftAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_manipulateLeftAction_mA82321B480841B1054C7C54C5F4BAEDAC32A1466 (void);
// 0x00000739 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_manipulateRightAction()
extern void XRDeviceSimulator_get_manipulateRightAction_mFD0D5FBC545703BC69919081932DBEE274EBB4AD (void);
// 0x0000073A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_manipulateRightAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_manipulateRightAction_m54665887203B970DF5D696E3C27BC9F0D056459F (void);
// 0x0000073B UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_toggleManipulateLeftAction()
extern void XRDeviceSimulator_get_toggleManipulateLeftAction_mB1AB1130B8FDB40CAB6664A3A2D75ED4475BBF14 (void);
// 0x0000073C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_toggleManipulateLeftAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_toggleManipulateLeftAction_mACB41B1E9B0E3665FF161170C6D52DD28259CCEF (void);
// 0x0000073D UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_toggleManipulateRightAction()
extern void XRDeviceSimulator_get_toggleManipulateRightAction_m5808CB9748058EDC8ACF52B7B954A3BFBCFF852F (void);
// 0x0000073E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_toggleManipulateRightAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_toggleManipulateRightAction_mAB6CC69904055B701563A50CFE6A3A82DF97B52A (void);
// 0x0000073F UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_manipulateHeadAction()
extern void XRDeviceSimulator_get_manipulateHeadAction_m1948244C874F76443370EED81FD6899E4170AE04 (void);
// 0x00000740 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_manipulateHeadAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_manipulateHeadAction_m44C0672D97A186A66B197AEA61943AE3F0D4319A (void);
// 0x00000741 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseDeltaAction()
extern void XRDeviceSimulator_get_mouseDeltaAction_m03FD86711D77A7739BA41B31929A0AAD3FF15F2E (void);
// 0x00000742 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseDeltaAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_mouseDeltaAction_mE5D01D667C6EF0E52050B3AC68619F53D9E400AD (void);
// 0x00000743 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseScrollAction()
extern void XRDeviceSimulator_get_mouseScrollAction_m8C30B704B54794BDFE80349B67998B44CEE18AD6 (void);
// 0x00000744 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseScrollAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_mouseScrollAction_m76B5328F81F8722C142A905B74A7F8630EEF4898 (void);
// 0x00000745 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_rotateModeOverrideAction()
extern void XRDeviceSimulator_get_rotateModeOverrideAction_m11FF0CC898D8EED0032B343245532E018E7D0264 (void);
// 0x00000746 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_rotateModeOverrideAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_rotateModeOverrideAction_m3875666E7964F451B74BA4362A5FDE40A0584D26 (void);
// 0x00000747 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_toggleMouseTransformationModeAction()
extern void XRDeviceSimulator_get_toggleMouseTransformationModeAction_m8E831EA2AF126773BC928B09F5684CCEDD595FB4 (void);
// 0x00000748 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_toggleMouseTransformationModeAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_toggleMouseTransformationModeAction_m067C40CACA52D5E87B5E634FD02E17F35B46457D (void);
// 0x00000749 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_negateModeAction()
extern void XRDeviceSimulator_get_negateModeAction_m825088F34B7FDDF847F7E439CCECAA92BA82A3E0 (void);
// 0x0000074A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_negateModeAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_negateModeAction_m493F3724035AE9867E6BDD26ED167521415B98EA (void);
// 0x0000074B UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_xConstraintAction()
extern void XRDeviceSimulator_get_xConstraintAction_m0F58D866DAC60889AA588D1CB34119C609484573 (void);
// 0x0000074C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_xConstraintAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_xConstraintAction_mD8ED4A6133F1DE169BB978B4D7EEC61B76A9A000 (void);
// 0x0000074D UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_yConstraintAction()
extern void XRDeviceSimulator_get_yConstraintAction_m955F4CC45D19B4A14B977FFB6AC207FE0A8579E9 (void);
// 0x0000074E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_yConstraintAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_yConstraintAction_m06A0ABCDE54E5A91DEB12691EFD98E11B94189CE (void);
// 0x0000074F UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_zConstraintAction()
extern void XRDeviceSimulator_get_zConstraintAction_m5D64FC5E7B07E86C1CD878ECA2EB2EBB4D8AA5D6 (void);
// 0x00000750 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_zConstraintAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_zConstraintAction_m230D3980169AD163104650CCD7BBBE4B3CD5799D (void);
// 0x00000751 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_resetAction()
extern void XRDeviceSimulator_get_resetAction_mFE0522E1330FC913A1D2C0002FC479AAE9022A3C (void);
// 0x00000752 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_resetAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_resetAction_m4AA53B730F668675F5D665FF2DD891DA06B75709 (void);
// 0x00000753 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_toggleCursorLockAction()
extern void XRDeviceSimulator_get_toggleCursorLockAction_mA230EB1D4709C3BFDEF7C784D8127436FFED7FFD (void);
// 0x00000754 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_toggleCursorLockAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_toggleCursorLockAction_mD0BE48B671BDDF6B53A73848328C0DAC188725A4 (void);
// 0x00000755 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_toggleDevicePositionTargetAction()
extern void XRDeviceSimulator_get_toggleDevicePositionTargetAction_m62774B55355AB3B4EC7F442D0C82F14B29BBCC08 (void);
// 0x00000756 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_toggleDevicePositionTargetAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_toggleDevicePositionTargetAction_m6566C70EC39B0722B2E71ECA73E237086917D32D (void);
// 0x00000757 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_togglePrimary2DAxisTargetAction()
extern void XRDeviceSimulator_get_togglePrimary2DAxisTargetAction_m8156C8BBAA2B648E786480CD666FD670FAA561D3 (void);
// 0x00000758 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_togglePrimary2DAxisTargetAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_togglePrimary2DAxisTargetAction_mF1BB9A22AF00A6D435F33C4925C4D47C5FB0215A (void);
// 0x00000759 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_toggleSecondary2DAxisTargetAction()
extern void XRDeviceSimulator_get_toggleSecondary2DAxisTargetAction_m8D76834A573A7BB22825E46E51280F5CA468766E (void);
// 0x0000075A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_toggleSecondary2DAxisTargetAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_toggleSecondary2DAxisTargetAction_m30F611596C3608FF80FBB40680B3FBFF45BB1913 (void);
// 0x0000075B UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_axis2DAction()
extern void XRDeviceSimulator_get_axis2DAction_mB6D4E7DB50DEAB354F634B5B97F4450DDF6DFDE7 (void);
// 0x0000075C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_axis2DAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_axis2DAction_m680EB6C7F6FA9756BC85F50FBFF597F653FC4B02 (void);
// 0x0000075D UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_restingHandAxis2DAction()
extern void XRDeviceSimulator_get_restingHandAxis2DAction_m7A19F0EB497DEE03682C72218207BB96D0C4CCEA (void);
// 0x0000075E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_restingHandAxis2DAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_restingHandAxis2DAction_m3964DD5C30D2F1B9AF84C612DABF5AD427E1276F (void);
// 0x0000075F UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_gripAction()
extern void XRDeviceSimulator_get_gripAction_mF8D3A50D9BA8A1E2822455ABA4D6EDAF67F841C9 (void);
// 0x00000760 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_gripAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_gripAction_mC82A4386E1833F46BC2487B18524FD65CE20BD77 (void);
// 0x00000761 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_triggerAction()
extern void XRDeviceSimulator_get_triggerAction_m356C2FD6244EBAD3F3691EADDDAF06D6C41E418C (void);
// 0x00000762 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_triggerAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_triggerAction_m2445205267DF7CC40CD780C614B1B225A5E72A87 (void);
// 0x00000763 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_primaryButtonAction()
extern void XRDeviceSimulator_get_primaryButtonAction_m286F93EFAB14D74C8034F8BEEC084AC30231B032 (void);
// 0x00000764 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_primaryButtonAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_primaryButtonAction_m37DD9A023EDCB8099B7B6595850D0891239692BB (void);
// 0x00000765 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_secondaryButtonAction()
extern void XRDeviceSimulator_get_secondaryButtonAction_mBA85B7EB879C7FF29D445134DF724473F9EBA37B (void);
// 0x00000766 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_secondaryButtonAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_secondaryButtonAction_m2652D2A7B3A59902721385E50FEE59DFB2E783B8 (void);
// 0x00000767 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_menuAction()
extern void XRDeviceSimulator_get_menuAction_m7AB8A4601FCF614B1B8A0952E7CEB273B0D6C846 (void);
// 0x00000768 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_menuAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_menuAction_m5FD921B1A1FB9A3C49FA8E2CE18D6CCE004B73CD (void);
// 0x00000769 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_primary2DAxisClickAction()
extern void XRDeviceSimulator_get_primary2DAxisClickAction_m3EBE6A566E1765FC0CC0D056950E2FAF6C2529ED (void);
// 0x0000076A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_primary2DAxisClickAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_primary2DAxisClickAction_m2D5CA90C271FDCA05A850C65F7BDC584E14FA123 (void);
// 0x0000076B UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_secondary2DAxisClickAction()
extern void XRDeviceSimulator_get_secondary2DAxisClickAction_m5D00330E31AB9A4D35ACF78953B24388BED58CDC (void);
// 0x0000076C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_secondary2DAxisClickAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_secondary2DAxisClickAction_m58132C5FF2C088BFAA88BB73B0BA2D70F68FC76F (void);
// 0x0000076D UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_primary2DAxisTouchAction()
extern void XRDeviceSimulator_get_primary2DAxisTouchAction_m3E488B2B036D17A1125D5DD345E3C9140A378E2E (void);
// 0x0000076E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_primary2DAxisTouchAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_primary2DAxisTouchAction_m0274E44C8AFA39DEEB51499D67100A10764A7975 (void);
// 0x0000076F UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_secondary2DAxisTouchAction()
extern void XRDeviceSimulator_get_secondary2DAxisTouchAction_mCE8E64F6ECF20ACBE13DACC0DE4E5A05EFCF97A1 (void);
// 0x00000770 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_secondary2DAxisTouchAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_secondary2DAxisTouchAction_m47D65F14FC902C965802218DCA82BFCA5977ACF7 (void);
// 0x00000771 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_primaryTouchAction()
extern void XRDeviceSimulator_get_primaryTouchAction_mB32728372313E7634E1FB3F8E9CF42281F3A572E (void);
// 0x00000772 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_primaryTouchAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_primaryTouchAction_m5EF5D0D5918B2BC411DA19C7D507933B6B33AE5A (void);
// 0x00000773 UnityEngine.InputSystem.InputActionReference UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_secondaryTouchAction()
extern void XRDeviceSimulator_get_secondaryTouchAction_m15C9D2FEAE5BF84BF458E7B5F91325A7D30A1C71 (void);
// 0x00000774 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_secondaryTouchAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_set_secondaryTouchAction_mE7A471FAC7DAED4C0F3ECE93DE3C4DBCF7EC0013 (void);
// 0x00000775 UnityEngine.Transform UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_cameraTransform()
extern void XRDeviceSimulator_get_cameraTransform_mE69EA56A2BD8CCE33B2631022BFE58ABA823B5D1 (void);
// 0x00000776 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_cameraTransform(UnityEngine.Transform)
extern void XRDeviceSimulator_set_cameraTransform_mA5541FFA49D1B07233D99919DD6C1C1E8E3C0159 (void);
// 0x00000777 UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/Space UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_keyboardTranslateSpace()
extern void XRDeviceSimulator_get_keyboardTranslateSpace_mD84B30BF94B9EAE217EBC5C1B9F54A6DF18BFAD9 (void);
// 0x00000778 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_keyboardTranslateSpace(UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/Space)
extern void XRDeviceSimulator_set_keyboardTranslateSpace_m8BAD2FB8021AED6460529298C046080EEF95F50F (void);
// 0x00000779 UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/Space UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseTranslateSpace()
extern void XRDeviceSimulator_get_mouseTranslateSpace_m18E032CBB10CE1C9529C1F4BDF191B9734A3684A (void);
// 0x0000077A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseTranslateSpace(UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/Space)
extern void XRDeviceSimulator_set_mouseTranslateSpace_mF9266577B9AC52FF3E8EEEDD6B902FF61A74BF94 (void);
// 0x0000077B System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_keyboardXTranslateSpeed()
extern void XRDeviceSimulator_get_keyboardXTranslateSpeed_m389BC52DEA00FD27DF4FCCDA29B54293C88B8791 (void);
// 0x0000077C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_keyboardXTranslateSpeed(System.Single)
extern void XRDeviceSimulator_set_keyboardXTranslateSpeed_m68F7FB38A4C94C9CE490C81B935DEB2E89453811 (void);
// 0x0000077D System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_keyboardYTranslateSpeed()
extern void XRDeviceSimulator_get_keyboardYTranslateSpeed_m922752C7771B3AEF27485A3295FB7BFD81B0630F (void);
// 0x0000077E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_keyboardYTranslateSpeed(System.Single)
extern void XRDeviceSimulator_set_keyboardYTranslateSpeed_m8258090B50D3E65A36A7B0DA6BEBE01D0341E81D (void);
// 0x0000077F System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_keyboardZTranslateSpeed()
extern void XRDeviceSimulator_get_keyboardZTranslateSpeed_mCA243411A3963B47CA8E534D9EB16F6599FA05CD (void);
// 0x00000780 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_keyboardZTranslateSpeed(System.Single)
extern void XRDeviceSimulator_set_keyboardZTranslateSpeed_m44E32EFE21308F559FDD0F2A344E8B67887EF81B (void);
// 0x00000781 System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseXTranslateSensitivity()
extern void XRDeviceSimulator_get_mouseXTranslateSensitivity_m1504A63453D5CC021B445FB8CAF316F196821424 (void);
// 0x00000782 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseXTranslateSensitivity(System.Single)
extern void XRDeviceSimulator_set_mouseXTranslateSensitivity_m3A90484266B8310E1C9FCB719781BF6B33994945 (void);
// 0x00000783 System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseYTranslateSensitivity()
extern void XRDeviceSimulator_get_mouseYTranslateSensitivity_m642A808C643B1376D4D807D06FA2A5BC1C50BF74 (void);
// 0x00000784 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseYTranslateSensitivity(System.Single)
extern void XRDeviceSimulator_set_mouseYTranslateSensitivity_m4BBA160B76EE5F21EC8BD32F4CF680D8873B85B8 (void);
// 0x00000785 System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseScrollTranslateSensitivity()
extern void XRDeviceSimulator_get_mouseScrollTranslateSensitivity_mE0D21CF2BED48CF37F59B63BB9DA971361FFFAAF (void);
// 0x00000786 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseScrollTranslateSensitivity(System.Single)
extern void XRDeviceSimulator_set_mouseScrollTranslateSensitivity_m47C02FCED3054DB801CA902049D0DE4D1264CB49 (void);
// 0x00000787 System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseXRotateSensitivity()
extern void XRDeviceSimulator_get_mouseXRotateSensitivity_m640232A7A57AC262214ED5AA126901BD95D629C3 (void);
// 0x00000788 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseXRotateSensitivity(System.Single)
extern void XRDeviceSimulator_set_mouseXRotateSensitivity_m5253525A9FBE8FCDF378C783AA84479F68DBBA6D (void);
// 0x00000789 System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseYRotateSensitivity()
extern void XRDeviceSimulator_get_mouseYRotateSensitivity_m1A7EDA07D6A575189DFAEF5C54295BC4D902A4A0 (void);
// 0x0000078A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseYRotateSensitivity(System.Single)
extern void XRDeviceSimulator_set_mouseYRotateSensitivity_mF8765671B6B5965442DDE6E62D1C1F5F8696C3D8 (void);
// 0x0000078B System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseScrollRotateSensitivity()
extern void XRDeviceSimulator_get_mouseScrollRotateSensitivity_m27C0ABBACC66FD4BC97B6037EFF971FC170A5965 (void);
// 0x0000078C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseScrollRotateSensitivity(System.Single)
extern void XRDeviceSimulator_set_mouseScrollRotateSensitivity_mA13117FF8411100F7E2478FFD646D3CCF3F2CB3B (void);
// 0x0000078D System.Boolean UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseYRotateInvert()
extern void XRDeviceSimulator_get_mouseYRotateInvert_m398877E0C1C8F04B3DA76F8CB84D4B889AB60242 (void);
// 0x0000078E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseYRotateInvert(System.Boolean)
extern void XRDeviceSimulator_set_mouseYRotateInvert_mB9456EC115026466FF5ADB444AC27F4940764592 (void);
// 0x0000078F UnityEngine.CursorLockMode UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_desiredCursorLockMode()
extern void XRDeviceSimulator_get_desiredCursorLockMode_m3ECE62FE6FCC61F60A56432597AF19D44555F843 (void);
// 0x00000790 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_desiredCursorLockMode(UnityEngine.CursorLockMode)
extern void XRDeviceSimulator_set_desiredCursorLockMode_mBD392BDE2729319B4BBD3E372A72164276816C88 (void);
// 0x00000791 UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/TransformationMode UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_mouseTransformationMode()
extern void XRDeviceSimulator_get_mouseTransformationMode_m4B1DA38C4DDCC9785B3B219F9A550A98E7DECEA1 (void);
// 0x00000792 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_mouseTransformationMode(UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/TransformationMode)
extern void XRDeviceSimulator_set_mouseTransformationMode_m660FD714F69BB1D3BA010C8C5F1278349A4C0B3D (void);
// 0x00000793 UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/Axis2DTargets UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::get_axis2DTargets()
extern void XRDeviceSimulator_get_axis2DTargets_m309638162C67C1A72F68994752C16F50F6DB0FEF (void);
// 0x00000794 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::set_axis2DTargets(UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/Axis2DTargets)
extern void XRDeviceSimulator_set_axis2DTargets_m0D927832A2EDEDFBA734E03856DF8525430B08CA (void);
// 0x00000795 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::Awake()
extern void XRDeviceSimulator_Awake_mB7354166CC56F521B90B60B03C95F8876ACEDE0E (void);
// 0x00000796 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnEnable()
extern void XRDeviceSimulator_OnEnable_mABA8CCD66A510B8267D32B79C75D7F1AD8C86C9D (void);
// 0x00000797 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnDisable()
extern void XRDeviceSimulator_OnDisable_mA36DC085A76AAB0A0A593FEE28A4FA15E78A2708 (void);
// 0x00000798 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::Update()
extern void XRDeviceSimulator_Update_m1862A567D5B8003D30A0BDEB71229D61F1F1B27B (void);
// 0x00000799 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::ProcessPoseInput()
extern void XRDeviceSimulator_ProcessPoseInput_m9DE0CD2B443DAF1DAD34D1960D717456C6AAD905 (void);
// 0x0000079A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::ProcessControlInput()
extern void XRDeviceSimulator_ProcessControlInput_mD3A3C40953B571571370883177CFDF3BEF613691 (void);
// 0x0000079B System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::ProcessAxis2DControlInput()
extern void XRDeviceSimulator_ProcessAxis2DControlInput_m8F7CD38A2329FCFCB8F278D58224DB49A4924DD9 (void);
// 0x0000079C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::ProcessButtonControlInput(UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedControllerState&)
extern void XRDeviceSimulator_ProcessButtonControlInput_m4A2AFCA8A0754EDEE25C336AC07F9AC41662E297 (void);
// 0x0000079D System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::AddDevices()
extern void XRDeviceSimulator_AddDevices_m7A66EC8ABC4D2CF81EA42EB1F8072F32B6E4D496 (void);
// 0x0000079E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::RemoveDevices()
extern void XRDeviceSimulator_RemoveDevices_m4F234089A219F2460DC88E70E679DE414DD7EEFF (void);
// 0x0000079F UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::GetResetScale()
extern void XRDeviceSimulator_GetResetScale_mCB1E0A5E967781B3816F31EFFC32056E361EEA53 (void);
// 0x000007A0 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::GetAxes(UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/Space,UnityEngine.Transform,UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void XRDeviceSimulator_GetAxes_mFF030276175F56454AC60CCCC6D02C35C6C33836 (void);
// 0x000007A1 UnityEngine.Quaternion UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::GetDeltaRotation(UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/Space,UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedControllerState&,UnityEngine.Quaternion&)
extern void XRDeviceSimulator_GetDeltaRotation_m4DCF5F75EE0D312B36645EC08DF2EE329A8C3ABD (void);
// 0x000007A2 UnityEngine.Quaternion UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::GetDeltaRotation(UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/Space,UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedHMDState&,UnityEngine.Quaternion&)
extern void XRDeviceSimulator_GetDeltaRotation_mDCF47ED8533052B93FC8884173C90DE293963A1B (void);
// 0x000007A3 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::Subscribe(UnityEngine.InputSystem.InputActionReference,System.Action`1<UnityEngine.InputSystem.InputAction/CallbackContext>,System.Action`1<UnityEngine.InputSystem.InputAction/CallbackContext>)
extern void XRDeviceSimulator_Subscribe_m94B54AD4163BE1FC8818A38781BA4E02D865C4C8 (void);
// 0x000007A4 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::Unsubscribe(UnityEngine.InputSystem.InputActionReference,System.Action`1<UnityEngine.InputSystem.InputAction/CallbackContext>,System.Action`1<UnityEngine.InputSystem.InputAction/CallbackContext>)
extern void XRDeviceSimulator_Unsubscribe_m67CF8C4C8C245834AD5899CF9353C53D55F5D315 (void);
// 0x000007A5 UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/TransformationMode UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::Negate(UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator/TransformationMode)
extern void XRDeviceSimulator_Negate_mFDD855D432CF1EBB2C0CB7AF36B98D6749DCC5DE (void);
// 0x000007A6 UnityEngine.CursorLockMode UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::Negate(UnityEngine.CursorLockMode)
extern void XRDeviceSimulator_Negate_m83389CDC34F3273C4B0A84CD51EA2A96AF4B367F (void);
// 0x000007A7 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeKeyboardXTranslateAction()
extern void XRDeviceSimulator_SubscribeKeyboardXTranslateAction_mF5F214D6BE91F7D40A942F9FCF0C505A9BCB62A7 (void);
// 0x000007A8 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeKeyboardXTranslateAction()
extern void XRDeviceSimulator_UnsubscribeKeyboardXTranslateAction_m17B0CB976185047968EE8DACF1AFFEDC922A3326 (void);
// 0x000007A9 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeKeyboardYTranslateAction()
extern void XRDeviceSimulator_SubscribeKeyboardYTranslateAction_m3476DB11F7CBF16F6F96F5FCB70D2F09EE91A51A (void);
// 0x000007AA System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeKeyboardYTranslateAction()
extern void XRDeviceSimulator_UnsubscribeKeyboardYTranslateAction_mCF1C30BE8B5A92D13E93EA24783C2C9E49E3E559 (void);
// 0x000007AB System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeKeyboardZTranslateAction()
extern void XRDeviceSimulator_SubscribeKeyboardZTranslateAction_mF3D0838F678A3C975BB07A040FE6BB13EBE60C73 (void);
// 0x000007AC System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeKeyboardZTranslateAction()
extern void XRDeviceSimulator_UnsubscribeKeyboardZTranslateAction_m03AABC3A9C51776A67F67EF9150E6DEC0C084E51 (void);
// 0x000007AD System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeManipulateLeftAction()
extern void XRDeviceSimulator_SubscribeManipulateLeftAction_mD53C13547F74736EB1F5028C38B1EF027E7E1259 (void);
// 0x000007AE System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeManipulateLeftAction()
extern void XRDeviceSimulator_UnsubscribeManipulateLeftAction_mE7A2810F552F643BE8D136497007F74230675EDB (void);
// 0x000007AF System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeManipulateRightAction()
extern void XRDeviceSimulator_SubscribeManipulateRightAction_mEEC6214614815D4EC0672AEA1DCE96E800725B3C (void);
// 0x000007B0 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeManipulateRightAction()
extern void XRDeviceSimulator_UnsubscribeManipulateRightAction_m8C3ED9D684E387BAEA913CE292436ABB624F559C (void);
// 0x000007B1 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeToggleManipulateLeftAction()
extern void XRDeviceSimulator_SubscribeToggleManipulateLeftAction_mBD922DA8476E6E8C34A95DEFF25F19A611607498 (void);
// 0x000007B2 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeToggleManipulateLeftAction()
extern void XRDeviceSimulator_UnsubscribeToggleManipulateLeftAction_m58515CBE068E443BA8C10EDA17C40CA3C3AA2013 (void);
// 0x000007B3 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeToggleManipulateRightAction()
extern void XRDeviceSimulator_SubscribeToggleManipulateRightAction_mF8F99C0864D39497558B37FE66F476CCE907FF26 (void);
// 0x000007B4 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeToggleManipulateRightAction()
extern void XRDeviceSimulator_UnsubscribeToggleManipulateRightAction_mEF6C726FFB815DE24298CD9A872E8DA0C380F3E2 (void);
// 0x000007B5 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeManipulateHeadAction()
extern void XRDeviceSimulator_SubscribeManipulateHeadAction_mD93767D23006A63DD6609CC010FE1D811CD4718B (void);
// 0x000007B6 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeManipulateHeadAction()
extern void XRDeviceSimulator_UnsubscribeManipulateHeadAction_m7CE0F054B5B0F4AB0A0E3262F19E77006AEC37A5 (void);
// 0x000007B7 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeMouseDeltaAction()
extern void XRDeviceSimulator_SubscribeMouseDeltaAction_mFBC26E52821E64B00A48B28528144C477D79A449 (void);
// 0x000007B8 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeMouseDeltaAction()
extern void XRDeviceSimulator_UnsubscribeMouseDeltaAction_m4920F0A5805479C8D0EC907F9E1801012B8C53C4 (void);
// 0x000007B9 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeMouseScrollAction()
extern void XRDeviceSimulator_SubscribeMouseScrollAction_m2EA3A72C5F1197778296EC30FE2339E59B3307E5 (void);
// 0x000007BA System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeMouseScrollAction()
extern void XRDeviceSimulator_UnsubscribeMouseScrollAction_m1CCAC1953BD5ECAE03520DFAF98BF6C3806C7A5E (void);
// 0x000007BB System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeRotateModeOverrideAction()
extern void XRDeviceSimulator_SubscribeRotateModeOverrideAction_m675403D07C133800BCB377D1ABDA6FA822D3A831 (void);
// 0x000007BC System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeRotateModeOverrideAction()
extern void XRDeviceSimulator_UnsubscribeRotateModeOverrideAction_m432358631EFED54244B3C75E2536C2041919E3BB (void);
// 0x000007BD System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeToggleMouseTransformationModeAction()
extern void XRDeviceSimulator_SubscribeToggleMouseTransformationModeAction_mCA640A12CE85726CDEF7577A4B5BD6E7605DE398 (void);
// 0x000007BE System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeToggleMouseTransformationModeAction()
extern void XRDeviceSimulator_UnsubscribeToggleMouseTransformationModeAction_m2F1E864A99BA95B4A210E8143854F3BB87129C8E (void);
// 0x000007BF System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeNegateModeAction()
extern void XRDeviceSimulator_SubscribeNegateModeAction_m3D1CB0B778CE5ED454F6C71AE969A13EF5092BCD (void);
// 0x000007C0 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeNegateModeAction()
extern void XRDeviceSimulator_UnsubscribeNegateModeAction_m29A64AE898E18B60CF07B9D1854C4A7938F313F8 (void);
// 0x000007C1 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeXConstraintAction()
extern void XRDeviceSimulator_SubscribeXConstraintAction_mEC462812ED2BE192DF2140F610DCD6EF495149F5 (void);
// 0x000007C2 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeXConstraintAction()
extern void XRDeviceSimulator_UnsubscribeXConstraintAction_mE32B6BDA4A4C8DF81466ED5C0A2C21B5E5D9FA60 (void);
// 0x000007C3 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeYConstraintAction()
extern void XRDeviceSimulator_SubscribeYConstraintAction_mAEA84DE97813CCF038E9F0323988DF18D7DF708D (void);
// 0x000007C4 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeYConstraintAction()
extern void XRDeviceSimulator_UnsubscribeYConstraintAction_m4FB08602488FAF46370C7C546BC9A1E500C9F1F9 (void);
// 0x000007C5 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeZConstraintAction()
extern void XRDeviceSimulator_SubscribeZConstraintAction_m9DC31BFE74DC3BE79F674E32F7BFD118CFE3D263 (void);
// 0x000007C6 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeZConstraintAction()
extern void XRDeviceSimulator_UnsubscribeZConstraintAction_mD5F5C32604FA9279C4A2E4F5CA5930BD4365896C (void);
// 0x000007C7 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeResetAction()
extern void XRDeviceSimulator_SubscribeResetAction_mE43405C6958110CE587F3DEC8614F739F29FC907 (void);
// 0x000007C8 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeResetAction()
extern void XRDeviceSimulator_UnsubscribeResetAction_m297A5FA135042071E0ADF8D22E6FA072D16270DB (void);
// 0x000007C9 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeToggleCursorLockAction()
extern void XRDeviceSimulator_SubscribeToggleCursorLockAction_m69D27C5AD4016B86E8E5547524E0CB9594A925DF (void);
// 0x000007CA System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeToggleCursorLockAction()
extern void XRDeviceSimulator_UnsubscribeToggleCursorLockAction_mD2127A2E97077EC68E55277CFD0458A1BFC3B3D2 (void);
// 0x000007CB System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeToggleDevicePositionTargetAction()
extern void XRDeviceSimulator_SubscribeToggleDevicePositionTargetAction_m1718D06DAA48D827A4A660AA78563152C3B6BDB3 (void);
// 0x000007CC System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeToggleDevicePositionTargetAction()
extern void XRDeviceSimulator_UnsubscribeToggleDevicePositionTargetAction_m8AB133CDF4AF1A49467E7CBB7F624EB5CC07A334 (void);
// 0x000007CD System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeTogglePrimary2DAxisTargetAction()
extern void XRDeviceSimulator_SubscribeTogglePrimary2DAxisTargetAction_m9EABDF1D9C2D3CD4D75FCC8A0A28A26BCB9D6E9E (void);
// 0x000007CE System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeTogglePrimary2DAxisTargetAction()
extern void XRDeviceSimulator_UnsubscribeTogglePrimary2DAxisTargetAction_m3690C2751B86388858068BB1F4EF163CFD89D490 (void);
// 0x000007CF System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeToggleSecondary2DAxisTargetAction()
extern void XRDeviceSimulator_SubscribeToggleSecondary2DAxisTargetAction_mBFCB0BD393716F2BDDFC3268F92466CC69012A8D (void);
// 0x000007D0 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeToggleSecondary2DAxisTargetAction()
extern void XRDeviceSimulator_UnsubscribeToggleSecondary2DAxisTargetAction_m863257972E56B7226952901D2D7D5A91FB789927 (void);
// 0x000007D1 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeAxis2DAction()
extern void XRDeviceSimulator_SubscribeAxis2DAction_m275D1053C828F34EDB7883C4EE22C555D2176A89 (void);
// 0x000007D2 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeAxis2DAction()
extern void XRDeviceSimulator_UnsubscribeAxis2DAction_mD7054D44E01F2FA50432CB6B0F1F4C2C37BA12F3 (void);
// 0x000007D3 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeRestingHandAxis2DAction()
extern void XRDeviceSimulator_SubscribeRestingHandAxis2DAction_m8ED686AC4E153E5870A5EA493A3742038898CEF1 (void);
// 0x000007D4 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeRestingHandAxis2DAction()
extern void XRDeviceSimulator_UnsubscribeRestingHandAxis2DAction_mBBE849D0687339DABC2773440D2C3B1B6E9804B0 (void);
// 0x000007D5 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeGripAction()
extern void XRDeviceSimulator_SubscribeGripAction_mF6B3FAF307A12624EA0ABE3A9ADB1C924005C480 (void);
// 0x000007D6 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeGripAction()
extern void XRDeviceSimulator_UnsubscribeGripAction_m23A1AAFBA30065E12F94CD01ACA9B490D3367D7B (void);
// 0x000007D7 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeTriggerAction()
extern void XRDeviceSimulator_SubscribeTriggerAction_m10D96C279FD777BE6D52EB1DB97F7DCE9BE321BF (void);
// 0x000007D8 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeTriggerAction()
extern void XRDeviceSimulator_UnsubscribeTriggerAction_m1101AC4637487B6EE50DE3D1404784505350CE74 (void);
// 0x000007D9 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribePrimaryButtonAction()
extern void XRDeviceSimulator_SubscribePrimaryButtonAction_mF2C0DFCBD5A571C6F123B54F28FECA7C969E6D10 (void);
// 0x000007DA System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribePrimaryButtonAction()
extern void XRDeviceSimulator_UnsubscribePrimaryButtonAction_m22592C5ED5EB11FCE993554F5D9C90654A4CF4EE (void);
// 0x000007DB System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeSecondaryButtonAction()
extern void XRDeviceSimulator_SubscribeSecondaryButtonAction_m659FA3C481C9C04AF3FA2BB7C7DE01406335B912 (void);
// 0x000007DC System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeSecondaryButtonAction()
extern void XRDeviceSimulator_UnsubscribeSecondaryButtonAction_mBCD0F9829C2C2BC01F5D8A8D320EE80BB730E468 (void);
// 0x000007DD System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeMenuAction()
extern void XRDeviceSimulator_SubscribeMenuAction_m2ABF5166EC9983EC68D8F23C37C5E11F45275E7F (void);
// 0x000007DE System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeMenuAction()
extern void XRDeviceSimulator_UnsubscribeMenuAction_m6DA07E7D80E16E62E5D9EBA281052959128B7C58 (void);
// 0x000007DF System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribePrimary2DAxisClickAction()
extern void XRDeviceSimulator_SubscribePrimary2DAxisClickAction_mAD230435692F196C0F967879E49E17BC7C6822B8 (void);
// 0x000007E0 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribePrimary2DAxisClickAction()
extern void XRDeviceSimulator_UnsubscribePrimary2DAxisClickAction_m9E1779EDDD5709FCC3CF11CDE6B7453A7B37A71A (void);
// 0x000007E1 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeSecondary2DAxisClickAction()
extern void XRDeviceSimulator_SubscribeSecondary2DAxisClickAction_m3ABE2D97B22137F00ABC74EE676B062FCD62ECE4 (void);
// 0x000007E2 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeSecondary2DAxisClickAction()
extern void XRDeviceSimulator_UnsubscribeSecondary2DAxisClickAction_m3387E29A3C191F17CEA7030DC94BB2B4BDBBF1E6 (void);
// 0x000007E3 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribePrimary2DAxisTouchAction()
extern void XRDeviceSimulator_SubscribePrimary2DAxisTouchAction_mBC001D662AA4AE964D01CD1BAD0610E050F8F07E (void);
// 0x000007E4 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribePrimary2DAxisTouchAction()
extern void XRDeviceSimulator_UnsubscribePrimary2DAxisTouchAction_m64B6E6305AC8153A62D7B17247E4CB1690F0E0FC (void);
// 0x000007E5 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeSecondary2DAxisTouchAction()
extern void XRDeviceSimulator_SubscribeSecondary2DAxisTouchAction_mDA7DF3C1B099219DEE159DC84064DF025C74C159 (void);
// 0x000007E6 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeSecondary2DAxisTouchAction()
extern void XRDeviceSimulator_UnsubscribeSecondary2DAxisTouchAction_mD7B613B55AEF309407C78C126B30E62BA8490585 (void);
// 0x000007E7 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribePrimaryTouchAction()
extern void XRDeviceSimulator_SubscribePrimaryTouchAction_m757B15220C07284598CFF79169F0DD6E786D79E9 (void);
// 0x000007E8 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribePrimaryTouchAction()
extern void XRDeviceSimulator_UnsubscribePrimaryTouchAction_m99632A4EACE31027FA50710717AD4DCDAA630E27 (void);
// 0x000007E9 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::SubscribeSecondaryTouchAction()
extern void XRDeviceSimulator_SubscribeSecondaryTouchAction_mD6CC16F35F94B68735A93ECC5E2B0451CFFD5BA1 (void);
// 0x000007EA System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::UnsubscribeSecondaryTouchAction()
extern void XRDeviceSimulator_UnsubscribeSecondaryTouchAction_mCC186602E6C37BC40AEDE17C4E25F7B17CDC0CF1 (void);
// 0x000007EB System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnKeyboardXTranslatePerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnKeyboardXTranslatePerformed_mFCAC0258E6CC92FAFE3F91895BF06DE865D2C220 (void);
// 0x000007EC System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnKeyboardXTranslateCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnKeyboardXTranslateCanceled_mBD214F23552B463B76402D8A6D5C2C2ED9C59F16 (void);
// 0x000007ED System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnKeyboardYTranslatePerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnKeyboardYTranslatePerformed_m40F8069EAD76BA7E5D685102CCDB28DA2829F2D0 (void);
// 0x000007EE System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnKeyboardYTranslateCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnKeyboardYTranslateCanceled_mF089B425991D3DD571F436E0F0E18125FF7D7900 (void);
// 0x000007EF System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnKeyboardZTranslatePerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnKeyboardZTranslatePerformed_mAAB7B25C23D5E23D50AA933D11EA700630C86AEC (void);
// 0x000007F0 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnKeyboardZTranslateCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnKeyboardZTranslateCanceled_m20D44E88F331E32453CE24F34E5B5E86F9D5943F (void);
// 0x000007F1 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnManipulateLeftPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnManipulateLeftPerformed_mF23C2D6A5FC42C695C8CBA046B2E19B15F0271AB (void);
// 0x000007F2 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnManipulateLeftCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnManipulateLeftCanceled_m19CF065C2C176BCCF4B95FA32D9FBE95ED5DFCA2 (void);
// 0x000007F3 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnManipulateRightPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnManipulateRightPerformed_mCE9A6D27C1706457951B57B165D89FBF9BF260B0 (void);
// 0x000007F4 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnManipulateRightCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnManipulateRightCanceled_mCB8958CD353CD0B26C566579F512FC0514DD7169 (void);
// 0x000007F5 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnToggleManipulateLeftPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnToggleManipulateLeftPerformed_m1B3566D17D261DE520F311B1FFD51B771E081004 (void);
// 0x000007F6 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnToggleManipulateRightPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnToggleManipulateRightPerformed_mE6E471CB74C52993FF3B515DD1FBCDDE7481B213 (void);
// 0x000007F7 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnManipulateHeadPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnManipulateHeadPerformed_mFB8D9828739B209D08EEA0D1A8C2E6B4A9B57E07 (void);
// 0x000007F8 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnManipulateHeadCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnManipulateHeadCanceled_mFFBE7BA9559CCE2DB07F672BFF5E395624EB34AE (void);
// 0x000007F9 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnMouseDeltaPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnMouseDeltaPerformed_m4CA1862B19F8B444BC6AC423E22F9408E875BD91 (void);
// 0x000007FA System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnMouseDeltaCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnMouseDeltaCanceled_m6CB39E02ED7F5793569BDCC75E9FF239F738EC0B (void);
// 0x000007FB System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnMouseScrollPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnMouseScrollPerformed_m95786C5926090F9A201C22D7126C1FFD76447A5C (void);
// 0x000007FC System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnMouseScrollCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnMouseScrollCanceled_mDBD720D6A5B8F31473B0D6556638872D785E69C1 (void);
// 0x000007FD System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnRotateModeOverridePerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnRotateModeOverridePerformed_m1BE1317326284C080D7A7F0A5A7AA9E697A12678 (void);
// 0x000007FE System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnRotateModeOverrideCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnRotateModeOverrideCanceled_mAE8D8DAC62B3AFA676A68E227B802897AE521B44 (void);
// 0x000007FF System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnToggleMouseTransformationModePerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnToggleMouseTransformationModePerformed_m5BC9D11803692128CBAB258E1FD55BCF013B93BC (void);
// 0x00000800 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnNegateModePerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnNegateModePerformed_m64FF191DF49B980B1DAC7AC9736D308A17ADC8B2 (void);
// 0x00000801 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnNegateModeCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnNegateModeCanceled_m7D92F90F5893FB5C62ACBDECFCD8A26DEE813AAF (void);
// 0x00000802 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnXConstraintPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnXConstraintPerformed_m4F20432B217EB5AA31E9B8D1C3682F50352F2FAB (void);
// 0x00000803 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnXConstraintCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnXConstraintCanceled_mA6E34558C4D79762840CAEA3861BEAF38214B7FF (void);
// 0x00000804 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnYConstraintPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnYConstraintPerformed_m8A9FA9338631AD01BEB211894588D40CE713855F (void);
// 0x00000805 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnYConstraintCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnYConstraintCanceled_m447AEF57E5584D790F01A0FD646B1769FD24846B (void);
// 0x00000806 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnZConstraintPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnZConstraintPerformed_m96B5BA427F6A3A2D91CA3C4EE6EFB64A8AE08A73 (void);
// 0x00000807 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnZConstraintCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnZConstraintCanceled_mF70A4658361DB0669A0D88EDA8F507BFFAF7C4EE (void);
// 0x00000808 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnResetPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnResetPerformed_m6806C760C8DFC82949BA4D70B0118AAEE2DE2394 (void);
// 0x00000809 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnResetCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnResetCanceled_mA06C83A4037DB3E800B13C5AE046430B3F4612C8 (void);
// 0x0000080A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnToggleCursorLockPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnToggleCursorLockPerformed_m6EDD25F207DFBED58F76DF23BBA9239C045858E7 (void);
// 0x0000080B System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnToggleDevicePositionTargetPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnToggleDevicePositionTargetPerformed_m0037BE411764319DEB1D1AF25D0C0AA25DD18AE3 (void);
// 0x0000080C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnTogglePrimary2DAxisTargetPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnTogglePrimary2DAxisTargetPerformed_m892D157F0D0E8ACF21D01C275DF81BCFD1BFFFC5 (void);
// 0x0000080D System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnToggleSecondary2DAxisTargetPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnToggleSecondary2DAxisTargetPerformed_m8C2D0BD581AD2359AEAA5809EB722DACF56CD80A (void);
// 0x0000080E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnAxis2DPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnAxis2DPerformed_mD5664DCB475D5F3C924E23D0D6C1FA2BBA1C38B2 (void);
// 0x0000080F System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnAxis2DCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnAxis2DCanceled_m764D20A59AAB7E41B5F9701014A797C8CAE9B31D (void);
// 0x00000810 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnRestingHandAxis2DPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnRestingHandAxis2DPerformed_mF88AB28FD2D3104B56460D04E5ED94E5D76981C8 (void);
// 0x00000811 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnRestingHandAxis2DCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnRestingHandAxis2DCanceled_m81B48D1151E59B2127A6424BCA390FD695557EA8 (void);
// 0x00000812 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnGripPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnGripPerformed_mFF57E28A0F5C3FA3F01A5B6070B93A551F527F11 (void);
// 0x00000813 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnGripCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnGripCanceled_m06150399A70700B0E3AADCE3A221DE582637DE54 (void);
// 0x00000814 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnTriggerPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnTriggerPerformed_m1BCAC29E1AD73CE447E9A4A795FC13F37CE1660E (void);
// 0x00000815 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnTriggerCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnTriggerCanceled_mD02FE23ABB6A93E85C8E7D3A0FDCE6FEF3C13D93 (void);
// 0x00000816 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnPrimaryButtonPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnPrimaryButtonPerformed_mFF4B8B2C09231ADCA420F06FFE8EB1FD4EEC4BD6 (void);
// 0x00000817 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnPrimaryButtonCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnPrimaryButtonCanceled_m81D740D5C0DC62D465F2673AEB6CB73042EF185E (void);
// 0x00000818 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnSecondaryButtonPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnSecondaryButtonPerformed_m5178544B95463BDA3058B0D29BDC396AE7B37211 (void);
// 0x00000819 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnSecondaryButtonCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnSecondaryButtonCanceled_mE2771DA3E65DFAC8CAF2505F2EE8A5A5663DD8D0 (void);
// 0x0000081A System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnMenuPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnMenuPerformed_mECE12672BA68D8A48A011904443D2A22F5EB96C6 (void);
// 0x0000081B System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnMenuCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnMenuCanceled_mA3876DEE847FACE2FB13582B7F096CDFEC6D400C (void);
// 0x0000081C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnPrimary2DAxisClickPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnPrimary2DAxisClickPerformed_mC2219112443FF7E03C6755653DB6E38149B66F23 (void);
// 0x0000081D System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnPrimary2DAxisClickCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnPrimary2DAxisClickCanceled_mD30F7D15FB6A0DD42FE3DB591AD51D1941E4FC0D (void);
// 0x0000081E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnSecondary2DAxisClickPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnSecondary2DAxisClickPerformed_m4C67AE3185C97A85D3A48C62C4F7BAF75311B5F7 (void);
// 0x0000081F System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnSecondary2DAxisClickCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnSecondary2DAxisClickCanceled_m19423A5BE6CC8EAB8AD576F5A97B3D6C4717A5EE (void);
// 0x00000820 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnPrimary2DAxisTouchPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnPrimary2DAxisTouchPerformed_m53471FB52C78133DC361545152034BF1733127F0 (void);
// 0x00000821 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnPrimary2DAxisTouchCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnPrimary2DAxisTouchCanceled_m6A8280D66B5BEAC7BECFD0E99B45D596A644157B (void);
// 0x00000822 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnSecondary2DAxisTouchPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnSecondary2DAxisTouchPerformed_m5A0E5F9B25F1198649BBDED3866E56FE321777DD (void);
// 0x00000823 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnSecondary2DAxisTouchCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnSecondary2DAxisTouchCanceled_m36C291294831D2D7C5CE565D0CF84BF20830DD5F (void);
// 0x00000824 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnPrimaryTouchPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnPrimaryTouchPerformed_m292235D411F52FA79F7662B90522260C62163F79 (void);
// 0x00000825 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnPrimaryTouchCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnPrimaryTouchCanceled_m6FAFC708C56DE710D2E0EDEC0EAB51439FA282E1 (void);
// 0x00000826 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnSecondaryTouchPerformed(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnSecondaryTouchPerformed_mC3D6308E6A6D0FBD0E9BA86948274FE472E540DD (void);
// 0x00000827 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::OnSecondaryTouchCanceled(UnityEngine.InputSystem.InputAction/CallbackContext)
extern void XRDeviceSimulator_OnSecondaryTouchCanceled_mE504E7C7997707627B60D54E5AB5A715CED4B822 (void);
// 0x00000828 UnityEngine.InputSystem.InputAction UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::GetInputAction(UnityEngine.InputSystem.InputActionReference)
extern void XRDeviceSimulator_GetInputAction_mCF2EE1D4E657C46A6A6C2AE241F6D4519DE6792F (void);
// 0x00000829 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRDeviceSimulator::.ctor()
extern void XRDeviceSimulator__ctor_mD8BB5B64046CD20C8F2904623F02EB3084A3338D (void);
// 0x0000082A UnityEngine.InputSystem.Controls.Vector2Control UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_primary2DAxis()
extern void XRSimulatedController_get_primary2DAxis_mAF2FED1E7AB64C05557A4A4F7CB52F56E67108FA (void);
// 0x0000082B System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_primary2DAxis(UnityEngine.InputSystem.Controls.Vector2Control)
extern void XRSimulatedController_set_primary2DAxis_m7A0C20F1B4404906C997D9CE91D6C52C50F0F15C (void);
// 0x0000082C UnityEngine.InputSystem.Controls.AxisControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_trigger()
extern void XRSimulatedController_get_trigger_m27D6198CE632235EAD8D1F4718331303C51F1875 (void);
// 0x0000082D System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_trigger(UnityEngine.InputSystem.Controls.AxisControl)
extern void XRSimulatedController_set_trigger_m68796BA3B3A576C7B4FE3F87B0818238F17581FE (void);
// 0x0000082E UnityEngine.InputSystem.Controls.AxisControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_grip()
extern void XRSimulatedController_get_grip_m7A18FD9D5A4568D9798C26EEDA57C1DE9DE3CB25 (void);
// 0x0000082F System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_grip(UnityEngine.InputSystem.Controls.AxisControl)
extern void XRSimulatedController_set_grip_mA29793E90FFBAF46AB97ECFDCADF35319225FC5F (void);
// 0x00000830 UnityEngine.InputSystem.Controls.Vector2Control UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_secondary2DAxis()
extern void XRSimulatedController_get_secondary2DAxis_m1F393220F560984BBAA42279EA41B9998DAD62A3 (void);
// 0x00000831 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_secondary2DAxis(UnityEngine.InputSystem.Controls.Vector2Control)
extern void XRSimulatedController_set_secondary2DAxis_m613F0CDCCBC1F183CA72C25314F86B1AF178857C (void);
// 0x00000832 UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_primaryButton()
extern void XRSimulatedController_get_primaryButton_mC9F0C0771A1127157D33BBDB9FA703199F3CC4FB (void);
// 0x00000833 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_primaryButton(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_primaryButton_m15D617064AE81505F37102EFF63C7409351B8A7A (void);
// 0x00000834 UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_primaryTouch()
extern void XRSimulatedController_get_primaryTouch_m6B203A3E37CB2C57A1A880FC46DD993ABEBCC485 (void);
// 0x00000835 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_primaryTouch(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_primaryTouch_mDFAF8210AD8C22DE3A9FE56EF0CDFFF34D4C1440 (void);
// 0x00000836 UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_secondaryButton()
extern void XRSimulatedController_get_secondaryButton_m7294824267990D389FD1A2F5C0FE8B4CCF0E2C0E (void);
// 0x00000837 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_secondaryButton(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_secondaryButton_m60115A11E636816EAC49D12C80A0E2FCD7DEE421 (void);
// 0x00000838 UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_secondaryTouch()
extern void XRSimulatedController_get_secondaryTouch_mE297E7E8746E76C736E3E84FA257919B71919B0E (void);
// 0x00000839 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_secondaryTouch(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_secondaryTouch_mC35856850084AC8AFD91583382C6CD7A19B1477A (void);
// 0x0000083A UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_gripButton()
extern void XRSimulatedController_get_gripButton_m54671C748837AAC21BE0A97C7688A5E391772811 (void);
// 0x0000083B System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_gripButton(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_gripButton_mFD25C7B73E266E962F4947B0F5CE2E4F794E9EAC (void);
// 0x0000083C UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_triggerButton()
extern void XRSimulatedController_get_triggerButton_m7AAE82E76AA1F943C6ED68BB3FD7A2E1BC637E34 (void);
// 0x0000083D System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_triggerButton(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_triggerButton_mE6B324265109BF69F513972AADF7BBAD404A7AFC (void);
// 0x0000083E UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_menuButton()
extern void XRSimulatedController_get_menuButton_mA7B7A75B485333B47356D280C1001759B7E320E1 (void);
// 0x0000083F System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_menuButton(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_menuButton_mC8BC114ABE931CCC003E4396FF0698809A99B72E (void);
// 0x00000840 UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_primary2DAxisClick()
extern void XRSimulatedController_get_primary2DAxisClick_m588E4991D53C843C37B4584782DB744B027309E8 (void);
// 0x00000841 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_primary2DAxisClick(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_primary2DAxisClick_m638CB68202BC37E28C6F0E57D55E6F8EB331F6B6 (void);
// 0x00000842 UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_primary2DAxisTouch()
extern void XRSimulatedController_get_primary2DAxisTouch_m3124E177B5CCE1A73B9AA76BEDF4F8A42DFC43CE (void);
// 0x00000843 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_primary2DAxisTouch(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_primary2DAxisTouch_mBC97D927DA2369C28252198AC3C9DD5BB9B59BC1 (void);
// 0x00000844 UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_secondary2DAxisClick()
extern void XRSimulatedController_get_secondary2DAxisClick_mE78883C6965CBB7918AC02F2D5DDFDC03A3357CA (void);
// 0x00000845 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_secondary2DAxisClick(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_secondary2DAxisClick_m6A4F93455D5534D4E92E319FC4FFA3563B067785 (void);
// 0x00000846 UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_secondary2DAxisTouch()
extern void XRSimulatedController_get_secondary2DAxisTouch_m96828C8B69B1C2A8E96096198C84514D7D1B6B60 (void);
// 0x00000847 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_secondary2DAxisTouch(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_secondary2DAxisTouch_mCC043B0B0B5151781240A54D17EB6C5F216608DB (void);
// 0x00000848 UnityEngine.InputSystem.Controls.AxisControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_batteryLevel()
extern void XRSimulatedController_get_batteryLevel_m594224555A74A8B309D4F7EEDC627BDEF7A4990E (void);
// 0x00000849 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_batteryLevel(UnityEngine.InputSystem.Controls.AxisControl)
extern void XRSimulatedController_set_batteryLevel_m976781C86BAFCB8B6EB82BEF3CE094679EA55FB5 (void);
// 0x0000084A UnityEngine.InputSystem.Controls.ButtonControl UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::get_userPresence()
extern void XRSimulatedController_get_userPresence_m098F4606FAE0AE89492F73E3017F3BB301FFBDFD (void);
// 0x0000084B System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::set_userPresence(UnityEngine.InputSystem.Controls.ButtonControl)
extern void XRSimulatedController_set_userPresence_mC9D9BC9139B15D8916BCABB263A03130152A0D01 (void);
// 0x0000084C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::FinishSetup()
extern void XRSimulatedController_FinishSetup_mC4F39D2415258871BDC77C81A34846D3D2BCB60C (void);
// 0x0000084D System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedController::.ctor()
extern void XRSimulatedController__ctor_m3FD0B01E3EAF634756117453A5630363F71A5A28 (void);
// 0x0000084E UnityEngine.InputSystem.Utilities.FourCC UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedControllerState::get_formatId()
extern void XRSimulatedControllerState_get_formatId_m33E91E1AC8A754DB2FAB298BE3CD9F9AA7BF32B4 (void);
// 0x0000084F UnityEngine.InputSystem.Utilities.FourCC UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedControllerState::get_format()
extern void XRSimulatedControllerState_get_format_mEF0A3619592E3FE42EEF41C6C13DCB3281AD4F93 (void);
// 0x00000850 UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedControllerState UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedControllerState::WithButton(UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.ControllerButton,System.Boolean)
extern void XRSimulatedControllerState_WithButton_m19828BD5A6F4B3AC3B3A83EB98172C9099658594 (void);
// 0x00000851 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedControllerState::Reset()
extern void XRSimulatedControllerState_Reset_m1216B08CF7B737AABDA2F2E321A8164AD8D17351 (void);
// 0x00000852 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedHMD::.ctor()
extern void XRSimulatedHMD__ctor_mAD88459F96D54A3EE12A1C3AED0EA693A0111493 (void);
// 0x00000853 UnityEngine.InputSystem.Utilities.FourCC UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedHMDState::get_formatId()
extern void XRSimulatedHMDState_get_formatId_m40DE5859F6C18E72436D347602F12DDE29E71706 (void);
// 0x00000854 UnityEngine.InputSystem.Utilities.FourCC UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedHMDState::get_format()
extern void XRSimulatedHMDState_get_format_m6690480C9D6962BDEC42737C39C3FE448ABDCCD6 (void);
// 0x00000855 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Simulation.XRSimulatedHMDState::Reset()
extern void XRSimulatedHMDState_Reset_mF2E881F062465B441F929A6319E6843800A0B9BC (void);
// 0x00000856 System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction::get_pressPointOrDefault()
extern void SectorInteraction_get_pressPointOrDefault_mE709A4723D93A3D5FC139C363DE576F66CBF334B (void);
// 0x00000857 System.Single UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction::get_defaultPressPoint()
extern void SectorInteraction_get_defaultPressPoint_mBA26AF006B61005E9C3CAC911325A722786505C2 (void);
// 0x00000858 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction::set_defaultPressPoint(System.Single)
extern void SectorInteraction_set_defaultPressPoint_m4126E087B8480CB673D5510CA5D309D53D558C8D (void);
// 0x00000859 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction::Process(UnityEngine.InputSystem.InputInteractionContext&)
extern void SectorInteraction_Process_m15140D9DD8E6FA0EFF8C60EAD1B9577AE2E9A2EF (void);
// 0x0000085A System.Boolean UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction::IsValidDirection(UnityEngine.InputSystem.InputInteractionContext&)
extern void SectorInteraction_IsValidDirection_mE3A9B2DEF36F7368D0CC27D6E99A2329282E74AE (void);
// 0x0000085B UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction/Directions UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction::GetNearestDirection(UnityEngine.XR.Interaction.Toolkit.Inputs.Cardinal)
extern void SectorInteraction_GetNearestDirection_mD6BB363B927A3F1821B92E6A4589739A7A5E0DF2 (void);
// 0x0000085C System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction::Reset()
extern void SectorInteraction_Reset_mED795C773B8816F14A8F960DE5898B8F803AEEBB (void);
// 0x0000085D System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction::.cctor()
extern void SectorInteraction__cctor_mB817DC76635AE8218E6ED13B98FB02291CAAC91B (void);
// 0x0000085E System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction::Initialize()
extern void SectorInteraction_Initialize_mA42347DD5E0540724306D8DC659B47DAC898720B (void);
// 0x0000085F System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Interactions.SectorInteraction::.ctor()
extern void SectorInteraction__ctor_mFDBD65DC250F73D14ECC59790FC264DCF250B2D1 (void);
// 0x00000860 UnityEngine.Vector3 UnityEngine.XR.Interaction.Toolkit.Inputs.Composites.Vector3FallbackComposite::ReadValue(UnityEngine.InputSystem.InputBindingCompositeContext&)
extern void Vector3FallbackComposite_ReadValue_m8EFF75D486C86B0269C51437B1F14B6AF64912CB (void);
// 0x00000861 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Composites.Vector3FallbackComposite::Initialize()
extern void Vector3FallbackComposite_Initialize_m2F7E008EAA2DA0E9C5EF3BED00E3E6605B7EAA90 (void);
// 0x00000862 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Composites.Vector3FallbackComposite::.cctor()
extern void Vector3FallbackComposite__cctor_mECF0F5020FEE68767684752180139BD714A2C042 (void);
// 0x00000863 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Composites.Vector3FallbackComposite::.ctor()
extern void Vector3FallbackComposite__ctor_mA7FB7D94F8CC9364D035F53F339A16922A4828E5 (void);
// 0x00000864 UnityEngine.Quaternion UnityEngine.XR.Interaction.Toolkit.Inputs.Composites.QuaternionFallbackComposite::ReadValue(UnityEngine.InputSystem.InputBindingCompositeContext&)
extern void QuaternionFallbackComposite_ReadValue_mDA42E8F1708CA5FF6576762AA5AD9246CD57F79C (void);
// 0x00000865 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Composites.QuaternionFallbackComposite::Initialize()
extern void QuaternionFallbackComposite_Initialize_mDC5AE52C41780284AFBAEF0DC7DEA4E078E3DDB8 (void);
// 0x00000866 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Composites.QuaternionFallbackComposite::.cctor()
extern void QuaternionFallbackComposite__cctor_mA71EFAF4EB3C1694427F846696FD02D9FBF18E4D (void);
// 0x00000867 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Composites.QuaternionFallbackComposite::.ctor()
extern void QuaternionFallbackComposite__ctor_m3B8838F04A32156EAF3BC64828BA26423EFD7023 (void);
// 0x00000868 System.Void UnityEngine.XR.Interaction.Toolkit.Inputs.Composites.FallbackComposite`1::.ctor()
// 0x00000869 System.Int32 UnityEngine.XR.Interaction.Toolkit.Inputs.Composites.FallbackComposite`1/QuaternionCompositeComparer::Compare(UnityEngine.Quaternion,UnityEngine.Quaternion)
// 0x0000086A System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARAnnotationInteractable::.ctor()
extern void ARAnnotationInteractable__ctor_mBF4CBD033270A86CA19BF97BF0E551015DB218A3 (void);
// 0x0000086B System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARBaseGestureInteractable::.ctor()
extern void ARBaseGestureInteractable__ctor_m7D7701B9E98DDBEF1B8DE65810A1CB5DA566B630 (void);
// 0x0000086C System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARPlacementInteractable::.ctor()
extern void ARPlacementInteractable__ctor_m4EAD0538822BFBBDA0E901E8DC336C3A1F0FA525 (void);
// 0x0000086D System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARRotationInteractable::.ctor()
extern void ARRotationInteractable__ctor_mA72FB121E2FCBD152D18E022DEDF50CB220DF7E8 (void);
// 0x0000086E System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARScaleInteractable::.ctor()
extern void ARScaleInteractable__ctor_mAD014E0F828B208D2862EF42FF30AD80F73FA976 (void);
// 0x0000086F System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARSelectionInteractable::.ctor()
extern void ARSelectionInteractable__ctor_m01B8BFEA185D36AF5CF566282B1C186A2F6DF578 (void);
// 0x00000870 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARTranslationInteractable::.ctor()
extern void ARTranslationInteractable__ctor_m830DC66E9B418617FD0BC6844D1D4C332F8103A7 (void);
// 0x00000871 System.Void UnityEngine.XR.Interaction.Toolkit.AR.ARGestureInteractor::.ctor()
extern void ARGestureInteractor__ctor_mBDE13EF9AE00A65ABC1FF3E2726FDEE57FDFB7DD (void);
static Il2CppMethodPointer s_methodPointers[2161] = 
{
	CanSelectMultipleAttribute_get_allowMultiple_m8557815228A36EA8FB99C86FC9E7E0854C6568EB,
	CanSelectMultipleAttribute__ctor_m65A147231626A91AD8D6C66A80723EA6795FD1CF,
	ActionBasedController_get_positionAction_m754BEEC79908AD0B05827F441039715F3FF9F40A,
	ActionBasedController_set_positionAction_m1E352B658F8756D78E7BC0FED74834AE22EBBB29,
	ActionBasedController_get_rotationAction_m418204140263364B58561E704F5D97DF648E1B9A,
	ActionBasedController_set_rotationAction_mBD9206C9F2B73E15CD85A95C59FE348AE3914C2B,
	ActionBasedController_get_trackingStateAction_m7E3164EA6486DC1176AC983954B65B93805C9951,
	ActionBasedController_set_trackingStateAction_m377F19A22AA7DF326781E8E171E5391F79F5C5D8,
	ActionBasedController_get_selectAction_mB7F0F7A3FDA18D5753FFC539AB4D9A9451C78C3C,
	ActionBasedController_set_selectAction_mB210DAA27E0F045CEBDEEDA584B3EBC7BAC99246,
	ActionBasedController_get_selectActionValue_mC1D5E27D1EC30E1A31954815CF60DEE165C24704,
	ActionBasedController_set_selectActionValue_mB6B34DA26D1D3BCE3B4761F8F3E9630D1B7EF0F8,
	ActionBasedController_get_activateAction_mD97B355F98BF302391A562F2A661DB97CA72C845,
	ActionBasedController_set_activateAction_m62C67F63B2B8F3404F7B2909FD9D84A0101FD515,
	ActionBasedController_get_activateActionValue_mDC487447CFEBCBC00EC988EF0B88DC9F4AE23FE5,
	ActionBasedController_set_activateActionValue_mD3449A9AD114DFBE8A6413BCA0C44D946CEB64A9,
	ActionBasedController_get_uiPressAction_m289E3CE312A085905B6E5257933CC65971F39E6D,
	ActionBasedController_set_uiPressAction_mB2A8DC81210F16A6CA03E647CB0159B5F298F2AB,
	ActionBasedController_get_uiPressActionValue_mAA7085044BE279673714B48D92937AE5DBF96757,
	ActionBasedController_set_uiPressActionValue_m357BB1F6FE310478FCBFB670421AFFF368864DCD,
	ActionBasedController_get_hapticDeviceAction_m673A63E53DBBD8F2DF95E73F656DAA5889C3C016,
	ActionBasedController_set_hapticDeviceAction_m0EAD0A6F262DEB2F94203889133180E40533B524,
	ActionBasedController_get_rotateAnchorAction_m585FB8A85651CB53058D262F356FFDB555C0434D,
	ActionBasedController_set_rotateAnchorAction_mABD5D53EFC70CDDC035E88760CB12E7A34DB0AA3,
	ActionBasedController_get_translateAnchorAction_m43AB9FEF504B78C5397B53170D59FF8B3F28D688,
	ActionBasedController_set_translateAnchorAction_m56A78271FB3AE8400BC0417F24DBCEB9007C9626,
	ActionBasedController_OnEnable_mA6D2EAC1A7A285B0AA3A5DF7635A333127931AEC,
	ActionBasedController_OnDisable_m1FF4C941BD3FC5F660A32CDDC627F65EA0F24BC1,
	ActionBasedController_UpdateTrackingInput_m7E685CC1E2820C31654BAF8B78059B576BF96C0A,
	ActionBasedController_UpdateInput_m50BC27AA49CD78DA5BBABDA13B7B14885A78351E,
	ActionBasedController_IsPressed_m4BC91FBF17261111A6546341A6ABFCC656473E49,
	ActionBasedController_ReadValue_mA23FF5B4D8BA41D21380CE793203BB92F36B1C7C,
	ActionBasedController_SendHapticImpulse_mEEAB1C22F0D5D99C809709F1983D16B05E15A182,
	ActionBasedController_EnableAllDirectActions_m0C45E546471C3183F092CCB85D51C009E6D6A803,
	ActionBasedController_DisableAllDirectActions_mADDBCFCAC755FAC913EFDDF983FC1D7266FEF253,
	ActionBasedController_SetInputActionProperty_m999355F89D6CDA8327F99C4F721F6BE5104C5313,
	ActionBasedController_IsDisabledReferenceAction_m4153A76E0C89C388E5247ED98AB95E98C6855B51,
	ActionBasedController_get_buttonPressPoint_mC0CF59C4782CC5610D006923A7290BEB7C1FB7EB,
	ActionBasedController_set_buttonPressPoint_m0BCF0E785363E6F25CA2D6102593A08FDC188845,
	ActionBasedController__ctor_m601BEF4C957FC4FD1641271BB7D7DA5542419DE6,
	XRBaseController_get_updateTrackingType_m9F99E1E98DB2D0E33A8CF4D83D8FC0FBA112216D,
	XRBaseController_set_updateTrackingType_mE5401B9A9B1A2D46C588C0FC8EAC7EABA89A3F2B,
	XRBaseController_get_enableInputTracking_mCB03DA4E1BF7E6E77A7BC359A166E7FD09CDD0F5,
	XRBaseController_set_enableInputTracking_m19387852D9C6A0869AA04A4BD6A4E5F9F5111858,
	XRBaseController_get_enableInputActions_m4E285A2F619049FF60318453228523C193C9E8CE,
	XRBaseController_set_enableInputActions_m74E6BEA651230890AF81718CE1E25FF030592BFA,
	XRBaseController_get_modelPrefab_m8F3104181B37688F66D3C71F6AE871F1E8576A58,
	XRBaseController_set_modelPrefab_m78555A9D2D46FFDF2303E9927F725686BD8D6BAC,
	XRBaseController_get_modelParent_m759C95F1FA9D11AF1A380B9F16438A41DA409AEF,
	XRBaseController_set_modelParent_m5CA5FB47E54C33F02BCEB1501298B7DB22589112,
	XRBaseController_get_model_m8E9DD91990CD87A6B4AF13DB6C3EA06EB5A3A5C0,
	XRBaseController_set_model_mEECED3A71604C4CC57B821D6311E8C229EDD8C5D,
	XRBaseController_get_animateModel_m18E1D1CC94513D87FC19213F418BFD5E8D052E5A,
	XRBaseController_set_animateModel_m38D1A893585B1C56FE91E1076BBDEDEF0705BABB,
	XRBaseController_get_modelSelectTransition_mD242ED880A0434C2D5B308E0FDFDC36539D006DA,
	XRBaseController_set_modelSelectTransition_m2FE46551D42B6EA02B416551BD40548733A274D0,
	XRBaseController_get_modelDeSelectTransition_mB5029F76300D9665584B3C2367F271A8AF985E40,
	XRBaseController_set_modelDeSelectTransition_m03973FE1F5AC9A5D8C498262251D6985F40B71D5,
	XRBaseController_get_hideControllerModel_m49B1EE19937162AA4F16AC81832210BD248A5B1A,
	XRBaseController_set_hideControllerModel_mC89F417807EF5C8E4D787AE69746FF81B1C3EF3A,
	XRBaseController_get_selectInteractionState_m607E98EBB0AA181459CF4165499F84BEFC49B53A,
	XRBaseController_get_activateInteractionState_m93E7F1F64049D215C2CCDB11C0567D07C349DC41,
	XRBaseController_get_uiPressInteractionState_mB07F0309336EA4A99D5FD150A6FD76A7F6FA417F,
	XRBaseController_get_currentControllerState_mA9E97CEA72CB7A87F1A5D78A6F214A4879F43F6F,
	XRBaseController_set_currentControllerState_mDD2F323DD62343478F9B924018187AB5CF3AFE7D,
	XRBaseController_Awake_m969CBFCD5A52E263BFD8D37F85600F2BBF0D8C59,
	XRBaseController_OnEnable_mF366667E8E73F4917E9E08DE2C1431E3FB1194B4,
	XRBaseController_OnDisable_m15F25B1E176A7DEE509BBFE7F360EBE7E3338167,
	XRBaseController_Update_m1954F912B6A6C56E2BB39D582EDEEB80DF1DE7F4,
	XRBaseController_SetupModel_mA383D4BFA4B75F134FB3FB7A584F159803327D52,
	XRBaseController_SetupControllerState_mAB522AB27E4F8ED391B88158F498DF62BD8C9C74,
	XRBaseController_GetModelPrefab_m7E27A0C2202581E1C33524E9E8BD9CA7763545A4,
	XRBaseController_UpdateController_mD419ABCB5D7D017EAFC69E08AEE961B1DF708222,
	XRBaseController_OnBeforeRender_mA8D54A70D64EFD4DE2EA3F61B3F08BAE32FE2529,
	XRBaseController_ApplyControllerState_m812F8B210953E22C782D0EF934FF734E3FBEF1D9,
	XRBaseController_UpdateTrackingInput_mCC0333C7F9A8781D9CA01FF18E2314D6E7F1282F,
	XRBaseController_UpdateInput_m4132D572C76473379C969E65AC2AD05CE34AA8C4,
	XRBaseController_UpdateControllerModelAnimation_m510A87EA3FED6C9DE4CF132FE5819DBCC9B61666,
	XRBaseController_SendHapticImpulse_m7DBFA2261E7FCEA7930852ACE307C77A691528A1,
	XRBaseController_GetControllerState_m4E08576FDD9FAB931643EE136053BCECAD1C9F0A,
	XRBaseController_SetControllerState_mD0E3F48F2F9337A923E61125272D10043B72A463,
	XRBaseController_get_modelTransform_m2B451BBC8FBF5A268C9A68D1B74B9C5F904DD976,
	XRBaseController_set_modelTransform_m00F2D5ED969A73D258AC5378B18B7A56C8163A7E,
	XRBaseController_get_anchorControlDeadzone_m554D8D27AB3CCB197125C4F102959286DBFF231E,
	XRBaseController_set_anchorControlDeadzone_m68BDD2E6B5959DD97FEDF6E033DF52AE532B2233,
	XRBaseController_get_anchorControlOffAxisDeadzone_mE5D5AD2AD1F00DCF9B04FFFFC7C83492B386C3A3,
	XRBaseController_set_anchorControlOffAxisDeadzone_mFCBD92C990571310E6ED383E782B92B869604B24,
	XRBaseController__ctor_mAB469A8A2B478CC37F1BA0BEE00D7ED28C1CAA30,
	XRController_get_controllerNode_m84357B5F8DB7E0E61C12C8E89BC0F8CEBE1B0ED4,
	XRController_set_controllerNode_mDB11A0BBD405A0D024AB926F6A50861D389A041F,
	XRController_get_selectUsage_mC9C45D97DA3FFD0DC5F43E5A5D5EAD8722FF7DCD,
	XRController_set_selectUsage_m233DAAF98F5F3C531B58B672A6490C2A9C88FD84,
	XRController_get_activateUsage_m8937EBF3E85592AFDF8766495B307364628CE0D9,
	XRController_set_activateUsage_mEE163A312869B64527AC02F402AB892D16B85A5E,
	XRController_get_uiPressUsage_m20022FE68843065176BCB5351BE67A9C1F5AACC7,
	XRController_set_uiPressUsage_m949C86B998663FDAC3F9240A0D5B0B58166AF7F8,
	XRController_get_axisToPressThreshold_m7D44CA04CC3C10786D7B0EBA8D648CD1284B3B06,
	XRController_set_axisToPressThreshold_m85BAAE24786C4715C2FE76D4826275E2A573FBF2,
	XRController_get_rotateObjectLeft_m4445D21E8199AEEF3260128685D574EAABBE56F3,
	XRController_set_rotateObjectLeft_m7A196512A1AC2E46B1F42144E63BCE8689B26EED,
	XRController_get_rotateObjectRight_mE8E05BF5562681EEF2C644361981E49AC3F21B72,
	XRController_set_rotateObjectRight_mE04DC79D754449C284B945F82366F65089852279,
	XRController_get_moveObjectIn_mE1BC59DD9456484BFC945802712B1AAF4C471FD6,
	XRController_set_moveObjectIn_m81CCDBB1F3518D5560A426B33CA415F402106875,
	XRController_get_moveObjectOut_m5B470BCB70F62E72DEEBAA4ED362DAC82ACA8B81,
	XRController_set_moveObjectOut_m7C4D09527C06F337AEEC1BDBBB25DA561A354AC6,
	XRController_get_poseProvider_mA193852B0920865CDE7C09390C45F35F5AA7D0F9,
	XRController_set_poseProvider_mC33BCBD2433BADEE7A111854FAD953AD13060515,
	XRController_get_inputDevice_m584AA43BBBC4CD0FAD047217DDB64DCD35281389,
	XRController_UpdateTrackingInput_m8990DE6A19F455C9069E94FE1269BA8FF0E0B1C3,
	XRController_UpdateInput_m5A3EA9E142CF530241D40B8C2BCC9FE25AD81CE2,
	XRController_IsPressed_mB6EFB2C76C05ABE3C3714249935F74C059C07452,
	XRController_ReadValue_mF1FB601A4147C4FF73F0C43F4684429B081B9CE9,
	XRController_SendHapticImpulse_m0E806AA5D00ACD79FB676FD683C078154D53C2E7,
	XRController__ctor_mFD260BA76E7F67E04FD4BB87FF0503D56B711901,
	XRControllerRecorder_get_playOnStart_m0C823A5F4D18A82823F2C79719E6601E6F9DC49C,
	XRControllerRecorder_set_playOnStart_m5DF305E21C59E009B87D156A611A5C91FB8F976A,
	XRControllerRecorder_get_recording_m227AE5B7CCEB3345DDBACF67A9EEE84CFD092443,
	XRControllerRecorder_set_recording_mC5826AC9954858BF14E8AF98A358864AE8635623,
	XRControllerRecorder_get_xrController_m025A4175322862B5FDA4D1F03256DA247A490657,
	XRControllerRecorder_set_xrController_mAAEB712272CC24019A7773E0A552EA3564C77A82,
	XRControllerRecorder_get_isRecording_m8CA5F5A62CB1285F3F9974829D992176F21AD956,
	XRControllerRecorder_set_isRecording_m40043115D1978067B1795B259119EA846AAD28D6,
	XRControllerRecorder_get_isPlaying_m2D33C6F89A6AB582F6FC5B8C4F9666E703F0A8FB,
	XRControllerRecorder_set_isPlaying_m80CCEA22180D5AC8C51BB30360B10BA88B622110,
	XRControllerRecorder_get_currentTime_mE4A76107CD1AAB706A5FE618B23D18FD8E2DEDB6,
	XRControllerRecorder_get_duration_m0A4C7407B5BC633DF8DF24BED50A263838219B5F,
	XRControllerRecorder_get_recordingStartTime_m11FF7EB2618B66213B259CB000F6282ED8A24C5D,
	XRControllerRecorder_set_recordingStartTime_mE03290CF98AB070C1705EFF8B1E13867D892501C,
	XRControllerRecorder_Awake_m06542BF05267DC192672EFD27D48C1FFD898D273,
	XRControllerRecorder_Update_m6E884E4CB3B7E3EE972D0E64044C9B4AA2BE409C,
	XRControllerRecorder_OnDestroy_m9B30F6533FD2B2D1EB26AED12CECAA5444108780,
	XRControllerRecorder_ResetPlayback_mC5BAE715DEDFCF3C3A969120D3CBC9C855DAB427,
	XRControllerRecorder_UpdatePlaybackTime_mE78B41A2B3BD2F26A7FDD8CA936E1AD3C8763605,
	XRControllerRecorder_GetControllerState_mE1E333D3C4C2B941326B34B15840448CBEC47DAC,
	XRControllerRecorder__ctor_mF15646BC8E7B61EB36596FF3919DBFB59DE3E524,
	XRControllerRecording_get_frames_m006772DE1B30E70E1CF387541325D606A522ADF7,
	XRControllerRecording_get_duration_mC79AA5413F875C410E85E4EB41B61481BD3A7DB1,
	XRControllerRecording_UnityEngine_ISerializationCallbackReceiver_OnBeforeSerialize_m870556D9C38001EA0B00217F8C5F3F1B78B9053B,
	XRControllerRecording_UnityEngine_ISerializationCallbackReceiver_OnAfterDeserialize_m64A30D5EDC2A6884764202CF81A92623D8A39F50,
	XRControllerRecording_AddRecordingFrame_mCE544FC7E7DEF6934204D64455922C9428E2C1C3,
	XRControllerRecording_AddRecordingFrameNonAlloc_m701C354DBBE731AFF29167FE5EFA180B58729300,
	XRControllerRecording_InitRecording_m47C1F6C9469FF38363164ACDD851F0BA9B5359AE,
	XRControllerRecording_SaveRecording_mAE299C7A3EB90C171CB33054E739D10643000DCC,
	XRControllerRecording_AddRecordingFrame_m6AF90EC7798B6BC3323F01D69F8D7D44F28F8E9C,
	XRControllerRecording__ctor_m97867E991DC4EEE6E2ADFA828EEAD91AD7FE2B96,
	InteractionState_get_value_mD1E8048CF73C1EBD045C1F2598CB8D4300291F89,
	InteractionState_set_value_m99DCAF279B4C23C1D2690616B6D8E5C9D9CA46BD,
	InteractionState_get_active_m1E069A7D42F19F587B2F384A8EFB9A3D6EDE8E31,
	InteractionState_set_active_mA48D0212ED136A9EDB38879A4B1D3A4DB3DB78F3,
	InteractionState_get_activatedThisFrame_m512E1A559B40E19753A0D9F666B3BB44C8BCC6DA,
	InteractionState_set_activatedThisFrame_mEF19740F5C82F14B507A05C0CD746BE6E0B703F3,
	InteractionState_get_deactivatedThisFrame_m9C1D440D21737F44E68D853F0934B0102A87470F,
	InteractionState_set_deactivatedThisFrame_mA0DCE61AC5D7E1124AA742288C6543419984D786,
	InteractionState_SetFrameState_m7DF731F357512FDD2952CCEB5F2BDCA64FDE4535,
	InteractionState_SetFrameState_mFD251DE03E6724F0D133CC5D16543BC560D54674,
	InteractionState_SetFrameDependent_mA78B0D0627754F8D1B5405695155862AB8EA9B0B,
	InteractionState_ResetFrameDependent_mE6F39B9BB60334F9652E917EC843F188E54F4F5F,
	InteractionState_get_deActivatedThisFrame_mFD3F769CA4FC43468E7736C83142E27C96252B70,
	InteractionState_set_deActivatedThisFrame_m46FBAA1B24DF5B3E7C3865DBBBB500A9D3B22E6F,
	InteractionState_Reset_m3D7F3D026CC49E00BD95858EE7AE95A0B8923B2F,
	XRControllerState__ctor_mBF6971311B10D4A0D6F8EBE3FED5F51CE342469E,
	XRControllerState__ctor_m807A8F212CB98DEC9EAB4A04AC25953D0A3298C6,
	XRControllerState__ctor_m55DAF7C31D41E5FE77C74DCE9F162B8FECE32535,
	XRControllerState__ctor_mD257D8EF23D4A9C190DA834DFD6461C206D77893,
	XRControllerState__ctor_mE3A66949F7E69179EC8FE9D642E8A06C3C475F0D,
	XRControllerState_ResetFrameDependentStates_m15DFF7131ACB5EF2CA0067EBEE0322C2A7594E5C,
	XRControllerState_ToString_m994EFC44E2FDFEA49883AB914489166E2C75D103,
	XRControllerState_get_poseDataFlags_mB1583388E8CEDF58B2109D3DC1684E26FC0B2371,
	XRControllerState_set_poseDataFlags_m52A1E2271B7F9D409501D6961A547484BBF6F916,
	XRControllerState__ctor_mEC6732F822B7072790CD4DD0BFA45C1EDB966BE1,
	XRControllerState_ResetInputs_m1F0BC0DC4AB6908D37DB1C0612334C401AB472C1,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	XRHoverInteractableExtensions_GetOldestInteractorHovering_m78EDB4DFD4C3FB1C7B6C2963F17FA38EB2E85BDA,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	XRSelectInteractableExtensions_GetOldestInteractorSelecting_m0F5900227EA241C238F920E82466EBF2C58E2353,
	XRTintInteractableVisual_get_tintColor_m7145A02A74CA838BA4E26C27D3BD19FAFE9A97DD,
	XRTintInteractableVisual_set_tintColor_m9176AD56D30555DEA395383ACB8E3C414E31B5B6,
	XRTintInteractableVisual_get_tintOnHover_mA5876B3A6E8C2A963DDBD277990EA2BC29C68005,
	XRTintInteractableVisual_set_tintOnHover_m1C4F777A50BCE43EBF27E15317D136A113A310FF,
	XRTintInteractableVisual_get_tintOnSelection_m3109785F8A57BDDDB0F142DD3EA0D6175EADBCF6,
	XRTintInteractableVisual_set_tintOnSelection_mF5A91D7A962B054C86582BDA6DEAB386653FD26F,
	XRTintInteractableVisual_get_tintRenderers_mD935957D5B0A06D2655ED25C11EF48B2C8AE1660,
	XRTintInteractableVisual_set_tintRenderers_m344D4CC07935107654296040A65B34319A2771B7,
	XRTintInteractableVisual_Awake_mDB09588103934C4AFDBC7B65CA067081474554C4,
	XRTintInteractableVisual_OnDestroy_m93FC361530B8D707FEC9EE4A7CFCB65823CE1354,
	XRTintInteractableVisual_SetTint_mD984003D236126213968A3D3D12D6F512D3D7965,
	XRTintInteractableVisual_GetEmissionEnabled_mBF0C94BD63AA1FD8F49D7E62F8DDFEB9946BF060,
	XRTintInteractableVisual_OnFirstHoverEntered_mA73FE7C7D9F0ACCD8D947D03D1198A6532B55A4E,
	XRTintInteractableVisual_OnLastHoverExited_mC9165137EBEE7376A08B0A52DB79E49684D67CC2,
	XRTintInteractableVisual_OnFirstSelectEntered_mBB5A687D94FF00306D27F567BE96E3B1B0A2947F,
	XRTintInteractableVisual_OnLastSelectExited_mFB4CF802302907392AEF24F321617A23EC9D5464,
	XRTintInteractableVisual__ctor_m8B9A445C3C83B1EA59E4DE857976EEDE5F7362B5,
	XRTintInteractableVisual__cctor_mABB60E7166727237AC7B7995178BBD8233D6BB2C,
	ShaderPropertyLookup__cctor_m7734229F68E5BB46CACB9D0122197FFD341A734C,
	XRBaseInteractable_add_registered_m09346541B23553255EBD6BB26163560597EA8B7E,
	XRBaseInteractable_remove_registered_mE2FE41CD4B24E3ACD9B2F85E28CAAF6B7BEF8439,
	XRBaseInteractable_add_unregistered_m76DE4D9CF32C801E4C78BE10C2B5FE00969ED072,
	XRBaseInteractable_remove_unregistered_mC96DEF6108477652E9EFF7D09BB8BAA69893D00D,
	XRBaseInteractable_get_interactionManager_m1BF21BCF113132237CB3D85E8DBD6DA30CE1D78E,
	XRBaseInteractable_set_interactionManager_mCCFE5F459938E450DC09E1DAFA066F225658A996,
	XRBaseInteractable_get_colliders_m7E5D104638AC4B5E5C77D40094AA52B9ABEB32FB,
	XRBaseInteractable_get_interactionLayers_mEC1D65D0D0A1AF16FD395579E18942DB4D421363,
	XRBaseInteractable_set_interactionLayers_mC6A6EAEF851239E9090EBE58388B3BB263517830,
	XRBaseInteractable_get_selectMode_m21EADCACAC064B501A96C9CD7CAA1440B7C06B30,
	XRBaseInteractable_set_selectMode_m44F4C7BA37A6FF9A9F46A6B8494173089CD1D132,
	XRBaseInteractable_get_customReticle_mA9B2BFF7868C4730592B791EC85496C34976590A,
	XRBaseInteractable_set_customReticle_m1620568983D26FCAE38E32CD2DABF946E9DB3EF2,
	XRBaseInteractable_get_firstHoverEntered_m45486072B947B2E93C0F330FCB737647A168CCA3,
	XRBaseInteractable_set_firstHoverEntered_m3EBADB826862699D8645E43A325248C2C1B431D2,
	XRBaseInteractable_get_lastHoverExited_mAED97F9ECA09E7A8E2B3D380BB4FB68F64E8B7D4,
	XRBaseInteractable_set_lastHoverExited_mA4F9C29CBE698E53210844755E640FFC07E4FB5F,
	XRBaseInteractable_get_hoverEntered_m49384274F14DF80AC8FEFC1D214B7ACD41C67FB5,
	XRBaseInteractable_set_hoverEntered_m3B4406A5E1BB6A1E8A0A3613D28BDA0FE6A0B967,
	XRBaseInteractable_get_hoverExited_m6A0E55603A368A85D086A00AEFD032A434CF6162,
	XRBaseInteractable_set_hoverExited_mF9EA4EAE648FE9D90E6C560C827F0E6038AEAF83,
	XRBaseInteractable_get_firstSelectEntered_m8BC5CDD83B7BCC0E1F0F1ADCA3225C8170DED77D,
	XRBaseInteractable_set_firstSelectEntered_m2E0ABC1E23403073B3FB8491325D6FD7851F9EDC,
	XRBaseInteractable_get_lastSelectExited_m513D028F328E1A7D31A7D6D2889D295553AC4504,
	XRBaseInteractable_set_lastSelectExited_m431E670D452B60AE0F865A6D9A8629008496A4BE,
	XRBaseInteractable_get_selectEntered_m1E5439CAE1D95FDB7D60F14D919E739435F2C341,
	XRBaseInteractable_set_selectEntered_m1306AE4FA060099D107FCA958522CED90E38BF00,
	XRBaseInteractable_get_selectExited_m35974CB2AD2FB38B4B093DC75D2917A1D321AFA6,
	XRBaseInteractable_set_selectExited_m2DDAC89B52DCC5A862C066C035C91E7601C0FB15,
	XRBaseInteractable_get_activated_mA303C37F9F4F7C8F5E8830DD0A60735A1FD7A71F,
	XRBaseInteractable_set_activated_mD2514AF9C22F727130054BF404A8B45F86E185B8,
	XRBaseInteractable_get_deactivated_m9A80B739218EFA7D495859A22B3010D6EA5552D5,
	XRBaseInteractable_set_deactivated_mC6C62FF411F15BB078D13656120B2A2ADACE11C0,
	XRBaseInteractable_get_interactorsHovering_m59A8081C49E99C1C9D50C84BF1438EDE2B823295,
	XRBaseInteractable_get_isHovered_m365DB744ECBAB53AD4A489F6EBA5360DF993FB1E,
	XRBaseInteractable_get_interactorsSelecting_m4B5A53704757881608DB333C792979DDE0EF3473,
	XRBaseInteractable_get_firstInteractorSelecting_m4DB61C389039768C7BB8B4A9C46974D7C7CEF015,
	XRBaseInteractable_set_firstInteractorSelecting_m63956885FE6D8E0C7788252DBDA2B59694741E76,
	XRBaseInteractable_get_isSelected_m48487E7F2E3E1EDB6D9B6985FF146020F628B3CE,
	XRBaseInteractable_Reset_m1CFAA75E8F77AB5E11B2DE07BD3969BEAA2B8A0D,
	XRBaseInteractable_Awake_m0F05BB9C7C9315AD7A6FA1654A50612AFB5D8EA0,
	XRBaseInteractable_OnEnable_m7BE7345371D6ED1B91C5EC90CDF8F34CE11E3366,
	XRBaseInteractable_OnDisable_mB02958BFFAFF6C61A9FABE1D80056C3ABDCAB243,
	XRBaseInteractable_OnDestroy_mEB434BB14A20C725528F9A1A0F04E70DED3D2B4F,
	XRBaseInteractable_FindCreateInteractionManager_m7D14F62C6263BF91A05088C5A4389F3AC79A1AA7,
	XRBaseInteractable_RegisterWithInteractionManager_m811463136B69D370F00869171BE8E55D625DA2D8,
	XRBaseInteractable_UnregisterWithInteractionManager_mF1741B78B8865667C57556AB492ACE8CEF13017D,
	XRBaseInteractable_GetAttachTransform_m49E682DC33A9B633B38300722D3A1F539B3AE8FE,
	XRBaseInteractable_GetAttachPoseOnSelect_m4443BA2DC8FC267988EC9ABADC3A9EA19465CB51,
	XRBaseInteractable_GetLocalAttachPoseOnSelect_mFE2982B558239FAB820826B9DD44F73B4A5AEA00,
	XRBaseInteractable_GetDistanceSqrToInteractor_m52F94F37A4FD3F5ECB7A6CB8A10BCD0F5A7B7128,
	XRBaseInteractable_IsHoverableBy_mA746CF4F19A39315495C004ED35EF6AF75AA8429,
	XRBaseInteractable_IsSelectableBy_mB736F5FFEBCD5B29610E94980C7E8D2B4058A9CB,
	XRBaseInteractable_AttachCustomReticle_m5209EEF1D09AA44CB21A97F65FD84861C6CE0719,
	XRBaseInteractable_RemoveCustomReticle_m3773C9455009E0875257C3EFA4B1578855D564B4,
	XRBaseInteractable_CaptureAttachPose_m1E96A11AE3119F0183F1A34117A52DEB0EC12F49,
	XRBaseInteractable_ProcessInteractable_mD5D51C6B4F6673EE9380C4EA707DA67F7CF8B0F2,
	XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRInteractable_OnRegistered_mC957784F3672267038E0CE90F5A3DCE0739DB63F,
	XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRInteractable_OnUnregistered_m317A9269A7185732331ED6205C97BC0698E1B431,
	XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRActivateInteractable_OnActivated_m77041A7F42D5CBAD509C60285E84CF0B45CBA183,
	XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRActivateInteractable_OnDeactivated_mA6117AC7A9583AEB7E561093C734AACCE04FBC23,
	XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRHoverInteractable_IsHoverableBy_m71F62341E08547B200BF655868174572BECE047C,
	XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRHoverInteractable_OnHoverEntering_m542D7F2636927C72158456381632E25DB7034C59,
	XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRHoverInteractable_OnHoverEntered_m56B5D09532D66BED3EB655F7989BA3434C5D57AF,
	XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRHoverInteractable_OnHoverExiting_m8D6E79B614A6E1901D6D7C5578730501CDBAC064,
	XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRHoverInteractable_OnHoverExited_m3C98A50682BB75E4A991E6F56B7F99A07270949A,
	XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRSelectInteractable_IsSelectableBy_m7E9ABF5FF8039EB88287F833495D86930BBA3CF3,
	XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRSelectInteractable_OnSelectEntering_m366007321636CDD4FA2266137A1B1F5E822717D4,
	XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRSelectInteractable_OnSelectEntered_m02789F82FAD64B8DCBB7115AC76E5D39D75B9682,
	XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRSelectInteractable_OnSelectExiting_mC3E2FD987AEF56E2859EFC3AAC4609D7F18ABF22,
	XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRSelectInteractable_OnSelectExited_m5CF609325B7E322A004AA92D9232C1AB9FD0F945,
	XRBaseInteractable_OnRegistered_mA848DE6637488E5C5CBB998C7D1B7187A197081E,
	XRBaseInteractable_OnUnregistered_m0F4657C75F7D6BD9E3503E6CB04AD4235A7C8733,
	XRBaseInteractable_OnHoverEntering_m91511B5EC9D4C94BF629F4CE9C48165B919B89AD,
	XRBaseInteractable_OnHoverEntered_m640C05A966C7FBCFBBE06A528FD67B3E4417D8B9,
	XRBaseInteractable_OnHoverExiting_m2CB16CAD51B6CE0C92C4378C9ACB5AE628B45260,
	XRBaseInteractable_OnHoverExited_m151F89528B26490399D2A7A3F468DD021D6DD295,
	XRBaseInteractable_OnSelectEntering_mA92C356B0CBA88075ED772C00D6D7B53FED2AA93,
	XRBaseInteractable_OnSelectEntered_m548EC86DEEF771E952DFC75BAE8EA5C27E441C5C,
	XRBaseInteractable_OnSelectExiting_m4F97E28A978DC4A5B7B843CA0FDAAFA9640F72F3,
	XRBaseInteractable_OnSelectExited_m0D5AEB82DE37B8584A97A262468AF59B70A5568C,
	XRBaseInteractable_OnActivated_mF584BF76F2FE64DB21A707C4FDBBEA7885D6524C,
	XRBaseInteractable_OnDeactivated_m3A86068F620BFE049FCF5D0712CDC3A2819F1577,
	XRBaseInteractable_get_interactionLayerMask_m88A182317E350501A4A982352B416F61E4C42D71,
	XRBaseInteractable_set_interactionLayerMask_m9DA83A873E341FD33AF6889A7DDFD95FAE03D3D1,
	XRBaseInteractable_get_onFirstHoverEntered_m8BB778DBC5BEF3D02A69D508153913D7B263DAFF,
	XRBaseInteractable_set_onFirstHoverEntered_mBC020593B115AA187F6CF97F1997BB55FC7F6BA8,
	XRBaseInteractable_get_onLastHoverExited_m8C95DAD155571E0196F07CD6DAD18E9A3D73900A,
	XRBaseInteractable_set_onLastHoverExited_mF9ABD3DB3A133C39D0271D726EB925541D695EAA,
	XRBaseInteractable_get_onHoverEntered_mFF277C048C0AC263D36E6028C09BD6A096816EA5,
	XRBaseInteractable_set_onHoverEntered_m7D3FA0366F1B3063C1078D5D6CB8CCF4009FA839,
	XRBaseInteractable_get_onHoverExited_m7AFF158F1499360FBF4334F07FB2394CF7D0C67A,
	XRBaseInteractable_set_onHoverExited_m190E015CDAF3D90EDA68CC35A182D8818340B439,
	XRBaseInteractable_get_onSelectEntered_m3AF1E23061186454C8CD5233921F4FC6C3780A37,
	XRBaseInteractable_set_onSelectEntered_mC6060A43303B6BED1FE9083E85BED946EB23FABE,
	XRBaseInteractable_get_onSelectExited_m8024BC6BA704E0465A0DA3BAE263C18CEB74F142,
	XRBaseInteractable_set_onSelectExited_m792ADF3DA24E5F2E77D1B091D60DDCAF75C7A099,
	XRBaseInteractable_get_onSelectCanceled_mEEF8B7DC54AACFDEE8592736105501B5B5DB9AE4,
	XRBaseInteractable_set_onSelectCanceled_m06133B21C01B4B19CB4D8D8FCA893E6286152F26,
	XRBaseInteractable_get_onActivate_m1D3C7DF34FE13FCCB1E912EFB16C418C14825CE5,
	XRBaseInteractable_set_onActivate_m1D7B1CD39B70B34EEC637AD5EEB6368500440285,
	XRBaseInteractable_get_onDeactivate_m1847E4D28A1DCD913BB256DAF5E0AD7941C1519C,
	XRBaseInteractable_set_onDeactivate_m63B2A481DFC3B6F21F27143B978896123698AB6D,
	XRBaseInteractable_get_onFirstHoverEnter_mA09216C44D0C76CAB339483EAAD4D02A27BED0DC,
	XRBaseInteractable_get_onHoverEnter_m01071D5812EA0B89F558C77BA43FAFDEB51BACD9,
	XRBaseInteractable_get_onHoverExit_m8F78D5AFD6F310F4E1BFE4E6C9C6C8FC01701960,
	XRBaseInteractable_get_onLastHoverExit_mCFC12B17916FCC5FF167E9A730AF3B85D66B17C1,
	XRBaseInteractable_get_onSelectEnter_m1FD30C7BD9A91AD63C3645CCFD3C6DE3CFA59E99,
	XRBaseInteractable_get_onSelectExit_m7CE4A2E3F926261A864CEB8C565046345A687C83,
	XRBaseInteractable_get_onSelectCancel_m21F0114EFE5248D836F9E91D72C133FF220917D8,
	XRBaseInteractable_OnHoverEntering_mC7AE47E988E9FDE228CF21D37CBFA01B8D0D2647,
	XRBaseInteractable_OnHoverEntered_mDEBCCB9316DD58BE33D7BE24474BE879C7874AB4,
	XRBaseInteractable_OnHoverExiting_m50CC99BF19E96C3CAFDAB799A7A4A157899FB2F6,
	XRBaseInteractable_OnHoverExited_m9804823A7EC919D6E8AF56EA07F2C9D38A75DF1E,
	XRBaseInteractable_OnSelectEntering_m8F7D6BCD011845DB205C19A5EF2888BC2498AD3C,
	XRBaseInteractable_OnSelectEntered_mFBD06824A89594F0777D691A5A62775C1F908F2D,
	XRBaseInteractable_OnSelectExiting_m66D3F2D1F00CCA02FFD0D023BE7AD9D0CA9057AA,
	XRBaseInteractable_OnSelectExited_mE701B8C24D777780E087CBC1BA70DEA5E0C9811C,
	XRBaseInteractable_OnSelectCanceling_m480CD53FAD683DF9A1CAAED37DEF2C715EAA36CA,
	XRBaseInteractable_OnSelectCanceled_m2F45D168F919DB89F4B099F769640D5950080C42,
	XRBaseInteractable_OnActivate_mE1DEF5C544A8DDA4CDC2F8791A2F3A45E419BF44,
	XRBaseInteractable_OnDeactivate_mB2EAE293AC23EE6D075E6FCBCA1C4C619B00459B,
	XRBaseInteractable_GetDistanceSqrToInteractor_m0D4E455457E95DDDB45146E260EDA9C3A56D5BEF,
	XRBaseInteractable_AttachCustomReticle_m350001A881BA032E9D9B7D6BA5986EE59E5F1DD2,
	XRBaseInteractable_RemoveCustomReticle_m332B9551BADA33D8E2BCF9A1A52F97854E30A762,
	XRBaseInteractable_get_hoveringInteractors_mE0B8E9F9A3CFC8FE238AF4148B9B467DEA95F7C7,
	XRBaseInteractable_get_selectingInteractor_mDA5536E167016B048166B2DC5061AE3F752B115A,
	XRBaseInteractable_set_selectingInteractor_mDDD4EEC6E146FFDAAB2727A52EA9B99660665CEB,
	XRBaseInteractable_IsHoverableBy_m7F71CC4449838B94CFC6E7C3834FA0613B0B331F,
	XRBaseInteractable_IsSelectableBy_mB86D990CC7B0D23A8FADA53DF1DF05A2A0905B56,
	XRBaseInteractable__ctor_m0B36974579D0C9F2799C4C5DE77B136C291247F4,
	XRBaseInteractable_UnityEngine_XR_Interaction_Toolkit_IXRInteractable_get_transform_m6A2A880913D12F5EC5E0C9A1D2E34D3517687F44,
	XRGrabInteractable_get_attachTransform_m30CDBF31508E618FE793B016216943805111DA12,
	XRGrabInteractable_set_attachTransform_mB9E32067852B3E793C78488AFF113E217D8DA148,
	XRGrabInteractable_get_attachEaseInTime_mEC2614EA89075DA4BE757331DFAE3B022991B71C,
	XRGrabInteractable_set_attachEaseInTime_mBF3660E565944E6282C82A0E37E5735294A7A122,
	XRGrabInteractable_get_movementType_m5BEBCC2DE7D252FF0829FA0213B9F615A06B3CD8,
	XRGrabInteractable_set_movementType_m2F7742535D1427EAAFF3B18C3AA2871B730C07FC,
	XRGrabInteractable_get_velocityDamping_mE46219AFCC01851337A04ED9D87ECE992E059A86,
	XRGrabInteractable_set_velocityDamping_m08C1E8BC409C1333A2CED17BAAEFED45A64044E5,
	XRGrabInteractable_get_velocityScale_m788546BF2A3482AF4416A827F713058344B58A13,
	XRGrabInteractable_set_velocityScale_m948FA5A69546C471440956A464E6AC3808A6AC0E,
	XRGrabInteractable_get_angularVelocityDamping_m6F0E8F58F03E925D9C40AD45FB6B5F3BAF8B6D27,
	XRGrabInteractable_set_angularVelocityDamping_mE759FB87B43922C160ED2F6C753BD42CDE2C1D54,
	XRGrabInteractable_get_angularVelocityScale_m5F0D67D74CD6D8CAC7BF4A168C478B48E4E7E0F3,
	XRGrabInteractable_set_angularVelocityScale_m8B15F58CD5A6869542CFFE7BD213E5C0F26D6D7F,
	XRGrabInteractable_get_trackPosition_mAAD71450024A7E9E1DE556E266078694D60FB192,
	XRGrabInteractable_set_trackPosition_m53B90FBE1263F72AAEBCF8EB68757B696647124B,
	XRGrabInteractable_get_smoothPosition_mA778146AB6B8BD121D8110E96FEBCC4EE24BB7CF,
	XRGrabInteractable_set_smoothPosition_m57E1B2429E52B0F1A64E9133A3B01EE68761EFA5,
	XRGrabInteractable_get_smoothPositionAmount_m8FD0547FE5BA607EADD209476A80D0976D122912,
	XRGrabInteractable_set_smoothPositionAmount_mA4027D3BE5609C429F404DEFCDF6F0B06F917289,
	XRGrabInteractable_get_tightenPosition_mAEBB39CB11C030CC4FCFF5E8765A382508B07852,
	XRGrabInteractable_set_tightenPosition_mAABADE03ED7294B614068F11599066287EDE6DB2,
	XRGrabInteractable_get_trackRotation_m60327C0792A4F7BCD7283BBF3D0EEE053A5DEF34,
	XRGrabInteractable_set_trackRotation_m627BD2250CB0C69A40C506C66A253C8070B70590,
	XRGrabInteractable_get_smoothRotation_mECC92250F9BD027AA23154241C8062012A908A51,
	XRGrabInteractable_set_smoothRotation_mD20170A4C093858570941B43FB85E48A2F833A2A,
	XRGrabInteractable_get_smoothRotationAmount_m3FE8A7855076EB44F8906E3D3412717600446EEB,
	XRGrabInteractable_set_smoothRotationAmount_m4DA12E0C6AF5665EDBAB8D09C83B6751D9543C2F,
	XRGrabInteractable_get_tightenRotation_m0D5412A278006818760D40E18FE69EB43D2B64C5,
	XRGrabInteractable_set_tightenRotation_m70C50B7C7F323EA9DD3317C323CEE04569D1D41D,
	XRGrabInteractable_get_throwOnDetach_mD4EA5FEF8B8C3D95111703FCA580153A9A2557A7,
	XRGrabInteractable_set_throwOnDetach_m555DCA298C7DC53FBA4AE199AECDE27483B1630A,
	XRGrabInteractable_get_throwSmoothingDuration_mB4D0AAA91F0945294AF817EC515F498B997C1DE6,
	XRGrabInteractable_set_throwSmoothingDuration_m140C2316786CAAC8B30DC82261A384A1DAAB4419,
	XRGrabInteractable_get_throwSmoothingCurve_mD38081AF8BD606F87FC0C854A78DEE6DB1AF83AF,
	XRGrabInteractable_set_throwSmoothingCurve_m1CAE7417FA52E9601B515D3275A6AE446ED4085B,
	XRGrabInteractable_get_throwVelocityScale_mD00F6AD657B58D3174CB2173F15540D321E736BE,
	XRGrabInteractable_set_throwVelocityScale_m9181485F86E64F8EEAFA281024F08AC050ABD37D,
	XRGrabInteractable_get_throwAngularVelocityScale_mD2CB0703E07A5B03B6733F29780CFF96E02CEB56,
	XRGrabInteractable_set_throwAngularVelocityScale_m56068620501DAA582DFE9B9A88370F78C4A54895,
	XRGrabInteractable_get_forceGravityOnDetach_m3FFD2461924750484E894E5C0813BDE0D6BCB19C,
	XRGrabInteractable_set_forceGravityOnDetach_m65EA1CF74E61CA70088E884C4CA8460D1C8B9D68,
	XRGrabInteractable_get_retainTransformParent_mC1801D384D9CEFA8B04F692D8D5A772C55309238,
	XRGrabInteractable_set_retainTransformParent_m7E0FE171CA7C1D127C848A84183E9EA85F548579,
	XRGrabInteractable_get_attachPointCompatibilityMode_m5AB593A3EEA6EBA3C0C88FA93B43D7F5A230CF82,
	XRGrabInteractable_set_attachPointCompatibilityMode_mED5BBBDE2845C3F6E9F561CECE0E6147A5A7E7E5,
	XRGrabInteractable_Awake_m891664C7C2647A8A7CE5DE52F137573CD8F708C8,
	XRGrabInteractable_ProcessInteractable_m65B864C1FB5251D0A7AD42154BEF07ED41CB5A2E,
	XRGrabInteractable_GetAttachTransform_m5370DCC9CA70440E39B0D76A60E0AD15E1ED6A10,
	XRGrabInteractable_GetWorldAttachPosition_m58476328ACE5B1C72B0B436F4EC8CFE340742BCC,
	XRGrabInteractable_GetWorldAttachRotation_m99C8927648DF18E004950AB2CEE0FB9E09B2254E,
	XRGrabInteractable_UpdateTarget_m50F47D017722FDA5D89B9E766EFA0BF48E44800B,
	XRGrabInteractable_PerformInstantaneousUpdate_m3E31C1D2DFA918157194820C45B66B868C67838D,
	XRGrabInteractable_PerformKinematicUpdate_mC6BE984E8D18107E077BD78F5E50371A2D888FFE,
	XRGrabInteractable_PerformVelocityTrackingUpdate_m2CFE4053D531708CD3596A05964D83726198A699,
	XRGrabInteractable_UpdateInteractorLocalPose_mD06AE482BE26FBE58CB58E234653650F6B8647F9,
	XRGrabInteractable_UpdateInteractorLocalPoseLegacy_mF76A525301DFE4E43DC5C657663E8D06B72DE38C,
	XRGrabInteractable_UpdateCurrentMovementType_m97D4A5723DEFAAB9CA9B4B87852C61F770CF7C41,
	XRGrabInteractable_OnSelectEntering_m61F7528D64DC4008194F74434CCBB07118F65230,
	XRGrabInteractable_OnSelectExiting_mF52B6F4DD6BAC23E34610E8394768B08510F7A65,
	XRGrabInteractable_Grab_m3C68C5A2882F938DE4B3C62B6B97EDFBA45D8A42,
	XRGrabInteractable_Drop_mE90A72FE9E8B6307A9BA5F41D4A7449689D7F070,
	XRGrabInteractable_Detach_m17458B5384D1105B5755C5532A3C61DC157FC1E4,
	XRGrabInteractable_SetupRigidbodyGrab_m2884D7EA52F22582579C52C0215508352F56A5EB,
	XRGrabInteractable_SetupRigidbodyDrop_mDBFA76F417BE6263209BC1674E9AAD1AE7F8E18A,
	XRGrabInteractable_SmoothVelocityStart_mCE0F6FDC648B61FDD3AE901034CFA97F63711CFF,
	XRGrabInteractable_SmoothVelocityEnd_mC8629B7FB83D124BE434ED9BC3B4ECEF21D7A634,
	XRGrabInteractable_SmoothVelocityUpdate_mA1B2C1123B5893B84AA3BA15CF257DEA49A3230B,
	XRGrabInteractable_GetSmoothedVelocityValue_m08790F7834347E5567A1627A61BDDC44371D8B79,
	XRGrabInteractable_OnBeginTeleportation_m7F32F8600E5C4E7317678E06AD051A696716AF29,
	XRGrabInteractable_OnEndTeleportation_mE0B5FBF6F683CAF439009618A1ED794BBFC2C40B,
	XRGrabInteractable_SetTeleportationProvider_m4AF65996EAD55190DCCD0F72DEC974FE2D45DC0C,
	XRGrabInteractable_ClearTeleportationProvider_m03849DF083EF6A4C10826CF61808EB7DF3015F1E,
	XRGrabInteractable_get_gravityOnDetach_m53B8CC5440249181806F01AC0008B4BDC629D564,
	XRGrabInteractable_set_gravityOnDetach_m5E8D301416F2D440EF9685A6EB1A166C5B528DCD,
	XRGrabInteractable__ctor_mF1FA77294880EFA9C7C840025B207B80327B5E2E,
	XRSimpleInteractable__ctor_m8AC8AD7F6792CC5A7A7D7FB4F78FF415C3EBE412,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	XRHoverInteractorExtensions_GetOldestInteractableHovered_m0011D51EF6150DDF195BCF11A461CA7C7E36AC95,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	XRSelectInteractorExtensions_GetOldestInteractableSelected_mF66A05C14A9DE3239C35811C64B45F948027C1BB,
	NULL,
	NULL,
	NULL,
	NULL,
	XRInteractorLineVisual_get_lineWidth_mC66DEB8990FD9B4CF139D780AD8A34DF24073006,
	XRInteractorLineVisual_set_lineWidth_mC8C31FBE1FE050131E9792159DD896C8D3A52EEA,
	XRInteractorLineVisual_get_overrideInteractorLineLength_m8FD4941CD7331917A96A976DDB88F41C2DDE6110,
	XRInteractorLineVisual_set_overrideInteractorLineLength_mF10463355C64CBC15A9C7E5270BC5E95D622BED4,
	XRInteractorLineVisual_get_lineLength_mF289A3460D8301793BEF729484143404F75A7D86,
	XRInteractorLineVisual_set_lineLength_mE0287680765071A6C6CACF55CC00C788F15227A4,
	XRInteractorLineVisual_get_widthCurve_m52EEDF8BF50C0A203FC3516E0B3470D84F7A8EE1,
	XRInteractorLineVisual_set_widthCurve_m9205EE7C93071DF058F8295E9ADE28B6C09303EF,
	XRInteractorLineVisual_get_validColorGradient_m9434069D6C9A901BF72B9D69FCCE4A2C64CD1773,
	XRInteractorLineVisual_set_validColorGradient_m415ED2CD0EAAA98AC12DD33CB94585431BF8C33E,
	XRInteractorLineVisual_get_invalidColorGradient_m6ED840748037F2F909CDC705494911A4B9018065,
	XRInteractorLineVisual_set_invalidColorGradient_mC9811AD5025321389532F87AB6D2DB290CE7C8CC,
	XRInteractorLineVisual_get_smoothMovement_m44CC8A971593A3C530E455EFD934747263A19EDC,
	XRInteractorLineVisual_set_smoothMovement_m3210C5D1C1D8844E4FFA068C02DC906B2AB9AB1D,
	XRInteractorLineVisual_get_followTightness_mF291BEE16CB0E85D2C2B166A0A642C56559F9E68,
	XRInteractorLineVisual_set_followTightness_m09DA58E8B8C498C829A8717A2C74745F9C554934,
	XRInteractorLineVisual_get_snapThresholdDistance_mB8B92692CA9B7BD325B92D0CF6815F99ED086E7E,
	XRInteractorLineVisual_set_snapThresholdDistance_mB08404B9F3F837F682EA6D98FCFA394F91E1843D,
	XRInteractorLineVisual_get_reticle_m57552D0FBC2DBD6E01F7AD606089AA22A23692CE,
	XRInteractorLineVisual_set_reticle_mC92C09611BD59AED2A6C2AF4EDAF652FBC49C5FA,
	XRInteractorLineVisual_get_stopLineAtFirstRaycastHit_m15AFD0CA4A48A925A8E06BDBB29D2AC2A684D748,
	XRInteractorLineVisual_set_stopLineAtFirstRaycastHit_m53BA2377E3DB8165FE607FEB7136247C9959A8E8,
	XRInteractorLineVisual_Reset_mA291A2E1BED3CA4495D2A929C005F1A38D178D90,
	XRInteractorLineVisual_OnValidate_m5519F1A09A4153A774D16C58182336690020869C,
	XRInteractorLineVisual_Awake_m77305D94E957AD6CF69A7BC730B4F92DC3CFB517,
	XRInteractorLineVisual_OnEnable_m5D548C8CA44E0E0B7AE1132C742DE744CF400D68,
	XRInteractorLineVisual_OnDisable_mCBCB4335BC723A056EECFC3D19A558E607ECE039,
	XRInteractorLineVisual_ClearLineRenderer_m242175B37ABB851CD251CC210D76E9E08AB9C193,
	XRInteractorLineVisual_OnBeforeRenderLineVisual_mA41C9082D06B12685562CCE56869BE4A96047EAD,
	XRInteractorLineVisual_UpdateLineVisual_mC96D44DF8210C4DA7798E624D7C66E8AC5B92DAB,
	XRInteractorLineVisual_UpdateSettings_m10E249F2316A569DBC57D4C08031E8F69669B366,
	XRInteractorLineVisual_TryFindLineRenderer_m2D0483568BBD97EA9AFC9B7929D125DADA198996,
	XRInteractorLineVisual_AttachCustomReticle_m8DFF54A19EFBFD619DDA97203AEC5600B40627D7,
	XRInteractorLineVisual_RemoveCustomReticle_m7CFD61BE14E5772CD3C4A412DE448759207805BF,
	XRInteractorLineVisual__ctor_m3CECB46C4CF6AC1348F592782FCE02796FD3E6BD,
	XRInteractorReticleVisual_get_maxRaycastDistance_m0FD2FEFC00DA86D8705DF03E73E096C98F8DD058,
	XRInteractorReticleVisual_set_maxRaycastDistance_mA1FBCA332ED7360D1734F395ECFB90B2256583E4,
	XRInteractorReticleVisual_get_reticlePrefab_mBB69BAB72702482A8AC57BD25E116C431A3C4C5A,
	XRInteractorReticleVisual_set_reticlePrefab_m2BD3DB77D1EF17C12BD3D6D28409C985286918A3,
	XRInteractorReticleVisual_get_prefabScalingFactor_mB4A095DDFBA3D749250B79569C42AD3C10577866,
	XRInteractorReticleVisual_set_prefabScalingFactor_mF74606716AE1299FAFA92079E80D5197B645BC09,
	XRInteractorReticleVisual_get_undoDistanceScaling_m450794F3C5F483111F630A22F930FFDAF8DF5B89,
	XRInteractorReticleVisual_set_undoDistanceScaling_m7422EBDE0C8DD4445A1521525B788225E4AC524E,
	XRInteractorReticleVisual_get_alignPrefabWithSurfaceNormal_mEEC5EAE1BF7EB9CD093B4415A65343E3FB834062,
	XRInteractorReticleVisual_set_alignPrefabWithSurfaceNormal_m09059A5FFB442A0F4A701739CCF357B8A262AA83,
	XRInteractorReticleVisual_get_endpointSmoothingTime_m8779A5AB66B68F55F8194389C925F560DE8BC238,
	XRInteractorReticleVisual_set_endpointSmoothingTime_m781E3AB98270AF8B7D42BDFE4A6F23B57AEB4E85,
	XRInteractorReticleVisual_get_drawWhileSelecting_mBACBD95DF4DE19EA9A3D8978BF4D95BB80172A02,
	XRInteractorReticleVisual_set_drawWhileSelecting_m7B84B25405BF25A2C77397FCF1F996FB469D4BD8,
	XRInteractorReticleVisual_get_raycastMask_m8A22B285C9A9CBAEB134E219FE1683A8DFFD265C,
	XRInteractorReticleVisual_set_raycastMask_m51DCD3AD0249E5E2BDF29CA73E8F3A2BE2D630ED,
	XRInteractorReticleVisual_get_reticleActive_m7FF0E330C5E1795C6FB323708A57E4923B1C3ED4,
	XRInteractorReticleVisual_set_reticleActive_m9AEE679F93F9047FAFA1636B67A6B440F9540120,
	XRInteractorReticleVisual_Awake_m620E8256EF9B9B4B09390D28D28D3C8B4FE5CC5F,
	XRInteractorReticleVisual_Update_m9D4213458FF15F09611139B92EA47EB5BA330E9F,
	XRInteractorReticleVisual_OnDestroy_mFF1FE79C0D5AE2CF54460A0802F7856D297DBAE6,
	XRInteractorReticleVisual_SetupReticlePrefab_m26AA753B23AC0A8C795B7A94A73DFF24505CFCA0,
	XRInteractorReticleVisual_FindClosestHit_m356DB666879D2014B1D186186BCD457E88AD9A0F,
	XRInteractorReticleVisual_TryGetRaycastPoint_mECBDD69BC9BBC77A819B785FE2F3BC8CDDE88BD6,
	XRInteractorReticleVisual_UpdateReticleTarget_mB09856FE0B6930BFAA966A3CE60216B878ABCC1C,
	XRInteractorReticleVisual_ActivateReticleAtTarget_m18AB75BF534986A02656F869C547CFA417C60B38,
	XRInteractorReticleVisual_OnSelectEntered_m11BE97991A944F1054E59CB0053DF6CBE271E876,
	XRInteractorReticleVisual__ctor_m23E64B7C8027F35967D8B9ACF59D0F4241E1A5D1,
	XRBaseControllerInteractor_get_selectActionTrigger_mCB494C7BA0CBE50A36F058E35AA3AC521C9D2010,
	XRBaseControllerInteractor_set_selectActionTrigger_mED28C90236E93293019D4F9132AA5C3447861A88,
	XRBaseControllerInteractor_get_hideControllerOnSelect_mCB86A19F5DE0AC8188C31E241C9C64929FBE55DB,
	XRBaseControllerInteractor_set_hideControllerOnSelect_mDD43C12E034AAEBCFA01E370A2C76B102B4FDEA5,
	XRBaseControllerInteractor_get_allowHoveredActivate_m7604FF7BA4C2AEA53DA917D94ACDE4FEE3413254,
	XRBaseControllerInteractor_set_allowHoveredActivate_m132E0D5D79F38485EABB97AA1ABF6F556F4878DC,
	XRBaseControllerInteractor_get_playAudioClipOnSelectEntered_mA25EB8261F66A5B079F07F645221E8B3FE5D4222,
	XRBaseControllerInteractor_set_playAudioClipOnSelectEntered_m4760D4496FA93D12EEAE3422AC0261EDA9670CCC,
	XRBaseControllerInteractor_get_audioClipForOnSelectEntered_m9A0E4824ADDE03866B16524FC3D340870FD775AD,
	XRBaseControllerInteractor_set_audioClipForOnSelectEntered_mEECB50AAC1E0AB695CFF9DA8F0BD892CDD40097C,
	XRBaseControllerInteractor_get_playAudioClipOnSelectExited_m8978833C86F99CE7FCA7139CAB2545D180AF2D2A,
	XRBaseControllerInteractor_set_playAudioClipOnSelectExited_mE581F3D4F87EC98324A80BFFC1E525288A3FF013,
	XRBaseControllerInteractor_get_audioClipForOnSelectExited_m7A09420C644DCACE326E4B5C4F8E33598B34E582,
	XRBaseControllerInteractor_set_audioClipForOnSelectExited_mE281ED7816675A52713088BF97DA0EBBAD0E8D28,
	XRBaseControllerInteractor_get_playAudioClipOnSelectCanceled_m9B0E43785F6CB9F5DB69298C306CBB4EE2A7E905,
	XRBaseControllerInteractor_set_playAudioClipOnSelectCanceled_m2D966F1B89C15EB331693675D157DB8F02107C4F,
	XRBaseControllerInteractor_get_audioClipForOnSelectCanceled_mC30675A1F8E48AB1E7E59BE9B2C2224E9DBAADA6,
	XRBaseControllerInteractor_set_audioClipForOnSelectCanceled_m857146DE36A5B510D2B58D84AA7A35314663D2ED,
	XRBaseControllerInteractor_get_playAudioClipOnHoverEntered_m248DA5BCC9CD1489BD8B8B953A7D5CC4C38E47A7,
	XRBaseControllerInteractor_set_playAudioClipOnHoverEntered_m01F4ED76F62B831613D0B48FC2F60AF0C887B820,
	XRBaseControllerInteractor_get_audioClipForOnHoverEntered_m7684A91511FDC02358D565E70D77D8AA668302FE,
	XRBaseControllerInteractor_set_audioClipForOnHoverEntered_mF7613F7A75BEC20FD6B0D1FCDC67E274323A1D5E,
	XRBaseControllerInteractor_get_playAudioClipOnHoverExited_m83B5234181B9A0907F021DB9015040164444DAED,
	XRBaseControllerInteractor_set_playAudioClipOnHoverExited_m714CBC8F50386871D88B28F32EE34DBAD4261DB3,
	XRBaseControllerInteractor_get_audioClipForOnHoverExited_mC30E51B5B790343F3BB6C1148CFE24E54E7F6441,
	XRBaseControllerInteractor_set_audioClipForOnHoverExited_m59986DCCE208E7BEA8BD31DBA4A3964DE11FFB37,
	XRBaseControllerInteractor_get_playAudioClipOnHoverCanceled_m6051B977A9F4670C29EBC513283929514B1831B9,
	XRBaseControllerInteractor_set_playAudioClipOnHoverCanceled_mADA799753DF5F279D0EDE9BB3638CE374E333B50,
	XRBaseControllerInteractor_get_audioClipForOnHoverCanceled_mEA9C59A47E3515B85662AFD5CF75F4533DCF0D4E,
	XRBaseControllerInteractor_set_audioClipForOnHoverCanceled_mB4DAAC7B829DF82466BBDFC3F62CFCFD5CAABC86,
	XRBaseControllerInteractor_get_playHapticsOnSelectEntered_m763E2EACB3F0DF0A325955B34F5CB6D8245C3297,
	XRBaseControllerInteractor_set_playHapticsOnSelectEntered_m9043BA2D99CA2B7FE73151960CC6BED3CB020CD3,
	XRBaseControllerInteractor_get_hapticSelectEnterIntensity_m0FF641A19A017CCDF39CF27C03C21FA0EBAAE4BF,
	XRBaseControllerInteractor_set_hapticSelectEnterIntensity_mD2058A1D3EF40199553E39913BC96A2D3173E316,
	XRBaseControllerInteractor_get_hapticSelectEnterDuration_m5D86D1C7E863D394013AA5026B4DF510619E3080,
	XRBaseControllerInteractor_set_hapticSelectEnterDuration_mBE46CFDFDA52329BF3F57ABAACBCD51490E4B5B7,
	XRBaseControllerInteractor_get_playHapticsOnSelectExited_m5DF2C108759F681632FB85E5759C03AF358BE2E8,
	XRBaseControllerInteractor_set_playHapticsOnSelectExited_m5C407F2EA7D8F76210B7998B246F8B20D68C781B,
	XRBaseControllerInteractor_get_hapticSelectExitIntensity_m5D338D33D49AE3C99E877044F3319579330FB43E,
	XRBaseControllerInteractor_set_hapticSelectExitIntensity_m8F08D58A280BB703BA2C63F31A01B4DF0B2D76C8,
	XRBaseControllerInteractor_get_hapticSelectExitDuration_mC00C544D1B360C6FBC4A75191F567FC9D951F3D4,
	XRBaseControllerInteractor_set_hapticSelectExitDuration_mF00BEBE636025202D9BC741CF99D8FE6C58A307A,
	XRBaseControllerInteractor_get_playHapticsOnSelectCanceled_m0DD4D8C866C5D6A76ADC095FF8B08CB0FDB9C1E2,
	XRBaseControllerInteractor_set_playHapticsOnSelectCanceled_m1DBDB0A623D1494C686696EE84CF18C122C7A1D6,
	XRBaseControllerInteractor_get_hapticSelectCancelIntensity_mE45AB9D6F0067C2F67F0C5B97EE7BD309ADAE335,
	XRBaseControllerInteractor_set_hapticSelectCancelIntensity_m266CC7DFA9CC8FCBFCF298B6848E2E768CFDFC39,
	XRBaseControllerInteractor_get_hapticSelectCancelDuration_mF8B7CAC67A9EE3D6D64D20E6323F5D0CC831E9FB,
	XRBaseControllerInteractor_set_hapticSelectCancelDuration_mE64EC55CEA68B7114131D806148141CBA194E7F3,
	XRBaseControllerInteractor_get_playHapticsOnHoverEntered_m57462B71C4340F341140AD5A58BEC7E3A1D79445,
	XRBaseControllerInteractor_set_playHapticsOnHoverEntered_m12E6BC09757083BDF6D39B833A9779AFE885573D,
	XRBaseControllerInteractor_get_hapticHoverEnterIntensity_m1B4750EDF0745C988ADFD452CD6E779990EC6FD3,
	XRBaseControllerInteractor_set_hapticHoverEnterIntensity_m131FB945810E77EDD595B895F852C94A4714632C,
	XRBaseControllerInteractor_get_hapticHoverEnterDuration_mA6332338614A3D81A71A009F49D2FB022A8A786D,
	XRBaseControllerInteractor_set_hapticHoverEnterDuration_mE52A2F51917C3EFC6169939DAE3F6B9DA48AF515,
	XRBaseControllerInteractor_get_playHapticsOnHoverExited_m3D5ED4BE8757E3370A596A37B80A38F2342859D6,
	XRBaseControllerInteractor_set_playHapticsOnHoverExited_m7FAE85CA6C4C385561BC7685F0D088715BD91996,
	XRBaseControllerInteractor_get_hapticHoverExitIntensity_mE1535489AC6AE761EC64383CFABDBA56FB870E5F,
	XRBaseControllerInteractor_set_hapticHoverExitIntensity_mB28A46AC3432AFA77B81CEA82F8151ADD384B353,
	XRBaseControllerInteractor_get_hapticHoverExitDuration_mD994A2439337F73FEFE0D09A05CF9348F248924D,
	XRBaseControllerInteractor_set_hapticHoverExitDuration_mF6BF30CBFCFB3638D9AA1D485C09DCD3B9B8B41F,
	XRBaseControllerInteractor_get_playHapticsOnHoverCanceled_mC74AAD7E966F17AE8BF854CA2B62A92B263C3A90,
	XRBaseControllerInteractor_set_playHapticsOnHoverCanceled_mA18876593E753602FE5850BAB137312BF5682EE3,
	XRBaseControllerInteractor_get_hapticHoverCancelIntensity_m52902A33C06EDF8A34EA08C96CE82A06A026E25A,
	XRBaseControllerInteractor_set_hapticHoverCancelIntensity_m3A6C9F831690E4583B11239162412185DC086E84,
	XRBaseControllerInteractor_get_hapticHoverCancelDuration_mA72726302124D5EACA9468D2C8BE5BEBBF3B7047,
	XRBaseControllerInteractor_set_hapticHoverCancelDuration_m9CFC0A57C66CC443D8505E4C14B12EBE72461FE4,
	XRBaseControllerInteractor_get_allowActivate_m18841206E1DAB3E556D6543DC77C28B68ACFDECC,
	XRBaseControllerInteractor_set_allowActivate_m5567F89005093B2E724BD91B90A68AD8A907FDB0,
	XRBaseControllerInteractor_get_xrController_m3BBC15462D296ED35A6F2E87D290B86BF9216650,
	XRBaseControllerInteractor_set_xrController_m23CD933EEC980FBEEDA28EB1F6A16B7D7900D454,
	XRBaseControllerInteractor_Awake_m56049D4907C4F717D23E1125B0A889C03B1BC2C7,
	XRBaseControllerInteractor_PreprocessInteractor_m35D8EFA87BBD74851FA55C0CB992C673F75A3BC3,
	XRBaseControllerInteractor_ProcessInteractor_m7C0801EA3674FB041D39591839085D70CCBD2924,
	XRBaseControllerInteractor_SendActivateEvent_m1CCDC1F6AF37B0CA504BA32566BCB1F937AE0E55,
	XRBaseControllerInteractor_SendDeactivateEvent_mAF2DA1D5D44D2F945BBFC4FDAB8434AA54380A70,
	XRBaseControllerInteractor_get_isSelectActive_mD2A0FEDFB804B2D728DDDAFD14A36F4CC7DDB0DB,
	XRBaseControllerInteractor_get_isUISelectActive_m0161BBF0121D3B3C388D07CD8BA284CC2D30B081,
	XRBaseControllerInteractor_get_shouldActivate_m1614B653063CAAE5F92978BE2EC718F06C568CBE,
	XRBaseControllerInteractor_get_shouldDeactivate_m4C899A54579C59F177468F043318D3A486445A3A,
	XRBaseControllerInteractor_GetActivateTargets_mC085A4C633558C4664682DE73936BDE993CE10EA,
	XRBaseControllerInteractor_OnSelectEntering_mC2F8B79C49F40CCD49B2E2D3619958CBBE193778,
	XRBaseControllerInteractor_OnSelectExiting_mA62F40FAA1C318A29C57208462E5B84707EB58B4,
	XRBaseControllerInteractor_OnHoverEntering_m9D888FB65519609A49AD2668FE3DE65D396F9194,
	XRBaseControllerInteractor_OnHoverExiting_mD0013FAB461685432BA128724E05FE16381DF569,
	XRBaseControllerInteractor_SendHapticImpulse_m3FB94421656EEEFB493079ECF9A835ED76A16FFF,
	XRBaseControllerInteractor_PlayAudio_m810ABE116A0AA27D131791151F15B1D93C066F40,
	XRBaseControllerInteractor_CreateEffectsAudioSource_m5DD59A4BB8EB6CBBBC5E30CA7FA3ECA04BBC592C,
	XRBaseControllerInteractor_HandleSelecting_mEE385E75B21EB5525DCAF6CD7FB476DC1DD6BE48,
	XRBaseControllerInteractor_HandleDeselecting_m082894DDF402A43720079B75502722B21086FAFF,
	XRBaseControllerInteractor_get_playAudioClipOnSelectEnter_mA27A80951779A122CB4338EEEB98A313E0E81DBC,
	XRBaseControllerInteractor_get_audioClipForOnSelectEnter_m028B5FD8F656B98DF97A43F876EC707BB085D091,
	XRBaseControllerInteractor_get_AudioClipForOnSelectEnter_m3EE95869C8606934182F99711B7CA63C7D7FE918,
	XRBaseControllerInteractor_set_AudioClipForOnSelectEnter_m847AA895C79DD6D13400B10779513E6054C690ED,
	XRBaseControllerInteractor_get_playAudioClipOnSelectExit_m1AB9FE4B8D5504AF267A51A9CCB1E7995E1F6FEA,
	XRBaseControllerInteractor_get_audioClipForOnSelectExit_m6048BBDA543298D2490A743C755F528F067838EA,
	XRBaseControllerInteractor_get_AudioClipForOnSelectExit_m172979B3FCB857AF4FED242D0CD05DBFC9EF7AFA,
	XRBaseControllerInteractor_set_AudioClipForOnSelectExit_mF02E062055BC554990E931D86D826AAD1D48DDDB,
	XRBaseControllerInteractor_get_playAudioClipOnHoverEnter_m76E47B225A881B6A5A929987FEC2A2AE8FBD253C,
	XRBaseControllerInteractor_get_audioClipForOnHoverEnter_mA2EE38C5F2DBA8ACDF60C67DE4A54E0364704121,
	XRBaseControllerInteractor_get_AudioClipForOnHoverEnter_m262D11C7E2816D16EAD0BD618287FD2052C35BE1,
	XRBaseControllerInteractor_set_AudioClipForOnHoverEnter_mB0EB82559130360882514F049D607BBDB787CE81,
	XRBaseControllerInteractor_get_playAudioClipOnHoverExit_m8FFE6D35DA39106CE854A790C58DFB395D81FF5B,
	XRBaseControllerInteractor_get_audioClipForOnHoverExit_mBBF425B63F214550CA43A5B36583CC3F5BF93A0C,
	XRBaseControllerInteractor_get_AudioClipForOnHoverExit_m3A8E9280F3A45698DC4BBD3CC90762AC22523DCC,
	XRBaseControllerInteractor_set_AudioClipForOnHoverExit_m25E6581419E3218E15E16690611B66FCB5FC69C6,
	XRBaseControllerInteractor_get_playHapticsOnSelectEnter_mFC4B1C291125623DAE52E2BE3BEADD322755BD97,
	XRBaseControllerInteractor_get_playHapticsOnSelectExit_m4B750C6EF6E0790E1970F807B337950B55998B81,
	XRBaseControllerInteractor_get_playHapticsOnHoverEnter_m06B9BC3E4A5A964BA88A6C2A890C8BAE02F57596,
	XRBaseControllerInteractor_get_validTargets_m93BDD6EAE63E4178772D16B4ECBCE42E23325C2E,
	XRBaseControllerInteractor__ctor_m3389EC35F9C9C32149307AEEAF3A39C93A652AC5,
	XRBaseControllerInteractor__cctor_m1AFAC1ADC99B0B69BD8785469D92DB472B25C31C,
	XRBaseControllerInteractor_UnityEngine_XR_Interaction_Toolkit_IXRInteractor_get_transform_m0D684F19C850A054FF77B58331DB7662A9EB35B2,
	U3CU3Ec__cctor_m5C794AE4E6AEE87AC9AB5CE584C0DEC7AAE0841A,
	U3CU3Ec__ctor_mDB687ED85F378EB8ADF03F88D91757B797AF8EA7,
	U3CU3Ec_U3C_ctorU3Eb__208_0_m4FCDF50D009FCF86BB98AB312E9A24FD673ECDC8,
	U3CU3Ec_U3C_ctorU3Eb__208_1_m132BEE78FD9C2A71D6A610372D21E0E392860AF6,
	XRBaseInteractor_add_registered_mDFEA7418891929970CAD59F5A51E8F98123F172B,
	XRBaseInteractor_remove_registered_mF2A497E4857266A8B3D61DB0F02F79C7337D838E,
	XRBaseInteractor_add_unregistered_mDEED3743311D18B0748940FF13BF76722A6723A8,
	XRBaseInteractor_remove_unregistered_m21B916157AF57EC9F79BBF8A7BB027351A880E2C,
	XRBaseInteractor_get_interactionManager_mD7FB7431097431DD95D2333E58A5052DF106E09F,
	XRBaseInteractor_set_interactionManager_m3B0BFBBFE80325CF8837DFC31B61E907710554AA,
	XRBaseInteractor_get_interactionLayers_m83DCB38A70922078AEBD323EBD7EDBEB6A70D00D,
	XRBaseInteractor_set_interactionLayers_mA988AF491A54DB866194C07D5E374780543B77D8,
	XRBaseInteractor_get_attachTransform_m704C74165ED1463CF8B79670066472AE4BD33482,
	XRBaseInteractor_set_attachTransform_mA8DC6CAE14C3CAEDF3A8A9F23EC5DD5D533F7D56,
	XRBaseInteractor_get_keepSelectedTargetValid_m76A234A876F9418E93317B3068157B6AE5D9674A,
	XRBaseInteractor_set_keepSelectedTargetValid_m1DA1CA84FCA03C3FF7B9A4A7868DFAA2068B0033,
	XRBaseInteractor_get_startingSelectedInteractable_m0A551AC3C85D5B2EC353B2161A02CC2BCF888BAF,
	XRBaseInteractor_set_startingSelectedInteractable_m875C82466909DF095E03CE0F3E3376CFF7BF24C9,
	XRBaseInteractor_get_hoverEntered_m15CE707680BD64D93BD6F923CC1F431860ACA98D,
	XRBaseInteractor_set_hoverEntered_m076D53344B91F828218086BAD2C12C085C5D37C9,
	XRBaseInteractor_get_hoverExited_m56584228DB8A08A444922894BC6988171F306178,
	XRBaseInteractor_set_hoverExited_m880D6DFBF560D779430A6200270395C076EE05D3,
	XRBaseInteractor_get_selectEntered_m49681B23359BF5E9E0C3F69040D0C1567A528EC3,
	XRBaseInteractor_set_selectEntered_mB607AC59A9E90460E22969EE3BAB1D14C567303C,
	XRBaseInteractor_get_selectExited_m2B4FA666B95E8DF09EB6D92ACEDB892BFF375384,
	XRBaseInteractor_set_selectExited_mEC821344C8B82E21C6224FFBB03D23C7D097D271,
	XRBaseInteractor_get_allowHover_m357ADDB98144E2F7F866B103035C2A35BE27E776,
	XRBaseInteractor_set_allowHover_m1BCBF8BEFBF5043EFCC4EF41489AED8233C953AD,
	XRBaseInteractor_get_allowSelect_m0EA6D2C7201E691481A8FFA9F415623F632A1741,
	XRBaseInteractor_set_allowSelect_mE1104EAFC8D63D651C5461949D3ACB4C7C0353A2,
	XRBaseInteractor_get_isPerformingManualInteraction_mB89C10BD1B4884EE369A46CC0D145B780B385A86,
	XRBaseInteractor_get_interactablesHovered_mBC239352EDAB9F297C3E88EFF08EC5D4EC4AA43A,
	XRBaseInteractor_get_hasHover_mD3BEFFEC29767CA2E4DC8C118803F9FE522FC5B3,
	XRBaseInteractor_get_interactablesSelected_mD1EBA5422B2A291EF032106674611CCDACC62270,
	XRBaseInteractor_get_firstInteractableSelected_m26779B4796BA51429DE9B5F34EB69BB4C02C48AF,
	XRBaseInteractor_set_firstInteractableSelected_mD8E07F7A066965269176D5A61F3240A6D733357A,
	XRBaseInteractor_get_hasSelection_mDC47E8BD0F4498E27BD041B52008C36AD09583B1,
	XRBaseInteractor_Reset_m7ACAE4DF6A1A8F7E4DD6BC0A4D5645DC11D240C7,
	XRBaseInteractor_Awake_m6C75157E01BD94FADF8EC1815E1202CB615DD88E,
	XRBaseInteractor_OnEnable_m65BC403EF883EFD685764D768F787C11F8906BDD,
	XRBaseInteractor_OnDisable_mA7C2B26F5887ECF0E95A964759EE035800B40D6E,
	XRBaseInteractor_Start_m1FBD6D21C76646104BF949DD673C5319C3AD4970,
	XRBaseInteractor_OnDestroy_m9B3CE432DC24BE6ED8985CE17BF5EBDC5DBEA02C,
	XRBaseInteractor_GetAttachTransform_m116EB7BBA8EF9EAAD2C044726DC10F88B632D5BE,
	XRBaseInteractor_GetAttachPoseOnSelect_mA3CADA2CF3873F38794DF86EDCF10D1EDD7D6E3B,
	XRBaseInteractor_GetLocalAttachPoseOnSelect_mE54064C64C854AB01AA234E026DC97686BACD37A,
	XRBaseInteractor_GetValidTargets_mB24AEE297EE623EB57A903520BA832326A7DF1B1,
	XRBaseInteractor_FindCreateInteractionManager_mD1E7D03121B1D9946933705229C54F4F22506A58,
	XRBaseInteractor_RegisterWithInteractionManager_m4C35108B7708D2123C20B5E3515FF93870302F4A,
	XRBaseInteractor_UnregisterWithInteractionManager_m456B9BEBB2209C64758A7D821AFBF090041E656B,
	XRBaseInteractor_get_isHoverActive_m91F8634F4F3B4BB0F54BEC2546B98AC2C4ECB357,
	XRBaseInteractor_get_isSelectActive_m56CB9182C9F3FD3012F7C13B2F02C8B3969B1039,
	XRBaseInteractor_CanHover_mE4BFF4D695C12708D5544781C80A499EF3DCF8F1,
	XRBaseInteractor_CanSelect_m857FE99BC5AAAD3DC5245EF8F0D77B32E87A2C31,
	XRBaseInteractor_IsHovering_m55FB787EEE350276EEA14DAD207CC480E50922BF,
	XRBaseInteractor_IsSelecting_m3B428FEC36DAE9F97CCC2987B72D9F706CD8CE62,
	XRBaseInteractor_IsHovering_m3D8CA61660A77820B30C03D47C42D21E99E389E6,
	XRBaseInteractor_IsSelecting_mA346D7D3004F15BF9D982B4F8D1E3A45F078ADB5,
	XRBaseInteractor_get_selectedInteractableMovementTypeOverride_m1E0E40901DE181CE04985FF5626CD59AA5D10FDA,
	XRBaseInteractor_CaptureAttachPose_mDBE1D76673D032F2C1EEBBE7B2D65E976CD6B471,
	XRBaseInteractor_PreprocessInteractor_mF1F270D70D1E2F39E36486B92D6E1E44255F6ED4,
	XRBaseInteractor_ProcessInteractor_mCA4F4CDFE9578064E85EEA274098EDAE7E9E27BC,
	XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRInteractor_OnRegistered_m34EAB9F9D1C38DF1390A49955087E32F8BEA4171,
	XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRInteractor_OnUnregistered_m44641B37B1BEB0A9867536930C20F6EDBEDDC578,
	XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRHoverInteractor_CanHover_m067F71B53F2F5A51A65E742FA87A9D952382C312,
	XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRHoverInteractor_OnHoverEntering_m36F164B4EB67530252354129C857484DF82287A1,
	XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRHoverInteractor_OnHoverEntered_m8673D1EBE4CBE66030CEB1817494A7673C767AB9,
	XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRHoverInteractor_OnHoverExiting_m3792F6819F7835D23D739B70CF7B3E43F8499C45,
	XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRHoverInteractor_OnHoverExited_mFB7411803014DDC82F60D0EE75EFDA827A4641BC,
	XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRSelectInteractor_CanSelect_m8D3B9E08C4F360BE69CF45ABE3412932D89B5063,
	XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRSelectInteractor_OnSelectEntering_m1A29BD94DB518DEACEB24E373A5E70AD5CD75D63,
	XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRSelectInteractor_OnSelectEntered_m223DD16423E761FA865023F1FF0AECC510ED2CA3,
	XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRSelectInteractor_OnSelectExiting_mE4828A2B54422D1339F0B79094CEDE6A6FBFD063,
	XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRSelectInteractor_OnSelectExited_m5A144267275180DC7F69468A3AB233CFEF0F0482,
	XRBaseInteractor_OnRegistered_m1BB39FA738FF1BFA87EB9ACB9D091D2C0FF8F67A,
	XRBaseInteractor_OnUnregistered_mA14336625DC266534FFF8056AB2655A817D1B778,
	XRBaseInteractor_OnHoverEntering_m2A2499BDF0F89D2714BA789EE9A20675474A69C7,
	XRBaseInteractor_OnHoverEntered_m78767217DB9B63C9574E796C58F65C5EA2E908A6,
	XRBaseInteractor_OnHoverExiting_m52628FF618019474078CB02DDF2F49711FAA810E,
	XRBaseInteractor_OnHoverExited_m4939A4A5FF0A6139436EF0742C04CE7EC65E33D6,
	XRBaseInteractor_OnSelectEntering_m3EA6F5821354FC822F71995CE161471F39F150A9,
	XRBaseInteractor_OnSelectEntered_mB8E77D8ECF4F1E05EACC983AB4ADC30A7436E9D8,
	XRBaseInteractor_OnSelectExiting_m7725B69F454CC0A648E0B60AB5E18CBE5787F0AF,
	XRBaseInteractor_OnSelectExited_mF549A06BF8301DC612AA2514EC4C781869DAC0E5,
	XRBaseInteractor_StartManualInteraction_mB19DA7DD686B95D10F99BA7D8A10D1499B724039,
	XRBaseInteractor_EndManualInteraction_mFAC265C520AD30A85A7C4522772C22EDB4C9518B,
	XRBaseInteractor_get_interactionLayerMask_mA396D79861729A68EEB8C025A947071E948B6CF1,
	XRBaseInteractor_set_interactionLayerMask_m1737C7588EE2CBD195D86719BE2510B508D6776D,
	XRBaseInteractor_get_enableInteractions_m67A61D810107BF13A42C8261A47454B84678E874,
	XRBaseInteractor_set_enableInteractions_m74617749137DB759AA43C023634C1F23D32DF712,
	XRBaseInteractor_get_onHoverEntered_mA449A72C5F366C8BB222D6262D5127D61D3F10AC,
	XRBaseInteractor_set_onHoverEntered_m08FBEB36390D812631ABC807B8587D0C4C842DA2,
	XRBaseInteractor_get_onHoverExited_m0DDF2121B99C14B9AF139D7FF4B27D9F7C1398C3,
	XRBaseInteractor_set_onHoverExited_mEF0748AC36F7BA764AA9C09509BA95DB2CBEE67C,
	XRBaseInteractor_get_onSelectEntered_m238310EE85C99FE578B38F20895C83365184E69E,
	XRBaseInteractor_set_onSelectEntered_m0BFFBB5D6C943205F9B3D2DA4184353D3120662A,
	XRBaseInteractor_get_onSelectExited_m29B6A63775E3A7E3F0C8881D4BB6194F059780C4,
	XRBaseInteractor_set_onSelectExited_mCF801299B6060B380B394E13494C0A49F558FA31,
	XRBaseInteractor_get_onHoverEnter_m1DC8B81FA2FEC784301933C81822B13823386EF0,
	XRBaseInteractor_get_onHoverExit_m8C280AC6F90D71F321757C994D1E01D9E61BE429,
	XRBaseInteractor_get_onSelectEnter_m0CEDEDB2FAC2877CD60B1407BA2A4C79A7D2DF75,
	XRBaseInteractor_get_onSelectExit_m23C9C661A20C668B2EB73FA878BDFA2641A09977,
	XRBaseInteractor_OnHoverEntering_m53C199DBE536D343E946E44574A2E020C08EE690,
	XRBaseInteractor_OnHoverEntered_mEB7BD83EA335C9CAE1224FA8301A92ED6209256D,
	XRBaseInteractor_OnHoverExiting_m34E59BB6AC0126095917BE5796E6B6912E0345D6,
	XRBaseInteractor_OnHoverExited_mA4685CA32D22F19E62B69473771C77F32605B992,
	XRBaseInteractor_OnSelectEntering_m163C97B729A7F45EA303E24EAAFC6E03730048F7,
	XRBaseInteractor_OnSelectEntered_m28C75857F4107F32CFD49D47BE284A0C7F3B3E9D,
	XRBaseInteractor_OnSelectExiting_m4CA8911663511BDECB64BE2CAFF7D04AAFF002AB,
	XRBaseInteractor_OnSelectExited_mF49B11491BA75211E785DE4DF3EF21155D12EE95,
	XRBaseInteractor_get_selectTarget_m2888C3BFA4B168C6DDD37CAC1A999BEF406596E4,
	XRBaseInteractor_set_selectTarget_m91662B5B6BFF86231E8A5D2D1DB4248D621EE38B,
	XRBaseInteractor_get_hoverTargets_mE8E85B88E7C55FD9B89CCDECAB26FFF81C6A33AA,
	XRBaseInteractor_GetHoverTargets_m97B6CFE8D71144CF21C4D470482DAB9101D4AA35,
	XRBaseInteractor_GetValidTargets_mCBA71C2416753720B26909D52E2B91F61D9F7CBD,
	XRBaseInteractor_CanHover_m937BB7BEF8BD5FAD64BFAE799C9A7B749B5BBA19,
	XRBaseInteractor_CanSelect_m55EAA2676B54657E1BBA826503EC7886802041DA,
	XRBaseInteractor_get_requireSelectExclusive_m954D86172595A6FEB6FC427F2E29BCDAFED636F9,
	XRBaseInteractor_StartManualInteraction_mD772BD84B374A52F64A5BE7C92C1D9CE62AB0ACF,
	XRBaseInteractor__ctor_mCEB69DD262DE1CF1951979855AFC2FEEC41806FE,
	XRBaseInteractor_UnityEngine_XR_Interaction_Toolkit_IXRInteractor_get_transform_mE7E88B629F433D7A1FC24827D99A50FBECDCAA1D,
	XRDirectInteractor_get_unsortedValidTargets_m3F187FD1D01B26250B2BE851DCD1AE186D7C3B5F,
	XRDirectInteractor_Awake_mB51788F86E4C2D7C55F00477E3F5E5588D7BDF65,
	XRDirectInteractor_Start_m3C997ED103F1B5ECA652552D6DCC984898B0AE5E,
	XRDirectInteractor_OnTriggerEnter_m3D9CCA2EED4E0AA34A0BE36DE7599FF6348FC9F6,
	XRDirectInteractor_OnTriggerStay_mEE525A746196804F4A7E66C5A72807B66E91950A,
	XRDirectInteractor_OnTriggerExit_m5C355D85FAE1ED7E7FE8E4A22168B81DD50FB8D0,
	XRDirectInteractor_UpdateCollidersAfterOnTriggerStay_mFB001408D287F1B2C2D25AAB0294916FAA7EB2A5,
	XRDirectInteractor_ProcessInteractor_mCFC6F659CE3B3CB8E61651E9C445AB2A7FDEEA50,
	XRDirectInteractor_ValidateTriggerCollider_mBA36322C35D0D862DC3BBB4589E327539EE57DAA,
	XRDirectInteractor_GetValidTargets_mA400D3C7DA91720BCD4ED266D4C904C830ADE99E,
	XRDirectInteractor_CanHover_mA55E90FBCC4617EBCA46DE2C95A1D1494EEC6C17,
	XRDirectInteractor_CanSelect_mC3B39DC4FEE142197D08FE0236BDF3893621A6B7,
	XRDirectInteractor_OnRegistered_m4C60146C4CA689769D38EAFB32C3EB477BC34E13,
	XRDirectInteractor_OnUnregistered_m8FB63736F9FCF0593AB7DCE2FEFE18F50188D436,
	XRDirectInteractor_OnInteractableRegistered_m1E2ACA6632D19A7684383401D04969214102195C,
	XRDirectInteractor_OnInteractableUnregistered_mC33CD46EFB5E5617B9B1EB93596928F9FD0C6429,
	XRDirectInteractor_OnContactAdded_m790E0C50C4A81E54CC96E91DB14466423F821702,
	XRDirectInteractor_OnContactRemoved_m6B6012C3F5264D3D55E701B25838C6FE89AC3156,
	XRDirectInteractor_CanHover_mDEA26F94E9C64C3EB89A0AEB805856FDE0DA7A41,
	XRDirectInteractor_CanSelect_m5E29D77F0A224AEC11AAD270A566C9C417B32DF3,
	XRDirectInteractor__ctor_mD3BF236502DEBCF85593CEF7F585F787AE08E4A2,
	XRDirectInteractor__cctor_m2FA03D795AC5902AB95B581382D4E8BF5B2D1F5F,
	U3CUpdateCollidersAfterOnTriggerStayU3Ed__11__ctor_m31DF5879A500B55F9C0B6E6C09554979D09371B2,
	U3CUpdateCollidersAfterOnTriggerStayU3Ed__11_System_IDisposable_Dispose_mA7A1F4A04B1EF73D60B837F3F314F9E5D5739F37,
	U3CUpdateCollidersAfterOnTriggerStayU3Ed__11_MoveNext_m17CD9ECB3FD5F8D87F55991A7F6D7909640F50F1,
	U3CUpdateCollidersAfterOnTriggerStayU3Ed__11_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mD2AF0E969EDB30FA9AD8D8272E0B3D7CFF771AA6,
	U3CUpdateCollidersAfterOnTriggerStayU3Ed__11_System_Collections_IEnumerator_Reset_m1000802674DC352AEFEB54E3F6DF8324E2438759,
	U3CUpdateCollidersAfterOnTriggerStayU3Ed__11_System_Collections_IEnumerator_get_Current_mF4EF99BD0B0D5A4C69ECE072388316561645A550,
	XRRayInteractor_get_lineType_mCE9C5CDA4DF31B8C3425D5F8050707655D36745B,
	XRRayInteractor_set_lineType_m0D312CD7538192F49A152DBCB266E4D9AECEF677,
	XRRayInteractor_get_blendVisualLinePoints_m45738324AB95BBFEAEAD7236861C8FA7B7C23B3A,
	XRRayInteractor_set_blendVisualLinePoints_m564BB6E62C7C182A06B40591FA3E660F4E064EE6,
	XRRayInteractor_get_maxRaycastDistance_m1069A3FBFC0A89685DB6E46A1F31D4F089303FEB,
	XRRayInteractor_set_maxRaycastDistance_m63BCDCD92B9E27CB3B967D7942B38DE5B60B26C1,
	XRRayInteractor_get_rayOriginTransform_m1E25B9D203ABF076A179802DC530B2A3137232F2,
	XRRayInteractor_set_rayOriginTransform_m615A2661622EC41AC56242329D3ED7AC681AB289,
	XRRayInteractor_get_referenceFrame_mDA09B1E0E001EFE89607F065B032F92729B5323D,
	XRRayInteractor_set_referenceFrame_m7AF2D18BEB12CE4C215AF25D53970778E02D9B53,
	XRRayInteractor_get_velocity_mC30B6466EDEA67F4CB76157FBE64DC9721A4609F,
	XRRayInteractor_set_velocity_mCCF6C243466B1646E2C08915D3315F22BA4CFCED,
	XRRayInteractor_get_acceleration_m795393467FD40A04E5BFD13A8A35F05C9AAF0493,
	XRRayInteractor_set_acceleration_m5FD2D0617C088F3829D1569DD40B8ADF8FE74FBA,
	XRRayInteractor_get_additionalGroundHeight_m82BE02908177DB7B59DE24D22D5E51350F18E7D3,
	XRRayInteractor_set_additionalGroundHeight_mE2977A1FD487B14A4FEB971A26F030F95C1816B6,
	XRRayInteractor_get_additionalFlightTime_mA73DCAC70D780715D3C79888D97BE7BC52FA145E,
	XRRayInteractor_set_additionalFlightTime_m439C1605D143999EC6124A6650F2EC40E786BDE7,
	XRRayInteractor_get_endPointDistance_mC3B7A8459DA824BCEE794196532AD07494B44704,
	XRRayInteractor_set_endPointDistance_m824F8D5F8D12D185A5E0DB9C333B19BD8DB92399,
	XRRayInteractor_get_endPointHeight_m2BF3923091F4C4C2C7F8DB03973E192EBAB5D994,
	XRRayInteractor_set_endPointHeight_m3D1E99D32A678C433AFE0DD335308301669FAF1F,
	XRRayInteractor_get_controlPointDistance_m943999A8F649AC0EB624C41C43B7CB65E712D399,
	XRRayInteractor_set_controlPointDistance_m167046E23C6C56911AF5D1791DA6AAE7B8B044CD,
	XRRayInteractor_get_controlPointHeight_m22D1E8077AADC14CD6B5BEADBB3218B0D5A9D11A,
	XRRayInteractor_set_controlPointHeight_m75D2883EEB5BB7E457B6C7118A4277E4D1D76F28,
	XRRayInteractor_get_sampleFrequency_m84137E62F2F5D869D915166F5C9CAC51279C333A,
	XRRayInteractor_set_sampleFrequency_mEA325242F6BD6109D4A66BD383373898EED50483,
	XRRayInteractor_get_hitDetectionType_m56489A2A9D1D4B46E76AB06B1BBBAD0B64DE5712,
	XRRayInteractor_set_hitDetectionType_m1344C3C4EF7FD5AD4460680D9272C15E1DC6FEC4,
	XRRayInteractor_get_sphereCastRadius_mB224B23B50CADB816FF38A8BB8E61E2F1E574CF6,
	XRRayInteractor_set_sphereCastRadius_m125335531C37195BA247DC1319ED3BF2035461A7,
	XRRayInteractor_get_raycastMask_m02C2CE6B9DAFA5AC0B6FE84A580AC7269A989C36,
	XRRayInteractor_set_raycastMask_m9584267773FB9BEBD2F0D530461BAFD4772B15D6,
	XRRayInteractor_get_raycastTriggerInteraction_m958C93F2AF2B349DAA54FBF3F36EA1584E5F1122,
	XRRayInteractor_set_raycastTriggerInteraction_mA28B34B3E8AF9E8F1EEBE58A2603AC584C135D0C,
	XRRayInteractor_get_hitClosestOnly_m805AF397E71FE0E26E22DB3BC2C16E667B30EA3A,
	XRRayInteractor_set_hitClosestOnly_m7C2D5C87EE3BF70943827C44A3D2DE87C0F949F9,
	XRRayInteractor_get_hoverToSelect_m8E990754FB4491BA0083639F657F31268EB553EC,
	XRRayInteractor_set_hoverToSelect_m768C5E42FE973AF304BB107647E20822FF575473,
	XRRayInteractor_get_hoverTimeToSelect_m5823C8CA027B591248F80778E536BCBA72225106,
	XRRayInteractor_set_hoverTimeToSelect_mD9161C16F6EDBB1CDCDD6DAAC043365B86AF1573,
	XRRayInteractor_get_enableUIInteraction_m50E1F190769782C0B3A07186CCB377C1CACD052B,
	XRRayInteractor_set_enableUIInteraction_mD9CCCEBED6763F747B471C754B0E59C6B2EEC66A,
	XRRayInteractor_get_allowAnchorControl_m51594FACBD4A49AAFC7353F65ED8240F4646ADEF,
	XRRayInteractor_set_allowAnchorControl_mDCA19C625E5D567B4D8BE11B600B8B6D90FA2789,
	XRRayInteractor_get_useForceGrab_m7D8E5B79255A824D546B669F39D505CF87925A56,
	XRRayInteractor_set_useForceGrab_m32748F17CD4BCDA71BFE9306D9973C7307769E60,
	XRRayInteractor_get_rotateSpeed_m537E0014CB47BBA3E12B33472F4529332EFA83AC,
	XRRayInteractor_set_rotateSpeed_m0EEA37A30E60ABF0C9B10ACEB3566A88465E16DF,
	XRRayInteractor_get_translateSpeed_mE5950FBE32CE216680DFDD6FAE859092A379CCEB,
	XRRayInteractor_set_translateSpeed_m2BE27E2DAEC0D40F829FD5AAEC11070DB16300C0,
	XRRayInteractor_get_anchorRotateReferenceFrame_m3C17045FE587675A05CDFE73D981F4AFA23E9B12,
	XRRayInteractor_set_anchorRotateReferenceFrame_m56F0F8C1CAF3C0EC632929B038483AAEDDB10348,
	XRRayInteractor_get_angle_mAF632F8978FF0387DC7A9EA05267D893BC2A160E,
	XRRayInteractor_get_effectiveRayOrigin_m55B8E8E664761C5362A94336DF2F67F58CFC9052,
	XRRayInteractor_get_closestAnyHitIndex_m6C80C28C657B13EE96C321CB596F2737B842C65D,
	XRRayInteractor_OnValidate_mE0D577E74BEDFBAB060630783AD10D294D42F505,
	XRRayInteractor_Awake_mD4EAAAFECF93D0F4D662C08087D24EAB6B21B109,
	XRRayInteractor_OnEnable_m2C9F1F1C87F0A767AEA9DF2BCF3407F37A4991B2,
	XRRayInteractor_OnDisable_m4DECBE5770DA2751AF8D08D070FC861BC7FD668C,
	XRRayInteractor_OnDrawGizmosSelected_mD67B665592054CCE75AB58A57481A4A0540B9333,
	XRRayInteractor_DrawQuadraticBezierGizmo_m16828B1E1140B9E9832F4BA6FA33329DA38BB512,
	XRRayInteractor_FindReferenceFrame_m4844393D835BDEE5F527C4AED3A6255D2F06C37D,
	XRRayInteractor_CreateRayOrigin_m2A57C20C49A3F578A70090642855EAF8D4D1AF2E,
	XRRayInteractor_FindOrCreateXRUIInputModule_mE330D81A83210C2997D860F4D419B39E048ABCC4,
	XRRayInteractor_RegisterWithXRUIInputModule_m2EE92ABC9177938118467CD455670533AA6DC486,
	XRRayInteractor_UnregisterFromXRUIInputModule_mE6AA25434D584A533536DB30CAF6C491AD45633A,
	XRRayInteractor_RegisterOrUnregisterXRUIInputModule_mF6580068667EE3E5AB1FC12112DB39B359BC3A95,
	XRRayInteractor_GetLinePoints_m0A66C8DAE1B16CC5A34788E2112AA3D5FCB2D5DA,
	XRRayInteractor_EnsureCapacity_mE8E8D17AD034BD24C158A6EDC7A7949DEA20D731,
	XRRayInteractor_TryGetHitInfo_mCC8B3B99CCA30572E3B29C7E9C019BD79E8B99BE,
	XRRayInteractor_UpdateUIModel_m9D7E4BFD4DDC1932D8F70BCECF4708B9E10B3FE2,
	XRRayInteractor_TryGetUIModel_m5A62C29FAE2BFE162FF9FB1B81C79D273CDCCD58,
	XRRayInteractor_TryGetCurrent3DRaycastHit_m3B0B4ECA2D4B2786F08B42F1BA327D63706BB060,
	XRRayInteractor_TryGetCurrent3DRaycastHit_mAA8EF4BE6DC36D08FBB27625B19932826D1EEBEF,
	XRRayInteractor_TryGetCurrentUIRaycastResult_m51500817ADD5ED072A6AB56F324BC3F501DEFDF4,
	XRRayInteractor_TryGetCurrentUIRaycastResult_m291ECE81D6B7582175946E2E70A31E6C88D7E132,
	XRRayInteractor_TryGetCurrentRaycast_mF6C0E3DE22A6CF5FD8777CC2837C3F79E215E5F3,
	XRRayInteractor_UpdateBezierControlPoints_m32476399E92C7D1118FD71446BC47906508685DD,
	XRRayInteractor_SampleQuadraticBezierPoint_m90C9882FEC10F1EE9925A4637CEDFCD4D3443F81,
	XRRayInteractor_SampleCubicBezierPoint_mD49879E296C290AFD84AC71CFB66C3AA83708095,
	XRRayInteractor_ElevateQuadraticToCubicBezier_m93EB3858AEB9EB176CE5EB9F34B1B2DF3A77930F,
	XRRayInteractor_SampleProjectilePoint_m805B768AC3DEA5EB8116CDD8FFF24924894A4896,
	XRRayInteractor_CalculateProjectileParameters_m0C33EABD7A60F32DB66E3C569E9D8A7F1CE76F82,
	XRRayInteractor_TryRead2DAxis_m0411C43079185297C2BA4986DCEFBD2572F7C18E,
	XRRayInteractor_RotateAnchor_m6CA24C650C70FCCC35CDDFDF07E8912C61005CA6,
	XRRayInteractor_TranslateAnchor_m491B098760F389BB13DD7660C75A3D3F3A8873B7,
	XRRayInteractor_PreprocessInteractor_m02BC9E78B3F2B6B2890980388E0E955D80FDF010,
	XRRayInteractor_ProcessInteractor_mB44555B7A4E1A1B9C1DB59F45685CC43119DD0E2,
	XRRayInteractor_GetValidTargets_mA53EDC8BC750BD42FF2CAB4DC6A84D7E2405048E,
	XRRayInteractor_UpdateSamplePoints_mDEDA5492A7F0C1E613C0F72F733D8919FD4F2012,
	XRRayInteractor_UpdateRaycastHits_m196A1AFACB4DAAE67BE11459AC4D80BA2CA04951,
	XRRayInteractor_CheckCollidersBetweenPoints_m855D3B039C534E465B3FEF624D8CFBC8DA588843,
	XRRayInteractor_UpdateUIHitIndex_m2A351D458844411CC5C147083FCDB32FD8EB1526,
	XRRayInteractor_CreateBezierCurve_mBF1A2D289709988BB88B6D5860AEF2B7132AE25D,
	XRRayInteractor_get_isSelectActive_m206586FAAB8EC9DA9B38230E326249258C7AAF37,
	XRRayInteractor_CanHover_m83C4143E4713D800E3650921204058CD0E29A597,
	XRRayInteractor_CanSelect_m6C48CE11344832B567F42EC86397252B83030D87,
	XRRayInteractor_OnSelectEntering_mB2B1497AA544B96A53440D9049B554C9FA44D4AA,
	XRRayInteractor_OnSelectExiting_m83151373B9CB8001E3EE4A79DF2151D3B4197458,
	XRRayInteractor_RestoreAttachTransform_m6C4F246238BB5DF30C37D3F35C03CFC55D3534F3,
	XRRayInteractor_SanitizeSampleFrequency_mF485E0CCC8D8E8E919B358A9C49BCC689A1528EA,
	XRRayInteractor_get_Velocity_mCD63C7939FBB4BA47614FA62F4DECF7C5D44A120,
	XRRayInteractor_set_Velocity_mB55BCA00A7DF34D49D13A83D4662B21E7E4BA88B,
	XRRayInteractor_get_Acceleration_m26D3B9D340ECB09BC42A91A1440DDE91ADFCCD65,
	XRRayInteractor_set_Acceleration_m3D085078F4375C5BA693CA1E935D11FB3B109B4F,
	XRRayInteractor_get_AdditionalFlightTime_mF3106B8247839BE357F725AE725C39B8FA1A1F15,
	XRRayInteractor_set_AdditionalFlightTime_m17B9E6D48289E2D0E87D821DBEA0D40DBC17963E,
	XRRayInteractor_get_Angle_mB917C6D7C9B61C705326E9C9C3F5E9C065AB790C,
	XRRayInteractor_get_originalAttachTransform_m878213826A5E8E8D42D348256F47AA993B52B57C,
	XRRayInteractor_set_originalAttachTransform_m628968BCB4571B08EC03FE401AFC37A326F80F4B,
	XRRayInteractor_GetLinePoints_m28A2F91AC58CDF03D4AAAACA499798D4E886221E,
	XRRayInteractor_TryGetHitInfo_m6B340EAA6F108EDC34C2004028CD87D0D0B93F98,
	XRRayInteractor_GetCurrentRaycastHit_mDCBAE2A7314764499EF43F973CFA848C7A2E6D67,
	XRRayInteractor_CanHover_m716D573DEC49A14606C4FD31B2DE42AE30BA0AD9,
	XRRayInteractor_CanSelect_m916F1D170407BF398BBC3CAD1FCD1458AC76E297,
	XRRayInteractor__ctor_mC79035FCCEC9CAAA160A4834B82D3E09C3423138,
	XRRayInteractor__cctor_m72311321B348BBFD73F73E61B25A439AAA11B624,
	RaycastHitComparer_Compare_mEF9D90C17CB04E5FE07303C5F8D4FC0F992FE8E1,
	RaycastHitComparer__ctor_mF4CD20A7FEB0D6BE43809FAA21EC3EE87798A8C2,
	SamplePoint_get_position_mF9D3DAA244F75823D675144E555BEAC9776CC8E6,
	SamplePoint_set_position_m7DB8D7915D8C065E2138825C1ECF29460A450633,
	SamplePoint_get_parameter_m3B1DB18CF168339E8153E33E2FC87983549940BB,
	SamplePoint_set_parameter_mBEAD6B1E02633C8CA26116F89AFDCBC10D3273F3,
	XRSocketInteractor_get_showInteractableHoverMeshes_mA13C3376AE7EC382FC9D3FE3D40F2CF937069C60,
	XRSocketInteractor_set_showInteractableHoverMeshes_m272B2E3F1A0DE579705D7E0D449D20567FCEC515,
	XRSocketInteractor_get_interactableHoverMeshMaterial_m4F7DC269C114A9B2D8AE22A3D0B0CF503D77BB12,
	XRSocketInteractor_set_interactableHoverMeshMaterial_m9228A178C2C0EFAB69382C078B599FC0229EC1C7,
	XRSocketInteractor_get_interactableCantHoverMeshMaterial_m7D51DD8B38B538CECE017115519004783602E2CA,
	XRSocketInteractor_set_interactableCantHoverMeshMaterial_m6B60D3C1A552AA62352EF47F6120599A0E05A27D,
	XRSocketInteractor_get_socketActive_m279A07381397CFA72029326EC820EDDC35C18410,
	XRSocketInteractor_set_socketActive_m63F82455B5998A4A68851C3CD6864147E6FDE95A,
	XRSocketInteractor_get_interactableHoverScale_m5915E69E6876CA574F17EFA91DE62C8913690AD5,
	XRSocketInteractor_set_interactableHoverScale_m633D3EE46EEC77B3ED8C642ADCB782E4273D81E2,
	XRSocketInteractor_get_recycleDelayTime_mE91A9F5EC67DDF587F5B93ADA2470289534E7A9D,
	XRSocketInteractor_set_recycleDelayTime_m8CF70510C2980DBEBD33DC01851EA17989D0EA06,
	XRSocketInteractor_get_unsortedValidTargets_m4791BE8637A59493A2F196731269FE9FBE2F43D8,
	XRSocketInteractor_Awake_m728DB8B4F55AFA12CC3D687C2110F2BC78291B55,
	XRSocketInteractor_Start_mD0A89E30DF8007E31B271E1846F6C6847D3CD59D,
	XRSocketInteractor_OnTriggerEnter_m13762BE126D57C1CC81D8C80222B48ED2554C73F,
	XRSocketInteractor_OnTriggerStay_mBD77351B76D9187648140A5F06229FF680D992CC,
	XRSocketInteractor_OnTriggerExit_m370FE0D3027D577166A1C89B7156AC423943F2B3,
	XRSocketInteractor_UpdateCollidersAfterOnTriggerStay_mE2762B59E6A798AADD446169E4E6EB2C719C7637,
	XRSocketInteractor_ProcessInteractor_mF5DFFB7FEC471C2783C6D58161C3B8135D6D2928,
	XRSocketInteractor_CreateDefaultHoverMaterials_m9A28D7BBCF909D05A6DBC5DC58FF5E162A12748D,
	XRSocketInteractor_SetMaterialFade_m512ACFE82C5B051448A4B5B737686BE919545B17,
	XRSocketInteractor_OnHoverEntering_mC37B527C1D74305B6CFD2DC256750559431111CE,
	XRSocketInteractor_OnHoverExiting_mB74BF3AF6152D71F3FF0BB3B20133A89829625C4,
	XRSocketInteractor_OnSelectExiting_m31DFB98912AA8B4C3CDAE3BD1DC34319882550C7,
	XRSocketInteractor_GetHoverMeshMatrix_m01CF4E9023D39BD70A32749885212E6BF37523AE,
	XRSocketInteractor_InverseTransformDirection_mA06E0ABA71FEB0A1E836636DA931DFEF8A9472EF,
	XRSocketInteractor_DrawHoveredInteractables_m3FBB4ABEA1AA9F751AF7DE4F988BCA1F676705F0,
	XRSocketInteractor_GetValidTargets_mE2F539502B602807FC850F4EE596AF5AA34260F7,
	XRSocketInteractor_get_isHoverActive_m8D9CD29DF67452E89C121AFA36726CC067C870C3,
	XRSocketInteractor_get_isSelectActive_m639D46E618AE693D40C7F9EBCE756204E9A7BDD1,
	XRSocketInteractor_get_selectedInteractableMovementTypeOverride_mC823C78833056F46E2F1ED83D10AC621408E6270,
	XRSocketInteractor_CanHover_mC11E4C207BD6D5C2436146D6730190861E82F460,
	XRSocketInteractor_get_isHoverRecycleAllowed_mB3F7E667E924A3EE7BD763A62B0ECDBE788041BB,
	XRSocketInteractor_CanSelect_mDF980B26B103D799D1D7A775B6F7B7BCAE1753D1,
	XRSocketInteractor_ShouldDrawHoverMesh_m804C0F4ACE8D7225A0AC0FCF769FE724747B3445,
	XRSocketInteractor_OnRegistered_mDA4725A07484B6E5B652271481629A503410A6FE,
	XRSocketInteractor_OnUnregistered_m692446CD32442D8402070097B53C708E4B8E9493,
	XRSocketInteractor_OnInteractableRegistered_m9F6CFAEE4375AFD39BB7E6118FDD5A1D35A89C57,
	XRSocketInteractor_OnInteractableUnregistered_m8B22001876BF4F03AC42C85F5B0E5E13E9A8A602,
	XRSocketInteractor_OnContactAdded_mFB2698788AF6FF8A135AFF77141E8F3300D66094,
	XRSocketInteractor_OnContactRemoved_mB0529B0AAE3A02A975B24614DBC21B379CB23CAD,
	XRSocketInteractor_CanHover_mD06D9A7A3E164FE555F88B874F8FD5412E178C52,
	XRSocketInteractor_CanSelect_m3EC7D7A0594FB1F3E602DAD01E1DD8A3DE323BC5,
	XRSocketInteractor__ctor_m5976C30C655C920BB7D715E7703471C2695DC48B,
	XRSocketInteractor__cctor_mDCA455BA7F7550272F36D6936329DF647F5B9154,
	ShaderPropertyLookup__cctor_m1A59E24DA3A24CE183DF3916009DE66C992A5A6C,
	U3CUpdateCollidersAfterOnTriggerStayU3Ed__38__ctor_m6E5C86A23AD575C538B8349A7C97D790B44D6190,
	U3CUpdateCollidersAfterOnTriggerStayU3Ed__38_System_IDisposable_Dispose_m35DB36F4FD9BAE666D067BABF4DA9CF7801AFD2D,
	U3CUpdateCollidersAfterOnTriggerStayU3Ed__38_MoveNext_m89AB7549E7DD618512E2A8F916364BE317FB9B1B,
	U3CUpdateCollidersAfterOnTriggerStayU3Ed__38_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mA53C39E84D14DC4A3BE1AC43AAFB7A8AE7D3AFED,
	U3CUpdateCollidersAfterOnTriggerStayU3Ed__38_System_Collections_IEnumerator_Reset_m286FBDD6AE03892803862915F5E2B23AF55BBD7A,
	U3CUpdateCollidersAfterOnTriggerStayU3Ed__38_System_Collections_IEnumerator_get_Current_mB7B81869F309CE1962760101F8247DC63334C5FB,
	InteractionLayerMask_op_Implicit_m08C4E510BDA50EADE9029D9FF0D811ED7E1C8DB7,
	InteractionLayerMask_op_Implicit_m0CA28CDA57CD4D9EE8A9881078BD4546D0D93F26,
	InteractionLayerMask_get_value_m1DE10E281BAC55AC711581379777370B8D0EF4AF,
	InteractionLayerMask_set_value_m59C5C67FB2CC2DCC65CD752B56F3B74E229899E4,
	InteractionLayerMask_LayerToName_m41AB95A8FBC26C037B4A245D22B01CAD3094D8F6,
	InteractionLayerMask_NameToLayer_m66F30E9BE29227B5430F9351ECB47FBA2B186A0B,
	InteractionLayerMask_GetMask_mCC20AFA8EF6565328C4F137F19E2F20740A6D4A9,
	InteractionLayerMask_OnAfterDeserialize_m3FDFE3DE357CFE1B8558ED7BDEC7DF4542BE4C58,
	InteractionLayerMask_OnBeforeSerialize_m673AD8B8D37CF455D65F3D6D3C8AE04C0C68D901,
	InteractionLayerSettings_GetLayerNameAt_m94BF99E7DE7503FB3FBF45A46BBFAF639D98B645,
	InteractionLayerSettings_GetLayer_m2185EA5B60D38B1FC61C94A23525C38D7C198363,
	InteractionLayerSettings_GetLayerNamesAndValues_mDA223C0C1FD17B21EF0229E8025CD306935189E3,
	InteractionLayerSettings_OnBeforeSerialize_m8FB5F44C3F90306B0D6F8730A7C536BB83B78B86,
	InteractionLayerSettings_OnAfterDeserialize_m25C6D4D26CCB1151473724E4651617B54ABFD4AF,
	InteractionLayerSettings__ctor_mCF7AF5E963C37818AF6B842DAC8D013882DA21CE,
	BaseInteractionEventArgs_get_interactorObject_mDC483F1AAA1267A774B677E14189A3EDD1040864,
	BaseInteractionEventArgs_set_interactorObject_mAFCA4A8A7569428E3B2ADDBBCA1B98EE9D54B1D1,
	BaseInteractionEventArgs_get_interactableObject_m26541C3E132246CFFA125A00BB3605DB8E3F72D3,
	BaseInteractionEventArgs_set_interactableObject_m666E479700814D51AB92B1A2279D30B7D91117D9,
	BaseInteractionEventArgs_get_interactor_mE0AC419B526DA1A39B56DA244258474047DD0176,
	BaseInteractionEventArgs_set_interactor_mD8877C3687E32637F0E1F67F83B4B0B8AF91C649,
	BaseInteractionEventArgs_get_interactable_mE03A040C395B75F0EB35E1CE5371458C1345BD45,
	BaseInteractionEventArgs_set_interactable_m2F82CCB58107BAB47A77981E751779A7A4FA3266,
	BaseInteractionEventArgs__ctor_mFBE9F5A938004146A92AFBA8FC7382B4CE7F7995,
	TeleportingEvent__ctor_m6500A5219DA0E3B6C0BD6B6FBA212E6968AAB2AD,
	TeleportingEventArgs_get_teleportRequest_m826263B8C3497EDADB982081053273A9F35AA73E,
	TeleportingEventArgs_set_teleportRequest_m7689B96CF5C675E696667AD065575DBE5EB41A0D,
	TeleportingEventArgs__ctor_m99DD9DD2A593D6838DAF382428A3FC9DB4352C92,
	HoverEnterEvent__ctor_mBA15FC5A5D70A50E4508C1AD60B798C433520D5C,
	HoverEnterEventArgs_get_interactorObject_m9735CAB1FCE64F6DD65498458C582463A0FB5D19,
	HoverEnterEventArgs_set_interactorObject_m938429D32D4E2C1771EDA7A6FFAE91F6928946B2,
	HoverEnterEventArgs_get_interactableObject_mF3402C9ABF2BBFBABE7847BD3F97DA76DBB047E0,
	HoverEnterEventArgs_set_interactableObject_mF7B2CDEFA249D49A8C9CD38D4880843D30EF3B7D,
	HoverEnterEventArgs_get_manager_m7BF0809EFB35384B071E9F1749BD918F9B8EF9C4,
	HoverEnterEventArgs_set_manager_m158A6A9C6E07649471E84928B795E07528C824AF,
	HoverEnterEventArgs__ctor_m64B2FD3D0E28418D562AB3E809D4D41FB73B61F5,
	HoverExitEvent__ctor_mC6DCAF3BA7DD1BF2D25E0E94D1DFDF8BB69F6599,
	HoverExitEventArgs_get_interactorObject_m0018175DBF0540C147451C1E11B5EE5DA64CB150,
	HoverExitEventArgs_set_interactorObject_mCABC016A89E81C1CB36A8B1EBE4E8B6CCCD69ED7,
	HoverExitEventArgs_get_interactableObject_mE6E7CF97FC9B0F33216BC872B5574A5D367E654C,
	HoverExitEventArgs_set_interactableObject_m12E7E0DCFCBF9A059844083C911DC1CADF177F52,
	HoverExitEventArgs_get_manager_mFDACB06544FBF52A43FB64EC4BCDCFAEAB40AAC0,
	HoverExitEventArgs_set_manager_mA18E069893E2011A5DC128198EBA4E504D7F8D3C,
	HoverExitEventArgs_get_isCanceled_mCD404A43E8B419E9C4A66AE69F74CBF4840B80FF,
	HoverExitEventArgs_set_isCanceled_mD30ECFAFDE30B96DB1C4BA30800D72D6CC31218C,
	HoverExitEventArgs__ctor_mE583F8ECA5AA5CD5766A4819840CF8AA29473223,
	SelectEnterEvent__ctor_mBD914CC3077CB09488C19CB000BF84A8CF4075FA,
	SelectEnterEventArgs_get_interactorObject_m97F5CFDD451F9E85F5B92FD2B3E668A43B1C146C,
	SelectEnterEventArgs_set_interactorObject_mD6F6E386DB5DEEEB5D8E10D39781726C63CD5C3F,
	SelectEnterEventArgs_get_interactableObject_m1BF44240E99A894B17EE07BBBC4B6AA6D1058DD2,
	SelectEnterEventArgs_set_interactableObject_m47DD9FF8C3D93D8DE88E40EAA071D11DDBFC0718,
	SelectEnterEventArgs_get_manager_m26C686181BAFB4304EBA14BEDB47C75D9826B7E4,
	SelectEnterEventArgs_set_manager_mAB91B3764075B4953BBEED2CFDAC395CC624C7D9,
	SelectEnterEventArgs__ctor_mE74661F8720305C7C924ADBA1766057084A1D264,
	SelectExitEvent__ctor_m3F1845BDE2ADD85BE5B34309656DE33AB8BE65AC,
	SelectExitEventArgs_get_interactorObject_m395880E1D46E6008A4AA90836393E4F1E39CAAA3,
	SelectExitEventArgs_set_interactorObject_m5C1FF7816358E5BCB016ED0C7DCA5725C6BAA8F3,
	SelectExitEventArgs_get_interactableObject_mDF1FCDA090159514365D791FB3DFA9A7CFE634B6,
	SelectExitEventArgs_set_interactableObject_mED2657D7556DD5E69DEBC70668C9A47C7444954C,
	SelectExitEventArgs_get_manager_m0EC8623D5F0EF3296433E5F3E2FD0F6F3D42B387,
	SelectExitEventArgs_set_manager_m041398DAAD78BF90C51FA159C8213120F25A0D88,
	SelectExitEventArgs_get_isCanceled_m4C9FCCB6A51201B8728DAF9BA356BB589A149FF7,
	SelectExitEventArgs_set_isCanceled_mCD4C4244EBD5D443FD62B581F29FF05B2751AF42,
	SelectExitEventArgs__ctor_mF2917F17EA7F2AD8B1698AE1E4D5C3B9F0225A69,
	ActivateEvent__ctor_mE03DD9A189FB311D8AC4BD2C02D4E5E29C66CFA3,
	ActivateEventArgs_get_interactorObject_mCE290719C5F47593EA43F4B6D015BD62D9886E1D,
	ActivateEventArgs_set_interactorObject_m2E18040B549E170B89EA2E4CB67E840BC02FB3BA,
	ActivateEventArgs_get_interactableObject_m4C814BF602A7E2B5043E1EB1B817D64BCDD5EA1A,
	ActivateEventArgs_set_interactableObject_m199252718AAFBFEF9360F92A3CEA925584B1CD53,
	ActivateEventArgs__ctor_m0F13A7B797CD0F08C6C81FA05374157ED0174798,
	DeactivateEvent__ctor_m35BFEF1CB25E0CEE6C6D7D6A06B70EB9D9B141E1,
	DeactivateEventArgs_get_interactorObject_m8469FB820E50EC9170BB9C503EE34577D8DAB537,
	DeactivateEventArgs_set_interactorObject_m441ECC2F19258EF07AA11FBAE0BF0C147DE32332,
	DeactivateEventArgs_get_interactableObject_mF441ABDF82A16D6182D9DF8B7DC01E2B04DB1926,
	DeactivateEventArgs_set_interactableObject_m32D35955F889F3E9337B58CA5E489D7E20321772,
	DeactivateEventArgs__ctor_m7CBB9F171A35CB64534F7B9306D93F337FD2582C,
	BaseRegistrationEventArgs_get_manager_m84ED1D40C6386160D7158A59481F70348DD48413,
	BaseRegistrationEventArgs_set_manager_mDCA0E4515B5577A245206663B79F1BD793865AA5,
	BaseRegistrationEventArgs__ctor_m161AA13E866857D922FA734ECFC87A1A3915D681,
	InteractorRegisteredEventArgs_get_interactorObject_m3E9876ECB8E6998EBFBA8A28CC57E70B77A84A1C,
	InteractorRegisteredEventArgs_set_interactorObject_m0796FE5FD1653517D293F08CEC51B21B2051C557,
	InteractorRegisteredEventArgs_get_interactor_m5941F52A62289266C834D92590783488A171FAD8,
	InteractorRegisteredEventArgs_set_interactor_mC7D4F7F96D374D0689576F9781A8059692A21B17,
	InteractorRegisteredEventArgs__ctor_m1CEEB1E90C5E36396D47DEE555CA51EAF67E51A4,
	InteractableRegisteredEventArgs_get_interactableObject_m895A23B809D8B0DA415F16C644A4A4B93A8EB87A,
	InteractableRegisteredEventArgs_set_interactableObject_m0986611CA5A508142C0416D8EB09C0893916E3FC,
	InteractableRegisteredEventArgs_get_interactable_m8E24757B1B66EF6ED74A2BCC89A63E10364E7C6E,
	InteractableRegisteredEventArgs_set_interactable_m8FAF324ECEAFDB5BD64BE2D71A991B9A3FDACBB4,
	InteractableRegisteredEventArgs__ctor_m822E9B17C5624FD5DAC56EDDB45B0BBC559ED753,
	InteractorUnregisteredEventArgs_get_interactorObject_m6CC2A62AD00F985B8AF1E3EAC388F17966ED20B8,
	InteractorUnregisteredEventArgs_set_interactorObject_m0D221058BC2E3F511EC39CECF4C26BB5A5A57FB0,
	InteractorUnregisteredEventArgs_get_interactor_m850F10AA69039103E6E674733DB4CA93C4369E65,
	InteractorUnregisteredEventArgs_set_interactor_m06E8669E5C820661A28255E6983ECD6FE607B4E9,
	InteractorUnregisteredEventArgs__ctor_m4A66D6EAF8334F6DB39B8C23D81FF3641910F98F,
	InteractableUnregisteredEventArgs_get_interactableObject_m741DCCDBE1F7476E90F779B28768D86CD0BD02D0,
	InteractableUnregisteredEventArgs_set_interactableObject_mAD6A4A7E4190275B129316D796F2DFA1396E68C1,
	InteractableUnregisteredEventArgs_get_interactable_m6B266EFCEBB22E4EE3F3E1F86E9D3D2E6F9BCA05,
	InteractableUnregisteredEventArgs_set_interactable_m0433D6227E005137B947C8C68C7131B2D3F7E1BF,
	InteractableUnregisteredEventArgs__ctor_m06876C6525B6E04247181AE3D01F172CD6CF8A9E,
	XRInteractableEvent__ctor_mDDC1471E4ABA20B7E264547F4C6AF92D00FA373A,
	XRInteractorEvent__ctor_m1A2EDF11BD3670B83606D8416ECB4F84E55A31EE,
	XRInteractionManager_add_interactorRegistered_m326A4E8AB1DF06624D008EDC28711341CD3D8F1A,
	XRInteractionManager_remove_interactorRegistered_mF08538A5559BA84629940B3810F00DA55C01D259,
	XRInteractionManager_add_interactorUnregistered_m40D6A12AB95F14CF45A3EB93D5FEBFDBC240D712,
	XRInteractionManager_remove_interactorUnregistered_mC0AD12A62B1B527063B721395A2B252B91CAE5F8,
	XRInteractionManager_add_interactableRegistered_mA988BE3542F18F59BD66F16017DF19153DA7CF3F,
	XRInteractionManager_remove_interactableRegistered_mE2A574D88B059A17C482B057CFB632446D6537D1,
	XRInteractionManager_add_interactableUnregistered_mF868D7595D14DDA38D60F61249878B9E0E261E36,
	XRInteractionManager_remove_interactableUnregistered_mC4F1CD6073FFE6B6AB221522A1BEBE2CEE0E93E5,
	XRInteractionManager_get_activeInteractionManagers_m5A2A2413296876F10164C973358D57FA2B3EB1E5,
	XRInteractionManager_OnEnable_mC89EE86392CA1087C5C2D541F90A3FA9C521AA72,
	XRInteractionManager_OnDisable_m411C689A20C051276331AC5492824BA02891271D,
	XRInteractionManager_Update_m69F79C2139BBB77F7079EBFA048C66D60F7768C8,
	XRInteractionManager_LateUpdate_m5E2F8CF6300555B49625C955FA50C05528E28012,
	XRInteractionManager_FixedUpdate_m194833B9D47F1CF8AD543BDA15F619BFC9E80522,
	XRInteractionManager_OnBeforeRender_m58B0EE0C78D17A8A707D7CCE3FE52B17799551CD,
	XRInteractionManager_PreprocessInteractors_mB5B20D909FC78305180D0AD985239DC506735349,
	XRInteractionManager_ProcessInteractors_mC790B832EAC50F9C9FFDAB2559C8BD417D46E489,
	XRInteractionManager_ProcessInteractables_mC4E0C4ACA409D4912EFBE9FFFF146AE817AC7961,
	XRInteractionManager_RegisterInteractor_m8C87B8F7F17EBD37E43D42A0C2620E147273AF5F,
	XRInteractionManager_OnRegistered_m052F72C1CDD636EF1D93079185870F2B24D2DB02,
	XRInteractionManager_UnregisterInteractor_mDCA3EEA2C6C8C699E227F782012B9B1541D3E303,
	XRInteractionManager_OnUnregistered_m9396BB503AB65E22DDA0B45A8F22095B2F15B79E,
	XRInteractionManager_RegisterInteractable_m9515894CC5AE623DB9CFD0EC915A0EB8FE240A61,
	XRInteractionManager_OnRegistered_mAB7EE4460DCF09AF516883DCF9680B185A9CEDE7,
	XRInteractionManager_UnregisterInteractable_m7DCFBDBCAE2547B55467306C3A3543FECB276656,
	XRInteractionManager_OnUnregistered_m4B2BACB59BFB2070B6A8EE045CA4347557D6ED45,
	XRInteractionManager_GetRegisteredInteractors_m10AC6F729264FDD9B6323C7643C2744E08327613,
	XRInteractionManager_GetRegisteredInteractables_m5255C91F428D890463EC1FDC3273425FC82A2679,
	XRInteractionManager_IsRegistered_mF4665ACA0886A1A9A487DFCC217910F4F9037D52,
	XRInteractionManager_IsRegistered_mB4839EFE423FAED99D27FDB6764841406FA485B3,
	XRInteractionManager_TryGetInteractableForCollider_mB5101149B97FD28DFBA42F84643F8549DDB5E607,
	XRInteractionManager_GetValidTargets_m2466547EA6CE2E4DF08784B06C05D9CEBF4CDA7C,
	XRInteractionManager_RemoveAllUnregistered_m49A04CA0816252EFDBD5A183CC04CF250574299A,
	XRInteractionManager_ClearInteractorSelection_mB789D725484039BB950C19F9B9331F396CE2C90B,
	XRInteractionManager_ClearInteractorSelectionInternal_m3310F9804E31A21A99B7AF471033858320381E53,
	XRInteractionManager_CancelInteractorSelection_mC4602F60D28368A064C9245C55316091FF8C4CB4,
	XRInteractionManager_CancelInteractorSelectionInternal_mA0AA3511DE00DA2208184D1E1AFB19362E66B310,
	XRInteractionManager_CancelInteractableSelection_m7500B2BBDA9BF8D3F3F13B1562FE0276F5F1F18B,
	XRInteractionManager_CancelInteractableSelectionInternal_mFF3CC0C7309D5B5EA8C15F51B0B389EAE2D589AC,
	XRInteractionManager_ClearInteractorHover_mA70FFCE292B94A7B0C956D4783F89879A46415C2,
	XRInteractionManager_ClearInteractorHoverInternal_m1FDD875CA52E7B681BB601E5B9F415591391CD53,
	XRInteractionManager_CancelInteractorHover_m5D264DEC8ADE1699F64A48D2103F70A8A57DFFEE,
	XRInteractionManager_CancelInteractorHoverInternal_m040DAF03B7D617F528881C5F09F204A0224374AA,
	XRInteractionManager_CancelInteractableHover_m465C60DD72290629AE5A72FA6D7C1CE628ECA958,
	XRInteractionManager_CancelInteractableHoverInternal_m48DF98EA13ACFA3F445A2335590D7F2AE27E1E75,
	XRInteractionManager_SelectEnter_mF8B22B192B55DA4E15F7716A3731768EB52F2AA3,
	XRInteractionManager_SelectEnterInternal_m0E03175D0A8B4187C1E03A5E63149888EAE90A96,
	XRInteractionManager_SelectExit_m5580A661ABC461675C2165F10CD4BB487DA9E115,
	XRInteractionManager_SelectExitInternal_m5C44EAA94101D3E89B79DA54E1D4CB0E2E75F388,
	XRInteractionManager_SelectCancel_m8EB7643E80920812BBADA58F9A2E590380E359CD,
	XRInteractionManager_SelectCancelInternal_m1310F0C8B5464357CEF28D5ACC8D3654ED2901D9,
	XRInteractionManager_HoverEnter_m85C0AAF57022AFB537F4EC3466A0DE17255FC77D,
	XRInteractionManager_HoverEnterInternal_mABA0AF49B01D92FA3280DA2C5D06C4299351E1B0,
	XRInteractionManager_HoverExit_m6A17CAE72E9E759090CFDF4945658DE1F2CAB353,
	XRInteractionManager_HoverExitInternal_mA04E07537F5432EDA074C978EDD03995FA7F650A,
	XRInteractionManager_HoverCancel_mF8AFE99481CCD532A3AE04D9656C03DB6512B944,
	XRInteractionManager_HoverCancelInternal_mE3A078E4359E689692560B16A80F08B569BE9E6D,
	XRInteractionManager_SelectEnter_m43375FE6AB714D1892E58E47D35B86B69D21E009,
	XRInteractionManager_SelectEnterInternal_mE9A3C30C0E7FB661C1F9CBFD8B5625DC073E799C,
	XRInteractionManager_SelectExit_mA05F49C3A13F5EA4E31277F0EDCD62FD9B847E73,
	XRInteractionManager_SelectExitInternal_m2EF03B4FF4EACFA7AAD582F36A2B7E6F6781A65B,
	XRInteractionManager_HoverEnter_mA15A2FBE71141DE2B305D1E359C53D570959B01A,
	XRInteractionManager_HoverEnterInternal_mE2801FEEA5F1CEAAC6F8408D2FE83C7488AB6B05,
	XRInteractionManager_HoverExit_m5BE01EDFAF1F7376931F89ED09F48851F9FAE22E,
	XRInteractionManager_HoverExitInternal_m3EEFFA9BFEC5D1FAB7922B50013E69B652EC6C45,
	XRInteractionManager_InteractorSelectValidTargets_m74CC380537EBFDA2F2DC005767F586D3B3B3A48D,
	XRInteractionManager_InteractorSelectValidTargetsInternal_m48BB2DDD65BE3AB16D4CC34AEC143C1C387B04F8,
	XRInteractionManager_InteractorHoverValidTargets_mD5B7DCE67E8AD408AE3B20C234905C7BB207482B,
	XRInteractionManager_InteractorHoverValidTargetsInternal_m8203987A0F3C52AD1A1515AF74B2AA6F187603AB,
	XRInteractionManager_ResolveExistingSelect_mDA56D2DF7249BA2C008BCE9D3400E8F60D7BBA69,
	XRInteractionManager_HasInteractionLayerOverlap_m5239C2DF235560F65C389F4C7ABD977C9BFE614E,
	XRInteractionManager_ExitInteractableSelection_mC77FA22A8A7087E937A4B92CF616D412E7AE299D,
	XRInteractionManager_FlushRegistration_mD3A98438B16A1A1CF88A66E6935578619C60251A,
	NULL,
	XRInteractionManager_RegisterInteractor_m291902066C1A64C6CD0D0557B831990414E0CBDA,
	XRInteractionManager_UnregisterInteractor_mCFC04749344C221B072AEA031A03E71187F1C238,
	XRInteractionManager_RegisterInteractable_m47116DD86C0C734E3E9646AB2AA85DB74113F37C,
	XRInteractionManager_UnregisterInteractable_mA97A2CFE958FB7F05A6F9E57B2EF10315A3480CC,
	XRInteractionManager_GetRegisteredInteractors_m0380C9C368C156CA43AF42C0591E1DE07CB5D675,
	XRInteractionManager_GetRegisteredInteractables_mDFF6CDD0AF4CFE2C1AA54011D5F42C7CEE1FE532,
	XRInteractionManager_IsRegistered_mF3B3EB4CB278C9BCF8589AFE0EB3A416EEBB6CF2,
	XRInteractionManager_IsRegistered_m65C28B573DBC80DE8DBD06206B7F9AC60E3E4C6F,
	XRInteractionManager_TryGetInteractableForCollider_mBAA4EBFE6CEB2D28B1EDE2C333CFED8A3ED4709D,
	XRInteractionManager_GetInteractableForCollider_m546BE05EAB715F319718D1A173325A8EE87EAD25,
	XRInteractionManager_GetColliderToInteractableMap_mB5A3282DA7AB1E69B50E94C768A6EF7914C15478,
	XRInteractionManager_GetValidTargets_m682F8B8F1BB671DADE1CC90A262ECEBDBA3DD49C,
	XRInteractionManager_ForceSelect_m80E8A7B047D0665E564212CF8D0362A5E7DB26A7,
	XRInteractionManager_ClearInteractorSelection_mB18301D8B367C0EC84A5F10C2E41AFB0BF77A2F9,
	XRInteractionManager_CancelInteractorSelection_m43232207EDF5EF8FF4063F3B7865639C64014A87,
	XRInteractionManager_CancelInteractableSelection_mC6D2D4BB81E6540886DA49A7A67EA14E2EC680C4,
	XRInteractionManager_ClearInteractorHover_m9D87C101D59A96346A0A735EB244433ABA3DB556,
	XRInteractionManager_CancelInteractorHover_m5B85342A7F9360C9482A771DD5D73FA620AEF7F0,
	XRInteractionManager_CancelInteractableHover_m0B6B797908BA79D6626DE41951C13EB85F09143F,
	XRInteractionManager_SelectEnter_mD730B42373CC3C4A71B53BB79EDEF0B9598D96C2,
	XRInteractionManager_SelectExit_mFFB8E8B5FC957BCF99BC2F4D007643A416FE71D8,
	XRInteractionManager_SelectCancel_m68A36B47E48F294ADC6128D763EDC9F3D73266BD,
	XRInteractionManager_HoverEnter_m11CCF7D0EECDE1D6F8F6E1B7EF5730806D6A1B1E,
	XRInteractionManager_HoverExit_m6880CADA950FEAC8F7B6027D78189BA787AB9458,
	XRInteractionManager_HoverCancel_m57F0EB47090B391FA9AEA4E2BBB417C6CC93C9F0,
	XRInteractionManager_SelectEnter_m9F21AB38B8090B0D2EEDCBCB24A6BF83F53F4011,
	XRInteractionManager_SelectExit_mFF618D4F47C3CCDF4BBC7FB78D7DF57A980DE8C7,
	XRInteractionManager_HoverEnter_m3E7765D447A8F4CCF1F731EA850AA85644609E21,
	XRInteractionManager_HoverExit_m99E3E05573C2F4438E51A209934BB5EF4510AB59,
	XRInteractionManager_InteractorSelectValidTargets_m53D39B4C1EC70D1F918D5C10BA27D3088B6ED7F3,
	XRInteractionManager_InteractorHoverValidTargets_mA35E677C2AD9CED7637B75A1753BE0DF8CF84630,
	XRInteractionManager__ctor_m33B9DE751643CC7A9CDCA18704DD2CFC8C2A47BA,
	XRInteractionManager__cctor_m8FACD8A6CE2EFF761C03AB0A86DAAEC8417F50D6,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	U3CU3Ec__cctor_mF43E7E4E77ED998249A496778372159A22783920,
	U3CU3Ec__ctor_m0B1FCFBA75EAE8D29D2D4BE3567A2C4B299A3857,
	U3CU3Ec_U3C_ctorU3Eb__143_0_mC261DA412A44037B60CA1234E47AC0D768881C67,
	U3CU3Ec_U3C_ctorU3Eb__143_1_m76CA5C4990FD08FF3FF21DA3E8CD85604F7F2F30,
	U3CU3Ec_U3C_ctorU3Eb__143_2_mAF90E6B53C81EAE2CBC8C0DB5D3C63E27BC9A3E0,
	U3CU3Ec_U3C_ctorU3Eb__143_3_m2E12920EB733B1D61405C6A44B8A7E5DFD226AB6,
	U3CU3Ec_U3C_ctorU3Eb__143_4_m7B8F529C669EB8EC0113ECF6C6A382010E1464FE,
	U3CU3Ec_U3C_ctorU3Eb__143_5_m3B897464528D51EFB1F67F1ADD963F76DCDD5C6D,
	U3CU3Ec_U3C_ctorU3Eb__143_6_mB0A321045292EDFA888CB76107E1F611C1B4E273,
	U3CU3Ec_U3C_ctorU3Eb__143_7_m56BC24B08723AD31FAC4F591C5EDEC1701549E5F,
	CharacterControllerDriver_get_locomotionProvider_m832426BACE3C1BDC3018D7B1DA87F33ADF3EF7A6,
	CharacterControllerDriver_set_locomotionProvider_mC5E56C97BBC05EE1ECCC28088B49A3EBB1B05A3A,
	CharacterControllerDriver_get_minHeight_m26E0DDB8EC35F9568751F364BBADFA5EBF84B706,
	CharacterControllerDriver_set_minHeight_m04B4E59CC6A1CA42E3A6F7CBD114D3D13019E938,
	CharacterControllerDriver_get_maxHeight_mA992C84A42D96607A5AED26E850C4B3D8092A0D5,
	CharacterControllerDriver_set_maxHeight_m756CD8A723605CFCEEC322AE624E694F33441DFE,
	CharacterControllerDriver_get_xrOrigin_m20D41C4839F146E7CB2B1AC9E2D9D2CE968B49FD,
	CharacterControllerDriver_get_characterController_m0CFBBECC5698525CC38657D490F6B1FD36E5F325,
	CharacterControllerDriver_Awake_m20B28E81716B563EC32B5EC3A7A387C492E8F213,
	CharacterControllerDriver_OnEnable_m701B823C384A3331E6F7FB701607672BAA7ADC3D,
	CharacterControllerDriver_OnDisable_mD76F600A9E78338A2CF7027C625958C27B61A2DD,
	CharacterControllerDriver_Start_mB21C2A78801CA14CCA3ABF9E8ACB412626846670,
	CharacterControllerDriver_UpdateCharacterController_mD0DBBA9B0393708F017DCF4305245307011A6760,
	CharacterControllerDriver_Subscribe_mD02046724D31A50E465795C29C463F8F42E35565,
	CharacterControllerDriver_Unsubscribe_m9EACB74F852F90A861C7983CDFB425F5B99DFC14,
	CharacterControllerDriver_SetupCharacterController_m3259E81F5099D6F5A91D23EC016C25FD173547A0,
	CharacterControllerDriver_OnBeginLocomotion_m524111528FE7083D44800E28EA2CCA0C7F4CFC6C,
	CharacterControllerDriver_OnEndLocomotion_m0FAAE4B4A7D0B5B4DF84D04C8AF737D78C92EB7B,
	CharacterControllerDriver_get_xrRig_m511BE884B2E3510BD714FF7C3FF5EA5332EAE0A4,
	CharacterControllerDriver__ctor_m51FA99929552C3ADB304E663BEC0C528C701E386,
	ActionBasedContinuousMoveProvider_get_leftHandMoveAction_m1A3CE1F7AFE741716F8CABEE541C67DE5E16C64B,
	ActionBasedContinuousMoveProvider_set_leftHandMoveAction_m2F74B31226292DBBF6932160F6DB596217E8028F,
	ActionBasedContinuousMoveProvider_get_rightHandMoveAction_m798EAE65B649189963A7A35D4084FE9B28618490,
	ActionBasedContinuousMoveProvider_set_rightHandMoveAction_mF39B0E3E9C73287445C2D48CC10B89EDD1593D01,
	ActionBasedContinuousMoveProvider_OnEnable_mA9B8E570972B0F2F18EAAC3F64A94616C7ED1AC5,
	ActionBasedContinuousMoveProvider_OnDisable_mC6999757EB98EB241640A71ED8C9CB52C850F065,
	ActionBasedContinuousMoveProvider_ReadInput_m06114221CD3B7CC7998B19DEE88DAC1C9B6B057E,
	ActionBasedContinuousMoveProvider_SetInputActionProperty_m372EC1CCE4169CE641FD0DCBEE996DF11C35148C,
	ActionBasedContinuousMoveProvider__ctor_m1310A2218E70F36811987629965EF7BC0F356583,
	ActionBasedContinuousTurnProvider_get_leftHandTurnAction_m5BCCB053D1B00DC263CD37DC0C3C696BADE74AC5,
	ActionBasedContinuousTurnProvider_set_leftHandTurnAction_mDD02C10E24CE3DD53AE203369CC2B3C4F71F0E2B,
	ActionBasedContinuousTurnProvider_get_rightHandTurnAction_m2146FD4E90F61AA61299F06966E0B320C7C5B0B6,
	ActionBasedContinuousTurnProvider_set_rightHandTurnAction_mE42B3483F0532A56D4E23F3A89F98F1B242F5247,
	ActionBasedContinuousTurnProvider_OnEnable_m44BA623643961E42C10CE7B5FD41AD08CC8D9E89,
	ActionBasedContinuousTurnProvider_OnDisable_m956FFE42EF85B4C43C2B2CE858676B8F0247069F,
	ActionBasedContinuousTurnProvider_ReadInput_mD48398B9672DFD785926FB6B3B45EF799D6730FA,
	ActionBasedContinuousTurnProvider_SetInputActionProperty_m9DDF18609BB9EC477E7DC06DE67B3AB94A443977,
	ActionBasedContinuousTurnProvider__ctor_mA0E25E1DE63BFF2460D4A9BDF269A4A576D2635B,
	ContinuousMoveProviderBase_get_moveSpeed_m00ACE6C470CA370D6C6FEE014B6BF2D14C451DD5,
	ContinuousMoveProviderBase_set_moveSpeed_m6BC9C1AF5A210F6F2DCA2A40172B75C5F779C395,
	ContinuousMoveProviderBase_get_enableStrafe_m9758D9CDEB6112A8394AED688394C9FF8306E392,
	ContinuousMoveProviderBase_set_enableStrafe_mE7F22E383EA4CE1CAB919EF4FCF5E90E219A0DB4,
	ContinuousMoveProviderBase_get_useGravity_mA8680EF757EDE40AA7C53DA4B22A78DE0AE9625D,
	ContinuousMoveProviderBase_set_useGravity_mB589343669C70EAAFD0C7E679F82A97AFEA223E8,
	ContinuousMoveProviderBase_get_gravityApplicationMode_m006349EFCBDFB54D975269A4CDA53DF65D172A39,
	ContinuousMoveProviderBase_set_gravityApplicationMode_m0F358A25FD462AF9ED298DFB66F70C38856E7A66,
	ContinuousMoveProviderBase_get_forwardSource_mCA2A40CF7B059F8096B8DA7EE022417D5E9AA89A,
	ContinuousMoveProviderBase_set_forwardSource_mA1CBEB304ED21A5E919AEDBC38CAD176E23C9195,
	ContinuousMoveProviderBase_Update_m0A8CFF12DE7E3239FAAC9EB63A53577E4C44242E,
	NULL,
	ContinuousMoveProviderBase_ComputeDesiredMove_mDB77C9D41306941782F36D150B7CD774E1E3A702,
	ContinuousMoveProviderBase_MoveRig_m3793312F1A333B733E60E373DED0938CC8BF5DF2,
	ContinuousMoveProviderBase_FindCharacterController_m55140569E91D84284B2CC949BDBEB4A162F1B1CB,
	ContinuousMoveProviderBase__ctor_m1AB119E41778C58681F1785ECE37EF8270A24EA0,
	ContinuousTurnProviderBase_get_turnSpeed_mE485FB7889080A4924E65F7A3B5BDB73C53F96E0,
	ContinuousTurnProviderBase_set_turnSpeed_m0AB633C39385D76B8E67AC90B437C1B52D1B3E11,
	ContinuousTurnProviderBase_Update_mDB0CEC76A176AF26216BFA5EA9F1E22A5D0CE9DF,
	NULL,
	ContinuousTurnProviderBase_GetTurnAmount_mD19AF31C63223D9F9721D757C7A32FD1D0F674BC,
	ContinuousTurnProviderBase_TurnRig_mA600D2931DEB1C2D38A61A1E909412AB89230B48,
	ContinuousTurnProviderBase__ctor_mA41947ADBB4D280EC0EAB152CA5653FE7315B606,
	DeviceBasedContinuousMoveProvider_get_inputBinding_mDDE00466CC8BCE56238FD5430A3692F3506DF11C,
	DeviceBasedContinuousMoveProvider_set_inputBinding_mDC6908FBDCCD7D6085F21A9AD01765D8F02767D2,
	DeviceBasedContinuousMoveProvider_get_controllers_m34D4DC4440DF930E318BDE0E66A03B51D79C0CFD,
	DeviceBasedContinuousMoveProvider_set_controllers_mA94C7B5930A60D1467ACC361DB69CD62A8D2A8D0,
	DeviceBasedContinuousMoveProvider_get_deadzoneMin_mA570A98208C7C9C2F0F9553A3EEBC6554FB4FF8C,
	DeviceBasedContinuousMoveProvider_set_deadzoneMin_m574BE6DBF774C842B818DB774A273314E8612872,
	DeviceBasedContinuousMoveProvider_get_deadzoneMax_m63750776276B2BF5FDD2646BDE427803D7AB9AA0,
	DeviceBasedContinuousMoveProvider_set_deadzoneMax_m95781010EFD332ADAF75E1102DFC21DF2F7DFBCE,
	DeviceBasedContinuousMoveProvider_ReadInput_m8D4042FC29FAF250497C4B79E492ECFB215ABC7B,
	DeviceBasedContinuousMoveProvider_GetDeadzoneAdjustedValue_m90BE91A308931611184788A6B87DA7F4C0BE8606,
	DeviceBasedContinuousMoveProvider_GetDeadzoneAdjustedValue_m6E80A90408CDC315BCAEB19795923D3D0F848B42,
	DeviceBasedContinuousMoveProvider__ctor_m109CBDC9183E36A999EAC8C21A85D86D509A9447,
	DeviceBasedContinuousMoveProvider__cctor_m2373127C6AB1D6B7FF0072834CFA95CE71EAA730,
	DeviceBasedContinuousTurnProvider_get_inputBinding_mBA9F1D47A5C8A8393289615FD0EDCD198DBC2F53,
	DeviceBasedContinuousTurnProvider_set_inputBinding_m4E9EAF677F30334229F46D1E119B8989429039BC,
	DeviceBasedContinuousTurnProvider_get_controllers_m99326439026E816417E91F15A5AC84DF591EED14,
	DeviceBasedContinuousTurnProvider_set_controllers_m8A2E5DFDBE6134F9B799766B202A40D21A54F2F0,
	DeviceBasedContinuousTurnProvider_get_deadzoneMin_m556117BFD91F788969FA0298E0375B320C3EF63E,
	DeviceBasedContinuousTurnProvider_set_deadzoneMin_mB4A38EC2A8DED4650164207B05F85CA7FF9C3E94,
	DeviceBasedContinuousTurnProvider_get_deadzoneMax_m28ACEABA4A3ABEE45EE29EB6EAB86CDC98CF53F3,
	DeviceBasedContinuousTurnProvider_set_deadzoneMax_m9C5632D1323033930E2FB374446B836947945099,
	DeviceBasedContinuousTurnProvider_ReadInput_m5BFBB8DE35D3636C1782543CB9400233B133C895,
	DeviceBasedContinuousTurnProvider_GetDeadzoneAdjustedValue_m7330A75975136CD9152900A65A8A4813D5C69870,
	DeviceBasedContinuousTurnProvider_GetDeadzoneAdjustedValue_m0359AEBBAEA030B13719A3A3084FDC1EF6535D3F,
	DeviceBasedContinuousTurnProvider__ctor_m383D3502C281C05B920D91A2CE3348AB590544B9,
	DeviceBasedContinuousTurnProvider__cctor_m6B2BF6C886E964D6806976950276810976E291D0,
	LocomotionProvider_add_beginLocomotion_mE886C8B4354EE712934C278A497C77834B4754F0,
	LocomotionProvider_remove_beginLocomotion_mBACFA0AD5B200C844F3B0191C9312813F4696CD0,
	LocomotionProvider_add_endLocomotion_mB5BE7BC07AD5A5A22A5CAD63540D2A0D6D698606,
	LocomotionProvider_remove_endLocomotion_mC78E210D6096F0D694ADB7108AE7AA2132923B0D,
	LocomotionProvider_get_system_m2FFD680EAEA3837BF1BE61B34DB6685118760D94,
	LocomotionProvider_set_system_m356CEE71E1057AAD0A615898E7E92A89E2E4664C,
	LocomotionProvider_Awake_mDB71AC0528310B8B6A57E0D5D0C6E54C0E0E22EB,
	LocomotionProvider_CanBeginLocomotion_m3DE86A342E4B792E125FE73F2FE933BE99EDA9F0,
	LocomotionProvider_BeginLocomotion_mFB221E462FEC6E933C9161E30271678311D1AAEF,
	LocomotionProvider_EndLocomotion_m64CC4C14527FF9F8D2956159425A2208E4612ECB,
	LocomotionProvider_add_startLocomotion_m788F6350336CBB47917142134CDFAE7CB268A6E7,
	LocomotionProvider_remove_startLocomotion_mF92BE5D2EBCDA9D120F5A743CB63D42C368267EC,
	LocomotionProvider__ctor_m402BA4925BA100FA69742DD86D76BA0ECB39C7E7,
	LocomotionSystem_get_timeout_mFD09A2DD790389F19DBF9721011D7D905CE36F2E,
	LocomotionSystem_set_timeout_m7B3F1CA7FEADE7103002DDBA0580B08A7E86FE3F,
	LocomotionSystem_get_xrOrigin_m06C2599D9739A71562F0F3DD27BC57BCC18F3EF7,
	LocomotionSystem_set_xrOrigin_mCBC0B979D95B8DB1086C505645AE0BD97DCE3016,
	LocomotionSystem_get_busy_m28D47236EB8305F858FAA903E490FF1F9D678A9F,
	LocomotionSystem_Awake_m6A110BC4319FBEC64AD112B130CC3DDAA2B04D14,
	LocomotionSystem_Update_m0E0FE862254C451ADBEFE63756E120C6C57E1159,
	LocomotionSystem_RequestExclusiveOperation_m38B962B56859A1978AC995893D7FD9C7CEB0A0F1,
	LocomotionSystem_ResetExclusivity_m25A6EA802DDFDAF8A1FE6C59FB85C66F58A55DDE,
	LocomotionSystem_FinishExclusiveOperation_mE60B5D19065E9DC6F76357B21942126ED8383644,
	LocomotionSystem_get_xrRig_m66C8141D2D2FACDEC33DB82CAC8ED5278DEEDDE1,
	LocomotionSystem_set_xrRig_m582AE29CF788F3FA6E544A852CE884CEDFC50A80,
	LocomotionSystem_get_Busy_m43E2C5C416E56C27D9079BE43A58E31C9131B1E7,
	LocomotionSystem__ctor_mB37629153362E038054DC424AC2748E8F3CFA8E4,
	ActionBasedSnapTurnProvider_get_leftHandSnapTurnAction_m080880500C2C7AF09C16DD9E3AD8987FF54F41B8,
	ActionBasedSnapTurnProvider_set_leftHandSnapTurnAction_m593DEF28D9A4AC170EF9CECD72A4CCC39FC1F18A,
	ActionBasedSnapTurnProvider_get_rightHandSnapTurnAction_mB7D3DC36F102F0B0B144A7E66DBD6D8E99DC6D11,
	ActionBasedSnapTurnProvider_set_rightHandSnapTurnAction_m6909A7D5317BC44B3B6FC8A2C86D1ABF1CA3B6EF,
	ActionBasedSnapTurnProvider_OnEnable_mB974392761A9F3507B232702D0974A3B620F0CFD,
	ActionBasedSnapTurnProvider_OnDisable_m50B8D2411258F6363F6167D2706A42FA2A0EDC20,
	ActionBasedSnapTurnProvider_ReadInput_mB3F4758285A8867A4564A78CCEEC422FBCB4356B,
	ActionBasedSnapTurnProvider_SetInputActionProperty_mC9D57A366A4C04274E9FAB6B9E46E383A2B96FCC,
	ActionBasedSnapTurnProvider__ctor_m2DD0B1A6EBB603FA40E193EC764E68047A24059C,
	DeviceBasedSnapTurnProvider_get_turnUsage_m13EA8E1F1E0D250A1CA79550A71D0C3567AFF9BC,
	DeviceBasedSnapTurnProvider_set_turnUsage_m862FDD3D55F0C49AAB990906404ADE4902DFDD95,
	DeviceBasedSnapTurnProvider_get_controllers_m0BAA48EADCBCD01F05ADEC2320DF14C5582ED437,
	DeviceBasedSnapTurnProvider_set_controllers_m1D926F8431A5DFC4D68B7219763D82FCCFF7C905,
	DeviceBasedSnapTurnProvider_get_deadZone_m5BD8B17BD1FFDA15FBF13CE57B6B228183FC224D,
	DeviceBasedSnapTurnProvider_set_deadZone_m1F0A53F7076A009D8C97B244C0F86F99EAE941EA,
	DeviceBasedSnapTurnProvider_ReadInput_m8032A60D620CC1F500C253C42BD42B3D298BE2F0,
	DeviceBasedSnapTurnProvider__ctor_m3BF22C66539C00C07B72AFD688BC9EDBC006A66E,
	DeviceBasedSnapTurnProvider__cctor_mAC0B8900E5AC49A44914C6F2DBB283CE5FE8BC46,
	SnapTurnProviderBase_get_turnAmount_m1A71B1F663BBA314E04F40A87F976E65C585329A,
	SnapTurnProviderBase_set_turnAmount_m7CF964B94A1EF781ED3318E924FD1F6E60BBD959,
	SnapTurnProviderBase_get_debounceTime_mBE1DB957DE0AEFDA923ADF4F60749AAB5777D112,
	SnapTurnProviderBase_set_debounceTime_mF1EC6DC3B36931E6DDD9A9A7837794DDDE35DF80,
	SnapTurnProviderBase_get_enableTurnLeftRight_m305A42F82C0DA2E59ED427C612B31714110C3A6B,
	SnapTurnProviderBase_set_enableTurnLeftRight_mA12C92CD143D8DBCE0CB8C9B1AD5D1221BC62513,
	SnapTurnProviderBase_get_enableTurnAround_mBDD9557E4365D79557C02612DB6211CEC921F0B1,
	SnapTurnProviderBase_set_enableTurnAround_m7F986600E4931C3157B0C68C6C3F484969FB0033,
	SnapTurnProviderBase_Update_m5A976A8A283FD65E2D7D7D5B0CDD8C908811ACBB,
	NULL,
	SnapTurnProviderBase_GetTurnAmount_m8ED0772ED87A2E33FA68B280111BBC1688D215C3,
	SnapTurnProviderBase_StartTurn_m8050D3721A33C34B57752916F121AC72754B6390,
	SnapTurnProviderBase_FakeStartTurn_m7E059AB0072FC7622EFA51DADA5A4290975A3814,
	SnapTurnProviderBase_FakeStartTurnAround_m8C6CA0D15294B087F3B93488549801E48916CD76,
	SnapTurnProviderBase__ctor_m962618BDF42FF3FCDB3D8816C9ADDA6E18304F7D,
	BaseTeleportationInteractable_get_teleportationProvider_m9B53CC4903106CE7C0DA0F861BB22ED63AAD076F,
	BaseTeleportationInteractable_set_teleportationProvider_m10689329CEEDA0CECFC6C6DE42FEC5F402726CED,
	BaseTeleportationInteractable_get_matchOrientation_mB4CE35CEB0A0206457993CB28A618F300E4BC03D,
	BaseTeleportationInteractable_set_matchOrientation_mD9AD6D9C7CD63E80BDAFB6D6AC229531671960D9,
	BaseTeleportationInteractable_get_teleportTrigger_m875F50A1066F596DA0CB800997B84B4A0F8B1A94,
	BaseTeleportationInteractable_set_teleportTrigger_m456E07E992D4B82240DC266B240D46E12F3FB55A,
	BaseTeleportationInteractable_get_teleporting_mA6FB2E68A293161C7032494906520E47B6B5A84E,
	BaseTeleportationInteractable_set_teleporting_m5B4EC45250271E70D9E1735D2E69A1B7F760D011,
	BaseTeleportationInteractable_Awake_mC0C13EE138834FD575C21D6CA01E1FC07F701600,
	BaseTeleportationInteractable_Reset_mAA6ED9E19696086C7036357A04DAD5C5E8A10438,
	BaseTeleportationInteractable_GenerateTeleportRequest_m70FFEB12F9E0DEB0391C867E5740C656FA01E31A,
	BaseTeleportationInteractable_SendTeleportRequest_m050DF693E20FB0FA6A6C51314336ABEB736C973D,
	BaseTeleportationInteractable_OnSelectEntered_m0FD58F8C469202E81555C08B4362E2D23B620676,
	BaseTeleportationInteractable_OnSelectExited_m104024A13FA59E4110738133C4FB571DB6607E83,
	BaseTeleportationInteractable_OnActivated_m3519F32AD8EF48DEA2DC762AA0203AC2CA2BF9E7,
	BaseTeleportationInteractable_OnDeactivated_mCC3F748F7269D8A30EED80532E054CF274283D4E,
	BaseTeleportationInteractable_GenerateTeleportRequest_mB9FB5D40C078FF126CDFD19CECB2C3DC8E6FA7A5,
	BaseTeleportationInteractable__ctor_m03523AE1E1C51AF0E9B210844669220113406EE7,
	U3CU3Ec__cctor_m46A80D0E445DDDCE7FCCCECA8DA2D02050A4247D,
	U3CU3Ec__ctor_m7D71BA0703858033BED989B6EE9B928786F3640B,
	U3CU3Ec_U3C_ctorU3Eb__27_0_m5B232FEC2B244B7B1F264DC2EB9C282BABE65962,
	TeleportationAnchor_get_teleportAnchorTransform_m0711868C6E4463287017D36942E8A5C03122A435,
	TeleportationAnchor_set_teleportAnchorTransform_m00BFEA234630A95B4B9BE291610D89DC72EB9A5F,
	TeleportationAnchor_OnValidate_m7D4D44B9600ADB0E40D31F2D7AE24DBADC1036E5,
	TeleportationAnchor_Reset_m4EEAE41C190D2626B1A9F01A946CFD7E58E90B1F,
	TeleportationAnchor_OnDrawGizmos_m5D8C112B038BBB334829CE1185DB35C0C45B925D,
	TeleportationAnchor_GenerateTeleportRequest_mC00CA4094040F51A2B40D1E154B7F2443089046B,
	TeleportationAnchor__ctor_m8645304E8AFD708D9BF3C8E3B8D2F64F9CEBA427,
	TeleportationArea_GenerateTeleportRequest_m316BFEC3E6F188832FEB7FE20F4B3953A454A990,
	TeleportationArea__ctor_mBD0DD39D29BA373207C79E8600D8F183D3E14EFB,
	TeleportationProvider_get_currentRequest_m0CCE6B6BE488A506F4FD398A18C8D0450ED6C39B,
	TeleportationProvider_set_currentRequest_m109FD936C57760C70C312B799E6AD6D7651B0581,
	TeleportationProvider_get_validRequest_m083A1AF44E1AD7BD791A2B599216067B94D65788,
	TeleportationProvider_set_validRequest_m539A9FBCF21BBCE6062D888442666D0679B27B0D,
	TeleportationProvider_QueueTeleportRequest_mE1D319B5F451A6AD4CC2749D9B4CF6763E67A278,
	TeleportationProvider_Update_mF3A1A890CCFF2A42AC886504065D4F503E22C88D,
	TeleportationProvider__ctor_mE4031FC9A5B03DA60B3C68E52F39D0F721C3C2ED,
	GizmoHelpers_DrawWirePlaneOriented_m601D38814CCE4734D7248C027878AC09610001FA,
	GizmoHelpers_DrawWireCubeOriented_mB0B3D31FD9FCEFEC22AFB3B26E9AA374BB918730,
	GizmoHelpers_DrawAxisArrows_m2E693699692850260E01A003FDE03C207C04804F,
	InputHelpers_IsPressed_mD0516F35AE1B3765A098C89EDBC1E5F1E68144E2,
	InputHelpers_TryReadSingleValue_m658270EEE0C9578ECB0A21556A09347DA3813051,
	InputHelpers__cctor_m9959AB7052F722A32BD5C0F5065FB1D0E0383C5F,
	ButtonInfo__ctor_m3478ACD7B8502B0839AAA54A15EC75CE3A5A2A69,
	NULL,
	SortingHelpers_SortByDistanceToInteractor_mE70C409D7B9650D23AA37C83DCF4457385716D5C,
	SortingHelpers_InteractableDistanceComparison_m6AF8D736AF5F182F7A0FC8A6A8ED662D57B136B3,
	SortingHelpers__cctor_m5B6BEBB684FF311488D74E34B93688E9AE00BCE2,
	XRRig_Awake_m4C54DB98C4E12B1283219E8DB8F7649E8B02E9D3,
	XRRig_get_rig_mE186F9F6B042C09CA316CFB7137A8CC44D49A573,
	XRRig_set_rig_m3EB7C0D9BD2B867ACF1E100075E0C0BB467FCF95,
	XRRig_get_cameraGameObject_m599F292919A35F8427477F95D733377B56C43A73,
	XRRig_set_cameraGameObject_m68EB375A3940A631155A30F1E85E712B5CCF73FC,
	XRRig_get_cameraFloorOffsetObject_m1218E7E974839EBB80C129E4611301124283D235,
	XRRig_set_cameraFloorOffsetObject_mC072D15643C2FCF1B004A287E0663BA6DBAED604,
	XRRig_get_requestedTrackingOriginMode_mC13FB64E7EA0423190E238CE2163B7D563FAAB15,
	XRRig_set_requestedTrackingOriginMode_mEAB738898E3E74A6D0E6BF897DF7AC9A0C94C86B,
	XRRig_get_cameraYOffset_m671108AC8E1F340886A0B37C38155586F3499B84,
	XRRig_set_cameraYOffset_m289E1253EB6C747D6D221881829D5E88874BC810,
	XRRig_get_currentTrackingOriginMode_m4E0D1ECA3BB9564009C4ADC500DDF4FCC2D0182B,
	XRRig_get_rigInCameraSpacePos_m504AE7211B9F2359312069B68DD810C00F04F578,
	XRRig_get_cameraInRigSpacePos_mA397E5CCFBED6DB8DE87BE51E2C2CA686604B72E,
	XRRig_get_cameraInRigSpaceHeight_m9ED1541D7D6485281124CE4EC109D826851BC575,
	XRRig_RotateAroundCameraUsingRigUp_mE9DB5E392764B04743D17BC410E1DB5D37A10CC2,
	XRRig_MatchRigUp_m02778B1BD71CC152FF1A66B7C448E1DED5464744,
	XRRig_MatchRigUpCameraForward_m0C2B0CEA4D62279A7E2D370B072996F8418D550E,
	XRRig_MatchRigUpRigForward_m94F4910B4B27AAFD942946712A4098567C93A982,
	XRRig__ctor_mCE1DD53EEE749B4BD2C5914BF5BA8E8B3C60334F,
	ReflectionUtils_GetCachedAssemblies_m7FA5BB9EF7E5293063433F744CB3586F7AFA6428,
	ReflectionUtils_ForEachAssembly_m108C85DFA4980EC7F46536EC674ECD022ACACBF8,
	NULL,
	NULL,
	NULL,
	ScriptableSettingsPathAttribute_get_path_m5865F5A04288486F58C11373396761B338174198,
	ScriptableSettingsPathAttribute_set_path_mE3FFB7D573FE8B57A1B80EF5E4CB3C75B05196DE,
	ScriptableSettingsPathAttribute__ctor_m8D9F1CDF5EA8280EEE13866B9126505637E25F2C,
	NULL,
	TriggerContactMonitor_add_contactAdded_m625E817F417893FC68A1F1230B6684C66E588FA4,
	TriggerContactMonitor_remove_contactAdded_m76CB17DF8810E065275C5E9B2935F9D708EDF128,
	TriggerContactMonitor_add_contactRemoved_mD880723A00B23F29E938E6009F27EA66B3D4D8AB,
	TriggerContactMonitor_remove_contactRemoved_m9BFD21EB12A28EBF40681B392E6FD85EBD118E91,
	TriggerContactMonitor_get_interactionManager_m962AC519D6229441CA8EB1F2703A6B653E0B9B1F,
	TriggerContactMonitor_set_interactionManager_m43C96CAC16C5FEB57406D67B68065078FC50D4FC,
	TriggerContactMonitor_AddCollider_m90B52CC8A482935FE03014BA709AFED8C1A91210,
	TriggerContactMonitor_RemoveCollider_mAD618FBAD24B9791B2613A2792CA5C846F2C23D4,
	TriggerContactMonitor_ResolveUnassociatedColliders_m2790DF3456DEC8F2EDC7DF84EA7B64E169E68F87,
	TriggerContactMonitor_ResolveUnassociatedColliders_m1C1F8ACFAB59B76652A5321395085C18EED3B54B,
	TriggerContactMonitor_UpdateStayedColliders_mD2E17848428F8EC2F39855829EC043AAEFC9FB97,
	TriggerContactMonitor_IsContacting_mDB8343D7E36539EE8B60D596DCDC4C5E2830BB76,
	TriggerContactMonitor_IsDestroyed_m80DA0F1122E5C8E582379C7C615523BB6C704616,
	TriggerContactMonitor__ctor_m1F4312F4BFDBF70D5B3B9434FF5D32A276A1EE7A,
	TriggerContactMonitor__cctor_m1B2BD458E5A92A64C930FECE6203F8BB05A7FE18,
	ScriptableSettingsBase_GetInstanceByType_m5AF034F9E4B889F925DC9239130754FA177C7064,
	ScriptableSettingsBase_Awake_m2772A5D5F973FCB0E4006C4BC41294A9F311201B,
	ScriptableSettingsBase_OnEnable_m8D424C36FE448222EA165B6F21C11CAA745DCED2,
	ScriptableSettingsBase_OnLoaded_m6B90F5D2D4DE34897AF0D5ECC7FD4C6C058EB488,
	ScriptableSettingsBase_ValidatePath_m3AD32CF41B1CB8D5259C4F8F6E762C8ECF7FB13A,
	ScriptableSettingsBase__ctor_m8ACABB98DE308D194D6A46B945F11DAD0EF18D2F,
	ScriptableSettingsBase__cctor_m3A85C7078B4A36668F4BFF7CC9027311C7EE9916,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	GamepadModel_get_leftStick_m05E487F6B1C65806FA9B5657564D00249B6A3556,
	GamepadModel_set_leftStick_m8579917EDFBF3F998A18240C454FED95E50E1587,
	GamepadModel_get_dpad_m302B674C6D8AF62092807DAEAAA44AC3992510F1,
	GamepadModel_set_dpad_m39D1B66AF19424C3A1308577EC7108024DA21963,
	GamepadModel_get_submitButtonDown_m37C632D27087A446184DEBFF8EEE2E8BCCF8575D,
	GamepadModel_set_submitButtonDown_m23F72A7B2DF8A8808F6889A1E98BD8931ED3458B,
	GamepadModel_get_submitButtonDelta_m0EE8DBF1F060C7B0607127FB6AB4E892EC61A611,
	GamepadModel_set_submitButtonDelta_m9B1EDCDDB54FF0F21E0EF2341EDEC78E4E54A884,
	GamepadModel_get_cancelButtonDown_m086620B25E1BF6CC385D240CD48CD0DB55D360B9,
	GamepadModel_set_cancelButtonDown_mF13195D2D11D9371BDC1310B58075B7D93626F84,
	GamepadModel_get_cancelButtonDelta_m2F7BF6DD3A971F5122856813E3CD13BF868D24DA,
	GamepadModel_set_cancelButtonDelta_mD4ED8E73A3D8A53E2F8241D31131022FBFB0373B,
	GamepadModel_get_implementationData_mF118CFCAE36CE8BAF659D32D26B3EFB160A3B3BF,
	GamepadModel_set_implementationData_mF30CAE55823B11E6951323F6839D519CE2E5EBA9,
	GamepadModel_Reset_m028796E2B92E78CF1E054A7D97CDF42A9A2AC815,
	GamepadModel_OnFrameFinished_m2F0775532D18EB593DA0D2D8E1DC025A82C82AD5,
	ImplementationData_get_consecutiveMoveCount_mA3B5FF3A4D9BBBFD14CBAEF381A3B09245136BF5,
	ImplementationData_set_consecutiveMoveCount_m91D6C0702BD7F193B029443EB3CFFE3400A873AA,
	ImplementationData_get_lastMoveDirection_m70CE1DDAEBA14387D27273E11B5C55CD9CA5DD3A,
	ImplementationData_set_lastMoveDirection_m25C3B0B1B7CCA64B134D4C830A3F29098A0CE90A,
	ImplementationData_get_lastMoveTime_mE68BD5B91C6F28F0EAF230142A28241181A177F5,
	ImplementationData_set_lastMoveTime_m204AECF315C9F05B23A27749531D8D43A0825084,
	ImplementationData_Reset_m6952C9AE850B2D99257334E837C9A923C39867AD,
	JoystickModel_get_move_mB60103AA953140276E6BDBFF9E2674048B666B81,
	JoystickModel_set_move_m84DB43EE4C57318CE0B7FFC8416A6E9DC7DEDEFD,
	JoystickModel_get_hat_m60938F380B439629A5D0E69A9CD0B24812951CC3,
	JoystickModel_set_hat_mEEFA4CAF09C6DE4B0B10287C9D2276E8D180F232,
	JoystickModel_get_submitButtonDown_m2C594CD060FC1467793EB7D04F3A356D3FF5215F,
	JoystickModel_set_submitButtonDown_m972C04699F6CF1AE3EF76B94B9F303D508345596,
	JoystickModel_get_submitButtonDelta_m012B855F15407CE39563A2465270BFE766488E7A,
	JoystickModel_set_submitButtonDelta_mBCE238395763AD138FBF5CAD201B57F4AAF0A838,
	JoystickModel_get_cancelButtonDown_m0D382FCC9FD1D913786C962041D034B0A93FABDA,
	JoystickModel_set_cancelButtonDown_mF5A043FAAB87DC5964D93A18CF3D643600009BEA,
	JoystickModel_get_cancelButtonDelta_m51F7C586967ECC22CE4DA5F81255F83347A71E9E,
	JoystickModel_set_cancelButtonDelta_m508A4F611F64F834D6EDB84B6539F80FAD1F98DE,
	JoystickModel_get_implementationData_mE5B08F7B50DD4815D1930845A677CB4620467160,
	JoystickModel_set_implementationData_m1654E5AEE33F55136D14F090EC47DF7E5C097C39,
	JoystickModel_Reset_mAFDFEBC8EA109267A0A16C62033097C38AB9849E,
	JoystickModel_OnFrameFinished_mEF369FFD6CC791F3E9EE01510F1B07356D28A804,
	ImplementationData_get_consecutiveMoveCount_mB600F1F6A45941D8114E410D6014964554D7ADEC,
	ImplementationData_set_consecutiveMoveCount_mE564012624169F567A720A33E73AA649FD164198,
	ImplementationData_get_lastMoveDirection_m5795BF4D421FE58497DF6E154592CCC66CA43018,
	ImplementationData_set_lastMoveDirection_mE7B0C290F1AB9C8C30172606E3B05C9A9EE0B59B,
	ImplementationData_get_lastMoveTime_mFEE11CE8F3FFDD639707E8064EA99CCD64F5C99F,
	ImplementationData_set_lastMoveTime_m008BD50A07C1403D58D895BE67A571FF72C914D4,
	ImplementationData_Reset_m140D036D05B8FF021576CAABBCC5DC942AC9C079,
	MouseButtonModel_get_isDown_m6D25D5D7BE9E1781DF3B00F4C0ADD0942F7A0A8C,
	MouseButtonModel_set_isDown_mF109D7F287B91F942F835520CB7B67EC131A9EC0,
	MouseButtonModel_get_lastFrameDelta_mF2AC9472F0D1F820ED76F1D6F759B84B97E3842E,
	MouseButtonModel_set_lastFrameDelta_m760052CA3C1CA5CE93AA226D9F6D7D46023D5346,
	MouseButtonModel_Reset_m04966A9974669AFD8314FF5D8DA61B0AA13D8808,
	MouseButtonModel_OnFrameFinished_m3AA8EAB2730BD77885C53B5127E65FBADC09DF89,
	MouseButtonModel_CopyTo_mE192240DC4F3852B78A43812C3273BE692F95B04,
	MouseButtonModel_CopyFrom_mDB836BEC9F0538CD4C75CC917EA71A474279B1E6,
	ImplementationData_get_isDragging_m4342CE900F2E1C5F378AAF38248795FDB757278A,
	ImplementationData_set_isDragging_m23603F83850AE86ED35D0A35EA577A51A5934912,
	ImplementationData_get_pressedTime_m6BB28908890AC2AA318371062BD0B1825AD011A0,
	ImplementationData_set_pressedTime_m08CE027B7019E15F97EC2997A310D2E26B2B688A,
	ImplementationData_get_pressedPosition_m68E4FD86C4F9EC5B81D3A15A9ED5776642075218,
	ImplementationData_set_pressedPosition_m1402B47299E1C642D94FAF5AA83750DCBC61FA10,
	ImplementationData_get_pressedRaycast_mBDF58873A81E64D77396EEDD9BA9FDE899807683,
	ImplementationData_set_pressedRaycast_m3FEA7BEBCA8A181BCBA546A396608AD05E719314,
	ImplementationData_get_pressedGameObject_mED5188E469B0B53324D43C84CDC4092BFE81802B,
	ImplementationData_set_pressedGameObject_m43A6B848D7254A1A27999F73ACDEAFC53B69A6E5,
	ImplementationData_get_pressedGameObjectRaw_mE114B4837644AF9AA92C0AB5952ACC15385A8E35,
	ImplementationData_set_pressedGameObjectRaw_mBF3547F3629CF684A4151F0EB8EDC49AA6C85D6E,
	ImplementationData_get_draggedGameObject_m5AABEB516101C86E6A8E7243C2E12B3BD2DDE43E,
	ImplementationData_set_draggedGameObject_m9992F3D5D397185C774C37867A18FED90348B6F6,
	ImplementationData_Reset_mE8D9F86E602D177FCA6FEC7F0F8279D9EA08F60F,
	MouseModel_get_pointerId_m4093B901532AE29AF876BDE011E97CDB75B19A48,
	MouseModel_get_changedThisFrame_m9FA4FB5A8C2561339EA712BBD12468ADF6B31500,
	MouseModel_set_changedThisFrame_m654FCF5EE83F82EEFF6939869044FE1781239014,
	MouseModel_get_position_m7E6304F677CAB4B807B518B947B95AA63A2BE95A,
	MouseModel_set_position_mF52DACDB97F269AEC85646486093D6A135C5E509,
	MouseModel_get_deltaPosition_m343DD465AA88D7C5DE2A2E8A48CC3645434F70FF,
	MouseModel_set_deltaPosition_mF4C0644A65E3E98A9A397643D0E006B9187654DA,
	MouseModel_get_scrollDelta_mE5D60044DDB3DC20CB2660C371DCF359DE7B19E0,
	MouseModel_set_scrollDelta_m107437C513BD8F66EFDE6160EF224FEC6DA1F7A9,
	MouseModel_get_leftButton_m4E4FEAA3354E2243FC862B4E1212D8C372B399A0,
	MouseModel_set_leftButton_mDFA9E10E68EC1E60BDAA76BEC99F128F69B0272A,
	MouseModel_set_leftButtonPressed_mF1308166818C7AE8C3083EAE08FF32B24C8DDBF1,
	MouseModel_get_rightButton_m847C28E359189D4A2D4E39F0F5D3CC9943D5E624,
	MouseModel_set_rightButton_m41EB3062E8E1FD0F92D648F5591DBCE675E81FDF,
	MouseModel_set_rightButtonPressed_m87EF490742E8A801BBAB04A32A4B868C7E6031AE,
	MouseModel_get_middleButton_m8997BE389494AA17D6BF696BDF1E4889A68EA3C1,
	MouseModel_set_middleButton_m528B124FF921B92CD25CD2EE623D97B8DE01C318,
	MouseModel_set_middleButtonPressed_mF1E5EA114314006CDD15F484FCE7450F3D3B0A39,
	MouseModel__ctor_m63009692E802DED0663F43C9C8C5190FF33C8573,
	MouseModel_OnFrameFinished_m3C72244B03A8536965118B81CB098E355CCAE12D,
	MouseModel_CopyTo_m783AAB4CDC5D0569D63B7DCDFFDD13E6219AA8BA,
	MouseModel_CopyFrom_m7B8817A31CE42B0A96A5FAD2B93DEF906E4E1055,
	InternalData_get_hoverTargets_m7B27E64A82CB4C34D900E18D81B2BDCE8336EA4C,
	InternalData_set_hoverTargets_m0EBDF30E6181C88E401E66EF7241F8C206B88360,
	InternalData_get_pointerTarget_m4C93CAD2F36BD7E897463C1C3DE6BD07B741BF06,
	InternalData_set_pointerTarget_mC6341AA6C2995C1E180BA15AE61884C000F6D89C,
	InternalData_Reset_m285105197FFE5EC122647161C449132D50E4472F,
	TouchModel_get_pointerId_mEF567A1F3619C12F6519E4A6335E47BEC45F3D6A,
	TouchModel_get_selectPhase_m8EF259C3B4DE6A8B17699E796E4294405E07450D,
	TouchModel_set_selectPhase_m20B064E217FF3B1FC1D408A613E37D482B7ABFE7,
	TouchModel_get_selectDelta_mE61F993C8533C9E3BBEB2BDBDC65DB68D19C15C5,
	TouchModel_set_selectDelta_m78599CB986783C0797E2C4DFF21B3C41062E29BD,
	TouchModel_get_changedThisFrame_mAF76A9DB5F6F80A8BE56ADB2BDD35E55A5BE717B,
	TouchModel_set_changedThisFrame_m6F51A89025E6D541FAD0C743D409CA10F0981ECF,
	TouchModel_get_position_m6D3991EE4E0BD3CF7D530F9BDCB34804A21C431F,
	TouchModel_set_position_mCC5A8772603B39F6EB6440B5592AA3FCB813D908,
	TouchModel_get_deltaPosition_m8F1A9044D3FFE83FA0E82B3D6268829F6DD2A5CD,
	TouchModel_set_deltaPosition_m347C7275855704F7257AADD47BCABBBEA82F5499,
	TouchModel__ctor_m7DCCF8284C173C8BD0BE01B0CD15F912C15FEF4B,
	TouchModel_Reset_m23AF647E5BDA070B4FAF70877E2A5932D5235454,
	TouchModel_OnFrameFinished_m4FD14ED5AF9964A444CD372A80B81ED55671FEF2,
	TouchModel_CopyTo_mDDC9DCAA045380589E0325B4D8D272E419D4A75C,
	TouchModel_CopyFrom_m6727074A88A573B3B5A696C9BAC2EE03F1FD70FF,
	ImplementationData_get_hoverTargets_m4291FA348576902BD6421C43CEF21005B42DDEA2,
	ImplementationData_set_hoverTargets_mA2493C8E719D7734B4B52E0224B269C9265795FE,
	ImplementationData_get_pointerTarget_m1B2B7AB756D7AB58E4DDD61724B28C5BEA7ED45F,
	ImplementationData_set_pointerTarget_m0D4C6DE0126FB9B434079FB0191701AE39D11CFA,
	ImplementationData_get_isDragging_mA2CDC9BC26BCAE431DC2D5556C26C4081C0120EC,
	ImplementationData_set_isDragging_mF4D332D1A15D3A25CA9DCD01FA66D1DD3509053A,
	ImplementationData_get_pressedTime_m72D41F1D9D6D5374145B9EA73D48DD514DF57FD8,
	ImplementationData_set_pressedTime_m1DD37E6DF363A9D52AAB0DF5D41FA85D480412AB,
	ImplementationData_get_pressedPosition_m521F6BF90F71F5364A9D3C9A7DBEC1B3263C2410,
	ImplementationData_set_pressedPosition_mE0AE62062AD3BB0B3F91FC5A0A72C984838BB6A8,
	ImplementationData_get_pressedRaycast_m449154600AFBECB2454BE161E4F2D8E1C64E2725,
	ImplementationData_set_pressedRaycast_mD8206A598973DF87B20BDBBEC8E6E470D7EDC8FB,
	ImplementationData_get_pressedGameObject_m1C35ACFE7671A98B1BE4C9E63F99DE6F26F5A701,
	ImplementationData_set_pressedGameObject_m0B1B3517DF2991D515A6EE42D9A4E1EEB0F3D1A8,
	ImplementationData_get_pressedGameObjectRaw_m9ACBBB249DE666C8A4FC22EF9D2738F7769ABC26,
	ImplementationData_set_pressedGameObjectRaw_m53BFBDBF206350007C3B16570C0D1D1017B4478F,
	ImplementationData_get_draggedGameObject_mE3FA41A9E5B1A53CE2D810ECB6F70E931C8C24D2,
	ImplementationData_set_draggedGameObject_m6E44F10143BEC035EA6D122100AE0E331D40EF45,
	ImplementationData_Reset_mCC0BA6F7121A295E5A12ED99C63C2A644C4CBD2D,
	TrackedDeviceEventData__ctor_m84DA911667F1B78CAA3C828871BA1C0E6B472513,
	TrackedDeviceEventData_get_rayPoints_m634507CA62EF8BCFC3A5F1B7F1DE107480FBFE7D,
	TrackedDeviceEventData_set_rayPoints_m50DE65136BB92487876DC7FA3E8FD98AB95CDE04,
	TrackedDeviceEventData_get_rayHitIndex_mF78EEEBC65BFB650372F8AE3736CC747A852D857,
	TrackedDeviceEventData_set_rayHitIndex_m1DBE5C18ABAC0E5B241D10DB6164A391F37D5AF7,
	TrackedDeviceEventData_get_layerMask_m4A2A83C58E6B60DC4ED886236CCB760E70D610DD,
	TrackedDeviceEventData_set_layerMask_mE98A92C0797C746EE0692EA41121D862C279D76F,
	TrackedDeviceEventData_get_interactor_mAB97D54909C335DE1C55CE0DA071DB1B078320EC,
	TrackedDeviceGraphicRaycaster_get_ignoreReversedGraphics_m67397D0EDB5E58DAC62754B97DCBBFD8006F6217,
	TrackedDeviceGraphicRaycaster_set_ignoreReversedGraphics_mEDEF9B517AC5D2C807DBAEA30B38A45631AF4244,
	TrackedDeviceGraphicRaycaster_get_checkFor2DOcclusion_m4A896F3482512E5F84E842FD81344FD376F16483,
	TrackedDeviceGraphicRaycaster_set_checkFor2DOcclusion_m090F9DC270B6D82514EAA8D3EFE270A342CE8959,
	TrackedDeviceGraphicRaycaster_get_checkFor3DOcclusion_m81B936C36E3939FE427C0F83828AB40F25DCDE46,
	TrackedDeviceGraphicRaycaster_set_checkFor3DOcclusion_m9B197AC3C42575A001DC499159F4B012BA4B80B1,
	TrackedDeviceGraphicRaycaster_get_blockingMask_m04A970E664E86282B4FA8F768E3FD57CECAE22B9,
	TrackedDeviceGraphicRaycaster_set_blockingMask_m7D7EC827BFCFAC1C8FEDC12D8B7FD47A596A758E,
	TrackedDeviceGraphicRaycaster_get_raycastTriggerInteraction_m5B3AE66C78F898828750D70E7C248E3DD314B2FF,
	TrackedDeviceGraphicRaycaster_set_raycastTriggerInteraction_m59A653ECE711A18DD756571637443BBC14CE9C44,
	TrackedDeviceGraphicRaycaster_get_eventCamera_m8B52EB17FFC37F45CF8145AB861936BA6466FB73,
	TrackedDeviceGraphicRaycaster_Raycast_m67913B9B94A5A1B9077CC201F6EB3963F1C5D819,
	TrackedDeviceGraphicRaycaster_get_canvas_mAD7A34E53FB188AC4DA28255C022DAFCBBA5613D,
	TrackedDeviceGraphicRaycaster_FindClosestHit_m90A61B47165A9C072BB7879FE72753C87EF62497,
	TrackedDeviceGraphicRaycaster_FindClosestHit_mFDC5F6850B9AE7BE705AC95267570FF2F4344467,
	TrackedDeviceGraphicRaycaster_PerformRaycasts_mFCEEBBF50B3116C9783A46D8A99F138FB7C788A2,
	TrackedDeviceGraphicRaycaster_PerformRaycast_mF146A36CF05B6428122C843316097970AD82732C,
	TrackedDeviceGraphicRaycaster_SortedRaycastGraphics_m5C36293D866172FE0B49DFADCFDF0A5391525803,
	TrackedDeviceGraphicRaycaster_RayIntersectsRectTransform_mBF69EFB476321A58716B6C97F21E2CBA3EF6D030,
	TrackedDeviceGraphicRaycaster_GetRectTransformWorldCorners_m96C108FD9826453DD7E5E870CE97272F07431633,
	TrackedDeviceGraphicRaycaster__ctor_m171C45F821562D30B97D90B0258CC906FD837972,
	TrackedDeviceGraphicRaycaster__cctor_m47A6ED8F4ADEBAC44E2F35E923D467EB7D23FBCF,
	RaycastHitData__ctor_m46C10CA0C3686A7DFC808CC5E995563E3E6E0900,
	RaycastHitData_get_graphic_mD7D675E65B6B19526DEC71B273334796C44D7B88,
	RaycastHitData_get_worldHitPosition_mA36CED27016B4C803EE9129A379C1052152D15F2,
	RaycastHitData_get_screenPosition_mAAA69CF11624FC7EA8667F228C640DEFCD6FB2AB,
	RaycastHitData_get_distance_mC2299A0A61CCB9C17D93D532D8DE4109C8291EC0,
	RaycastHitData_get_displayIndex_mA3B5A6BD21766DBCE8EA33251BF23FDE7DFE0C50,
	RaycastHitComparer_Compare_mCC40F8BCA5482E5FB84B5F53618FE0885B8B8A31,
	RaycastHitComparer__ctor_m3738852194278662207000E744F68BCA0B6C5C59,
	TrackedDeviceModel_get_implementationData_m95202DC252DDE53560803CED892DDD834686B749,
	TrackedDeviceModel_get_pointerId_m7AEFEA8657A653D0968500004E01A9B8672464DD,
	TrackedDeviceModel_get_select_mF73B603383F4D45021CD0AAFC29324A54AC8D55D,
	TrackedDeviceModel_set_select_m9513F69D1C9E4B312EC23820BFC81CA7030E6F02,
	TrackedDeviceModel_get_selectDelta_m3F6B5717A4F6C2DC505EA92A11846820A14B35FC,
	TrackedDeviceModel_set_selectDelta_m61649F57176681CCBD64C07F4A4F0F3974DECE4C,
	TrackedDeviceModel_get_changedThisFrame_m4C3C35C841B822ABB3D5DEE90F26FA74D8EE9FE1,
	TrackedDeviceModel_set_changedThisFrame_mDE51F8C5DC3A66BA3F13B32F0CEE792E9FF7C1AB,
	TrackedDeviceModel_get_position_mA1B101753B4DE6F7142EE4DB49487104019DF4BE,
	TrackedDeviceModel_set_position_mDB462484180081FA49D38E28ACAE1772E8F11442,
	TrackedDeviceModel_get_orientation_m870C73AC6F4686930F729F7BDBF5812D7BB0CBCA,
	TrackedDeviceModel_set_orientation_m1A0A17586D375B499F224DECEC2BB19721EF05FA,
	TrackedDeviceModel_get_raycastPoints_m3087C3A9A899CDA89FABE930AB7CD63A9856E07B,
	TrackedDeviceModel_set_raycastPoints_m582BE854A82211D8DC757CF5A79445D1DC464C3A,
	TrackedDeviceModel_get_currentRaycast_mAF58714250F6AB9E34888B19F2449EF2D0FA94E4,
	TrackedDeviceModel_set_currentRaycast_mB605A8C85EFDAEDC5D8A39468CD0933E54F50C73,
	TrackedDeviceModel_get_currentRaycastEndpointIndex_m2CF4F264EBDDE6EAE7285ED58636F55FB1FCAA9C,
	TrackedDeviceModel_set_currentRaycastEndpointIndex_m590E66F5A9635363FE8E140E0F9CC28328AEC2E1,
	TrackedDeviceModel_get_raycastLayerMask_mB1E60DDB72A91FD2A65B00356D485513174C60AF,
	TrackedDeviceModel_set_raycastLayerMask_m15984C257F236CA50C3131EE3A6AA7814BAB715B,
	TrackedDeviceModel_get_scrollDelta_mCADE5E90334C1EE03593B0BCB7E21D55D2098E87,
	TrackedDeviceModel_set_scrollDelta_m961E99EA067FBCA97B2E8BC805BF1D608DF95014,
	TrackedDeviceModel__ctor_m2128F49761ECD982EEC5C86F0B18C9991A3ADE2E,
	TrackedDeviceModel_Reset_m29196B36856087C2404D20AF734005C0BB6B0AA9,
	TrackedDeviceModel_OnFrameFinished_m0CB3B1A5BB3236A786E674AEE6E740951AC59184,
	TrackedDeviceModel_CopyTo_m077D1C3D2AB67EE3E95101C04E8ABDFD5D82D56B,
	TrackedDeviceModel_CopyFrom_m2A29E70045067F467379D43A4AFB7CDCAFC1786B,
	TrackedDeviceModel_get_invalid_mD252CC40ED4B59DC50948450945B0894FBE5419D,
	TrackedDeviceModel_get_maxRaycastDistance_m7D59D0EB9A5D126EB753972241962421E4A41E7A,
	TrackedDeviceModel_set_maxRaycastDistance_m6EC3C19F85D167D4BFC03883616522D37BFB2648,
	TrackedDeviceModel__cctor_mA5735BEC35DB568F5706065BFE19119D36E234A7,
	ImplementationData_get_hoverTargets_m49C9E4E462CC1064607FA5A3BA0EF5AB0360EE0D,
	ImplementationData_set_hoverTargets_mCD8DCF11D40DAC82195A1724F2BA0D85FF57E70C,
	ImplementationData_get_pointerTarget_mB2D4D091AC3BC5E937FB7252047DA33AC409FAEB,
	ImplementationData_set_pointerTarget_m6A49B7736E5B50E934D4D998648ED2AB2D69C582,
	ImplementationData_get_isDragging_mEE3BF283FC9C5235D15708D18BE89E06319F781D,
	ImplementationData_set_isDragging_m315511026FE53448151B19E47E4902F90E819BC2,
	ImplementationData_get_pressedTime_m154FBADD86CD746C703BF37003C64C428CADAC35,
	ImplementationData_set_pressedTime_m0EB8960EE81F4D82A71AAC719999CE01D64DCDA6,
	ImplementationData_get_position_m421FC9657A48CBED5AD985B2D7905BF7B06CA446,
	ImplementationData_set_position_m82C559B25F9B9515CCAE8FA900B78A2072CD3F7E,
	ImplementationData_get_pressedPosition_mE3E33C31F62A5ABF18461C479CA7DA9D8DB32262,
	ImplementationData_set_pressedPosition_m9BBCEC0224F0FCB1572F06B61A01074A0CAD5DCA,
	ImplementationData_get_pressedRaycast_mA355A412C26FAB49EA39F4DEFDA824465DFDE48E,
	ImplementationData_set_pressedRaycast_mB79CE5436DFBFAB118F234D25B7D49E72582D9EB,
	ImplementationData_get_pressedGameObject_m81DA354AA04B9531100A8C8C6A61100493115CF5,
	ImplementationData_set_pressedGameObject_mF87125F8EFFBE3ED0609B5C67EA86704715996FE,
	ImplementationData_get_pressedGameObjectRaw_mE9702863BC33793FB5DE550F0789A9058F369A2C,
	ImplementationData_set_pressedGameObjectRaw_m3AEB4F85F771C297EAE30B1CAAFDD990446624B4,
	ImplementationData_get_draggedGameObject_mBD53214AA566627B15D7EA5F6080758FF95C1848,
	ImplementationData_set_draggedGameObject_m977BE3A90025D2F50AC30A321D30245423B9CA6A,
	ImplementationData_Reset_m78CB6F5BD992AECD4D7D58E5880CFC0DF4DBBC55,
	TrackedDevicePhysicsRaycaster_get_raycastTriggerInteraction_m9E934B1D2880B5AF17B565D8574F9CA2699EA7E6,
	TrackedDevicePhysicsRaycaster_set_raycastTriggerInteraction_mEF929F720FD15B157653827D6EBB0D4E6C61F006,
	TrackedDevicePhysicsRaycaster_get_eventMask_mB75E7F77242C64D1B41710EBE3B8C6395A34F38B,
	TrackedDevicePhysicsRaycaster_set_eventMask_m13F16E19AB895BD2B44805043676FD67CF691C8A,
	TrackedDevicePhysicsRaycaster_get_maxRayIntersections_mEE9EB9579C61CA31869B544DBE855DE6A3D2C902,
	TrackedDevicePhysicsRaycaster_set_maxRayIntersections_mA7EE3F4A79BC6CB7C1B1BE49668506AF255C5C4E,
	TrackedDevicePhysicsRaycaster_get_eventCamera_mF1AF235906E16B8D61A1BD240AB1CAC1233BB553,
	TrackedDevicePhysicsRaycaster_SetEventCamera_m109CC7E7D596F53719E1AB06CFBF28A0A380921C,
	TrackedDevicePhysicsRaycaster_Raycast_m0BFFAA0821C6C57A8C3EC44211EB88DC761F472E,
	TrackedDevicePhysicsRaycaster_Awake_mC3C96AE1AC1C7A2B2DB4A901EA0ADEFBE448C995,
	TrackedDevicePhysicsRaycaster_PerformRaycasts_m86E342C9D8A61B890C0909381DE96566125257E7,
	TrackedDevicePhysicsRaycaster_PerformRaycast_m20052CC3DBF3C62D0A7705DF04CDEE6CFCF763FD,
	TrackedDevicePhysicsRaycaster__ctor_m604E49C73D48122271025602D10B9890B12AD0D0,
	RaycastHitArraySegment_get_count_m5BBA6588A64FF768F053CCFF5D6E6ACA65F9DB4D,
	RaycastHitArraySegment_set_count_m914E21014BA452D837B277FC9088881160F7AE1D,
	RaycastHitArraySegment_get_Current_mECA5B92CC673BB2BCED92B7F5E82075A17A800C8,
	RaycastHitArraySegment_System_Collections_IEnumerator_get_Current_m2AAD9444FCF9F4F1813B275122B187EAE922DE79,
	RaycastHitArraySegment__ctor_m1EA0C75F9B3A4AD6EEEA6EBB5D9926EC57FF0B01,
	RaycastHitArraySegment_MoveNext_m714394CDED45A30BEB73086BC42576E6AE231D95,
	RaycastHitArraySegment_Reset_mA0FABB4A4E7AD22B6E83C3248A9D57EAFF1490EB,
	RaycastHitArraySegment_Dispose_m10C35FE8B7DCC03C144372A085EC2025D07C85ED,
	RaycastHitArraySegment_GetEnumerator_mC9D09D2871FFB820FB5496456E5649B01594A0F7,
	RaycastHitArraySegment_System_Collections_IEnumerable_GetEnumerator_m5681610A873C7C0B3659BB929E4241B5796322D2,
	RaycastHitComparer_Compare_mBC14B5D686F0C0E6D85AD46FEFD965E6001E3A8D,
	RaycastHitComparer__ctor_m25412161F14970521D7D85A4DD8BAE3C18AC4CC0,
	UIInputModule_get_clickSpeed_mA97C1FD6A500C3EBA907A6C79EF59112B02BB894,
	UIInputModule_set_clickSpeed_mFF1C7BD7B5FCB5274D85BB7C4AFEB9B025F491C4,
	UIInputModule_get_moveDeadzone_mFB3CDD0FC69E6DFAF3ABDE5DD44D19C24B6D2104,
	UIInputModule_set_moveDeadzone_mE56FF053ABB13F67F0162D3A825D1B25A0707398,
	UIInputModule_get_repeatDelay_mD2B5AF5E141A0C82768461C6A7012004443ED934,
	UIInputModule_set_repeatDelay_m7F75D6EC2C48820238C441AE06D527275019286D,
	UIInputModule_get_repeatRate_m159C95DF8BA72BA67569F6B9A3B379976B14F4B4,
	UIInputModule_set_repeatRate_mFFE6FB4FB6C1D8BA45707D9C5F4D79C82E673A52,
	UIInputModule_get_trackedDeviceDragThresholdMultiplier_mFD629D1343B6CE4DC2DE135F17C3032A342A9D2A,
	UIInputModule_set_trackedDeviceDragThresholdMultiplier_m229733B6750687F4B2F730F0ABB0C8B92214CD62,
	UIInputModule_get_uiCamera_mE7FE3483DD96250D5E9C4EEA0E4ADD4FAC1E7647,
	UIInputModule_set_uiCamera_m37C392685DE455B9197AC432551BA808A1A9001D,
	UIInputModule_Update_m7D6322B0FDDFDE7B1E82943EFBD2C2E6BE70F100,
	UIInputModule_DoProcess_m2F3415E90165B1AF36AA82DE27C23B2A9EBBE47C,
	UIInputModule_Process_m5F41F23491E526BA70E4980C0143A020D9E0B5AA,
	UIInputModule_SendUpdateEventToSelectedObject_m7DD6DD3839C2A33F9D34A11A8643D193DBE8268B,
	UIInputModule_IsPointerOverGameObject_mDED22CBFD2207F371923EB30699528F09B4C1790,
	UIInputModule_PerformRaycast_m4716E7450EC96B541A924BB1DC20E58B2F159B28,
	UIInputModule_ProcessMouse_mF90F8EA789274FCD298E5ED801EE9675A9E3EEA4,
	UIInputModule_ProcessMouseMovement_m8654AF723206F8BE52803F57801811E4B54E9E41,
	UIInputModule_ProcessMouseButton_mCD0F73EA5A20835EE50E9F238E2BDA4865B0F391,
	UIInputModule_ProcessMouseButtonDrag_m768E9FBBC339845C4E7849C71B86D14DEB91F141,
	UIInputModule_ProcessMouseScroll_m8A93D635F089F339891607F19D746BA4DB11452F,
	UIInputModule_ProcessTouch_m6E005B10690A60C60030CCB1803BA683337224FE,
	UIInputModule_ProcessTrackedDevice_m82718A0C6C9B13B6FEAC0967D3DBAC75BD3C5E86,
	UIInputModule_ProcessGamepad_m4CAB4ED476E35FF67CF895157F3DDA8DDC456AB9,
	UIInputModule_ProcessJoystick_m0AC925B34544FA77F96A55E284B516410D30D8FF,
	UIInputModule_RemovePointerEventData_m0F281258935D22628B31140F4578DD54F6CED2A7,
	UIInputModule_GetOrCreateCachedPointerEvent_m2A3C1845504FDFCDE1AE2BDDF396ED6DD279BBCA,
	UIInputModule_GetOrCreateCachedTrackedDeviceEvent_m50DEA6D9F60E668D14EBAA52D247CBB9B138C4BC,
	UIInputModule_GetOrCreateCachedAxisEvent_m0BA809D7FFB01FB16E1D388DE8C9C3E920BE95B9,
	UIInputModule_add_finalizeRaycastResults_m284F9F3718129B2D178D831C1334A8EF0F22205F,
	UIInputModule_remove_finalizeRaycastResults_m869EE6506EF67AE07A6FB1DCA5BF0EB862CB50A9,
	UIInputModule_add_pointerEnter_mC2952CF870EDCC16D60CBAFDC20C2B617FF1F9F6,
	UIInputModule_remove_pointerEnter_m732BEA4FDE353F48038A2A2AA275EDD73B853D46,
	UIInputModule_add_pointerExit_m72DBA62BD601A3517C3AF34693641CEF292C07B4,
	UIInputModule_remove_pointerExit_mA5248639F07AECDDADC478FED718014D6C79CC41,
	UIInputModule_add_pointerDown_m9173418E3433ACBF1E748369DDDFB71A3B9F2D13,
	UIInputModule_remove_pointerDown_m25D2DAB8B81DCC5BC70F49CB92B83290A045EC4B,
	UIInputModule_add_pointerUp_m2A53C7E0EDC56ECCD5E7E9DEDE13FC3C0B13E839,
	UIInputModule_remove_pointerUp_m1208A993218A61396EA4AA9C573D3D1917A8FE5C,
	UIInputModule_add_pointerClick_mD5B1AFA7ACF6EBF0E061EF6BE18DF2063B010F67,
	UIInputModule_remove_pointerClick_m243047A5B5D18CD7C176D87E8E57E20520701850,
	UIInputModule_add_initializePotentialDrag_m7806CE850913CAECF12C3E1F2F5D7CC4B2A690F3,
	UIInputModule_remove_initializePotentialDrag_mEEF545F889D9C81BA1D0EDA0B57B7DB9CC37794C,
	UIInputModule_add_beginDrag_mAA5E03401ECB3A89C93EA86353CB8E704803B8EC,
	UIInputModule_remove_beginDrag_m31368ACAD0CC7C4F356F89ED70089D21DCD90AC1,
	UIInputModule_add_drag_mE60899C9ECF48D389A7B258F9F1C78D14685541E,
	UIInputModule_remove_drag_mCD37C151704D73D698AFBD3CE9B18A427908F517,
	UIInputModule_add_endDrag_m193A9FD0DAF60C9C0D57A16A2C919930CA0F8A67,
	UIInputModule_remove_endDrag_mCA258F00211C2E70081D50B908A691FCC868AAD2,
	UIInputModule_add_drop_m6E8254ABE1D0826375B88DED6743659D6F8CFE52,
	UIInputModule_remove_drop_m239EB803ED8DBC0D4E2F3E43CBBD243CA947506C,
	UIInputModule_add_scroll_m19016175E3F43A156EF4221210E524B5DB274443,
	UIInputModule_remove_scroll_m52E356A774F8B0685F0FAFF6D312E0B116720BE9,
	UIInputModule_add_updateSelected_m8AEC6AD19A00852977CDFD6EF6C39BFF4A19A1C7,
	UIInputModule_remove_updateSelected_m5D17BA3093E9705FB538F0940BEF379998C78CEB,
	UIInputModule_add_move_m97DF584BF7ED6BBF2FC0FDD60551B656C08B722E,
	UIInputModule_remove_move_m012D47230F257F7F7D0A04CE4B03FD46927CB97C,
	UIInputModule_add_submit_mDFA87455410A48B770FF3835B588956822394A10,
	UIInputModule_remove_submit_m4982C6B93ADAF49EFC6DA6D609BA6F33B352084D,
	UIInputModule_add_cancel_m8F9F7D7D7FE1845910BE00593D06FCF8A7B15623,
	UIInputModule_remove_cancel_mBD92353A869FE561F961AC8821BACEC2DE87FD92,
	UIInputModule__ctor_mF6B661E76FF09FEC44404BA11DD54F8D3E2FB827,
	NULL,
	NULL,
	XRUIInputModule_get_enableXRInput_mEF148C23548DFE6B9CFBEA481D9C5C6E9B997D96,
	XRUIInputModule_set_enableXRInput_mA67F93E18007DC7053BC83C68689F2E64DC64F4D,
	XRUIInputModule_get_enableMouseInput_m3984250F9A4B5401DC7ABACF1E96107B93FDEA81,
	XRUIInputModule_set_enableMouseInput_mF931954CCC642A69E354CED3C5888394B38289DE,
	XRUIInputModule_get_enableTouchInput_m421820762C081C055B51C4BB1EE8B840DF7FE6EA,
	XRUIInputModule_set_enableTouchInput_mD9C65CAEA46CA87A96674571B348F4F93E4F429F,
	XRUIInputModule_get_enableGamepadInput_mA340B34F91FBE777897271181E25E579F7D2FF6E,
	XRUIInputModule_set_enableGamepadInput_m433C31F6C28BD03A1030B76EB111C146928219EE,
	XRUIInputModule_get_enableJoystickInput_m05ECF1903097F7E4C2405A877E0C0960AA0E757F,
	XRUIInputModule_set_enableJoystickInput_mB2C7A5D5AB89AB9C1D1C7A6C7B6DBDF87D09CC83,
	XRUIInputModule_get_horizontalAxis_m18B8523D5ED51B8F96F57D5B315F000A409C3496,
	XRUIInputModule_set_horizontalAxis_m961D5E18A5814D94963FE46BC6D44A6D8E3D9543,
	XRUIInputModule_get_verticalAxis_m62A0C0D3EA3024694A70767019804CE6F9931985,
	XRUIInputModule_set_verticalAxis_m8CED8D229193C44F9B7998D2DB1B8BC685E244C3,
	XRUIInputModule_get_submitButton_m335DDEC0D182813E8F46F64EC703036D8A765C92,
	XRUIInputModule_set_submitButton_m238B5E49DC52E8B0FE34DEB1179FA3C914500D87,
	XRUIInputModule_get_cancelButton_mF18097E9E5A4CFF4F42EB1775C6A09E1CF7B8088,
	XRUIInputModule_set_cancelButton_mFB2DDF6699839CB2340B9B8A8D15F7A9863790CA,
	XRUIInputModule_OnEnable_mB938D9A55AF66EDC8A3384F357ADAEC6B3EA1431,
	XRUIInputModule_OnDisable_m95329A7D7D20015E4E4475FFFD074A902606BEF8,
	XRUIInputModule_RegisterInteractor_m5A17069C7410839807F8EB0E5E7FF2D438F7A55B,
	XRUIInputModule_UnregisterInteractor_mE078BB0F40BF245171F44E7629A853FA08CAB0B5,
	XRUIInputModule_GetInteractor_mBBAF268AB57CAB8CB6390D339B7D5A5893CEF747,
	XRUIInputModule_GetTrackedDeviceModel_m85E330D47C648609FA20F173C8C036E3DF280875,
	XRUIInputModule_DoProcess_m3E40FE8EB0244A2390709FCE793271DD8AFB60DF,
	XRUIInputModule_ProcessMouse_mD684700E9D27203EE72E7DE93F773DF887050EA6,
	XRUIInputModule_ProcessTouches_m5803B279A332A189EF841756931CF463879E516C,
	XRUIInputModule_ProcessGamepad_m0D8E15D91A8781985480A739B3900A1E307AD205,
	XRUIInputModule_ProcessJoystick_m8B718A243731D7E32AAFD357C9CD0D936F405EAA,
	XRUIInputModule_get_maxRaycastDistance_m87049643E3AE060060068D25BD71D5ECE14EBA7B,
	XRUIInputModule_set_maxRaycastDistance_mA769014A0999A1B5DB9AEFCC70FC58AE2DF49A4A,
	XRUIInputModule__ctor_mE15B70D3CE192C4622EE2144530F98F6E0CA0829,
	RegisteredInteractor__ctor_m6F1AB931437F1F9ACEC036DF8D35D6F5615109BF,
	RegisteredTouch__ctor_mEAB697F13AE6A0335886FE62EF14C790C9077324,
	CardinalUtility_GetNearestCardinal_m6761662410E5FAE1002827B1863A7A2871B85734,
	InputActionManager_get_actionAssets_mB7B35CC08659DF051DE9FC4968B973BF399CDEFF,
	InputActionManager_set_actionAssets_mE9347456325C863ED670FA7FE43AC34B273B3397,
	InputActionManager_OnEnable_m1EC5781A35CBB463796556D6F6AFFD4E1D1A0342,
	InputActionManager_OnDisable_mB8DA0A993A336F3873BD3201922B4047DECECA3E,
	InputActionManager_EnableInput_mD7F60DE6CB14A163521E0A08A37791C98381FA2B,
	InputActionManager_DisableInput_m90B494A96DAFD272A29A9EEB5073AE96906007E9,
	InputActionManager__ctor_mA44CD5855DA22DBF1F8B99A9A4361BAD30D66C94,
	InputActionPropertyExtensions_EnableDirectAction_mA8846AAA44837965CF99FD82C518A86D6479AB46,
	InputActionPropertyExtensions_DisableDirectAction_m9699BBB4F5F25E03534B2C4A346DC52D2FEE30A7,
	SimulatedInputLayoutLoader__cctor_m50660E669D07DD504B791EC6A2FB38A36A4DC8C6,
	SimulatedInputLayoutLoader_Initialize_mCF21EB8EADAB5BE96981379B22B44E89B3CE54A6,
	SimulatedInputLayoutLoader_RegisterInputLayouts_mCE7E28444FE451126299C16F63F416BD8D230888,
	XRDeviceSimulator_get_keyboardXTranslateAction_m366F9B6E96C557A7B1CAB51FB10C4E2DA1692D51,
	XRDeviceSimulator_set_keyboardXTranslateAction_m89EC0F9C42104BEDA69AC8AE8BF9B964FE0E241E,
	XRDeviceSimulator_get_keyboardYTranslateAction_m4E77F2AAB63C5BD5C2131A852D37E7D1EFD0A377,
	XRDeviceSimulator_set_keyboardYTranslateAction_m920064BC3FE9EF16B702E479D99D39FF3BEB1186,
	XRDeviceSimulator_get_keyboardZTranslateAction_mBA7240AF7BF6271D5B6B0B635F041A86DB82199A,
	XRDeviceSimulator_set_keyboardZTranslateAction_mD0AC287DDFF9F7D339C4760191ED53C51BBE178D,
	XRDeviceSimulator_get_manipulateLeftAction_mF13D03BDD3B1691F40956156E6C00F12A381B7DF,
	XRDeviceSimulator_set_manipulateLeftAction_mA82321B480841B1054C7C54C5F4BAEDAC32A1466,
	XRDeviceSimulator_get_manipulateRightAction_mFD0D5FBC545703BC69919081932DBEE274EBB4AD,
	XRDeviceSimulator_set_manipulateRightAction_m54665887203B970DF5D696E3C27BC9F0D056459F,
	XRDeviceSimulator_get_toggleManipulateLeftAction_mB1AB1130B8FDB40CAB6664A3A2D75ED4475BBF14,
	XRDeviceSimulator_set_toggleManipulateLeftAction_mACB41B1E9B0E3665FF161170C6D52DD28259CCEF,
	XRDeviceSimulator_get_toggleManipulateRightAction_m5808CB9748058EDC8ACF52B7B954A3BFBCFF852F,
	XRDeviceSimulator_set_toggleManipulateRightAction_mAB6CC69904055B701563A50CFE6A3A82DF97B52A,
	XRDeviceSimulator_get_manipulateHeadAction_m1948244C874F76443370EED81FD6899E4170AE04,
	XRDeviceSimulator_set_manipulateHeadAction_m44C0672D97A186A66B197AEA61943AE3F0D4319A,
	XRDeviceSimulator_get_mouseDeltaAction_m03FD86711D77A7739BA41B31929A0AAD3FF15F2E,
	XRDeviceSimulator_set_mouseDeltaAction_mE5D01D667C6EF0E52050B3AC68619F53D9E400AD,
	XRDeviceSimulator_get_mouseScrollAction_m8C30B704B54794BDFE80349B67998B44CEE18AD6,
	XRDeviceSimulator_set_mouseScrollAction_m76B5328F81F8722C142A905B74A7F8630EEF4898,
	XRDeviceSimulator_get_rotateModeOverrideAction_m11FF0CC898D8EED0032B343245532E018E7D0264,
	XRDeviceSimulator_set_rotateModeOverrideAction_m3875666E7964F451B74BA4362A5FDE40A0584D26,
	XRDeviceSimulator_get_toggleMouseTransformationModeAction_m8E831EA2AF126773BC928B09F5684CCEDD595FB4,
	XRDeviceSimulator_set_toggleMouseTransformationModeAction_m067C40CACA52D5E87B5E634FD02E17F35B46457D,
	XRDeviceSimulator_get_negateModeAction_m825088F34B7FDDF847F7E439CCECAA92BA82A3E0,
	XRDeviceSimulator_set_negateModeAction_m493F3724035AE9867E6BDD26ED167521415B98EA,
	XRDeviceSimulator_get_xConstraintAction_m0F58D866DAC60889AA588D1CB34119C609484573,
	XRDeviceSimulator_set_xConstraintAction_mD8ED4A6133F1DE169BB978B4D7EEC61B76A9A000,
	XRDeviceSimulator_get_yConstraintAction_m955F4CC45D19B4A14B977FFB6AC207FE0A8579E9,
	XRDeviceSimulator_set_yConstraintAction_m06A0ABCDE54E5A91DEB12691EFD98E11B94189CE,
	XRDeviceSimulator_get_zConstraintAction_m5D64FC5E7B07E86C1CD878ECA2EB2EBB4D8AA5D6,
	XRDeviceSimulator_set_zConstraintAction_m230D3980169AD163104650CCD7BBBE4B3CD5799D,
	XRDeviceSimulator_get_resetAction_mFE0522E1330FC913A1D2C0002FC479AAE9022A3C,
	XRDeviceSimulator_set_resetAction_m4AA53B730F668675F5D665FF2DD891DA06B75709,
	XRDeviceSimulator_get_toggleCursorLockAction_mA230EB1D4709C3BFDEF7C784D8127436FFED7FFD,
	XRDeviceSimulator_set_toggleCursorLockAction_mD0BE48B671BDDF6B53A73848328C0DAC188725A4,
	XRDeviceSimulator_get_toggleDevicePositionTargetAction_m62774B55355AB3B4EC7F442D0C82F14B29BBCC08,
	XRDeviceSimulator_set_toggleDevicePositionTargetAction_m6566C70EC39B0722B2E71ECA73E237086917D32D,
	XRDeviceSimulator_get_togglePrimary2DAxisTargetAction_m8156C8BBAA2B648E786480CD666FD670FAA561D3,
	XRDeviceSimulator_set_togglePrimary2DAxisTargetAction_mF1BB9A22AF00A6D435F33C4925C4D47C5FB0215A,
	XRDeviceSimulator_get_toggleSecondary2DAxisTargetAction_m8D76834A573A7BB22825E46E51280F5CA468766E,
	XRDeviceSimulator_set_toggleSecondary2DAxisTargetAction_m30F611596C3608FF80FBB40680B3FBFF45BB1913,
	XRDeviceSimulator_get_axis2DAction_mB6D4E7DB50DEAB354F634B5B97F4450DDF6DFDE7,
	XRDeviceSimulator_set_axis2DAction_m680EB6C7F6FA9756BC85F50FBFF597F653FC4B02,
	XRDeviceSimulator_get_restingHandAxis2DAction_m7A19F0EB497DEE03682C72218207BB96D0C4CCEA,
	XRDeviceSimulator_set_restingHandAxis2DAction_m3964DD5C30D2F1B9AF84C612DABF5AD427E1276F,
	XRDeviceSimulator_get_gripAction_mF8D3A50D9BA8A1E2822455ABA4D6EDAF67F841C9,
	XRDeviceSimulator_set_gripAction_mC82A4386E1833F46BC2487B18524FD65CE20BD77,
	XRDeviceSimulator_get_triggerAction_m356C2FD6244EBAD3F3691EADDDAF06D6C41E418C,
	XRDeviceSimulator_set_triggerAction_m2445205267DF7CC40CD780C614B1B225A5E72A87,
	XRDeviceSimulator_get_primaryButtonAction_m286F93EFAB14D74C8034F8BEEC084AC30231B032,
	XRDeviceSimulator_set_primaryButtonAction_m37DD9A023EDCB8099B7B6595850D0891239692BB,
	XRDeviceSimulator_get_secondaryButtonAction_mBA85B7EB879C7FF29D445134DF724473F9EBA37B,
	XRDeviceSimulator_set_secondaryButtonAction_m2652D2A7B3A59902721385E50FEE59DFB2E783B8,
	XRDeviceSimulator_get_menuAction_m7AB8A4601FCF614B1B8A0952E7CEB273B0D6C846,
	XRDeviceSimulator_set_menuAction_m5FD921B1A1FB9A3C49FA8E2CE18D6CCE004B73CD,
	XRDeviceSimulator_get_primary2DAxisClickAction_m3EBE6A566E1765FC0CC0D056950E2FAF6C2529ED,
	XRDeviceSimulator_set_primary2DAxisClickAction_m2D5CA90C271FDCA05A850C65F7BDC584E14FA123,
	XRDeviceSimulator_get_secondary2DAxisClickAction_m5D00330E31AB9A4D35ACF78953B24388BED58CDC,
	XRDeviceSimulator_set_secondary2DAxisClickAction_m58132C5FF2C088BFAA88BB73B0BA2D70F68FC76F,
	XRDeviceSimulator_get_primary2DAxisTouchAction_m3E488B2B036D17A1125D5DD345E3C9140A378E2E,
	XRDeviceSimulator_set_primary2DAxisTouchAction_m0274E44C8AFA39DEEB51499D67100A10764A7975,
	XRDeviceSimulator_get_secondary2DAxisTouchAction_mCE8E64F6ECF20ACBE13DACC0DE4E5A05EFCF97A1,
	XRDeviceSimulator_set_secondary2DAxisTouchAction_m47D65F14FC902C965802218DCA82BFCA5977ACF7,
	XRDeviceSimulator_get_primaryTouchAction_mB32728372313E7634E1FB3F8E9CF42281F3A572E,
	XRDeviceSimulator_set_primaryTouchAction_m5EF5D0D5918B2BC411DA19C7D507933B6B33AE5A,
	XRDeviceSimulator_get_secondaryTouchAction_m15C9D2FEAE5BF84BF458E7B5F91325A7D30A1C71,
	XRDeviceSimulator_set_secondaryTouchAction_mE7A471FAC7DAED4C0F3ECE93DE3C4DBCF7EC0013,
	XRDeviceSimulator_get_cameraTransform_mE69EA56A2BD8CCE33B2631022BFE58ABA823B5D1,
	XRDeviceSimulator_set_cameraTransform_mA5541FFA49D1B07233D99919DD6C1C1E8E3C0159,
	XRDeviceSimulator_get_keyboardTranslateSpace_mD84B30BF94B9EAE217EBC5C1B9F54A6DF18BFAD9,
	XRDeviceSimulator_set_keyboardTranslateSpace_m8BAD2FB8021AED6460529298C046080EEF95F50F,
	XRDeviceSimulator_get_mouseTranslateSpace_m18E032CBB10CE1C9529C1F4BDF191B9734A3684A,
	XRDeviceSimulator_set_mouseTranslateSpace_mF9266577B9AC52FF3E8EEEDD6B902FF61A74BF94,
	XRDeviceSimulator_get_keyboardXTranslateSpeed_m389BC52DEA00FD27DF4FCCDA29B54293C88B8791,
	XRDeviceSimulator_set_keyboardXTranslateSpeed_m68F7FB38A4C94C9CE490C81B935DEB2E89453811,
	XRDeviceSimulator_get_keyboardYTranslateSpeed_m922752C7771B3AEF27485A3295FB7BFD81B0630F,
	XRDeviceSimulator_set_keyboardYTranslateSpeed_m8258090B50D3E65A36A7B0DA6BEBE01D0341E81D,
	XRDeviceSimulator_get_keyboardZTranslateSpeed_mCA243411A3963B47CA8E534D9EB16F6599FA05CD,
	XRDeviceSimulator_set_keyboardZTranslateSpeed_m44E32EFE21308F559FDD0F2A344E8B67887EF81B,
	XRDeviceSimulator_get_mouseXTranslateSensitivity_m1504A63453D5CC021B445FB8CAF316F196821424,
	XRDeviceSimulator_set_mouseXTranslateSensitivity_m3A90484266B8310E1C9FCB719781BF6B33994945,
	XRDeviceSimulator_get_mouseYTranslateSensitivity_m642A808C643B1376D4D807D06FA2A5BC1C50BF74,
	XRDeviceSimulator_set_mouseYTranslateSensitivity_m4BBA160B76EE5F21EC8BD32F4CF680D8873B85B8,
	XRDeviceSimulator_get_mouseScrollTranslateSensitivity_mE0D21CF2BED48CF37F59B63BB9DA971361FFFAAF,
	XRDeviceSimulator_set_mouseScrollTranslateSensitivity_m47C02FCED3054DB801CA902049D0DE4D1264CB49,
	XRDeviceSimulator_get_mouseXRotateSensitivity_m640232A7A57AC262214ED5AA126901BD95D629C3,
	XRDeviceSimulator_set_mouseXRotateSensitivity_m5253525A9FBE8FCDF378C783AA84479F68DBBA6D,
	XRDeviceSimulator_get_mouseYRotateSensitivity_m1A7EDA07D6A575189DFAEF5C54295BC4D902A4A0,
	XRDeviceSimulator_set_mouseYRotateSensitivity_mF8765671B6B5965442DDE6E62D1C1F5F8696C3D8,
	XRDeviceSimulator_get_mouseScrollRotateSensitivity_m27C0ABBACC66FD4BC97B6037EFF971FC170A5965,
	XRDeviceSimulator_set_mouseScrollRotateSensitivity_mA13117FF8411100F7E2478FFD646D3CCF3F2CB3B,
	XRDeviceSimulator_get_mouseYRotateInvert_m398877E0C1C8F04B3DA76F8CB84D4B889AB60242,
	XRDeviceSimulator_set_mouseYRotateInvert_mB9456EC115026466FF5ADB444AC27F4940764592,
	XRDeviceSimulator_get_desiredCursorLockMode_m3ECE62FE6FCC61F60A56432597AF19D44555F843,
	XRDeviceSimulator_set_desiredCursorLockMode_mBD392BDE2729319B4BBD3E372A72164276816C88,
	XRDeviceSimulator_get_mouseTransformationMode_m4B1DA38C4DDCC9785B3B219F9A550A98E7DECEA1,
	XRDeviceSimulator_set_mouseTransformationMode_m660FD714F69BB1D3BA010C8C5F1278349A4C0B3D,
	XRDeviceSimulator_get_axis2DTargets_m309638162C67C1A72F68994752C16F50F6DB0FEF,
	XRDeviceSimulator_set_axis2DTargets_m0D927832A2EDEDFBA734E03856DF8525430B08CA,
	XRDeviceSimulator_Awake_mB7354166CC56F521B90B60B03C95F8876ACEDE0E,
	XRDeviceSimulator_OnEnable_mABA8CCD66A510B8267D32B79C75D7F1AD8C86C9D,
	XRDeviceSimulator_OnDisable_mA36DC085A76AAB0A0A593FEE28A4FA15E78A2708,
	XRDeviceSimulator_Update_m1862A567D5B8003D30A0BDEB71229D61F1F1B27B,
	XRDeviceSimulator_ProcessPoseInput_m9DE0CD2B443DAF1DAD34D1960D717456C6AAD905,
	XRDeviceSimulator_ProcessControlInput_mD3A3C40953B571571370883177CFDF3BEF613691,
	XRDeviceSimulator_ProcessAxis2DControlInput_m8F7CD38A2329FCFCB8F278D58224DB49A4924DD9,
	XRDeviceSimulator_ProcessButtonControlInput_m4A2AFCA8A0754EDEE25C336AC07F9AC41662E297,
	XRDeviceSimulator_AddDevices_m7A66EC8ABC4D2CF81EA42EB1F8072F32B6E4D496,
	XRDeviceSimulator_RemoveDevices_m4F234089A219F2460DC88E70E679DE414DD7EEFF,
	XRDeviceSimulator_GetResetScale_mCB1E0A5E967781B3816F31EFFC32056E361EEA53,
	XRDeviceSimulator_GetAxes_mFF030276175F56454AC60CCCC6D02C35C6C33836,
	XRDeviceSimulator_GetDeltaRotation_m4DCF5F75EE0D312B36645EC08DF2EE329A8C3ABD,
	XRDeviceSimulator_GetDeltaRotation_mDCF47ED8533052B93FC8884173C90DE293963A1B,
	XRDeviceSimulator_Subscribe_m94B54AD4163BE1FC8818A38781BA4E02D865C4C8,
	XRDeviceSimulator_Unsubscribe_m67CF8C4C8C245834AD5899CF9353C53D55F5D315,
	XRDeviceSimulator_Negate_mFDD855D432CF1EBB2C0CB7AF36B98D6749DCC5DE,
	XRDeviceSimulator_Negate_m83389CDC34F3273C4B0A84CD51EA2A96AF4B367F,
	XRDeviceSimulator_SubscribeKeyboardXTranslateAction_mF5F214D6BE91F7D40A942F9FCF0C505A9BCB62A7,
	XRDeviceSimulator_UnsubscribeKeyboardXTranslateAction_m17B0CB976185047968EE8DACF1AFFEDC922A3326,
	XRDeviceSimulator_SubscribeKeyboardYTranslateAction_m3476DB11F7CBF16F6F96F5FCB70D2F09EE91A51A,
	XRDeviceSimulator_UnsubscribeKeyboardYTranslateAction_mCF1C30BE8B5A92D13E93EA24783C2C9E49E3E559,
	XRDeviceSimulator_SubscribeKeyboardZTranslateAction_mF3D0838F678A3C975BB07A040FE6BB13EBE60C73,
	XRDeviceSimulator_UnsubscribeKeyboardZTranslateAction_m03AABC3A9C51776A67F67EF9150E6DEC0C084E51,
	XRDeviceSimulator_SubscribeManipulateLeftAction_mD53C13547F74736EB1F5028C38B1EF027E7E1259,
	XRDeviceSimulator_UnsubscribeManipulateLeftAction_mE7A2810F552F643BE8D136497007F74230675EDB,
	XRDeviceSimulator_SubscribeManipulateRightAction_mEEC6214614815D4EC0672AEA1DCE96E800725B3C,
	XRDeviceSimulator_UnsubscribeManipulateRightAction_m8C3ED9D684E387BAEA913CE292436ABB624F559C,
	XRDeviceSimulator_SubscribeToggleManipulateLeftAction_mBD922DA8476E6E8C34A95DEFF25F19A611607498,
	XRDeviceSimulator_UnsubscribeToggleManipulateLeftAction_m58515CBE068E443BA8C10EDA17C40CA3C3AA2013,
	XRDeviceSimulator_SubscribeToggleManipulateRightAction_mF8F99C0864D39497558B37FE66F476CCE907FF26,
	XRDeviceSimulator_UnsubscribeToggleManipulateRightAction_mEF6C726FFB815DE24298CD9A872E8DA0C380F3E2,
	XRDeviceSimulator_SubscribeManipulateHeadAction_mD93767D23006A63DD6609CC010FE1D811CD4718B,
	XRDeviceSimulator_UnsubscribeManipulateHeadAction_m7CE0F054B5B0F4AB0A0E3262F19E77006AEC37A5,
	XRDeviceSimulator_SubscribeMouseDeltaAction_mFBC26E52821E64B00A48B28528144C477D79A449,
	XRDeviceSimulator_UnsubscribeMouseDeltaAction_m4920F0A5805479C8D0EC907F9E1801012B8C53C4,
	XRDeviceSimulator_SubscribeMouseScrollAction_m2EA3A72C5F1197778296EC30FE2339E59B3307E5,
	XRDeviceSimulator_UnsubscribeMouseScrollAction_m1CCAC1953BD5ECAE03520DFAF98BF6C3806C7A5E,
	XRDeviceSimulator_SubscribeRotateModeOverrideAction_m675403D07C133800BCB377D1ABDA6FA822D3A831,
	XRDeviceSimulator_UnsubscribeRotateModeOverrideAction_m432358631EFED54244B3C75E2536C2041919E3BB,
	XRDeviceSimulator_SubscribeToggleMouseTransformationModeAction_mCA640A12CE85726CDEF7577A4B5BD6E7605DE398,
	XRDeviceSimulator_UnsubscribeToggleMouseTransformationModeAction_m2F1E864A99BA95B4A210E8143854F3BB87129C8E,
	XRDeviceSimulator_SubscribeNegateModeAction_m3D1CB0B778CE5ED454F6C71AE969A13EF5092BCD,
	XRDeviceSimulator_UnsubscribeNegateModeAction_m29A64AE898E18B60CF07B9D1854C4A7938F313F8,
	XRDeviceSimulator_SubscribeXConstraintAction_mEC462812ED2BE192DF2140F610DCD6EF495149F5,
	XRDeviceSimulator_UnsubscribeXConstraintAction_mE32B6BDA4A4C8DF81466ED5C0A2C21B5E5D9FA60,
	XRDeviceSimulator_SubscribeYConstraintAction_mAEA84DE97813CCF038E9F0323988DF18D7DF708D,
	XRDeviceSimulator_UnsubscribeYConstraintAction_m4FB08602488FAF46370C7C546BC9A1E500C9F1F9,
	XRDeviceSimulator_SubscribeZConstraintAction_m9DC31BFE74DC3BE79F674E32F7BFD118CFE3D263,
	XRDeviceSimulator_UnsubscribeZConstraintAction_mD5F5C32604FA9279C4A2E4F5CA5930BD4365896C,
	XRDeviceSimulator_SubscribeResetAction_mE43405C6958110CE587F3DEC8614F739F29FC907,
	XRDeviceSimulator_UnsubscribeResetAction_m297A5FA135042071E0ADF8D22E6FA072D16270DB,
	XRDeviceSimulator_SubscribeToggleCursorLockAction_m69D27C5AD4016B86E8E5547524E0CB9594A925DF,
	XRDeviceSimulator_UnsubscribeToggleCursorLockAction_mD2127A2E97077EC68E55277CFD0458A1BFC3B3D2,
	XRDeviceSimulator_SubscribeToggleDevicePositionTargetAction_m1718D06DAA48D827A4A660AA78563152C3B6BDB3,
	XRDeviceSimulator_UnsubscribeToggleDevicePositionTargetAction_m8AB133CDF4AF1A49467E7CBB7F624EB5CC07A334,
	XRDeviceSimulator_SubscribeTogglePrimary2DAxisTargetAction_m9EABDF1D9C2D3CD4D75FCC8A0A28A26BCB9D6E9E,
	XRDeviceSimulator_UnsubscribeTogglePrimary2DAxisTargetAction_m3690C2751B86388858068BB1F4EF163CFD89D490,
	XRDeviceSimulator_SubscribeToggleSecondary2DAxisTargetAction_mBFCB0BD393716F2BDDFC3268F92466CC69012A8D,
	XRDeviceSimulator_UnsubscribeToggleSecondary2DAxisTargetAction_m863257972E56B7226952901D2D7D5A91FB789927,
	XRDeviceSimulator_SubscribeAxis2DAction_m275D1053C828F34EDB7883C4EE22C555D2176A89,
	XRDeviceSimulator_UnsubscribeAxis2DAction_mD7054D44E01F2FA50432CB6B0F1F4C2C37BA12F3,
	XRDeviceSimulator_SubscribeRestingHandAxis2DAction_m8ED686AC4E153E5870A5EA493A3742038898CEF1,
	XRDeviceSimulator_UnsubscribeRestingHandAxis2DAction_mBBE849D0687339DABC2773440D2C3B1B6E9804B0,
	XRDeviceSimulator_SubscribeGripAction_mF6B3FAF307A12624EA0ABE3A9ADB1C924005C480,
	XRDeviceSimulator_UnsubscribeGripAction_m23A1AAFBA30065E12F94CD01ACA9B490D3367D7B,
	XRDeviceSimulator_SubscribeTriggerAction_m10D96C279FD777BE6D52EB1DB97F7DCE9BE321BF,
	XRDeviceSimulator_UnsubscribeTriggerAction_m1101AC4637487B6EE50DE3D1404784505350CE74,
	XRDeviceSimulator_SubscribePrimaryButtonAction_mF2C0DFCBD5A571C6F123B54F28FECA7C969E6D10,
	XRDeviceSimulator_UnsubscribePrimaryButtonAction_m22592C5ED5EB11FCE993554F5D9C90654A4CF4EE,
	XRDeviceSimulator_SubscribeSecondaryButtonAction_m659FA3C481C9C04AF3FA2BB7C7DE01406335B912,
	XRDeviceSimulator_UnsubscribeSecondaryButtonAction_mBCD0F9829C2C2BC01F5D8A8D320EE80BB730E468,
	XRDeviceSimulator_SubscribeMenuAction_m2ABF5166EC9983EC68D8F23C37C5E11F45275E7F,
	XRDeviceSimulator_UnsubscribeMenuAction_m6DA07E7D80E16E62E5D9EBA281052959128B7C58,
	XRDeviceSimulator_SubscribePrimary2DAxisClickAction_mAD230435692F196C0F967879E49E17BC7C6822B8,
	XRDeviceSimulator_UnsubscribePrimary2DAxisClickAction_m9E1779EDDD5709FCC3CF11CDE6B7453A7B37A71A,
	XRDeviceSimulator_SubscribeSecondary2DAxisClickAction_m3ABE2D97B22137F00ABC74EE676B062FCD62ECE4,
	XRDeviceSimulator_UnsubscribeSecondary2DAxisClickAction_m3387E29A3C191F17CEA7030DC94BB2B4BDBBF1E6,
	XRDeviceSimulator_SubscribePrimary2DAxisTouchAction_mBC001D662AA4AE964D01CD1BAD0610E050F8F07E,
	XRDeviceSimulator_UnsubscribePrimary2DAxisTouchAction_m64B6E6305AC8153A62D7B17247E4CB1690F0E0FC,
	XRDeviceSimulator_SubscribeSecondary2DAxisTouchAction_mDA7DF3C1B099219DEE159DC84064DF025C74C159,
	XRDeviceSimulator_UnsubscribeSecondary2DAxisTouchAction_mD7B613B55AEF309407C78C126B30E62BA8490585,
	XRDeviceSimulator_SubscribePrimaryTouchAction_m757B15220C07284598CFF79169F0DD6E786D79E9,
	XRDeviceSimulator_UnsubscribePrimaryTouchAction_m99632A4EACE31027FA50710717AD4DCDAA630E27,
	XRDeviceSimulator_SubscribeSecondaryTouchAction_mD6CC16F35F94B68735A93ECC5E2B0451CFFD5BA1,
	XRDeviceSimulator_UnsubscribeSecondaryTouchAction_mCC186602E6C37BC40AEDE17C4E25F7B17CDC0CF1,
	XRDeviceSimulator_OnKeyboardXTranslatePerformed_mFCAC0258E6CC92FAFE3F91895BF06DE865D2C220,
	XRDeviceSimulator_OnKeyboardXTranslateCanceled_mBD214F23552B463B76402D8A6D5C2C2ED9C59F16,
	XRDeviceSimulator_OnKeyboardYTranslatePerformed_m40F8069EAD76BA7E5D685102CCDB28DA2829F2D0,
	XRDeviceSimulator_OnKeyboardYTranslateCanceled_mF089B425991D3DD571F436E0F0E18125FF7D7900,
	XRDeviceSimulator_OnKeyboardZTranslatePerformed_mAAB7B25C23D5E23D50AA933D11EA700630C86AEC,
	XRDeviceSimulator_OnKeyboardZTranslateCanceled_m20D44E88F331E32453CE24F34E5B5E86F9D5943F,
	XRDeviceSimulator_OnManipulateLeftPerformed_mF23C2D6A5FC42C695C8CBA046B2E19B15F0271AB,
	XRDeviceSimulator_OnManipulateLeftCanceled_m19CF065C2C176BCCF4B95FA32D9FBE95ED5DFCA2,
	XRDeviceSimulator_OnManipulateRightPerformed_mCE9A6D27C1706457951B57B165D89FBF9BF260B0,
	XRDeviceSimulator_OnManipulateRightCanceled_mCB8958CD353CD0B26C566579F512FC0514DD7169,
	XRDeviceSimulator_OnToggleManipulateLeftPerformed_m1B3566D17D261DE520F311B1FFD51B771E081004,
	XRDeviceSimulator_OnToggleManipulateRightPerformed_mE6E471CB74C52993FF3B515DD1FBCDDE7481B213,
	XRDeviceSimulator_OnManipulateHeadPerformed_mFB8D9828739B209D08EEA0D1A8C2E6B4A9B57E07,
	XRDeviceSimulator_OnManipulateHeadCanceled_mFFBE7BA9559CCE2DB07F672BFF5E395624EB34AE,
	XRDeviceSimulator_OnMouseDeltaPerformed_m4CA1862B19F8B444BC6AC423E22F9408E875BD91,
	XRDeviceSimulator_OnMouseDeltaCanceled_m6CB39E02ED7F5793569BDCC75E9FF239F738EC0B,
	XRDeviceSimulator_OnMouseScrollPerformed_m95786C5926090F9A201C22D7126C1FFD76447A5C,
	XRDeviceSimulator_OnMouseScrollCanceled_mDBD720D6A5B8F31473B0D6556638872D785E69C1,
	XRDeviceSimulator_OnRotateModeOverridePerformed_m1BE1317326284C080D7A7F0A5A7AA9E697A12678,
	XRDeviceSimulator_OnRotateModeOverrideCanceled_mAE8D8DAC62B3AFA676A68E227B802897AE521B44,
	XRDeviceSimulator_OnToggleMouseTransformationModePerformed_m5BC9D11803692128CBAB258E1FD55BCF013B93BC,
	XRDeviceSimulator_OnNegateModePerformed_m64FF191DF49B980B1DAC7AC9736D308A17ADC8B2,
	XRDeviceSimulator_OnNegateModeCanceled_m7D92F90F5893FB5C62ACBDECFCD8A26DEE813AAF,
	XRDeviceSimulator_OnXConstraintPerformed_m4F20432B217EB5AA31E9B8D1C3682F50352F2FAB,
	XRDeviceSimulator_OnXConstraintCanceled_mA6E34558C4D79762840CAEA3861BEAF38214B7FF,
	XRDeviceSimulator_OnYConstraintPerformed_m8A9FA9338631AD01BEB211894588D40CE713855F,
	XRDeviceSimulator_OnYConstraintCanceled_m447AEF57E5584D790F01A0FD646B1769FD24846B,
	XRDeviceSimulator_OnZConstraintPerformed_m96B5BA427F6A3A2D91CA3C4EE6EFB64A8AE08A73,
	XRDeviceSimulator_OnZConstraintCanceled_mF70A4658361DB0669A0D88EDA8F507BFFAF7C4EE,
	XRDeviceSimulator_OnResetPerformed_m6806C760C8DFC82949BA4D70B0118AAEE2DE2394,
	XRDeviceSimulator_OnResetCanceled_mA06C83A4037DB3E800B13C5AE046430B3F4612C8,
	XRDeviceSimulator_OnToggleCursorLockPerformed_m6EDD25F207DFBED58F76DF23BBA9239C045858E7,
	XRDeviceSimulator_OnToggleDevicePositionTargetPerformed_m0037BE411764319DEB1D1AF25D0C0AA25DD18AE3,
	XRDeviceSimulator_OnTogglePrimary2DAxisTargetPerformed_m892D157F0D0E8ACF21D01C275DF81BCFD1BFFFC5,
	XRDeviceSimulator_OnToggleSecondary2DAxisTargetPerformed_m8C2D0BD581AD2359AEAA5809EB722DACF56CD80A,
	XRDeviceSimulator_OnAxis2DPerformed_mD5664DCB475D5F3C924E23D0D6C1FA2BBA1C38B2,
	XRDeviceSimulator_OnAxis2DCanceled_m764D20A59AAB7E41B5F9701014A797C8CAE9B31D,
	XRDeviceSimulator_OnRestingHandAxis2DPerformed_mF88AB28FD2D3104B56460D04E5ED94E5D76981C8,
	XRDeviceSimulator_OnRestingHandAxis2DCanceled_m81B48D1151E59B2127A6424BCA390FD695557EA8,
	XRDeviceSimulator_OnGripPerformed_mFF57E28A0F5C3FA3F01A5B6070B93A551F527F11,
	XRDeviceSimulator_OnGripCanceled_m06150399A70700B0E3AADCE3A221DE582637DE54,
	XRDeviceSimulator_OnTriggerPerformed_m1BCAC29E1AD73CE447E9A4A795FC13F37CE1660E,
	XRDeviceSimulator_OnTriggerCanceled_mD02FE23ABB6A93E85C8E7D3A0FDCE6FEF3C13D93,
	XRDeviceSimulator_OnPrimaryButtonPerformed_mFF4B8B2C09231ADCA420F06FFE8EB1FD4EEC4BD6,
	XRDeviceSimulator_OnPrimaryButtonCanceled_m81D740D5C0DC62D465F2673AEB6CB73042EF185E,
	XRDeviceSimulator_OnSecondaryButtonPerformed_m5178544B95463BDA3058B0D29BDC396AE7B37211,
	XRDeviceSimulator_OnSecondaryButtonCanceled_mE2771DA3E65DFAC8CAF2505F2EE8A5A5663DD8D0,
	XRDeviceSimulator_OnMenuPerformed_mECE12672BA68D8A48A011904443D2A22F5EB96C6,
	XRDeviceSimulator_OnMenuCanceled_mA3876DEE847FACE2FB13582B7F096CDFEC6D400C,
	XRDeviceSimulator_OnPrimary2DAxisClickPerformed_mC2219112443FF7E03C6755653DB6E38149B66F23,
	XRDeviceSimulator_OnPrimary2DAxisClickCanceled_mD30F7D15FB6A0DD42FE3DB591AD51D1941E4FC0D,
	XRDeviceSimulator_OnSecondary2DAxisClickPerformed_m4C67AE3185C97A85D3A48C62C4F7BAF75311B5F7,
	XRDeviceSimulator_OnSecondary2DAxisClickCanceled_m19423A5BE6CC8EAB8AD576F5A97B3D6C4717A5EE,
	XRDeviceSimulator_OnPrimary2DAxisTouchPerformed_m53471FB52C78133DC361545152034BF1733127F0,
	XRDeviceSimulator_OnPrimary2DAxisTouchCanceled_m6A8280D66B5BEAC7BECFD0E99B45D596A644157B,
	XRDeviceSimulator_OnSecondary2DAxisTouchPerformed_m5A0E5F9B25F1198649BBDED3866E56FE321777DD,
	XRDeviceSimulator_OnSecondary2DAxisTouchCanceled_m36C291294831D2D7C5CE565D0CF84BF20830DD5F,
	XRDeviceSimulator_OnPrimaryTouchPerformed_m292235D411F52FA79F7662B90522260C62163F79,
	XRDeviceSimulator_OnPrimaryTouchCanceled_m6FAFC708C56DE710D2E0EDEC0EAB51439FA282E1,
	XRDeviceSimulator_OnSecondaryTouchPerformed_mC3D6308E6A6D0FBD0E9BA86948274FE472E540DD,
	XRDeviceSimulator_OnSecondaryTouchCanceled_mE504E7C7997707627B60D54E5AB5A715CED4B822,
	XRDeviceSimulator_GetInputAction_mCF2EE1D4E657C46A6A6C2AE241F6D4519DE6792F,
	XRDeviceSimulator__ctor_mD8BB5B64046CD20C8F2904623F02EB3084A3338D,
	XRSimulatedController_get_primary2DAxis_mAF2FED1E7AB64C05557A4A4F7CB52F56E67108FA,
	XRSimulatedController_set_primary2DAxis_m7A0C20F1B4404906C997D9CE91D6C52C50F0F15C,
	XRSimulatedController_get_trigger_m27D6198CE632235EAD8D1F4718331303C51F1875,
	XRSimulatedController_set_trigger_m68796BA3B3A576C7B4FE3F87B0818238F17581FE,
	XRSimulatedController_get_grip_m7A18FD9D5A4568D9798C26EEDA57C1DE9DE3CB25,
	XRSimulatedController_set_grip_mA29793E90FFBAF46AB97ECFDCADF35319225FC5F,
	XRSimulatedController_get_secondary2DAxis_m1F393220F560984BBAA42279EA41B9998DAD62A3,
	XRSimulatedController_set_secondary2DAxis_m613F0CDCCBC1F183CA72C25314F86B1AF178857C,
	XRSimulatedController_get_primaryButton_mC9F0C0771A1127157D33BBDB9FA703199F3CC4FB,
	XRSimulatedController_set_primaryButton_m15D617064AE81505F37102EFF63C7409351B8A7A,
	XRSimulatedController_get_primaryTouch_m6B203A3E37CB2C57A1A880FC46DD993ABEBCC485,
	XRSimulatedController_set_primaryTouch_mDFAF8210AD8C22DE3A9FE56EF0CDFFF34D4C1440,
	XRSimulatedController_get_secondaryButton_m7294824267990D389FD1A2F5C0FE8B4CCF0E2C0E,
	XRSimulatedController_set_secondaryButton_m60115A11E636816EAC49D12C80A0E2FCD7DEE421,
	XRSimulatedController_get_secondaryTouch_mE297E7E8746E76C736E3E84FA257919B71919B0E,
	XRSimulatedController_set_secondaryTouch_mC35856850084AC8AFD91583382C6CD7A19B1477A,
	XRSimulatedController_get_gripButton_m54671C748837AAC21BE0A97C7688A5E391772811,
	XRSimulatedController_set_gripButton_mFD25C7B73E266E962F4947B0F5CE2E4F794E9EAC,
	XRSimulatedController_get_triggerButton_m7AAE82E76AA1F943C6ED68BB3FD7A2E1BC637E34,
	XRSimulatedController_set_triggerButton_mE6B324265109BF69F513972AADF7BBAD404A7AFC,
	XRSimulatedController_get_menuButton_mA7B7A75B485333B47356D280C1001759B7E320E1,
	XRSimulatedController_set_menuButton_mC8BC114ABE931CCC003E4396FF0698809A99B72E,
	XRSimulatedController_get_primary2DAxisClick_m588E4991D53C843C37B4584782DB744B027309E8,
	XRSimulatedController_set_primary2DAxisClick_m638CB68202BC37E28C6F0E57D55E6F8EB331F6B6,
	XRSimulatedController_get_primary2DAxisTouch_m3124E177B5CCE1A73B9AA76BEDF4F8A42DFC43CE,
	XRSimulatedController_set_primary2DAxisTouch_mBC97D927DA2369C28252198AC3C9DD5BB9B59BC1,
	XRSimulatedController_get_secondary2DAxisClick_mE78883C6965CBB7918AC02F2D5DDFDC03A3357CA,
	XRSimulatedController_set_secondary2DAxisClick_m6A4F93455D5534D4E92E319FC4FFA3563B067785,
	XRSimulatedController_get_secondary2DAxisTouch_m96828C8B69B1C2A8E96096198C84514D7D1B6B60,
	XRSimulatedController_set_secondary2DAxisTouch_mCC043B0B0B5151781240A54D17EB6C5F216608DB,
	XRSimulatedController_get_batteryLevel_m594224555A74A8B309D4F7EEDC627BDEF7A4990E,
	XRSimulatedController_set_batteryLevel_m976781C86BAFCB8B6EB82BEF3CE094679EA55FB5,
	XRSimulatedController_get_userPresence_m098F4606FAE0AE89492F73E3017F3BB301FFBDFD,
	XRSimulatedController_set_userPresence_mC9D9BC9139B15D8916BCABB263A03130152A0D01,
	XRSimulatedController_FinishSetup_mC4F39D2415258871BDC77C81A34846D3D2BCB60C,
	XRSimulatedController__ctor_m3FD0B01E3EAF634756117453A5630363F71A5A28,
	XRSimulatedControllerState_get_formatId_m33E91E1AC8A754DB2FAB298BE3CD9F9AA7BF32B4,
	XRSimulatedControllerState_get_format_mEF0A3619592E3FE42EEF41C6C13DCB3281AD4F93,
	XRSimulatedControllerState_WithButton_m19828BD5A6F4B3AC3B3A83EB98172C9099658594,
	XRSimulatedControllerState_Reset_m1216B08CF7B737AABDA2F2E321A8164AD8D17351,
	XRSimulatedHMD__ctor_mAD88459F96D54A3EE12A1C3AED0EA693A0111493,
	XRSimulatedHMDState_get_formatId_m40DE5859F6C18E72436D347602F12DDE29E71706,
	XRSimulatedHMDState_get_format_m6690480C9D6962BDEC42737C39C3FE448ABDCCD6,
	XRSimulatedHMDState_Reset_mF2E881F062465B441F929A6319E6843800A0B9BC,
	SectorInteraction_get_pressPointOrDefault_mE709A4723D93A3D5FC139C363DE576F66CBF334B,
	SectorInteraction_get_defaultPressPoint_mBA26AF006B61005E9C3CAC911325A722786505C2,
	SectorInteraction_set_defaultPressPoint_m4126E087B8480CB673D5510CA5D309D53D558C8D,
	SectorInteraction_Process_m15140D9DD8E6FA0EFF8C60EAD1B9577AE2E9A2EF,
	SectorInteraction_IsValidDirection_mE3A9B2DEF36F7368D0CC27D6E99A2329282E74AE,
	SectorInteraction_GetNearestDirection_mD6BB363B927A3F1821B92E6A4589739A7A5E0DF2,
	SectorInteraction_Reset_mED795C773B8816F14A8F960DE5898B8F803AEEBB,
	SectorInteraction__cctor_mB817DC76635AE8218E6ED13B98FB02291CAAC91B,
	SectorInteraction_Initialize_mA42347DD5E0540724306D8DC659B47DAC898720B,
	SectorInteraction__ctor_mFDBD65DC250F73D14ECC59790FC264DCF250B2D1,
	Vector3FallbackComposite_ReadValue_m8EFF75D486C86B0269C51437B1F14B6AF64912CB,
	Vector3FallbackComposite_Initialize_m2F7E008EAA2DA0E9C5EF3BED00E3E6605B7EAA90,
	Vector3FallbackComposite__cctor_mECF0F5020FEE68767684752180139BD714A2C042,
	Vector3FallbackComposite__ctor_mA7FB7D94F8CC9364D035F53F339A16922A4828E5,
	QuaternionFallbackComposite_ReadValue_mDA42E8F1708CA5FF6576762AA5AD9246CD57F79C,
	QuaternionFallbackComposite_Initialize_mDC5AE52C41780284AFBAEF0DC7DEA4E078E3DDB8,
	QuaternionFallbackComposite__cctor_mA71EFAF4EB3C1694427F846696FD02D9FBF18E4D,
	QuaternionFallbackComposite__ctor_m3B8838F04A32156EAF3BC64828BA26423EFD7023,
	NULL,
	NULL,
	ARAnnotationInteractable__ctor_mBF4CBD033270A86CA19BF97BF0E551015DB218A3,
	ARBaseGestureInteractable__ctor_m7D7701B9E98DDBEF1B8DE65810A1CB5DA566B630,
	ARPlacementInteractable__ctor_m4EAD0538822BFBBDA0E901E8DC336C3A1F0FA525,
	ARRotationInteractable__ctor_mA72FB121E2FCBD152D18E022DEDF50CB220DF7E8,
	ARScaleInteractable__ctor_mAD014E0F828B208D2862EF42FF30AD80F73FA976,
	ARSelectionInteractable__ctor_m01B8BFEA185D36AF5CF566282B1C186A2F6DF578,
	ARTranslationInteractable__ctor_m830DC66E9B418617FD0BC6844D1D4C332F8103A7,
	ARGestureInteractor__ctor_mBDE13EF9AE00A65ABC1FF3E2726FDEE57FDFB7DD,
};
extern void InteractionState_get_value_mD1E8048CF73C1EBD045C1F2598CB8D4300291F89_AdjustorThunk (void);
extern void InteractionState_set_value_m99DCAF279B4C23C1D2690616B6D8E5C9D9CA46BD_AdjustorThunk (void);
extern void InteractionState_get_active_m1E069A7D42F19F587B2F384A8EFB9A3D6EDE8E31_AdjustorThunk (void);
extern void InteractionState_set_active_mA48D0212ED136A9EDB38879A4B1D3A4DB3DB78F3_AdjustorThunk (void);
extern void InteractionState_get_activatedThisFrame_m512E1A559B40E19753A0D9F666B3BB44C8BCC6DA_AdjustorThunk (void);
extern void InteractionState_set_activatedThisFrame_mEF19740F5C82F14B507A05C0CD746BE6E0B703F3_AdjustorThunk (void);
extern void InteractionState_get_deactivatedThisFrame_m9C1D440D21737F44E68D853F0934B0102A87470F_AdjustorThunk (void);
extern void InteractionState_set_deactivatedThisFrame_mA0DCE61AC5D7E1124AA742288C6543419984D786_AdjustorThunk (void);
extern void InteractionState_SetFrameState_m7DF731F357512FDD2952CCEB5F2BDCA64FDE4535_AdjustorThunk (void);
extern void InteractionState_SetFrameState_mFD251DE03E6724F0D133CC5D16543BC560D54674_AdjustorThunk (void);
extern void InteractionState_SetFrameDependent_mA78B0D0627754F8D1B5405695155862AB8EA9B0B_AdjustorThunk (void);
extern void InteractionState_ResetFrameDependent_mE6F39B9BB60334F9652E917EC843F188E54F4F5F_AdjustorThunk (void);
extern void InteractionState_get_deActivatedThisFrame_mFD3F769CA4FC43468E7736C83142E27C96252B70_AdjustorThunk (void);
extern void InteractionState_set_deActivatedThisFrame_m46FBAA1B24DF5B3E7C3865DBBBB500A9D3B22E6F_AdjustorThunk (void);
extern void InteractionState_Reset_m3D7F3D026CC49E00BD95858EE7AE95A0B8923B2F_AdjustorThunk (void);
extern void SamplePoint_get_position_mF9D3DAA244F75823D675144E555BEAC9776CC8E6_AdjustorThunk (void);
extern void SamplePoint_set_position_m7DB8D7915D8C065E2138825C1ECF29460A450633_AdjustorThunk (void);
extern void SamplePoint_get_parameter_m3B1DB18CF168339E8153E33E2FC87983549940BB_AdjustorThunk (void);
extern void SamplePoint_set_parameter_mBEAD6B1E02633C8CA26116F89AFDCBC10D3273F3_AdjustorThunk (void);
extern void InteractionLayerMask_get_value_m1DE10E281BAC55AC711581379777370B8D0EF4AF_AdjustorThunk (void);
extern void InteractionLayerMask_set_value_m59C5C67FB2CC2DCC65CD752B56F3B74E229899E4_AdjustorThunk (void);
extern void InteractionLayerMask_OnAfterDeserialize_m3FDFE3DE357CFE1B8558ED7BDEC7DF4542BE4C58_AdjustorThunk (void);
extern void InteractionLayerMask_OnBeforeSerialize_m673AD8B8D37CF455D65F3D6D3C8AE04C0C68D901_AdjustorThunk (void);
extern void ButtonInfo__ctor_m3478ACD7B8502B0839AAA54A15EC75CE3A5A2A69_AdjustorThunk (void);
extern void GamepadModel_get_leftStick_m05E487F6B1C65806FA9B5657564D00249B6A3556_AdjustorThunk (void);
extern void GamepadModel_set_leftStick_m8579917EDFBF3F998A18240C454FED95E50E1587_AdjustorThunk (void);
extern void GamepadModel_get_dpad_m302B674C6D8AF62092807DAEAAA44AC3992510F1_AdjustorThunk (void);
extern void GamepadModel_set_dpad_m39D1B66AF19424C3A1308577EC7108024DA21963_AdjustorThunk (void);
extern void GamepadModel_get_submitButtonDown_m37C632D27087A446184DEBFF8EEE2E8BCCF8575D_AdjustorThunk (void);
extern void GamepadModel_set_submitButtonDown_m23F72A7B2DF8A8808F6889A1E98BD8931ED3458B_AdjustorThunk (void);
extern void GamepadModel_get_submitButtonDelta_m0EE8DBF1F060C7B0607127FB6AB4E892EC61A611_AdjustorThunk (void);
extern void GamepadModel_set_submitButtonDelta_m9B1EDCDDB54FF0F21E0EF2341EDEC78E4E54A884_AdjustorThunk (void);
extern void GamepadModel_get_cancelButtonDown_m086620B25E1BF6CC385D240CD48CD0DB55D360B9_AdjustorThunk (void);
extern void GamepadModel_set_cancelButtonDown_mF13195D2D11D9371BDC1310B58075B7D93626F84_AdjustorThunk (void);
extern void GamepadModel_get_cancelButtonDelta_m2F7BF6DD3A971F5122856813E3CD13BF868D24DA_AdjustorThunk (void);
extern void GamepadModel_set_cancelButtonDelta_mD4ED8E73A3D8A53E2F8241D31131022FBFB0373B_AdjustorThunk (void);
extern void GamepadModel_get_implementationData_mF118CFCAE36CE8BAF659D32D26B3EFB160A3B3BF_AdjustorThunk (void);
extern void GamepadModel_set_implementationData_mF30CAE55823B11E6951323F6839D519CE2E5EBA9_AdjustorThunk (void);
extern void GamepadModel_Reset_m028796E2B92E78CF1E054A7D97CDF42A9A2AC815_AdjustorThunk (void);
extern void GamepadModel_OnFrameFinished_m2F0775532D18EB593DA0D2D8E1DC025A82C82AD5_AdjustorThunk (void);
extern void ImplementationData_get_consecutiveMoveCount_mA3B5FF3A4D9BBBFD14CBAEF381A3B09245136BF5_AdjustorThunk (void);
extern void ImplementationData_set_consecutiveMoveCount_m91D6C0702BD7F193B029443EB3CFFE3400A873AA_AdjustorThunk (void);
extern void ImplementationData_get_lastMoveDirection_m70CE1DDAEBA14387D27273E11B5C55CD9CA5DD3A_AdjustorThunk (void);
extern void ImplementationData_set_lastMoveDirection_m25C3B0B1B7CCA64B134D4C830A3F29098A0CE90A_AdjustorThunk (void);
extern void ImplementationData_get_lastMoveTime_mE68BD5B91C6F28F0EAF230142A28241181A177F5_AdjustorThunk (void);
extern void ImplementationData_set_lastMoveTime_m204AECF315C9F05B23A27749531D8D43A0825084_AdjustorThunk (void);
extern void ImplementationData_Reset_m6952C9AE850B2D99257334E837C9A923C39867AD_AdjustorThunk (void);
extern void JoystickModel_get_move_mB60103AA953140276E6BDBFF9E2674048B666B81_AdjustorThunk (void);
extern void JoystickModel_set_move_m84DB43EE4C57318CE0B7FFC8416A6E9DC7DEDEFD_AdjustorThunk (void);
extern void JoystickModel_get_hat_m60938F380B439629A5D0E69A9CD0B24812951CC3_AdjustorThunk (void);
extern void JoystickModel_set_hat_mEEFA4CAF09C6DE4B0B10287C9D2276E8D180F232_AdjustorThunk (void);
extern void JoystickModel_get_submitButtonDown_m2C594CD060FC1467793EB7D04F3A356D3FF5215F_AdjustorThunk (void);
extern void JoystickModel_set_submitButtonDown_m972C04699F6CF1AE3EF76B94B9F303D508345596_AdjustorThunk (void);
extern void JoystickModel_get_submitButtonDelta_m012B855F15407CE39563A2465270BFE766488E7A_AdjustorThunk (void);
extern void JoystickModel_set_submitButtonDelta_mBCE238395763AD138FBF5CAD201B57F4AAF0A838_AdjustorThunk (void);
extern void JoystickModel_get_cancelButtonDown_m0D382FCC9FD1D913786C962041D034B0A93FABDA_AdjustorThunk (void);
extern void JoystickModel_set_cancelButtonDown_mF5A043FAAB87DC5964D93A18CF3D643600009BEA_AdjustorThunk (void);
extern void JoystickModel_get_cancelButtonDelta_m51F7C586967ECC22CE4DA5F81255F83347A71E9E_AdjustorThunk (void);
extern void JoystickModel_set_cancelButtonDelta_m508A4F611F64F834D6EDB84B6539F80FAD1F98DE_AdjustorThunk (void);
extern void JoystickModel_get_implementationData_mE5B08F7B50DD4815D1930845A677CB4620467160_AdjustorThunk (void);
extern void JoystickModel_set_implementationData_m1654E5AEE33F55136D14F090EC47DF7E5C097C39_AdjustorThunk (void);
extern void JoystickModel_Reset_mAFDFEBC8EA109267A0A16C62033097C38AB9849E_AdjustorThunk (void);
extern void JoystickModel_OnFrameFinished_mEF369FFD6CC791F3E9EE01510F1B07356D28A804_AdjustorThunk (void);
extern void ImplementationData_get_consecutiveMoveCount_mB600F1F6A45941D8114E410D6014964554D7ADEC_AdjustorThunk (void);
extern void ImplementationData_set_consecutiveMoveCount_mE564012624169F567A720A33E73AA649FD164198_AdjustorThunk (void);
extern void ImplementationData_get_lastMoveDirection_m5795BF4D421FE58497DF6E154592CCC66CA43018_AdjustorThunk (void);
extern void ImplementationData_set_lastMoveDirection_mE7B0C290F1AB9C8C30172606E3B05C9A9EE0B59B_AdjustorThunk (void);
extern void ImplementationData_get_lastMoveTime_mFEE11CE8F3FFDD639707E8064EA99CCD64F5C99F_AdjustorThunk (void);
extern void ImplementationData_set_lastMoveTime_m008BD50A07C1403D58D895BE67A571FF72C914D4_AdjustorThunk (void);
extern void ImplementationData_Reset_m140D036D05B8FF021576CAABBCC5DC942AC9C079_AdjustorThunk (void);
extern void MouseButtonModel_get_isDown_m6D25D5D7BE9E1781DF3B00F4C0ADD0942F7A0A8C_AdjustorThunk (void);
extern void MouseButtonModel_set_isDown_mF109D7F287B91F942F835520CB7B67EC131A9EC0_AdjustorThunk (void);
extern void MouseButtonModel_get_lastFrameDelta_mF2AC9472F0D1F820ED76F1D6F759B84B97E3842E_AdjustorThunk (void);
extern void MouseButtonModel_set_lastFrameDelta_m760052CA3C1CA5CE93AA226D9F6D7D46023D5346_AdjustorThunk (void);
extern void MouseButtonModel_Reset_m04966A9974669AFD8314FF5D8DA61B0AA13D8808_AdjustorThunk (void);
extern void MouseButtonModel_OnFrameFinished_m3AA8EAB2730BD77885C53B5127E65FBADC09DF89_AdjustorThunk (void);
extern void MouseButtonModel_CopyTo_mE192240DC4F3852B78A43812C3273BE692F95B04_AdjustorThunk (void);
extern void MouseButtonModel_CopyFrom_mDB836BEC9F0538CD4C75CC917EA71A474279B1E6_AdjustorThunk (void);
extern void ImplementationData_get_isDragging_m4342CE900F2E1C5F378AAF38248795FDB757278A_AdjustorThunk (void);
extern void ImplementationData_set_isDragging_m23603F83850AE86ED35D0A35EA577A51A5934912_AdjustorThunk (void);
extern void ImplementationData_get_pressedTime_m6BB28908890AC2AA318371062BD0B1825AD011A0_AdjustorThunk (void);
extern void ImplementationData_set_pressedTime_m08CE027B7019E15F97EC2997A310D2E26B2B688A_AdjustorThunk (void);
extern void ImplementationData_get_pressedPosition_m68E4FD86C4F9EC5B81D3A15A9ED5776642075218_AdjustorThunk (void);
extern void ImplementationData_set_pressedPosition_m1402B47299E1C642D94FAF5AA83750DCBC61FA10_AdjustorThunk (void);
extern void ImplementationData_get_pressedRaycast_mBDF58873A81E64D77396EEDD9BA9FDE899807683_AdjustorThunk (void);
extern void ImplementationData_set_pressedRaycast_m3FEA7BEBCA8A181BCBA546A396608AD05E719314_AdjustorThunk (void);
extern void ImplementationData_get_pressedGameObject_mED5188E469B0B53324D43C84CDC4092BFE81802B_AdjustorThunk (void);
extern void ImplementationData_set_pressedGameObject_m43A6B848D7254A1A27999F73ACDEAFC53B69A6E5_AdjustorThunk (void);
extern void ImplementationData_get_pressedGameObjectRaw_mE114B4837644AF9AA92C0AB5952ACC15385A8E35_AdjustorThunk (void);
extern void ImplementationData_set_pressedGameObjectRaw_mBF3547F3629CF684A4151F0EB8EDC49AA6C85D6E_AdjustorThunk (void);
extern void ImplementationData_get_draggedGameObject_m5AABEB516101C86E6A8E7243C2E12B3BD2DDE43E_AdjustorThunk (void);
extern void ImplementationData_set_draggedGameObject_m9992F3D5D397185C774C37867A18FED90348B6F6_AdjustorThunk (void);
extern void ImplementationData_Reset_mE8D9F86E602D177FCA6FEC7F0F8279D9EA08F60F_AdjustorThunk (void);
extern void MouseModel_get_pointerId_m4093B901532AE29AF876BDE011E97CDB75B19A48_AdjustorThunk (void);
extern void MouseModel_get_changedThisFrame_m9FA4FB5A8C2561339EA712BBD12468ADF6B31500_AdjustorThunk (void);
extern void MouseModel_set_changedThisFrame_m654FCF5EE83F82EEFF6939869044FE1781239014_AdjustorThunk (void);
extern void MouseModel_get_position_m7E6304F677CAB4B807B518B947B95AA63A2BE95A_AdjustorThunk (void);
extern void MouseModel_set_position_mF52DACDB97F269AEC85646486093D6A135C5E509_AdjustorThunk (void);
extern void MouseModel_get_deltaPosition_m343DD465AA88D7C5DE2A2E8A48CC3645434F70FF_AdjustorThunk (void);
extern void MouseModel_set_deltaPosition_mF4C0644A65E3E98A9A397643D0E006B9187654DA_AdjustorThunk (void);
extern void MouseModel_get_scrollDelta_mE5D60044DDB3DC20CB2660C371DCF359DE7B19E0_AdjustorThunk (void);
extern void MouseModel_set_scrollDelta_m107437C513BD8F66EFDE6160EF224FEC6DA1F7A9_AdjustorThunk (void);
extern void MouseModel_get_leftButton_m4E4FEAA3354E2243FC862B4E1212D8C372B399A0_AdjustorThunk (void);
extern void MouseModel_set_leftButton_mDFA9E10E68EC1E60BDAA76BEC99F128F69B0272A_AdjustorThunk (void);
extern void MouseModel_set_leftButtonPressed_mF1308166818C7AE8C3083EAE08FF32B24C8DDBF1_AdjustorThunk (void);
extern void MouseModel_get_rightButton_m847C28E359189D4A2D4E39F0F5D3CC9943D5E624_AdjustorThunk (void);
extern void MouseModel_set_rightButton_m41EB3062E8E1FD0F92D648F5591DBCE675E81FDF_AdjustorThunk (void);
extern void MouseModel_set_rightButtonPressed_m87EF490742E8A801BBAB04A32A4B868C7E6031AE_AdjustorThunk (void);
extern void MouseModel_get_middleButton_m8997BE389494AA17D6BF696BDF1E4889A68EA3C1_AdjustorThunk (void);
extern void MouseModel_set_middleButton_m528B124FF921B92CD25CD2EE623D97B8DE01C318_AdjustorThunk (void);
extern void MouseModel_set_middleButtonPressed_mF1E5EA114314006CDD15F484FCE7450F3D3B0A39_AdjustorThunk (void);
extern void MouseModel__ctor_m63009692E802DED0663F43C9C8C5190FF33C8573_AdjustorThunk (void);
extern void MouseModel_OnFrameFinished_m3C72244B03A8536965118B81CB098E355CCAE12D_AdjustorThunk (void);
extern void MouseModel_CopyTo_m783AAB4CDC5D0569D63B7DCDFFDD13E6219AA8BA_AdjustorThunk (void);
extern void MouseModel_CopyFrom_m7B8817A31CE42B0A96A5FAD2B93DEF906E4E1055_AdjustorThunk (void);
extern void InternalData_get_hoverTargets_m7B27E64A82CB4C34D900E18D81B2BDCE8336EA4C_AdjustorThunk (void);
extern void InternalData_set_hoverTargets_m0EBDF30E6181C88E401E66EF7241F8C206B88360_AdjustorThunk (void);
extern void InternalData_get_pointerTarget_m4C93CAD2F36BD7E897463C1C3DE6BD07B741BF06_AdjustorThunk (void);
extern void InternalData_set_pointerTarget_mC6341AA6C2995C1E180BA15AE61884C000F6D89C_AdjustorThunk (void);
extern void InternalData_Reset_m285105197FFE5EC122647161C449132D50E4472F_AdjustorThunk (void);
extern void TouchModel_get_pointerId_mEF567A1F3619C12F6519E4A6335E47BEC45F3D6A_AdjustorThunk (void);
extern void TouchModel_get_selectPhase_m8EF259C3B4DE6A8B17699E796E4294405E07450D_AdjustorThunk (void);
extern void TouchModel_set_selectPhase_m20B064E217FF3B1FC1D408A613E37D482B7ABFE7_AdjustorThunk (void);
extern void TouchModel_get_selectDelta_mE61F993C8533C9E3BBEB2BDBDC65DB68D19C15C5_AdjustorThunk (void);
extern void TouchModel_set_selectDelta_m78599CB986783C0797E2C4DFF21B3C41062E29BD_AdjustorThunk (void);
extern void TouchModel_get_changedThisFrame_mAF76A9DB5F6F80A8BE56ADB2BDD35E55A5BE717B_AdjustorThunk (void);
extern void TouchModel_set_changedThisFrame_m6F51A89025E6D541FAD0C743D409CA10F0981ECF_AdjustorThunk (void);
extern void TouchModel_get_position_m6D3991EE4E0BD3CF7D530F9BDCB34804A21C431F_AdjustorThunk (void);
extern void TouchModel_set_position_mCC5A8772603B39F6EB6440B5592AA3FCB813D908_AdjustorThunk (void);
extern void TouchModel_get_deltaPosition_m8F1A9044D3FFE83FA0E82B3D6268829F6DD2A5CD_AdjustorThunk (void);
extern void TouchModel_set_deltaPosition_m347C7275855704F7257AADD47BCABBBEA82F5499_AdjustorThunk (void);
extern void TouchModel__ctor_m7DCCF8284C173C8BD0BE01B0CD15F912C15FEF4B_AdjustorThunk (void);
extern void TouchModel_Reset_m23AF647E5BDA070B4FAF70877E2A5932D5235454_AdjustorThunk (void);
extern void TouchModel_OnFrameFinished_m4FD14ED5AF9964A444CD372A80B81ED55671FEF2_AdjustorThunk (void);
extern void TouchModel_CopyTo_mDDC9DCAA045380589E0325B4D8D272E419D4A75C_AdjustorThunk (void);
extern void TouchModel_CopyFrom_m6727074A88A573B3B5A696C9BAC2EE03F1FD70FF_AdjustorThunk (void);
extern void ImplementationData_get_hoverTargets_m4291FA348576902BD6421C43CEF21005B42DDEA2_AdjustorThunk (void);
extern void ImplementationData_set_hoverTargets_mA2493C8E719D7734B4B52E0224B269C9265795FE_AdjustorThunk (void);
extern void ImplementationData_get_pointerTarget_m1B2B7AB756D7AB58E4DDD61724B28C5BEA7ED45F_AdjustorThunk (void);
extern void ImplementationData_set_pointerTarget_m0D4C6DE0126FB9B434079FB0191701AE39D11CFA_AdjustorThunk (void);
extern void ImplementationData_get_isDragging_mA2CDC9BC26BCAE431DC2D5556C26C4081C0120EC_AdjustorThunk (void);
extern void ImplementationData_set_isDragging_mF4D332D1A15D3A25CA9DCD01FA66D1DD3509053A_AdjustorThunk (void);
extern void ImplementationData_get_pressedTime_m72D41F1D9D6D5374145B9EA73D48DD514DF57FD8_AdjustorThunk (void);
extern void ImplementationData_set_pressedTime_m1DD37E6DF363A9D52AAB0DF5D41FA85D480412AB_AdjustorThunk (void);
extern void ImplementationData_get_pressedPosition_m521F6BF90F71F5364A9D3C9A7DBEC1B3263C2410_AdjustorThunk (void);
extern void ImplementationData_set_pressedPosition_mE0AE62062AD3BB0B3F91FC5A0A72C984838BB6A8_AdjustorThunk (void);
extern void ImplementationData_get_pressedRaycast_m449154600AFBECB2454BE161E4F2D8E1C64E2725_AdjustorThunk (void);
extern void ImplementationData_set_pressedRaycast_mD8206A598973DF87B20BDBBEC8E6E470D7EDC8FB_AdjustorThunk (void);
extern void ImplementationData_get_pressedGameObject_m1C35ACFE7671A98B1BE4C9E63F99DE6F26F5A701_AdjustorThunk (void);
extern void ImplementationData_set_pressedGameObject_m0B1B3517DF2991D515A6EE42D9A4E1EEB0F3D1A8_AdjustorThunk (void);
extern void ImplementationData_get_pressedGameObjectRaw_m9ACBBB249DE666C8A4FC22EF9D2738F7769ABC26_AdjustorThunk (void);
extern void ImplementationData_set_pressedGameObjectRaw_m53BFBDBF206350007C3B16570C0D1D1017B4478F_AdjustorThunk (void);
extern void ImplementationData_get_draggedGameObject_mE3FA41A9E5B1A53CE2D810ECB6F70E931C8C24D2_AdjustorThunk (void);
extern void ImplementationData_set_draggedGameObject_m6E44F10143BEC035EA6D122100AE0E331D40EF45_AdjustorThunk (void);
extern void ImplementationData_Reset_mCC0BA6F7121A295E5A12ED99C63C2A644C4CBD2D_AdjustorThunk (void);
extern void RaycastHitData__ctor_m46C10CA0C3686A7DFC808CC5E995563E3E6E0900_AdjustorThunk (void);
extern void RaycastHitData_get_graphic_mD7D675E65B6B19526DEC71B273334796C44D7B88_AdjustorThunk (void);
extern void RaycastHitData_get_worldHitPosition_mA36CED27016B4C803EE9129A379C1052152D15F2_AdjustorThunk (void);
extern void RaycastHitData_get_screenPosition_mAAA69CF11624FC7EA8667F228C640DEFCD6FB2AB_AdjustorThunk (void);
extern void RaycastHitData_get_distance_mC2299A0A61CCB9C17D93D532D8DE4109C8291EC0_AdjustorThunk (void);
extern void RaycastHitData_get_displayIndex_mA3B5A6BD21766DBCE8EA33251BF23FDE7DFE0C50_AdjustorThunk (void);
extern void TrackedDeviceModel_get_implementationData_m95202DC252DDE53560803CED892DDD834686B749_AdjustorThunk (void);
extern void TrackedDeviceModel_get_pointerId_m7AEFEA8657A653D0968500004E01A9B8672464DD_AdjustorThunk (void);
extern void TrackedDeviceModel_get_select_mF73B603383F4D45021CD0AAFC29324A54AC8D55D_AdjustorThunk (void);
extern void TrackedDeviceModel_set_select_m9513F69D1C9E4B312EC23820BFC81CA7030E6F02_AdjustorThunk (void);
extern void TrackedDeviceModel_get_selectDelta_m3F6B5717A4F6C2DC505EA92A11846820A14B35FC_AdjustorThunk (void);
extern void TrackedDeviceModel_set_selectDelta_m61649F57176681CCBD64C07F4A4F0F3974DECE4C_AdjustorThunk (void);
extern void TrackedDeviceModel_get_changedThisFrame_m4C3C35C841B822ABB3D5DEE90F26FA74D8EE9FE1_AdjustorThunk (void);
extern void TrackedDeviceModel_set_changedThisFrame_mDE51F8C5DC3A66BA3F13B32F0CEE792E9FF7C1AB_AdjustorThunk (void);
extern void TrackedDeviceModel_get_position_mA1B101753B4DE6F7142EE4DB49487104019DF4BE_AdjustorThunk (void);
extern void TrackedDeviceModel_set_position_mDB462484180081FA49D38E28ACAE1772E8F11442_AdjustorThunk (void);
extern void TrackedDeviceModel_get_orientation_m870C73AC6F4686930F729F7BDBF5812D7BB0CBCA_AdjustorThunk (void);
extern void TrackedDeviceModel_set_orientation_m1A0A17586D375B499F224DECEC2BB19721EF05FA_AdjustorThunk (void);
extern void TrackedDeviceModel_get_raycastPoints_m3087C3A9A899CDA89FABE930AB7CD63A9856E07B_AdjustorThunk (void);
extern void TrackedDeviceModel_set_raycastPoints_m582BE854A82211D8DC757CF5A79445D1DC464C3A_AdjustorThunk (void);
extern void TrackedDeviceModel_get_currentRaycast_mAF58714250F6AB9E34888B19F2449EF2D0FA94E4_AdjustorThunk (void);
extern void TrackedDeviceModel_set_currentRaycast_mB605A8C85EFDAEDC5D8A39468CD0933E54F50C73_AdjustorThunk (void);
extern void TrackedDeviceModel_get_currentRaycastEndpointIndex_m2CF4F264EBDDE6EAE7285ED58636F55FB1FCAA9C_AdjustorThunk (void);
extern void TrackedDeviceModel_set_currentRaycastEndpointIndex_m590E66F5A9635363FE8E140E0F9CC28328AEC2E1_AdjustorThunk (void);
extern void TrackedDeviceModel_get_raycastLayerMask_mB1E60DDB72A91FD2A65B00356D485513174C60AF_AdjustorThunk (void);
extern void TrackedDeviceModel_set_raycastLayerMask_m15984C257F236CA50C3131EE3A6AA7814BAB715B_AdjustorThunk (void);
extern void TrackedDeviceModel_get_scrollDelta_mCADE5E90334C1EE03593B0BCB7E21D55D2098E87_AdjustorThunk (void);
extern void TrackedDeviceModel_set_scrollDelta_m961E99EA067FBCA97B2E8BC805BF1D608DF95014_AdjustorThunk (void);
extern void TrackedDeviceModel__ctor_m2128F49761ECD982EEC5C86F0B18C9991A3ADE2E_AdjustorThunk (void);
extern void TrackedDeviceModel_Reset_m29196B36856087C2404D20AF734005C0BB6B0AA9_AdjustorThunk (void);
extern void TrackedDeviceModel_OnFrameFinished_m0CB3B1A5BB3236A786E674AEE6E740951AC59184_AdjustorThunk (void);
extern void TrackedDeviceModel_CopyTo_m077D1C3D2AB67EE3E95101C04E8ABDFD5D82D56B_AdjustorThunk (void);
extern void TrackedDeviceModel_CopyFrom_m2A29E70045067F467379D43A4AFB7CDCAFC1786B_AdjustorThunk (void);
extern void TrackedDeviceModel_get_maxRaycastDistance_m7D59D0EB9A5D126EB753972241962421E4A41E7A_AdjustorThunk (void);
extern void TrackedDeviceModel_set_maxRaycastDistance_m6EC3C19F85D167D4BFC03883616522D37BFB2648_AdjustorThunk (void);
extern void ImplementationData_get_hoverTargets_m49C9E4E462CC1064607FA5A3BA0EF5AB0360EE0D_AdjustorThunk (void);
extern void ImplementationData_set_hoverTargets_mCD8DCF11D40DAC82195A1724F2BA0D85FF57E70C_AdjustorThunk (void);
extern void ImplementationData_get_pointerTarget_mB2D4D091AC3BC5E937FB7252047DA33AC409FAEB_AdjustorThunk (void);
extern void ImplementationData_set_pointerTarget_m6A49B7736E5B50E934D4D998648ED2AB2D69C582_AdjustorThunk (void);
extern void ImplementationData_get_isDragging_mEE3BF283FC9C5235D15708D18BE89E06319F781D_AdjustorThunk (void);
extern void ImplementationData_set_isDragging_m315511026FE53448151B19E47E4902F90E819BC2_AdjustorThunk (void);
extern void ImplementationData_get_pressedTime_m154FBADD86CD746C703BF37003C64C428CADAC35_AdjustorThunk (void);
extern void ImplementationData_set_pressedTime_m0EB8960EE81F4D82A71AAC719999CE01D64DCDA6_AdjustorThunk (void);
extern void ImplementationData_get_position_m421FC9657A48CBED5AD985B2D7905BF7B06CA446_AdjustorThunk (void);
extern void ImplementationData_set_position_m82C559B25F9B9515CCAE8FA900B78A2072CD3F7E_AdjustorThunk (void);
extern void ImplementationData_get_pressedPosition_mE3E33C31F62A5ABF18461C479CA7DA9D8DB32262_AdjustorThunk (void);
extern void ImplementationData_set_pressedPosition_m9BBCEC0224F0FCB1572F06B61A01074A0CAD5DCA_AdjustorThunk (void);
extern void ImplementationData_get_pressedRaycast_mA355A412C26FAB49EA39F4DEFDA824465DFDE48E_AdjustorThunk (void);
extern void ImplementationData_set_pressedRaycast_mB79CE5436DFBFAB118F234D25B7D49E72582D9EB_AdjustorThunk (void);
extern void ImplementationData_get_pressedGameObject_m81DA354AA04B9531100A8C8C6A61100493115CF5_AdjustorThunk (void);
extern void ImplementationData_set_pressedGameObject_mF87125F8EFFBE3ED0609B5C67EA86704715996FE_AdjustorThunk (void);
extern void ImplementationData_get_pressedGameObjectRaw_mE9702863BC33793FB5DE550F0789A9058F369A2C_AdjustorThunk (void);
extern void ImplementationData_set_pressedGameObjectRaw_m3AEB4F85F771C297EAE30B1CAAFDD990446624B4_AdjustorThunk (void);
extern void ImplementationData_get_draggedGameObject_mBD53214AA566627B15D7EA5F6080758FF95C1848_AdjustorThunk (void);
extern void ImplementationData_set_draggedGameObject_m977BE3A90025D2F50AC30A321D30245423B9CA6A_AdjustorThunk (void);
extern void ImplementationData_Reset_m78CB6F5BD992AECD4D7D58E5880CFC0DF4DBBC55_AdjustorThunk (void);
extern void RegisteredInteractor__ctor_m6F1AB931437F1F9ACEC036DF8D35D6F5615109BF_AdjustorThunk (void);
extern void RegisteredTouch__ctor_mEAB697F13AE6A0335886FE62EF14C790C9077324_AdjustorThunk (void);
extern void XRSimulatedControllerState_get_format_mEF0A3619592E3FE42EEF41C6C13DCB3281AD4F93_AdjustorThunk (void);
extern void XRSimulatedControllerState_WithButton_m19828BD5A6F4B3AC3B3A83EB98172C9099658594_AdjustorThunk (void);
extern void XRSimulatedControllerState_Reset_m1216B08CF7B737AABDA2F2E321A8164AD8D17351_AdjustorThunk (void);
extern void XRSimulatedHMDState_get_format_m6690480C9D6962BDEC42737C39C3FE448ABDCCD6_AdjustorThunk (void);
extern void XRSimulatedHMDState_Reset_mF2E881F062465B441F929A6319E6843800A0B9BC_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[218] = 
{
	{ 0x06000093, InteractionState_get_value_mD1E8048CF73C1EBD045C1F2598CB8D4300291F89_AdjustorThunk },
	{ 0x06000094, InteractionState_set_value_m99DCAF279B4C23C1D2690616B6D8E5C9D9CA46BD_AdjustorThunk },
	{ 0x06000095, InteractionState_get_active_m1E069A7D42F19F587B2F384A8EFB9A3D6EDE8E31_AdjustorThunk },
	{ 0x06000096, InteractionState_set_active_mA48D0212ED136A9EDB38879A4B1D3A4DB3DB78F3_AdjustorThunk },
	{ 0x06000097, InteractionState_get_activatedThisFrame_m512E1A559B40E19753A0D9F666B3BB44C8BCC6DA_AdjustorThunk },
	{ 0x06000098, InteractionState_set_activatedThisFrame_mEF19740F5C82F14B507A05C0CD746BE6E0B703F3_AdjustorThunk },
	{ 0x06000099, InteractionState_get_deactivatedThisFrame_m9C1D440D21737F44E68D853F0934B0102A87470F_AdjustorThunk },
	{ 0x0600009A, InteractionState_set_deactivatedThisFrame_mA0DCE61AC5D7E1124AA742288C6543419984D786_AdjustorThunk },
	{ 0x0600009B, InteractionState_SetFrameState_m7DF731F357512FDD2952CCEB5F2BDCA64FDE4535_AdjustorThunk },
	{ 0x0600009C, InteractionState_SetFrameState_mFD251DE03E6724F0D133CC5D16543BC560D54674_AdjustorThunk },
	{ 0x0600009D, InteractionState_SetFrameDependent_mA78B0D0627754F8D1B5405695155862AB8EA9B0B_AdjustorThunk },
	{ 0x0600009E, InteractionState_ResetFrameDependent_mE6F39B9BB60334F9652E917EC843F188E54F4F5F_AdjustorThunk },
	{ 0x0600009F, InteractionState_get_deActivatedThisFrame_mFD3F769CA4FC43468E7736C83142E27C96252B70_AdjustorThunk },
	{ 0x060000A0, InteractionState_set_deActivatedThisFrame_m46FBAA1B24DF5B3E7C3865DBBBB500A9D3B22E6F_AdjustorThunk },
	{ 0x060000A1, InteractionState_Reset_m3D7F3D026CC49E00BD95858EE7AE95A0B8923B2F_AdjustorThunk },
	{ 0x060003A9, SamplePoint_get_position_mF9D3DAA244F75823D675144E555BEAC9776CC8E6_AdjustorThunk },
	{ 0x060003AA, SamplePoint_set_position_m7DB8D7915D8C065E2138825C1ECF29460A450633_AdjustorThunk },
	{ 0x060003AB, SamplePoint_get_parameter_m3B1DB18CF168339E8153E33E2FC87983549940BB_AdjustorThunk },
	{ 0x060003AC, SamplePoint_set_parameter_mBEAD6B1E02633C8CA26116F89AFDCBC10D3273F3_AdjustorThunk },
	{ 0x060003E4, InteractionLayerMask_get_value_m1DE10E281BAC55AC711581379777370B8D0EF4AF_AdjustorThunk },
	{ 0x060003E5, InteractionLayerMask_set_value_m59C5C67FB2CC2DCC65CD752B56F3B74E229899E4_AdjustorThunk },
	{ 0x060003E9, InteractionLayerMask_OnAfterDeserialize_m3FDFE3DE357CFE1B8558ED7BDEC7DF4542BE4C58_AdjustorThunk },
	{ 0x060003EA, InteractionLayerMask_OnBeforeSerialize_m673AD8B8D37CF455D65F3D6D3C8AE04C0C68D901_AdjustorThunk },
	{ 0x06000583, ButtonInfo__ctor_m3478ACD7B8502B0839AAA54A15EC75CE3A5A2A69_AdjustorThunk },
	{ 0x060005CA, GamepadModel_get_leftStick_m05E487F6B1C65806FA9B5657564D00249B6A3556_AdjustorThunk },
	{ 0x060005CB, GamepadModel_set_leftStick_m8579917EDFBF3F998A18240C454FED95E50E1587_AdjustorThunk },
	{ 0x060005CC, GamepadModel_get_dpad_m302B674C6D8AF62092807DAEAAA44AC3992510F1_AdjustorThunk },
	{ 0x060005CD, GamepadModel_set_dpad_m39D1B66AF19424C3A1308577EC7108024DA21963_AdjustorThunk },
	{ 0x060005CE, GamepadModel_get_submitButtonDown_m37C632D27087A446184DEBFF8EEE2E8BCCF8575D_AdjustorThunk },
	{ 0x060005CF, GamepadModel_set_submitButtonDown_m23F72A7B2DF8A8808F6889A1E98BD8931ED3458B_AdjustorThunk },
	{ 0x060005D0, GamepadModel_get_submitButtonDelta_m0EE8DBF1F060C7B0607127FB6AB4E892EC61A611_AdjustorThunk },
	{ 0x060005D1, GamepadModel_set_submitButtonDelta_m9B1EDCDDB54FF0F21E0EF2341EDEC78E4E54A884_AdjustorThunk },
	{ 0x060005D2, GamepadModel_get_cancelButtonDown_m086620B25E1BF6CC385D240CD48CD0DB55D360B9_AdjustorThunk },
	{ 0x060005D3, GamepadModel_set_cancelButtonDown_mF13195D2D11D9371BDC1310B58075B7D93626F84_AdjustorThunk },
	{ 0x060005D4, GamepadModel_get_cancelButtonDelta_m2F7BF6DD3A971F5122856813E3CD13BF868D24DA_AdjustorThunk },
	{ 0x060005D5, GamepadModel_set_cancelButtonDelta_mD4ED8E73A3D8A53E2F8241D31131022FBFB0373B_AdjustorThunk },
	{ 0x060005D6, GamepadModel_get_implementationData_mF118CFCAE36CE8BAF659D32D26B3EFB160A3B3BF_AdjustorThunk },
	{ 0x060005D7, GamepadModel_set_implementationData_mF30CAE55823B11E6951323F6839D519CE2E5EBA9_AdjustorThunk },
	{ 0x060005D8, GamepadModel_Reset_m028796E2B92E78CF1E054A7D97CDF42A9A2AC815_AdjustorThunk },
	{ 0x060005D9, GamepadModel_OnFrameFinished_m2F0775532D18EB593DA0D2D8E1DC025A82C82AD5_AdjustorThunk },
	{ 0x060005DA, ImplementationData_get_consecutiveMoveCount_mA3B5FF3A4D9BBBFD14CBAEF381A3B09245136BF5_AdjustorThunk },
	{ 0x060005DB, ImplementationData_set_consecutiveMoveCount_m91D6C0702BD7F193B029443EB3CFFE3400A873AA_AdjustorThunk },
	{ 0x060005DC, ImplementationData_get_lastMoveDirection_m70CE1DDAEBA14387D27273E11B5C55CD9CA5DD3A_AdjustorThunk },
	{ 0x060005DD, ImplementationData_set_lastMoveDirection_m25C3B0B1B7CCA64B134D4C830A3F29098A0CE90A_AdjustorThunk },
	{ 0x060005DE, ImplementationData_get_lastMoveTime_mE68BD5B91C6F28F0EAF230142A28241181A177F5_AdjustorThunk },
	{ 0x060005DF, ImplementationData_set_lastMoveTime_m204AECF315C9F05B23A27749531D8D43A0825084_AdjustorThunk },
	{ 0x060005E0, ImplementationData_Reset_m6952C9AE850B2D99257334E837C9A923C39867AD_AdjustorThunk },
	{ 0x060005E1, JoystickModel_get_move_mB60103AA953140276E6BDBFF9E2674048B666B81_AdjustorThunk },
	{ 0x060005E2, JoystickModel_set_move_m84DB43EE4C57318CE0B7FFC8416A6E9DC7DEDEFD_AdjustorThunk },
	{ 0x060005E3, JoystickModel_get_hat_m60938F380B439629A5D0E69A9CD0B24812951CC3_AdjustorThunk },
	{ 0x060005E4, JoystickModel_set_hat_mEEFA4CAF09C6DE4B0B10287C9D2276E8D180F232_AdjustorThunk },
	{ 0x060005E5, JoystickModel_get_submitButtonDown_m2C594CD060FC1467793EB7D04F3A356D3FF5215F_AdjustorThunk },
	{ 0x060005E6, JoystickModel_set_submitButtonDown_m972C04699F6CF1AE3EF76B94B9F303D508345596_AdjustorThunk },
	{ 0x060005E7, JoystickModel_get_submitButtonDelta_m012B855F15407CE39563A2465270BFE766488E7A_AdjustorThunk },
	{ 0x060005E8, JoystickModel_set_submitButtonDelta_mBCE238395763AD138FBF5CAD201B57F4AAF0A838_AdjustorThunk },
	{ 0x060005E9, JoystickModel_get_cancelButtonDown_m0D382FCC9FD1D913786C962041D034B0A93FABDA_AdjustorThunk },
	{ 0x060005EA, JoystickModel_set_cancelButtonDown_mF5A043FAAB87DC5964D93A18CF3D643600009BEA_AdjustorThunk },
	{ 0x060005EB, JoystickModel_get_cancelButtonDelta_m51F7C586967ECC22CE4DA5F81255F83347A71E9E_AdjustorThunk },
	{ 0x060005EC, JoystickModel_set_cancelButtonDelta_m508A4F611F64F834D6EDB84B6539F80FAD1F98DE_AdjustorThunk },
	{ 0x060005ED, JoystickModel_get_implementationData_mE5B08F7B50DD4815D1930845A677CB4620467160_AdjustorThunk },
	{ 0x060005EE, JoystickModel_set_implementationData_m1654E5AEE33F55136D14F090EC47DF7E5C097C39_AdjustorThunk },
	{ 0x060005EF, JoystickModel_Reset_mAFDFEBC8EA109267A0A16C62033097C38AB9849E_AdjustorThunk },
	{ 0x060005F0, JoystickModel_OnFrameFinished_mEF369FFD6CC791F3E9EE01510F1B07356D28A804_AdjustorThunk },
	{ 0x060005F1, ImplementationData_get_consecutiveMoveCount_mB600F1F6A45941D8114E410D6014964554D7ADEC_AdjustorThunk },
	{ 0x060005F2, ImplementationData_set_consecutiveMoveCount_mE564012624169F567A720A33E73AA649FD164198_AdjustorThunk },
	{ 0x060005F3, ImplementationData_get_lastMoveDirection_m5795BF4D421FE58497DF6E154592CCC66CA43018_AdjustorThunk },
	{ 0x060005F4, ImplementationData_set_lastMoveDirection_mE7B0C290F1AB9C8C30172606E3B05C9A9EE0B59B_AdjustorThunk },
	{ 0x060005F5, ImplementationData_get_lastMoveTime_mFEE11CE8F3FFDD639707E8064EA99CCD64F5C99F_AdjustorThunk },
	{ 0x060005F6, ImplementationData_set_lastMoveTime_m008BD50A07C1403D58D895BE67A571FF72C914D4_AdjustorThunk },
	{ 0x060005F7, ImplementationData_Reset_m140D036D05B8FF021576CAABBCC5DC942AC9C079_AdjustorThunk },
	{ 0x060005F8, MouseButtonModel_get_isDown_m6D25D5D7BE9E1781DF3B00F4C0ADD0942F7A0A8C_AdjustorThunk },
	{ 0x060005F9, MouseButtonModel_set_isDown_mF109D7F287B91F942F835520CB7B67EC131A9EC0_AdjustorThunk },
	{ 0x060005FA, MouseButtonModel_get_lastFrameDelta_mF2AC9472F0D1F820ED76F1D6F759B84B97E3842E_AdjustorThunk },
	{ 0x060005FB, MouseButtonModel_set_lastFrameDelta_m760052CA3C1CA5CE93AA226D9F6D7D46023D5346_AdjustorThunk },
	{ 0x060005FC, MouseButtonModel_Reset_m04966A9974669AFD8314FF5D8DA61B0AA13D8808_AdjustorThunk },
	{ 0x060005FD, MouseButtonModel_OnFrameFinished_m3AA8EAB2730BD77885C53B5127E65FBADC09DF89_AdjustorThunk },
	{ 0x060005FE, MouseButtonModel_CopyTo_mE192240DC4F3852B78A43812C3273BE692F95B04_AdjustorThunk },
	{ 0x060005FF, MouseButtonModel_CopyFrom_mDB836BEC9F0538CD4C75CC917EA71A474279B1E6_AdjustorThunk },
	{ 0x06000600, ImplementationData_get_isDragging_m4342CE900F2E1C5F378AAF38248795FDB757278A_AdjustorThunk },
	{ 0x06000601, ImplementationData_set_isDragging_m23603F83850AE86ED35D0A35EA577A51A5934912_AdjustorThunk },
	{ 0x06000602, ImplementationData_get_pressedTime_m6BB28908890AC2AA318371062BD0B1825AD011A0_AdjustorThunk },
	{ 0x06000603, ImplementationData_set_pressedTime_m08CE027B7019E15F97EC2997A310D2E26B2B688A_AdjustorThunk },
	{ 0x06000604, ImplementationData_get_pressedPosition_m68E4FD86C4F9EC5B81D3A15A9ED5776642075218_AdjustorThunk },
	{ 0x06000605, ImplementationData_set_pressedPosition_m1402B47299E1C642D94FAF5AA83750DCBC61FA10_AdjustorThunk },
	{ 0x06000606, ImplementationData_get_pressedRaycast_mBDF58873A81E64D77396EEDD9BA9FDE899807683_AdjustorThunk },
	{ 0x06000607, ImplementationData_set_pressedRaycast_m3FEA7BEBCA8A181BCBA546A396608AD05E719314_AdjustorThunk },
	{ 0x06000608, ImplementationData_get_pressedGameObject_mED5188E469B0B53324D43C84CDC4092BFE81802B_AdjustorThunk },
	{ 0x06000609, ImplementationData_set_pressedGameObject_m43A6B848D7254A1A27999F73ACDEAFC53B69A6E5_AdjustorThunk },
	{ 0x0600060A, ImplementationData_get_pressedGameObjectRaw_mE114B4837644AF9AA92C0AB5952ACC15385A8E35_AdjustorThunk },
	{ 0x0600060B, ImplementationData_set_pressedGameObjectRaw_mBF3547F3629CF684A4151F0EB8EDC49AA6C85D6E_AdjustorThunk },
	{ 0x0600060C, ImplementationData_get_draggedGameObject_m5AABEB516101C86E6A8E7243C2E12B3BD2DDE43E_AdjustorThunk },
	{ 0x0600060D, ImplementationData_set_draggedGameObject_m9992F3D5D397185C774C37867A18FED90348B6F6_AdjustorThunk },
	{ 0x0600060E, ImplementationData_Reset_mE8D9F86E602D177FCA6FEC7F0F8279D9EA08F60F_AdjustorThunk },
	{ 0x0600060F, MouseModel_get_pointerId_m4093B901532AE29AF876BDE011E97CDB75B19A48_AdjustorThunk },
	{ 0x06000610, MouseModel_get_changedThisFrame_m9FA4FB5A8C2561339EA712BBD12468ADF6B31500_AdjustorThunk },
	{ 0x06000611, MouseModel_set_changedThisFrame_m654FCF5EE83F82EEFF6939869044FE1781239014_AdjustorThunk },
	{ 0x06000612, MouseModel_get_position_m7E6304F677CAB4B807B518B947B95AA63A2BE95A_AdjustorThunk },
	{ 0x06000613, MouseModel_set_position_mF52DACDB97F269AEC85646486093D6A135C5E509_AdjustorThunk },
	{ 0x06000614, MouseModel_get_deltaPosition_m343DD465AA88D7C5DE2A2E8A48CC3645434F70FF_AdjustorThunk },
	{ 0x06000615, MouseModel_set_deltaPosition_mF4C0644A65E3E98A9A397643D0E006B9187654DA_AdjustorThunk },
	{ 0x06000616, MouseModel_get_scrollDelta_mE5D60044DDB3DC20CB2660C371DCF359DE7B19E0_AdjustorThunk },
	{ 0x06000617, MouseModel_set_scrollDelta_m107437C513BD8F66EFDE6160EF224FEC6DA1F7A9_AdjustorThunk },
	{ 0x06000618, MouseModel_get_leftButton_m4E4FEAA3354E2243FC862B4E1212D8C372B399A0_AdjustorThunk },
	{ 0x06000619, MouseModel_set_leftButton_mDFA9E10E68EC1E60BDAA76BEC99F128F69B0272A_AdjustorThunk },
	{ 0x0600061A, MouseModel_set_leftButtonPressed_mF1308166818C7AE8C3083EAE08FF32B24C8DDBF1_AdjustorThunk },
	{ 0x0600061B, MouseModel_get_rightButton_m847C28E359189D4A2D4E39F0F5D3CC9943D5E624_AdjustorThunk },
	{ 0x0600061C, MouseModel_set_rightButton_m41EB3062E8E1FD0F92D648F5591DBCE675E81FDF_AdjustorThunk },
	{ 0x0600061D, MouseModel_set_rightButtonPressed_m87EF490742E8A801BBAB04A32A4B868C7E6031AE_AdjustorThunk },
	{ 0x0600061E, MouseModel_get_middleButton_m8997BE389494AA17D6BF696BDF1E4889A68EA3C1_AdjustorThunk },
	{ 0x0600061F, MouseModel_set_middleButton_m528B124FF921B92CD25CD2EE623D97B8DE01C318_AdjustorThunk },
	{ 0x06000620, MouseModel_set_middleButtonPressed_mF1E5EA114314006CDD15F484FCE7450F3D3B0A39_AdjustorThunk },
	{ 0x06000621, MouseModel__ctor_m63009692E802DED0663F43C9C8C5190FF33C8573_AdjustorThunk },
	{ 0x06000622, MouseModel_OnFrameFinished_m3C72244B03A8536965118B81CB098E355CCAE12D_AdjustorThunk },
	{ 0x06000623, MouseModel_CopyTo_m783AAB4CDC5D0569D63B7DCDFFDD13E6219AA8BA_AdjustorThunk },
	{ 0x06000624, MouseModel_CopyFrom_m7B8817A31CE42B0A96A5FAD2B93DEF906E4E1055_AdjustorThunk },
	{ 0x06000625, InternalData_get_hoverTargets_m7B27E64A82CB4C34D900E18D81B2BDCE8336EA4C_AdjustorThunk },
	{ 0x06000626, InternalData_set_hoverTargets_m0EBDF30E6181C88E401E66EF7241F8C206B88360_AdjustorThunk },
	{ 0x06000627, InternalData_get_pointerTarget_m4C93CAD2F36BD7E897463C1C3DE6BD07B741BF06_AdjustorThunk },
	{ 0x06000628, InternalData_set_pointerTarget_mC6341AA6C2995C1E180BA15AE61884C000F6D89C_AdjustorThunk },
	{ 0x06000629, InternalData_Reset_m285105197FFE5EC122647161C449132D50E4472F_AdjustorThunk },
	{ 0x0600062A, TouchModel_get_pointerId_mEF567A1F3619C12F6519E4A6335E47BEC45F3D6A_AdjustorThunk },
	{ 0x0600062B, TouchModel_get_selectPhase_m8EF259C3B4DE6A8B17699E796E4294405E07450D_AdjustorThunk },
	{ 0x0600062C, TouchModel_set_selectPhase_m20B064E217FF3B1FC1D408A613E37D482B7ABFE7_AdjustorThunk },
	{ 0x0600062D, TouchModel_get_selectDelta_mE61F993C8533C9E3BBEB2BDBDC65DB68D19C15C5_AdjustorThunk },
	{ 0x0600062E, TouchModel_set_selectDelta_m78599CB986783C0797E2C4DFF21B3C41062E29BD_AdjustorThunk },
	{ 0x0600062F, TouchModel_get_changedThisFrame_mAF76A9DB5F6F80A8BE56ADB2BDD35E55A5BE717B_AdjustorThunk },
	{ 0x06000630, TouchModel_set_changedThisFrame_m6F51A89025E6D541FAD0C743D409CA10F0981ECF_AdjustorThunk },
	{ 0x06000631, TouchModel_get_position_m6D3991EE4E0BD3CF7D530F9BDCB34804A21C431F_AdjustorThunk },
	{ 0x06000632, TouchModel_set_position_mCC5A8772603B39F6EB6440B5592AA3FCB813D908_AdjustorThunk },
	{ 0x06000633, TouchModel_get_deltaPosition_m8F1A9044D3FFE83FA0E82B3D6268829F6DD2A5CD_AdjustorThunk },
	{ 0x06000634, TouchModel_set_deltaPosition_m347C7275855704F7257AADD47BCABBBEA82F5499_AdjustorThunk },
	{ 0x06000635, TouchModel__ctor_m7DCCF8284C173C8BD0BE01B0CD15F912C15FEF4B_AdjustorThunk },
	{ 0x06000636, TouchModel_Reset_m23AF647E5BDA070B4FAF70877E2A5932D5235454_AdjustorThunk },
	{ 0x06000637, TouchModel_OnFrameFinished_m4FD14ED5AF9964A444CD372A80B81ED55671FEF2_AdjustorThunk },
	{ 0x06000638, TouchModel_CopyTo_mDDC9DCAA045380589E0325B4D8D272E419D4A75C_AdjustorThunk },
	{ 0x06000639, TouchModel_CopyFrom_m6727074A88A573B3B5A696C9BAC2EE03F1FD70FF_AdjustorThunk },
	{ 0x0600063A, ImplementationData_get_hoverTargets_m4291FA348576902BD6421C43CEF21005B42DDEA2_AdjustorThunk },
	{ 0x0600063B, ImplementationData_set_hoverTargets_mA2493C8E719D7734B4B52E0224B269C9265795FE_AdjustorThunk },
	{ 0x0600063C, ImplementationData_get_pointerTarget_m1B2B7AB756D7AB58E4DDD61724B28C5BEA7ED45F_AdjustorThunk },
	{ 0x0600063D, ImplementationData_set_pointerTarget_m0D4C6DE0126FB9B434079FB0191701AE39D11CFA_AdjustorThunk },
	{ 0x0600063E, ImplementationData_get_isDragging_mA2CDC9BC26BCAE431DC2D5556C26C4081C0120EC_AdjustorThunk },
	{ 0x0600063F, ImplementationData_set_isDragging_mF4D332D1A15D3A25CA9DCD01FA66D1DD3509053A_AdjustorThunk },
	{ 0x06000640, ImplementationData_get_pressedTime_m72D41F1D9D6D5374145B9EA73D48DD514DF57FD8_AdjustorThunk },
	{ 0x06000641, ImplementationData_set_pressedTime_m1DD37E6DF363A9D52AAB0DF5D41FA85D480412AB_AdjustorThunk },
	{ 0x06000642, ImplementationData_get_pressedPosition_m521F6BF90F71F5364A9D3C9A7DBEC1B3263C2410_AdjustorThunk },
	{ 0x06000643, ImplementationData_set_pressedPosition_mE0AE62062AD3BB0B3F91FC5A0A72C984838BB6A8_AdjustorThunk },
	{ 0x06000644, ImplementationData_get_pressedRaycast_m449154600AFBECB2454BE161E4F2D8E1C64E2725_AdjustorThunk },
	{ 0x06000645, ImplementationData_set_pressedRaycast_mD8206A598973DF87B20BDBBEC8E6E470D7EDC8FB_AdjustorThunk },
	{ 0x06000646, ImplementationData_get_pressedGameObject_m1C35ACFE7671A98B1BE4C9E63F99DE6F26F5A701_AdjustorThunk },
	{ 0x06000647, ImplementationData_set_pressedGameObject_m0B1B3517DF2991D515A6EE42D9A4E1EEB0F3D1A8_AdjustorThunk },
	{ 0x06000648, ImplementationData_get_pressedGameObjectRaw_m9ACBBB249DE666C8A4FC22EF9D2738F7769ABC26_AdjustorThunk },
	{ 0x06000649, ImplementationData_set_pressedGameObjectRaw_m53BFBDBF206350007C3B16570C0D1D1017B4478F_AdjustorThunk },
	{ 0x0600064A, ImplementationData_get_draggedGameObject_mE3FA41A9E5B1A53CE2D810ECB6F70E931C8C24D2_AdjustorThunk },
	{ 0x0600064B, ImplementationData_set_draggedGameObject_m6E44F10143BEC035EA6D122100AE0E331D40EF45_AdjustorThunk },
	{ 0x0600064C, ImplementationData_Reset_mCC0BA6F7121A295E5A12ED99C63C2A644C4CBD2D_AdjustorThunk },
	{ 0x0600066B, RaycastHitData__ctor_m46C10CA0C3686A7DFC808CC5E995563E3E6E0900_AdjustorThunk },
	{ 0x0600066C, RaycastHitData_get_graphic_mD7D675E65B6B19526DEC71B273334796C44D7B88_AdjustorThunk },
	{ 0x0600066D, RaycastHitData_get_worldHitPosition_mA36CED27016B4C803EE9129A379C1052152D15F2_AdjustorThunk },
	{ 0x0600066E, RaycastHitData_get_screenPosition_mAAA69CF11624FC7EA8667F228C640DEFCD6FB2AB_AdjustorThunk },
	{ 0x0600066F, RaycastHitData_get_distance_mC2299A0A61CCB9C17D93D532D8DE4109C8291EC0_AdjustorThunk },
	{ 0x06000670, RaycastHitData_get_displayIndex_mA3B5A6BD21766DBCE8EA33251BF23FDE7DFE0C50_AdjustorThunk },
	{ 0x06000673, TrackedDeviceModel_get_implementationData_m95202DC252DDE53560803CED892DDD834686B749_AdjustorThunk },
	{ 0x06000674, TrackedDeviceModel_get_pointerId_m7AEFEA8657A653D0968500004E01A9B8672464DD_AdjustorThunk },
	{ 0x06000675, TrackedDeviceModel_get_select_mF73B603383F4D45021CD0AAFC29324A54AC8D55D_AdjustorThunk },
	{ 0x06000676, TrackedDeviceModel_set_select_m9513F69D1C9E4B312EC23820BFC81CA7030E6F02_AdjustorThunk },
	{ 0x06000677, TrackedDeviceModel_get_selectDelta_m3F6B5717A4F6C2DC505EA92A11846820A14B35FC_AdjustorThunk },
	{ 0x06000678, TrackedDeviceModel_set_selectDelta_m61649F57176681CCBD64C07F4A4F0F3974DECE4C_AdjustorThunk },
	{ 0x06000679, TrackedDeviceModel_get_changedThisFrame_m4C3C35C841B822ABB3D5DEE90F26FA74D8EE9FE1_AdjustorThunk },
	{ 0x0600067A, TrackedDeviceModel_set_changedThisFrame_mDE51F8C5DC3A66BA3F13B32F0CEE792E9FF7C1AB_AdjustorThunk },
	{ 0x0600067B, TrackedDeviceModel_get_position_mA1B101753B4DE6F7142EE4DB49487104019DF4BE_AdjustorThunk },
	{ 0x0600067C, TrackedDeviceModel_set_position_mDB462484180081FA49D38E28ACAE1772E8F11442_AdjustorThunk },
	{ 0x0600067D, TrackedDeviceModel_get_orientation_m870C73AC6F4686930F729F7BDBF5812D7BB0CBCA_AdjustorThunk },
	{ 0x0600067E, TrackedDeviceModel_set_orientation_m1A0A17586D375B499F224DECEC2BB19721EF05FA_AdjustorThunk },
	{ 0x0600067F, TrackedDeviceModel_get_raycastPoints_m3087C3A9A899CDA89FABE930AB7CD63A9856E07B_AdjustorThunk },
	{ 0x06000680, TrackedDeviceModel_set_raycastPoints_m582BE854A82211D8DC757CF5A79445D1DC464C3A_AdjustorThunk },
	{ 0x06000681, TrackedDeviceModel_get_currentRaycast_mAF58714250F6AB9E34888B19F2449EF2D0FA94E4_AdjustorThunk },
	{ 0x06000682, TrackedDeviceModel_set_currentRaycast_mB605A8C85EFDAEDC5D8A39468CD0933E54F50C73_AdjustorThunk },
	{ 0x06000683, TrackedDeviceModel_get_currentRaycastEndpointIndex_m2CF4F264EBDDE6EAE7285ED58636F55FB1FCAA9C_AdjustorThunk },
	{ 0x06000684, TrackedDeviceModel_set_currentRaycastEndpointIndex_m590E66F5A9635363FE8E140E0F9CC28328AEC2E1_AdjustorThunk },
	{ 0x06000685, TrackedDeviceModel_get_raycastLayerMask_mB1E60DDB72A91FD2A65B00356D485513174C60AF_AdjustorThunk },
	{ 0x06000686, TrackedDeviceModel_set_raycastLayerMask_m15984C257F236CA50C3131EE3A6AA7814BAB715B_AdjustorThunk },
	{ 0x06000687, TrackedDeviceModel_get_scrollDelta_mCADE5E90334C1EE03593B0BCB7E21D55D2098E87_AdjustorThunk },
	{ 0x06000688, TrackedDeviceModel_set_scrollDelta_m961E99EA067FBCA97B2E8BC805BF1D608DF95014_AdjustorThunk },
	{ 0x06000689, TrackedDeviceModel__ctor_m2128F49761ECD982EEC5C86F0B18C9991A3ADE2E_AdjustorThunk },
	{ 0x0600068A, TrackedDeviceModel_Reset_m29196B36856087C2404D20AF734005C0BB6B0AA9_AdjustorThunk },
	{ 0x0600068B, TrackedDeviceModel_OnFrameFinished_m0CB3B1A5BB3236A786E674AEE6E740951AC59184_AdjustorThunk },
	{ 0x0600068C, TrackedDeviceModel_CopyTo_m077D1C3D2AB67EE3E95101C04E8ABDFD5D82D56B_AdjustorThunk },
	{ 0x0600068D, TrackedDeviceModel_CopyFrom_m2A29E70045067F467379D43A4AFB7CDCAFC1786B_AdjustorThunk },
	{ 0x0600068F, TrackedDeviceModel_get_maxRaycastDistance_m7D59D0EB9A5D126EB753972241962421E4A41E7A_AdjustorThunk },
	{ 0x06000690, TrackedDeviceModel_set_maxRaycastDistance_m6EC3C19F85D167D4BFC03883616522D37BFB2648_AdjustorThunk },
	{ 0x06000692, ImplementationData_get_hoverTargets_m49C9E4E462CC1064607FA5A3BA0EF5AB0360EE0D_AdjustorThunk },
	{ 0x06000693, ImplementationData_set_hoverTargets_mCD8DCF11D40DAC82195A1724F2BA0D85FF57E70C_AdjustorThunk },
	{ 0x06000694, ImplementationData_get_pointerTarget_mB2D4D091AC3BC5E937FB7252047DA33AC409FAEB_AdjustorThunk },
	{ 0x06000695, ImplementationData_set_pointerTarget_m6A49B7736E5B50E934D4D998648ED2AB2D69C582_AdjustorThunk },
	{ 0x06000696, ImplementationData_get_isDragging_mEE3BF283FC9C5235D15708D18BE89E06319F781D_AdjustorThunk },
	{ 0x06000697, ImplementationData_set_isDragging_m315511026FE53448151B19E47E4902F90E819BC2_AdjustorThunk },
	{ 0x06000698, ImplementationData_get_pressedTime_m154FBADD86CD746C703BF37003C64C428CADAC35_AdjustorThunk },
	{ 0x06000699, ImplementationData_set_pressedTime_m0EB8960EE81F4D82A71AAC719999CE01D64DCDA6_AdjustorThunk },
	{ 0x0600069A, ImplementationData_get_position_m421FC9657A48CBED5AD985B2D7905BF7B06CA446_AdjustorThunk },
	{ 0x0600069B, ImplementationData_set_position_m82C559B25F9B9515CCAE8FA900B78A2072CD3F7E_AdjustorThunk },
	{ 0x0600069C, ImplementationData_get_pressedPosition_mE3E33C31F62A5ABF18461C479CA7DA9D8DB32262_AdjustorThunk },
	{ 0x0600069D, ImplementationData_set_pressedPosition_m9BBCEC0224F0FCB1572F06B61A01074A0CAD5DCA_AdjustorThunk },
	{ 0x0600069E, ImplementationData_get_pressedRaycast_mA355A412C26FAB49EA39F4DEFDA824465DFDE48E_AdjustorThunk },
	{ 0x0600069F, ImplementationData_set_pressedRaycast_mB79CE5436DFBFAB118F234D25B7D49E72582D9EB_AdjustorThunk },
	{ 0x060006A0, ImplementationData_get_pressedGameObject_m81DA354AA04B9531100A8C8C6A61100493115CF5_AdjustorThunk },
	{ 0x060006A1, ImplementationData_set_pressedGameObject_mF87125F8EFFBE3ED0609B5C67EA86704715996FE_AdjustorThunk },
	{ 0x060006A2, ImplementationData_get_pressedGameObjectRaw_mE9702863BC33793FB5DE550F0789A9058F369A2C_AdjustorThunk },
	{ 0x060006A3, ImplementationData_set_pressedGameObjectRaw_m3AEB4F85F771C297EAE30B1CAAFDD990446624B4_AdjustorThunk },
	{ 0x060006A4, ImplementationData_get_draggedGameObject_mBD53214AA566627B15D7EA5F6080758FF95C1848_AdjustorThunk },
	{ 0x060006A5, ImplementationData_set_draggedGameObject_m977BE3A90025D2F50AC30A321D30245423B9CA6A_AdjustorThunk },
	{ 0x060006A6, ImplementationData_Reset_m78CB6F5BD992AECD4D7D58E5880CFC0DF4DBBC55_AdjustorThunk },
	{ 0x06000722, RegisteredInteractor__ctor_m6F1AB931437F1F9ACEC036DF8D35D6F5615109BF_AdjustorThunk },
	{ 0x06000723, RegisteredTouch__ctor_mEAB697F13AE6A0335886FE62EF14C790C9077324_AdjustorThunk },
	{ 0x0600084F, XRSimulatedControllerState_get_format_mEF0A3619592E3FE42EEF41C6C13DCB3281AD4F93_AdjustorThunk },
	{ 0x06000850, XRSimulatedControllerState_WithButton_m19828BD5A6F4B3AC3B3A83EB98172C9099658594_AdjustorThunk },
	{ 0x06000851, XRSimulatedControllerState_Reset_m1216B08CF7B737AABDA2F2E321A8164AD8D17351_AdjustorThunk },
	{ 0x06000854, XRSimulatedHMDState_get_format_m6690480C9D6962BDEC42737C39C3FE448ABDCCD6_AdjustorThunk },
	{ 0x06000855, XRSimulatedHMDState_Reset_mF2E881F062465B441F929A6319E6843800A0B9BC_AdjustorThunk },
};
static const int32_t s_InvokerIndices[2161] = 
{
	6618,
	5305,
	6523,
	5217,
	6523,
	5217,
	6523,
	5217,
	6523,
	5217,
	6523,
	5217,
	6523,
	5217,
	6523,
	5217,
	6523,
	5217,
	6523,
	5217,
	6523,
	5217,
	6523,
	5217,
	6523,
	5217,
	6698,
	6698,
	5261,
	5261,
	4427,
	4764,
	2128,
	6698,
	6698,
	2310,
	10890,
	6628,
	5316,
	6698,
	6536,
	5230,
	6618,
	5305,
	6618,
	5305,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6618,
	5305,
	6569,
	5261,
	6569,
	5261,
	6618,
	5305,
	6541,
	6541,
	6541,
	6569,
	5261,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6569,
	6698,
	6698,
	2605,
	5261,
	5261,
	6698,
	2128,
	4303,
	5261,
	6569,
	5261,
	6628,
	5316,
	6628,
	5316,
	6698,
	6536,
	5230,
	6536,
	5230,
	6536,
	5230,
	6536,
	5230,
	6628,
	5316,
	6536,
	5230,
	6536,
	5230,
	6536,
	5230,
	6536,
	5230,
	6569,
	5261,
	6526,
	5261,
	5261,
	4395,
	4763,
	2128,
	6698,
	6618,
	5305,
	6569,
	5261,
	6569,
	5261,
	6618,
	5305,
	6618,
	5305,
	6486,
	6486,
	6628,
	5316,
	6698,
	6698,
	6698,
	6698,
	5182,
	4303,
	6698,
	6569,
	6486,
	6698,
	6698,
	5261,
	5261,
	6698,
	6698,
	224,
	6698,
	6628,
	5316,
	6618,
	5305,
	6618,
	5305,
	6618,
	5305,
	5305,
	2915,
	5305,
	6698,
	6618,
	5305,
	6698,
	937,
	6698,
	5261,
	141,
	25,
	6698,
	6569,
	6536,
	5230,
	224,
	6698,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	10821,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	10821,
	6465,
	5158,
	6618,
	5305,
	6618,
	5305,
	6569,
	5261,
	6698,
	6698,
	5305,
	6618,
	5261,
	5261,
	5261,
	5261,
	6698,
	11833,
	11833,
	5261,
	5261,
	5261,
	5261,
	6569,
	5261,
	6569,
	6540,
	5235,
	6536,
	5230,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	6618,
	6569,
	6569,
	5261,
	6618,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	3939,
	3972,
	3972,
	4764,
	4427,
	4427,
	5261,
	5261,
	5261,
	5230,
	5261,
	5261,
	5261,
	5261,
	4427,
	5261,
	5261,
	5261,
	5261,
	4427,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	6548,
	5242,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	6569,
	6569,
	6569,
	6569,
	6569,
	6569,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	4764,
	5261,
	5261,
	6569,
	6569,
	5261,
	4427,
	4427,
	6698,
	6569,
	6569,
	5261,
	6628,
	5316,
	6536,
	5230,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6618,
	5305,
	6618,
	5305,
	6628,
	5316,
	6628,
	5316,
	6618,
	5305,
	6618,
	5305,
	6628,
	5316,
	6628,
	5316,
	6618,
	5305,
	6628,
	5316,
	6569,
	5261,
	6628,
	5316,
	6628,
	5316,
	6618,
	5305,
	6618,
	5305,
	6536,
	5230,
	6698,
	5230,
	3939,
	4854,
	3986,
	2879,
	5230,
	5230,
	2926,
	5261,
	5261,
	6698,
	5261,
	5261,
	6698,
	6698,
	6698,
	5261,
	5261,
	5261,
	6698,
	5261,
	4854,
	5261,
	5261,
	5261,
	6698,
	6618,
	5305,
	6698,
	6698,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	10821,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	10821,
	0,
	0,
	0,
	0,
	6628,
	5316,
	6618,
	5305,
	6628,
	5316,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6618,
	5305,
	6628,
	5316,
	6628,
	5316,
	6569,
	5261,
	6618,
	5305,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6618,
	4427,
	6618,
	6698,
	6628,
	5316,
	6569,
	5261,
	6628,
	5316,
	6618,
	5305,
	6618,
	5305,
	6628,
	5316,
	6618,
	5305,
	6548,
	5242,
	6618,
	5305,
	6698,
	6698,
	6698,
	6698,
	9293,
	2003,
	6618,
	6698,
	5261,
	6698,
	6536,
	5230,
	6618,
	5305,
	6618,
	5305,
	6618,
	5305,
	6569,
	5261,
	6618,
	5305,
	6569,
	5261,
	6618,
	5305,
	6569,
	5261,
	6618,
	5305,
	6569,
	5261,
	6618,
	5305,
	6569,
	5261,
	6618,
	5305,
	6569,
	5261,
	6618,
	5305,
	6628,
	5316,
	6628,
	5316,
	6618,
	5305,
	6628,
	5316,
	6628,
	5316,
	6618,
	5305,
	6628,
	5316,
	6628,
	5316,
	6618,
	5305,
	6628,
	5316,
	6628,
	5316,
	6618,
	5305,
	6628,
	5316,
	6628,
	5316,
	6618,
	5305,
	6628,
	5316,
	6628,
	5316,
	6618,
	5305,
	6569,
	5261,
	6698,
	5230,
	5230,
	5261,
	5261,
	6618,
	6618,
	6618,
	6618,
	5261,
	5261,
	5261,
	5261,
	5261,
	2128,
	5261,
	6698,
	6698,
	6698,
	6618,
	6569,
	6569,
	5261,
	6618,
	6569,
	6569,
	5261,
	6618,
	6569,
	6569,
	5261,
	6618,
	6569,
	6569,
	5261,
	6618,
	6618,
	6618,
	6569,
	6698,
	11833,
	6569,
	11833,
	6698,
	6569,
	6569,
	5261,
	5261,
	5261,
	5261,
	6569,
	5261,
	6540,
	5235,
	6569,
	5261,
	6618,
	5305,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6618,
	5305,
	6618,
	5305,
	6618,
	6569,
	6618,
	6569,
	6569,
	5261,
	6618,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	3939,
	3972,
	3972,
	5261,
	6698,
	6698,
	6698,
	6618,
	6618,
	4427,
	4427,
	4427,
	4427,
	4427,
	4427,
	6366,
	5261,
	5230,
	5230,
	5261,
	5261,
	4427,
	5261,
	5261,
	5261,
	5261,
	4427,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	6698,
	6548,
	5242,
	6618,
	5305,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	6569,
	6569,
	6569,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	6569,
	5261,
	6569,
	5261,
	5261,
	4427,
	4427,
	6618,
	5261,
	6698,
	6569,
	6569,
	6698,
	6698,
	5261,
	5261,
	5261,
	6569,
	5230,
	6698,
	5261,
	4427,
	4427,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	4427,
	4427,
	6698,
	11833,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	6536,
	5230,
	6618,
	5305,
	6628,
	5316,
	6569,
	5261,
	6569,
	5261,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6536,
	5230,
	6536,
	5230,
	6628,
	5316,
	6548,
	5242,
	6536,
	5230,
	6618,
	5305,
	6618,
	5305,
	6628,
	5316,
	6618,
	5305,
	6618,
	5305,
	6618,
	5305,
	6628,
	5316,
	6628,
	5316,
	6569,
	5261,
	6628,
	6569,
	6536,
	6698,
	6698,
	6698,
	6698,
	6698,
	8863,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	2003,
	9675,
	872,
	5144,
	4303,
	4303,
	2003,
	4303,
	2003,
	432,
	6698,
	8029,
	7446,
	7081,
	8029,
	911,
	9415,
	2879,
	1451,
	5230,
	5230,
	5261,
	2605,
	6698,
	1790,
	6698,
	1428,
	6618,
	4427,
	4427,
	5261,
	5261,
	6698,
	10652,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	6569,
	5261,
	1193,
	433,
	4303,
	4427,
	4427,
	6698,
	11833,
	1730,
	6698,
	6687,
	5370,
	6628,
	5316,
	6618,
	5305,
	6569,
	5261,
	6569,
	5261,
	6618,
	5305,
	6628,
	5316,
	6628,
	5316,
	6569,
	6698,
	6698,
	5261,
	5261,
	5261,
	6569,
	5230,
	6698,
	9762,
	5261,
	5261,
	5261,
	1144,
	9566,
	6698,
	5261,
	6618,
	6618,
	6366,
	4427,
	6618,
	4427,
	1246,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	4427,
	4427,
	6698,
	11833,
	11833,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	10655,
	10759,
	6536,
	5230,
	10817,
	10657,
	10657,
	6698,
	6698,
	3932,
	3652,
	2870,
	6698,
	6698,
	6698,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6698,
	6698,
	6662,
	5347,
	6698,
	6698,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6698,
	6698,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6618,
	5305,
	6698,
	6698,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6698,
	6698,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6618,
	5305,
	6698,
	6698,
	6569,
	5261,
	6569,
	5261,
	6698,
	6698,
	6569,
	5261,
	6569,
	5261,
	6698,
	6569,
	5261,
	6698,
	6569,
	5261,
	6569,
	5261,
	6698,
	6569,
	5261,
	6569,
	5261,
	6698,
	6569,
	5261,
	6569,
	5261,
	6698,
	6569,
	5261,
	6569,
	5261,
	6698,
	6698,
	6698,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	11786,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	5230,
	5230,
	5230,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	4427,
	4427,
	2075,
	2870,
	9154,
	2870,
	2870,
	5261,
	5261,
	5261,
	5261,
	2870,
	1449,
	5261,
	5261,
	5261,
	5261,
	2870,
	2870,
	2870,
	2870,
	2870,
	2870,
	2870,
	2870,
	2870,
	2870,
	2870,
	2870,
	1449,
	1449,
	1449,
	1449,
	1449,
	1449,
	1449,
	1449,
	2870,
	1449,
	2870,
	1449,
	2085,
	9423,
	5261,
	6698,
	0,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	4427,
	4427,
	3939,
	3939,
	5144,
	1946,
	2870,
	5261,
	5261,
	5261,
	2870,
	5261,
	5261,
	2870,
	2870,
	2870,
	2870,
	2870,
	2870,
	1449,
	1449,
	1449,
	1449,
	2870,
	2870,
	6698,
	11833,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	11833,
	6698,
	6569,
	6569,
	6569,
	6569,
	6569,
	6569,
	6569,
	6569,
	6569,
	5261,
	6628,
	5316,
	6628,
	5316,
	6569,
	6569,
	6698,
	6698,
	6698,
	6698,
	6698,
	5261,
	5261,
	6698,
	5261,
	5261,
	6569,
	6698,
	6523,
	5217,
	6523,
	5217,
	6698,
	6698,
	6685,
	2310,
	6698,
	6523,
	5217,
	6523,
	5217,
	6698,
	6698,
	6685,
	2310,
	6698,
	6628,
	5316,
	6618,
	5305,
	6618,
	5305,
	6536,
	5230,
	6569,
	5261,
	6698,
	0,
	4856,
	5370,
	6698,
	6698,
	6628,
	5316,
	6698,
	0,
	4768,
	5316,
	6698,
	6536,
	5230,
	6569,
	5261,
	6628,
	5316,
	6628,
	5316,
	6685,
	4847,
	4766,
	6698,
	11833,
	6536,
	5230,
	6569,
	5261,
	6628,
	5316,
	6628,
	5316,
	6685,
	4847,
	4766,
	6698,
	11833,
	5261,
	5261,
	5261,
	5261,
	6569,
	5261,
	6698,
	6618,
	6618,
	6618,
	5261,
	5261,
	6698,
	6628,
	5316,
	6569,
	5261,
	6618,
	6698,
	6698,
	3652,
	6698,
	3652,
	6569,
	5261,
	6618,
	6698,
	6523,
	5217,
	6523,
	5217,
	6698,
	6698,
	6685,
	2310,
	6698,
	6536,
	5230,
	6569,
	5261,
	6628,
	5316,
	6685,
	6698,
	11833,
	6628,
	5316,
	6628,
	5316,
	6618,
	5305,
	6618,
	5305,
	6698,
	0,
	4768,
	5316,
	5305,
	6698,
	6698,
	6569,
	5261,
	6536,
	5230,
	6536,
	5230,
	6569,
	5261,
	6698,
	6698,
	1250,
	5261,
	5261,
	5261,
	5261,
	5261,
	1250,
	6698,
	11833,
	6698,
	6569,
	6569,
	5261,
	6698,
	6698,
	6698,
	1250,
	6698,
	1250,
	6698,
	6662,
	5347,
	6618,
	5305,
	4516,
	6698,
	6698,
	8862,
	8862,
	9781,
	7969,
	8515,
	11833,
	2862,
	0,
	8837,
	9154,
	11833,
	6698,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6536,
	5230,
	6628,
	5316,
	6536,
	6687,
	6687,
	6628,
	4482,
	4542,
	2157,
	2157,
	6698,
	11786,
	11016,
	0,
	0,
	0,
	6569,
	5261,
	5261,
	0,
	5261,
	5261,
	5261,
	5261,
	6569,
	5261,
	5261,
	5261,
	6698,
	5261,
	5261,
	4427,
	10895,
	6698,
	11833,
	10821,
	6698,
	6698,
	6698,
	9415,
	6698,
	11833,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	6685,
	5368,
	6685,
	5368,
	6618,
	5305,
	6536,
	5230,
	6618,
	5305,
	6536,
	5230,
	6749,
	5476,
	6698,
	6698,
	6536,
	5230,
	6536,
	5230,
	6628,
	5316,
	6698,
	6685,
	5368,
	6685,
	5368,
	6618,
	5305,
	6536,
	5230,
	6618,
	5305,
	6536,
	5230,
	6794,
	5514,
	6698,
	6698,
	6536,
	5230,
	6536,
	5230,
	6628,
	5316,
	6698,
	6618,
	5305,
	6536,
	5230,
	6698,
	6698,
	5261,
	5261,
	6618,
	5305,
	6628,
	5316,
	6685,
	5368,
	6594,
	5284,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6698,
	6536,
	6618,
	5305,
	6685,
	5368,
	6685,
	5368,
	6685,
	5368,
	6565,
	5257,
	5305,
	6565,
	5257,
	5305,
	6565,
	5257,
	5305,
	5230,
	6698,
	5261,
	5261,
	6569,
	5261,
	6569,
	5261,
	6698,
	6536,
	6536,
	5230,
	6536,
	5230,
	6618,
	5305,
	6685,
	5368,
	6685,
	5368,
	5230,
	6698,
	6698,
	5261,
	5261,
	6569,
	5261,
	6569,
	5261,
	6618,
	5305,
	6628,
	5316,
	6685,
	5368,
	6594,
	5284,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6698,
	5261,
	6569,
	5261,
	6536,
	5230,
	6548,
	5242,
	6569,
	6618,
	5305,
	6618,
	5305,
	6618,
	5305,
	6548,
	5242,
	6536,
	5230,
	6569,
	2870,
	6569,
	9293,
	9294,
	2870,
	446,
	7185,
	7435,
	8850,
	6698,
	11833,
	529,
	6569,
	6687,
	6685,
	6628,
	6536,
	1876,
	6698,
	6853,
	6536,
	6618,
	5305,
	6536,
	5230,
	6618,
	5305,
	6687,
	5370,
	6588,
	5279,
	6569,
	5261,
	6594,
	5284,
	6536,
	5230,
	6548,
	5242,
	6685,
	5368,
	5230,
	5305,
	6698,
	5261,
	5261,
	11825,
	6628,
	5316,
	11833,
	6569,
	5261,
	6569,
	5261,
	6618,
	5305,
	6628,
	5316,
	6685,
	5368,
	6685,
	5368,
	6594,
	5284,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6698,
	6536,
	5230,
	6548,
	5242,
	6536,
	5230,
	6569,
	5261,
	2870,
	6698,
	2870,
	446,
	6698,
	6536,
	5230,
	6592,
	6569,
	2862,
	6618,
	6698,
	6698,
	6569,
	6569,
	1730,
	6698,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6569,
	5261,
	6698,
	6698,
	6698,
	6618,
	4395,
	3995,
	5144,
	5261,
	2605,
	2879,
	5261,
	5144,
	2314,
	5144,
	5144,
	5230,
	3932,
	3932,
	6569,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	6698,
	0,
	0,
	6618,
	5305,
	6618,
	5305,
	6618,
	5305,
	6618,
	5305,
	6618,
	5305,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6698,
	6698,
	5261,
	5261,
	3932,
	2075,
	6698,
	6698,
	6618,
	6698,
	6698,
	6628,
	5316,
	6698,
	2862,
	2938,
	10665,
	6569,
	5261,
	6698,
	6698,
	6698,
	6698,
	6698,
	11008,
	11008,
	11833,
	11833,
	11833,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6536,
	5230,
	6536,
	5230,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6618,
	5305,
	6536,
	5230,
	6536,
	5230,
	6536,
	5230,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	5144,
	6698,
	6698,
	6687,
	7564,
	8486,
	8486,
	8837,
	8837,
	10652,
	3626,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	5484,
	10821,
	6698,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6698,
	6698,
	11767,
	6500,
	3014,
	6698,
	6698,
	11767,
	6500,
	6698,
	6628,
	11816,
	11023,
	5144,
	4303,
	10652,
	6698,
	11833,
	11833,
	6698,
	4851,
	11833,
	11833,
	6698,
	3984,
	11833,
	11833,
	6698,
	0,
	0,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
};
static const Il2CppTokenRangePair s_rgctxIndices[9] = 
{
	{ 0x0200004A, { 11, 25 } },
	{ 0x02000071, { 43, 8 } },
	{ 0x02000076, { 53, 3 } },
	{ 0x02000077, { 56, 12 } },
	{ 0x02000079, { 68, 2 } },
	{ 0x020000A7, { 70, 2 } },
	{ 0x06000490, { 0, 11 } },
	{ 0x06000584, { 36, 7 } },
	{ 0x060005A4, { 51, 2 } },
};
extern const uint32_t g_rgctx_List_1_t0DC065959E682BD91BEC742A2CC136AFBE061B01;
extern const uint32_t g_rgctx_List_1_Clear_mE10FBDE248A39421258982E3498D554D4759443D;
extern const uint32_t g_rgctx_List_1_tA8CC4FA37F69547F8E997FB092A89F94716858BC;
extern const uint32_t g_rgctx_List_1_GetEnumerator_mDBE6E694793BDBB65F18E5A93CB62DCFBD9FCB3F;
extern const uint32_t g_rgctx_Enumerator_get_Current_m871498E53E28AFC7B6A2958617B99366FDF6FE31;
extern const uint32_t g_rgctx_TSource_t4AB3FEC6C9A535E9C016344378C93E8F58D19914;
extern const uint32_t g_rgctx_TDestination_tBFB9A0F406ADD7FB8AA53973B5CBB58B736E2A2F;
extern const uint32_t g_rgctx_List_1_Add_m9F34912E03EC04A59D43666AC334DA93054E8F4E;
extern const uint32_t g_rgctx_Enumerator_MoveNext_mFA7BA77701F8A7D701B9BDB38E08517F5350E042;
extern const uint32_t g_rgctx_Enumerator_t18E4F5A6D3ED7FD5F9D7BF5B70B20929BD9E0C4C;
extern const Il2CppRGCTXConstrainedData g_rgctx_Enumerator_t18E4F5A6D3ED7FD5F9D7BF5B70B20929BD9E0C4C_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7;
extern const uint32_t g_rgctx_HashSet_1_t56A90047C2E3B766AD3D00D3E42892B940DD592F;
extern const uint32_t g_rgctx_HashSet_1_Contains_m739AF1BF8E6C86397838347F8EB6247C3D9C5EF2;
extern const uint32_t g_rgctx_HashSet_1_get_Count_mB826E2503CA807CC5DA7E946D7C37F23794DC871;
extern const uint32_t g_rgctx_HashSet_1_Remove_m245DB2CD2DFF443EA7F3911663EE65FFE362553C;
extern const uint32_t g_rgctx_List_1_tDEDDA3714EF75F3DDF77E03B087C4C3E5995144E;
extern const uint32_t g_rgctx_List_1_Remove_m65E82A6B1535AC0C21AB4BE8C2C61788C4103018;
extern const uint32_t g_rgctx_List_1_Add_m8907C3FE835A833CF3E337C9082756E76AFA0BA9;
extern const uint32_t g_rgctx_HashSet_1_Add_mED74CB9C9AAA0E239F31EFC6E9D0C4B1E68B9E31;
extern const uint32_t g_rgctx_List_1_Contains_m1001B899792BD9A0641B7FBB49AD17F021BD2E8E;
extern const uint32_t g_rgctx_List_1_get_Count_m9BBF0F08860C35E01E81359B1D4A56D6F8E5455C;
extern const uint32_t g_rgctx_List_1_GetEnumerator_mE062419A4E1B97ED3231770EC5D5FCC61434DDB6;
extern const uint32_t g_rgctx_Enumerator_get_Current_m602892762095D49A2BB30DFC6E429AB286F6FE7A;
extern const uint32_t g_rgctx_RegistrationList_1_get_registeredSnapshot_mAFF2D09E3EA4EB7709635FADC7D383E6F367BF70;
extern const uint32_t g_rgctx_Enumerator_MoveNext_m73510958A69FD4502C71AB3724DC3478C1D109D2;
extern const uint32_t g_rgctx_Enumerator_t6F64FD475A391D11C1B25E22757CA59287943A25;
extern const Il2CppRGCTXConstrainedData g_rgctx_Enumerator_t6F64FD475A391D11C1B25E22757CA59287943A25_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7;
extern const uint32_t g_rgctx_List_1_Clear_m8ACFEBBBBA6A936A12DAFD3D8C5870CC956C6F36;
extern const uint32_t g_rgctx_HashSet_1_Clear_m842CF8A613124A89847535991D24CA9C325131B4;
extern const uint32_t g_rgctx_RegistrationList_1_EnsureCapacity_m20D7CD0A6B15CC09D550A8BAB4F2A09A79D76261;
extern const uint32_t g_rgctx_RegistrationList_1_t8FB6DE4F05B868AE445CC388D9BA356783271D27;
extern const uint32_t g_rgctx_List_1_AddRange_mA964A7743E27461014F8986783C031823AF0CC72;
extern const uint32_t g_rgctx_List_1_get_Capacity_mAE87E28F820A84BDC6D0D6457EA4A0FC2FCDC246;
extern const uint32_t g_rgctx_List_1_set_Capacity_mCDC1D68EB8C3638A5A7A82F561E34B968FBFEBC6;
extern const uint32_t g_rgctx_List_1__ctor_m7E5EC5939EA95F8B3147B968A1CAB0DF96284E40;
extern const uint32_t g_rgctx_HashSet_1__ctor_m40C6E225E454BD7D2B40820133F2AC5A1D179FBC;
extern const uint32_t g_rgctx_IList_1_t2CF9E3A700433CF0F80E98279B5661081D646A54;
extern const uint32_t g_rgctx_IList_1_get_Item_mE7399099F98DE32A5AE350737F9B499F8887E05D;
extern const uint32_t g_rgctx_IComparer_1_tC397730A8CBE0973DC34DDB4FA32FCD2E6B160CC;
extern const uint32_t g_rgctx_IComparer_1_Compare_mBCDFEA210FD568216B6D32F42027F242E75143DD;
extern const uint32_t g_rgctx_IList_1_set_Item_mAF1C686F3AFD21F93D2D2ACB4030FC69FDD19D0F;
extern const uint32_t g_rgctx_ICollection_1_tB1C0B877F02467B9B9608BE2610A681CFC3EFDFE;
extern const uint32_t g_rgctx_ICollection_1_get_Count_m0AFC7A7CE90A1705933EBC590A829CA2A1C67BC2;
extern const uint32_t g_rgctx_ScriptableSettingsBase_1_t627139FDDE8A1FA81A1E75F5C68F9E3A9C15C016;
extern const uint32_t g_rgctx_T_tDDF8DE3E2FCFD7B1904152379258589FBB1F96EA;
extern const uint32_t g_rgctx_ScriptableSettings_1_CreateAndLoad_m5F11882BAF69E3248455660CAD0D083545491089;
extern const uint32_t g_rgctx_ScriptableSettings_1_t29CFA08564F3080DFEA2D4A49A5F3C02D6484639;
extern const uint32_t g_rgctx_ScriptableSettingsBase_1_GetFilePath_m785065BD7A895A56CC4FF06319E67B201E0FE242;
extern const uint32_t g_rgctx_ScriptableObject_CreateInstance_TisT_tDDF8DE3E2FCFD7B1904152379258589FBB1F96EA_m9B0AE2378E8B99845F0D735D4A8A36E3711E54AD;
extern const uint32_t g_rgctx_ScriptableSettingsBase_1_Save_mD33A4593900808895C90240ED87C836228C54B52;
extern const uint32_t g_rgctx_ScriptableSettingsBase_1__ctor_m111F4C4B90EA1632A33343E6F53D0D6F5E54792A;
extern const uint32_t g_rgctx_TAttribute_tD84F59BFC25FA20E979CDD1BCEBA60F91566972A;
extern const uint32_t g_rgctx_TAttribute_tD84F59BFC25FA20E979CDD1BCEBA60F91566972A;
extern const uint32_t g_rgctx_ScriptableSettingsBase_1_t0FD07083FE9901216761346ED884D2DC9E88E6B9;
extern const uint32_t g_rgctx_T_tD3F1682F46BD29F3F8A5804BCC3BF81F8123D89D;
extern const uint32_t g_rgctx_T_tD3F1682F46BD29F3F8A5804BCC3BF81F8123D89D;
extern const uint32_t g_rgctx_Func_1_t0F1DF3BBB115D4FB73A2F07292F4A0672F0DBD9B;
extern const uint32_t g_rgctx_Func_1_Invoke_m1BFBC23051AB44B547913554450546CBF26F3C64;
extern const uint32_t g_rgctx_LinkedPool_1_get_countInactive_mC69DA81EDE397CF5FB2D998E88185CF62A5B458A;
extern const uint32_t g_rgctx_LinkedPool_1_set_countInactive_m53BA233B380E53BB6A98CD7348EB606CDC0F287F;
extern const uint32_t g_rgctx_Action_1_t433C2CB55659D8A876C064C6DBA4955680E1F945;
extern const uint32_t g_rgctx_Action_1_Invoke_m304172ABDEE833F5457CAF0D33D7E274C3EE4E0D;
extern const uint32_t g_rgctx_LinkedPool_1_Get_mE38823F44335EC8DFA2881A87C0BAE57C112ED81;
extern const uint32_t g_rgctx_PooledObject_1_t84CDA889C62417483A52F82EE1574CF9D173E9E3;
extern const uint32_t g_rgctx_PooledObject_1__ctor_mC13A8B50534AC85C136BCC3946FA1B561E65CD47;
extern const uint32_t g_rgctx_LinkedPoolItem_tA9FB38C29963A9C41EAE15A8A81F6C009D20C998;
extern const uint32_t g_rgctx_LinkedPoolItem__ctor_m29A8C608AE22E5A5B5A0495E117051FC74F69C8F;
extern const uint32_t g_rgctx_LinkedPool_1_Clear_m58960BFEF9AFF06AFFFD59E3D24029AC5F5B4BF8;
extern const uint32_t g_rgctx_LinkedPool_1_t30CED966D97EFCFE47F2E8206B7E5C3A5D44BD66;
extern const uint32_t g_rgctx_LinkedPool_1_Release_mC17A4980935B556D5952D3343BFB6653AB22E1A1;
extern const uint32_t g_rgctx_InputBindingComposite_1__ctor_m033E97DE8F41C5CDA927522921DD3D114A949B1A;
extern const uint32_t g_rgctx_InputBindingComposite_1_tA4417858E3612F563D25C996250D32C7EB15970F;
static const Il2CppRGCTXDefinition s_rgctxValues[72] = 
{
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_t0DC065959E682BD91BEC742A2CC136AFBE061B01 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Clear_mE10FBDE248A39421258982E3498D554D4759443D },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_tA8CC4FA37F69547F8E997FB092A89F94716858BC },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_GetEnumerator_mDBE6E694793BDBB65F18E5A93CB62DCFBD9FCB3F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_get_Current_m871498E53E28AFC7B6A2958617B99366FDF6FE31 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TSource_t4AB3FEC6C9A535E9C016344378C93E8F58D19914 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TDestination_tBFB9A0F406ADD7FB8AA53973B5CBB58B736E2A2F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Add_m9F34912E03EC04A59D43666AC334DA93054E8F4E },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_MoveNext_mFA7BA77701F8A7D701B9BDB38E08517F5350E042 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Enumerator_t18E4F5A6D3ED7FD5F9D7BF5B70B20929BD9E0C4C },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_Enumerator_t18E4F5A6D3ED7FD5F9D7BF5B70B20929BD9E0C4C_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_HashSet_1_t56A90047C2E3B766AD3D00D3E42892B940DD592F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_HashSet_1_Contains_m739AF1BF8E6C86397838347F8EB6247C3D9C5EF2 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_HashSet_1_get_Count_mB826E2503CA807CC5DA7E946D7C37F23794DC871 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_HashSet_1_Remove_m245DB2CD2DFF443EA7F3911663EE65FFE362553C },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_tDEDDA3714EF75F3DDF77E03B087C4C3E5995144E },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Remove_m65E82A6B1535AC0C21AB4BE8C2C61788C4103018 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Add_m8907C3FE835A833CF3E337C9082756E76AFA0BA9 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_HashSet_1_Add_mED74CB9C9AAA0E239F31EFC6E9D0C4B1E68B9E31 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Contains_m1001B899792BD9A0641B7FBB49AD17F021BD2E8E },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Count_m9BBF0F08860C35E01E81359B1D4A56D6F8E5455C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_GetEnumerator_mE062419A4E1B97ED3231770EC5D5FCC61434DDB6 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_get_Current_m602892762095D49A2BB30DFC6E429AB286F6FE7A },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_RegistrationList_1_get_registeredSnapshot_mAFF2D09E3EA4EB7709635FADC7D383E6F367BF70 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_MoveNext_m73510958A69FD4502C71AB3724DC3478C1D109D2 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Enumerator_t6F64FD475A391D11C1B25E22757CA59287943A25 },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_Enumerator_t6F64FD475A391D11C1B25E22757CA59287943A25_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Clear_m8ACFEBBBBA6A936A12DAFD3D8C5870CC956C6F36 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_HashSet_1_Clear_m842CF8A613124A89847535991D24CA9C325131B4 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_RegistrationList_1_EnsureCapacity_m20D7CD0A6B15CC09D550A8BAB4F2A09A79D76261 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_RegistrationList_1_t8FB6DE4F05B868AE445CC388D9BA356783271D27 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_AddRange_mA964A7743E27461014F8986783C031823AF0CC72 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Capacity_mAE87E28F820A84BDC6D0D6457EA4A0FC2FCDC246 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_set_Capacity_mCDC1D68EB8C3638A5A7A82F561E34B968FBFEBC6 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1__ctor_m7E5EC5939EA95F8B3147B968A1CAB0DF96284E40 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_HashSet_1__ctor_m40C6E225E454BD7D2B40820133F2AC5A1D179FBC },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IList_1_t2CF9E3A700433CF0F80E98279B5661081D646A54 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IList_1_get_Item_mE7399099F98DE32A5AE350737F9B499F8887E05D },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IComparer_1_tC397730A8CBE0973DC34DDB4FA32FCD2E6B160CC },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IComparer_1_Compare_mBCDFEA210FD568216B6D32F42027F242E75143DD },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IList_1_set_Item_mAF1C686F3AFD21F93D2D2ACB4030FC69FDD19D0F },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ICollection_1_tB1C0B877F02467B9B9608BE2610A681CFC3EFDFE },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ICollection_1_get_Count_m0AFC7A7CE90A1705933EBC590A829CA2A1C67BC2 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ScriptableSettingsBase_1_t627139FDDE8A1FA81A1E75F5C68F9E3A9C15C016 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_tDDF8DE3E2FCFD7B1904152379258589FBB1F96EA },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ScriptableSettings_1_CreateAndLoad_m5F11882BAF69E3248455660CAD0D083545491089 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ScriptableSettings_1_t29CFA08564F3080DFEA2D4A49A5F3C02D6484639 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ScriptableSettingsBase_1_GetFilePath_m785065BD7A895A56CC4FF06319E67B201E0FE242 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ScriptableObject_CreateInstance_TisT_tDDF8DE3E2FCFD7B1904152379258589FBB1F96EA_m9B0AE2378E8B99845F0D735D4A8A36E3711E54AD },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ScriptableSettingsBase_1_Save_mD33A4593900808895C90240ED87C836228C54B52 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ScriptableSettingsBase_1__ctor_m111F4C4B90EA1632A33343E6F53D0D6F5E54792A },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_TAttribute_tD84F59BFC25FA20E979CDD1BCEBA60F91566972A },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TAttribute_tD84F59BFC25FA20E979CDD1BCEBA60F91566972A },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ScriptableSettingsBase_1_t0FD07083FE9901216761346ED884D2DC9E88E6B9 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_tD3F1682F46BD29F3F8A5804BCC3BF81F8123D89D },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_T_tD3F1682F46BD29F3F8A5804BCC3BF81F8123D89D },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Func_1_t0F1DF3BBB115D4FB73A2F07292F4A0672F0DBD9B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Func_1_Invoke_m1BFBC23051AB44B547913554450546CBF26F3C64 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_LinkedPool_1_get_countInactive_mC69DA81EDE397CF5FB2D998E88185CF62A5B458A },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_LinkedPool_1_set_countInactive_m53BA233B380E53BB6A98CD7348EB606CDC0F287F },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Action_1_t433C2CB55659D8A876C064C6DBA4955680E1F945 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Action_1_Invoke_m304172ABDEE833F5457CAF0D33D7E274C3EE4E0D },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_LinkedPool_1_Get_mE38823F44335EC8DFA2881A87C0BAE57C112ED81 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_PooledObject_1_t84CDA889C62417483A52F82EE1574CF9D173E9E3 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_PooledObject_1__ctor_mC13A8B50534AC85C136BCC3946FA1B561E65CD47 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_LinkedPoolItem_tA9FB38C29963A9C41EAE15A8A81F6C009D20C998 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_LinkedPoolItem__ctor_m29A8C608AE22E5A5B5A0495E117051FC74F69C8F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_LinkedPool_1_Clear_m58960BFEF9AFF06AFFFD59E3D24029AC5F5B4BF8 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_LinkedPool_1_t30CED966D97EFCFE47F2E8206B7E5C3A5D44BD66 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_LinkedPool_1_Release_mC17A4980935B556D5952D3343BFB6653AB22E1A1 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_InputBindingComposite_1__ctor_m033E97DE8F41C5CDA927522921DD3D114A949B1A },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_InputBindingComposite_1_tA4417858E3612F563D25C996250D32C7EB15970F },
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_Unity_XR_Interaction_Toolkit_CodeGenModule;
const Il2CppCodeGenModule g_Unity_XR_Interaction_Toolkit_CodeGenModule = 
{
	"Unity.XR.Interaction.Toolkit.dll",
	2161,
	s_methodPointers,
	218,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	9,
	s_rgctxIndices,
	72,
	s_rgctxValues,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
