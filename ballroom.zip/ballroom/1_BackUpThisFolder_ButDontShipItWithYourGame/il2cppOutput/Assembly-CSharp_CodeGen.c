﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void Main::Start()
extern void Main_Start_m5864CE07B60D35921FE23903087087FC5C3CF8FD (void);
// 0x00000002 System.Void Main::Update()
extern void Main_Update_m6A75833947272413C503ECE10B0D91F56F193526 (void);
// 0x00000003 System.Void Main::AddElements()
extern void Main_AddElements_m42BA141AEF7893B2B7B5CB848A845DCFACCEFABF (void);
// 0x00000004 System.Void Main::LimbControl()
extern void Main_LimbControl_m90BF02AE72762B6A040D8AD1740D007D736EA072 (void);
// 0x00000005 System.Void Main::.ctor()
extern void Main__ctor_mC5886B5D00EEF6A6D8F96F3A84762F8AD71E51B6 (void);
// 0x00000006 System.Void SkinnedVertices::Start()
extern void SkinnedVertices_Start_m1CE07837F5AAC8EAB54724313252E19F4AE2E876 (void);
// 0x00000007 System.Void SkinnedVertices::Update()
extern void SkinnedVertices_Update_m52C8A0C9DD994F574D9B829DBA4685EC907618F8 (void);
// 0x00000008 System.Void SkinnedVertices::.ctor()
extern void SkinnedVertices__ctor_m9E8D85F8C3320E681CEC6D648F4B2EB20AD3E983 (void);
// 0x00000009 System.Void SkinnedVertices/Bone::.ctor()
extern void Bone__ctor_mC7230F177D90E1D79A0526EA587401AB3DF057A8 (void);
// 0x0000000A System.Void TriggerDetact::OnTriggerEnter(UnityEngine.Collider)
extern void TriggerDetact_OnTriggerEnter_m718546D74B35193B0AE2BC2CA9FF1560D9A66A68 (void);
// 0x0000000B System.Void TriggerDetact::OnTriggerExit(UnityEngine.Collider)
extern void TriggerDetact_OnTriggerExit_m21A223FFB96F7F9AB32160D7BAE730D66934663C (void);
// 0x0000000C System.Void TriggerDetact::.ctor()
extern void TriggerDetact__ctor_m8EED2D4D1FACD28C5C21E1E65C0961D3F62E3588 (void);
// 0x0000000D System.Void WhiteLightFade::Start()
extern void WhiteLightFade_Start_m74CAF07861D7004EA033B09905764964EB0A346A (void);
// 0x0000000E System.Void WhiteLightFade::Update()
extern void WhiteLightFade_Update_m89DCA91AE10FC0E8EB23C9421D20A867EDEEEF7F (void);
// 0x0000000F System.Void WhiteLightFade::.ctor()
extern void WhiteLightFade__ctor_m8F1DE063A534F87C5A2C62D0CFD2A668A004E868 (void);
// 0x00000010 System.Collections.IEnumerator WhiteLightFade::<Update>g__whiteLightFade|3_0()
extern void WhiteLightFade_U3CUpdateU3Eg__whiteLightFadeU7C3_0_m4F576EC3A00D9AA4363081DF7CFCD9E6321AE380 (void);
// 0x00000011 System.Void WhiteLightFade/<<Update>g__whiteLightFade|3_0>d::.ctor(System.Int32)
extern void U3CU3CUpdateU3Eg__whiteLightFadeU7C3_0U3Ed__ctor_m88FA6F11F43F5F8C595DBE8F53D3D048055AD952 (void);
// 0x00000012 System.Void WhiteLightFade/<<Update>g__whiteLightFade|3_0>d::System.IDisposable.Dispose()
extern void U3CU3CUpdateU3Eg__whiteLightFadeU7C3_0U3Ed_System_IDisposable_Dispose_m4B3A47D6F207F15174720CF7DCCE6E99635AB3FB (void);
// 0x00000013 System.Boolean WhiteLightFade/<<Update>g__whiteLightFade|3_0>d::MoveNext()
extern void U3CU3CUpdateU3Eg__whiteLightFadeU7C3_0U3Ed_MoveNext_mC901187650F7062BA9933477E1323CB514B55841 (void);
// 0x00000014 System.Object WhiteLightFade/<<Update>g__whiteLightFade|3_0>d::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CU3CUpdateU3Eg__whiteLightFadeU7C3_0U3Ed_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mF59F56AAC2EA6EC54EE7C0A36C9E327E17EFCFBE (void);
// 0x00000015 System.Void WhiteLightFade/<<Update>g__whiteLightFade|3_0>d::System.Collections.IEnumerator.Reset()
extern void U3CU3CUpdateU3Eg__whiteLightFadeU7C3_0U3Ed_System_Collections_IEnumerator_Reset_m27DC578BD76F697A8BEBCCC12BF22F6AE3D73A53 (void);
// 0x00000016 System.Object WhiteLightFade/<<Update>g__whiteLightFade|3_0>d::System.Collections.IEnumerator.get_Current()
extern void U3CU3CUpdateU3Eg__whiteLightFadeU7C3_0U3Ed_System_Collections_IEnumerator_get_Current_mADD1157784B968149ECEABDA96A2CFB5E67AF17E (void);
// 0x00000017 System.Void PublicFunctions::Start()
extern void PublicFunctions_Start_mB350E3410BD56390DC2A74472BC0CF79E8F30700 (void);
// 0x00000018 System.Void PublicFunctions::OnGUI()
extern void PublicFunctions_OnGUI_m7F3D979DB9A395EF46944D16D90357B0D002DF82 (void);
// 0x00000019 System.Void PublicFunctions::Awake()
extern void PublicFunctions_Awake_m66150D06C73BA468D102EA252EC6CD6EF7C9B9B4 (void);
// 0x0000001A System.Void PublicFunctions::Update()
extern void PublicFunctions_Update_m30E939D95BA99A535A021F79665264B7C26C351B (void);
// 0x0000001B System.Void PublicFunctions::Move(System.String)
extern void PublicFunctions_Move_m7814810BE19019B119E74F8022842CA3C51B8663 (void);
// 0x0000001C System.Void PublicFunctions::Rotate()
extern void PublicFunctions_Rotate_m98D01D6FA42DCAB14EE8B8D17F5494526DC23D61 (void);
// 0x0000001D System.Void PublicFunctions::.ctor()
extern void PublicFunctions__ctor_mA2E5751F1C4DE908CD0E1F2004F6B8A1B6DD0DAA (void);
// 0x0000001E System.Void AssignTags::Awake()
extern void AssignTags_Awake_m6C94AC7D68D5CBAEAED99351A3173FD528F51655 (void);
// 0x0000001F System.Void AssignTags::.ctor()
extern void AssignTags__ctor_m68EC0A133A05DE6DF3A8E136E14A67BC5F5E33B6 (void);
// 0x00000020 System.Void FloatInLight::Start()
extern void FloatInLight_Start_m6336B341C977EAAF9790829FB083E14C44CCF38B (void);
// 0x00000021 System.Void FloatInLight::OnTriggerEnter(UnityEngine.Collider)
extern void FloatInLight_OnTriggerEnter_m1A13E7E9275ACBF9E291C151CC24278D596E3666 (void);
// 0x00000022 System.Void FloatInLight::OnTriggerExit(UnityEngine.Collider)
extern void FloatInLight_OnTriggerExit_m09E66452882B4FDB5A0306065FDA973B4217127B (void);
// 0x00000023 System.Void FloatInLight::Update()
extern void FloatInLight_Update_m043CA448CF3451C7BCDB2783F023B0C49AA0D367 (void);
// 0x00000024 System.Void FloatInLight::.ctor()
extern void FloatInLight__ctor_m0CCEA1083D28BF1D748FA782B2250D6D6890FFB8 (void);
// 0x00000025 System.Void NextScene::Start()
extern void NextScene_Start_mB01999C2F0A2F57812B0E73977515956E53FF369 (void);
// 0x00000026 System.Void NextScene::Update()
extern void NextScene_Update_m5AA5CFFDC6687DDAE51529DE556DDFBE0B431ADD (void);
// 0x00000027 System.Void NextScene::OnTriggerEnter(UnityEngine.Collider)
extern void NextScene_OnTriggerEnter_m6AE74F45B42F590AA89522C6EAAF926C4221AAC6 (void);
// 0x00000028 System.Collections.IEnumerator NextScene::ExampleCoroutine()
extern void NextScene_ExampleCoroutine_m4221D0E3B624942DD8619FACDA728F7C31E2E2D4 (void);
// 0x00000029 System.Void NextScene::.ctor()
extern void NextScene__ctor_mF930690F11186753D518C23AF63B16D8CBA87419 (void);
// 0x0000002A System.Void NextScene/<ExampleCoroutine>d__6::.ctor(System.Int32)
extern void U3CExampleCoroutineU3Ed__6__ctor_m946082FFA11063E80F506BB429D62B64FFE95CB4 (void);
// 0x0000002B System.Void NextScene/<ExampleCoroutine>d__6::System.IDisposable.Dispose()
extern void U3CExampleCoroutineU3Ed__6_System_IDisposable_Dispose_mA6AC9A9366F0694380E575660F1E2862C4DA38B0 (void);
// 0x0000002C System.Boolean NextScene/<ExampleCoroutine>d__6::MoveNext()
extern void U3CExampleCoroutineU3Ed__6_MoveNext_m21E3FDCBB05B58D2E264066E2780002E2896FB6A (void);
// 0x0000002D System.Object NextScene/<ExampleCoroutine>d__6::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CExampleCoroutineU3Ed__6_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m9304D08B9F7875B3FC528FC72B74F4D88D298143 (void);
// 0x0000002E System.Void NextScene/<ExampleCoroutine>d__6::System.Collections.IEnumerator.Reset()
extern void U3CExampleCoroutineU3Ed__6_System_Collections_IEnumerator_Reset_mC41A9F7A9609031CAACCC1DC047E9A3D15AADCE9 (void);
// 0x0000002F System.Object NextScene/<ExampleCoroutine>d__6::System.Collections.IEnumerator.get_Current()
extern void U3CExampleCoroutineU3Ed__6_System_Collections_IEnumerator_get_Current_m10F949A91AC9A5A8077356D4D6EAB86EE8EB2A85 (void);
// 0x00000030 System.Void Struggle::Start()
extern void Struggle_Start_m7E74D15AED68AFDD9D9916B0A93FF0539FD75287 (void);
// 0x00000031 System.Void Struggle::HandRotate(System.String,System.Single,System.Single)
extern void Struggle_HandRotate_m2A54A16CB7B1453B6E2794300579FB9ADCE0B650 (void);
// 0x00000032 System.Void Struggle::Update()
extern void Struggle_Update_mCE924AF389C962FB03829C1159EB076D2A1257F5 (void);
// 0x00000033 System.Collections.IEnumerator Struggle::ExampleCoroutine()
extern void Struggle_ExampleCoroutine_m4EDB06BE15E1A738217E6A504E1B8F80B7DCF6BC (void);
// 0x00000034 System.Void Struggle::.ctor()
extern void Struggle__ctor_m8FD9B3F79B1216F08A3CB02F414477D1B72A3C04 (void);
// 0x00000035 System.Void Struggle/<ExampleCoroutine>d__24::.ctor(System.Int32)
extern void U3CExampleCoroutineU3Ed__24__ctor_mAFF1F71F7A9204EDA18C0337DBD8EBF395B60F82 (void);
// 0x00000036 System.Void Struggle/<ExampleCoroutine>d__24::System.IDisposable.Dispose()
extern void U3CExampleCoroutineU3Ed__24_System_IDisposable_Dispose_mDFE7B66923BDABD3165021C9AA05F4FED056AFC6 (void);
// 0x00000037 System.Boolean Struggle/<ExampleCoroutine>d__24::MoveNext()
extern void U3CExampleCoroutineU3Ed__24_MoveNext_m1D91D76D8A82B873B944867CED48C30B29390CC6 (void);
// 0x00000038 System.Object Struggle/<ExampleCoroutine>d__24::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CExampleCoroutineU3Ed__24_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mE5EBC82C7E7E34650FEC1C7EE6676251087781DC (void);
// 0x00000039 System.Void Struggle/<ExampleCoroutine>d__24::System.Collections.IEnumerator.Reset()
extern void U3CExampleCoroutineU3Ed__24_System_Collections_IEnumerator_Reset_mD7E955457C6F08CB20F49EF1DCF5A42F4E7BD77E (void);
// 0x0000003A System.Object Struggle/<ExampleCoroutine>d__24::System.Collections.IEnumerator.get_Current()
extern void U3CExampleCoroutineU3Ed__24_System_Collections_IEnumerator_get_Current_m922E9AFF22B4EFD7A371E172E754584FC8E86258 (void);
// 0x0000003B System.Single UduinoReceive::Remap(System.Single,System.Single,System.Single,System.Single,System.Single)
extern void UduinoReceive_Remap_mC94340BD7AD53A3DCDDBB6A569D5D8A72CDCB552 (void);
// 0x0000003C System.Void UduinoReceive::BoardConnected(Uduino.UduinoDevice)
extern void UduinoReceive_BoardConnected_m9CC40CB9047DD35250CBC4EC9F67BA4A82928598 (void);
// 0x0000003D System.Void UduinoReceive::Update()
extern void UduinoReceive_Update_mEE82144B03A40E39C8B44239582F183619B61CB4 (void);
// 0x0000003E System.Void UduinoReceive::.ctor()
extern void UduinoReceive__ctor_mC526A624142E0E2912DF09FCCDB8FF632B2DC8D1 (void);
// 0x0000003F System.Void Bloom::OnRenderImage(UnityEngine.RenderTexture,UnityEngine.RenderTexture)
extern void Bloom_OnRenderImage_mD7750BD37D887456642266EEBF718FC78F1717C4 (void);
// 0x00000040 System.Void Bloom::.ctor()
extern void Bloom__ctor_mF53865061B69135EEA4B6B02F203BE158C80EDE8 (void);
// 0x00000041 System.Void MegaReadWrite::Start()
extern void MegaReadWrite_Start_m8177F907BDEE8F5AD402230AB9E2EA507A1EC23B (void);
// 0x00000042 System.Void MegaReadWrite::BoardConnected(Uduino.UduinoDevice)
extern void MegaReadWrite_BoardConnected_m54FFFB69592AF251B0F007625A7D2012DF7BFDFD (void);
// 0x00000043 System.Void MegaReadWrite::Update()
extern void MegaReadWrite_Update_m4905BF57B90534A0B0DD952365A519FD50F5F4E2 (void);
// 0x00000044 System.Void MegaReadWrite::.ctor()
extern void MegaReadWrite__ctor_m7A7122BD15C7874A6ACB22682F4B5E375FBDE335 (void);
// 0x00000045 System.Void ChangeBoardType::Start()
extern void ChangeBoardType_Start_m09457C92FBD90F93ED092744F1D93D884362F755 (void);
// 0x00000046 System.Void ChangeBoardType::OnBoardConnected(Uduino.UduinoDevice)
extern void ChangeBoardType_OnBoardConnected_m3A718616D097EDC77F9ADD7B78557F39D2FEB52F (void);
// 0x00000047 System.Void ChangeBoardType::.ctor()
extern void ChangeBoardType__ctor_m5E1FAC081B023A21FDC63C7249EBB48BB46BF068 (void);
// 0x00000048 System.Void Bundle::Start()
extern void Bundle_Start_m22FC21872C389D03B203811CF034816D9279F7D8 (void);
// 0x00000049 System.Collections.IEnumerator Bundle::BlinkAllLoop()
extern void Bundle_BlinkAllLoop_m2D93ED7019C6207951F04BABB3D114CB2B3DBB90 (void);
// 0x0000004A System.Void Bundle::.ctor()
extern void Bundle__ctor_mF564BD780BCFA392DD8FC378BBF537A5A61FB284 (void);
// 0x0000004B System.Void Bundle/<BlinkAllLoop>d__2::.ctor(System.Int32)
extern void U3CBlinkAllLoopU3Ed__2__ctor_m2917DFE00A8C4354C1A9ADAD03EF12FC77C7C3F3 (void);
// 0x0000004C System.Void Bundle/<BlinkAllLoop>d__2::System.IDisposable.Dispose()
extern void U3CBlinkAllLoopU3Ed__2_System_IDisposable_Dispose_m5B6E109605222519B88B0CE0ED4D3C3F5698443B (void);
// 0x0000004D System.Boolean Bundle/<BlinkAllLoop>d__2::MoveNext()
extern void U3CBlinkAllLoopU3Ed__2_MoveNext_m493FAD55966A1846550A04AB0C6C521FED607A7C (void);
// 0x0000004E System.Object Bundle/<BlinkAllLoop>d__2::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CBlinkAllLoopU3Ed__2_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m1751E9D754C80712577AB1338C42E84ED1A7E404 (void);
// 0x0000004F System.Void Bundle/<BlinkAllLoop>d__2::System.Collections.IEnumerator.Reset()
extern void U3CBlinkAllLoopU3Ed__2_System_Collections_IEnumerator_Reset_m5F7E54B33C855DF7B81A7CBC0611D0569DEAB7BD (void);
// 0x00000050 System.Object Bundle/<BlinkAllLoop>d__2::System.Collections.IEnumerator.get_Current()
extern void U3CBlinkAllLoopU3Ed__2_System_Collections_IEnumerator_get_Current_mDA82DCA481A85D6F7D7D5508D83F4279A64733F3 (void);
// 0x00000051 System.Void ButtonTrigger::Awake()
extern void ButtonTrigger_Awake_m67A4F77EE2A5B3838DE44F1CB82E295BB48417AE (void);
// 0x00000052 System.Void ButtonTrigger::OnDataReceived(System.String,Uduino.UduinoDevice)
extern void ButtonTrigger_OnDataReceived_mF2A25EB881D6621E732D00F044BCFDB40CB8584F (void);
// 0x00000053 System.Void ButtonTrigger::PressedDown()
extern void ButtonTrigger_PressedDown_m551EFF727605FA836596B779210B7020D089E28F (void);
// 0x00000054 System.Void ButtonTrigger::PressedUp()
extern void ButtonTrigger_PressedUp_mCEC3A4BDB2877DC07568DA4E475FD2C27853470B (void);
// 0x00000055 System.Void ButtonTrigger::.ctor()
extern void ButtonTrigger__ctor_m7127FE8CACB7773026CCFC0F73460626EE31DBAC (void);
// 0x00000056 System.Void EncoderLibrary::Start()
extern void EncoderLibrary_Start_m9F62CA3310FF1ECF6BA5DC9E435C2F8253523F82 (void);
// 0x00000057 System.Void EncoderLibrary::ReadEncoder(System.String)
extern void EncoderLibrary_ReadEncoder_m5ABF62BD32ADD9214B28ED723F0FF5A80F1CF872 (void);
// 0x00000058 System.Void EncoderLibrary::.ctor()
extern void EncoderLibrary__ctor_m2BBB30BCE767A83D891046759A2A3ED2D5FFC822 (void);
// 0x00000059 System.Void SendLedIntensity::Update()
extern void SendLedIntensity_Update_mA9070E07D418B95F86ADFD0330835585786A7ED0 (void);
// 0x0000005A System.Void SendLedIntensity::.ctor()
extern void SendLedIntensity__ctor_m955D52594943F3651904DF337B6EAF7D8608FAE3 (void);
// 0x0000005B System.Void MultipleArduino::Start()
extern void MultipleArduino_Start_mF47E3A5C6E779105FF1EBD18E3E50C761D4C18E6 (void);
// 0x0000005C System.Void MultipleArduino::Update()
extern void MultipleArduino_Update_mF23E3A126D45C488DE55380511E27DDC280A18E4 (void);
// 0x0000005D System.Void MultipleArduino::OnDataReceived(System.String,Uduino.UduinoDevice)
extern void MultipleArduino_OnDataReceived_m0F24DC673EBC5F734909D99A5822601E61A8EC17 (void);
// 0x0000005E System.Void MultipleArduino::.ctor()
extern void MultipleArduino__ctor_m8F5D7BCF68D77215A346FA10315B4EB7C434895F (void);
// 0x0000005F System.Void MultipleArduino2::Start()
extern void MultipleArduino2_Start_m2867BDA5CFF099443C5E95424ACA48AB95EFD27F (void);
// 0x00000060 System.Void MultipleArduino2::Update()
extern void MultipleArduino2_Update_m58088783A85AF6D9CAFE08766101816342098F52 (void);
// 0x00000061 System.Void MultipleArduino2::OnDataReceived(System.String,Uduino.UduinoDevice)
extern void MultipleArduino2_OnDataReceived_mEE4C6DB04FF8478397E5A3B63E2F41F97CA8305B (void);
// 0x00000062 System.Void MultipleArduino2::OnBoardConnected(Uduino.UduinoDevice)
extern void MultipleArduino2_OnBoardConnected_mBB100749CA04E1D7240E9B514B3450BABF5C2E4E (void);
// 0x00000063 System.Void MultipleArduino2::.ctor()
extern void MultipleArduino2__ctor_m25C8D7E034086770E67CF7FF0C2BB271E9651A26 (void);
// 0x00000064 System.Void UduinoShortCall::Update()
extern void UduinoShortCall_Update_mF09247A21AFBDA2AAEAA5AA29263BBB363157D0E (void);
// 0x00000065 System.Void UduinoShortCall::.ctor()
extern void UduinoShortCall__ctor_m6FBBEB86B323114106F87F069E5C140C6011593E (void);
// 0x00000066 System.Void UduinoShortCall::<Update>b__2_0(System.String)
extern void UduinoShortCall_U3CUpdateU3Eb__2_0_m07B6F9B95AF362E7A0F7BE8838B04BFEC694CDB3 (void);
// 0x00000067 System.Void ReadSensor::Awake()
extern void ReadSensor_Awake_m5F4D2476D14A398FC97846E2B0CBA2BC29F1F788 (void);
// 0x00000068 System.Void ReadSensor::Update()
extern void ReadSensor_Update_m61D01F5C000A1769B1623CAC760FB513BB836EAF (void);
// 0x00000069 System.Void ReadSensor::OnDataReceived(System.String,Uduino.UduinoDevice)
extern void ReadSensor_OnDataReceived_m9F95E777EEC202CED139C206133A21BB58A2AA47 (void);
// 0x0000006A System.Void ReadSensor::Read()
extern void ReadSensor_Read_m38243660133DB5CB275F2AFD911F623B0CF9B3A0 (void);
// 0x0000006B System.Void ReadSensor::.ctor()
extern void ReadSensor__ctor_m791FD0A507821750DAC4AD013FDB788522AAC7B7 (void);
// 0x0000006C System.Void SendCommandToArduino::Start()
extern void SendCommandToArduino_Start_m53F8817507355C5538FA6682796422129DB7BB73 (void);
// 0x0000006D System.Collections.IEnumerator SendCommandToArduino::Loop()
extern void SendCommandToArduino_Loop_m7AD9CBE6E84CD6D310049D37CC70172813612503 (void);
// 0x0000006E System.Void SendCommandToArduino::ReceviedData(System.String,Uduino.UduinoDevice)
extern void SendCommandToArduino_ReceviedData_m8AF500E90B1D18074EECE57DF1C99FA00A5F4AAB (void);
// 0x0000006F System.Void SendCommandToArduino::.ctor()
extern void SendCommandToArduino__ctor_m4985E93866820D03F38DFB47A32FFB0BD7DC65A8 (void);
// 0x00000070 System.Void SendCommandToArduino/<Loop>d__4::.ctor(System.Int32)
extern void U3CLoopU3Ed__4__ctor_mDA3792A6931C0934A8355194C07DD83AD52D68CE (void);
// 0x00000071 System.Void SendCommandToArduino/<Loop>d__4::System.IDisposable.Dispose()
extern void U3CLoopU3Ed__4_System_IDisposable_Dispose_mA093968C97CFDE13B105B7193D0E9FFE9814A20D (void);
// 0x00000072 System.Boolean SendCommandToArduino/<Loop>d__4::MoveNext()
extern void U3CLoopU3Ed__4_MoveNext_m7D491723D41A4AC63A78E6AFABFE57478A437E77 (void);
// 0x00000073 System.Object SendCommandToArduino/<Loop>d__4::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CLoopU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m0FCDBD649E689C9FAA1AF45B1A35555AA157E93F (void);
// 0x00000074 System.Void SendCommandToArduino/<Loop>d__4::System.Collections.IEnumerator.Reset()
extern void U3CLoopU3Ed__4_System_Collections_IEnumerator_Reset_m73B87E33B828A6B375D6EC920A0C0FD0588351C5 (void);
// 0x00000075 System.Object SendCommandToArduino/<Loop>d__4::System.Collections.IEnumerator.get_Current()
extern void U3CLoopU3Ed__4_System_Collections_IEnumerator_get_Current_m652D0B88F188D1A75E8488FA5A769B6FBCAA6B5C (void);
// 0x00000076 System.Void ServoOptimized::Update()
extern void ServoOptimized_Update_mD47E963E27CECC87489F1E1E3D1019F646E1B977 (void);
// 0x00000077 System.Void ServoOptimized::OptimizedWrite()
extern void ServoOptimized_OptimizedWrite_m7521D1AD473AB61D7DFE71CBEB2A40044798CA73 (void);
// 0x00000078 System.Void ServoOptimized::.ctor()
extern void ServoOptimized__ctor_m72CAA11A28CFDBD454CFDC36B526EC7F074270DE (void);
// 0x00000079 System.Void AnalogRead::Start()
extern void AnalogRead_Start_m982369B49D648B413AB8EF650926CE8CFA025E1F (void);
// 0x0000007A System.Void AnalogRead::Update()
extern void AnalogRead_Update_m0DAD6029E2E3CEB6F8A73ED7CB8856C3D1041919 (void);
// 0x0000007B System.Void AnalogRead::ReadLights()
extern void AnalogRead_ReadLights_mA2289F7B2280E78FF3643691242C13E1A75B512C (void);
// 0x0000007C System.Void AnalogRead::.ctor()
extern void AnalogRead__ctor_mEEEE0451A140028289C3BB85AEAA38197133CD15 (void);
// 0x0000007D System.Void AnalogWrite::Start()
extern void AnalogWrite_Start_m978E6337B9EDB5BE5B34A09816E4780AFED57E24 (void);
// 0x0000007E System.Void AnalogWrite::Update()
extern void AnalogWrite_Update_m5BEBF73FD9288BCC7FF419BEDAD04E08995AD672 (void);
// 0x0000007F System.Void AnalogWrite::.ctor()
extern void AnalogWrite__ctor_m26955E638F6EA76FF925745E4EF3BA788C3AEF57 (void);
// 0x00000080 System.Void BlinkLed::Start()
extern void BlinkLed_Start_mA2D7BF07E4F88CC2D57126C2EFB8907106429D5D (void);
// 0x00000081 System.Collections.IEnumerator BlinkLed::BlinkLoop()
extern void BlinkLed_BlinkLoop_mA9654A0699D2B299B1D435C9F58DB88FC1D16563 (void);
// 0x00000082 System.Void BlinkLed::.ctor()
extern void BlinkLed__ctor_mE6E4E36704E419F668A4E40E976F4642319944E7 (void);
// 0x00000083 System.Void BlinkLed/<BlinkLoop>d__4::.ctor(System.Int32)
extern void U3CBlinkLoopU3Ed__4__ctor_m4CB846997137A0430E443C9F3D1683FDA4FCC68A (void);
// 0x00000084 System.Void BlinkLed/<BlinkLoop>d__4::System.IDisposable.Dispose()
extern void U3CBlinkLoopU3Ed__4_System_IDisposable_Dispose_m6AD96AF945FA97988DADAE9E7D2138E1BA1FA73A (void);
// 0x00000085 System.Boolean BlinkLed/<BlinkLoop>d__4::MoveNext()
extern void U3CBlinkLoopU3Ed__4_MoveNext_mE8EC5B0F86ACCB7A452E205B8A215FB018202637 (void);
// 0x00000086 System.Object BlinkLed/<BlinkLoop>d__4::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CBlinkLoopU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mB8CA5DF93DB23FBA602B9A1C5FF4DA754D28DDEA (void);
// 0x00000087 System.Void BlinkLed/<BlinkLoop>d__4::System.Collections.IEnumerator.Reset()
extern void U3CBlinkLoopU3Ed__4_System_Collections_IEnumerator_Reset_m38C04F4D44107F9D40418EAED0915C787E1AE8BE (void);
// 0x00000088 System.Object BlinkLed/<BlinkLoop>d__4::System.Collections.IEnumerator.get_Current()
extern void U3CBlinkLoopU3Ed__4_System_Collections_IEnumerator_get_Current_m83702C9F88CB0AD62EA4D0A26C8989C5FC309F69 (void);
// 0x00000089 System.Void DigitalReadButton::Start()
extern void DigitalReadButton_Start_mFF75CB388DF833C0A4813E6669A2B788331D3977 (void);
// 0x0000008A System.Void DigitalReadButton::Update()
extern void DigitalReadButton_Update_m2316F48A30F174F102DBEAF565A2FB6F96AF1379 (void);
// 0x0000008B System.Void DigitalReadButton::PressedDown()
extern void DigitalReadButton_PressedDown_mDE5B59A4B51C70FC01EF79F7EDAE2F2C9A184778 (void);
// 0x0000008C System.Void DigitalReadButton::PressedUp()
extern void DigitalReadButton_PressedUp_mF2681AE9F4081B760FF37F1FEA9E9EA33FCA006D (void);
// 0x0000008D System.Void DigitalReadButton::.ctor()
extern void DigitalReadButton__ctor_mA628462D26011A1A707D92DCF991A98921E7B6D2 (void);
// 0x0000008E System.Void MultipleButtons::Start()
extern void MultipleButtons_Start_m81FD3E957DC1D80E5FEEC9E91458031CACA7898D (void);
// 0x0000008F System.Void MultipleButtons::DataReceived(System.String,Uduino.UduinoDevice)
extern void MultipleButtons_DataReceived_m71F51D61E1EEDEFFEA5B50A1E702F84DC444A089 (void);
// 0x00000090 System.Void MultipleButtons::Update()
extern void MultipleButtons_Update_m1C560497D6FF8C5C0FF564C0F71EEB8CAEE56C4D (void);
// 0x00000091 System.Void MultipleButtons::PressedDown(MultipleButtons/UduinoButton)
extern void MultipleButtons_PressedDown_m0F932116B734732762A236EA9D07D402B5E1DE05 (void);
// 0x00000092 System.Void MultipleButtons::PressedUp(MultipleButtons/UduinoButton)
extern void MultipleButtons_PressedUp_mD5D1B4F47612E05295ED1719C6FE06534030E9F2 (void);
// 0x00000093 System.Void MultipleButtons::.ctor()
extern void MultipleButtons__ctor_m465BB193B242D6DB0640165D545D994260F12AD1 (void);
// 0x00000094 System.Void MultipleButtons/UduinoButton::.ctor(System.Int32,UnityEngine.GameObject)
extern void UduinoButton__ctor_m3E5E326F5FA06EDE9C45D19A1458A63AA4C1AA83 (void);
// 0x00000095 System.Int32 MultipleButtons/UduinoButton::Read()
extern void UduinoButton_Read_mA228653E6D058C9FB735355B22EA051DF86C443E (void);
// 0x00000096 System.Boolean MultipleButtons/UduinoButton::pressedDown()
extern void UduinoButton_pressedDown_m798A1A143455C8D3E1EB87F0C05EE76C1C845485 (void);
// 0x00000097 System.Boolean MultipleButtons/UduinoButton::pressedUp()
extern void UduinoButton_pressedUp_m85E9B32A18F84D775F13BA87552BE844B3E0EAA4 (void);
// 0x00000098 System.Boolean MultipleButtons/UduinoButton::valueChanged()
extern void UduinoButton_valueChanged_m1C787B3C51D687743FD9B484DF294DFE577306A7 (void);
// 0x00000099 System.Void UduinoEventsReceiver::DataReceived(System.String,Uduino.UduinoDevice)
extern void UduinoEventsReceiver_DataReceived_mBF8553B109981192C3A5B0E536E08247EE40A42A (void);
// 0x0000009A System.Void UduinoEventsReceiver::BoardConnected(Uduino.UduinoDevice)
extern void UduinoEventsReceiver_BoardConnected_m01584F8BC0151A3021EC01C8BA6AA79697217B00 (void);
// 0x0000009B System.Void UduinoEventsReceiver::BoardDisconnected(Uduino.UduinoDevice)
extern void UduinoEventsReceiver_BoardDisconnected_mF1C5224E78D63BB08E2735FD721225AEF0E26A75 (void);
// 0x0000009C System.Void UduinoEventsReceiver::.ctor()
extern void UduinoEventsReceiver__ctor_mBADE0C0FE7558A6AAA0E192E5DBF01AED482FAD8 (void);
// 0x0000009D System.Void FadeInOut::Start()
extern void FadeInOut_Start_m981511CF39B92FD67F55EFDEA7EBBF3A063055F6 (void);
// 0x0000009E System.Collections.IEnumerator FadeInOut::FadeLoop()
extern void FadeInOut_FadeLoop_m800A303348A561B3133CBDEDEBFE46C57D4CC7C9 (void);
// 0x0000009F System.Void FadeInOut::.ctor()
extern void FadeInOut__ctor_m1C4183C53A57A5FFBC0293ED557387702E89DDC8 (void);
// 0x000000A0 System.Void FadeInOut/<FadeLoop>d__5::.ctor(System.Int32)
extern void U3CFadeLoopU3Ed__5__ctor_m69FE480DB22F3C73F8F42FD013890B8CF776FC40 (void);
// 0x000000A1 System.Void FadeInOut/<FadeLoop>d__5::System.IDisposable.Dispose()
extern void U3CFadeLoopU3Ed__5_System_IDisposable_Dispose_m7D9AE71F63905C46A761C35BBE6EE21BA69389AB (void);
// 0x000000A2 System.Boolean FadeInOut/<FadeLoop>d__5::MoveNext()
extern void U3CFadeLoopU3Ed__5_MoveNext_m4B9C21FD97D8105A5F5F8DAC47102204FD8739ED (void);
// 0x000000A3 System.Object FadeInOut/<FadeLoop>d__5::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CFadeLoopU3Ed__5_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m9EA4EB1254484BF5FDF5AC465CC73E268B53A1E2 (void);
// 0x000000A4 System.Void FadeInOut/<FadeLoop>d__5::System.Collections.IEnumerator.Reset()
extern void U3CFadeLoopU3Ed__5_System_Collections_IEnumerator_Reset_m9F4EDCD3B9A6C4896DF95B5BBF63C2C86F98D613 (void);
// 0x000000A5 System.Object FadeInOut/<FadeLoop>d__5::System.Collections.IEnumerator.get_Current()
extern void U3CFadeLoopU3Ed__5_System_Collections_IEnumerator_get_Current_mA4B8E4471D736E8C41EB0F4C41E9369E8F16F461 (void);
// 0x000000A6 System.Void ReadWrite::Start()
extern void ReadWrite_Start_mA7B07224F06779E7E4653E43504C0D1328E97421 (void);
// 0x000000A7 System.Void ReadWrite::Update()
extern void ReadWrite_Update_mBA77E3F266E0B02243341749F9A1CCF922E133BC (void);
// 0x000000A8 System.Void ReadWrite::ReadValue()
extern void ReadWrite_ReadValue_mB5A05294D3697BA76D0C84C2FD1872145EED09F9 (void);
// 0x000000A9 System.Void ReadWrite::.ctor()
extern void ReadWrite__ctor_m31B8331B3023735DCEDD2398C8DB937EC13540DD (void);
// 0x000000AA System.Void Servo::Start()
extern void Servo_Start_m53D8C8C4544A4DE76C6DDBC84B5613C2A2E14CFB (void);
// 0x000000AB System.Void Servo::Update()
extern void Servo_Update_m20F2788BEBF73CE5921162FAE5D674DC8E3E948D (void);
// 0x000000AC System.Void Servo::.ctor()
extern void Servo__ctor_m592678397C799FDE4E3E48C603D52FE08960E22D (void);
// 0x000000AD System.Void SimpleUduino::Start()
extern void SimpleUduino_Start_m87FBD0F7708DF84F474A2E1EB6B7D54D8429F693 (void);
// 0x000000AE System.Void SimpleUduino::Update()
extern void SimpleUduino_Update_m3C56FAE2514CC043505979B9B4FEBD0C41DC5C5F (void);
// 0x000000AF System.Void SimpleUduino::.ctor()
extern void SimpleUduino__ctor_mA56B67FD44B3B4FF4446F624C2317E7CDC2EA73B (void);
// 0x000000B0 System.Void SimpleUduino::<Update>b__6_0(System.String)
extern void SimpleUduino_U3CUpdateU3Eb__6_0_mAB7D52E60A06819FE5C2DF69E65D3EF26FABB61B (void);
// 0x000000B1 System.Void UduinoWifi_ReadWrite::Update()
extern void UduinoWifi_ReadWrite_Update_mF3E2C02BE0F16E8059267DD19811C0D75ECA338B (void);
// 0x000000B2 System.Void UduinoWifi_ReadWrite::Received(System.String,Uduino.UduinoDevice)
extern void UduinoWifi_ReadWrite_Received_mEA80466434DCFF0D741826C84C2D9A9B5EA9BBB7 (void);
// 0x000000B3 System.Void UduinoWifi_ReadWrite::.ctor()
extern void UduinoWifi_ReadWrite__ctor_mBEAA606C20C21A21CCEB22D7700C63D867E82198 (void);
// 0x000000B4 System.Void MultipleWifiBoards::Update()
extern void MultipleWifiBoards_Update_m534E148D657C9DBE04A6920ED30D4C631D381144 (void);
// 0x000000B5 System.Void MultipleWifiBoards::Received(System.String,Uduino.UduinoDevice)
extern void MultipleWifiBoards_Received_m05ABC2956BFA47116DF0E79A4056DD826790CA8E (void);
// 0x000000B6 System.Void MultipleWifiBoards::.ctor()
extern void MultipleWifiBoards__ctor_mF47D96DB41B9BD843039B1FEFD7DC4D403356DE4 (void);
// 0x000000B7 System.Void UduinoWifiInterfaceStart::ConnectWifi()
extern void UduinoWifiInterfaceStart_ConnectWifi_m1D4621BE5376752463E8171D8E74D8614F226205 (void);
// 0x000000B8 System.Void UduinoWifiInterfaceStart::LoadWifi()
extern void UduinoWifiInterfaceStart_LoadWifi_mD2063B36C3698661DC94CB9C4C669F7B176838F2 (void);
// 0x000000B9 System.Void UduinoWifiInterfaceStart::SaveWifi()
extern void UduinoWifiInterfaceStart_SaveWifi_mF769EE410AA1BACC6421134E2124CD03DE2BBC99 (void);
// 0x000000BA System.Void UduinoWifiInterfaceStart::.ctor()
extern void UduinoWifiInterfaceStart__ctor_mE546CE72E42B6D120517975CED662CBCE53B696E (void);
// 0x000000BB SimpleJSON.JSONNodeType SimpleJSON.JSONNode::get_Tag()
// 0x000000BC SimpleJSON.JSONNode SimpleJSON.JSONNode::get_Item(System.Int32)
extern void JSONNode_get_Item_m77F15891BEC7ED659BFBC392555178B558747AD8 (void);
// 0x000000BD System.Void SimpleJSON.JSONNode::set_Item(System.Int32,SimpleJSON.JSONNode)
extern void JSONNode_set_Item_mC6F47073D979B943286B2EAB1A6D0380AFE58A09 (void);
// 0x000000BE SimpleJSON.JSONNode SimpleJSON.JSONNode::get_Item(System.String)
extern void JSONNode_get_Item_m466B08DF2E30B20606697EC7AE043C2791DC6768 (void);
// 0x000000BF System.Void SimpleJSON.JSONNode::set_Item(System.String,SimpleJSON.JSONNode)
extern void JSONNode_set_Item_m045530804B67FC5E2E57E497219F27ED70CE437E (void);
// 0x000000C0 System.String SimpleJSON.JSONNode::get_Value()
extern void JSONNode_get_Value_m2A9961ACC3D4BCBB028012CD79B619DCBD82A839 (void);
// 0x000000C1 System.Void SimpleJSON.JSONNode::set_Value(System.String)
extern void JSONNode_set_Value_mE8CD0E68E0E2B0A716F56B0FE9B988EC2BAD773A (void);
// 0x000000C2 System.Int32 SimpleJSON.JSONNode::get_Count()
extern void JSONNode_get_Count_m260DDA50B8AFB98F5946E54B9EADD05891A82C8B (void);
// 0x000000C3 System.Boolean SimpleJSON.JSONNode::get_IsNumber()
extern void JSONNode_get_IsNumber_m6B495FE576572E9FC7999740C63980BCB65AD768 (void);
// 0x000000C4 System.Boolean SimpleJSON.JSONNode::get_IsString()
extern void JSONNode_get_IsString_mBDE2CAF25E51CDA450074BE9DC81D834903BA392 (void);
// 0x000000C5 System.Boolean SimpleJSON.JSONNode::get_IsBoolean()
extern void JSONNode_get_IsBoolean_m13F16853C0F6D76D0AB6B7E866923A0632C108A2 (void);
// 0x000000C6 System.Boolean SimpleJSON.JSONNode::get_IsNull()
extern void JSONNode_get_IsNull_m6443A7B3540D725ED3ACA0038A74CE0346A31F8D (void);
// 0x000000C7 System.Boolean SimpleJSON.JSONNode::get_IsArray()
extern void JSONNode_get_IsArray_m52DCDB47E4CB2673FDCECCD3BE9DD2D90B5C948F (void);
// 0x000000C8 System.Boolean SimpleJSON.JSONNode::get_IsObject()
extern void JSONNode_get_IsObject_m237FE2EA3382DD9762ED426B49F46183F5EF39AB (void);
// 0x000000C9 System.Boolean SimpleJSON.JSONNode::get_Inline()
extern void JSONNode_get_Inline_m7A5B6C07F44EFEEDD80FD72580C32C0579041F4C (void);
// 0x000000CA System.Void SimpleJSON.JSONNode::set_Inline(System.Boolean)
extern void JSONNode_set_Inline_m18362F10F03DDCD1FF29B4868C3EA793D39AE7F6 (void);
// 0x000000CB System.Void SimpleJSON.JSONNode::Add(System.String,SimpleJSON.JSONNode)
extern void JSONNode_Add_mB05F1A32B54A9A1223F9AC6A6A737836FA1F4E7E (void);
// 0x000000CC System.Void SimpleJSON.JSONNode::Add(SimpleJSON.JSONNode)
extern void JSONNode_Add_mDAF96580EAF3B9FF23888A8549BED7A98439075D (void);
// 0x000000CD SimpleJSON.JSONNode SimpleJSON.JSONNode::Remove(System.String)
extern void JSONNode_Remove_mF56C4223700DF4F1D5AE12BCD69C492C2487FA59 (void);
// 0x000000CE SimpleJSON.JSONNode SimpleJSON.JSONNode::Remove(System.Int32)
extern void JSONNode_Remove_m7B5E0BC0A29C35857D7B10857A8C52C0E3DFB615 (void);
// 0x000000CF SimpleJSON.JSONNode SimpleJSON.JSONNode::Remove(SimpleJSON.JSONNode)
extern void JSONNode_Remove_mE2CFD05512C25BD11EA4160CAAF88B8154D9DBE5 (void);
// 0x000000D0 System.Collections.Generic.IEnumerable`1<SimpleJSON.JSONNode> SimpleJSON.JSONNode::get_Children()
extern void JSONNode_get_Children_m3E2D70DBCA2C8311F65A47B766668728392B1F89 (void);
// 0x000000D1 System.Collections.Generic.IEnumerable`1<SimpleJSON.JSONNode> SimpleJSON.JSONNode::get_DeepChildren()
extern void JSONNode_get_DeepChildren_m891CB892AEA834980686ED760B952A86DC1E8725 (void);
// 0x000000D2 System.String SimpleJSON.JSONNode::ToString()
extern void JSONNode_ToString_m4CC464630B0AEEDD82AEB6B069690949AF569345 (void);
// 0x000000D3 System.String SimpleJSON.JSONNode::ToString(System.Int32)
extern void JSONNode_ToString_m1F607CB90F49115510B7CF5228733578E9AD41F2 (void);
// 0x000000D4 System.Void SimpleJSON.JSONNode::WriteToStringBuilder(System.Text.StringBuilder,System.Int32,System.Int32,SimpleJSON.JSONTextMode)
// 0x000000D5 SimpleJSON.JSONNode/Enumerator SimpleJSON.JSONNode::GetEnumerator()
// 0x000000D6 System.Collections.Generic.IEnumerable`1<System.Collections.Generic.KeyValuePair`2<System.String,SimpleJSON.JSONNode>> SimpleJSON.JSONNode::get_Linq()
extern void JSONNode_get_Linq_m8569DB478533504290D9A09ECA0DF12F116122DA (void);
// 0x000000D7 SimpleJSON.JSONNode/KeyEnumerator SimpleJSON.JSONNode::get_Keys()
extern void JSONNode_get_Keys_mC3401CC91BBD9D1166EF8EFC0C87A820FC543D1B (void);
// 0x000000D8 SimpleJSON.JSONNode/ValueEnumerator SimpleJSON.JSONNode::get_Values()
extern void JSONNode_get_Values_mF8FB164A48A169146D00EBA3F51D4C8E380C1930 (void);
// 0x000000D9 System.Double SimpleJSON.JSONNode::get_AsDouble()
extern void JSONNode_get_AsDouble_m9A8E3EC46E4545BCBFA26B99C0F013067D2F0AE4 (void);
// 0x000000DA System.Void SimpleJSON.JSONNode::set_AsDouble(System.Double)
extern void JSONNode_set_AsDouble_mCDBB05BD0AE82EEF0C4842F5A9205B8F4C858015 (void);
// 0x000000DB System.Int32 SimpleJSON.JSONNode::get_AsInt()
extern void JSONNode_get_AsInt_mE4A3FCC1D91362D077C2ACF418ACAB43771B1FE6 (void);
// 0x000000DC System.Void SimpleJSON.JSONNode::set_AsInt(System.Int32)
extern void JSONNode_set_AsInt_m12FCF0B7E45E17EA0456AE44EFEF0C8731603F50 (void);
// 0x000000DD System.Single SimpleJSON.JSONNode::get_AsFloat()
extern void JSONNode_get_AsFloat_m0D044C1F3FC35086783A4BAF506EA96DC997D050 (void);
// 0x000000DE System.Void SimpleJSON.JSONNode::set_AsFloat(System.Single)
extern void JSONNode_set_AsFloat_m55FCE24DF60B37724DACCCF0A759522B2561DE92 (void);
// 0x000000DF System.Boolean SimpleJSON.JSONNode::get_AsBool()
extern void JSONNode_get_AsBool_m902380F5939671ACBBB7EFA01A48F1A082B1FD9C (void);
// 0x000000E0 System.Void SimpleJSON.JSONNode::set_AsBool(System.Boolean)
extern void JSONNode_set_AsBool_m6097FD196A8C7BB156125363D1C1D3EF0EB67CD3 (void);
// 0x000000E1 SimpleJSON.JSONArray SimpleJSON.JSONNode::get_AsArray()
extern void JSONNode_get_AsArray_m2D0890FDDA140528CAB44B1B6B3E34B26383ACC7 (void);
// 0x000000E2 SimpleJSON.JSONObject SimpleJSON.JSONNode::get_AsObject()
extern void JSONNode_get_AsObject_m72F6D406BECA2FB0A24B20E0A353FDB8E409CA1B (void);
// 0x000000E3 SimpleJSON.JSONNode SimpleJSON.JSONNode::op_Implicit(System.String)
extern void JSONNode_op_Implicit_mA884A397C3152BDB411767FDE9EDC274A8904523 (void);
// 0x000000E4 System.String SimpleJSON.JSONNode::op_Implicit(SimpleJSON.JSONNode)
extern void JSONNode_op_Implicit_m31D5D161C5F21186F90F99E09EC78CED5188C349 (void);
// 0x000000E5 SimpleJSON.JSONNode SimpleJSON.JSONNode::op_Implicit(System.Double)
extern void JSONNode_op_Implicit_m35AB6AB8F232F07E3226DEB06AB832F5C2BD7A8A (void);
// 0x000000E6 System.Double SimpleJSON.JSONNode::op_Implicit(SimpleJSON.JSONNode)
extern void JSONNode_op_Implicit_m0039518B4032423C4CDC8C8B07790AE1779E8E25 (void);
// 0x000000E7 SimpleJSON.JSONNode SimpleJSON.JSONNode::op_Implicit(System.Single)
extern void JSONNode_op_Implicit_m6ECC1712EB162E1AC774A36E31AF31A1FCC5E659 (void);
// 0x000000E8 System.Single SimpleJSON.JSONNode::op_Implicit(SimpleJSON.JSONNode)
extern void JSONNode_op_Implicit_m8312FC9381D54EBF755C7B41D525C6EEAD0EC135 (void);
// 0x000000E9 SimpleJSON.JSONNode SimpleJSON.JSONNode::op_Implicit(System.Int32)
extern void JSONNode_op_Implicit_mD0756B05030DAE5F5D4A3E57708D5EEEF6A362BB (void);
// 0x000000EA System.Int32 SimpleJSON.JSONNode::op_Implicit(SimpleJSON.JSONNode)
extern void JSONNode_op_Implicit_mE793F9163050BD78846F2C2A288A968E8F9C11AD (void);
// 0x000000EB SimpleJSON.JSONNode SimpleJSON.JSONNode::op_Implicit(System.Boolean)
extern void JSONNode_op_Implicit_m2BD30AE4D30506EF634EA264A90E018FF66FF1E4 (void);
// 0x000000EC System.Boolean SimpleJSON.JSONNode::op_Implicit(SimpleJSON.JSONNode)
extern void JSONNode_op_Implicit_m057A1C72683211B58678B1448C260F747434DF40 (void);
// 0x000000ED SimpleJSON.JSONNode SimpleJSON.JSONNode::op_Implicit(System.Collections.Generic.KeyValuePair`2<System.String,SimpleJSON.JSONNode>)
extern void JSONNode_op_Implicit_m5D106035AB428BDA4B6671950E8E5747771CBD7F (void);
// 0x000000EE System.Boolean SimpleJSON.JSONNode::op_Equality(SimpleJSON.JSONNode,System.Object)
extern void JSONNode_op_Equality_m6961ED452D3A120FE9908FFB96260DF98A47A8B3 (void);
// 0x000000EF System.Boolean SimpleJSON.JSONNode::op_Inequality(SimpleJSON.JSONNode,System.Object)
extern void JSONNode_op_Inequality_m2DF69DE99CD87AA07CE1200892E24EA22B351943 (void);
// 0x000000F0 System.Boolean SimpleJSON.JSONNode::Equals(System.Object)
extern void JSONNode_Equals_mE1B8A846783529B1E54786975A6A2396089A88DE (void);
// 0x000000F1 System.Int32 SimpleJSON.JSONNode::GetHashCode()
extern void JSONNode_GetHashCode_m0A263555D1F0E6766A61692A7E1BC3546B2BC984 (void);
// 0x000000F2 System.Text.StringBuilder SimpleJSON.JSONNode::get_EscapeBuilder()
extern void JSONNode_get_EscapeBuilder_m351C10540498042FC3ED424E3D9C08DCB16071FF (void);
// 0x000000F3 System.String SimpleJSON.JSONNode::Escape(System.String)
extern void JSONNode_Escape_mC20A370D25C7B269E4707FF5CEC7062C470C416A (void);
// 0x000000F4 System.Void SimpleJSON.JSONNode::ParseElement(SimpleJSON.JSONNode,System.String,System.String,System.Boolean)
extern void JSONNode_ParseElement_m978282020EF903D5D8F2F2B7B05074A5D1C3F2EF (void);
// 0x000000F5 SimpleJSON.JSONNode SimpleJSON.JSONNode::Parse(System.String)
extern void JSONNode_Parse_m51FFFB4953A8D875B9D2DD5E032D131A149956E0 (void);
// 0x000000F6 System.Void SimpleJSON.JSONNode::.ctor()
extern void JSONNode__ctor_mF8F2893483161D3B7B9877B63C69063D26A5C353 (void);
// 0x000000F7 System.Boolean SimpleJSON.JSONNode/Enumerator::get_IsValid()
extern void Enumerator_get_IsValid_mBC273331DC1699FF46BD3621AE5059A54AD98BA6 (void);
// 0x000000F8 System.Void SimpleJSON.JSONNode/Enumerator::.ctor(System.Collections.Generic.List`1/Enumerator<SimpleJSON.JSONNode>)
extern void Enumerator__ctor_mF21239C69620D815F8CD34F022BE18E9DAF9CB10 (void);
// 0x000000F9 System.Void SimpleJSON.JSONNode/Enumerator::.ctor(System.Collections.Generic.Dictionary`2/Enumerator<System.String,SimpleJSON.JSONNode>)
extern void Enumerator__ctor_mAC4ED0FA4B083E2652E865A41EA5C74A49478EFE (void);
// 0x000000FA System.Collections.Generic.KeyValuePair`2<System.String,SimpleJSON.JSONNode> SimpleJSON.JSONNode/Enumerator::get_Current()
extern void Enumerator_get_Current_mDE6750203413E1069D0520793D6AA0B2527CB20E (void);
// 0x000000FB System.Boolean SimpleJSON.JSONNode/Enumerator::MoveNext()
extern void Enumerator_MoveNext_m238CF072385A1106BEDEFCE33BA2B0DBE999758A (void);
// 0x000000FC System.Void SimpleJSON.JSONNode/ValueEnumerator::.ctor(System.Collections.Generic.List`1/Enumerator<SimpleJSON.JSONNode>)
extern void ValueEnumerator__ctor_mCC61CE3EDCF1AC94A84E031F2E89F8054C94A015 (void);
// 0x000000FD System.Void SimpleJSON.JSONNode/ValueEnumerator::.ctor(System.Collections.Generic.Dictionary`2/Enumerator<System.String,SimpleJSON.JSONNode>)
extern void ValueEnumerator__ctor_m122732DF448B45E8E82956E07AC8314C60E28C29 (void);
// 0x000000FE System.Void SimpleJSON.JSONNode/ValueEnumerator::.ctor(SimpleJSON.JSONNode/Enumerator)
extern void ValueEnumerator__ctor_m7BA4BAD5FEBAC4054F71575B728DC27EC4080F0A (void);
// 0x000000FF SimpleJSON.JSONNode SimpleJSON.JSONNode/ValueEnumerator::get_Current()
extern void ValueEnumerator_get_Current_mAA24A52FDEB7160BD268193175388EACB41B7CE2 (void);
// 0x00000100 System.Boolean SimpleJSON.JSONNode/ValueEnumerator::MoveNext()
extern void ValueEnumerator_MoveNext_m5B596A2EF2FF395EDA8F5CAB97C0789498D250C9 (void);
// 0x00000101 SimpleJSON.JSONNode/ValueEnumerator SimpleJSON.JSONNode/ValueEnumerator::GetEnumerator()
extern void ValueEnumerator_GetEnumerator_m765261287A2C0AEF757B94994826F43951387E4C (void);
// 0x00000102 System.Void SimpleJSON.JSONNode/KeyEnumerator::.ctor(System.Collections.Generic.List`1/Enumerator<SimpleJSON.JSONNode>)
extern void KeyEnumerator__ctor_m6EA81E2BED4CA5194A7306D8B324F7356E37F80A (void);
// 0x00000103 System.Void SimpleJSON.JSONNode/KeyEnumerator::.ctor(System.Collections.Generic.Dictionary`2/Enumerator<System.String,SimpleJSON.JSONNode>)
extern void KeyEnumerator__ctor_mA6338E82A9F8AA19A1744352B4FE54103AD70405 (void);
// 0x00000104 System.Void SimpleJSON.JSONNode/KeyEnumerator::.ctor(SimpleJSON.JSONNode/Enumerator)
extern void KeyEnumerator__ctor_m526EA1364C367B83C931F4208CDD816BD02810EA (void);
// 0x00000105 SimpleJSON.JSONNode SimpleJSON.JSONNode/KeyEnumerator::get_Current()
extern void KeyEnumerator_get_Current_m8FBFEE52D4438AAF3E10AB4370B34FBB8E66B3C2 (void);
// 0x00000106 System.Boolean SimpleJSON.JSONNode/KeyEnumerator::MoveNext()
extern void KeyEnumerator_MoveNext_m42FE2CEE808A7E065895BA333B7FBD2F3AEE032F (void);
// 0x00000107 SimpleJSON.JSONNode/KeyEnumerator SimpleJSON.JSONNode/KeyEnumerator::GetEnumerator()
extern void KeyEnumerator_GetEnumerator_mD4687B4D6D10E4D6870CBBECC680689A62A95C0B (void);
// 0x00000108 System.Void SimpleJSON.JSONNode/LinqEnumerator::.ctor(SimpleJSON.JSONNode)
extern void LinqEnumerator__ctor_m9FD8AB1580F3D94C5C36D070DBE85E023ED36E30 (void);
// 0x00000109 System.Collections.Generic.KeyValuePair`2<System.String,SimpleJSON.JSONNode> SimpleJSON.JSONNode/LinqEnumerator::get_Current()
extern void LinqEnumerator_get_Current_m28F0BE4D9B5736F5BD79197C1895EAC1592EBAAF (void);
// 0x0000010A System.Object SimpleJSON.JSONNode/LinqEnumerator::System.Collections.IEnumerator.get_Current()
extern void LinqEnumerator_System_Collections_IEnumerator_get_Current_m6B6C12C7E8CD21DF513FCDCB4E88E454790B6FF0 (void);
// 0x0000010B System.Boolean SimpleJSON.JSONNode/LinqEnumerator::MoveNext()
extern void LinqEnumerator_MoveNext_mCA8604B6E8D857CF16003E674048C05E29447819 (void);
// 0x0000010C System.Void SimpleJSON.JSONNode/LinqEnumerator::Dispose()
extern void LinqEnumerator_Dispose_m5D6A54C4B712D138739726323D5BEA50A4E12E32 (void);
// 0x0000010D System.Collections.Generic.IEnumerator`1<System.Collections.Generic.KeyValuePair`2<System.String,SimpleJSON.JSONNode>> SimpleJSON.JSONNode/LinqEnumerator::GetEnumerator()
extern void LinqEnumerator_GetEnumerator_m4A9F0720F0C0964F91032AB8B8776F09DC70A90B (void);
// 0x0000010E System.Void SimpleJSON.JSONNode/LinqEnumerator::Reset()
extern void LinqEnumerator_Reset_m56B65E398518EF57070307FDC48069DFE37BC57B (void);
// 0x0000010F System.Collections.IEnumerator SimpleJSON.JSONNode/LinqEnumerator::System.Collections.IEnumerable.GetEnumerator()
extern void LinqEnumerator_System_Collections_IEnumerable_GetEnumerator_mB63F02D713868ABF87DAB18ABFD5D832F4D805A4 (void);
// 0x00000110 System.Void SimpleJSON.JSONNode/<get_Children>d__39::.ctor(System.Int32)
extern void U3Cget_ChildrenU3Ed__39__ctor_mE347A8AF3B9D5C4D4F6509D57E7CC6CE66ECB030 (void);
// 0x00000111 System.Void SimpleJSON.JSONNode/<get_Children>d__39::System.IDisposable.Dispose()
extern void U3Cget_ChildrenU3Ed__39_System_IDisposable_Dispose_m83B3259F42DA4913E6BA73E4B67995251F62B659 (void);
// 0x00000112 System.Boolean SimpleJSON.JSONNode/<get_Children>d__39::MoveNext()
extern void U3Cget_ChildrenU3Ed__39_MoveNext_m7F8BC2F0D3F2F133AE089C63DF942F68EC60B061 (void);
// 0x00000113 SimpleJSON.JSONNode SimpleJSON.JSONNode/<get_Children>d__39::System.Collections.Generic.IEnumerator<SimpleJSON.JSONNode>.get_Current()
extern void U3Cget_ChildrenU3Ed__39_System_Collections_Generic_IEnumeratorU3CSimpleJSON_JSONNodeU3E_get_Current_m08B40FC9CDFD3E5D5870D853FC8A2F8FDE4002FF (void);
// 0x00000114 System.Void SimpleJSON.JSONNode/<get_Children>d__39::System.Collections.IEnumerator.Reset()
extern void U3Cget_ChildrenU3Ed__39_System_Collections_IEnumerator_Reset_m29D526BB30BD3C9C22C4AEB799A0F66BE86F3634 (void);
// 0x00000115 System.Object SimpleJSON.JSONNode/<get_Children>d__39::System.Collections.IEnumerator.get_Current()
extern void U3Cget_ChildrenU3Ed__39_System_Collections_IEnumerator_get_Current_mCEDDCFFB132A818568BC4C90DD1034DE67445C2C (void);
// 0x00000116 System.Collections.Generic.IEnumerator`1<SimpleJSON.JSONNode> SimpleJSON.JSONNode/<get_Children>d__39::System.Collections.Generic.IEnumerable<SimpleJSON.JSONNode>.GetEnumerator()
extern void U3Cget_ChildrenU3Ed__39_System_Collections_Generic_IEnumerableU3CSimpleJSON_JSONNodeU3E_GetEnumerator_m88A6D227A5F685108F3C0AF2B3C09F441D1DB2B4 (void);
// 0x00000117 System.Collections.IEnumerator SimpleJSON.JSONNode/<get_Children>d__39::System.Collections.IEnumerable.GetEnumerator()
extern void U3Cget_ChildrenU3Ed__39_System_Collections_IEnumerable_GetEnumerator_mDBBA1FB4E94BA2024CF7AB55E45A30CDF8A9D97C (void);
// 0x00000118 System.Void SimpleJSON.JSONNode/<get_DeepChildren>d__41::.ctor(System.Int32)
extern void U3Cget_DeepChildrenU3Ed__41__ctor_mBDA566DBD5671420C00A4BE3C626FE3DBCA4F2FF (void);
// 0x00000119 System.Void SimpleJSON.JSONNode/<get_DeepChildren>d__41::System.IDisposable.Dispose()
extern void U3Cget_DeepChildrenU3Ed__41_System_IDisposable_Dispose_m7CC1A44CD233B61577B3588C893E5A08CC632820 (void);
// 0x0000011A System.Boolean SimpleJSON.JSONNode/<get_DeepChildren>d__41::MoveNext()
extern void U3Cget_DeepChildrenU3Ed__41_MoveNext_mBF21C7378F5F84A820EBFE2A902E4AE286C7B766 (void);
// 0x0000011B System.Void SimpleJSON.JSONNode/<get_DeepChildren>d__41::<>m__Finally1()
extern void U3Cget_DeepChildrenU3Ed__41_U3CU3Em__Finally1_mADDA3B6024A9F163E8407AFCC5DD816C86425BD1 (void);
// 0x0000011C System.Void SimpleJSON.JSONNode/<get_DeepChildren>d__41::<>m__Finally2()
extern void U3Cget_DeepChildrenU3Ed__41_U3CU3Em__Finally2_m5F77C658D020C0D4C1BDB73CC95472686B866933 (void);
// 0x0000011D SimpleJSON.JSONNode SimpleJSON.JSONNode/<get_DeepChildren>d__41::System.Collections.Generic.IEnumerator<SimpleJSON.JSONNode>.get_Current()
extern void U3Cget_DeepChildrenU3Ed__41_System_Collections_Generic_IEnumeratorU3CSimpleJSON_JSONNodeU3E_get_Current_m5DF708741D3562929E32905F4971899FBD460B22 (void);
// 0x0000011E System.Void SimpleJSON.JSONNode/<get_DeepChildren>d__41::System.Collections.IEnumerator.Reset()
extern void U3Cget_DeepChildrenU3Ed__41_System_Collections_IEnumerator_Reset_m44EB9C4E73D96517BE71B57398E810F9D773BD85 (void);
// 0x0000011F System.Object SimpleJSON.JSONNode/<get_DeepChildren>d__41::System.Collections.IEnumerator.get_Current()
extern void U3Cget_DeepChildrenU3Ed__41_System_Collections_IEnumerator_get_Current_mB834AFAFFC33D4E01335C829157FC7F6466261BF (void);
// 0x00000120 System.Collections.Generic.IEnumerator`1<SimpleJSON.JSONNode> SimpleJSON.JSONNode/<get_DeepChildren>d__41::System.Collections.Generic.IEnumerable<SimpleJSON.JSONNode>.GetEnumerator()
extern void U3Cget_DeepChildrenU3Ed__41_System_Collections_Generic_IEnumerableU3CSimpleJSON_JSONNodeU3E_GetEnumerator_mA8D43B603CE4FF1056ECD5ACE0B408F581C8D0AB (void);
// 0x00000121 System.Collections.IEnumerator SimpleJSON.JSONNode/<get_DeepChildren>d__41::System.Collections.IEnumerable.GetEnumerator()
extern void U3Cget_DeepChildrenU3Ed__41_System_Collections_IEnumerable_GetEnumerator_m644D4075F06E77109D3702EDD1AD55FDCFD61BB1 (void);
// 0x00000122 System.Boolean SimpleJSON.JSONArray::get_Inline()
extern void JSONArray_get_Inline_mBA0C9AEBB7420DBDFD977C0F54CC237E8F2BE3E5 (void);
// 0x00000123 System.Void SimpleJSON.JSONArray::set_Inline(System.Boolean)
extern void JSONArray_set_Inline_m731089F5D0FA649ED210518DC299635A8D86A1DC (void);
// 0x00000124 SimpleJSON.JSONNodeType SimpleJSON.JSONArray::get_Tag()
extern void JSONArray_get_Tag_m360EB078D7897D6D52783B8CDA6B736D014E97BC (void);
// 0x00000125 System.Boolean SimpleJSON.JSONArray::get_IsArray()
extern void JSONArray_get_IsArray_mA7B4EF5B0128FB64ACEB7EAC66FA3522991980AF (void);
// 0x00000126 SimpleJSON.JSONNode/Enumerator SimpleJSON.JSONArray::GetEnumerator()
extern void JSONArray_GetEnumerator_m6AF64AE0DD2A5AAB8C0E271BF0CAB8AA1FD32E17 (void);
// 0x00000127 SimpleJSON.JSONNode SimpleJSON.JSONArray::get_Item(System.Int32)
extern void JSONArray_get_Item_m8BE9047FC512840E6A4594560EDF86BB4E0FF657 (void);
// 0x00000128 System.Void SimpleJSON.JSONArray::set_Item(System.Int32,SimpleJSON.JSONNode)
extern void JSONArray_set_Item_mBCD05590C34BC589B786E753B9FE796EBA3F6725 (void);
// 0x00000129 SimpleJSON.JSONNode SimpleJSON.JSONArray::get_Item(System.String)
extern void JSONArray_get_Item_mE18312128B02B505BA656D7F444B05A6769710AE (void);
// 0x0000012A System.Void SimpleJSON.JSONArray::set_Item(System.String,SimpleJSON.JSONNode)
extern void JSONArray_set_Item_mE4E0DE5133E60AF49E46FEDAD00D2A04349C0855 (void);
// 0x0000012B System.Int32 SimpleJSON.JSONArray::get_Count()
extern void JSONArray_get_Count_mB71218A2D8288D0665C467844F7351D301FDAFDD (void);
// 0x0000012C System.Void SimpleJSON.JSONArray::Add(System.String,SimpleJSON.JSONNode)
extern void JSONArray_Add_mD1FBE0F0FC20E7415014B7FF21939592EBB0C9A1 (void);
// 0x0000012D SimpleJSON.JSONNode SimpleJSON.JSONArray::Remove(System.Int32)
extern void JSONArray_Remove_m79500DBD9751A04C02756470A4D22DDCF9C97FEC (void);
// 0x0000012E SimpleJSON.JSONNode SimpleJSON.JSONArray::Remove(SimpleJSON.JSONNode)
extern void JSONArray_Remove_m64C3EBFE3DB5BE130232769DC43000E84589E674 (void);
// 0x0000012F System.Collections.Generic.IEnumerable`1<SimpleJSON.JSONNode> SimpleJSON.JSONArray::get_Children()
extern void JSONArray_get_Children_m733AE4C5816E51E6F86441110606489A0406AA91 (void);
// 0x00000130 System.Void SimpleJSON.JSONArray::WriteToStringBuilder(System.Text.StringBuilder,System.Int32,System.Int32,SimpleJSON.JSONTextMode)
extern void JSONArray_WriteToStringBuilder_m9F23115433028794DCAC019F82EEFD946990D994 (void);
// 0x00000131 System.Void SimpleJSON.JSONArray::.ctor()
extern void JSONArray__ctor_m92FFF2DC8E1425398814F50D4B253EB459B8477F (void);
// 0x00000132 System.Void SimpleJSON.JSONArray/<get_Children>d__22::.ctor(System.Int32)
extern void U3Cget_ChildrenU3Ed__22__ctor_m85868694A6F76D6658184E05C60FF81F01F77A15 (void);
// 0x00000133 System.Void SimpleJSON.JSONArray/<get_Children>d__22::System.IDisposable.Dispose()
extern void U3Cget_ChildrenU3Ed__22_System_IDisposable_Dispose_m2F364B8DD4640833161EE743D458FAF77BCAED9F (void);
// 0x00000134 System.Boolean SimpleJSON.JSONArray/<get_Children>d__22::MoveNext()
extern void U3Cget_ChildrenU3Ed__22_MoveNext_mD1A93CD03B10AD9224ACD34AA4478BA4EB448AE5 (void);
// 0x00000135 System.Void SimpleJSON.JSONArray/<get_Children>d__22::<>m__Finally1()
extern void U3Cget_ChildrenU3Ed__22_U3CU3Em__Finally1_mE8C769C27FDCFEA9BDE25D788AE87EC9565F4C5F (void);
// 0x00000136 SimpleJSON.JSONNode SimpleJSON.JSONArray/<get_Children>d__22::System.Collections.Generic.IEnumerator<SimpleJSON.JSONNode>.get_Current()
extern void U3Cget_ChildrenU3Ed__22_System_Collections_Generic_IEnumeratorU3CSimpleJSON_JSONNodeU3E_get_Current_m9FB6C47800DA9AC5BD99118430A954370D30FA70 (void);
// 0x00000137 System.Void SimpleJSON.JSONArray/<get_Children>d__22::System.Collections.IEnumerator.Reset()
extern void U3Cget_ChildrenU3Ed__22_System_Collections_IEnumerator_Reset_m5FDF47F215C3ECA0B88DBDBA67D9E23939FB6E75 (void);
// 0x00000138 System.Object SimpleJSON.JSONArray/<get_Children>d__22::System.Collections.IEnumerator.get_Current()
extern void U3Cget_ChildrenU3Ed__22_System_Collections_IEnumerator_get_Current_mB7369D4C4D04908F6F69E55E0FDF6835418E9671 (void);
// 0x00000139 System.Collections.Generic.IEnumerator`1<SimpleJSON.JSONNode> SimpleJSON.JSONArray/<get_Children>d__22::System.Collections.Generic.IEnumerable<SimpleJSON.JSONNode>.GetEnumerator()
extern void U3Cget_ChildrenU3Ed__22_System_Collections_Generic_IEnumerableU3CSimpleJSON_JSONNodeU3E_GetEnumerator_mE9E5D91FED8686D7D44613FE3F2E5A67765D924E (void);
// 0x0000013A System.Collections.IEnumerator SimpleJSON.JSONArray/<get_Children>d__22::System.Collections.IEnumerable.GetEnumerator()
extern void U3Cget_ChildrenU3Ed__22_System_Collections_IEnumerable_GetEnumerator_m64A7C394D254404FA1EE6C54C42CB33064B85573 (void);
// 0x0000013B System.Boolean SimpleJSON.JSONObject::get_Inline()
extern void JSONObject_get_Inline_mCDF2154366BEFF9E547918F999E7F3C7C4865F84 (void);
// 0x0000013C System.Void SimpleJSON.JSONObject::set_Inline(System.Boolean)
extern void JSONObject_set_Inline_m7F048A7565E5A53FDB610D44B7CA75A314CB7A7A (void);
// 0x0000013D SimpleJSON.JSONNodeType SimpleJSON.JSONObject::get_Tag()
extern void JSONObject_get_Tag_mD57D6BCAD1C677B88693FD508129CFAD661F4FBD (void);
// 0x0000013E System.Boolean SimpleJSON.JSONObject::get_IsObject()
extern void JSONObject_get_IsObject_m9F72861BE5A0DB2888AA3CBEC82718E08DD71E93 (void);
// 0x0000013F SimpleJSON.JSONNode/Enumerator SimpleJSON.JSONObject::GetEnumerator()
extern void JSONObject_GetEnumerator_m8912E3D1EA302655BB5701B53EB19437238BABDA (void);
// 0x00000140 SimpleJSON.JSONNode SimpleJSON.JSONObject::get_Item(System.String)
extern void JSONObject_get_Item_m219B9BA37D800A5DFEAA14E4EECA375B3565BF96 (void);
// 0x00000141 System.Void SimpleJSON.JSONObject::set_Item(System.String,SimpleJSON.JSONNode)
extern void JSONObject_set_Item_m1AC7334DBA67D0CB6C9549B83B3FFA75CF226AEF (void);
// 0x00000142 SimpleJSON.JSONNode SimpleJSON.JSONObject::get_Item(System.Int32)
extern void JSONObject_get_Item_m5C2EDBE7B154A3FC1CC43616C4C40255B4D95652 (void);
// 0x00000143 System.Void SimpleJSON.JSONObject::set_Item(System.Int32,SimpleJSON.JSONNode)
extern void JSONObject_set_Item_mFB6E61E3FA394B7D2CA01CC957A6A253642D109B (void);
// 0x00000144 System.Int32 SimpleJSON.JSONObject::get_Count()
extern void JSONObject_get_Count_m9109E9A81559A9006EE160CA6A0F3291C71F2D08 (void);
// 0x00000145 System.Void SimpleJSON.JSONObject::Add(System.String,SimpleJSON.JSONNode)
extern void JSONObject_Add_m25BD208A0AC0F0223FD93FBCB42785B12A6E1A18 (void);
// 0x00000146 SimpleJSON.JSONNode SimpleJSON.JSONObject::Remove(System.String)
extern void JSONObject_Remove_m34280FDB4512E61F42781475E492BE98514830C9 (void);
// 0x00000147 SimpleJSON.JSONNode SimpleJSON.JSONObject::Remove(System.Int32)
extern void JSONObject_Remove_mD1B01E22A9C1FEE83A00ECDFD8E0D8A422F8E4C2 (void);
// 0x00000148 SimpleJSON.JSONNode SimpleJSON.JSONObject::Remove(SimpleJSON.JSONNode)
extern void JSONObject_Remove_m51B998A7997D184A1A20359D512C6B5A1B825404 (void);
// 0x00000149 System.Collections.Generic.IEnumerable`1<SimpleJSON.JSONNode> SimpleJSON.JSONObject::get_Children()
extern void JSONObject_get_Children_m03D7227DE57F0BE2977FC0436C0DE48858650B7C (void);
// 0x0000014A System.Void SimpleJSON.JSONObject::WriteToStringBuilder(System.Text.StringBuilder,System.Int32,System.Int32,SimpleJSON.JSONTextMode)
extern void JSONObject_WriteToStringBuilder_m931DC8805C6B8F09617958EFDAEA957751EB2EAE (void);
// 0x0000014B System.Void SimpleJSON.JSONObject::.ctor()
extern void JSONObject__ctor_m8007967452F5257DC9F5DF2B78B411BFD4B6D6AB (void);
// 0x0000014C System.Void SimpleJSON.JSONObject/<>c__DisplayClass21_0::.ctor()
extern void U3CU3Ec__DisplayClass21_0__ctor_m6976B4CF7F93E28364B390F81E55DAD60BB141C1 (void);
// 0x0000014D System.Boolean SimpleJSON.JSONObject/<>c__DisplayClass21_0::<Remove>b__0(System.Collections.Generic.KeyValuePair`2<System.String,SimpleJSON.JSONNode>)
extern void U3CU3Ec__DisplayClass21_0_U3CRemoveU3Eb__0_m8B35D441B276B749481FF797FC51A256A7A56105 (void);
// 0x0000014E System.Void SimpleJSON.JSONObject/<get_Children>d__23::.ctor(System.Int32)
extern void U3Cget_ChildrenU3Ed__23__ctor_mD7DD2FB8F14148B45EC4AC3A595DC1AFE369FC99 (void);
// 0x0000014F System.Void SimpleJSON.JSONObject/<get_Children>d__23::System.IDisposable.Dispose()
extern void U3Cget_ChildrenU3Ed__23_System_IDisposable_Dispose_m85C7654E92BD35A4525D4F3E70FFD57B5CD497AF (void);
// 0x00000150 System.Boolean SimpleJSON.JSONObject/<get_Children>d__23::MoveNext()
extern void U3Cget_ChildrenU3Ed__23_MoveNext_mB9E90BB01F42BA8913E7CD7AEA18FBEADFC46CC0 (void);
// 0x00000151 System.Void SimpleJSON.JSONObject/<get_Children>d__23::<>m__Finally1()
extern void U3Cget_ChildrenU3Ed__23_U3CU3Em__Finally1_m0FEB12CB9C8CC84E25A44F9FC928D8EB8F4DF9DD (void);
// 0x00000152 SimpleJSON.JSONNode SimpleJSON.JSONObject/<get_Children>d__23::System.Collections.Generic.IEnumerator<SimpleJSON.JSONNode>.get_Current()
extern void U3Cget_ChildrenU3Ed__23_System_Collections_Generic_IEnumeratorU3CSimpleJSON_JSONNodeU3E_get_Current_mFB2B5F5F93F044ADBF11AF1C59D305BFE295D063 (void);
// 0x00000153 System.Void SimpleJSON.JSONObject/<get_Children>d__23::System.Collections.IEnumerator.Reset()
extern void U3Cget_ChildrenU3Ed__23_System_Collections_IEnumerator_Reset_mE65CCEC3E7FCE86596AF14C5821DA3D5F76C34E3 (void);
// 0x00000154 System.Object SimpleJSON.JSONObject/<get_Children>d__23::System.Collections.IEnumerator.get_Current()
extern void U3Cget_ChildrenU3Ed__23_System_Collections_IEnumerator_get_Current_m3B0D1EE4EF3C849E2A702C9B9DB6F65FA70890D9 (void);
// 0x00000155 System.Collections.Generic.IEnumerator`1<SimpleJSON.JSONNode> SimpleJSON.JSONObject/<get_Children>d__23::System.Collections.Generic.IEnumerable<SimpleJSON.JSONNode>.GetEnumerator()
extern void U3Cget_ChildrenU3Ed__23_System_Collections_Generic_IEnumerableU3CSimpleJSON_JSONNodeU3E_GetEnumerator_m42B5EADBEE1E083675385176B87BCAB7C4FA0873 (void);
// 0x00000156 System.Collections.IEnumerator SimpleJSON.JSONObject/<get_Children>d__23::System.Collections.IEnumerable.GetEnumerator()
extern void U3Cget_ChildrenU3Ed__23_System_Collections_IEnumerable_GetEnumerator_mC4F14551458D7F9F3DDC7610F078982D1C04DBD4 (void);
// 0x00000157 SimpleJSON.JSONNodeType SimpleJSON.JSONString::get_Tag()
extern void JSONString_get_Tag_m68B0FF9ADDC3E203E5D60BB10639AEABACA34D44 (void);
// 0x00000158 System.Boolean SimpleJSON.JSONString::get_IsString()
extern void JSONString_get_IsString_m933985E37AE8A887A2039A9BAC7698F083BCD6E3 (void);
// 0x00000159 SimpleJSON.JSONNode/Enumerator SimpleJSON.JSONString::GetEnumerator()
extern void JSONString_GetEnumerator_m1CB9E437FC8622F3FE05D0AC12024D144747E0B8 (void);
// 0x0000015A System.String SimpleJSON.JSONString::get_Value()
extern void JSONString_get_Value_mEAD2BD372A2C517E83233BA5F6E309745AA5E9B4 (void);
// 0x0000015B System.Void SimpleJSON.JSONString::set_Value(System.String)
extern void JSONString_set_Value_mB974D9B82AB8F9FAB84DCA99B8BD4B7C1C08ED00 (void);
// 0x0000015C System.Void SimpleJSON.JSONString::.ctor(System.String)
extern void JSONString__ctor_m1DD5FB9A4147F72A0ED5F773FF82FA269241AD19 (void);
// 0x0000015D System.Void SimpleJSON.JSONString::WriteToStringBuilder(System.Text.StringBuilder,System.Int32,System.Int32,SimpleJSON.JSONTextMode)
extern void JSONString_WriteToStringBuilder_mDF24D860FBF8E71F6F04799DD70F7700CE41D818 (void);
// 0x0000015E System.Boolean SimpleJSON.JSONString::Equals(System.Object)
extern void JSONString_Equals_m1C60B537E558E6DF85ACF3EF9FF43BF9A3CF5435 (void);
// 0x0000015F System.Int32 SimpleJSON.JSONString::GetHashCode()
extern void JSONString_GetHashCode_m979A74F84B4C0F45BF63D75DE1146490F743EE00 (void);
// 0x00000160 SimpleJSON.JSONNodeType SimpleJSON.JSONNumber::get_Tag()
extern void JSONNumber_get_Tag_m7C6E217E85B6161812496B63E5D371B910AAC856 (void);
// 0x00000161 System.Boolean SimpleJSON.JSONNumber::get_IsNumber()
extern void JSONNumber_get_IsNumber_mFABFD0C9C4905CFB34A62700A1BD335F53E4214E (void);
// 0x00000162 SimpleJSON.JSONNode/Enumerator SimpleJSON.JSONNumber::GetEnumerator()
extern void JSONNumber_GetEnumerator_m4D13E84756AEED9FCD7EFEEE4D01187DD049C596 (void);
// 0x00000163 System.String SimpleJSON.JSONNumber::get_Value()
extern void JSONNumber_get_Value_mBC5AB046D134B1E54C228C9C1C2231F8448CD56D (void);
// 0x00000164 System.Void SimpleJSON.JSONNumber::set_Value(System.String)
extern void JSONNumber_set_Value_m2264762BBD76F39DDC5DF3160910A44FBEFDE54C (void);
// 0x00000165 System.Double SimpleJSON.JSONNumber::get_AsDouble()
extern void JSONNumber_get_AsDouble_m8C004121700A7E7EB2B77ED223187227E33DE60B (void);
// 0x00000166 System.Void SimpleJSON.JSONNumber::set_AsDouble(System.Double)
extern void JSONNumber_set_AsDouble_m8E17AF8C0E9AE0EF6E25D86CB1B119904ADC0558 (void);
// 0x00000167 System.Void SimpleJSON.JSONNumber::.ctor(System.Double)
extern void JSONNumber__ctor_m1CE3527102D15EBC3A183E3519895E291CAC1D90 (void);
// 0x00000168 System.Void SimpleJSON.JSONNumber::.ctor(System.String)
extern void JSONNumber__ctor_m39FDDE1A9EFEE9C4F2498E531D12B97AA49A1BA5 (void);
// 0x00000169 System.Void SimpleJSON.JSONNumber::WriteToStringBuilder(System.Text.StringBuilder,System.Int32,System.Int32,SimpleJSON.JSONTextMode)
extern void JSONNumber_WriteToStringBuilder_mD311BC3C1EE3E159C43801EB214F084E567367F2 (void);
// 0x0000016A System.Boolean SimpleJSON.JSONNumber::IsNumeric(System.Object)
extern void JSONNumber_IsNumeric_mE6C07226FABFDD425449643925B667C05C52D41D (void);
// 0x0000016B System.Boolean SimpleJSON.JSONNumber::Equals(System.Object)
extern void JSONNumber_Equals_mC04BB811CCAF20E70AE696AE74ECFDF5DA888688 (void);
// 0x0000016C System.Int32 SimpleJSON.JSONNumber::GetHashCode()
extern void JSONNumber_GetHashCode_m976ADFE41037830524798C7E6AFE08006B5F77AD (void);
// 0x0000016D SimpleJSON.JSONNodeType SimpleJSON.JSONBool::get_Tag()
extern void JSONBool_get_Tag_m82CE84C4C89E157D4DB036B9F0745343C005C338 (void);
// 0x0000016E System.Boolean SimpleJSON.JSONBool::get_IsBoolean()
extern void JSONBool_get_IsBoolean_m2671AE98710859611DF47E6BC58E6582C3A5B445 (void);
// 0x0000016F SimpleJSON.JSONNode/Enumerator SimpleJSON.JSONBool::GetEnumerator()
extern void JSONBool_GetEnumerator_mA07A10A6111713F7AD09FF03D09A6028556094D9 (void);
// 0x00000170 System.String SimpleJSON.JSONBool::get_Value()
extern void JSONBool_get_Value_mBEA89869448B0B597758D5BF2A3B576CA0BB64E3 (void);
// 0x00000171 System.Void SimpleJSON.JSONBool::set_Value(System.String)
extern void JSONBool_set_Value_mC960EE4083CA91D0059BE24661AFC06E131E2CFC (void);
// 0x00000172 System.Boolean SimpleJSON.JSONBool::get_AsBool()
extern void JSONBool_get_AsBool_mE04224144EAD0A9AD2F3B14BC0C68557A3BF22AC (void);
// 0x00000173 System.Void SimpleJSON.JSONBool::set_AsBool(System.Boolean)
extern void JSONBool_set_AsBool_m88EDF61A5ABBFF3ECF723312852E14F3C60AE365 (void);
// 0x00000174 System.Void SimpleJSON.JSONBool::.ctor(System.Boolean)
extern void JSONBool__ctor_mBB02E388CFB96B99E84561FCFF68147F00391C58 (void);
// 0x00000175 System.Void SimpleJSON.JSONBool::.ctor(System.String)
extern void JSONBool__ctor_m8CFB6AA78095EA003AB9B5EDD8932E8E0B01A1B9 (void);
// 0x00000176 System.Void SimpleJSON.JSONBool::WriteToStringBuilder(System.Text.StringBuilder,System.Int32,System.Int32,SimpleJSON.JSONTextMode)
extern void JSONBool_WriteToStringBuilder_m82C70C80863730E8A22EE7A5B099C765F2E1D91E (void);
// 0x00000177 System.Boolean SimpleJSON.JSONBool::Equals(System.Object)
extern void JSONBool_Equals_m2671F40DA8F1128BA1451FE7066515C6E0C50D45 (void);
// 0x00000178 System.Int32 SimpleJSON.JSONBool::GetHashCode()
extern void JSONBool_GetHashCode_mC5B59375A9EE9978A5ADD1A24ECEE3FC920836DB (void);
// 0x00000179 SimpleJSON.JSONNull SimpleJSON.JSONNull::CreateOrGet()
extern void JSONNull_CreateOrGet_m68ED6000156701E566B1EA9DDC5284299B0C9105 (void);
// 0x0000017A System.Void SimpleJSON.JSONNull::.ctor()
extern void JSONNull__ctor_m909243259F39D10FA6FEB176474DEF9C9972D76B (void);
// 0x0000017B SimpleJSON.JSONNodeType SimpleJSON.JSONNull::get_Tag()
extern void JSONNull_get_Tag_m89A7F368EA6269874235F85E43AE82254AAFD41E (void);
// 0x0000017C System.Boolean SimpleJSON.JSONNull::get_IsNull()
extern void JSONNull_get_IsNull_m1174212D6379871AC361EF06FA05DD510FC55595 (void);
// 0x0000017D SimpleJSON.JSONNode/Enumerator SimpleJSON.JSONNull::GetEnumerator()
extern void JSONNull_GetEnumerator_m16D254C74386D1A0AB2EFD1DE0EAF409C73B7686 (void);
// 0x0000017E System.String SimpleJSON.JSONNull::get_Value()
extern void JSONNull_get_Value_mB15431220D7D0B45CE002A204DF9E070CF78DBE0 (void);
// 0x0000017F System.Void SimpleJSON.JSONNull::set_Value(System.String)
extern void JSONNull_set_Value_mAF0CD2E912EF772E0892EB4ABB77294F689CF20A (void);
// 0x00000180 System.Boolean SimpleJSON.JSONNull::get_AsBool()
extern void JSONNull_get_AsBool_m6F3817CD49ED7CC10C180D31D84ED4B0151C78CE (void);
// 0x00000181 System.Void SimpleJSON.JSONNull::set_AsBool(System.Boolean)
extern void JSONNull_set_AsBool_m5717BC3921B7DE0683E9160B3816628B5CBC663D (void);
// 0x00000182 System.Boolean SimpleJSON.JSONNull::Equals(System.Object)
extern void JSONNull_Equals_m8A39CAD3A41E9584C434B90A1360C62B3E158DE6 (void);
// 0x00000183 System.Int32 SimpleJSON.JSONNull::GetHashCode()
extern void JSONNull_GetHashCode_m74BE6286F06C6E7D5E35381E8BD27215117D9061 (void);
// 0x00000184 System.Void SimpleJSON.JSONNull::WriteToStringBuilder(System.Text.StringBuilder,System.Int32,System.Int32,SimpleJSON.JSONTextMode)
extern void JSONNull_WriteToStringBuilder_mB5B78BFA6A4943319926C1B2AE93F68C7B9B5FFD (void);
// 0x00000185 System.Void SimpleJSON.JSONNull::.cctor()
extern void JSONNull__cctor_m49F440C5442212437C3A1CDAF32B864961BE534B (void);
// 0x00000186 SimpleJSON.JSONNodeType SimpleJSON.JSONLazyCreator::get_Tag()
extern void JSONLazyCreator_get_Tag_m1CB86FEA25328F1BE9CC01F6D020C9450E9F466E (void);
// 0x00000187 SimpleJSON.JSONNode/Enumerator SimpleJSON.JSONLazyCreator::GetEnumerator()
extern void JSONLazyCreator_GetEnumerator_m720BF0642A079A8BD44F6D650CF4D833DEF67757 (void);
// 0x00000188 System.Void SimpleJSON.JSONLazyCreator::.ctor(SimpleJSON.JSONNode)
extern void JSONLazyCreator__ctor_m0B3625D19DDD8DBDBB45822FAABCE266FA4EE694 (void);
// 0x00000189 System.Void SimpleJSON.JSONLazyCreator::.ctor(SimpleJSON.JSONNode,System.String)
extern void JSONLazyCreator__ctor_m02E2D630C60045F25A3AC001B7A17DF2D5D197B4 (void);
// 0x0000018A System.Void SimpleJSON.JSONLazyCreator::Set(SimpleJSON.JSONNode)
extern void JSONLazyCreator_Set_mEF6EB64379EBE960F050C24D45EDCA4B6D404958 (void);
// 0x0000018B SimpleJSON.JSONNode SimpleJSON.JSONLazyCreator::get_Item(System.Int32)
extern void JSONLazyCreator_get_Item_m562D16AE7F1F0CACA5ED050B390B63F98EBC77B1 (void);
// 0x0000018C System.Void SimpleJSON.JSONLazyCreator::set_Item(System.Int32,SimpleJSON.JSONNode)
extern void JSONLazyCreator_set_Item_m42894F9D00193BC7138C5D451E1B0BBD1BFE1084 (void);
// 0x0000018D SimpleJSON.JSONNode SimpleJSON.JSONLazyCreator::get_Item(System.String)
extern void JSONLazyCreator_get_Item_mF7AE3ADFBE062BF3B83FECCE0EF10F10996DE0CD (void);
// 0x0000018E System.Void SimpleJSON.JSONLazyCreator::set_Item(System.String,SimpleJSON.JSONNode)
extern void JSONLazyCreator_set_Item_m0107997E3B3CB75FACD86FB487C5D9416171CBEC (void);
// 0x0000018F System.Void SimpleJSON.JSONLazyCreator::Add(SimpleJSON.JSONNode)
extern void JSONLazyCreator_Add_mA8451EE34FEA0205B6BD6527AB46E5926451F49F (void);
// 0x00000190 System.Void SimpleJSON.JSONLazyCreator::Add(System.String,SimpleJSON.JSONNode)
extern void JSONLazyCreator_Add_mDC69A4E203B73054072D1575EC4CF20D95064F61 (void);
// 0x00000191 System.Boolean SimpleJSON.JSONLazyCreator::op_Equality(SimpleJSON.JSONLazyCreator,System.Object)
extern void JSONLazyCreator_op_Equality_m7C4199B28912BE4C1AE6009F94C6FE07776923C5 (void);
// 0x00000192 System.Boolean SimpleJSON.JSONLazyCreator::op_Inequality(SimpleJSON.JSONLazyCreator,System.Object)
extern void JSONLazyCreator_op_Inequality_m8E4E9C09E420FE4E5A0AB54B63CFAEF2244B5F3B (void);
// 0x00000193 System.Boolean SimpleJSON.JSONLazyCreator::Equals(System.Object)
extern void JSONLazyCreator_Equals_m753939907CFDB1548B0DAAB38E4737EF17B50066 (void);
// 0x00000194 System.Int32 SimpleJSON.JSONLazyCreator::GetHashCode()
extern void JSONLazyCreator_GetHashCode_m878E7AFF42AE5C43F4F643B6AEB25662491316F9 (void);
// 0x00000195 System.Int32 SimpleJSON.JSONLazyCreator::get_AsInt()
extern void JSONLazyCreator_get_AsInt_mE1404FBC99CE4E8EF4ABBE0BDF661206BAC2C44D (void);
// 0x00000196 System.Void SimpleJSON.JSONLazyCreator::set_AsInt(System.Int32)
extern void JSONLazyCreator_set_AsInt_m13146E53FD6A2F7573B752BFF079E0AF6A5FAE74 (void);
// 0x00000197 System.Single SimpleJSON.JSONLazyCreator::get_AsFloat()
extern void JSONLazyCreator_get_AsFloat_m2600D4B0E1179583EFE268070C66EAC11D380E04 (void);
// 0x00000198 System.Void SimpleJSON.JSONLazyCreator::set_AsFloat(System.Single)
extern void JSONLazyCreator_set_AsFloat_m9DCF79C70D4ED3728C12B709A6D95A0F0A057DE0 (void);
// 0x00000199 System.Double SimpleJSON.JSONLazyCreator::get_AsDouble()
extern void JSONLazyCreator_get_AsDouble_m41D6DF89CD7CEC00F36962068EE072D391EC0B38 (void);
// 0x0000019A System.Void SimpleJSON.JSONLazyCreator::set_AsDouble(System.Double)
extern void JSONLazyCreator_set_AsDouble_mB7ABE38136DBEDA7CC9AC12A381322D6C49ADED9 (void);
// 0x0000019B System.Boolean SimpleJSON.JSONLazyCreator::get_AsBool()
extern void JSONLazyCreator_get_AsBool_m7D8AF5879C2C8036916AA6B15E22CB4B80412CF4 (void);
// 0x0000019C System.Void SimpleJSON.JSONLazyCreator::set_AsBool(System.Boolean)
extern void JSONLazyCreator_set_AsBool_m4DB409DB959182CAA610147A51A2ECDBAFEA6092 (void);
// 0x0000019D SimpleJSON.JSONArray SimpleJSON.JSONLazyCreator::get_AsArray()
extern void JSONLazyCreator_get_AsArray_m493C069A3624597885A7B6E00C82E829A84B47C4 (void);
// 0x0000019E SimpleJSON.JSONObject SimpleJSON.JSONLazyCreator::get_AsObject()
extern void JSONLazyCreator_get_AsObject_mE01B43B261A6A56F4FCE40AB11F3AAF90B7C292D (void);
// 0x0000019F System.Void SimpleJSON.JSONLazyCreator::WriteToStringBuilder(System.Text.StringBuilder,System.Int32,System.Int32,SimpleJSON.JSONTextMode)
extern void JSONLazyCreator_WriteToStringBuilder_mC9975859B1C42C9F5E507E604121D10B2FB2D93D (void);
// 0x000001A0 SimpleJSON.JSONNode SimpleJSON.JSON::Parse(System.String)
extern void JSON_Parse_m9E6F3A67011C765E4352E350D1F400C9A52DC5F6 (void);
// 0x000001A1 System.Void Uduino.ArduinoBoardType::.ctor(System.String,System.Int32[],System.Int32[],System.Int32[])
extern void ArduinoBoardType__ctor_m12B1F0FD83B9A6724DCC7B03F31AF39BDDC9501F (void);
// 0x000001A2 System.Void Uduino.ArduinoBoardType::.ctor(System.String,System.Collections.Generic.Dictionary`2<System.String,System.Int32>)
extern void ArduinoBoardType__ctor_mAF567EFAA44749EC18A37CBC4BF061BA36143196 (void);
// 0x000001A3 System.String[] Uduino.ArduinoBoardType::GetPins()
extern void ArduinoBoardType_GetPins_m461C9FCACE56BAA39FAC27BC69A3FD67C3C8B287 (void);
// 0x000001A4 System.Int32[] Uduino.ArduinoBoardType::GetValues()
extern void ArduinoBoardType_GetValues_mCE7F52EEC113B65400C345638CAD36ACE46009D2 (void);
// 0x000001A5 System.Int32 Uduino.ArduinoBoardType::GetPin(System.Int32)
extern void ArduinoBoardType_GetPin_m0756211D53BCB27E8D1EA22CB5457A80B05202D0 (void);
// 0x000001A6 System.Int32 Uduino.ArduinoBoardType::GetPin(System.String)
extern void ArduinoBoardType_GetPin_m715C1325CEC6946F6AA957C3E8CCA083A617D778 (void);
// 0x000001A7 Uduino.BoardsTypeList Uduino.BoardsTypeList::get_Boards()
extern void BoardsTypeList_get_Boards_m9B2355F3DC58D45CC0D5DE7C0506ADF810E0BAAB (void);
// 0x000001A8 System.Void Uduino.BoardsTypeList::set_Boards(Uduino.BoardsTypeList)
extern void BoardsTypeList_set_Boards_m68452F7F541BA61CE759D806DE81BEC10F5A861F (void);
// 0x000001A9 System.Void Uduino.BoardsTypeList::.ctor()
extern void BoardsTypeList__ctor_m1D055C57F69D4E3432322BCE4A5AA021CC62F468 (void);
// 0x000001AA System.String[] Uduino.BoardsTypeList::ListToNames()
extern void BoardsTypeList_ListToNames_mF1F7E37C188E98DA8BEBE1118808FFB9E5342BD0 (void);
// 0x000001AB Uduino.ArduinoBoardType Uduino.BoardsTypeList::GetBoardFromName(System.String)
extern void BoardsTypeList_GetBoardFromName_m6864B73B71EE8C2BD9BC087230AB6A768E1A6A53 (void);
// 0x000001AC Uduino.ArduinoBoardType Uduino.BoardsTypeList::GetBoardFromId(System.Int32)
extern void BoardsTypeList_GetBoardFromId_m2DBC7B3ABA3C9D07544B66C868EBB4C2BDAB0CB0 (void);
// 0x000001AD System.Int32 Uduino.BoardsTypeList::GetBoardIdFromName(System.String)
extern void BoardsTypeList_GetBoardIdFromName_mBBC17CE3DC49E5E2BB434FE84CF0A036D7182FAB (void);
// 0x000001AE System.String Uduino.BoardsTypeList::GetBoardName(System.Int32)
extern void BoardsTypeList_GetBoardName_m5EACB85F15561286663279126E1B55031A94A0FA (void);
// 0x000001AF System.Boolean Uduino.BoardsTypeList::IsWifiBoard(System.Int32)
extern void BoardsTypeList_IsWifiBoard_m11DC5AEA40B9D7D1E07D59F2746D089F89F7AF58 (void);
// 0x000001B0 Uduino.ArduinoBoardType Uduino.BoardsTypeList::addCustomBoardType(System.String,System.Int32[],System.Int32[],System.Int32[])
extern void BoardsTypeList_addCustomBoardType_mA8E042B625A2965832D9AFB07BF55CF6FE5FF5A8 (void);
// 0x000001B1 System.Void Uduino.BoardsTypeList/<>c__DisplayClass6_0::.ctor()
extern void U3CU3Ec__DisplayClass6_0__ctor_m6C0D46713F53CDFDB5882E8A6A7815138027C7D9 (void);
// 0x000001B2 System.Void Uduino.BoardsTypeList/<>c__DisplayClass6_0::<ListToNames>b__0(Uduino.ArduinoBoardType)
extern void U3CU3Ec__DisplayClass6_0_U3CListToNamesU3Eb__0_m54E2862F3E3D1A0F189E5A6ABF384704061F45BB (void);
// 0x000001B3 System.Void Uduino.BoardsTypeList/<>c__DisplayClass7_0::.ctor()
extern void U3CU3Ec__DisplayClass7_0__ctor_m8A1EAB2A8AB3F5C4F402BEE96B732718D9EB1A93 (void);
// 0x000001B4 System.Boolean Uduino.BoardsTypeList/<>c__DisplayClass7_0::<GetBoardFromName>b__0(Uduino.ArduinoBoardType)
extern void U3CU3Ec__DisplayClass7_0_U3CGetBoardFromNameU3Eb__0_m1F5AFF5DDB6B508E5D3A51CC0808AA8CAE1FC797 (void);
// 0x000001B5 System.Void Uduino.BoardsTypeList/<>c__DisplayClass9_0::.ctor()
extern void U3CU3Ec__DisplayClass9_0__ctor_m399234551E1B3911A9AF7E23A3F974ECF6169232 (void);
// 0x000001B6 System.Boolean Uduino.BoardsTypeList/<>c__DisplayClass9_0::<GetBoardIdFromName>b__0(Uduino.ArduinoBoardType)
extern void U3CU3Ec__DisplayClass9_0_U3CGetBoardIdFromNameU3Eb__0_m4D43C729BACEFFA9F879821C068319A79FDD17EF (void);
// 0x000001B7 System.Void Uduino.UduinoConnection_DesktopSerial::.ctor()
extern void UduinoConnection_DesktopSerial__ctor_mB109344083E289FE23BDA76D31E4C6CE2ACAFC6E (void);
// 0x000001B8 System.Void Uduino.UduinoConnection_DesktopSerial::FindBoards(Uduino.UduinoManager)
extern void UduinoConnection_DesktopSerial_FindBoards_mDC9272EC076A744392C3C2EE6D0761D9E0AB36FD (void);
// 0x000001B9 System.String[] Uduino.UduinoConnection_DesktopSerial::GetWindowsPortNames()
extern void UduinoConnection_DesktopSerial_GetWindowsPortNames_m985B4862043B5FB4889744395D9B75C19F711324 (void);
// 0x000001BA System.String[] Uduino.UduinoConnection_DesktopSerial::GetUnixPortNames()
extern void UduinoConnection_DesktopSerial_GetUnixPortNames_mFE32941BC55ED921682C10A792A73BE05F9D7F91 (void);
// 0x000001BB System.Void Uduino.UduinoConnection_DesktopSerial::Discover(System.String[])
extern void UduinoConnection_DesktopSerial_Discover_m1A237CC80C29D0456F544199E24C2A4DC186076F (void);
// 0x000001BC Uduino.UduinoDevice Uduino.UduinoConnection_DesktopSerial::OpenUduinoDevice(System.String)
extern void UduinoConnection_DesktopSerial_OpenUduinoDevice_mE6416AAD3E74E64B4840537CE385E57AACBF7919 (void);
// 0x000001BD System.Void Uduino.UduinoDevice_DesktopSerial::.ctor(System.Int32)
extern void UduinoDevice_DesktopSerial__ctor_m22C4E6BF3E80DEE0022934FAD50B29050189B27D (void);
// 0x000001BE System.Void Uduino.UduinoDevice_DesktopSerial::.ctor(System.String,System.Int32,System.Int32,System.Int32,System.Int32)
extern void UduinoDevice_DesktopSerial__ctor_mCCE2934EB2B2B756C7E9EBCC4B3187D44AFF6433 (void);
// 0x000001BF System.Void Uduino.UduinoDevice_DesktopSerial::Open()
extern void UduinoDevice_DesktopSerial_Open_m3D7A9B00CB97EBACEF5A4D462F41FAF328000E93 (void);
// 0x000001C0 System.Void Uduino.UduinoDevice_DesktopSerial::UduinoFound()
extern void UduinoDevice_DesktopSerial_UduinoFound_mCF1A4C8C44B352C0609494E672B55B1E35A5C30E (void);
// 0x000001C1 System.String Uduino.UduinoDevice_DesktopSerial::getPort()
extern void UduinoDevice_DesktopSerial_getPort_m38C821A0392264AC1972ACFAACE21AAD0C33AE32 (void);
// 0x000001C2 System.Boolean Uduino.UduinoDevice_DesktopSerial::WriteToArduinoLoop()
extern void UduinoDevice_DesktopSerial_WriteToArduinoLoop_mD4D7D037B1E768A779FCD8B9E4ADEE8320BD1EE2 (void);
// 0x000001C3 System.String Uduino.UduinoDevice_DesktopSerial::ReadFromArduino(System.String,System.Boolean)
extern void UduinoDevice_DesktopSerial_ReadFromArduino_m98317BD9738F633B357ADF84208C10EBD79C1B20 (void);
// 0x000001C4 System.Boolean Uduino.UduinoDevice_DesktopSerial::ReadFromArduinoLoop(System.Boolean)
extern void UduinoDevice_DesktopSerial_ReadFromArduinoLoop_m3C77B1DF3480055084EAB1C671E2DEEE479B45DD (void);
// 0x000001C5 System.Void Uduino.UduinoDevice_DesktopSerial::Close()
extern void UduinoDevice_DesktopSerial_Close_m75546EA237F1023834DFA521126D2DAAEFB64D51 (void);
// 0x000001C6 System.Void Uduino.UduinoDevice_DesktopSerial::<WriteToArduinoLoop>b__11_0()
extern void UduinoDevice_DesktopSerial_U3CWriteToArduinoLoopU3Eb__11_0_mE2E9BB8B205474E4FF9228FD09340051EE5224FF (void);
// 0x000001C7 System.Void Uduino.UduinoDevice_DesktopSerial::<ReadFromArduinoLoop>b__13_0()
extern void UduinoDevice_DesktopSerial_U3CReadFromArduinoLoopU3Eb__13_0_m1212BC5509A7852CCDB1838EB2BA57C3E51735F0 (void);
// 0x000001C8 Uduino.UduinoConnection Uduino.UduinoConnection::GetFinder(Uduino.UduinoManager,Uduino.Platform,Uduino.ConnectionMethod)
extern void UduinoConnection_GetFinder_m7A68F659A2C18CE03272C49476BD1C906B12110E (void);
// 0x000001C9 System.Void Uduino.UduinoConnection::.ctor(Uduino.UduinoManager)
extern void UduinoConnection__ctor_mA6A76ED64840BBFAB6FDBB09C245ADAF043E8F48 (void);
// 0x000001CA System.Void Uduino.UduinoConnection::Setup()
extern void UduinoConnection_Setup_m491C77D595B97A13E2D9718D05898F840EE9F487 (void);
// 0x000001CB System.Void Uduino.UduinoConnection::FindBoards(Uduino.UduinoManager)
extern void UduinoConnection_FindBoards_m0BEB194CA06AE8D8101E8354ECAEA0276EB129B1 (void);
// 0x000001CC Uduino.UduinoDevice Uduino.UduinoConnection::OpenUduinoDevice(System.String)
extern void UduinoConnection_OpenUduinoDevice_m1AFC6D3C514081CEC7841B8C0EF2DD3AC261F862 (void);
// 0x000001CD System.Void Uduino.UduinoConnection::DetectUduino(Uduino.UduinoDevice)
extern void UduinoConnection_DetectUduino_mFD52D41058028D94D11F1993C6DB03CA84B767E0 (void);
// 0x000001CE System.Void Uduino.UduinoConnection::DetectUduinoThread(Uduino.UduinoDevice)
extern void UduinoConnection_DetectUduinoThread_m104FA649B9B53F555C4A6FC9C4C6FFBCAA519F74 (void);
// 0x000001CF System.Collections.IEnumerator Uduino.UduinoConnection::DetectUduinoCoroutine(Uduino.UduinoDevice)
extern void UduinoConnection_DetectUduinoCoroutine_m29582BCE6DAFE24540611E35AA6D73E315D1C167 (void);
// 0x000001D0 System.Boolean Uduino.UduinoConnection::TryToFind(Uduino.UduinoDevice,System.Boolean)
extern void UduinoConnection_TryToFind_m24508C52DA5CD7CE7C3C29D0BA91E804364A9450 (void);
// 0x000001D1 System.Boolean Uduino.UduinoConnection::BoardNotFound(Uduino.UduinoDevice)
extern void UduinoConnection_BoardNotFound_m8EF0C2B5F084757A70C0EFE0A6362CCE2416692D (void);
// 0x000001D2 System.Void Uduino.UduinoConnection::BoardFound(System.String)
extern void UduinoConnection_BoardFound_m98D24B7E4BD096C6856F17C43441E1344CA6C9BB (void);
// 0x000001D3 System.Void Uduino.UduinoConnection::ScanForDevices()
extern void UduinoConnection_ScanForDevices_m78888BD7C6E509594FC07C41DA1BDBAA54F6670E (void);
// 0x000001D4 System.Void Uduino.UduinoConnection::Discover()
extern void UduinoConnection_Discover_m183E13331894313A696154A857E86E77F01C25AE (void);
// 0x000001D5 System.Void Uduino.UduinoConnection::PluginReceived(System.String)
extern void UduinoConnection_PluginReceived_m25C11167B7A85D50B9807F0C4D03BE683C330F6B (void);
// 0x000001D6 System.Void Uduino.UduinoConnection::PluginWrite(System.String)
extern void UduinoConnection_PluginWrite_mEC6FA44E94D4A8009B67121AABD87E06DE5A3467 (void);
// 0x000001D7 System.Boolean Uduino.UduinoConnection::ConnectPeripheral(System.String,System.String)
extern void UduinoConnection_ConnectPeripheral_m2C64D26046AB4D2D4E7C13DDA24ECB0512D74EC4 (void);
// 0x000001D8 System.Boolean Uduino.UduinoConnection::Disconnect()
extern void UduinoConnection_Disconnect_m03E2B745C314F49CF576DC6E08F3261E59CB9CD8 (void);
// 0x000001D9 System.Void Uduino.UduinoConnection::Stop()
extern void UduinoConnection_Stop_m5D62E102422EFB77C9AD0D6B98883485622EF569 (void);
// 0x000001DA System.Void Uduino.UduinoConnection::CloseDevices()
extern void UduinoConnection_CloseDevices_m755B8EAE977BE9ED998368B7C20654F406246087 (void);
// 0x000001DB System.Void Uduino.UduinoConnection::CreateDebugCanvas()
extern void UduinoConnection_CreateDebugCanvas_mDDEB7113102110F2E31CA1D4093B4680C5FEBEBA (void);
// 0x000001DC System.Void Uduino.UduinoConnection/<>c__DisplayClass7_0::.ctor()
extern void U3CU3Ec__DisplayClass7_0__ctor_mF5925BB58A685C1E037E027424DB080805F70AF4 (void);
// 0x000001DD System.Void Uduino.UduinoConnection/<>c__DisplayClass7_0::<DetectUduino>b__0()
extern void U3CU3Ec__DisplayClass7_0_U3CDetectUduinoU3Eb__0_m72387E489B01B00B4823EE062316D16BD67EA86B (void);
// 0x000001DE System.Void Uduino.UduinoConnection/<DetectUduinoCoroutine>d__9::.ctor(System.Int32)
extern void U3CDetectUduinoCoroutineU3Ed__9__ctor_mA443818C937B9A70ED454B73D9961E4E78E509F8 (void);
// 0x000001DF System.Void Uduino.UduinoConnection/<DetectUduinoCoroutine>d__9::System.IDisposable.Dispose()
extern void U3CDetectUduinoCoroutineU3Ed__9_System_IDisposable_Dispose_mD6148DCAAC66247AC14EDFE29E029B68331755B9 (void);
// 0x000001E0 System.Boolean Uduino.UduinoConnection/<DetectUduinoCoroutine>d__9::MoveNext()
extern void U3CDetectUduinoCoroutineU3Ed__9_MoveNext_m2D125C2DF7FCA5869749299442F7B3BF42D1796B (void);
// 0x000001E1 System.Object Uduino.UduinoConnection/<DetectUduinoCoroutine>d__9::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CDetectUduinoCoroutineU3Ed__9_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m7AFE115A109A06E0D54D24BBC69E995B95B92045 (void);
// 0x000001E2 System.Void Uduino.UduinoConnection/<DetectUduinoCoroutine>d__9::System.Collections.IEnumerator.Reset()
extern void U3CDetectUduinoCoroutineU3Ed__9_System_Collections_IEnumerator_Reset_mC0DD27A0F9F747C62CA4D14F02AE00265F6659BE (void);
// 0x000001E3 System.Object Uduino.UduinoConnection/<DetectUduinoCoroutine>d__9::System.Collections.IEnumerator.get_Current()
extern void U3CDetectUduinoCoroutineU3Ed__9_System_Collections_IEnumerator_get_Current_m54DEE4971365617122CB2B51AA979B995B47ABCC (void);
// 0x000001E4 System.Void Uduino.UduinoConnection/<>c__DisplayClass10_0::.ctor()
extern void U3CU3Ec__DisplayClass10_0__ctor_mB1A6A80D0D838D6B8C711A6913098D501C3E08F6 (void);
// 0x000001E5 System.Void Uduino.UduinoConnection/<>c__DisplayClass10_0::<TryToFind>b__0()
extern void U3CU3Ec__DisplayClass10_0_U3CTryToFindU3Eb__0_m9FA9798293603E3D8DC5DE50DD2E52960086FDF9 (void);
// 0x000001E6 System.Void Uduino.UduinoDevice::add_OnBoardClosed(Uduino.UduinoDevice/OnBoardClosedEvent)
extern void UduinoDevice_add_OnBoardClosed_mC07D3936C9B2E33D425CFDA274545BB9A780AFDC (void);
// 0x000001E7 System.Void Uduino.UduinoDevice::remove_OnBoardClosed(Uduino.UduinoDevice/OnBoardClosedEvent)
extern void UduinoDevice_remove_OnBoardClosed_m8F8700B7387ED23068FA39CD088B9A9FCCFCEDA9 (void);
// 0x000001E8 System.Void Uduino.UduinoDevice::add_OnBoardFound(Uduino.UduinoDevice/OnBoardFoundEvent)
extern void UduinoDevice_add_OnBoardFound_mFD769490B80530AE0F6D05A0F18EFAF5F1CB455B (void);
// 0x000001E9 System.Void Uduino.UduinoDevice::remove_OnBoardFound(Uduino.UduinoDevice/OnBoardFoundEvent)
extern void UduinoDevice_remove_OnBoardFound_mC3F62FCB885BFD9BD57C5966A0D654D0C293833E (void);
// 0x000001EA Uduino.BoardStatus Uduino.UduinoDevice::getStatus()
extern void UduinoDevice_getStatus_m28FA6D70C3D7C532903929B07178F4311A731E4D (void);
// 0x000001EB System.String Uduino.UduinoDevice::getIdentity()
extern void UduinoDevice_getIdentity_mF3394683CBF93A4755CBD11A6A8337CAB53063E4 (void);
// 0x000001EC System.Void Uduino.UduinoDevice::setIdentity(System.String)
extern void UduinoDevice_setIdentity_m202A2BCE4F62359ABF1667661F5BD3ED7995BAE3 (void);
// 0x000001ED System.Void Uduino.UduinoDevice::.ctor(System.Int32)
extern void UduinoDevice__ctor_m2E4C2048367239D71D91D1629A58DFFB9C66CEC0 (void);
// 0x000001EE System.Void Uduino.UduinoDevice::Open()
extern void UduinoDevice_Open_mF08C9FDDFF396B076BFC43DB9463EE6D8F0AB005 (void);
// 0x000001EF System.Void Uduino.UduinoDevice::UduinoFound()
extern void UduinoDevice_UduinoFound_m5D5292AD1BF872F0E819B59ABE71AA0EF350BAB7 (void);
// 0x000001F0 System.Void Uduino.UduinoDevice::AddToBundle(System.String,System.String)
extern void UduinoDevice_AddToBundle_m48825EF05C36840AFA2FA7151D0EB18A277FD8D7 (void);
// 0x000001F1 System.Void Uduino.UduinoDevice::SendBundle(System.String)
extern void UduinoDevice_SendBundle_m09E680E9F78165DD30694A6DC4CB19EEC1B201D5 (void);
// 0x000001F2 System.Void Uduino.UduinoDevice::SendAllBundles()
extern void UduinoDevice_SendAllBundles_mAE0BC65CC9774BB5EE415A4038660B3DA7F2CBF3 (void);
// 0x000001F3 System.Boolean Uduino.UduinoDevice::WriteToArduino(System.String,System.Object,System.Boolean)
extern void UduinoDevice_WriteToArduino_m016FEA1332C488CFAB069C60D572E666113250D3 (void);
// 0x000001F4 System.Boolean Uduino.UduinoDevice::WriteToArduinoLoop()
extern void UduinoDevice_WriteToArduinoLoop_m9C704E562AD1BD186CF5677EEFB51A7450C8D0B3 (void);
// 0x000001F5 System.String Uduino.UduinoDevice::ReadFromArduino(System.String,System.Boolean)
extern void UduinoDevice_ReadFromArduino_m2FA92883E5D4AB2E4C80D552D0633CEB4E4BAD5F (void);
// 0x000001F6 System.Boolean Uduino.UduinoDevice::ReadFromArduinoLoop(System.Boolean)
extern void UduinoDevice_ReadFromArduinoLoop_mC3D44C903937A82D9370BE453EFA8062D88BA7F5 (void);
// 0x000001F7 System.Void Uduino.UduinoDevice::AddToArduinoReadQueue(System.String)
extern void UduinoDevice_AddToArduinoReadQueue_m787FCB08A0CF123AC9571ED29677CFAED1330AF2 (void);
// 0x000001F8 System.Boolean Uduino.UduinoDevice::AddToArduinoWriteQueue(System.String)
extern void UduinoDevice_AddToArduinoWriteQueue_m33B0DF75C6A8DDE20DC5B13ED41B713BBC8564C3 (void);
// 0x000001F9 System.Void Uduino.UduinoDevice::MessageReceived(System.String)
extern void UduinoDevice_MessageReceived_m728EF12D608238D5508981555D9F415D60C7A88C (void);
// 0x000001FA System.Void Uduino.UduinoDevice::WritingSuccess(System.String)
extern void UduinoDevice_WritingSuccess_m7040965EEC4851A13B5BA24F476C4DB4C739632C (void);
// 0x000001FB System.Void Uduino.UduinoDevice::ReadingSuccess(System.String)
extern void UduinoDevice_ReadingSuccess_m8EB45DDD803CF132D84E8C8F5FA88C4084B0C08E (void);
// 0x000001FC System.Void Uduino.UduinoDevice::Stopping()
extern void UduinoDevice_Stopping_m464418BF3AD5F99549A5ADDADFE3868E27C944D1 (void);
// 0x000001FD System.Void Uduino.UduinoDevice::Close()
extern void UduinoDevice_Close_m5EDD4A8F6A6F08B22E73A431EF1A819037750407 (void);
// 0x000001FE System.Void Uduino.UduinoDevice::OnDisable()
extern void UduinoDevice_OnDisable_m6FF3550DD8E24A6C19CFBFAFBE8F49FA9A5C5746 (void);
// 0x000001FF System.Void Uduino.UduinoDevice::ClearQueues()
extern void UduinoDevice_ClearQueues_mBADF66AC99C379A9E602E7222F4D3AFE4452A7ED (void);
// 0x00000200 System.Void Uduino.UduinoDevice::OnApplicationQuit()
extern void UduinoDevice_OnApplicationQuit_mE35928B65B9111770C8E70D1B3FCEE3A742ABAFF (void);
// 0x00000201 System.Void Uduino.UduinoDevice::IncrementFPS()
extern void UduinoDevice_IncrementFPS_mC29DC5D888C888457CC0742866ED2E396C8B6035 (void);
// 0x00000202 System.Void Uduino.UduinoDevice/OnBoardClosedEvent::.ctor(System.Object,System.IntPtr)
extern void OnBoardClosedEvent__ctor_mF59B98A5543CA8FF2E0ED4ED89648A48C094CF08 (void);
// 0x00000203 System.Void Uduino.UduinoDevice/OnBoardClosedEvent::Invoke()
extern void OnBoardClosedEvent_Invoke_mBF4439D7967499CCB4ABD111D3421F68B881A96C (void);
// 0x00000204 System.IAsyncResult Uduino.UduinoDevice/OnBoardClosedEvent::BeginInvoke(System.AsyncCallback,System.Object)
extern void OnBoardClosedEvent_BeginInvoke_m8258F475FAEC98B00E6657E17D461C7F158ED4A9 (void);
// 0x00000205 System.Void Uduino.UduinoDevice/OnBoardClosedEvent::EndInvoke(System.IAsyncResult)
extern void OnBoardClosedEvent_EndInvoke_m5DA4A55A6E9EF2F5423FB41DDE5303ADE733BBB2 (void);
// 0x00000206 System.Void Uduino.UduinoDevice/OnBoardFoundEvent::.ctor(System.Object,System.IntPtr)
extern void OnBoardFoundEvent__ctor_mB18FAD23C635DF6B1FCFBFDF4C36F4EEE2E064E3 (void);
// 0x00000207 System.Void Uduino.UduinoDevice/OnBoardFoundEvent::Invoke()
extern void OnBoardFoundEvent_Invoke_mEAB8ABCF77A661AAC95C7DEAF594278EB4E4D5EC (void);
// 0x00000208 System.IAsyncResult Uduino.UduinoDevice/OnBoardFoundEvent::BeginInvoke(System.AsyncCallback,System.Object)
extern void OnBoardFoundEvent_BeginInvoke_mDB4BAC865BD2C7BE416FF19AA912D5FF804E7406 (void);
// 0x00000209 System.Void Uduino.UduinoDevice/OnBoardFoundEvent::EndInvoke(System.IAsyncResult)
extern void OnBoardFoundEvent_EndInvoke_mC481AACC9E6672A83E538794E1AD46D956E94C0D (void);
// 0x0000020A System.Void Uduino.UduinoDevice/<>c__DisplayClass41_0::.ctor()
extern void U3CU3Ec__DisplayClass41_0__ctor_m782910647DED053F39BB6A1D8AFC17C4473FFB6E (void);
// 0x0000020B System.Void Uduino.UduinoDevice/<>c__DisplayClass41_0::<ReadingSuccess>b__0()
extern void U3CU3Ec__DisplayClass41_0_U3CReadingSuccessU3Eb__0_mD2992397DFB0E16543DADA68483F297AC36240BC (void);
// 0x0000020C Uduino.UduinoManager Uduino.Pin::get_Manager()
extern void Pin_get_Manager_m914F7AD632F7B9C0EED6E11110B4C2F0CB4CA1AA (void);
// 0x0000020D System.Void Uduino.Pin::set_Manager(Uduino.UduinoManager)
extern void Pin_set_Manager_m04D51CE19F9099065C768F7DA96FF78831C367E1 (void);
// 0x0000020E System.Void Uduino.Pin::.ctor(Uduino.UduinoDevice,System.Int32,Uduino.PinMode)
extern void Pin__ctor_mEEFC631D95FB17F0DF21552B1113F6450F78074C (void);
// 0x0000020F System.Void Uduino.Pin::Init(System.Boolean)
extern void Pin_Init_m99AC3EFBEBF1827AD5FBDC55EC2B1B3329584E1C (void);
// 0x00000210 System.Void Uduino.Pin::WriteReadMessage(System.String)
extern void Pin_WriteReadMessage_m75D95C3069EFC38FCEA50715EE6D3BB78E7CAFAE (void);
// 0x00000211 System.Boolean Uduino.Pin::WriteMessage(System.String,System.String)
extern void Pin_WriteMessage_m2672E2629C24A4F925D9DBDA3D7DD44D6AFCCCF8 (void);
// 0x00000212 System.Boolean Uduino.Pin::PinTargetExists(Uduino.UduinoDevice,System.Int32)
extern void Pin_PinTargetExists_mAD55094A030D2093D751AA98A5F254F4B6E1DB87 (void);
// 0x00000213 System.Void Uduino.Pin::OverridePinMode(Uduino.PinMode,System.Boolean)
extern void Pin_OverridePinMode_mE7801609FEC3CCCF923C80E331A9C13F8D781AD0 (void);
// 0x00000214 System.Void Uduino.Pin::ChangePinMode(Uduino.PinMode,System.String)
extern void Pin_ChangePinMode_mD06F1998C7455E8FCBE95A8E4F428E33BACD2F09 (void);
// 0x00000215 System.Int32 Uduino.Pin::SendRead(System.String,System.Action`1<System.String>,System.Boolean)
extern void Pin_SendRead_m935AB0498ED59874BF8B90332EF08A673D006313 (void);
// 0x00000216 System.Void Uduino.Pin::SendPinValue(System.Int32,System.String,System.String)
extern void Pin_SendPinValue_m047100B7E8BE59C845DE44D86B187A5142B30C07 (void);
// 0x00000217 System.Void Uduino.Pin::Destroy()
extern void Pin_Destroy_mCA0AD86D0495E5FB511D01611267687D56A0621B (void);
// 0x00000218 System.Void Uduino.Pin::Draw()
extern void Pin_Draw_m7E3598B8BCB4F6E46691603A52CE1F10DA3A5807 (void);
// 0x00000219 System.Int32 Uduino.Pin::ParseLastResults()
extern void Pin_ParseLastResults_m7CB086C926E4C2CEA9DCF191E7A044CFBBF6A469 (void);
// 0x0000021A System.Int32 Uduino.Pin::ParseIntValue(System.String)
extern void Pin_ParseIntValue_m72899F68638D8979496C829332E40439BD95BB2E (void);
// 0x0000021B System.Void Uduino.UduinoConnection_Wifi::.ctor()
extern void UduinoConnection_Wifi__ctor_mE9B48C178F58C16DA6D6121DEACC614F4AF13F0C (void);
// 0x0000021C System.Void Uduino.UduinoConnection_Wifi::FindBoards(Uduino.UduinoManager)
extern void UduinoConnection_Wifi_FindBoards_m0FB24E5C9A7D43879E23A1D5A9ABC10E6F0B00B2 (void);
// 0x0000021D System.Void Uduino.UduinoConnection_Wifi::Discover()
extern void UduinoConnection_Wifi_Discover_m135B5FF8B07467CF6EEF8841CC94C7AB2C872B83 (void);
// 0x0000021E System.Void Uduino.UduinoConnection_Wifi::Stop()
extern void UduinoConnection_Wifi_Stop_m26D53FC141B4D05ADB3E5E5AE4033FE3ABE7821A (void);
// 0x0000021F System.Void Uduino.UduinoDevice_Wifi::.ctor(Uduino.UduinoConnection_Wifi,Uduino.UduinoWiFiSettings)
extern void UduinoDevice_Wifi__ctor_mC597E948A2BBD705B5B03C2D00CBB32501A4FBA0 (void);
// 0x00000220 System.Void Uduino.UduinoDevice_Wifi::StartNetwork()
extern void UduinoDevice_Wifi_StartNetwork_m37FD82F2BC28F5A90192B1B95C1D09207AD23B8E (void);
// 0x00000221 System.Void Uduino.UduinoDevice_Wifi::UduinoFound()
extern void UduinoDevice_Wifi_UduinoFound_mF9A8F05852417C1E184F1A7A78206007620C06A3 (void);
// 0x00000222 System.Boolean Uduino.UduinoDevice_Wifi::WriteToArduinoLoop()
extern void UduinoDevice_Wifi_WriteToArduinoLoop_m2621948D4325DE94D40452EA0263D5F32D7A21DF (void);
// 0x00000223 System.String Uduino.UduinoDevice_Wifi::ReadFromArduino(System.String,System.Boolean)
extern void UduinoDevice_Wifi_ReadFromArduino_m8CFC3C7C38DBB1D747014D060951F77E144ADD56 (void);
// 0x00000224 System.Boolean Uduino.UduinoDevice_Wifi::ReadFromArduinoLoop(System.Boolean)
extern void UduinoDevice_Wifi_ReadFromArduinoLoop_mC321453D6936C551096BE4E79D5081C8BFE8FB05 (void);
// 0x00000225 System.Void Uduino.UduinoDevice_Wifi::Close()
extern void UduinoDevice_Wifi_Close_mAC441E50D2AF9404EF7544E4D3144621441D8B8B (void);
// 0x00000226 System.Void Uduino.BLEDeviceButton_Interface::.ctor(UnityEngine.UI.Button)
extern void BLEDeviceButton_Interface__ctor_mC5E05340CF037447D582C8C76F03060ED1D76B45 (void);
// 0x00000227 System.Void Uduino.BLEDeviceButton_Interface::CanConnect()
extern void BLEDeviceButton_Interface_CanConnect_m1ABE407F0FC067834329CD82C95B9D29E127F3D7 (void);
// 0x00000228 System.Void Uduino.BLEDeviceButton_Interface::Connecting()
extern void BLEDeviceButton_Interface_Connecting_m03DF234C57A810DF5F76A0F7AD5289F561813326 (void);
// 0x00000229 System.Void Uduino.BLEDeviceButton_Interface::Connected()
extern void BLEDeviceButton_Interface_Connected_mF8DA5ACCFDF42EF0DA235FC63BD04CB8DC886201 (void);
// 0x0000022A System.Void Uduino.BLEDeviceButton_Interface::Disconnected()
extern void BLEDeviceButton_Interface_Disconnected_m742B191DF6C7C0F85DC04EB39184AE30C42F332A (void);
// 0x0000022B System.Void Uduino.UduinoInterface_Bluetooth::Awake()
extern void UduinoInterface_Bluetooth_Awake_m1FB4FF2149285E2E1A37F420708A655BE909E9F6 (void);
// 0x0000022C System.Void Uduino.UduinoInterface_Bluetooth::Read()
extern void UduinoInterface_Bluetooth_Read_m8B5986423984A7F2C78E58B3AED612B6D9ACB032 (void);
// 0x0000022D System.Void Uduino.UduinoInterface_Bluetooth::SendValue()
extern void UduinoInterface_Bluetooth_SendValue_m13CC100B01E1651BD92492FF15C92C8D61817C3D (void);
// 0x0000022E System.Void Uduino.UduinoInterface_Bluetooth::LastReceviedValue(System.String)
extern void UduinoInterface_Bluetooth_LastReceviedValue_mDB3AA5B490301346601C31176103A0488FF2CE2C (void);
// 0x0000022F System.Void Uduino.UduinoInterface_Bluetooth::SearchDevices()
extern void UduinoInterface_Bluetooth_SearchDevices_m3ED98BAFA3AFE1F5650B6BA3971081EEB1F2BE77 (void);
// 0x00000230 System.Void Uduino.UduinoInterface_Bluetooth::StartSearching()
extern void UduinoInterface_Bluetooth_StartSearching_mBEE5AE887F79B1DEB620FE7DABEB09FFD79D8C83 (void);
// 0x00000231 System.Void Uduino.UduinoInterface_Bluetooth::StopSearching()
extern void UduinoInterface_Bluetooth_StopSearching_mBBC209A2313A0DEA9F394BE888AD6DC15FACCBB7 (void);
// 0x00000232 System.Void Uduino.UduinoInterface_Bluetooth::StartTimer()
extern void UduinoInterface_Bluetooth_StartTimer_mEC2598FFC8255FCAE246E7CECA53FC1789582586 (void);
// 0x00000233 System.Collections.IEnumerator Uduino.UduinoInterface_Bluetooth::StartSliderCountdown()
extern void UduinoInterface_Bluetooth_StartSliderCountdown_mF3C9F748761435E40F4647326ECAA25A13FDED21 (void);
// 0x00000234 System.Void Uduino.UduinoInterface_Bluetooth::SendCommand(System.String)
extern void UduinoInterface_Bluetooth_SendCommand_m28D2BED603E6D95DA06FF4120768C5946012D966 (void);
// 0x00000235 System.Void Uduino.UduinoInterface_Bluetooth::StopTimer()
extern void UduinoInterface_Bluetooth_StopTimer_m72134CBCB34D923214E4EB6F75CDC7EFDAD1E862 (void);
// 0x00000236 System.Void Uduino.UduinoInterface_Bluetooth::ClearPanel()
extern void UduinoInterface_Bluetooth_ClearPanel_m56994F927ACB30B359C08392C8CBEBDDD2A01F51 (void);
// 0x00000237 System.Void Uduino.UduinoInterface_Bluetooth::AddDeviceButton(System.String,System.String)
extern void UduinoInterface_Bluetooth_AddDeviceButton_mACD2AF5D3AFFC5FCE2D5FDD6B4BA2E2740DECE1E (void);
// 0x00000238 System.Void Uduino.UduinoInterface_Bluetooth::DisplayDebugPanel(System.Boolean)
extern void UduinoInterface_Bluetooth_DisplayDebugPanel_m16678C94D08EAEEFE3DE0A0966F55CF76B0E45D5 (void);
// 0x00000239 System.Void Uduino.UduinoInterface_Bluetooth::UduinoConnecting(System.String)
extern void UduinoInterface_Bluetooth_UduinoConnecting_m95CFF3C2A87EEBD20D3FE96E2AC6687D2DEBA8AF (void);
// 0x0000023A System.Void Uduino.UduinoInterface_Bluetooth::UduinoConnected(System.String)
extern void UduinoInterface_Bluetooth_UduinoConnected_m2FBEE4DC3F2AEDFAD57D88ACC6AD432030C23F98 (void);
// 0x0000023B System.Void Uduino.UduinoInterface_Bluetooth::UduinoDisconnected(System.String)
extern void UduinoInterface_Bluetooth_UduinoDisconnected_m4359B844A05DCF00DB51E4AB8FE22DBA23C15309 (void);
// 0x0000023C System.Void Uduino.UduinoInterface_Bluetooth::.ctor()
extern void UduinoInterface_Bluetooth__ctor_mB05F94CF6AF34DA266752650977CEE997E655CED (void);
// 0x0000023D System.Void Uduino.UduinoInterface_Bluetooth/<StartSliderCountdown>d__9::.ctor(System.Int32)
extern void U3CStartSliderCountdownU3Ed__9__ctor_mA2D89F644F058BB836362DCBD1E6AD73CC16AEDA (void);
// 0x0000023E System.Void Uduino.UduinoInterface_Bluetooth/<StartSliderCountdown>d__9::System.IDisposable.Dispose()
extern void U3CStartSliderCountdownU3Ed__9_System_IDisposable_Dispose_mB6A95BF613E86EA8D65B8CDC31A83E5A35EA6968 (void);
// 0x0000023F System.Boolean Uduino.UduinoInterface_Bluetooth/<StartSliderCountdown>d__9::MoveNext()
extern void U3CStartSliderCountdownU3Ed__9_MoveNext_mBCCB8DDFA64B1C694BB38CB39ABFB9F3855BFDF6 (void);
// 0x00000240 System.Object Uduino.UduinoInterface_Bluetooth/<StartSliderCountdown>d__9::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CStartSliderCountdownU3Ed__9_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m54563A121C73BB5B708133EA9223409F8D989C6D (void);
// 0x00000241 System.Void Uduino.UduinoInterface_Bluetooth/<StartSliderCountdown>d__9::System.Collections.IEnumerator.Reset()
extern void U3CStartSliderCountdownU3Ed__9_System_Collections_IEnumerator_Reset_mFA72FE20071773788D13F63CA2345EBB479AC51C (void);
// 0x00000242 System.Object Uduino.UduinoInterface_Bluetooth/<StartSliderCountdown>d__9::System.Collections.IEnumerator.get_Current()
extern void U3CStartSliderCountdownU3Ed__9_System_Collections_IEnumerator_get_Current_m1B2FFE60BCFA93B50D08132239CE893206F548EF (void);
// 0x00000243 System.Void Uduino.UduinoInterface_Bluetooth/<>c__DisplayClass13_0::.ctor()
extern void U3CU3Ec__DisplayClass13_0__ctor_m9F0D2D522555E85A2CF13F496C0F4602693B96BA (void);
// 0x00000244 System.Void Uduino.UduinoInterface_Bluetooth/<>c__DisplayClass13_0::<AddDeviceButton>b__0()
extern void U3CU3Ec__DisplayClass13_0_U3CAddDeviceButtonU3Eb__0_m456F0C15EEEB10704B3267E125164E135D6AB592 (void);
// 0x00000245 System.Void Uduino.UduinoInterface_Bluetooth/<>c__DisplayClass13_0::<AddDeviceButton>b__1()
extern void U3CU3Ec__DisplayClass13_0_U3CAddDeviceButtonU3Eb__1_m11E7D32131A257D3552B26296AF09AA23B5F0DA7 (void);
// 0x00000246 Uduino.Interface Uduino.Interface::get_Instance()
extern void Interface_get_Instance_mB030474712C9EA79D35DB43B84EE2514C416BB89 (void);
// 0x00000247 System.Boolean Uduino.Interface::isActive()
extern void Interface_isActive_mA1B7E909AD6E324C74C8493C860190312904A457 (void);
// 0x00000248 System.Void Uduino.Interface::Create()
extern void Interface_Create_m8353137CD136FC294913A2E3F4CC980DA77B30E5 (void);
// 0x00000249 System.Void Uduino.Interface::SetConnection(Uduino.UduinoConnection)
extern void Interface_SetConnection_m40BA40E56B5B36FAB34F1D1FF014F93930918BE7 (void);
// 0x0000024A System.Void Uduino.Interface::AddDeviceButton(System.String,System.String)
extern void Interface_AddDeviceButton_m73FF1027728D4DED1EAA90E4B2BE556754C79E98 (void);
// 0x0000024B System.Void Uduino.Interface::SendCommand(System.String)
extern void Interface_SendCommand_m7092C52F038419F52C159888466C446B5CF4D21E (void);
// 0x0000024C System.Void Uduino.Interface::Read()
extern void Interface_Read_mA632EAD29DBA5FE79BFBF66DDEAEA5998A17ED39 (void);
// 0x0000024D System.Void Uduino.Interface::SendValue()
extern void Interface_SendValue_mCF115CA5446D75FFF4BD169E028783DAED64B668 (void);
// 0x0000024E System.Void Uduino.Interface::LastReceviedValue(System.String)
extern void Interface_LastReceviedValue_m115C0AB34451C7DC7004BFE5F9C5B263606FCC8F (void);
// 0x0000024F System.Void Uduino.Interface::StartSearching()
extern void Interface_StartSearching_mF9C1722F58425DFD47CB90BFE5D9CF364CB514A3 (void);
// 0x00000250 System.Void Uduino.Interface::StopSearching()
extern void Interface_StopSearching_mBF523CBD87F090E621982ACA8642F8C8EDA2DEA5 (void);
// 0x00000251 System.Void Uduino.Interface::NoDeviceFound(System.Boolean)
extern void Interface_NoDeviceFound_m4C563A35CA61D47A938B860B9799940B0EDBF037 (void);
// 0x00000252 System.Void Uduino.Interface::DisplayError(System.String)
extern void Interface_DisplayError_m669D1D7A91A94E198C8C83410B489DE1D4D33726 (void);
// 0x00000253 System.Void Uduino.Interface::DetectDevice()
extern void Interface_DetectDevice_m4896A600608D057FE22D66CCE5168E36A7268ED4 (void);
// 0x00000254 System.Void Uduino.Interface::BoardNotFound(System.String)
extern void Interface_BoardNotFound_m55EEF8B599834A6EFBAFA9D46764C9146AC21CFE (void);
// 0x00000255 System.Void Uduino.Interface::UduinoConnected(System.String)
extern void Interface_UduinoConnected_m67AF98268A38FA8D37B978FE6AAFBB0019BFB811 (void);
// 0x00000256 System.Void Uduino.Interface::DisconnectUduino(System.String)
extern void Interface_DisconnectUduino_mB36CD5E46FC8C7709012518B7D9183C7D5C11C4E (void);
// 0x00000257 System.Void Uduino.Interface::RemoveDeviceButton(System.String)
extern void Interface_RemoveDeviceButton_mC71A76591FE69414F204DC0664740573ECE956FF (void);
// 0x00000258 System.Void Uduino.Interface::UduinoDisconnected(System.String)
extern void Interface_UduinoDisconnected_m9AE2A4FDC0629DC0519684332808378F6EEF142D (void);
// 0x00000259 System.Void Uduino.Interface::UduinoConnecting(System.String)
extern void Interface_UduinoConnecting_m4EF9819347A54C6ED5F7B92CD20B385896C91A23 (void);
// 0x0000025A System.Void Uduino.Interface::.ctor()
extern void Interface__ctor_mB88C2E64B64131D822A44FEFCEF555E8E4B6383C (void);
// 0x0000025B System.Void Uduino.UduinoInterface::Awake()
extern void UduinoInterface_Awake_m3E66EF2BC4AB5FE0A766A1EE647A0C969DFF212B (void);
// 0x0000025C System.Void Uduino.UduinoInterface::Create()
extern void UduinoInterface_Create_m04D99772A8C02B587ADFE185F7C40BDD293907FF (void);
// 0x0000025D System.Void Uduino.UduinoInterface::OnAwake()
extern void UduinoInterface_OnAwake_m4ACCE60A807D5A56C25645B5F2D0783DD5639DA6 (void);
// 0x0000025E System.Void Uduino.UduinoInterface::SetConnection(Uduino.UduinoConnection)
extern void UduinoInterface_SetConnection_mB9DB0C47B5A23F738E9350CF82E45621617D214A (void);
// 0x0000025F System.Void Uduino.UduinoInterface::AddDeviceButton(System.String,System.String)
extern void UduinoInterface_AddDeviceButton_mD157DA1C8C0753636F256954C10C9EECFE7AC9EF (void);
// 0x00000260 System.Void Uduino.UduinoInterface::SendCommand(System.String)
extern void UduinoInterface_SendCommand_mB4D53D9674C4F2DDAC459DB212F7441BEC553ED6 (void);
// 0x00000261 System.Void Uduino.UduinoInterface::Read()
extern void UduinoInterface_Read_m5B11A171B6918BCEC438C299FE3382B2ADA1C6CD (void);
// 0x00000262 System.Void Uduino.UduinoInterface::SendValue()
extern void UduinoInterface_SendValue_mD0C48D91043413AF9946254EA0A1A2156E99A03D (void);
// 0x00000263 System.Void Uduino.UduinoInterface::LastReceviedValue(System.String)
extern void UduinoInterface_LastReceviedValue_mA474A73B66F8E3ED6AAA2D3F0F9D7E279FB58203 (void);
// 0x00000264 System.Void Uduino.UduinoInterface::StartSearching()
extern void UduinoInterface_StartSearching_m3303F5104CF8D17F7AD46B0F87D9B04A589CFFFA (void);
// 0x00000265 System.Void Uduino.UduinoInterface::StopSearching()
extern void UduinoInterface_StopSearching_mAB8667E60B7EFC0E656A3A2E7F606DDCB6A41CB3 (void);
// 0x00000266 UnityEngine.UI.Text Uduino.UduinoInterface::getScanButton()
extern void UduinoInterface_getScanButton_m6FD2DE247DA1341F7BC74E80B264442B30209B80 (void);
// 0x00000267 UnityEngine.UI.Slider Uduino.UduinoInterface::getScanSlider()
extern void UduinoInterface_getScanSlider_mC7F216BCC0B31907C596F836E82ABF2F6EE5ADFE (void);
// 0x00000268 UnityEngine.GameObject Uduino.UduinoInterface::getDeviceButtonPrefab()
extern void UduinoInterface_getDeviceButtonPrefab_mD5CC39BBC82A217056BDA511005E3BCBB95920D9 (void);
// 0x00000269 UnityEngine.Transform Uduino.UduinoInterface::getPanel()
extern void UduinoInterface_getPanel_mE0F191B222A708A01514FA85B17CD55B5C9964A0 (void);
// 0x0000026A UnityEngine.GameObject Uduino.UduinoInterface::getErrorPanel()
extern void UduinoInterface_getErrorPanel_m88CB20ACB6A2EC25FF4EA30F57E0A9525602DB51 (void);
// 0x0000026B UnityEngine.GameObject Uduino.UduinoInterface::getNotFound()
extern void UduinoInterface_getNotFound_mD689AA8391D930EE3BAC687DA9B7F2731F5E9BFE (void);
// 0x0000026C UnityEngine.GameObject Uduino.UduinoInterface::getBoardButton(System.String)
extern void UduinoInterface_getBoardButton_mC88FB36B87185E0E81216AB77748E4D6076CB183 (void);
// 0x0000026D System.Void Uduino.UduinoInterface::Detect()
extern void UduinoInterface_Detect_mB546CED720D6027F19B1E9FBF6D6E95B761A4B61 (void);
// 0x0000026E System.Void Uduino.UduinoInterface::NoDeviceFound(System.Boolean)
extern void UduinoInterface_NoDeviceFound_m943C8378747C86FAA36E3D266944957639B10E20 (void);
// 0x0000026F System.Void Uduino.UduinoInterface::DisplayError(System.String)
extern void UduinoInterface_DisplayError_m599C21D783B2BDB270FE91230E377B66CA2FF1AA (void);
// 0x00000270 System.Void Uduino.UduinoInterface::DetectDevice()
extern void UduinoInterface_DetectDevice_mD1F744C1A733841DBAC5BD90C712EBE38C229629 (void);
// 0x00000271 System.Void Uduino.UduinoInterface::BoardNotFound(System.String)
extern void UduinoInterface_BoardNotFound_m6320E1EFBABB3BA793F8D7E9316FC172F94FEA86 (void);
// 0x00000272 System.Void Uduino.UduinoInterface::DisconnectUduino(System.String)
extern void UduinoInterface_DisconnectUduino_m4D43E171A82017D942041AE663D042D4DF83F8C1 (void);
// 0x00000273 System.Void Uduino.UduinoInterface::RemoveDeviceButton(System.String)
extern void UduinoInterface_RemoveDeviceButton_m80F9421992F9BD84AAA3D311588807C7A1BFDC4D (void);
// 0x00000274 System.Void Uduino.UduinoInterface::UduinoConnected(System.String)
extern void UduinoInterface_UduinoConnected_mBA1D90DA75FBA342C3381B9BA2588F14FA0D6EEF (void);
// 0x00000275 System.Void Uduino.UduinoInterface::UduinoDisconnected(System.String)
extern void UduinoInterface_UduinoDisconnected_m7271437707957A66140F965E85470B1C7C722864 (void);
// 0x00000276 System.Void Uduino.UduinoInterface::UduinoConnecting(System.String)
extern void UduinoInterface_UduinoConnecting_mC578F3E1E54DCBAD773275B6CCAB51C71D0BC890 (void);
// 0x00000277 System.Void Uduino.UduinoInterface::Destroy()
extern void UduinoInterface_Destroy_m5D36E0EA79DA7678D5D28D2FC73777ED7699B7D3 (void);
// 0x00000278 System.Void Uduino.UduinoInterface::.ctor()
extern void UduinoInterface__ctor_m158FE32E9144C8F72D86D871A65485AB9B1101CE (void);
// 0x00000279 System.Void Uduino.UduinoInterface/<>c__DisplayClass21_0::.ctor()
extern void U3CU3Ec__DisplayClass21_0__ctor_m322D9620A502540F515169E55904A9B54DFB63BB (void);
// 0x0000027A System.Void Uduino.UduinoInterface/<>c__DisplayClass21_0::<AddDeviceButton>b__0()
extern void U3CU3Ec__DisplayClass21_0_U3CAddDeviceButtonU3Eb__0_m49952AEC14394DA9910DC0AAAB49C9A8E81D07E2 (void);
// 0x0000027B System.Void Uduino.UduinoInterface_Serial::.ctor()
extern void UduinoInterface_Serial__ctor_m82E04CEFE9B8C8913A39EF971206E09B0A9A4755 (void);
// 0x0000027C System.Void Uduino.UduinoInterface_Wifi::.ctor()
extern void UduinoInterface_Wifi__ctor_mD5C2A40F20D4FC4F0C17AB3C930BF5F3EDD37F30 (void);
// 0x0000027D System.Void Uduino.Log::.cctor()
extern void Log__cctor_m741BCF643E8D9A5A9BB117737AFD02D2E1AA32F3 (void);
// 0x0000027E System.Void Uduino.Log::Error(System.Object,System.Boolean)
extern void Log_Error_m7270ED487C93FC7DAF15CD055B556723842D79AD (void);
// 0x0000027F System.Void Uduino.Log::Warning(System.Object,System.Boolean)
extern void Log_Warning_m6DCB39FB55894577E86F5FF7E4DDC1A58C3A2DA8 (void);
// 0x00000280 System.Void Uduino.Log::Info(System.Object,System.Boolean)
extern void Log_Info_mE8402069B4FA317A825839914D6134CC7A6033FD (void);
// 0x00000281 System.String Uduino.Log::TrimStartString(System.String,System.Char[])
extern void Log_TrimStartString_m560B5441AF734D955E80FD0786F21D6EA639CDED (void);
// 0x00000282 System.Void Uduino.Log::Debug(System.Object,System.Boolean)
extern void Log_Debug_m0B3DA316003BD25A5F73A72C6850D23898E88969 (void);
// 0x00000283 System.Void Uduino.Log::SetLogLevel(Uduino.LogLevel)
extern void Log_SetLogLevel_mAFB681C6D7A7DD1C220E4D4C1B9BA0E67F8C566F (void);
// 0x00000284 System.String Uduino.Log::RemoveLineEndings(System.String)
extern void Log_RemoveLineEndings_mC6371D7922271844E0C9A516563092DD6256C4F2 (void);
// 0x00000285 System.Void Uduino.UduinoDebugCanvas::Awake()
extern void UduinoDebugCanvas_Awake_m88B667E00E636159E5A599C450A5E6316769D1DC (void);
// 0x00000286 System.Void Uduino.UduinoDebugCanvas::Log(System.String)
extern void UduinoDebugCanvas_Log_mA23A387CD5D87DF0463F39C5D7BD9F9A22861EBD (void);
// 0x00000287 System.Void Uduino.UduinoDebugCanvas::OnEnable()
extern void UduinoDebugCanvas_OnEnable_m1A7B3237AECDE1E93956BB6D6A73CF38C65764F4 (void);
// 0x00000288 System.Void Uduino.UduinoDebugCanvas::OnDisable()
extern void UduinoDebugCanvas_OnDisable_mC6904C6F6B731522DFC03F62BD5230D2E1466986 (void);
// 0x00000289 System.Void Uduino.UduinoDebugCanvas::Clear()
extern void UduinoDebugCanvas_Clear_m5B86206A019E6F0F0EC6EE5BBAEF8267B932B94C (void);
// 0x0000028A System.Void Uduino.UduinoDebugCanvas::HandleLog(System.String,System.String,UnityEngine.LogType)
extern void UduinoDebugCanvas_HandleLog_m63713D941E3390B5D56FB03038F93ADCDD41CBA4 (void);
// 0x0000028B System.Void Uduino.UduinoDebugCanvas::Update()
extern void UduinoDebugCanvas_Update_m53D68726CF09729923CE144A2FAAC07CA968F8A4 (void);
// 0x0000028C System.Void Uduino.UduinoDebugCanvas::CreateCanvasAndText()
extern void UduinoDebugCanvas_CreateCanvasAndText_mD4E52C8B6005CB91ADF068C59ACCAF22ED51A64F (void);
// 0x0000028D System.Void Uduino.UduinoDebugCanvas::.ctor()
extern void UduinoDebugCanvas__ctor_mAE2A3668FA4D96406E1243D2C1773831FE9C12A2 (void);
// 0x0000028E Uduino.UduinoManager Uduino.UduinoManager::get_Instance()
extern void UduinoManager_get_Instance_mD8DECC4584AC27B54BB0BE9ACA30ABC83873CF7C (void);
// 0x0000028F System.Void Uduino.UduinoManager::set_Instance(Uduino.UduinoManager)
extern void UduinoManager_set_Instance_m07D289D9529F7F64E864DCF0D7285BE6F1F014D9 (void);
// 0x00000290 System.Int32 Uduino.UduinoManager::get_BaudRate()
extern void UduinoManager_get_BaudRate_m8A7A459B4052548FBAC1F5D3747F84B9A0563181 (void);
// 0x00000291 System.Void Uduino.UduinoManager::set_BaudRate(System.Int32)
extern void UduinoManager_set_BaudRate_m33B086266FB37389709AEF425250470579CAF0C0 (void);
// 0x00000292 Uduino.HardwareReading Uduino.UduinoManager::get_ReadingMethod()
extern void UduinoManager_get_ReadingMethod_mB19297CB7D343FCE132C5C89D84D3F1DF9DC4A95 (void);
// 0x00000293 System.Void Uduino.UduinoManager::set_ReadingMethod(Uduino.HardwareReading)
extern void UduinoManager_set_ReadingMethod_m08EAD88E6B10581D04E2EF8E1F64A1DC2C45AFC2 (void);
// 0x00000294 System.Boolean Uduino.UduinoManager::get_LimitSendRate()
extern void UduinoManager_get_LimitSendRate_mBD4B166BF7BB3B558F13D7E330584A77809364F1 (void);
// 0x00000295 System.Void Uduino.UduinoManager::set_LimitSendRate(System.Boolean)
extern void UduinoManager_set_LimitSendRate_m6E5755B0C69731B3AC5921D0F26815A653E1E71C (void);
// 0x00000296 System.Int32 Uduino.UduinoManager::get_SendRateDelay()
extern void UduinoManager_get_SendRateDelay_m3D2CC5E2FFB6A543C22B18416AFC6BA790F2606F (void);
// 0x00000297 System.Void Uduino.UduinoManager::set_SendRateDelay(System.Int32)
extern void UduinoManager_set_SendRateDelay_mD5B224820AA2D38EA60CD54FC9CF2A23841085C7 (void);
// 0x00000298 System.Int32 Uduino.UduinoManager::get_DiscoverTries()
extern void UduinoManager_get_DiscoverTries_m0745BD271FD93146973C666BCEDF0B540709E4FE (void);
// 0x00000299 System.Void Uduino.UduinoManager::set_DiscoverTries(System.Int32)
extern void UduinoManager_set_DiscoverTries_m83F7AD3357AFDB0366E3AB342A76FC041B9DE5E2 (void);
// 0x0000029A System.Collections.Generic.List`1<System.String> Uduino.UduinoManager::get_BlackListedPorts()
extern void UduinoManager_get_BlackListedPorts_m2D813F30A2ACFF450C65E2EFEF9BBE406C9F306E (void);
// 0x0000029B System.Void Uduino.UduinoManager::set_BlackListedPorts(System.Collections.Generic.List`1<System.String>)
extern void UduinoManager_set_BlackListedPorts_m23C1146F015C6BF06895F56362969ADDB676942D (void);
// 0x0000029C System.Void Uduino.UduinoManager::add_OnValueReceived(Uduino.UduinoManager/OnValueReceivedDelegate)
extern void UduinoManager_add_OnValueReceived_m87B6DECE5E9435D3A64C3B398EFE7663091DA9B3 (void);
// 0x0000029D System.Void Uduino.UduinoManager::remove_OnValueReceived(Uduino.UduinoManager/OnValueReceivedDelegate)
extern void UduinoManager_remove_OnValueReceived_m036FB784DE28C096A1C29D0069B08333B9E3A43D (void);
// 0x0000029E System.Void Uduino.UduinoManager::add_OnDataReceived(Uduino.UduinoManager/OnDataReceivedDelegate)
extern void UduinoManager_add_OnDataReceived_mF970C5C20843C82CEC47EB06B28B7DC5E2C01BBE (void);
// 0x0000029F System.Void Uduino.UduinoManager::remove_OnDataReceived(Uduino.UduinoManager/OnDataReceivedDelegate)
extern void UduinoManager_remove_OnDataReceived_mC84D14C3C702A01BEBC85FF4DAFAC74B07546AFC (void);
// 0x000002A0 System.Void Uduino.UduinoManager::add_OnBoardConnected(Uduino.UduinoManager/OnBoardConnectedDelegate)
extern void UduinoManager_add_OnBoardConnected_mC364545DEEBF39CDCE5E1E5B78EBC26A8C47CD45 (void);
// 0x000002A1 System.Void Uduino.UduinoManager::remove_OnBoardConnected(Uduino.UduinoManager/OnBoardConnectedDelegate)
extern void UduinoManager_remove_OnBoardConnected_mCBC904D2DC82A30D676E52C8751BD8235BD16B59 (void);
// 0x000002A2 System.Void Uduino.UduinoManager::add_OnBoardDisconnected(Uduino.UduinoManager/OnBoardDisconnectedDelegate)
extern void UduinoManager_add_OnBoardDisconnected_mBD59BEB776DF95AF83DC432D42BEF6C1ADA0689F (void);
// 0x000002A3 System.Void Uduino.UduinoManager::remove_OnBoardDisconnected(Uduino.UduinoManager/OnBoardDisconnectedDelegate)
extern void UduinoManager_remove_OnBoardDisconnected_m19A1B0EA3CDADBBB3FEBE245ECFFAEC49B8B0DB9 (void);
// 0x000002A4 System.Collections.Generic.List`1<Uduino.UduinoWiFiSettings> Uduino.UduinoManager::get_UduinoWiFiBoards()
extern void UduinoManager_get_UduinoWiFiBoards_m8AD29D2F40B762428AAD0FE082E43224DFC93508 (void);
// 0x000002A5 System.Void Uduino.UduinoManager::set_UduinoWiFiBoards(System.Collections.Generic.List`1<Uduino.UduinoWiFiSettings>)
extern void UduinoManager_set_UduinoWiFiBoards_mAA260D117267FC7CC354180CAEB2AF78CEFCBB2F (void);
// 0x000002A6 System.Void Uduino.UduinoManager::Awake()
extern void UduinoManager_Awake_m1C282CAFF2DB0A5E4EF4966BD0CEC0E998DAA619 (void);
// 0x000002A7 System.Void Uduino.UduinoManager::DiscoverWithDelay(System.Single)
extern void UduinoManager_DiscoverWithDelay_m7ED72FB1901947151F9223758DA35772C68FD99C (void);
// 0x000002A8 System.Collections.IEnumerator Uduino.UduinoManager::DelayedDiscover(System.Single)
extern void UduinoManager_DelayedDiscover_m689190128AE4D3D8E93574A0AFF98569240B6965 (void);
// 0x000002A9 System.Collections.IEnumerator Uduino.UduinoManager::RestartIfBoardNotDetected()
extern void UduinoManager_RestartIfBoardNotDetected_mF9F89FE0CFBDA9F9E0774A2C3BD06C69ED034BF0 (void);
// 0x000002AA System.Void Uduino.UduinoManager::UpdateManagerState()
extern void UduinoManager_UpdateManagerState_m5355B753FEBB4D263B9900622B272F8DE4733741 (void);
// 0x000002AB System.Void Uduino.UduinoManager::DiscoverPorts()
extern void UduinoManager_DiscoverPorts_m32DCFD6E0F083B859E82151A207A1B533180BF65 (void);
// 0x000002AC System.Void Uduino.UduinoManager::AddUduinoBoard(System.String,Uduino.UduinoDevice)
extern void UduinoManager_AddUduinoBoard_mAD0B94FD86C1A5FE707A16DD0CA62122A7E99215 (void);
// 0x000002AD System.Void Uduino.UduinoManager::GetPortState()
extern void UduinoManager_GetPortState_mB5E89A7315A7F27714054327BFC8D6253CC80ABE (void);
// 0x000002AE System.Boolean Uduino.UduinoManager::hasBoardConnected()
extern void UduinoManager_hasBoardConnected_mAAC5C51F9D2FE4132F4DEF621B2E30E4C4381556 (void);
// 0x000002AF System.Boolean Uduino.UduinoManager::GetBoard(System.String,Uduino.UduinoDevice[]&)
extern void UduinoManager_GetBoard_m79306B9471177C8B5943212377D7DE757F547062 (void);
// 0x000002B0 Uduino.UduinoDevice[] Uduino.UduinoManager::GetAllBoard()
extern void UduinoManager_GetAllBoard_m8140F72B762381E616F465566BCEAB39BA5569BB (void);
// 0x000002B1 System.Boolean Uduino.UduinoManager::GetBoard(Uduino.UduinoDevice,Uduino.UduinoDevice[]&)
extern void UduinoManager_GetBoard_m5CDE64DAE91BECD8E84E2202E2F5774F20CF8765 (void);
// 0x000002B2 Uduino.UduinoDevice Uduino.UduinoManager::GetBoard(System.String)
extern void UduinoManager_GetBoard_mD20418B8C26BEF956308F0DC1634AD3EE5C191E7 (void);
// 0x000002B3 System.Boolean Uduino.UduinoManager::UduinoTargetExists(System.String)
extern void UduinoManager_UduinoTargetExists_mE8D18D75E9C980FEF5A2E1F9B997A23723C4D899 (void);
// 0x000002B4 System.Boolean Uduino.UduinoManager::UduinoTargetExists(Uduino.UduinoDevice)
extern void UduinoManager_UduinoTargetExists_mE4824DFA8752C227F10078AA80F77F13702262DD (void);
// 0x000002B5 System.Void Uduino.UduinoManager::SetBoardType(System.String)
extern void UduinoManager_SetBoardType_m391C7F1B36D0552CC0B966852C793B5BB61AE8F6 (void);
// 0x000002B6 System.Void Uduino.UduinoManager::SetBoardType(Uduino.UduinoDevice,System.String)
extern void UduinoManager_SetBoardType_m100B8ACC231654ADB9D3CC0A9E192C1647CD3410 (void);
// 0x000002B7 System.Void Uduino.UduinoManager::SetBoardType(Uduino.UduinoDevice,System.Int32)
extern void UduinoManager_SetBoardType_m8DA735585D961E7195983D0ED56FAADE3872ADE8 (void);
// 0x000002B8 System.Int32 Uduino.UduinoManager::GetPinNumberFromBoardType(System.String,System.String)
extern void UduinoManager_GetPinNumberFromBoardType_m330FD92CDF69CC8492A9C92DE5E3AFDC3D916C0E (void);
// 0x000002B9 System.Int32 Uduino.UduinoManager::GetPinNumberFromBoardType(System.String,System.Int32)
extern void UduinoManager_GetPinNumberFromBoardType_m93A332E7383DAFA5757FFA76EE0D6303371ECB53 (void);
// 0x000002BA System.Int32 Uduino.UduinoManager::GetPinFromBoard(System.String)
extern void UduinoManager_GetPinFromBoard_m7382C9C13DDD42FB5BE68261E8B7853951EA60DB (void);
// 0x000002BB System.Int32 Uduino.UduinoManager::GetPinFromBoard(System.Int32)
extern void UduinoManager_GetPinFromBoard_mA5D7CD24C3BA158499E7B94E742D6F0077E6DB3B (void);
// 0x000002BC System.Boolean Uduino.UduinoManager::isConnected()
extern void UduinoManager_isConnected_mF5905E1346E536D5BE5FC942284E499EF795754A (void);
// 0x000002BD System.Void Uduino.UduinoManager::pinMode(System.Int32,Uduino.PinMode)
extern void UduinoManager_pinMode_m4F92F3E359AB3D17DB12828BDFA14325A1D5C842 (void);
// 0x000002BE System.Void Uduino.UduinoManager::pinMode(Uduino.AnalogPin,Uduino.PinMode)
extern void UduinoManager_pinMode_mCA441C2CA751DF84A3C06C5C7519BB6DBD68EB2D (void);
// 0x000002BF System.Void Uduino.UduinoManager::pinMode(Uduino.UduinoDevice,Uduino.AnalogPin,Uduino.PinMode)
extern void UduinoManager_pinMode_mD950E7FA527D1942A817759F6384B2D12DC6B7F3 (void);
// 0x000002C0 System.Void Uduino.UduinoManager::pinMode(Uduino.UduinoDevice,System.Int32,Uduino.PinMode)
extern void UduinoManager_pinMode_m954B30A7D27E02B219FCA058392CBC00A50C67E4 (void);
// 0x000002C1 System.Int32 Uduino.UduinoManager::PinValueToBoardValue(Uduino.AnalogPin,System.Int32)
extern void UduinoManager_PinValueToBoardValue_mA5915AEB02B0B74CC133F991CAA926A04B070DF8 (void);
// 0x000002C2 System.Void Uduino.UduinoManager::InitPin(System.Int32,Uduino.PinMode)
extern void UduinoManager_InitPin_m468E8629D0CD83F3BD028F678DCFB502D8F3DBF9 (void);
// 0x000002C3 System.Void Uduino.UduinoManager::InitPin(Uduino.AnalogPin,Uduino.PinMode)
extern void UduinoManager_InitPin_mDD6D048E7513F3A53B2878F9B08CE8A06DEFD508 (void);
// 0x000002C4 System.Void Uduino.UduinoManager::InitPin(Uduino.UduinoDevice,System.Int32,Uduino.PinMode)
extern void UduinoManager_InitPin_mECF0C90297C718F2DF2CF869C15249AF7DD23C5B (void);
// 0x000002C5 System.Void Uduino.UduinoManager::InitPin(System.String,Uduino.AnalogPin,Uduino.PinMode)
extern void UduinoManager_InitPin_mAE19E9F602BF7FE88CC83F6278C9C4C6A8FF6546 (void);
// 0x000002C6 System.Void Uduino.UduinoManager::InitAllPins()
extern void UduinoManager_InitAllPins_m6EBAEB38BF1F96D0D7E739343CD23B16D2E6D2F7 (void);
// 0x000002C7 System.Void Uduino.UduinoManager::InitAllArduinos()
extern void UduinoManager_InitAllArduinos_mF1A765604E6B52A929A243D06FBCDA4371B6A806 (void);
// 0x000002C8 System.Void Uduino.UduinoManager::InitAllCallbacks()
extern void UduinoManager_InitAllCallbacks_mD7C02C4037130151CEA5D6673CF95AEA966111E5 (void);
// 0x000002C9 System.Void Uduino.UduinoManager::arduinoWrite(Uduino.UduinoDevice,System.Int32,System.Int32,System.String,System.String)
extern void UduinoManager_arduinoWrite_m139A48E1A16FC3A84142C92AAF3305A745A2BD93 (void);
// 0x000002CA System.Void Uduino.UduinoManager::digitalWrite(Uduino.UduinoDevice,System.Int32,System.Int32,System.String)
extern void UduinoManager_digitalWrite_m529836DAEB7886854531EA84F2C6F5CB6A76CBCB (void);
// 0x000002CB System.Void Uduino.UduinoManager::digitalWrite(System.Int32,System.Int32,System.String)
extern void UduinoManager_digitalWrite_m98C76698A8F5FFD78A0B899FE135C7A74581D54A (void);
// 0x000002CC System.Void Uduino.UduinoManager::digitalWrite(System.Int32,Uduino.State,System.String)
extern void UduinoManager_digitalWrite_mEB5AAF0AE3EB8CAEBA2856A0C4FC0CE937D82359 (void);
// 0x000002CD System.Void Uduino.UduinoManager::digitalWrite(Uduino.UduinoDevice,System.Int32,Uduino.State,System.String)
extern void UduinoManager_digitalWrite_mA3FF63B71873294FE91595C89EBA472DD2974668 (void);
// 0x000002CE System.Void Uduino.UduinoManager::analogWrite(System.Int32,System.Int32,System.String)
extern void UduinoManager_analogWrite_mE6D68AE27E09A3545D96FF077D95184C4530269C (void);
// 0x000002CF System.Void Uduino.UduinoManager::analogWrite(Uduino.UduinoDevice,System.Int32,System.Int32,System.String)
extern void UduinoManager_analogWrite_m9A9BB3EAFF4D6DE2D95680A5972DDFCCDDCA8285 (void);
// 0x000002D0 System.Int32 Uduino.UduinoManager::digitalRead(Uduino.UduinoDevice,System.Int32,System.String)
extern void UduinoManager_digitalRead_m4949DF563F731EF497E4594F06670EF23835F13B (void);
// 0x000002D1 System.Int32 Uduino.UduinoManager::digitalRead(System.Int32,System.String)
extern void UduinoManager_digitalRead_m1720191426905756F368F6752089889F8579B600 (void);
// 0x000002D2 System.Int32 Uduino.UduinoManager::digitalRead(Uduino.AnalogPin,System.String)
extern void UduinoManager_digitalRead_mC49875D6030D27CDACE6837A4F18114421ADA937 (void);
// 0x000002D3 System.Int32 Uduino.UduinoManager::digitalRead(Uduino.UduinoDevice,Uduino.AnalogPin,System.String)
extern void UduinoManager_digitalRead_m07409773D153E03A7AC2AD6AFA27DE71D57AEE54 (void);
// 0x000002D4 System.Int32 Uduino.UduinoManager::analogRead(Uduino.UduinoDevice,System.Int32,System.String)
extern void UduinoManager_analogRead_m4EF12F5600ABA034344F7E1F514211B1EEDCC0F4 (void);
// 0x000002D5 System.Int32 Uduino.UduinoManager::analogRead(Uduino.UduinoDevice,Uduino.AnalogPin,System.String)
extern void UduinoManager_analogRead_m0AFBEE34347272E0E9839E12660EA675FE04F290 (void);
// 0x000002D6 System.Int32 Uduino.UduinoManager::analogRead(System.Int32,System.String)
extern void UduinoManager_analogRead_mAF749A5A5C5EAB7568057D15B80B10178982BC53 (void);
// 0x000002D7 System.Int32 Uduino.UduinoManager::analogRead(Uduino.AnalogPin,System.String)
extern void UduinoManager_analogRead_mBAC10662BAF552EF6B8E9252C18B0AA86E84BE78 (void);
// 0x000002D8 System.Int32 Uduino.UduinoManager::dispatchValueForPin(Uduino.UduinoDevice,System.Int32,System.Int32)
extern void UduinoManager_dispatchValueForPin_mCF9C7154F6B4DE415D14891C68D82C56E425F178 (void);
// 0x000002D9 System.String Uduino.UduinoManager::Read(Uduino.UduinoDevice,System.String,System.Action`1<System.String>,System.String)
extern void UduinoManager_Read_mFC6F8AA31F92151ED6C9DD26544DF042446D938C (void);
// 0x000002DA System.String Uduino.UduinoManager::Read(System.String,System.Action`1<System.String>,System.String)
extern void UduinoManager_Read_m96DFCF5D555F7350D455C872B0F70DBDBFAA311A (void);
// 0x000002DB System.String Uduino.UduinoManager::DirectReadFromArduino(Uduino.UduinoDevice,System.String,System.Action`1<System.String>,System.String)
extern void UduinoManager_DirectReadFromArduino_m326966EDE30233F529F5E9445C85A24E78E524F6 (void);
// 0x000002DC System.Void Uduino.UduinoManager::Read(System.Int32,System.String,System.Action`1<System.String>)
extern void UduinoManager_Read_mFF9BC9579DBF02A3CC78AA488B0F7A72E74ADC6A (void);
// 0x000002DD System.Void Uduino.UduinoManager::Read(System.Int32,System.Action`1<System.String>)
extern void UduinoManager_Read_mF2032C5BEA7B695D0E3B8858E416A5DC3B076F42 (void);
// 0x000002DE System.Boolean Uduino.UduinoManager::sendCommand(Uduino.UduinoDevice,System.String,System.String)
extern void UduinoManager_sendCommand_m488382E83AA091FAEA3E33F31819C36739419C8C (void);
// 0x000002DF System.Void Uduino.UduinoManager::sendCommand(System.String,System.Object[])
extern void UduinoManager_sendCommand_mE6736FB202B38232C418B41EA3D1AF6A1AF39F96 (void);
// 0x000002E0 System.Void Uduino.UduinoManager::sendCommand(Uduino.UduinoDevice,System.String,System.Object[])
extern void UduinoManager_sendCommand_m102DDD91C2310B54DFF5E98CF3A1AD7C8B27BE59 (void);
// 0x000002E1 System.Void Uduino.UduinoManager::Write(System.String,System.String,System.Object[])
extern void UduinoManager_Write_m2D8FD69772570B0DEFD3BA086874338EB7941551 (void);
// 0x000002E2 System.Void Uduino.UduinoManager::Write(System.String,System.String,System.String)
extern void UduinoManager_Write_m23E3BFF9BE82448BB19C9C27AC95F1EBFFAC06E0 (void);
// 0x000002E3 System.String Uduino.UduinoManager::BuildMessageParameters(System.Object[])
extern void UduinoManager_BuildMessageParameters_mEC6BEF98C679579E190352948285EC0C0ECBCF84 (void);
// 0x000002E4 System.Void Uduino.UduinoManager::SetReadCallback(Uduino.UduinoDevice,System.Action`1<System.String>)
extern void UduinoManager_SetReadCallback_m5CD59885FA8DF1C2FE7CB12DACDD9FF507D6C693 (void);
// 0x000002E5 System.Void Uduino.UduinoManager::SetReadCallback(System.Action`1<System.String>)
extern void UduinoManager_SetReadCallback_mA85C33A227DE88CB7668DAA108EC289C78F90C9B (void);
// 0x000002E6 System.Void Uduino.UduinoManager::SendBundle(Uduino.UduinoDevice,System.String)
extern void UduinoManager_SendBundle_m08D2163304F16F9BB79B842C6445A930D3420D11 (void);
// 0x000002E7 System.Void Uduino.UduinoManager::SendBundle(System.String)
extern void UduinoManager_SendBundle_m44087F083729C719A6368283A528E103D8902AC5 (void);
// 0x000002E8 System.Collections.IEnumerator Uduino.UduinoManager::AutoSendBundle()
extern void UduinoManager_AutoSendBundle_mA51BC80C61A3AAD1AB400B0B82AF6994B39A0CBF (void);
// 0x000002E9 System.Void Uduino.UduinoManager::AlwaysRead(System.String,System.Action`1<System.String>)
extern void UduinoManager_AlwaysRead_m9C7E1C15CB2DF529A68E7BAC402F2510CFB2DE1D (void);
// 0x000002EA System.Void Uduino.UduinoManager::AlwaysRead(System.String)
extern void UduinoManager_AlwaysRead_mFFF8259DDB890300486FFA93F3093D6B7819E914 (void);
// 0x000002EB System.Boolean Uduino.UduinoManager::ExtensionIsPresentAndActive(System.String)
extern void UduinoManager_ExtensionIsPresentAndActive_m6020EB1547D1C8F156C2AFED71BB24ADCF963475 (void);
// 0x000002EC System.Boolean Uduino.UduinoManager::ExtensionIsPresent(System.String)
extern void UduinoManager_ExtensionIsPresent_m48FD6B61C17A5C03E0000E5C3798736ECC317798 (void);
// 0x000002ED System.Void Uduino.UduinoManager::StartReading(Uduino.UduinoDevice)
extern void UduinoManager_StartReading_m9A1F61FEC1A62283C894339762B2C6E17E58FAD6 (void);
// 0x000002EE System.Void Uduino.UduinoManager::StartThread(System.Boolean)
extern void UduinoManager_StartThread_mC32B06EEB8CA3F57E6CB69860EF6DE64EB7FFBC2 (void);
// 0x000002EF System.Void Uduino.UduinoManager::StopThread()
extern void UduinoManager_StopThread_m2932B0697D8F7BD04202CDC14333B2066F692C91 (void);
// 0x000002F0 System.Boolean Uduino.UduinoManager::IsRunning()
extern void UduinoManager_IsRunning_m05261CF3CBCF190F3325333FA4D5C321B83F10AF (void);
// 0x000002F1 System.Void Uduino.UduinoManager::Update()
extern void UduinoManager_Update_m69307829E896B7C37C297DA39C29FECDE0F31495 (void);
// 0x000002F2 System.Void Uduino.UduinoManager::ReadPorts()
extern void UduinoManager_ReadPorts_mA774AF4B36D6AE963E7F86A355D43EC7C15CFDB8 (void);
// 0x000002F3 System.Void Uduino.UduinoManager::ReadWriteArduino(Uduino.UduinoDevice)
extern void UduinoManager_ReadWriteArduino_m43E6D13CC7332B6E100F582A41537D6BE766D0DB (void);
// 0x000002F4 System.Collections.IEnumerator Uduino.UduinoManager::CoroutineRead(Uduino.UduinoDevice)
extern void UduinoManager_CoroutineRead_mA7FF57228C45FC49EB873151654259452D3B757E (void);
// 0x000002F5 System.Void Uduino.UduinoManager::TriggerEvent(System.String,Uduino.UduinoDevice)
extern void UduinoManager_TriggerEvent_m7E3AC2AB6AF3260333027BFDC72908681EDFF341 (void);
// 0x000002F6 System.Void Uduino.UduinoManager::InvokeAsync(System.Action)
extern void UduinoManager_InvokeAsync_m43F222CBD87FF326BA8A0725394C795527659AEB (void);
// 0x000002F7 System.Void Uduino.UduinoManager::CloseAllPorts()
extern void UduinoManager_CloseAllPorts_mCACD844A6BFA39FA1E28FB353055EAB7381B2B7B (void);
// 0x000002F8 System.Void Uduino.UduinoManager::CloseAllDevices()
extern void UduinoManager_CloseAllDevices_m5E176430F0908AAB2E609D296B10982C1112FAE8 (void);
// 0x000002F9 System.Void Uduino.UduinoManager::CloseDevice(System.String)
extern void UduinoManager_CloseDevice_m4F5C14A5FF222D313D28F7A5EB05EA16C7546CF1 (void);
// 0x000002FA System.Void Uduino.UduinoManager::CloseDevice(Uduino.UduinoDevice)
extern void UduinoManager_CloseDevice_mE3CDD8284077A792BDD39FBC375A691803B344AA (void);
// 0x000002FB System.Void Uduino.UduinoManager::OnApplicationQuit()
extern void UduinoManager_OnApplicationQuit_mCBADFF42F24C1804854904CBAA252A4D4F72E178 (void);
// 0x000002FC System.Void Uduino.UduinoManager::OnDestroy()
extern void UduinoManager_OnDestroy_m44BFA61CE4234167D447E352A2388A4FC411136F (void);
// 0x000002FD System.Void Uduino.UduinoManager::OnDisable()
extern void UduinoManager_OnDisable_mEDAA3D2DB120F09A7E2CFED97843F4F6CDF45FA6 (void);
// 0x000002FE System.Void Uduino.UduinoManager::FullReset()
extern void UduinoManager_FullReset_m2A538BFA089324D9A8B46265D254AFF9067856F3 (void);
// 0x000002FF System.Void Uduino.UduinoManager::DisableThread()
extern void UduinoManager_DisableThread_mEC708E811500DF7AD3A20020D54A426502ABE642 (void);
// 0x00000300 System.Void Uduino.UduinoManager::.ctor()
extern void UduinoManager__ctor_m8D8933D6FA6B5D751F9183048A6F87EF338A4D24 (void);
// 0x00000301 System.Void Uduino.UduinoManager::.cctor()
extern void UduinoManager__cctor_m81960A934FA3119D975F45D540E8C3DA3A06DA50 (void);
// 0x00000302 System.Void Uduino.UduinoManager/BoardAlreadyExistException::.ctor(System.String)
extern void BoardAlreadyExistException__ctor_m666F892055104ECAA15394D08BB56F11D73DE8A6 (void);
// 0x00000303 System.Void Uduino.UduinoManager/eventValueReceived::.ctor()
extern void eventValueReceived__ctor_m676C2EBB7C7C190B041EE18ED18A5B75FFC4F90A (void);
// 0x00000304 System.Void Uduino.UduinoManager/eventBoard::.ctor()
extern void eventBoard__ctor_m7127F7C0E5A74EFEB7BDA8434208D0373D95C21E (void);
// 0x00000305 System.Void Uduino.UduinoManager/OnValueReceivedDelegate::.ctor(System.Object,System.IntPtr)
extern void OnValueReceivedDelegate__ctor_mEB84C72B2B62F410C144B0AE44C31BEC7201B57D (void);
// 0x00000306 System.Void Uduino.UduinoManager/OnValueReceivedDelegate::Invoke(System.String,Uduino.UduinoDevice)
extern void OnValueReceivedDelegate_Invoke_mCDBDDCC8170E7CEFAB37044C92F0BE34CC05CF06 (void);
// 0x00000307 System.IAsyncResult Uduino.UduinoManager/OnValueReceivedDelegate::BeginInvoke(System.String,Uduino.UduinoDevice,System.AsyncCallback,System.Object)
extern void OnValueReceivedDelegate_BeginInvoke_m304000A40163F88E1E81507B008F9DD0D2E20C9C (void);
// 0x00000308 System.Void Uduino.UduinoManager/OnValueReceivedDelegate::EndInvoke(System.IAsyncResult)
extern void OnValueReceivedDelegate_EndInvoke_m0D148C88E59DE19818A16B18346D05849468D16B (void);
// 0x00000309 System.Void Uduino.UduinoManager/OnDataReceivedDelegate::.ctor(System.Object,System.IntPtr)
extern void OnDataReceivedDelegate__ctor_mCC8A330689DF5BA02041E04F0036150E0ED8E997 (void);
// 0x0000030A System.Void Uduino.UduinoManager/OnDataReceivedDelegate::Invoke(System.String,Uduino.UduinoDevice)
extern void OnDataReceivedDelegate_Invoke_m47894B6E7A5A8AA4343CA37DE51101482DFA030A (void);
// 0x0000030B System.IAsyncResult Uduino.UduinoManager/OnDataReceivedDelegate::BeginInvoke(System.String,Uduino.UduinoDevice,System.AsyncCallback,System.Object)
extern void OnDataReceivedDelegate_BeginInvoke_m11AEBD584BA42EAB21046DE647DDD5392F17B93F (void);
// 0x0000030C System.Void Uduino.UduinoManager/OnDataReceivedDelegate::EndInvoke(System.IAsyncResult)
extern void OnDataReceivedDelegate_EndInvoke_mFCDB25FEFEA8A0CC7B053582ECDA19A81E7341B0 (void);
// 0x0000030D System.Void Uduino.UduinoManager/OnBoardConnectedDelegate::.ctor(System.Object,System.IntPtr)
extern void OnBoardConnectedDelegate__ctor_mAE57DFEC17DF7496233C2E2D598DD9453A22364D (void);
// 0x0000030E System.Void Uduino.UduinoManager/OnBoardConnectedDelegate::Invoke(Uduino.UduinoDevice)
extern void OnBoardConnectedDelegate_Invoke_m3385E7D15B65841CC9F8BF4A98B37828B8797CF4 (void);
// 0x0000030F System.IAsyncResult Uduino.UduinoManager/OnBoardConnectedDelegate::BeginInvoke(Uduino.UduinoDevice,System.AsyncCallback,System.Object)
extern void OnBoardConnectedDelegate_BeginInvoke_m97A3D60A772C7C08335EB7FD009AEB90B4BB068C (void);
// 0x00000310 System.Void Uduino.UduinoManager/OnBoardConnectedDelegate::EndInvoke(System.IAsyncResult)
extern void OnBoardConnectedDelegate_EndInvoke_m61BE22DB05506ED24F422603206449641CB7B914 (void);
// 0x00000311 System.Void Uduino.UduinoManager/OnBoardDisconnectedDelegate::.ctor(System.Object,System.IntPtr)
extern void OnBoardDisconnectedDelegate__ctor_m4908EB6CB0FD10852AC106D2AA50FA0CEBFA8D28 (void);
// 0x00000312 System.Void Uduino.UduinoManager/OnBoardDisconnectedDelegate::Invoke(Uduino.UduinoDevice)
extern void OnBoardDisconnectedDelegate_Invoke_mE536F2515C632077F3AA2A7163881312CFD8F26A (void);
// 0x00000313 System.IAsyncResult Uduino.UduinoManager/OnBoardDisconnectedDelegate::BeginInvoke(Uduino.UduinoDevice,System.AsyncCallback,System.Object)
extern void OnBoardDisconnectedDelegate_BeginInvoke_m31FD5D30A09FC582A0E4208B46C4457CF2D00441 (void);
// 0x00000314 System.Void Uduino.UduinoManager/OnBoardDisconnectedDelegate::EndInvoke(System.IAsyncResult)
extern void OnBoardDisconnectedDelegate_EndInvoke_m67A344995ADEE3D2814260C4CB32169E8B303142 (void);
// 0x00000315 System.Void Uduino.UduinoManager/<DelayedDiscover>d__94::.ctor(System.Int32)
extern void U3CDelayedDiscoverU3Ed__94__ctor_mCC5404B89F6577171AEC7B3AD035F76F3BDD127E (void);
// 0x00000316 System.Void Uduino.UduinoManager/<DelayedDiscover>d__94::System.IDisposable.Dispose()
extern void U3CDelayedDiscoverU3Ed__94_System_IDisposable_Dispose_m10732F0E759717BC106729299B70D1F5D74F1464 (void);
// 0x00000317 System.Boolean Uduino.UduinoManager/<DelayedDiscover>d__94::MoveNext()
extern void U3CDelayedDiscoverU3Ed__94_MoveNext_mC378C49DBF219927D9B35BE030A4AA484169DC48 (void);
// 0x00000318 System.Object Uduino.UduinoManager/<DelayedDiscover>d__94::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CDelayedDiscoverU3Ed__94_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m95508F1AB23820B034E65556B4A31A6470AF2D72 (void);
// 0x00000319 System.Void Uduino.UduinoManager/<DelayedDiscover>d__94::System.Collections.IEnumerator.Reset()
extern void U3CDelayedDiscoverU3Ed__94_System_Collections_IEnumerator_Reset_m91EC5B76C30D3F56637C6D66D73B97A5E4DE3431 (void);
// 0x0000031A System.Object Uduino.UduinoManager/<DelayedDiscover>d__94::System.Collections.IEnumerator.get_Current()
extern void U3CDelayedDiscoverU3Ed__94_System_Collections_IEnumerator_get_Current_m977C60D7E563738228AB9199F945441F0F7BA9ED (void);
// 0x0000031B System.Void Uduino.UduinoManager/<RestartIfBoardNotDetected>d__95::.ctor(System.Int32)
extern void U3CRestartIfBoardNotDetectedU3Ed__95__ctor_m7C2BA58897EA88BD33660740E16ABE4B9414F16A (void);
// 0x0000031C System.Void Uduino.UduinoManager/<RestartIfBoardNotDetected>d__95::System.IDisposable.Dispose()
extern void U3CRestartIfBoardNotDetectedU3Ed__95_System_IDisposable_Dispose_mDD0FB3788C9B34D4456492250E80BB4C2742B645 (void);
// 0x0000031D System.Boolean Uduino.UduinoManager/<RestartIfBoardNotDetected>d__95::MoveNext()
extern void U3CRestartIfBoardNotDetectedU3Ed__95_MoveNext_mE9265D3D799E84DB99CE2A83A893C0D352636E74 (void);
// 0x0000031E System.Object Uduino.UduinoManager/<RestartIfBoardNotDetected>d__95::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CRestartIfBoardNotDetectedU3Ed__95_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mBE24DD915D890E41B1DA4DF15A68B9BAAB5931B9 (void);
// 0x0000031F System.Void Uduino.UduinoManager/<RestartIfBoardNotDetected>d__95::System.Collections.IEnumerator.Reset()
extern void U3CRestartIfBoardNotDetectedU3Ed__95_System_Collections_IEnumerator_Reset_m546F50D94B924AC3A0DEE31647B16625FA714052 (void);
// 0x00000320 System.Object Uduino.UduinoManager/<RestartIfBoardNotDetected>d__95::System.Collections.IEnumerator.get_Current()
extern void U3CRestartIfBoardNotDetectedU3Ed__95_System_Collections_IEnumerator_get_Current_m8443F19DA412CF7CA9308736ECAF29A47F7B2AA6 (void);
// 0x00000321 System.Void Uduino.UduinoManager/<AutoSendBundle>d__158::.ctor(System.Int32)
extern void U3CAutoSendBundleU3Ed__158__ctor_m8D78C399578EC0481409F19CFA67D937A33D1A30 (void);
// 0x00000322 System.Void Uduino.UduinoManager/<AutoSendBundle>d__158::System.IDisposable.Dispose()
extern void U3CAutoSendBundleU3Ed__158_System_IDisposable_Dispose_m19861D441E86757A084F4B355784130B9EAB816C (void);
// 0x00000323 System.Boolean Uduino.UduinoManager/<AutoSendBundle>d__158::MoveNext()
extern void U3CAutoSendBundleU3Ed__158_MoveNext_m4351D742C9FD2C1DA44574908843ECE93E0C8387 (void);
// 0x00000324 System.Object Uduino.UduinoManager/<AutoSendBundle>d__158::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAutoSendBundleU3Ed__158_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m5BCC91B0E37B98FD040F8972A70256A72A8E1482 (void);
// 0x00000325 System.Void Uduino.UduinoManager/<AutoSendBundle>d__158::System.Collections.IEnumerator.Reset()
extern void U3CAutoSendBundleU3Ed__158_System_Collections_IEnumerator_Reset_m78AEB46D8407B72479B106AE8D98EE02C62C1A5A (void);
// 0x00000326 System.Object Uduino.UduinoManager/<AutoSendBundle>d__158::System.Collections.IEnumerator.get_Current()
extern void U3CAutoSendBundleU3Ed__158_System_Collections_IEnumerator_get_Current_mF9D7E35FC12E0D345F8BCA68598E0C035923610B (void);
// 0x00000327 System.Void Uduino.UduinoManager/<CoroutineRead>d__173::.ctor(System.Int32)
extern void U3CCoroutineReadU3Ed__173__ctor_mD60DA2B0781A5B5EB321DAAAF418339314ADD1F0 (void);
// 0x00000328 System.Void Uduino.UduinoManager/<CoroutineRead>d__173::System.IDisposable.Dispose()
extern void U3CCoroutineReadU3Ed__173_System_IDisposable_Dispose_m27E6AC4F8C31E2360CBE7EB7751E66544EA3571B (void);
// 0x00000329 System.Boolean Uduino.UduinoManager/<CoroutineRead>d__173::MoveNext()
extern void U3CCoroutineReadU3Ed__173_MoveNext_m63F731E33699A086E4355C9BFFE4B517438D487F (void);
// 0x0000032A System.Object Uduino.UduinoManager/<CoroutineRead>d__173::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CCoroutineReadU3Ed__173_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m1A77412D00611DB223923590C3361F233CFF171C (void);
// 0x0000032B System.Void Uduino.UduinoManager/<CoroutineRead>d__173::System.Collections.IEnumerator.Reset()
extern void U3CCoroutineReadU3Ed__173_System_Collections_IEnumerator_Reset_mD5C4EDD3F1CD015E293A7A91EB55181A4A2FE5F0 (void);
// 0x0000032C System.Object Uduino.UduinoManager/<CoroutineRead>d__173::System.Collections.IEnumerator.get_Current()
extern void U3CCoroutineReadU3Ed__173_System_Collections_IEnumerator_get_Current_m83FD71A9322855CAFC394868629C834C218D3C51 (void);
// 0x0000032D System.Void Uduino.UduinoManager/<>c__DisplayClass174_0::.ctor()
extern void U3CU3Ec__DisplayClass174_0__ctor_m34D528D848A071D3FCB966BE91537AB00C4BC188 (void);
// 0x0000032E System.Void Uduino.UduinoManager/<>c__DisplayClass174_0::<TriggerEvent>b__0()
extern void U3CU3Ec__DisplayClass174_0_U3CTriggerEventU3Eb__0_m22AA48E728ED4FE3A64AAB5B6E7DA690AD136E8E (void);
// 0x0000032F System.String Uduino.UduinoVersion::getVersion()
extern void UduinoVersion_getVersion_m687281B5392A04216C7CB1FFAD05431A189AC808 (void);
// 0x00000330 System.String Uduino.UduinoVersion::lastUpdate()
extern void UduinoVersion_lastUpdate_m9CC3C81F35B083CF796F68CEEB2D6E0FA16711B8 (void);
// 0x00000331 System.Void Uduino.UduinoVersion::.cctor()
extern void UduinoVersion__cctor_mDA54E9963892A8D473757549EA1B9CB9DED03A50 (void);
// 0x00000332 System.Void Uduino.SerializableDictionary`2::OnBeforeSerialize()
// 0x00000333 System.Void Uduino.SerializableDictionary`2::OnAfterDeserialize()
// 0x00000334 System.Void Uduino.SerializableDictionary`2::.ctor()
// 0x00000335 System.Void Uduino.IsPresentDictionnary::.ctor()
extern void IsPresentDictionnary__ctor_m29DF97F4B0DED41FBB74E2CF5653D748F47D4C6B (void);
// 0x00000336 System.Void Uduino.IsActiveDictionnary::.ctor()
extern void IsActiveDictionnary__ctor_mDE82022306954DF532F35E6D92127D8595C444C4 (void);
static Il2CppMethodPointer s_methodPointers[822] = 
{
	Main_Start_m5864CE07B60D35921FE23903087087FC5C3CF8FD,
	Main_Update_m6A75833947272413C503ECE10B0D91F56F193526,
	Main_AddElements_m42BA141AEF7893B2B7B5CB848A845DCFACCEFABF,
	Main_LimbControl_m90BF02AE72762B6A040D8AD1740D007D736EA072,
	Main__ctor_mC5886B5D00EEF6A6D8F96F3A84762F8AD71E51B6,
	SkinnedVertices_Start_m1CE07837F5AAC8EAB54724313252E19F4AE2E876,
	SkinnedVertices_Update_m52C8A0C9DD994F574D9B829DBA4685EC907618F8,
	SkinnedVertices__ctor_m9E8D85F8C3320E681CEC6D648F4B2EB20AD3E983,
	Bone__ctor_mC7230F177D90E1D79A0526EA587401AB3DF057A8,
	TriggerDetact_OnTriggerEnter_m718546D74B35193B0AE2BC2CA9FF1560D9A66A68,
	TriggerDetact_OnTriggerExit_m21A223FFB96F7F9AB32160D7BAE730D66934663C,
	TriggerDetact__ctor_m8EED2D4D1FACD28C5C21E1E65C0961D3F62E3588,
	WhiteLightFade_Start_m74CAF07861D7004EA033B09905764964EB0A346A,
	WhiteLightFade_Update_m89DCA91AE10FC0E8EB23C9421D20A867EDEEEF7F,
	WhiteLightFade__ctor_m8F1DE063A534F87C5A2C62D0CFD2A668A004E868,
	WhiteLightFade_U3CUpdateU3Eg__whiteLightFadeU7C3_0_m4F576EC3A00D9AA4363081DF7CFCD9E6321AE380,
	U3CU3CUpdateU3Eg__whiteLightFadeU7C3_0U3Ed__ctor_m88FA6F11F43F5F8C595DBE8F53D3D048055AD952,
	U3CU3CUpdateU3Eg__whiteLightFadeU7C3_0U3Ed_System_IDisposable_Dispose_m4B3A47D6F207F15174720CF7DCCE6E99635AB3FB,
	U3CU3CUpdateU3Eg__whiteLightFadeU7C3_0U3Ed_MoveNext_mC901187650F7062BA9933477E1323CB514B55841,
	U3CU3CUpdateU3Eg__whiteLightFadeU7C3_0U3Ed_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mF59F56AAC2EA6EC54EE7C0A36C9E327E17EFCFBE,
	U3CU3CUpdateU3Eg__whiteLightFadeU7C3_0U3Ed_System_Collections_IEnumerator_Reset_m27DC578BD76F697A8BEBCCC12BF22F6AE3D73A53,
	U3CU3CUpdateU3Eg__whiteLightFadeU7C3_0U3Ed_System_Collections_IEnumerator_get_Current_mADD1157784B968149ECEABDA96A2CFB5E67AF17E,
	PublicFunctions_Start_mB350E3410BD56390DC2A74472BC0CF79E8F30700,
	PublicFunctions_OnGUI_m7F3D979DB9A395EF46944D16D90357B0D002DF82,
	PublicFunctions_Awake_m66150D06C73BA468D102EA252EC6CD6EF7C9B9B4,
	PublicFunctions_Update_m30E939D95BA99A535A021F79665264B7C26C351B,
	PublicFunctions_Move_m7814810BE19019B119E74F8022842CA3C51B8663,
	PublicFunctions_Rotate_m98D01D6FA42DCAB14EE8B8D17F5494526DC23D61,
	PublicFunctions__ctor_mA2E5751F1C4DE908CD0E1F2004F6B8A1B6DD0DAA,
	AssignTags_Awake_m6C94AC7D68D5CBAEAED99351A3173FD528F51655,
	AssignTags__ctor_m68EC0A133A05DE6DF3A8E136E14A67BC5F5E33B6,
	FloatInLight_Start_m6336B341C977EAAF9790829FB083E14C44CCF38B,
	FloatInLight_OnTriggerEnter_m1A13E7E9275ACBF9E291C151CC24278D596E3666,
	FloatInLight_OnTriggerExit_m09E66452882B4FDB5A0306065FDA973B4217127B,
	FloatInLight_Update_m043CA448CF3451C7BCDB2783F023B0C49AA0D367,
	FloatInLight__ctor_m0CCEA1083D28BF1D748FA782B2250D6D6890FFB8,
	NextScene_Start_mB01999C2F0A2F57812B0E73977515956E53FF369,
	NextScene_Update_m5AA5CFFDC6687DDAE51529DE556DDFBE0B431ADD,
	NextScene_OnTriggerEnter_m6AE74F45B42F590AA89522C6EAAF926C4221AAC6,
	NextScene_ExampleCoroutine_m4221D0E3B624942DD8619FACDA728F7C31E2E2D4,
	NextScene__ctor_mF930690F11186753D518C23AF63B16D8CBA87419,
	U3CExampleCoroutineU3Ed__6__ctor_m946082FFA11063E80F506BB429D62B64FFE95CB4,
	U3CExampleCoroutineU3Ed__6_System_IDisposable_Dispose_mA6AC9A9366F0694380E575660F1E2862C4DA38B0,
	U3CExampleCoroutineU3Ed__6_MoveNext_m21E3FDCBB05B58D2E264066E2780002E2896FB6A,
	U3CExampleCoroutineU3Ed__6_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m9304D08B9F7875B3FC528FC72B74F4D88D298143,
	U3CExampleCoroutineU3Ed__6_System_Collections_IEnumerator_Reset_mC41A9F7A9609031CAACCC1DC047E9A3D15AADCE9,
	U3CExampleCoroutineU3Ed__6_System_Collections_IEnumerator_get_Current_m10F949A91AC9A5A8077356D4D6EAB86EE8EB2A85,
	Struggle_Start_m7E74D15AED68AFDD9D9916B0A93FF0539FD75287,
	Struggle_HandRotate_m2A54A16CB7B1453B6E2794300579FB9ADCE0B650,
	Struggle_Update_mCE924AF389C962FB03829C1159EB076D2A1257F5,
	Struggle_ExampleCoroutine_m4EDB06BE15E1A738217E6A504E1B8F80B7DCF6BC,
	Struggle__ctor_m8FD9B3F79B1216F08A3CB02F414477D1B72A3C04,
	U3CExampleCoroutineU3Ed__24__ctor_mAFF1F71F7A9204EDA18C0337DBD8EBF395B60F82,
	U3CExampleCoroutineU3Ed__24_System_IDisposable_Dispose_mDFE7B66923BDABD3165021C9AA05F4FED056AFC6,
	U3CExampleCoroutineU3Ed__24_MoveNext_m1D91D76D8A82B873B944867CED48C30B29390CC6,
	U3CExampleCoroutineU3Ed__24_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mE5EBC82C7E7E34650FEC1C7EE6676251087781DC,
	U3CExampleCoroutineU3Ed__24_System_Collections_IEnumerator_Reset_mD7E955457C6F08CB20F49EF1DCF5A42F4E7BD77E,
	U3CExampleCoroutineU3Ed__24_System_Collections_IEnumerator_get_Current_m922E9AFF22B4EFD7A371E172E754584FC8E86258,
	UduinoReceive_Remap_mC94340BD7AD53A3DCDDBB6A569D5D8A72CDCB552,
	UduinoReceive_BoardConnected_m9CC40CB9047DD35250CBC4EC9F67BA4A82928598,
	UduinoReceive_Update_mEE82144B03A40E39C8B44239582F183619B61CB4,
	UduinoReceive__ctor_mC526A624142E0E2912DF09FCCDB8FF632B2DC8D1,
	Bloom_OnRenderImage_mD7750BD37D887456642266EEBF718FC78F1717C4,
	Bloom__ctor_mF53865061B69135EEA4B6B02F203BE158C80EDE8,
	MegaReadWrite_Start_m8177F907BDEE8F5AD402230AB9E2EA507A1EC23B,
	MegaReadWrite_BoardConnected_m54FFFB69592AF251B0F007625A7D2012DF7BFDFD,
	MegaReadWrite_Update_m4905BF57B90534A0B0DD952365A519FD50F5F4E2,
	MegaReadWrite__ctor_m7A7122BD15C7874A6ACB22682F4B5E375FBDE335,
	ChangeBoardType_Start_m09457C92FBD90F93ED092744F1D93D884362F755,
	ChangeBoardType_OnBoardConnected_m3A718616D097EDC77F9ADD7B78557F39D2FEB52F,
	ChangeBoardType__ctor_m5E1FAC081B023A21FDC63C7249EBB48BB46BF068,
	Bundle_Start_m22FC21872C389D03B203811CF034816D9279F7D8,
	Bundle_BlinkAllLoop_m2D93ED7019C6207951F04BABB3D114CB2B3DBB90,
	Bundle__ctor_mF564BD780BCFA392DD8FC378BBF537A5A61FB284,
	U3CBlinkAllLoopU3Ed__2__ctor_m2917DFE00A8C4354C1A9ADAD03EF12FC77C7C3F3,
	U3CBlinkAllLoopU3Ed__2_System_IDisposable_Dispose_m5B6E109605222519B88B0CE0ED4D3C3F5698443B,
	U3CBlinkAllLoopU3Ed__2_MoveNext_m493FAD55966A1846550A04AB0C6C521FED607A7C,
	U3CBlinkAllLoopU3Ed__2_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m1751E9D754C80712577AB1338C42E84ED1A7E404,
	U3CBlinkAllLoopU3Ed__2_System_Collections_IEnumerator_Reset_m5F7E54B33C855DF7B81A7CBC0611D0569DEAB7BD,
	U3CBlinkAllLoopU3Ed__2_System_Collections_IEnumerator_get_Current_mDA82DCA481A85D6F7D7D5508D83F4279A64733F3,
	ButtonTrigger_Awake_m67A4F77EE2A5B3838DE44F1CB82E295BB48417AE,
	ButtonTrigger_OnDataReceived_mF2A25EB881D6621E732D00F044BCFDB40CB8584F,
	ButtonTrigger_PressedDown_m551EFF727605FA836596B779210B7020D089E28F,
	ButtonTrigger_PressedUp_mCEC3A4BDB2877DC07568DA4E475FD2C27853470B,
	ButtonTrigger__ctor_m7127FE8CACB7773026CCFC0F73460626EE31DBAC,
	EncoderLibrary_Start_m9F62CA3310FF1ECF6BA5DC9E435C2F8253523F82,
	EncoderLibrary_ReadEncoder_m5ABF62BD32ADD9214B28ED723F0FF5A80F1CF872,
	EncoderLibrary__ctor_m2BBB30BCE767A83D891046759A2A3ED2D5FFC822,
	SendLedIntensity_Update_mA9070E07D418B95F86ADFD0330835585786A7ED0,
	SendLedIntensity__ctor_m955D52594943F3651904DF337B6EAF7D8608FAE3,
	MultipleArduino_Start_mF47E3A5C6E779105FF1EBD18E3E50C761D4C18E6,
	MultipleArduino_Update_mF23E3A126D45C488DE55380511E27DDC280A18E4,
	MultipleArduino_OnDataReceived_m0F24DC673EBC5F734909D99A5822601E61A8EC17,
	MultipleArduino__ctor_m8F5D7BCF68D77215A346FA10315B4EB7C434895F,
	MultipleArduino2_Start_m2867BDA5CFF099443C5E95424ACA48AB95EFD27F,
	MultipleArduino2_Update_m58088783A85AF6D9CAFE08766101816342098F52,
	MultipleArduino2_OnDataReceived_mEE4C6DB04FF8478397E5A3B63E2F41F97CA8305B,
	MultipleArduino2_OnBoardConnected_mBB100749CA04E1D7240E9B514B3450BABF5C2E4E,
	MultipleArduino2__ctor_m25C8D7E034086770E67CF7FF0C2BB271E9651A26,
	UduinoShortCall_Update_mF09247A21AFBDA2AAEAA5AA29263BBB363157D0E,
	UduinoShortCall__ctor_m6FBBEB86B323114106F87F069E5C140C6011593E,
	UduinoShortCall_U3CUpdateU3Eb__2_0_m07B6F9B95AF362E7A0F7BE8838B04BFEC694CDB3,
	ReadSensor_Awake_m5F4D2476D14A398FC97846E2B0CBA2BC29F1F788,
	ReadSensor_Update_m61D01F5C000A1769B1623CAC760FB513BB836EAF,
	ReadSensor_OnDataReceived_m9F95E777EEC202CED139C206133A21BB58A2AA47,
	ReadSensor_Read_m38243660133DB5CB275F2AFD911F623B0CF9B3A0,
	ReadSensor__ctor_m791FD0A507821750DAC4AD013FDB788522AAC7B7,
	SendCommandToArduino_Start_m53F8817507355C5538FA6682796422129DB7BB73,
	SendCommandToArduino_Loop_m7AD9CBE6E84CD6D310049D37CC70172813612503,
	SendCommandToArduino_ReceviedData_m8AF500E90B1D18074EECE57DF1C99FA00A5F4AAB,
	SendCommandToArduino__ctor_m4985E93866820D03F38DFB47A32FFB0BD7DC65A8,
	U3CLoopU3Ed__4__ctor_mDA3792A6931C0934A8355194C07DD83AD52D68CE,
	U3CLoopU3Ed__4_System_IDisposable_Dispose_mA093968C97CFDE13B105B7193D0E9FFE9814A20D,
	U3CLoopU3Ed__4_MoveNext_m7D491723D41A4AC63A78E6AFABFE57478A437E77,
	U3CLoopU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m0FCDBD649E689C9FAA1AF45B1A35555AA157E93F,
	U3CLoopU3Ed__4_System_Collections_IEnumerator_Reset_m73B87E33B828A6B375D6EC920A0C0FD0588351C5,
	U3CLoopU3Ed__4_System_Collections_IEnumerator_get_Current_m652D0B88F188D1A75E8488FA5A769B6FBCAA6B5C,
	ServoOptimized_Update_mD47E963E27CECC87489F1E1E3D1019F646E1B977,
	ServoOptimized_OptimizedWrite_m7521D1AD473AB61D7DFE71CBEB2A40044798CA73,
	ServoOptimized__ctor_m72CAA11A28CFDBD454CFDC36B526EC7F074270DE,
	AnalogRead_Start_m982369B49D648B413AB8EF650926CE8CFA025E1F,
	AnalogRead_Update_m0DAD6029E2E3CEB6F8A73ED7CB8856C3D1041919,
	AnalogRead_ReadLights_mA2289F7B2280E78FF3643691242C13E1A75B512C,
	AnalogRead__ctor_mEEEE0451A140028289C3BB85AEAA38197133CD15,
	AnalogWrite_Start_m978E6337B9EDB5BE5B34A09816E4780AFED57E24,
	AnalogWrite_Update_m5BEBF73FD9288BCC7FF419BEDAD04E08995AD672,
	AnalogWrite__ctor_m26955E638F6EA76FF925745E4EF3BA788C3AEF57,
	BlinkLed_Start_mA2D7BF07E4F88CC2D57126C2EFB8907106429D5D,
	BlinkLed_BlinkLoop_mA9654A0699D2B299B1D435C9F58DB88FC1D16563,
	BlinkLed__ctor_mE6E4E36704E419F668A4E40E976F4642319944E7,
	U3CBlinkLoopU3Ed__4__ctor_m4CB846997137A0430E443C9F3D1683FDA4FCC68A,
	U3CBlinkLoopU3Ed__4_System_IDisposable_Dispose_m6AD96AF945FA97988DADAE9E7D2138E1BA1FA73A,
	U3CBlinkLoopU3Ed__4_MoveNext_mE8EC5B0F86ACCB7A452E205B8A215FB018202637,
	U3CBlinkLoopU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mB8CA5DF93DB23FBA602B9A1C5FF4DA754D28DDEA,
	U3CBlinkLoopU3Ed__4_System_Collections_IEnumerator_Reset_m38C04F4D44107F9D40418EAED0915C787E1AE8BE,
	U3CBlinkLoopU3Ed__4_System_Collections_IEnumerator_get_Current_m83702C9F88CB0AD62EA4D0A26C8989C5FC309F69,
	DigitalReadButton_Start_mFF75CB388DF833C0A4813E6669A2B788331D3977,
	DigitalReadButton_Update_m2316F48A30F174F102DBEAF565A2FB6F96AF1379,
	DigitalReadButton_PressedDown_mDE5B59A4B51C70FC01EF79F7EDAE2F2C9A184778,
	DigitalReadButton_PressedUp_mF2681AE9F4081B760FF37F1FEA9E9EA33FCA006D,
	DigitalReadButton__ctor_mA628462D26011A1A707D92DCF991A98921E7B6D2,
	MultipleButtons_Start_m81FD3E957DC1D80E5FEEC9E91458031CACA7898D,
	MultipleButtons_DataReceived_m71F51D61E1EEDEFFEA5B50A1E702F84DC444A089,
	MultipleButtons_Update_m1C560497D6FF8C5C0FF564C0F71EEB8CAEE56C4D,
	MultipleButtons_PressedDown_m0F932116B734732762A236EA9D07D402B5E1DE05,
	MultipleButtons_PressedUp_mD5D1B4F47612E05295ED1719C6FE06534030E9F2,
	MultipleButtons__ctor_m465BB193B242D6DB0640165D545D994260F12AD1,
	UduinoButton__ctor_m3E5E326F5FA06EDE9C45D19A1458A63AA4C1AA83,
	UduinoButton_Read_mA228653E6D058C9FB735355B22EA051DF86C443E,
	UduinoButton_pressedDown_m798A1A143455C8D3E1EB87F0C05EE76C1C845485,
	UduinoButton_pressedUp_m85E9B32A18F84D775F13BA87552BE844B3E0EAA4,
	UduinoButton_valueChanged_m1C787B3C51D687743FD9B484DF294DFE577306A7,
	UduinoEventsReceiver_DataReceived_mBF8553B109981192C3A5B0E536E08247EE40A42A,
	UduinoEventsReceiver_BoardConnected_m01584F8BC0151A3021EC01C8BA6AA79697217B00,
	UduinoEventsReceiver_BoardDisconnected_mF1C5224E78D63BB08E2735FD721225AEF0E26A75,
	UduinoEventsReceiver__ctor_mBADE0C0FE7558A6AAA0E192E5DBF01AED482FAD8,
	FadeInOut_Start_m981511CF39B92FD67F55EFDEA7EBBF3A063055F6,
	FadeInOut_FadeLoop_m800A303348A561B3133CBDEDEBFE46C57D4CC7C9,
	FadeInOut__ctor_m1C4183C53A57A5FFBC0293ED557387702E89DDC8,
	U3CFadeLoopU3Ed__5__ctor_m69FE480DB22F3C73F8F42FD013890B8CF776FC40,
	U3CFadeLoopU3Ed__5_System_IDisposable_Dispose_m7D9AE71F63905C46A761C35BBE6EE21BA69389AB,
	U3CFadeLoopU3Ed__5_MoveNext_m4B9C21FD97D8105A5F5F8DAC47102204FD8739ED,
	U3CFadeLoopU3Ed__5_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m9EA4EB1254484BF5FDF5AC465CC73E268B53A1E2,
	U3CFadeLoopU3Ed__5_System_Collections_IEnumerator_Reset_m9F4EDCD3B9A6C4896DF95B5BBF63C2C86F98D613,
	U3CFadeLoopU3Ed__5_System_Collections_IEnumerator_get_Current_mA4B8E4471D736E8C41EB0F4C41E9369E8F16F461,
	ReadWrite_Start_mA7B07224F06779E7E4653E43504C0D1328E97421,
	ReadWrite_Update_mBA77E3F266E0B02243341749F9A1CCF922E133BC,
	ReadWrite_ReadValue_mB5A05294D3697BA76D0C84C2FD1872145EED09F9,
	ReadWrite__ctor_m31B8331B3023735DCEDD2398C8DB937EC13540DD,
	Servo_Start_m53D8C8C4544A4DE76C6DDBC84B5613C2A2E14CFB,
	Servo_Update_m20F2788BEBF73CE5921162FAE5D674DC8E3E948D,
	Servo__ctor_m592678397C799FDE4E3E48C603D52FE08960E22D,
	SimpleUduino_Start_m87FBD0F7708DF84F474A2E1EB6B7D54D8429F693,
	SimpleUduino_Update_m3C56FAE2514CC043505979B9B4FEBD0C41DC5C5F,
	SimpleUduino__ctor_mA56B67FD44B3B4FF4446F624C2317E7CDC2EA73B,
	SimpleUduino_U3CUpdateU3Eb__6_0_mAB7D52E60A06819FE5C2DF69E65D3EF26FABB61B,
	UduinoWifi_ReadWrite_Update_mF3E2C02BE0F16E8059267DD19811C0D75ECA338B,
	UduinoWifi_ReadWrite_Received_mEA80466434DCFF0D741826C84C2D9A9B5EA9BBB7,
	UduinoWifi_ReadWrite__ctor_mBEAA606C20C21A21CCEB22D7700C63D867E82198,
	MultipleWifiBoards_Update_m534E148D657C9DBE04A6920ED30D4C631D381144,
	MultipleWifiBoards_Received_m05ABC2956BFA47116DF0E79A4056DD826790CA8E,
	MultipleWifiBoards__ctor_mF47D96DB41B9BD843039B1FEFD7DC4D403356DE4,
	UduinoWifiInterfaceStart_ConnectWifi_m1D4621BE5376752463E8171D8E74D8614F226205,
	UduinoWifiInterfaceStart_LoadWifi_mD2063B36C3698661DC94CB9C4C669F7B176838F2,
	UduinoWifiInterfaceStart_SaveWifi_mF769EE410AA1BACC6421134E2124CD03DE2BBC99,
	UduinoWifiInterfaceStart__ctor_mE546CE72E42B6D120517975CED662CBCE53B696E,
	NULL,
	JSONNode_get_Item_m77F15891BEC7ED659BFBC392555178B558747AD8,
	JSONNode_set_Item_mC6F47073D979B943286B2EAB1A6D0380AFE58A09,
	JSONNode_get_Item_m466B08DF2E30B20606697EC7AE043C2791DC6768,
	JSONNode_set_Item_m045530804B67FC5E2E57E497219F27ED70CE437E,
	JSONNode_get_Value_m2A9961ACC3D4BCBB028012CD79B619DCBD82A839,
	JSONNode_set_Value_mE8CD0E68E0E2B0A716F56B0FE9B988EC2BAD773A,
	JSONNode_get_Count_m260DDA50B8AFB98F5946E54B9EADD05891A82C8B,
	JSONNode_get_IsNumber_m6B495FE576572E9FC7999740C63980BCB65AD768,
	JSONNode_get_IsString_mBDE2CAF25E51CDA450074BE9DC81D834903BA392,
	JSONNode_get_IsBoolean_m13F16853C0F6D76D0AB6B7E866923A0632C108A2,
	JSONNode_get_IsNull_m6443A7B3540D725ED3ACA0038A74CE0346A31F8D,
	JSONNode_get_IsArray_m52DCDB47E4CB2673FDCECCD3BE9DD2D90B5C948F,
	JSONNode_get_IsObject_m237FE2EA3382DD9762ED426B49F46183F5EF39AB,
	JSONNode_get_Inline_m7A5B6C07F44EFEEDD80FD72580C32C0579041F4C,
	JSONNode_set_Inline_m18362F10F03DDCD1FF29B4868C3EA793D39AE7F6,
	JSONNode_Add_mB05F1A32B54A9A1223F9AC6A6A737836FA1F4E7E,
	JSONNode_Add_mDAF96580EAF3B9FF23888A8549BED7A98439075D,
	JSONNode_Remove_mF56C4223700DF4F1D5AE12BCD69C492C2487FA59,
	JSONNode_Remove_m7B5E0BC0A29C35857D7B10857A8C52C0E3DFB615,
	JSONNode_Remove_mE2CFD05512C25BD11EA4160CAAF88B8154D9DBE5,
	JSONNode_get_Children_m3E2D70DBCA2C8311F65A47B766668728392B1F89,
	JSONNode_get_DeepChildren_m891CB892AEA834980686ED760B952A86DC1E8725,
	JSONNode_ToString_m4CC464630B0AEEDD82AEB6B069690949AF569345,
	JSONNode_ToString_m1F607CB90F49115510B7CF5228733578E9AD41F2,
	NULL,
	NULL,
	JSONNode_get_Linq_m8569DB478533504290D9A09ECA0DF12F116122DA,
	JSONNode_get_Keys_mC3401CC91BBD9D1166EF8EFC0C87A820FC543D1B,
	JSONNode_get_Values_mF8FB164A48A169146D00EBA3F51D4C8E380C1930,
	JSONNode_get_AsDouble_m9A8E3EC46E4545BCBFA26B99C0F013067D2F0AE4,
	JSONNode_set_AsDouble_mCDBB05BD0AE82EEF0C4842F5A9205B8F4C858015,
	JSONNode_get_AsInt_mE4A3FCC1D91362D077C2ACF418ACAB43771B1FE6,
	JSONNode_set_AsInt_m12FCF0B7E45E17EA0456AE44EFEF0C8731603F50,
	JSONNode_get_AsFloat_m0D044C1F3FC35086783A4BAF506EA96DC997D050,
	JSONNode_set_AsFloat_m55FCE24DF60B37724DACCCF0A759522B2561DE92,
	JSONNode_get_AsBool_m902380F5939671ACBBB7EFA01A48F1A082B1FD9C,
	JSONNode_set_AsBool_m6097FD196A8C7BB156125363D1C1D3EF0EB67CD3,
	JSONNode_get_AsArray_m2D0890FDDA140528CAB44B1B6B3E34B26383ACC7,
	JSONNode_get_AsObject_m72F6D406BECA2FB0A24B20E0A353FDB8E409CA1B,
	JSONNode_op_Implicit_mA884A397C3152BDB411767FDE9EDC274A8904523,
	JSONNode_op_Implicit_m31D5D161C5F21186F90F99E09EC78CED5188C349,
	JSONNode_op_Implicit_m35AB6AB8F232F07E3226DEB06AB832F5C2BD7A8A,
	JSONNode_op_Implicit_m0039518B4032423C4CDC8C8B07790AE1779E8E25,
	JSONNode_op_Implicit_m6ECC1712EB162E1AC774A36E31AF31A1FCC5E659,
	JSONNode_op_Implicit_m8312FC9381D54EBF755C7B41D525C6EEAD0EC135,
	JSONNode_op_Implicit_mD0756B05030DAE5F5D4A3E57708D5EEEF6A362BB,
	JSONNode_op_Implicit_mE793F9163050BD78846F2C2A288A968E8F9C11AD,
	JSONNode_op_Implicit_m2BD30AE4D30506EF634EA264A90E018FF66FF1E4,
	JSONNode_op_Implicit_m057A1C72683211B58678B1448C260F747434DF40,
	JSONNode_op_Implicit_m5D106035AB428BDA4B6671950E8E5747771CBD7F,
	JSONNode_op_Equality_m6961ED452D3A120FE9908FFB96260DF98A47A8B3,
	JSONNode_op_Inequality_m2DF69DE99CD87AA07CE1200892E24EA22B351943,
	JSONNode_Equals_mE1B8A846783529B1E54786975A6A2396089A88DE,
	JSONNode_GetHashCode_m0A263555D1F0E6766A61692A7E1BC3546B2BC984,
	JSONNode_get_EscapeBuilder_m351C10540498042FC3ED424E3D9C08DCB16071FF,
	JSONNode_Escape_mC20A370D25C7B269E4707FF5CEC7062C470C416A,
	JSONNode_ParseElement_m978282020EF903D5D8F2F2B7B05074A5D1C3F2EF,
	JSONNode_Parse_m51FFFB4953A8D875B9D2DD5E032D131A149956E0,
	JSONNode__ctor_mF8F2893483161D3B7B9877B63C69063D26A5C353,
	Enumerator_get_IsValid_mBC273331DC1699FF46BD3621AE5059A54AD98BA6,
	Enumerator__ctor_mF21239C69620D815F8CD34F022BE18E9DAF9CB10,
	Enumerator__ctor_mAC4ED0FA4B083E2652E865A41EA5C74A49478EFE,
	Enumerator_get_Current_mDE6750203413E1069D0520793D6AA0B2527CB20E,
	Enumerator_MoveNext_m238CF072385A1106BEDEFCE33BA2B0DBE999758A,
	ValueEnumerator__ctor_mCC61CE3EDCF1AC94A84E031F2E89F8054C94A015,
	ValueEnumerator__ctor_m122732DF448B45E8E82956E07AC8314C60E28C29,
	ValueEnumerator__ctor_m7BA4BAD5FEBAC4054F71575B728DC27EC4080F0A,
	ValueEnumerator_get_Current_mAA24A52FDEB7160BD268193175388EACB41B7CE2,
	ValueEnumerator_MoveNext_m5B596A2EF2FF395EDA8F5CAB97C0789498D250C9,
	ValueEnumerator_GetEnumerator_m765261287A2C0AEF757B94994826F43951387E4C,
	KeyEnumerator__ctor_m6EA81E2BED4CA5194A7306D8B324F7356E37F80A,
	KeyEnumerator__ctor_mA6338E82A9F8AA19A1744352B4FE54103AD70405,
	KeyEnumerator__ctor_m526EA1364C367B83C931F4208CDD816BD02810EA,
	KeyEnumerator_get_Current_m8FBFEE52D4438AAF3E10AB4370B34FBB8E66B3C2,
	KeyEnumerator_MoveNext_m42FE2CEE808A7E065895BA333B7FBD2F3AEE032F,
	KeyEnumerator_GetEnumerator_mD4687B4D6D10E4D6870CBBECC680689A62A95C0B,
	LinqEnumerator__ctor_m9FD8AB1580F3D94C5C36D070DBE85E023ED36E30,
	LinqEnumerator_get_Current_m28F0BE4D9B5736F5BD79197C1895EAC1592EBAAF,
	LinqEnumerator_System_Collections_IEnumerator_get_Current_m6B6C12C7E8CD21DF513FCDCB4E88E454790B6FF0,
	LinqEnumerator_MoveNext_mCA8604B6E8D857CF16003E674048C05E29447819,
	LinqEnumerator_Dispose_m5D6A54C4B712D138739726323D5BEA50A4E12E32,
	LinqEnumerator_GetEnumerator_m4A9F0720F0C0964F91032AB8B8776F09DC70A90B,
	LinqEnumerator_Reset_m56B65E398518EF57070307FDC48069DFE37BC57B,
	LinqEnumerator_System_Collections_IEnumerable_GetEnumerator_mB63F02D713868ABF87DAB18ABFD5D832F4D805A4,
	U3Cget_ChildrenU3Ed__39__ctor_mE347A8AF3B9D5C4D4F6509D57E7CC6CE66ECB030,
	U3Cget_ChildrenU3Ed__39_System_IDisposable_Dispose_m83B3259F42DA4913E6BA73E4B67995251F62B659,
	U3Cget_ChildrenU3Ed__39_MoveNext_m7F8BC2F0D3F2F133AE089C63DF942F68EC60B061,
	U3Cget_ChildrenU3Ed__39_System_Collections_Generic_IEnumeratorU3CSimpleJSON_JSONNodeU3E_get_Current_m08B40FC9CDFD3E5D5870D853FC8A2F8FDE4002FF,
	U3Cget_ChildrenU3Ed__39_System_Collections_IEnumerator_Reset_m29D526BB30BD3C9C22C4AEB799A0F66BE86F3634,
	U3Cget_ChildrenU3Ed__39_System_Collections_IEnumerator_get_Current_mCEDDCFFB132A818568BC4C90DD1034DE67445C2C,
	U3Cget_ChildrenU3Ed__39_System_Collections_Generic_IEnumerableU3CSimpleJSON_JSONNodeU3E_GetEnumerator_m88A6D227A5F685108F3C0AF2B3C09F441D1DB2B4,
	U3Cget_ChildrenU3Ed__39_System_Collections_IEnumerable_GetEnumerator_mDBBA1FB4E94BA2024CF7AB55E45A30CDF8A9D97C,
	U3Cget_DeepChildrenU3Ed__41__ctor_mBDA566DBD5671420C00A4BE3C626FE3DBCA4F2FF,
	U3Cget_DeepChildrenU3Ed__41_System_IDisposable_Dispose_m7CC1A44CD233B61577B3588C893E5A08CC632820,
	U3Cget_DeepChildrenU3Ed__41_MoveNext_mBF21C7378F5F84A820EBFE2A902E4AE286C7B766,
	U3Cget_DeepChildrenU3Ed__41_U3CU3Em__Finally1_mADDA3B6024A9F163E8407AFCC5DD816C86425BD1,
	U3Cget_DeepChildrenU3Ed__41_U3CU3Em__Finally2_m5F77C658D020C0D4C1BDB73CC95472686B866933,
	U3Cget_DeepChildrenU3Ed__41_System_Collections_Generic_IEnumeratorU3CSimpleJSON_JSONNodeU3E_get_Current_m5DF708741D3562929E32905F4971899FBD460B22,
	U3Cget_DeepChildrenU3Ed__41_System_Collections_IEnumerator_Reset_m44EB9C4E73D96517BE71B57398E810F9D773BD85,
	U3Cget_DeepChildrenU3Ed__41_System_Collections_IEnumerator_get_Current_mB834AFAFFC33D4E01335C829157FC7F6466261BF,
	U3Cget_DeepChildrenU3Ed__41_System_Collections_Generic_IEnumerableU3CSimpleJSON_JSONNodeU3E_GetEnumerator_mA8D43B603CE4FF1056ECD5ACE0B408F581C8D0AB,
	U3Cget_DeepChildrenU3Ed__41_System_Collections_IEnumerable_GetEnumerator_m644D4075F06E77109D3702EDD1AD55FDCFD61BB1,
	JSONArray_get_Inline_mBA0C9AEBB7420DBDFD977C0F54CC237E8F2BE3E5,
	JSONArray_set_Inline_m731089F5D0FA649ED210518DC299635A8D86A1DC,
	JSONArray_get_Tag_m360EB078D7897D6D52783B8CDA6B736D014E97BC,
	JSONArray_get_IsArray_mA7B4EF5B0128FB64ACEB7EAC66FA3522991980AF,
	JSONArray_GetEnumerator_m6AF64AE0DD2A5AAB8C0E271BF0CAB8AA1FD32E17,
	JSONArray_get_Item_m8BE9047FC512840E6A4594560EDF86BB4E0FF657,
	JSONArray_set_Item_mBCD05590C34BC589B786E753B9FE796EBA3F6725,
	JSONArray_get_Item_mE18312128B02B505BA656D7F444B05A6769710AE,
	JSONArray_set_Item_mE4E0DE5133E60AF49E46FEDAD00D2A04349C0855,
	JSONArray_get_Count_mB71218A2D8288D0665C467844F7351D301FDAFDD,
	JSONArray_Add_mD1FBE0F0FC20E7415014B7FF21939592EBB0C9A1,
	JSONArray_Remove_m79500DBD9751A04C02756470A4D22DDCF9C97FEC,
	JSONArray_Remove_m64C3EBFE3DB5BE130232769DC43000E84589E674,
	JSONArray_get_Children_m733AE4C5816E51E6F86441110606489A0406AA91,
	JSONArray_WriteToStringBuilder_m9F23115433028794DCAC019F82EEFD946990D994,
	JSONArray__ctor_m92FFF2DC8E1425398814F50D4B253EB459B8477F,
	U3Cget_ChildrenU3Ed__22__ctor_m85868694A6F76D6658184E05C60FF81F01F77A15,
	U3Cget_ChildrenU3Ed__22_System_IDisposable_Dispose_m2F364B8DD4640833161EE743D458FAF77BCAED9F,
	U3Cget_ChildrenU3Ed__22_MoveNext_mD1A93CD03B10AD9224ACD34AA4478BA4EB448AE5,
	U3Cget_ChildrenU3Ed__22_U3CU3Em__Finally1_mE8C769C27FDCFEA9BDE25D788AE87EC9565F4C5F,
	U3Cget_ChildrenU3Ed__22_System_Collections_Generic_IEnumeratorU3CSimpleJSON_JSONNodeU3E_get_Current_m9FB6C47800DA9AC5BD99118430A954370D30FA70,
	U3Cget_ChildrenU3Ed__22_System_Collections_IEnumerator_Reset_m5FDF47F215C3ECA0B88DBDBA67D9E23939FB6E75,
	U3Cget_ChildrenU3Ed__22_System_Collections_IEnumerator_get_Current_mB7369D4C4D04908F6F69E55E0FDF6835418E9671,
	U3Cget_ChildrenU3Ed__22_System_Collections_Generic_IEnumerableU3CSimpleJSON_JSONNodeU3E_GetEnumerator_mE9E5D91FED8686D7D44613FE3F2E5A67765D924E,
	U3Cget_ChildrenU3Ed__22_System_Collections_IEnumerable_GetEnumerator_m64A7C394D254404FA1EE6C54C42CB33064B85573,
	JSONObject_get_Inline_mCDF2154366BEFF9E547918F999E7F3C7C4865F84,
	JSONObject_set_Inline_m7F048A7565E5A53FDB610D44B7CA75A314CB7A7A,
	JSONObject_get_Tag_mD57D6BCAD1C677B88693FD508129CFAD661F4FBD,
	JSONObject_get_IsObject_m9F72861BE5A0DB2888AA3CBEC82718E08DD71E93,
	JSONObject_GetEnumerator_m8912E3D1EA302655BB5701B53EB19437238BABDA,
	JSONObject_get_Item_m219B9BA37D800A5DFEAA14E4EECA375B3565BF96,
	JSONObject_set_Item_m1AC7334DBA67D0CB6C9549B83B3FFA75CF226AEF,
	JSONObject_get_Item_m5C2EDBE7B154A3FC1CC43616C4C40255B4D95652,
	JSONObject_set_Item_mFB6E61E3FA394B7D2CA01CC957A6A253642D109B,
	JSONObject_get_Count_m9109E9A81559A9006EE160CA6A0F3291C71F2D08,
	JSONObject_Add_m25BD208A0AC0F0223FD93FBCB42785B12A6E1A18,
	JSONObject_Remove_m34280FDB4512E61F42781475E492BE98514830C9,
	JSONObject_Remove_mD1B01E22A9C1FEE83A00ECDFD8E0D8A422F8E4C2,
	JSONObject_Remove_m51B998A7997D184A1A20359D512C6B5A1B825404,
	JSONObject_get_Children_m03D7227DE57F0BE2977FC0436C0DE48858650B7C,
	JSONObject_WriteToStringBuilder_m931DC8805C6B8F09617958EFDAEA957751EB2EAE,
	JSONObject__ctor_m8007967452F5257DC9F5DF2B78B411BFD4B6D6AB,
	U3CU3Ec__DisplayClass21_0__ctor_m6976B4CF7F93E28364B390F81E55DAD60BB141C1,
	U3CU3Ec__DisplayClass21_0_U3CRemoveU3Eb__0_m8B35D441B276B749481FF797FC51A256A7A56105,
	U3Cget_ChildrenU3Ed__23__ctor_mD7DD2FB8F14148B45EC4AC3A595DC1AFE369FC99,
	U3Cget_ChildrenU3Ed__23_System_IDisposable_Dispose_m85C7654E92BD35A4525D4F3E70FFD57B5CD497AF,
	U3Cget_ChildrenU3Ed__23_MoveNext_mB9E90BB01F42BA8913E7CD7AEA18FBEADFC46CC0,
	U3Cget_ChildrenU3Ed__23_U3CU3Em__Finally1_m0FEB12CB9C8CC84E25A44F9FC928D8EB8F4DF9DD,
	U3Cget_ChildrenU3Ed__23_System_Collections_Generic_IEnumeratorU3CSimpleJSON_JSONNodeU3E_get_Current_mFB2B5F5F93F044ADBF11AF1C59D305BFE295D063,
	U3Cget_ChildrenU3Ed__23_System_Collections_IEnumerator_Reset_mE65CCEC3E7FCE86596AF14C5821DA3D5F76C34E3,
	U3Cget_ChildrenU3Ed__23_System_Collections_IEnumerator_get_Current_m3B0D1EE4EF3C849E2A702C9B9DB6F65FA70890D9,
	U3Cget_ChildrenU3Ed__23_System_Collections_Generic_IEnumerableU3CSimpleJSON_JSONNodeU3E_GetEnumerator_m42B5EADBEE1E083675385176B87BCAB7C4FA0873,
	U3Cget_ChildrenU3Ed__23_System_Collections_IEnumerable_GetEnumerator_mC4F14551458D7F9F3DDC7610F078982D1C04DBD4,
	JSONString_get_Tag_m68B0FF9ADDC3E203E5D60BB10639AEABACA34D44,
	JSONString_get_IsString_m933985E37AE8A887A2039A9BAC7698F083BCD6E3,
	JSONString_GetEnumerator_m1CB9E437FC8622F3FE05D0AC12024D144747E0B8,
	JSONString_get_Value_mEAD2BD372A2C517E83233BA5F6E309745AA5E9B4,
	JSONString_set_Value_mB974D9B82AB8F9FAB84DCA99B8BD4B7C1C08ED00,
	JSONString__ctor_m1DD5FB9A4147F72A0ED5F773FF82FA269241AD19,
	JSONString_WriteToStringBuilder_mDF24D860FBF8E71F6F04799DD70F7700CE41D818,
	JSONString_Equals_m1C60B537E558E6DF85ACF3EF9FF43BF9A3CF5435,
	JSONString_GetHashCode_m979A74F84B4C0F45BF63D75DE1146490F743EE00,
	JSONNumber_get_Tag_m7C6E217E85B6161812496B63E5D371B910AAC856,
	JSONNumber_get_IsNumber_mFABFD0C9C4905CFB34A62700A1BD335F53E4214E,
	JSONNumber_GetEnumerator_m4D13E84756AEED9FCD7EFEEE4D01187DD049C596,
	JSONNumber_get_Value_mBC5AB046D134B1E54C228C9C1C2231F8448CD56D,
	JSONNumber_set_Value_m2264762BBD76F39DDC5DF3160910A44FBEFDE54C,
	JSONNumber_get_AsDouble_m8C004121700A7E7EB2B77ED223187227E33DE60B,
	JSONNumber_set_AsDouble_m8E17AF8C0E9AE0EF6E25D86CB1B119904ADC0558,
	JSONNumber__ctor_m1CE3527102D15EBC3A183E3519895E291CAC1D90,
	JSONNumber__ctor_m39FDDE1A9EFEE9C4F2498E531D12B97AA49A1BA5,
	JSONNumber_WriteToStringBuilder_mD311BC3C1EE3E159C43801EB214F084E567367F2,
	JSONNumber_IsNumeric_mE6C07226FABFDD425449643925B667C05C52D41D,
	JSONNumber_Equals_mC04BB811CCAF20E70AE696AE74ECFDF5DA888688,
	JSONNumber_GetHashCode_m976ADFE41037830524798C7E6AFE08006B5F77AD,
	JSONBool_get_Tag_m82CE84C4C89E157D4DB036B9F0745343C005C338,
	JSONBool_get_IsBoolean_m2671AE98710859611DF47E6BC58E6582C3A5B445,
	JSONBool_GetEnumerator_mA07A10A6111713F7AD09FF03D09A6028556094D9,
	JSONBool_get_Value_mBEA89869448B0B597758D5BF2A3B576CA0BB64E3,
	JSONBool_set_Value_mC960EE4083CA91D0059BE24661AFC06E131E2CFC,
	JSONBool_get_AsBool_mE04224144EAD0A9AD2F3B14BC0C68557A3BF22AC,
	JSONBool_set_AsBool_m88EDF61A5ABBFF3ECF723312852E14F3C60AE365,
	JSONBool__ctor_mBB02E388CFB96B99E84561FCFF68147F00391C58,
	JSONBool__ctor_m8CFB6AA78095EA003AB9B5EDD8932E8E0B01A1B9,
	JSONBool_WriteToStringBuilder_m82C70C80863730E8A22EE7A5B099C765F2E1D91E,
	JSONBool_Equals_m2671F40DA8F1128BA1451FE7066515C6E0C50D45,
	JSONBool_GetHashCode_mC5B59375A9EE9978A5ADD1A24ECEE3FC920836DB,
	JSONNull_CreateOrGet_m68ED6000156701E566B1EA9DDC5284299B0C9105,
	JSONNull__ctor_m909243259F39D10FA6FEB176474DEF9C9972D76B,
	JSONNull_get_Tag_m89A7F368EA6269874235F85E43AE82254AAFD41E,
	JSONNull_get_IsNull_m1174212D6379871AC361EF06FA05DD510FC55595,
	JSONNull_GetEnumerator_m16D254C74386D1A0AB2EFD1DE0EAF409C73B7686,
	JSONNull_get_Value_mB15431220D7D0B45CE002A204DF9E070CF78DBE0,
	JSONNull_set_Value_mAF0CD2E912EF772E0892EB4ABB77294F689CF20A,
	JSONNull_get_AsBool_m6F3817CD49ED7CC10C180D31D84ED4B0151C78CE,
	JSONNull_set_AsBool_m5717BC3921B7DE0683E9160B3816628B5CBC663D,
	JSONNull_Equals_m8A39CAD3A41E9584C434B90A1360C62B3E158DE6,
	JSONNull_GetHashCode_m74BE6286F06C6E7D5E35381E8BD27215117D9061,
	JSONNull_WriteToStringBuilder_mB5B78BFA6A4943319926C1B2AE93F68C7B9B5FFD,
	JSONNull__cctor_m49F440C5442212437C3A1CDAF32B864961BE534B,
	JSONLazyCreator_get_Tag_m1CB86FEA25328F1BE9CC01F6D020C9450E9F466E,
	JSONLazyCreator_GetEnumerator_m720BF0642A079A8BD44F6D650CF4D833DEF67757,
	JSONLazyCreator__ctor_m0B3625D19DDD8DBDBB45822FAABCE266FA4EE694,
	JSONLazyCreator__ctor_m02E2D630C60045F25A3AC001B7A17DF2D5D197B4,
	JSONLazyCreator_Set_mEF6EB64379EBE960F050C24D45EDCA4B6D404958,
	JSONLazyCreator_get_Item_m562D16AE7F1F0CACA5ED050B390B63F98EBC77B1,
	JSONLazyCreator_set_Item_m42894F9D00193BC7138C5D451E1B0BBD1BFE1084,
	JSONLazyCreator_get_Item_mF7AE3ADFBE062BF3B83FECCE0EF10F10996DE0CD,
	JSONLazyCreator_set_Item_m0107997E3B3CB75FACD86FB487C5D9416171CBEC,
	JSONLazyCreator_Add_mA8451EE34FEA0205B6BD6527AB46E5926451F49F,
	JSONLazyCreator_Add_mDC69A4E203B73054072D1575EC4CF20D95064F61,
	JSONLazyCreator_op_Equality_m7C4199B28912BE4C1AE6009F94C6FE07776923C5,
	JSONLazyCreator_op_Inequality_m8E4E9C09E420FE4E5A0AB54B63CFAEF2244B5F3B,
	JSONLazyCreator_Equals_m753939907CFDB1548B0DAAB38E4737EF17B50066,
	JSONLazyCreator_GetHashCode_m878E7AFF42AE5C43F4F643B6AEB25662491316F9,
	JSONLazyCreator_get_AsInt_mE1404FBC99CE4E8EF4ABBE0BDF661206BAC2C44D,
	JSONLazyCreator_set_AsInt_m13146E53FD6A2F7573B752BFF079E0AF6A5FAE74,
	JSONLazyCreator_get_AsFloat_m2600D4B0E1179583EFE268070C66EAC11D380E04,
	JSONLazyCreator_set_AsFloat_m9DCF79C70D4ED3728C12B709A6D95A0F0A057DE0,
	JSONLazyCreator_get_AsDouble_m41D6DF89CD7CEC00F36962068EE072D391EC0B38,
	JSONLazyCreator_set_AsDouble_mB7ABE38136DBEDA7CC9AC12A381322D6C49ADED9,
	JSONLazyCreator_get_AsBool_m7D8AF5879C2C8036916AA6B15E22CB4B80412CF4,
	JSONLazyCreator_set_AsBool_m4DB409DB959182CAA610147A51A2ECDBAFEA6092,
	JSONLazyCreator_get_AsArray_m493C069A3624597885A7B6E00C82E829A84B47C4,
	JSONLazyCreator_get_AsObject_mE01B43B261A6A56F4FCE40AB11F3AAF90B7C292D,
	JSONLazyCreator_WriteToStringBuilder_mC9975859B1C42C9F5E507E604121D10B2FB2D93D,
	JSON_Parse_m9E6F3A67011C765E4352E350D1F400C9A52DC5F6,
	ArduinoBoardType__ctor_m12B1F0FD83B9A6724DCC7B03F31AF39BDDC9501F,
	ArduinoBoardType__ctor_mAF567EFAA44749EC18A37CBC4BF061BA36143196,
	ArduinoBoardType_GetPins_m461C9FCACE56BAA39FAC27BC69A3FD67C3C8B287,
	ArduinoBoardType_GetValues_mCE7F52EEC113B65400C345638CAD36ACE46009D2,
	ArduinoBoardType_GetPin_m0756211D53BCB27E8D1EA22CB5457A80B05202D0,
	ArduinoBoardType_GetPin_m715C1325CEC6946F6AA957C3E8CCA083A617D778,
	BoardsTypeList_get_Boards_m9B2355F3DC58D45CC0D5DE7C0506ADF810E0BAAB,
	BoardsTypeList_set_Boards_m68452F7F541BA61CE759D806DE81BEC10F5A861F,
	BoardsTypeList__ctor_m1D055C57F69D4E3432322BCE4A5AA021CC62F468,
	BoardsTypeList_ListToNames_mF1F7E37C188E98DA8BEBE1118808FFB9E5342BD0,
	BoardsTypeList_GetBoardFromName_m6864B73B71EE8C2BD9BC087230AB6A768E1A6A53,
	BoardsTypeList_GetBoardFromId_m2DBC7B3ABA3C9D07544B66C868EBB4C2BDAB0CB0,
	BoardsTypeList_GetBoardIdFromName_mBBC17CE3DC49E5E2BB434FE84CF0A036D7182FAB,
	BoardsTypeList_GetBoardName_m5EACB85F15561286663279126E1B55031A94A0FA,
	BoardsTypeList_IsWifiBoard_m11DC5AEA40B9D7D1E07D59F2746D089F89F7AF58,
	BoardsTypeList_addCustomBoardType_mA8E042B625A2965832D9AFB07BF55CF6FE5FF5A8,
	U3CU3Ec__DisplayClass6_0__ctor_m6C0D46713F53CDFDB5882E8A6A7815138027C7D9,
	U3CU3Ec__DisplayClass6_0_U3CListToNamesU3Eb__0_m54E2862F3E3D1A0F189E5A6ABF384704061F45BB,
	U3CU3Ec__DisplayClass7_0__ctor_m8A1EAB2A8AB3F5C4F402BEE96B732718D9EB1A93,
	U3CU3Ec__DisplayClass7_0_U3CGetBoardFromNameU3Eb__0_m1F5AFF5DDB6B508E5D3A51CC0808AA8CAE1FC797,
	U3CU3Ec__DisplayClass9_0__ctor_m399234551E1B3911A9AF7E23A3F974ECF6169232,
	U3CU3Ec__DisplayClass9_0_U3CGetBoardIdFromNameU3Eb__0_m4D43C729BACEFFA9F879821C068319A79FDD17EF,
	UduinoConnection_DesktopSerial__ctor_mB109344083E289FE23BDA76D31E4C6CE2ACAFC6E,
	UduinoConnection_DesktopSerial_FindBoards_mDC9272EC076A744392C3C2EE6D0761D9E0AB36FD,
	UduinoConnection_DesktopSerial_GetWindowsPortNames_m985B4862043B5FB4889744395D9B75C19F711324,
	UduinoConnection_DesktopSerial_GetUnixPortNames_mFE32941BC55ED921682C10A792A73BE05F9D7F91,
	UduinoConnection_DesktopSerial_Discover_m1A237CC80C29D0456F544199E24C2A4DC186076F,
	UduinoConnection_DesktopSerial_OpenUduinoDevice_mE6416AAD3E74E64B4840537CE385E57AACBF7919,
	UduinoDevice_DesktopSerial__ctor_m22C4E6BF3E80DEE0022934FAD50B29050189B27D,
	UduinoDevice_DesktopSerial__ctor_mCCE2934EB2B2B756C7E9EBCC4B3187D44AFF6433,
	UduinoDevice_DesktopSerial_Open_m3D7A9B00CB97EBACEF5A4D462F41FAF328000E93,
	UduinoDevice_DesktopSerial_UduinoFound_mCF1A4C8C44B352C0609494E672B55B1E35A5C30E,
	UduinoDevice_DesktopSerial_getPort_m38C821A0392264AC1972ACFAACE21AAD0C33AE32,
	UduinoDevice_DesktopSerial_WriteToArduinoLoop_mD4D7D037B1E768A779FCD8B9E4ADEE8320BD1EE2,
	UduinoDevice_DesktopSerial_ReadFromArduino_m98317BD9738F633B357ADF84208C10EBD79C1B20,
	UduinoDevice_DesktopSerial_ReadFromArduinoLoop_m3C77B1DF3480055084EAB1C671E2DEEE479B45DD,
	UduinoDevice_DesktopSerial_Close_m75546EA237F1023834DFA521126D2DAAEFB64D51,
	UduinoDevice_DesktopSerial_U3CWriteToArduinoLoopU3Eb__11_0_mE2E9BB8B205474E4FF9228FD09340051EE5224FF,
	UduinoDevice_DesktopSerial_U3CReadFromArduinoLoopU3Eb__13_0_m1212BC5509A7852CCDB1838EB2BA57C3E51735F0,
	UduinoConnection_GetFinder_m7A68F659A2C18CE03272C49476BD1C906B12110E,
	UduinoConnection__ctor_mA6A76ED64840BBFAB6FDBB09C245ADAF043E8F48,
	UduinoConnection_Setup_m491C77D595B97A13E2D9718D05898F840EE9F487,
	UduinoConnection_FindBoards_m0BEB194CA06AE8D8101E8354ECAEA0276EB129B1,
	UduinoConnection_OpenUduinoDevice_m1AFC6D3C514081CEC7841B8C0EF2DD3AC261F862,
	UduinoConnection_DetectUduino_mFD52D41058028D94D11F1993C6DB03CA84B767E0,
	UduinoConnection_DetectUduinoThread_m104FA649B9B53F555C4A6FC9C4C6FFBCAA519F74,
	UduinoConnection_DetectUduinoCoroutine_m29582BCE6DAFE24540611E35AA6D73E315D1C167,
	UduinoConnection_TryToFind_m24508C52DA5CD7CE7C3C29D0BA91E804364A9450,
	UduinoConnection_BoardNotFound_m8EF0C2B5F084757A70C0EFE0A6362CCE2416692D,
	UduinoConnection_BoardFound_m98D24B7E4BD096C6856F17C43441E1344CA6C9BB,
	UduinoConnection_ScanForDevices_m78888BD7C6E509594FC07C41DA1BDBAA54F6670E,
	UduinoConnection_Discover_m183E13331894313A696154A857E86E77F01C25AE,
	UduinoConnection_PluginReceived_m25C11167B7A85D50B9807F0C4D03BE683C330F6B,
	UduinoConnection_PluginWrite_mEC6FA44E94D4A8009B67121AABD87E06DE5A3467,
	UduinoConnection_ConnectPeripheral_m2C64D26046AB4D2D4E7C13DDA24ECB0512D74EC4,
	UduinoConnection_Disconnect_m03E2B745C314F49CF576DC6E08F3261E59CB9CD8,
	UduinoConnection_Stop_m5D62E102422EFB77C9AD0D6B98883485622EF569,
	UduinoConnection_CloseDevices_m755B8EAE977BE9ED998368B7C20654F406246087,
	UduinoConnection_CreateDebugCanvas_mDDEB7113102110F2E31CA1D4093B4680C5FEBEBA,
	U3CU3Ec__DisplayClass7_0__ctor_mF5925BB58A685C1E037E027424DB080805F70AF4,
	U3CU3Ec__DisplayClass7_0_U3CDetectUduinoU3Eb__0_m72387E489B01B00B4823EE062316D16BD67EA86B,
	U3CDetectUduinoCoroutineU3Ed__9__ctor_mA443818C937B9A70ED454B73D9961E4E78E509F8,
	U3CDetectUduinoCoroutineU3Ed__9_System_IDisposable_Dispose_mD6148DCAAC66247AC14EDFE29E029B68331755B9,
	U3CDetectUduinoCoroutineU3Ed__9_MoveNext_m2D125C2DF7FCA5869749299442F7B3BF42D1796B,
	U3CDetectUduinoCoroutineU3Ed__9_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m7AFE115A109A06E0D54D24BBC69E995B95B92045,
	U3CDetectUduinoCoroutineU3Ed__9_System_Collections_IEnumerator_Reset_mC0DD27A0F9F747C62CA4D14F02AE00265F6659BE,
	U3CDetectUduinoCoroutineU3Ed__9_System_Collections_IEnumerator_get_Current_m54DEE4971365617122CB2B51AA979B995B47ABCC,
	U3CU3Ec__DisplayClass10_0__ctor_mB1A6A80D0D838D6B8C711A6913098D501C3E08F6,
	U3CU3Ec__DisplayClass10_0_U3CTryToFindU3Eb__0_m9FA9798293603E3D8DC5DE50DD2E52960086FDF9,
	UduinoDevice_add_OnBoardClosed_mC07D3936C9B2E33D425CFDA274545BB9A780AFDC,
	UduinoDevice_remove_OnBoardClosed_m8F8700B7387ED23068FA39CD088B9A9FCCFCEDA9,
	UduinoDevice_add_OnBoardFound_mFD769490B80530AE0F6D05A0F18EFAF5F1CB455B,
	UduinoDevice_remove_OnBoardFound_mC3F62FCB885BFD9BD57C5966A0D654D0C293833E,
	UduinoDevice_getStatus_m28FA6D70C3D7C532903929B07178F4311A731E4D,
	UduinoDevice_getIdentity_mF3394683CBF93A4755CBD11A6A8337CAB53063E4,
	UduinoDevice_setIdentity_m202A2BCE4F62359ABF1667661F5BD3ED7995BAE3,
	UduinoDevice__ctor_m2E4C2048367239D71D91D1629A58DFFB9C66CEC0,
	UduinoDevice_Open_mF08C9FDDFF396B076BFC43DB9463EE6D8F0AB005,
	UduinoDevice_UduinoFound_m5D5292AD1BF872F0E819B59ABE71AA0EF350BAB7,
	UduinoDevice_AddToBundle_m48825EF05C36840AFA2FA7151D0EB18A277FD8D7,
	UduinoDevice_SendBundle_m09E680E9F78165DD30694A6DC4CB19EEC1B201D5,
	UduinoDevice_SendAllBundles_mAE0BC65CC9774BB5EE415A4038660B3DA7F2CBF3,
	UduinoDevice_WriteToArduino_m016FEA1332C488CFAB069C60D572E666113250D3,
	UduinoDevice_WriteToArduinoLoop_m9C704E562AD1BD186CF5677EEFB51A7450C8D0B3,
	UduinoDevice_ReadFromArduino_m2FA92883E5D4AB2E4C80D552D0633CEB4E4BAD5F,
	UduinoDevice_ReadFromArduinoLoop_mC3D44C903937A82D9370BE453EFA8062D88BA7F5,
	UduinoDevice_AddToArduinoReadQueue_m787FCB08A0CF123AC9571ED29677CFAED1330AF2,
	UduinoDevice_AddToArduinoWriteQueue_m33B0DF75C6A8DDE20DC5B13ED41B713BBC8564C3,
	UduinoDevice_MessageReceived_m728EF12D608238D5508981555D9F415D60C7A88C,
	UduinoDevice_WritingSuccess_m7040965EEC4851A13B5BA24F476C4DB4C739632C,
	UduinoDevice_ReadingSuccess_m8EB45DDD803CF132D84E8C8F5FA88C4084B0C08E,
	UduinoDevice_Stopping_m464418BF3AD5F99549A5ADDADFE3868E27C944D1,
	UduinoDevice_Close_m5EDD4A8F6A6F08B22E73A431EF1A819037750407,
	UduinoDevice_OnDisable_m6FF3550DD8E24A6C19CFBFAFBE8F49FA9A5C5746,
	UduinoDevice_ClearQueues_mBADF66AC99C379A9E602E7222F4D3AFE4452A7ED,
	UduinoDevice_OnApplicationQuit_mE35928B65B9111770C8E70D1B3FCEE3A742ABAFF,
	UduinoDevice_IncrementFPS_mC29DC5D888C888457CC0742866ED2E396C8B6035,
	OnBoardClosedEvent__ctor_mF59B98A5543CA8FF2E0ED4ED89648A48C094CF08,
	OnBoardClosedEvent_Invoke_mBF4439D7967499CCB4ABD111D3421F68B881A96C,
	OnBoardClosedEvent_BeginInvoke_m8258F475FAEC98B00E6657E17D461C7F158ED4A9,
	OnBoardClosedEvent_EndInvoke_m5DA4A55A6E9EF2F5423FB41DDE5303ADE733BBB2,
	OnBoardFoundEvent__ctor_mB18FAD23C635DF6B1FCFBFDF4C36F4EEE2E064E3,
	OnBoardFoundEvent_Invoke_mEAB8ABCF77A661AAC95C7DEAF594278EB4E4D5EC,
	OnBoardFoundEvent_BeginInvoke_mDB4BAC865BD2C7BE416FF19AA912D5FF804E7406,
	OnBoardFoundEvent_EndInvoke_mC481AACC9E6672A83E538794E1AD46D956E94C0D,
	U3CU3Ec__DisplayClass41_0__ctor_m782910647DED053F39BB6A1D8AFC17C4473FFB6E,
	U3CU3Ec__DisplayClass41_0_U3CReadingSuccessU3Eb__0_mD2992397DFB0E16543DADA68483F297AC36240BC,
	Pin_get_Manager_m914F7AD632F7B9C0EED6E11110B4C2F0CB4CA1AA,
	Pin_set_Manager_m04D51CE19F9099065C768F7DA96FF78831C367E1,
	Pin__ctor_mEEFC631D95FB17F0DF21552B1113F6450F78074C,
	Pin_Init_m99AC3EFBEBF1827AD5FBDC55EC2B1B3329584E1C,
	Pin_WriteReadMessage_m75D95C3069EFC38FCEA50715EE6D3BB78E7CAFAE,
	Pin_WriteMessage_m2672E2629C24A4F925D9DBDA3D7DD44D6AFCCCF8,
	Pin_PinTargetExists_mAD55094A030D2093D751AA98A5F254F4B6E1DB87,
	Pin_OverridePinMode_mE7801609FEC3CCCF923C80E331A9C13F8D781AD0,
	Pin_ChangePinMode_mD06F1998C7455E8FCBE95A8E4F428E33BACD2F09,
	Pin_SendRead_m935AB0498ED59874BF8B90332EF08A673D006313,
	Pin_SendPinValue_m047100B7E8BE59C845DE44D86B187A5142B30C07,
	Pin_Destroy_mCA0AD86D0495E5FB511D01611267687D56A0621B,
	Pin_Draw_m7E3598B8BCB4F6E46691603A52CE1F10DA3A5807,
	Pin_ParseLastResults_m7CB086C926E4C2CEA9DCF191E7A044CFBBF6A469,
	Pin_ParseIntValue_m72899F68638D8979496C829332E40439BD95BB2E,
	UduinoConnection_Wifi__ctor_mE9B48C178F58C16DA6D6121DEACC614F4AF13F0C,
	UduinoConnection_Wifi_FindBoards_m0FB24E5C9A7D43879E23A1D5A9ABC10E6F0B00B2,
	UduinoConnection_Wifi_Discover_m135B5FF8B07467CF6EEF8841CC94C7AB2C872B83,
	UduinoConnection_Wifi_Stop_m26D53FC141B4D05ADB3E5E5AE4033FE3ABE7821A,
	UduinoDevice_Wifi__ctor_mC597E948A2BBD705B5B03C2D00CBB32501A4FBA0,
	UduinoDevice_Wifi_StartNetwork_m37FD82F2BC28F5A90192B1B95C1D09207AD23B8E,
	UduinoDevice_Wifi_UduinoFound_mF9A8F05852417C1E184F1A7A78206007620C06A3,
	UduinoDevice_Wifi_WriteToArduinoLoop_m2621948D4325DE94D40452EA0263D5F32D7A21DF,
	UduinoDevice_Wifi_ReadFromArduino_m8CFC3C7C38DBB1D747014D060951F77E144ADD56,
	UduinoDevice_Wifi_ReadFromArduinoLoop_mC321453D6936C551096BE4E79D5081C8BFE8FB05,
	UduinoDevice_Wifi_Close_mAC441E50D2AF9404EF7544E4D3144621441D8B8B,
	BLEDeviceButton_Interface__ctor_mC5E05340CF037447D582C8C76F03060ED1D76B45,
	BLEDeviceButton_Interface_CanConnect_m1ABE407F0FC067834329CD82C95B9D29E127F3D7,
	BLEDeviceButton_Interface_Connecting_m03DF234C57A810DF5F76A0F7AD5289F561813326,
	BLEDeviceButton_Interface_Connected_mF8DA5ACCFDF42EF0DA235FC63BD04CB8DC886201,
	BLEDeviceButton_Interface_Disconnected_m742B191DF6C7C0F85DC04EB39184AE30C42F332A,
	UduinoInterface_Bluetooth_Awake_m1FB4FF2149285E2E1A37F420708A655BE909E9F6,
	UduinoInterface_Bluetooth_Read_m8B5986423984A7F2C78E58B3AED612B6D9ACB032,
	UduinoInterface_Bluetooth_SendValue_m13CC100B01E1651BD92492FF15C92C8D61817C3D,
	UduinoInterface_Bluetooth_LastReceviedValue_mDB3AA5B490301346601C31176103A0488FF2CE2C,
	UduinoInterface_Bluetooth_SearchDevices_m3ED98BAFA3AFE1F5650B6BA3971081EEB1F2BE77,
	UduinoInterface_Bluetooth_StartSearching_mBEE5AE887F79B1DEB620FE7DABEB09FFD79D8C83,
	UduinoInterface_Bluetooth_StopSearching_mBBC209A2313A0DEA9F394BE888AD6DC15FACCBB7,
	UduinoInterface_Bluetooth_StartTimer_mEC2598FFC8255FCAE246E7CECA53FC1789582586,
	UduinoInterface_Bluetooth_StartSliderCountdown_mF3C9F748761435E40F4647326ECAA25A13FDED21,
	UduinoInterface_Bluetooth_SendCommand_m28D2BED603E6D95DA06FF4120768C5946012D966,
	UduinoInterface_Bluetooth_StopTimer_m72134CBCB34D923214E4EB6F75CDC7EFDAD1E862,
	UduinoInterface_Bluetooth_ClearPanel_m56994F927ACB30B359C08392C8CBEBDDD2A01F51,
	UduinoInterface_Bluetooth_AddDeviceButton_mACD2AF5D3AFFC5FCE2D5FDD6B4BA2E2740DECE1E,
	UduinoInterface_Bluetooth_DisplayDebugPanel_m16678C94D08EAEEFE3DE0A0966F55CF76B0E45D5,
	UduinoInterface_Bluetooth_UduinoConnecting_m95CFF3C2A87EEBD20D3FE96E2AC6687D2DEBA8AF,
	UduinoInterface_Bluetooth_UduinoConnected_m2FBEE4DC3F2AEDFAD57D88ACC6AD432030C23F98,
	UduinoInterface_Bluetooth_UduinoDisconnected_m4359B844A05DCF00DB51E4AB8FE22DBA23C15309,
	UduinoInterface_Bluetooth__ctor_mB05F94CF6AF34DA266752650977CEE997E655CED,
	U3CStartSliderCountdownU3Ed__9__ctor_mA2D89F644F058BB836362DCBD1E6AD73CC16AEDA,
	U3CStartSliderCountdownU3Ed__9_System_IDisposable_Dispose_mB6A95BF613E86EA8D65B8CDC31A83E5A35EA6968,
	U3CStartSliderCountdownU3Ed__9_MoveNext_mBCCB8DDFA64B1C694BB38CB39ABFB9F3855BFDF6,
	U3CStartSliderCountdownU3Ed__9_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m54563A121C73BB5B708133EA9223409F8D989C6D,
	U3CStartSliderCountdownU3Ed__9_System_Collections_IEnumerator_Reset_mFA72FE20071773788D13F63CA2345EBB479AC51C,
	U3CStartSliderCountdownU3Ed__9_System_Collections_IEnumerator_get_Current_m1B2FFE60BCFA93B50D08132239CE893206F548EF,
	U3CU3Ec__DisplayClass13_0__ctor_m9F0D2D522555E85A2CF13F496C0F4602693B96BA,
	U3CU3Ec__DisplayClass13_0_U3CAddDeviceButtonU3Eb__0_m456F0C15EEEB10704B3267E125164E135D6AB592,
	U3CU3Ec__DisplayClass13_0_U3CAddDeviceButtonU3Eb__1_m11E7D32131A257D3552B26296AF09AA23B5F0DA7,
	Interface_get_Instance_mB030474712C9EA79D35DB43B84EE2514C416BB89,
	Interface_isActive_mA1B7E909AD6E324C74C8493C860190312904A457,
	Interface_Create_m8353137CD136FC294913A2E3F4CC980DA77B30E5,
	Interface_SetConnection_m40BA40E56B5B36FAB34F1D1FF014F93930918BE7,
	Interface_AddDeviceButton_m73FF1027728D4DED1EAA90E4B2BE556754C79E98,
	Interface_SendCommand_m7092C52F038419F52C159888466C446B5CF4D21E,
	Interface_Read_mA632EAD29DBA5FE79BFBF66DDEAEA5998A17ED39,
	Interface_SendValue_mCF115CA5446D75FFF4BD169E028783DAED64B668,
	Interface_LastReceviedValue_m115C0AB34451C7DC7004BFE5F9C5B263606FCC8F,
	Interface_StartSearching_mF9C1722F58425DFD47CB90BFE5D9CF364CB514A3,
	Interface_StopSearching_mBF523CBD87F090E621982ACA8642F8C8EDA2DEA5,
	Interface_NoDeviceFound_m4C563A35CA61D47A938B860B9799940B0EDBF037,
	Interface_DisplayError_m669D1D7A91A94E198C8C83410B489DE1D4D33726,
	Interface_DetectDevice_m4896A600608D057FE22D66CCE5168E36A7268ED4,
	Interface_BoardNotFound_m55EEF8B599834A6EFBAFA9D46764C9146AC21CFE,
	Interface_UduinoConnected_m67AF98268A38FA8D37B978FE6AAFBB0019BFB811,
	Interface_DisconnectUduino_mB36CD5E46FC8C7709012518B7D9183C7D5C11C4E,
	Interface_RemoveDeviceButton_mC71A76591FE69414F204DC0664740573ECE956FF,
	Interface_UduinoDisconnected_m9AE2A4FDC0629DC0519684332808378F6EEF142D,
	Interface_UduinoConnecting_m4EF9819347A54C6ED5F7B92CD20B385896C91A23,
	Interface__ctor_mB88C2E64B64131D822A44FEFCEF555E8E4B6383C,
	UduinoInterface_Awake_m3E66EF2BC4AB5FE0A766A1EE647A0C969DFF212B,
	UduinoInterface_Create_m04D99772A8C02B587ADFE185F7C40BDD293907FF,
	UduinoInterface_OnAwake_m4ACCE60A807D5A56C25645B5F2D0783DD5639DA6,
	UduinoInterface_SetConnection_mB9DB0C47B5A23F738E9350CF82E45621617D214A,
	UduinoInterface_AddDeviceButton_mD157DA1C8C0753636F256954C10C9EECFE7AC9EF,
	UduinoInterface_SendCommand_mB4D53D9674C4F2DDAC459DB212F7441BEC553ED6,
	UduinoInterface_Read_m5B11A171B6918BCEC438C299FE3382B2ADA1C6CD,
	UduinoInterface_SendValue_mD0C48D91043413AF9946254EA0A1A2156E99A03D,
	UduinoInterface_LastReceviedValue_mA474A73B66F8E3ED6AAA2D3F0F9D7E279FB58203,
	UduinoInterface_StartSearching_m3303F5104CF8D17F7AD46B0F87D9B04A589CFFFA,
	UduinoInterface_StopSearching_mAB8667E60B7EFC0E656A3A2E7F606DDCB6A41CB3,
	UduinoInterface_getScanButton_m6FD2DE247DA1341F7BC74E80B264442B30209B80,
	UduinoInterface_getScanSlider_mC7F216BCC0B31907C596F836E82ABF2F6EE5ADFE,
	UduinoInterface_getDeviceButtonPrefab_mD5CC39BBC82A217056BDA511005E3BCBB95920D9,
	UduinoInterface_getPanel_mE0F191B222A708A01514FA85B17CD55B5C9964A0,
	UduinoInterface_getErrorPanel_m88CB20ACB6A2EC25FF4EA30F57E0A9525602DB51,
	UduinoInterface_getNotFound_mD689AA8391D930EE3BAC687DA9B7F2731F5E9BFE,
	UduinoInterface_getBoardButton_mC88FB36B87185E0E81216AB77748E4D6076CB183,
	UduinoInterface_Detect_mB546CED720D6027F19B1E9FBF6D6E95B761A4B61,
	UduinoInterface_NoDeviceFound_m943C8378747C86FAA36E3D266944957639B10E20,
	UduinoInterface_DisplayError_m599C21D783B2BDB270FE91230E377B66CA2FF1AA,
	UduinoInterface_DetectDevice_mD1F744C1A733841DBAC5BD90C712EBE38C229629,
	UduinoInterface_BoardNotFound_m6320E1EFBABB3BA793F8D7E9316FC172F94FEA86,
	UduinoInterface_DisconnectUduino_m4D43E171A82017D942041AE663D042D4DF83F8C1,
	UduinoInterface_RemoveDeviceButton_m80F9421992F9BD84AAA3D311588807C7A1BFDC4D,
	UduinoInterface_UduinoConnected_mBA1D90DA75FBA342C3381B9BA2588F14FA0D6EEF,
	UduinoInterface_UduinoDisconnected_m7271437707957A66140F965E85470B1C7C722864,
	UduinoInterface_UduinoConnecting_mC578F3E1E54DCBAD773275B6CCAB51C71D0BC890,
	UduinoInterface_Destroy_m5D36E0EA79DA7678D5D28D2FC73777ED7699B7D3,
	UduinoInterface__ctor_m158FE32E9144C8F72D86D871A65485AB9B1101CE,
	U3CU3Ec__DisplayClass21_0__ctor_m322D9620A502540F515169E55904A9B54DFB63BB,
	U3CU3Ec__DisplayClass21_0_U3CAddDeviceButtonU3Eb__0_m49952AEC14394DA9910DC0AAAB49C9A8E81D07E2,
	UduinoInterface_Serial__ctor_m82E04CEFE9B8C8913A39EF971206E09B0A9A4755,
	UduinoInterface_Wifi__ctor_mD5C2A40F20D4FC4F0C17AB3C930BF5F3EDD37F30,
	Log__cctor_m741BCF643E8D9A5A9BB117737AFD02D2E1AA32F3,
	Log_Error_m7270ED487C93FC7DAF15CD055B556723842D79AD,
	Log_Warning_m6DCB39FB55894577E86F5FF7E4DDC1A58C3A2DA8,
	Log_Info_mE8402069B4FA317A825839914D6134CC7A6033FD,
	Log_TrimStartString_m560B5441AF734D955E80FD0786F21D6EA639CDED,
	Log_Debug_m0B3DA316003BD25A5F73A72C6850D23898E88969,
	Log_SetLogLevel_mAFB681C6D7A7DD1C220E4D4C1B9BA0E67F8C566F,
	Log_RemoveLineEndings_mC6371D7922271844E0C9A516563092DD6256C4F2,
	UduinoDebugCanvas_Awake_m88B667E00E636159E5A599C450A5E6316769D1DC,
	UduinoDebugCanvas_Log_mA23A387CD5D87DF0463F39C5D7BD9F9A22861EBD,
	UduinoDebugCanvas_OnEnable_m1A7B3237AECDE1E93956BB6D6A73CF38C65764F4,
	UduinoDebugCanvas_OnDisable_mC6904C6F6B731522DFC03F62BD5230D2E1466986,
	UduinoDebugCanvas_Clear_m5B86206A019E6F0F0EC6EE5BBAEF8267B932B94C,
	UduinoDebugCanvas_HandleLog_m63713D941E3390B5D56FB03038F93ADCDD41CBA4,
	UduinoDebugCanvas_Update_m53D68726CF09729923CE144A2FAAC07CA968F8A4,
	UduinoDebugCanvas_CreateCanvasAndText_mD4E52C8B6005CB91ADF068C59ACCAF22ED51A64F,
	UduinoDebugCanvas__ctor_mAE2A3668FA4D96406E1243D2C1773831FE9C12A2,
	UduinoManager_get_Instance_mD8DECC4584AC27B54BB0BE9ACA30ABC83873CF7C,
	UduinoManager_set_Instance_m07D289D9529F7F64E864DCF0D7285BE6F1F014D9,
	UduinoManager_get_BaudRate_m8A7A459B4052548FBAC1F5D3747F84B9A0563181,
	UduinoManager_set_BaudRate_m33B086266FB37389709AEF425250470579CAF0C0,
	UduinoManager_get_ReadingMethod_mB19297CB7D343FCE132C5C89D84D3F1DF9DC4A95,
	UduinoManager_set_ReadingMethod_m08EAD88E6B10581D04E2EF8E1F64A1DC2C45AFC2,
	UduinoManager_get_LimitSendRate_mBD4B166BF7BB3B558F13D7E330584A77809364F1,
	UduinoManager_set_LimitSendRate_m6E5755B0C69731B3AC5921D0F26815A653E1E71C,
	UduinoManager_get_SendRateDelay_m3D2CC5E2FFB6A543C22B18416AFC6BA790F2606F,
	UduinoManager_set_SendRateDelay_mD5B224820AA2D38EA60CD54FC9CF2A23841085C7,
	UduinoManager_get_DiscoverTries_m0745BD271FD93146973C666BCEDF0B540709E4FE,
	UduinoManager_set_DiscoverTries_m83F7AD3357AFDB0366E3AB342A76FC041B9DE5E2,
	UduinoManager_get_BlackListedPorts_m2D813F30A2ACFF450C65E2EFEF9BBE406C9F306E,
	UduinoManager_set_BlackListedPorts_m23C1146F015C6BF06895F56362969ADDB676942D,
	UduinoManager_add_OnValueReceived_m87B6DECE5E9435D3A64C3B398EFE7663091DA9B3,
	UduinoManager_remove_OnValueReceived_m036FB784DE28C096A1C29D0069B08333B9E3A43D,
	UduinoManager_add_OnDataReceived_mF970C5C20843C82CEC47EB06B28B7DC5E2C01BBE,
	UduinoManager_remove_OnDataReceived_mC84D14C3C702A01BEBC85FF4DAFAC74B07546AFC,
	UduinoManager_add_OnBoardConnected_mC364545DEEBF39CDCE5E1E5B78EBC26A8C47CD45,
	UduinoManager_remove_OnBoardConnected_mCBC904D2DC82A30D676E52C8751BD8235BD16B59,
	UduinoManager_add_OnBoardDisconnected_mBD59BEB776DF95AF83DC432D42BEF6C1ADA0689F,
	UduinoManager_remove_OnBoardDisconnected_m19A1B0EA3CDADBBB3FEBE245ECFFAEC49B8B0DB9,
	UduinoManager_get_UduinoWiFiBoards_m8AD29D2F40B762428AAD0FE082E43224DFC93508,
	UduinoManager_set_UduinoWiFiBoards_mAA260D117267FC7CC354180CAEB2AF78CEFCBB2F,
	UduinoManager_Awake_m1C282CAFF2DB0A5E4EF4966BD0CEC0E998DAA619,
	UduinoManager_DiscoverWithDelay_m7ED72FB1901947151F9223758DA35772C68FD99C,
	UduinoManager_DelayedDiscover_m689190128AE4D3D8E93574A0AFF98569240B6965,
	UduinoManager_RestartIfBoardNotDetected_mF9F89FE0CFBDA9F9E0774A2C3BD06C69ED034BF0,
	UduinoManager_UpdateManagerState_m5355B753FEBB4D263B9900622B272F8DE4733741,
	UduinoManager_DiscoverPorts_m32DCFD6E0F083B859E82151A207A1B533180BF65,
	UduinoManager_AddUduinoBoard_mAD0B94FD86C1A5FE707A16DD0CA62122A7E99215,
	UduinoManager_GetPortState_mB5E89A7315A7F27714054327BFC8D6253CC80ABE,
	UduinoManager_hasBoardConnected_mAAC5C51F9D2FE4132F4DEF621B2E30E4C4381556,
	UduinoManager_GetBoard_m79306B9471177C8B5943212377D7DE757F547062,
	UduinoManager_GetAllBoard_m8140F72B762381E616F465566BCEAB39BA5569BB,
	UduinoManager_GetBoard_m5CDE64DAE91BECD8E84E2202E2F5774F20CF8765,
	UduinoManager_GetBoard_mD20418B8C26BEF956308F0DC1634AD3EE5C191E7,
	UduinoManager_UduinoTargetExists_mE8D18D75E9C980FEF5A2E1F9B997A23723C4D899,
	UduinoManager_UduinoTargetExists_mE4824DFA8752C227F10078AA80F77F13702262DD,
	UduinoManager_SetBoardType_m391C7F1B36D0552CC0B966852C793B5BB61AE8F6,
	UduinoManager_SetBoardType_m100B8ACC231654ADB9D3CC0A9E192C1647CD3410,
	UduinoManager_SetBoardType_m8DA735585D961E7195983D0ED56FAADE3872ADE8,
	UduinoManager_GetPinNumberFromBoardType_m330FD92CDF69CC8492A9C92DE5E3AFDC3D916C0E,
	UduinoManager_GetPinNumberFromBoardType_m93A332E7383DAFA5757FFA76EE0D6303371ECB53,
	UduinoManager_GetPinFromBoard_m7382C9C13DDD42FB5BE68261E8B7853951EA60DB,
	UduinoManager_GetPinFromBoard_mA5D7CD24C3BA158499E7B94E742D6F0077E6DB3B,
	UduinoManager_isConnected_mF5905E1346E536D5BE5FC942284E499EF795754A,
	UduinoManager_pinMode_m4F92F3E359AB3D17DB12828BDFA14325A1D5C842,
	UduinoManager_pinMode_mCA441C2CA751DF84A3C06C5C7519BB6DBD68EB2D,
	UduinoManager_pinMode_mD950E7FA527D1942A817759F6384B2D12DC6B7F3,
	UduinoManager_pinMode_m954B30A7D27E02B219FCA058392CBC00A50C67E4,
	UduinoManager_PinValueToBoardValue_mA5915AEB02B0B74CC133F991CAA926A04B070DF8,
	UduinoManager_InitPin_m468E8629D0CD83F3BD028F678DCFB502D8F3DBF9,
	UduinoManager_InitPin_mDD6D048E7513F3A53B2878F9B08CE8A06DEFD508,
	UduinoManager_InitPin_mECF0C90297C718F2DF2CF869C15249AF7DD23C5B,
	UduinoManager_InitPin_mAE19E9F602BF7FE88CC83F6278C9C4C6A8FF6546,
	UduinoManager_InitAllPins_m6EBAEB38BF1F96D0D7E739343CD23B16D2E6D2F7,
	UduinoManager_InitAllArduinos_mF1A765604E6B52A929A243D06FBCDA4371B6A806,
	UduinoManager_InitAllCallbacks_mD7C02C4037130151CEA5D6673CF95AEA966111E5,
	UduinoManager_arduinoWrite_m139A48E1A16FC3A84142C92AAF3305A745A2BD93,
	UduinoManager_digitalWrite_m529836DAEB7886854531EA84F2C6F5CB6A76CBCB,
	UduinoManager_digitalWrite_m98C76698A8F5FFD78A0B899FE135C7A74581D54A,
	UduinoManager_digitalWrite_mEB5AAF0AE3EB8CAEBA2856A0C4FC0CE937D82359,
	UduinoManager_digitalWrite_mA3FF63B71873294FE91595C89EBA472DD2974668,
	UduinoManager_analogWrite_mE6D68AE27E09A3545D96FF077D95184C4530269C,
	UduinoManager_analogWrite_m9A9BB3EAFF4D6DE2D95680A5972DDFCCDDCA8285,
	UduinoManager_digitalRead_m4949DF563F731EF497E4594F06670EF23835F13B,
	UduinoManager_digitalRead_m1720191426905756F368F6752089889F8579B600,
	UduinoManager_digitalRead_mC49875D6030D27CDACE6837A4F18114421ADA937,
	UduinoManager_digitalRead_m07409773D153E03A7AC2AD6AFA27DE71D57AEE54,
	UduinoManager_analogRead_m4EF12F5600ABA034344F7E1F514211B1EEDCC0F4,
	UduinoManager_analogRead_m0AFBEE34347272E0E9839E12660EA675FE04F290,
	UduinoManager_analogRead_mAF749A5A5C5EAB7568057D15B80B10178982BC53,
	UduinoManager_analogRead_mBAC10662BAF552EF6B8E9252C18B0AA86E84BE78,
	UduinoManager_dispatchValueForPin_mCF9C7154F6B4DE415D14891C68D82C56E425F178,
	UduinoManager_Read_mFC6F8AA31F92151ED6C9DD26544DF042446D938C,
	UduinoManager_Read_m96DFCF5D555F7350D455C872B0F70DBDBFAA311A,
	UduinoManager_DirectReadFromArduino_m326966EDE30233F529F5E9445C85A24E78E524F6,
	UduinoManager_Read_mFF9BC9579DBF02A3CC78AA488B0F7A72E74ADC6A,
	UduinoManager_Read_mF2032C5BEA7B695D0E3B8858E416A5DC3B076F42,
	UduinoManager_sendCommand_m488382E83AA091FAEA3E33F31819C36739419C8C,
	UduinoManager_sendCommand_mE6736FB202B38232C418B41EA3D1AF6A1AF39F96,
	UduinoManager_sendCommand_m102DDD91C2310B54DFF5E98CF3A1AD7C8B27BE59,
	UduinoManager_Write_m2D8FD69772570B0DEFD3BA086874338EB7941551,
	UduinoManager_Write_m23E3BFF9BE82448BB19C9C27AC95F1EBFFAC06E0,
	UduinoManager_BuildMessageParameters_mEC6BEF98C679579E190352948285EC0C0ECBCF84,
	UduinoManager_SetReadCallback_m5CD59885FA8DF1C2FE7CB12DACDD9FF507D6C693,
	UduinoManager_SetReadCallback_mA85C33A227DE88CB7668DAA108EC289C78F90C9B,
	UduinoManager_SendBundle_m08D2163304F16F9BB79B842C6445A930D3420D11,
	UduinoManager_SendBundle_m44087F083729C719A6368283A528E103D8902AC5,
	UduinoManager_AutoSendBundle_mA51BC80C61A3AAD1AB400B0B82AF6994B39A0CBF,
	UduinoManager_AlwaysRead_m9C7E1C15CB2DF529A68E7BAC402F2510CFB2DE1D,
	UduinoManager_AlwaysRead_mFFF8259DDB890300486FFA93F3093D6B7819E914,
	UduinoManager_ExtensionIsPresentAndActive_m6020EB1547D1C8F156C2AFED71BB24ADCF963475,
	UduinoManager_ExtensionIsPresent_m48FD6B61C17A5C03E0000E5C3798736ECC317798,
	UduinoManager_StartReading_m9A1F61FEC1A62283C894339762B2C6E17E58FAD6,
	UduinoManager_StartThread_mC32B06EEB8CA3F57E6CB69860EF6DE64EB7FFBC2,
	UduinoManager_StopThread_m2932B0697D8F7BD04202CDC14333B2066F692C91,
	UduinoManager_IsRunning_m05261CF3CBCF190F3325333FA4D5C321B83F10AF,
	UduinoManager_Update_m69307829E896B7C37C297DA39C29FECDE0F31495,
	UduinoManager_ReadPorts_mA774AF4B36D6AE963E7F86A355D43EC7C15CFDB8,
	UduinoManager_ReadWriteArduino_m43E6D13CC7332B6E100F582A41537D6BE766D0DB,
	UduinoManager_CoroutineRead_mA7FF57228C45FC49EB873151654259452D3B757E,
	UduinoManager_TriggerEvent_m7E3AC2AB6AF3260333027BFDC72908681EDFF341,
	UduinoManager_InvokeAsync_m43F222CBD87FF326BA8A0725394C795527659AEB,
	UduinoManager_CloseAllPorts_mCACD844A6BFA39FA1E28FB353055EAB7381B2B7B,
	UduinoManager_CloseAllDevices_m5E176430F0908AAB2E609D296B10982C1112FAE8,
	UduinoManager_CloseDevice_m4F5C14A5FF222D313D28F7A5EB05EA16C7546CF1,
	UduinoManager_CloseDevice_mE3CDD8284077A792BDD39FBC375A691803B344AA,
	UduinoManager_OnApplicationQuit_mCBADFF42F24C1804854904CBAA252A4D4F72E178,
	UduinoManager_OnDestroy_m44BFA61CE4234167D447E352A2388A4FC411136F,
	UduinoManager_OnDisable_mEDAA3D2DB120F09A7E2CFED97843F4F6CDF45FA6,
	UduinoManager_FullReset_m2A538BFA089324D9A8B46265D254AFF9067856F3,
	UduinoManager_DisableThread_mEC708E811500DF7AD3A20020D54A426502ABE642,
	UduinoManager__ctor_m8D8933D6FA6B5D751F9183048A6F87EF338A4D24,
	UduinoManager__cctor_m81960A934FA3119D975F45D540E8C3DA3A06DA50,
	BoardAlreadyExistException__ctor_m666F892055104ECAA15394D08BB56F11D73DE8A6,
	eventValueReceived__ctor_m676C2EBB7C7C190B041EE18ED18A5B75FFC4F90A,
	eventBoard__ctor_m7127F7C0E5A74EFEB7BDA8434208D0373D95C21E,
	OnValueReceivedDelegate__ctor_mEB84C72B2B62F410C144B0AE44C31BEC7201B57D,
	OnValueReceivedDelegate_Invoke_mCDBDDCC8170E7CEFAB37044C92F0BE34CC05CF06,
	OnValueReceivedDelegate_BeginInvoke_m304000A40163F88E1E81507B008F9DD0D2E20C9C,
	OnValueReceivedDelegate_EndInvoke_m0D148C88E59DE19818A16B18346D05849468D16B,
	OnDataReceivedDelegate__ctor_mCC8A330689DF5BA02041E04F0036150E0ED8E997,
	OnDataReceivedDelegate_Invoke_m47894B6E7A5A8AA4343CA37DE51101482DFA030A,
	OnDataReceivedDelegate_BeginInvoke_m11AEBD584BA42EAB21046DE647DDD5392F17B93F,
	OnDataReceivedDelegate_EndInvoke_mFCDB25FEFEA8A0CC7B053582ECDA19A81E7341B0,
	OnBoardConnectedDelegate__ctor_mAE57DFEC17DF7496233C2E2D598DD9453A22364D,
	OnBoardConnectedDelegate_Invoke_m3385E7D15B65841CC9F8BF4A98B37828B8797CF4,
	OnBoardConnectedDelegate_BeginInvoke_m97A3D60A772C7C08335EB7FD009AEB90B4BB068C,
	OnBoardConnectedDelegate_EndInvoke_m61BE22DB05506ED24F422603206449641CB7B914,
	OnBoardDisconnectedDelegate__ctor_m4908EB6CB0FD10852AC106D2AA50FA0CEBFA8D28,
	OnBoardDisconnectedDelegate_Invoke_mE536F2515C632077F3AA2A7163881312CFD8F26A,
	OnBoardDisconnectedDelegate_BeginInvoke_m31FD5D30A09FC582A0E4208B46C4457CF2D00441,
	OnBoardDisconnectedDelegate_EndInvoke_m67A344995ADEE3D2814260C4CB32169E8B303142,
	U3CDelayedDiscoverU3Ed__94__ctor_mCC5404B89F6577171AEC7B3AD035F76F3BDD127E,
	U3CDelayedDiscoverU3Ed__94_System_IDisposable_Dispose_m10732F0E759717BC106729299B70D1F5D74F1464,
	U3CDelayedDiscoverU3Ed__94_MoveNext_mC378C49DBF219927D9B35BE030A4AA484169DC48,
	U3CDelayedDiscoverU3Ed__94_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m95508F1AB23820B034E65556B4A31A6470AF2D72,
	U3CDelayedDiscoverU3Ed__94_System_Collections_IEnumerator_Reset_m91EC5B76C30D3F56637C6D66D73B97A5E4DE3431,
	U3CDelayedDiscoverU3Ed__94_System_Collections_IEnumerator_get_Current_m977C60D7E563738228AB9199F945441F0F7BA9ED,
	U3CRestartIfBoardNotDetectedU3Ed__95__ctor_m7C2BA58897EA88BD33660740E16ABE4B9414F16A,
	U3CRestartIfBoardNotDetectedU3Ed__95_System_IDisposable_Dispose_mDD0FB3788C9B34D4456492250E80BB4C2742B645,
	U3CRestartIfBoardNotDetectedU3Ed__95_MoveNext_mE9265D3D799E84DB99CE2A83A893C0D352636E74,
	U3CRestartIfBoardNotDetectedU3Ed__95_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mBE24DD915D890E41B1DA4DF15A68B9BAAB5931B9,
	U3CRestartIfBoardNotDetectedU3Ed__95_System_Collections_IEnumerator_Reset_m546F50D94B924AC3A0DEE31647B16625FA714052,
	U3CRestartIfBoardNotDetectedU3Ed__95_System_Collections_IEnumerator_get_Current_m8443F19DA412CF7CA9308736ECAF29A47F7B2AA6,
	U3CAutoSendBundleU3Ed__158__ctor_m8D78C399578EC0481409F19CFA67D937A33D1A30,
	U3CAutoSendBundleU3Ed__158_System_IDisposable_Dispose_m19861D441E86757A084F4B355784130B9EAB816C,
	U3CAutoSendBundleU3Ed__158_MoveNext_m4351D742C9FD2C1DA44574908843ECE93E0C8387,
	U3CAutoSendBundleU3Ed__158_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m5BCC91B0E37B98FD040F8972A70256A72A8E1482,
	U3CAutoSendBundleU3Ed__158_System_Collections_IEnumerator_Reset_m78AEB46D8407B72479B106AE8D98EE02C62C1A5A,
	U3CAutoSendBundleU3Ed__158_System_Collections_IEnumerator_get_Current_mF9D7E35FC12E0D345F8BCA68598E0C035923610B,
	U3CCoroutineReadU3Ed__173__ctor_mD60DA2B0781A5B5EB321DAAAF418339314ADD1F0,
	U3CCoroutineReadU3Ed__173_System_IDisposable_Dispose_m27E6AC4F8C31E2360CBE7EB7751E66544EA3571B,
	U3CCoroutineReadU3Ed__173_MoveNext_m63F731E33699A086E4355C9BFFE4B517438D487F,
	U3CCoroutineReadU3Ed__173_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m1A77412D00611DB223923590C3361F233CFF171C,
	U3CCoroutineReadU3Ed__173_System_Collections_IEnumerator_Reset_mD5C4EDD3F1CD015E293A7A91EB55181A4A2FE5F0,
	U3CCoroutineReadU3Ed__173_System_Collections_IEnumerator_get_Current_m83FD71A9322855CAFC394868629C834C218D3C51,
	U3CU3Ec__DisplayClass174_0__ctor_m34D528D848A071D3FCB966BE91537AB00C4BC188,
	U3CU3Ec__DisplayClass174_0_U3CTriggerEventU3Eb__0_m22AA48E728ED4FE3A64AAB5B6E7DA690AD136E8E,
	UduinoVersion_getVersion_m687281B5392A04216C7CB1FFAD05431A189AC808,
	UduinoVersion_lastUpdate_m9CC3C81F35B083CF796F68CEEB2D6E0FA16711B8,
	UduinoVersion__cctor_mDA54E9963892A8D473757549EA1B9CB9DED03A50,
	NULL,
	NULL,
	NULL,
	IsPresentDictionnary__ctor_m29DF97F4B0DED41FBB74E2CF5653D748F47D4C6B,
	IsActiveDictionnary__ctor_mDE82022306954DF532F35E6D92127D8595C444C4,
};
extern void Enumerator_get_IsValid_mBC273331DC1699FF46BD3621AE5059A54AD98BA6_AdjustorThunk (void);
extern void Enumerator__ctor_mF21239C69620D815F8CD34F022BE18E9DAF9CB10_AdjustorThunk (void);
extern void Enumerator__ctor_mAC4ED0FA4B083E2652E865A41EA5C74A49478EFE_AdjustorThunk (void);
extern void Enumerator_get_Current_mDE6750203413E1069D0520793D6AA0B2527CB20E_AdjustorThunk (void);
extern void Enumerator_MoveNext_m238CF072385A1106BEDEFCE33BA2B0DBE999758A_AdjustorThunk (void);
extern void ValueEnumerator__ctor_mCC61CE3EDCF1AC94A84E031F2E89F8054C94A015_AdjustorThunk (void);
extern void ValueEnumerator__ctor_m122732DF448B45E8E82956E07AC8314C60E28C29_AdjustorThunk (void);
extern void ValueEnumerator__ctor_m7BA4BAD5FEBAC4054F71575B728DC27EC4080F0A_AdjustorThunk (void);
extern void ValueEnumerator_get_Current_mAA24A52FDEB7160BD268193175388EACB41B7CE2_AdjustorThunk (void);
extern void ValueEnumerator_MoveNext_m5B596A2EF2FF395EDA8F5CAB97C0789498D250C9_AdjustorThunk (void);
extern void ValueEnumerator_GetEnumerator_m765261287A2C0AEF757B94994826F43951387E4C_AdjustorThunk (void);
extern void KeyEnumerator__ctor_m6EA81E2BED4CA5194A7306D8B324F7356E37F80A_AdjustorThunk (void);
extern void KeyEnumerator__ctor_mA6338E82A9F8AA19A1744352B4FE54103AD70405_AdjustorThunk (void);
extern void KeyEnumerator__ctor_m526EA1364C367B83C931F4208CDD816BD02810EA_AdjustorThunk (void);
extern void KeyEnumerator_get_Current_m8FBFEE52D4438AAF3E10AB4370B34FBB8E66B3C2_AdjustorThunk (void);
extern void KeyEnumerator_MoveNext_m42FE2CEE808A7E065895BA333B7FBD2F3AEE032F_AdjustorThunk (void);
extern void KeyEnumerator_GetEnumerator_mD4687B4D6D10E4D6870CBBECC680689A62A95C0B_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[17] = 
{
	{ 0x060000F7, Enumerator_get_IsValid_mBC273331DC1699FF46BD3621AE5059A54AD98BA6_AdjustorThunk },
	{ 0x060000F8, Enumerator__ctor_mF21239C69620D815F8CD34F022BE18E9DAF9CB10_AdjustorThunk },
	{ 0x060000F9, Enumerator__ctor_mAC4ED0FA4B083E2652E865A41EA5C74A49478EFE_AdjustorThunk },
	{ 0x060000FA, Enumerator_get_Current_mDE6750203413E1069D0520793D6AA0B2527CB20E_AdjustorThunk },
	{ 0x060000FB, Enumerator_MoveNext_m238CF072385A1106BEDEFCE33BA2B0DBE999758A_AdjustorThunk },
	{ 0x060000FC, ValueEnumerator__ctor_mCC61CE3EDCF1AC94A84E031F2E89F8054C94A015_AdjustorThunk },
	{ 0x060000FD, ValueEnumerator__ctor_m122732DF448B45E8E82956E07AC8314C60E28C29_AdjustorThunk },
	{ 0x060000FE, ValueEnumerator__ctor_m7BA4BAD5FEBAC4054F71575B728DC27EC4080F0A_AdjustorThunk },
	{ 0x060000FF, ValueEnumerator_get_Current_mAA24A52FDEB7160BD268193175388EACB41B7CE2_AdjustorThunk },
	{ 0x06000100, ValueEnumerator_MoveNext_m5B596A2EF2FF395EDA8F5CAB97C0789498D250C9_AdjustorThunk },
	{ 0x06000101, ValueEnumerator_GetEnumerator_m765261287A2C0AEF757B94994826F43951387E4C_AdjustorThunk },
	{ 0x06000102, KeyEnumerator__ctor_m6EA81E2BED4CA5194A7306D8B324F7356E37F80A_AdjustorThunk },
	{ 0x06000103, KeyEnumerator__ctor_mA6338E82A9F8AA19A1744352B4FE54103AD70405_AdjustorThunk },
	{ 0x06000104, KeyEnumerator__ctor_m526EA1364C367B83C931F4208CDD816BD02810EA_AdjustorThunk },
	{ 0x06000105, KeyEnumerator_get_Current_m8FBFEE52D4438AAF3E10AB4370B34FBB8E66B3C2_AdjustorThunk },
	{ 0x06000106, KeyEnumerator_MoveNext_m42FE2CEE808A7E065895BA333B7FBD2F3AEE032F_AdjustorThunk },
	{ 0x06000107, KeyEnumerator_GetEnumerator_mD4687B4D6D10E4D6870CBBECC680689A62A95C0B_AdjustorThunk },
};
static const int32_t s_InvokerIndices[822] = 
{
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	5261,
	5261,
	6698,
	6698,
	6698,
	6698,
	6569,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	6698,
	6698,
	6698,
	6698,
	5261,
	6698,
	6698,
	6698,
	6698,
	6698,
	5261,
	5261,
	6698,
	6698,
	6698,
	6698,
	5261,
	6569,
	6698,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	6698,
	1469,
	6698,
	6569,
	6698,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	7443,
	5261,
	6698,
	6698,
	2870,
	6698,
	6698,
	5261,
	6698,
	6698,
	6698,
	5261,
	6698,
	6698,
	6569,
	6698,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	6698,
	2870,
	6698,
	6698,
	6698,
	6698,
	5261,
	6698,
	6698,
	6698,
	6698,
	6698,
	2870,
	6698,
	6698,
	6698,
	2870,
	5261,
	6698,
	6698,
	6698,
	5261,
	6698,
	6698,
	2870,
	6698,
	6698,
	6698,
	6569,
	2870,
	6698,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6569,
	6698,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	2870,
	6698,
	5261,
	5261,
	6698,
	2605,
	6536,
	6618,
	6618,
	6618,
	2870,
	5261,
	5261,
	6698,
	6698,
	6569,
	6698,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	5261,
	6698,
	2870,
	6698,
	6698,
	2870,
	6698,
	6698,
	6698,
	6698,
	6698,
	0,
	3932,
	2605,
	3939,
	2870,
	6569,
	5261,
	6536,
	6618,
	6618,
	6618,
	6618,
	6618,
	6618,
	6618,
	5305,
	2870,
	5261,
	3939,
	3932,
	3939,
	6569,
	6569,
	6569,
	3932,
	0,
	0,
	6569,
	6792,
	6793,
	6486,
	5182,
	6536,
	5230,
	6628,
	5316,
	6618,
	5305,
	6569,
	6569,
	10821,
	10821,
	10811,
	10600,
	10831,
	10939,
	10817,
	10657,
	10829,
	10895,
	10778,
	9423,
	9423,
	4427,
	6536,
	11786,
	10821,
	8120,
	10821,
	6698,
	6618,
	4939,
	4941,
	6333,
	6618,
	4939,
	4941,
	5513,
	6569,
	6618,
	6793,
	4939,
	4941,
	5513,
	6569,
	6618,
	6792,
	5261,
	6333,
	6569,
	6618,
	6698,
	6569,
	6698,
	6569,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	6569,
	6569,
	5230,
	6698,
	6618,
	6698,
	6698,
	6569,
	6698,
	6569,
	6569,
	6569,
	6618,
	5305,
	6536,
	6618,
	6791,
	3932,
	2605,
	3939,
	2870,
	6536,
	2870,
	3932,
	3939,
	6569,
	1008,
	6698,
	5230,
	6698,
	6618,
	6698,
	6569,
	6698,
	6569,
	6569,
	6569,
	6618,
	5305,
	6536,
	6618,
	6791,
	3939,
	2870,
	3932,
	2605,
	6536,
	2870,
	3939,
	3932,
	3939,
	6569,
	1008,
	6698,
	6698,
	4158,
	5230,
	6698,
	6618,
	6698,
	6569,
	6698,
	6569,
	6569,
	6569,
	6536,
	6618,
	6791,
	6569,
	5261,
	5261,
	1008,
	4427,
	6536,
	6536,
	6618,
	6791,
	6569,
	5261,
	6486,
	5182,
	5182,
	5261,
	1008,
	10895,
	4427,
	6536,
	6536,
	6618,
	6791,
	6569,
	5261,
	6618,
	5305,
	5305,
	5261,
	1008,
	4427,
	6536,
	11786,
	6698,
	6536,
	6618,
	6791,
	6569,
	5261,
	6618,
	5305,
	4427,
	6536,
	1008,
	11833,
	6536,
	6791,
	5261,
	2870,
	5261,
	3932,
	2605,
	3939,
	2870,
	5261,
	2870,
	9423,
	9423,
	4427,
	6536,
	6536,
	5230,
	6628,
	5316,
	6486,
	5182,
	6618,
	5305,
	6569,
	6569,
	1008,
	10821,
	1030,
	2870,
	6569,
	6569,
	3626,
	3652,
	11786,
	11016,
	6698,
	6569,
	3939,
	3932,
	3652,
	3932,
	4395,
	856,
	6698,
	5261,
	6698,
	4427,
	6698,
	4427,
	6698,
	5261,
	6569,
	6569,
	5261,
	3939,
	5230,
	495,
	6698,
	6698,
	6569,
	6618,
	1947,
	4469,
	6698,
	6698,
	6698,
	8461,
	5261,
	6698,
	5261,
	3939,
	5261,
	5261,
	3939,
	2089,
	4427,
	5261,
	6698,
	6698,
	5261,
	5261,
	2085,
	6618,
	6698,
	6698,
	6698,
	6698,
	6698,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	6698,
	6698,
	5261,
	5261,
	5261,
	5261,
	6536,
	6569,
	5261,
	5230,
	6698,
	6698,
	2870,
	5261,
	6698,
	1247,
	6618,
	1947,
	4469,
	5261,
	4427,
	5261,
	5261,
	5261,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	2865,
	6698,
	1946,
	5261,
	2865,
	6698,
	1946,
	5261,
	6698,
	6698,
	6569,
	5261,
	1425,
	5305,
	5261,
	2085,
	2082,
	2635,
	2605,
	1133,
	1388,
	6698,
	6698,
	6536,
	3652,
	6698,
	5261,
	6698,
	6698,
	2884,
	6698,
	6698,
	6618,
	1947,
	4469,
	6698,
	5261,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	5261,
	6698,
	6698,
	6698,
	6698,
	6569,
	5261,
	6698,
	6698,
	2870,
	5305,
	5261,
	5261,
	5261,
	6698,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	6698,
	6698,
	6698,
	11786,
	6618,
	6698,
	5261,
	2870,
	5261,
	6698,
	6698,
	5261,
	6698,
	6698,
	5305,
	5261,
	6698,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	6698,
	6698,
	6698,
	6698,
	5261,
	2870,
	5261,
	6698,
	6698,
	5261,
	6698,
	6698,
	6569,
	6569,
	6569,
	6569,
	6569,
	6569,
	3939,
	6698,
	5305,
	5261,
	6698,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	11833,
	9780,
	9780,
	9780,
	9255,
	9780,
	11012,
	10821,
	6698,
	5261,
	6698,
	6698,
	6698,
	1445,
	6698,
	6698,
	6698,
	11786,
	11016,
	6536,
	5230,
	6536,
	5230,
	6618,
	5305,
	6536,
	5230,
	6536,
	5230,
	6569,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	6569,
	5261,
	6698,
	5316,
	3945,
	6569,
	6698,
	6698,
	2870,
	6698,
	6618,
	2075,
	6569,
	2075,
	3939,
	4427,
	4427,
	5261,
	2870,
	2862,
	1722,
	1721,
	3652,
	3626,
	6618,
	2579,
	2579,
	1425,
	1425,
	1697,
	2579,
	2579,
	1425,
	1425,
	6698,
	6698,
	6698,
	498,
	1009,
	1380,
	1380,
	1009,
	1380,
	1009,
	1130,
	1699,
	1699,
	1130,
	1130,
	1130,
	1699,
	1699,
	1129,
	856,
	1168,
	856,
	1388,
	2605,
	1246,
	2870,
	1449,
	1449,
	1449,
	10821,
	2870,
	5261,
	2870,
	5261,
	6569,
	2870,
	5261,
	4427,
	4427,
	5261,
	5305,
	6698,
	6618,
	6698,
	6698,
	5261,
	3939,
	2870,
	5261,
	6698,
	6698,
	5261,
	5261,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	11833,
	5261,
	6698,
	6698,
	2865,
	2870,
	856,
	5261,
	2865,
	2870,
	856,
	5261,
	2865,
	5261,
	1168,
	5261,
	2865,
	5261,
	1168,
	5261,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	6698,
	6698,
	11786,
	11786,
	11833,
	0,
	0,
	0,
	6698,
	6698,
};
static const Il2CppTokenRangePair s_rgctxIndices[1] = 
{
	{ 0x0200007A, { 0, 23 } },
};
extern const uint32_t g_rgctx_List_1_t811D1305F5AE9E66EA028E4722560AC7763A8F8B;
extern const uint32_t g_rgctx_List_1_Clear_m6B48BA50948B8BBF78A643532B4231D391313B51;
extern const uint32_t g_rgctx_List_1_tAE708C21522CF084063418931B85AEE87BD1B2C3;
extern const uint32_t g_rgctx_List_1_Clear_mA1715B9B6A50DF79C9C8610CA20C9DCBA4513E73;
extern const uint32_t g_rgctx_Dictionary_2_GetEnumerator_mFEB34FDBB5B39B70AA3F890594F5D5F3F05F66D4;
extern const uint32_t g_rgctx_Enumerator_get_Current_m9177096EB1CE74964491A3E71C718D5EAF1061F0;
extern const uint32_t g_rgctx_KeyValuePair_2_get_Key_m6FACA685426B22B9CCB86C09298F718AC0A57D12;
extern const uint32_t g_rgctx_List_1_Add_m042C6B552A09B3D5BA8C627B145ACE1C9D9C2EE6;
extern const uint32_t g_rgctx_KeyValuePair_2_get_Value_mD3A1E6ADB41C436EB5885FED938E405EEA1A0AE1;
extern const uint32_t g_rgctx_List_1_Add_m6CE1A3A74BAE7296DEA58AB37FD5891AD9F89F8E;
extern const uint32_t g_rgctx_Enumerator_MoveNext_mC28374087C595E5F173E31B80EDB9719830A01CE;
extern const uint32_t g_rgctx_Enumerator_t631092D4A8B07E0C051ACE699CA3F119F8E7F734;
extern const Il2CppRGCTXConstrainedData g_rgctx_Enumerator_t631092D4A8B07E0C051ACE699CA3F119F8E7F734_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7;
extern const uint32_t g_rgctx_Dictionary_2_Clear_m57891ADB129BE9668A96FADBBED97047828EE173;
extern const uint32_t g_rgctx_List_1_get_Count_m6C425E42AD62757D3849A03E111D5C5654395880;
extern const uint32_t g_rgctx_List_1_get_Count_mC671E3375FA435BB86CA8965799CBE1DFC60F304;
extern const uint32_t g_rgctx_List_1_get_Item_mEE6F2AF5918CDEC0A5E8AC958E8F11591D680C1D;
extern const uint32_t g_rgctx_List_1_get_Item_mAD4A2C5EBF74218924051524FE428F716A585491;
extern const uint32_t g_rgctx_Dictionary_2_Add_mA9B401787928F458AF99573D6496EADE88FB118C;
extern const uint32_t g_rgctx_List_1__ctor_mEDE2B1416D58DC324E68CF7D1C1D2174B541ED03;
extern const uint32_t g_rgctx_List_1__ctor_mC2F27BB61917A5C268BB1EB4B07E7CE79693EF96;
extern const uint32_t g_rgctx_Dictionary_2__ctor_m3F535975A6003BCE03D0EEE25545AABACB2BD67C;
extern const uint32_t g_rgctx_Dictionary_2_t8A542EE9B2F84E45C9D46212DE667E50A94AD03C;
static const Il2CppRGCTXDefinition s_rgctxValues[23] = 
{
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_t811D1305F5AE9E66EA028E4722560AC7763A8F8B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Clear_m6B48BA50948B8BBF78A643532B4231D391313B51 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_tAE708C21522CF084063418931B85AEE87BD1B2C3 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Clear_mA1715B9B6A50DF79C9C8610CA20C9DCBA4513E73 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2_GetEnumerator_mFEB34FDBB5B39B70AA3F890594F5D5F3F05F66D4 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_get_Current_m9177096EB1CE74964491A3E71C718D5EAF1061F0 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_KeyValuePair_2_get_Key_m6FACA685426B22B9CCB86C09298F718AC0A57D12 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Add_m042C6B552A09B3D5BA8C627B145ACE1C9D9C2EE6 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_KeyValuePair_2_get_Value_mD3A1E6ADB41C436EB5885FED938E405EEA1A0AE1 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Add_m6CE1A3A74BAE7296DEA58AB37FD5891AD9F89F8E },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_MoveNext_mC28374087C595E5F173E31B80EDB9719830A01CE },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Enumerator_t631092D4A8B07E0C051ACE699CA3F119F8E7F734 },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_Enumerator_t631092D4A8B07E0C051ACE699CA3F119F8E7F734_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2_Clear_m57891ADB129BE9668A96FADBBED97047828EE173 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Count_m6C425E42AD62757D3849A03E111D5C5654395880 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Count_mC671E3375FA435BB86CA8965799CBE1DFC60F304 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Item_mEE6F2AF5918CDEC0A5E8AC958E8F11591D680C1D },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Item_mAD4A2C5EBF74218924051524FE428F716A585491 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2_Add_mA9B401787928F458AF99573D6496EADE88FB118C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1__ctor_mEDE2B1416D58DC324E68CF7D1C1D2174B541ED03 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1__ctor_mC2F27BB61917A5C268BB1EB4B07E7CE79693EF96 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2__ctor_m3F535975A6003BCE03D0EEE25545AABACB2BD67C },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Dictionary_2_t8A542EE9B2F84E45C9D46212DE667E50A94AD03C },
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule = 
{
	"Assembly-CSharp.dll",
	822,
	s_methodPointers,
	17,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	1,
	s_rgctxIndices,
	23,
	s_rgctxValues,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
