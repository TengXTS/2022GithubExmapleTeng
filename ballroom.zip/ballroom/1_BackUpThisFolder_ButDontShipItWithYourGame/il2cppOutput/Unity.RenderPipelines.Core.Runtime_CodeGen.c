﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void Microsoft.CodeAnalysis.EmbeddedAttribute::.ctor()
extern void EmbeddedAttribute__ctor_mFDDD3801DF1C9072A93E9D0E0245AD6614296A93 (void);
// 0x00000002 System.Void System.Runtime.CompilerServices.IsUnmanagedAttribute::.ctor()
extern void IsUnmanagedAttribute__ctor_mC5A39467E97231F69EDDB82CEFF55799769D4831 (void);
// 0x00000003 System.Void SceneRenderPipeline::OnEnable()
extern void SceneRenderPipeline_OnEnable_m8DFB5817C811BD572F50828E2BC1846C33C563E0 (void);
// 0x00000004 System.Void SceneRenderPipeline::OnValidate()
extern void SceneRenderPipeline_OnValidate_m3431ACFDD2D051C2154E438CF8F238039EED461F (void);
// 0x00000005 System.Void SceneRenderPipeline::.ctor()
extern void SceneRenderPipeline__ctor_mA2BACFC1F9E1D784A1D22C33989F37AB2992B705 (void);
// 0x00000006 System.Single UnityEngine.LightAnchor::get_yaw()
extern void LightAnchor_get_yaw_m52ED0E5D97F44A13F5CDCE97B075943DF19C2C75 (void);
// 0x00000007 System.Void UnityEngine.LightAnchor::set_yaw(System.Single)
extern void LightAnchor_set_yaw_m9057876C5E232D78615173514C79C8CC793456FB (void);
// 0x00000008 System.Single UnityEngine.LightAnchor::get_pitch()
extern void LightAnchor_get_pitch_mEFF8824F48601C924A9FFFE53A037ABC94F0A457 (void);
// 0x00000009 System.Void UnityEngine.LightAnchor::set_pitch(System.Single)
extern void LightAnchor_set_pitch_mA6089A7741A4DF514CC7D1898CDC3B8395470AEF (void);
// 0x0000000A System.Single UnityEngine.LightAnchor::get_roll()
extern void LightAnchor_get_roll_m9E394A7FD38D78F77D9AF6D487ACE354AA0208BE (void);
// 0x0000000B System.Void UnityEngine.LightAnchor::set_roll(System.Single)
extern void LightAnchor_set_roll_m32BB11BB51EFACF5FA9ECD6EFA6D85326570261A (void);
// 0x0000000C System.Single UnityEngine.LightAnchor::get_distance()
extern void LightAnchor_get_distance_m77FE40AC57D00C6BA1182ED786A03F65E31127D3 (void);
// 0x0000000D System.Void UnityEngine.LightAnchor::set_distance(System.Single)
extern void LightAnchor_set_distance_m42E748EB369DBF850588C22C6918FE3FED37FA7A (void);
// 0x0000000E UnityEngine.LightAnchor/UpDirection UnityEngine.LightAnchor::get_frameSpace()
extern void LightAnchor_get_frameSpace_m44EDEFB1FE2D9935DF530548D473257FE92B59AE (void);
// 0x0000000F System.Void UnityEngine.LightAnchor::set_frameSpace(UnityEngine.LightAnchor/UpDirection)
extern void LightAnchor_set_frameSpace_m54BC03751526C7A6DC82478572424CF514CA539F (void);
// 0x00000010 UnityEngine.Vector3 UnityEngine.LightAnchor::get_anchorPosition()
extern void LightAnchor_get_anchorPosition_mEA9BCD0D6DC5F9D09946B603B002AAABED4931FB (void);
// 0x00000011 UnityEngine.Transform UnityEngine.LightAnchor::get_anchorPositionOverride()
extern void LightAnchor_get_anchorPositionOverride_m882CAD2DDBE5562E4A398A7A4F9AB5F9AFAC25F8 (void);
// 0x00000012 System.Void UnityEngine.LightAnchor::set_anchorPositionOverride(UnityEngine.Transform)
extern void LightAnchor_set_anchorPositionOverride_mC73D18D10951021DD39425772B455DD8E4433744 (void);
// 0x00000013 UnityEngine.Vector3 UnityEngine.LightAnchor::get_anchorPositionOffset()
extern void LightAnchor_get_anchorPositionOffset_m910D76FFBFFA8F1AC3863655ADA17A979EDA6841 (void);
// 0x00000014 System.Void UnityEngine.LightAnchor::set_anchorPositionOffset(UnityEngine.Vector3)
extern void LightAnchor_set_anchorPositionOffset_m1487F1C37C65F2935E8159883EFEF1FBBF52E292 (void);
// 0x00000015 System.Single UnityEngine.LightAnchor::NormalizeAngleDegree(System.Single)
extern void LightAnchor_NormalizeAngleDegree_m5E4EDD421FBEF855BBC993F4771F6D8BBB5C23F8 (void);
// 0x00000016 System.Void UnityEngine.LightAnchor::SynchronizeOnTransform(UnityEngine.Camera)
extern void LightAnchor_SynchronizeOnTransform_m34289C96616C858B40E5FC8881CE9B41F344C3A5 (void);
// 0x00000017 System.Void UnityEngine.LightAnchor::UpdateTransform(UnityEngine.Camera,UnityEngine.Vector3)
extern void LightAnchor_UpdateTransform_mDE72D1F5D3DB08833FD7447BC8936D0DB3E51889 (void);
// 0x00000018 UnityEngine.LightAnchor/Axes UnityEngine.LightAnchor::GetWorldSpaceAxes(UnityEngine.Camera)
extern void LightAnchor_GetWorldSpaceAxes_m5F7DC28223C9BF5A32D3EEB8343F0FBBAEBADC4D (void);
// 0x00000019 System.Void UnityEngine.LightAnchor::Update()
extern void LightAnchor_Update_m5A4E89DCC8E263D6574969883FCE75622779B966 (void);
// 0x0000001A System.Void UnityEngine.LightAnchor::OnDrawGizmosSelected()
extern void LightAnchor_OnDrawGizmosSelected_m8F7EDABE68EF7A8BC2959CB2A209A0F8C02C9CE7 (void);
// 0x0000001B System.Void UnityEngine.LightAnchor::UpdateTransform(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void LightAnchor_UpdateTransform_mF959E83F9B4FA3352C03C2493697A8B869E63CF3 (void);
// 0x0000001C System.Void UnityEngine.LightAnchor::.ctor()
extern void LightAnchor__ctor_mB0DD0C850B18562E6EE38F12E415F3917E3BBEAA (void);
// 0x0000001D System.Int32 UnityEngine.Experimental.Rendering.ProbeBrickIndex::get_estimatedVMemCost()
extern void ProbeBrickIndex_get_estimatedVMemCost_mFE477FD4F261500F38775DFE0B7DAB5A277A0BF1 (void);
// 0x0000001E System.Void UnityEngine.Experimental.Rendering.ProbeBrickIndex::set_estimatedVMemCost(System.Int32)
extern void ProbeBrickIndex_set_estimatedVMemCost_mC11B8A5219EA4A78BD8A5D71CC8673F7479DEDF1 (void);
// 0x0000001F System.Int32 UnityEngine.Experimental.Rendering.ProbeBrickIndex::GetVoxelSubdivLevel()
extern void ProbeBrickIndex_GetVoxelSubdivLevel_m3DC209B48D96D26959FAEEF4D16B88281981BDF7 (void);
// 0x00000020 System.Int32 UnityEngine.Experimental.Rendering.ProbeBrickIndex::SizeOfPhysicalIndexFromBudget(UnityEngine.Experimental.Rendering.ProbeVolumeTextureMemoryBudget)
extern void ProbeBrickIndex_SizeOfPhysicalIndexFromBudget_m7DD0531B067B5A9648EEA759AC150947B3870674 (void);
// 0x00000021 System.Void UnityEngine.Experimental.Rendering.ProbeBrickIndex::.ctor(UnityEngine.Experimental.Rendering.ProbeVolumeTextureMemoryBudget)
extern void ProbeBrickIndex__ctor_m05E67CF09FD73EB9674D8B0B028DF5DCA499B5D3 (void);
// 0x00000022 System.Void UnityEngine.Experimental.Rendering.ProbeBrickIndex::UploadIndexData()
extern void ProbeBrickIndex_UploadIndexData_m0C39F1400DAF3A9411424EF4B19821A2922E7AC9 (void);
// 0x00000023 System.Void UnityEngine.Experimental.Rendering.ProbeBrickIndex::Clear()
extern void ProbeBrickIndex_Clear_mF2C59212EC570181C8BE1B101F3EE2D489A37D27 (void);
// 0x00000024 System.Void UnityEngine.Experimental.Rendering.ProbeBrickIndex::MapBrickToVoxels(UnityEngine.Experimental.Rendering.ProbeBrickIndex/Brick,System.Collections.Generic.HashSet`1<UnityEngine.Vector3Int>)
extern void ProbeBrickIndex_MapBrickToVoxels_mE65C9F64C0CA2072358C43696988CF1C09AB96BE (void);
// 0x00000025 System.Void UnityEngine.Experimental.Rendering.ProbeBrickIndex::ClearVoxel(UnityEngine.Vector3Int,UnityEngine.Experimental.Rendering.ProbeBrickIndex/CellIndexUpdateInfo)
extern void ProbeBrickIndex_ClearVoxel_m7E65631F45A9E7081D6F04F2042EC7067FEE0B12 (void);
// 0x00000026 System.Void UnityEngine.Experimental.Rendering.ProbeBrickIndex::GetRuntimeResources(UnityEngine.Experimental.Rendering.ProbeReferenceVolume/RuntimeResources&)
extern void ProbeBrickIndex_GetRuntimeResources_m4C9914510D15AEBFF7710344B0149875D121AC63 (void);
// 0x00000027 System.Void UnityEngine.Experimental.Rendering.ProbeBrickIndex::Cleanup()
extern void ProbeBrickIndex_Cleanup_mB651AFFD1CB092785FE27879A0A4A3DE234E0D58 (void);
// 0x00000028 System.Int32 UnityEngine.Experimental.Rendering.ProbeBrickIndex::MergeIndex(System.Int32,System.Int32)
extern void ProbeBrickIndex_MergeIndex_m85D414F58BE14560CE051F7C79AC843F45F00B94 (void);
// 0x00000029 System.Boolean UnityEngine.Experimental.Rendering.ProbeBrickIndex::AssignIndexChunksToCell(UnityEngine.Experimental.Rendering.ProbeReferenceVolume/Cell,System.Int32,UnityEngine.Experimental.Rendering.ProbeBrickIndex/CellIndexUpdateInfo&)
extern void ProbeBrickIndex_AssignIndexChunksToCell_m8552299678638EAC75180BB5F988C3B0F5AB3AF9 (void);
// 0x0000002A System.Void UnityEngine.Experimental.Rendering.ProbeBrickIndex::AddBricks(UnityEngine.Experimental.Rendering.ProbeReferenceVolume/RegId,System.Collections.Generic.List`1<UnityEngine.Experimental.Rendering.ProbeBrickIndex/Brick>,System.Collections.Generic.List`1<UnityEngine.Experimental.Rendering.ProbeBrickPool/BrickChunkAlloc>,System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.ProbeBrickIndex/CellIndexUpdateInfo)
extern void ProbeBrickIndex_AddBricks_m7D03B36F02CDA5D5136C77A4EC0F1CD6ED7EBBB7 (void);
// 0x0000002B System.Void UnityEngine.Experimental.Rendering.ProbeBrickIndex::RemoveBricks(UnityEngine.Experimental.Rendering.ProbeReferenceVolume/RegId,UnityEngine.Experimental.Rendering.ProbeBrickIndex/CellIndexUpdateInfo)
extern void ProbeBrickIndex_RemoveBricks_mDB11AA33F8351FD7C3D0EFD946CA85E07636A170 (void);
// 0x0000002C System.Void UnityEngine.Experimental.Rendering.ProbeBrickIndex::UpdateIndexForVoxel(UnityEngine.Vector3Int,UnityEngine.Experimental.Rendering.ProbeBrickIndex/CellIndexUpdateInfo)
extern void ProbeBrickIndex_UpdateIndexForVoxel_m0E276C69C80F441BA39B5EC8FAEC2A8E6D0B419D (void);
// 0x0000002D System.Void UnityEngine.Experimental.Rendering.ProbeBrickIndex::UpdatePhysicalIndex(UnityEngine.Vector3Int,UnityEngine.Vector3Int,System.Int32,UnityEngine.Experimental.Rendering.ProbeBrickIndex/CellIndexUpdateInfo)
extern void ProbeBrickIndex_UpdatePhysicalIndex_mF7C71DF7BC9173BFEBB5040740D76B66272E1232 (void);
// 0x0000002E System.Void UnityEngine.Experimental.Rendering.ProbeBrickIndex::ClipToIndexSpace(UnityEngine.Vector3Int,System.Int32,UnityEngine.Vector3Int&,UnityEngine.Vector3Int&,UnityEngine.Experimental.Rendering.ProbeBrickIndex/CellIndexUpdateInfo)
extern void ProbeBrickIndex_ClipToIndexSpace_m67EAB9AAB95C4E9ED856432B480BA5181842C029 (void);
// 0x0000002F System.Void UnityEngine.Experimental.Rendering.ProbeBrickIndex::UpdateIndexForVoxel(UnityEngine.Vector3Int,System.Collections.Generic.List`1<UnityEngine.Experimental.Rendering.ProbeBrickIndex/ReservedBrick>,System.Collections.Generic.List`1<System.UInt16>,UnityEngine.Experimental.Rendering.ProbeBrickIndex/CellIndexUpdateInfo)
extern void ProbeBrickIndex_UpdateIndexForVoxel_m53C95CF74CFB0C44713B9578FF8D717ACCC1E2D2 (void);
// 0x00000030 System.Void UnityEngine.Experimental.Rendering.ProbeBrickIndex/Brick::.ctor(UnityEngine.Vector3Int,System.Int32)
extern void Brick__ctor_mF1384DE2A301E1649AA0B75AF1726649F330500B (void);
// 0x00000031 System.Boolean UnityEngine.Experimental.Rendering.ProbeBrickIndex/Brick::Equals(UnityEngine.Experimental.Rendering.ProbeBrickIndex/Brick)
extern void Brick_Equals_m51973370DE321FB79FE83BA500E6100A3676A62C (void);
// 0x00000032 System.Void UnityEngine.Experimental.Rendering.ProbeBrickIndex/<>c__DisplayClass31_0::.ctor()
extern void U3CU3Ec__DisplayClass31_0__ctor_m0D41A2E28E6C6807487A8C9F04742BD6C0FCC46D (void);
// 0x00000033 System.Boolean UnityEngine.Experimental.Rendering.ProbeBrickIndex/<>c__DisplayClass31_0::<AddBricks>b__0(UnityEngine.Experimental.Rendering.ProbeBrickIndex/VoxelMeta)
extern void U3CU3Ec__DisplayClass31_0_U3CAddBricksU3Eb__0_m4F62CA8F719AB83BB63600FF826BFC6D870DC03A (void);
// 0x00000034 System.Void UnityEngine.Experimental.Rendering.ProbeBrickIndex/<>c__DisplayClass32_0::.ctor()
extern void U3CU3Ec__DisplayClass32_0__ctor_mF894CFB004316B0FFCCB871803FFAEBD8DB3A380 (void);
// 0x00000035 System.Boolean UnityEngine.Experimental.Rendering.ProbeBrickIndex/<>c__DisplayClass32_0::<RemoveBricks>b__0(UnityEngine.Experimental.Rendering.ProbeBrickIndex/VoxelMeta)
extern void U3CU3Ec__DisplayClass32_0_U3CRemoveBricksU3Eb__0_mD7DC90ECA9CC7934699D1846AAB1FFBF5A7A4634 (void);
// 0x00000036 System.Int32 UnityEngine.Experimental.Rendering.ProbeBrickPool::get_estimatedVMemCost()
extern void ProbeBrickPool_get_estimatedVMemCost_m034678F278DC295B79596DB95A91C56DD2A93F16 (void);
// 0x00000037 System.Void UnityEngine.Experimental.Rendering.ProbeBrickPool::set_estimatedVMemCost(System.Int32)
extern void ProbeBrickPool_set_estimatedVMemCost_m6E4F705AFAB407937129B0DF5DF6ED9A3BB7E242 (void);
// 0x00000038 System.Void UnityEngine.Experimental.Rendering.ProbeBrickPool::.ctor(System.Int32,UnityEngine.Experimental.Rendering.ProbeVolumeTextureMemoryBudget,UnityEngine.Experimental.Rendering.ProbeVolumeSHBands)
extern void ProbeBrickPool__ctor_m0BD314B82E2BB586AEE10C0E6829076837A63E91 (void);
// 0x00000039 System.Void UnityEngine.Experimental.Rendering.ProbeBrickPool::EnsureTextureValidity()
extern void ProbeBrickPool_EnsureTextureValidity_m2D85061C632966FCF8FF4A205F01AE394E16D905 (void);
// 0x0000003A System.Int32 UnityEngine.Experimental.Rendering.ProbeBrickPool::GetChunkSize()
extern void ProbeBrickPool_GetChunkSize_m90C51A268641D7068187025F7BCFCCCE5048E79B (void);
// 0x0000003B System.Int32 UnityEngine.Experimental.Rendering.ProbeBrickPool::GetChunkSizeInProbeCount()
extern void ProbeBrickPool_GetChunkSizeInProbeCount_m89EE5CA53CC2200A0895C88692B475C2269EA6E6 (void);
// 0x0000003C System.Int32 UnityEngine.Experimental.Rendering.ProbeBrickPool::GetPoolWidth()
extern void ProbeBrickPool_GetPoolWidth_mC106DF0FAAA0AEC8CD200467EDB68F84CF9BCD15 (void);
// 0x0000003D System.Int32 UnityEngine.Experimental.Rendering.ProbeBrickPool::GetPoolHeight()
extern void ProbeBrickPool_GetPoolHeight_mC6582BAE0F1295E712B6DCDE03FA9252D8A0DCF5 (void);
// 0x0000003E UnityEngine.Vector3Int UnityEngine.Experimental.Rendering.ProbeBrickPool::GetPoolDimensions()
extern void ProbeBrickPool_GetPoolDimensions_m5FD1928EF8018F8795556D04EEA5945126962FF7 (void);
// 0x0000003F System.Void UnityEngine.Experimental.Rendering.ProbeBrickPool::GetRuntimeResources(UnityEngine.Experimental.Rendering.ProbeReferenceVolume/RuntimeResources&)
extern void ProbeBrickPool_GetRuntimeResources_mE1285A7706A4EB2FC4E1C42212207FF172E74C15 (void);
// 0x00000040 System.Void UnityEngine.Experimental.Rendering.ProbeBrickPool::Clear()
extern void ProbeBrickPool_Clear_m4AFA82638D01D1BFDDEAA2ADB2E7044F4A5BA0BD (void);
// 0x00000041 System.Void UnityEngine.Experimental.Rendering.ProbeBrickPool::Allocate(System.Int32,System.Collections.Generic.List`1<UnityEngine.Experimental.Rendering.ProbeBrickPool/BrickChunkAlloc>)
extern void ProbeBrickPool_Allocate_m6B017BDC77944EF981C7BA24117549595D54D9C6 (void);
// 0x00000042 System.Void UnityEngine.Experimental.Rendering.ProbeBrickPool::Deallocate(System.Collections.Generic.List`1<UnityEngine.Experimental.Rendering.ProbeBrickPool/BrickChunkAlloc>)
extern void ProbeBrickPool_Deallocate_mD129B65B3D591BBC9E7A6092B877429807A23CC9 (void);
// 0x00000043 System.Void UnityEngine.Experimental.Rendering.ProbeBrickPool::Update(UnityEngine.Experimental.Rendering.ProbeBrickPool/DataLocation,System.Collections.Generic.List`1<UnityEngine.Experimental.Rendering.ProbeBrickPool/BrickChunkAlloc>,System.Collections.Generic.List`1<UnityEngine.Experimental.Rendering.ProbeBrickPool/BrickChunkAlloc>,UnityEngine.Experimental.Rendering.ProbeVolumeSHBands)
extern void ProbeBrickPool_Update_mD19C587DA7D045D80AA6B4ADFB482D1318912ED9 (void);
// 0x00000044 UnityEngine.Vector3Int UnityEngine.Experimental.Rendering.ProbeBrickPool::ProbeCountToDataLocSize(System.Int32)
extern void ProbeBrickPool_ProbeCountToDataLocSize_mFB4FFBD7A584D6A533A39F1CC1B4DD0CDEDA80F1 (void);
// 0x00000045 UnityEngine.Experimental.Rendering.ProbeBrickPool/DataLocation UnityEngine.Experimental.Rendering.ProbeBrickPool::CreateDataLocation(System.Int32,System.Boolean,UnityEngine.Experimental.Rendering.ProbeVolumeSHBands,System.Int32&)
extern void ProbeBrickPool_CreateDataLocation_m69E2A8A785E5FFE755A213542EE2CDBC8040237D (void);
// 0x00000046 System.Void UnityEngine.Experimental.Rendering.ProbeBrickPool::SetPixel(UnityEngine.Color[]&,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,UnityEngine.Color)
extern void ProbeBrickPool_SetPixel_mBB676A7FFB5A8A92C24D4AC350FC72D678108C7F (void);
// 0x00000047 System.Void UnityEngine.Experimental.Rendering.ProbeBrickPool::FillDataLocation(UnityEngine.Experimental.Rendering.ProbeBrickPool/DataLocation&,UnityEngine.Rendering.SphericalHarmonicsL2[],UnityEngine.Experimental.Rendering.ProbeVolumeSHBands)
extern void ProbeBrickPool_FillDataLocation_m749F98CDC969320C029782CA95FA381A8267C095 (void);
// 0x00000048 System.Void UnityEngine.Experimental.Rendering.ProbeBrickPool::DerivePoolSizeFromBudget(System.Int32,UnityEngine.Experimental.Rendering.ProbeVolumeTextureMemoryBudget,System.Int32&,System.Int32&,System.Int32&)
extern void ProbeBrickPool_DerivePoolSizeFromBudget_m252784923D233C370B31CAF376822B0A8B4F0DEE (void);
// 0x00000049 System.Void UnityEngine.Experimental.Rendering.ProbeBrickPool::Cleanup()
extern void ProbeBrickPool_Cleanup_m7DDF8B0DA3D29B59D8D3F9E53211B205B5CBCFAA (void);
// 0x0000004A System.Int32 UnityEngine.Experimental.Rendering.ProbeBrickPool/BrickChunkAlloc::flattenIndex(System.Int32,System.Int32)
extern void BrickChunkAlloc_flattenIndex_mDDF83B6500BFACBB3DF4327BD285E912749664DD (void);
// 0x0000004B System.Void UnityEngine.Experimental.Rendering.ProbeBrickPool/DataLocation::Cleanup()
extern void DataLocation_Cleanup_mD3D6DFF36870590F6A6DEBAB39E65BF71BB17FBF (void);
// 0x0000004C System.Int32 UnityEngine.Experimental.Rendering.ProbeCellIndices::get_estimatedVMemCost()
extern void ProbeCellIndices_get_estimatedVMemCost_m5F027C6A9242F582122F2DFD593D9728D99C970B (void);
// 0x0000004D System.Void UnityEngine.Experimental.Rendering.ProbeCellIndices::set_estimatedVMemCost(System.Int32)
extern void ProbeCellIndices_set_estimatedVMemCost_m48C6C4530C2AB4BEB48C85C0AC18CBABBF79D945 (void);
// 0x0000004E UnityEngine.Vector3Int UnityEngine.Experimental.Rendering.ProbeCellIndices::GetCellIndexDimension()
extern void ProbeCellIndices_GetCellIndexDimension_m9E93661F7B58589CA0557D3B07A8FB635232B3D5 (void);
// 0x0000004F UnityEngine.Vector3Int UnityEngine.Experimental.Rendering.ProbeCellIndices::GetCellMinPosition()
extern void ProbeCellIndices_GetCellMinPosition_m2F7C085192B5E67252677C7B3C0D79DF7FADBC54 (void);
// 0x00000050 System.Int32 UnityEngine.Experimental.Rendering.ProbeCellIndices::GetFlatIndex(UnityEngine.Vector3Int)
extern void ProbeCellIndices_GetFlatIndex_m6847AC7311DF2F831B2A92995F8C6FC68F13BBAE (void);
// 0x00000051 System.Void UnityEngine.Experimental.Rendering.ProbeCellIndices::.ctor(UnityEngine.Vector3Int,UnityEngine.Vector3Int,System.Int32)
extern void ProbeCellIndices__ctor_mB2B093549B9F43B1A624F277B91EA10651A14F30 (void);
// 0x00000052 System.Int32 UnityEngine.Experimental.Rendering.ProbeCellIndices::GetFlatIdxForCell(UnityEngine.Vector3Int)
extern void ProbeCellIndices_GetFlatIdxForCell_m0E8103CD210C64D23927C96BD86BB349EFEFCD67 (void);
// 0x00000053 System.Void UnityEngine.Experimental.Rendering.ProbeCellIndices::AddCell(System.Int32,UnityEngine.Experimental.Rendering.ProbeBrickIndex/CellIndexUpdateInfo)
extern void ProbeCellIndices_AddCell_mB5C00D8EF3DAA8EA55A78E58B255F9F2E0ADD8BD (void);
// 0x00000054 System.Void UnityEngine.Experimental.Rendering.ProbeCellIndices::MarkCellAsUnloaded(System.Int32)
extern void ProbeCellIndices_MarkCellAsUnloaded_mF2C9BE87210AB183AE9F4649A1562F19EB3EE4E5 (void);
// 0x00000055 System.Void UnityEngine.Experimental.Rendering.ProbeCellIndices::PushComputeData()
extern void ProbeCellIndices_PushComputeData_m647D18E694F7DBFC7FA1386157C862C422B4D36F (void);
// 0x00000056 System.Void UnityEngine.Experimental.Rendering.ProbeCellIndices::GetRuntimeResources(UnityEngine.Experimental.Rendering.ProbeReferenceVolume/RuntimeResources&)
extern void ProbeCellIndices_GetRuntimeResources_mC562C8F0D3EB039D60A752D91E8106F2011BA428 (void);
// 0x00000057 System.Void UnityEngine.Experimental.Rendering.ProbeCellIndices::Cleanup()
extern void ProbeCellIndices_Cleanup_mE9FAE4FD94D9AFF389980F80D6254A657E9987E5 (void);
// 0x00000058 System.Void UnityEngine.Experimental.Rendering.ProbeCellIndices/IndexMetaData::Pack(System.UInt32[]&)
extern void IndexMetaData_Pack_mD890E178B9204BB2B438B3AF6D328086BDAF7056 (void);
// 0x00000059 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::InvalidateAllCellRefs()
extern void ProbeReferenceVolume_InvalidateAllCellRefs_mC9899CBE0BD02C52065E4ACB1D4B871D0870B467 (void);
// 0x0000005A System.Boolean UnityEngine.Experimental.Rendering.ProbeReferenceVolume::get_isInitialized()
extern void ProbeReferenceVolume_get_isInitialized_mF23A464CC55545B81DCF87CD846DDBB1D083F656 (void);
// 0x0000005B System.Boolean UnityEngine.Experimental.Rendering.ProbeReferenceVolume::get_enabledBySRP()
extern void ProbeReferenceVolume_get_enabledBySRP_m4EDBD40DD9C008D5BE71C8B63E4734AB80CADFCC (void);
// 0x0000005C UnityEngine.Experimental.Rendering.ProbeVolumeSHBands UnityEngine.Experimental.Rendering.ProbeReferenceVolume::get_shBands()
extern void ProbeReferenceVolume_get_shBands_m4226E70293AB7D461B40DCBA788C3936574604E7 (void);
// 0x0000005D UnityEngine.Experimental.Rendering.ProbeVolumeTextureMemoryBudget UnityEngine.Experimental.Rendering.ProbeReferenceVolume::get_memoryBudget()
extern void ProbeReferenceVolume_get_memoryBudget_mE288C614ADB6D076B824FA6F794DF6E43A08FA20 (void);
// 0x0000005E UnityEngine.Experimental.Rendering.ProbeReferenceVolume UnityEngine.Experimental.Rendering.ProbeReferenceVolume::get_instance()
extern void ProbeReferenceVolume_get_instance_m2C37B082CAD0E7ED8A9A063B553DB456B89D8FFC (void);
// 0x0000005F System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::SetNumberOfCellsLoadedPerFrame(System.Int32)
extern void ProbeReferenceVolume_SetNumberOfCellsLoadedPerFrame_m05295E2EC6686E43BC6E3A25C7A222A9817B5E46 (void);
// 0x00000060 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::Initialize(UnityEngine.Experimental.Rendering.ProbeVolumeSystemParameters&)
extern void ProbeReferenceVolume_Initialize_mFC60AE4AB09643D221CE0E6EA3EB68FEB0A4D458 (void);
// 0x00000061 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::SetEnableStateFromSRP(System.Boolean)
extern void ProbeReferenceVolume_SetEnableStateFromSRP_m6ABC5B2B94635F9E1EE218F9191564B527D421AD (void);
// 0x00000062 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::ForceSHBand(UnityEngine.Experimental.Rendering.ProbeVolumeSHBands)
extern void ProbeReferenceVolume_ForceSHBand_m6242CF41956912A6D6E08C244CE21EFF90963FF2 (void);
// 0x00000063 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::Cleanup()
extern void ProbeReferenceVolume_Cleanup_m371AE89841E21926498188BC77064602AADE4B0A (void);
// 0x00000064 System.Int32 UnityEngine.Experimental.Rendering.ProbeReferenceVolume::GetVideoMemoryCost()
extern void ProbeReferenceVolume_GetVideoMemoryCost_m1D5387B5E18210B12414D2D2872DF894BC35F0AF (void);
// 0x00000065 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::RemoveCell(UnityEngine.Experimental.Rendering.ProbeReferenceVolume/Cell)
extern void ProbeReferenceVolume_RemoveCell_m5A0D41776583972976AAB53206FE1CA079156396 (void);
// 0x00000066 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::AddCell(UnityEngine.Experimental.Rendering.ProbeReferenceVolume/Cell,System.Collections.Generic.List`1<UnityEngine.Experimental.Rendering.ProbeBrickPool/BrickChunkAlloc>)
extern void ProbeReferenceVolume_AddCell_mE2159918E79C6C8134BAACED69C3E0ECEB8DCCCD (void);
// 0x00000067 System.Boolean UnityEngine.Experimental.Rendering.ProbeReferenceVolume::CheckCompatibilityWithCollection(UnityEngine.Experimental.Rendering.ProbeVolumeAsset,System.Collections.Generic.Dictionary`2<System.String,UnityEngine.Experimental.Rendering.ProbeVolumeAsset>)
extern void ProbeReferenceVolume_CheckCompatibilityWithCollection_m08A5838880203FA8D70E253A887B28E85FB6A517 (void);
// 0x00000068 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::AddPendingAssetLoading(UnityEngine.Experimental.Rendering.ProbeVolumeAsset)
extern void ProbeReferenceVolume_AddPendingAssetLoading_m7EF404D492670EE60C0CF10A66C5F9015A38F1B7 (void);
// 0x00000069 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::AddPendingAssetRemoval(UnityEngine.Experimental.Rendering.ProbeVolumeAsset)
extern void ProbeReferenceVolume_AddPendingAssetRemoval_mBD95A44765631D66376763508952902BDD03A8DD (void);
// 0x0000006A System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::RemovePendingAsset(UnityEngine.Experimental.Rendering.ProbeVolumeAsset)
extern void ProbeReferenceVolume_RemovePendingAsset_m6570DA934E9ACE3DA84E10783816ED6157B98762 (void);
// 0x0000006B System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::PerformPendingIndexChangeAndInit()
extern void ProbeReferenceVolume_PerformPendingIndexChangeAndInit_m31E431668BAEA4F76051C3F4F08BCBF7893F3341 (void);
// 0x0000006C System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::SetMinBrickAndMaxSubdiv(System.Single,System.Int32)
extern void ProbeReferenceVolume_SetMinBrickAndMaxSubdiv_m88473F4B1337645D2F5B6F9AA6B60D20CB1AC078 (void);
// 0x0000006D System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::LoadAsset(UnityEngine.Experimental.Rendering.ProbeVolumeAsset)
extern void ProbeReferenceVolume_LoadAsset_m6762ED235290551AF23A3A741A5AB44DCC635DC7 (void);
// 0x0000006E System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::PerformPendingLoading()
extern void ProbeReferenceVolume_PerformPendingLoading_m3A0D300661A997E2026BDFB631C1C02037A5F621 (void);
// 0x0000006F System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::PerformPendingDeletion()
extern void ProbeReferenceVolume_PerformPendingDeletion_m394606ACC70C20888F50E08C3EB940DB8B87F6EA (void);
// 0x00000070 System.Int32 UnityEngine.Experimental.Rendering.ProbeReferenceVolume::GetNumberOfBricksAtSubdiv(UnityEngine.Experimental.Rendering.ProbeReferenceVolume/Cell,UnityEngine.Vector3Int&,UnityEngine.Vector3Int&)
extern void ProbeReferenceVolume_GetNumberOfBricksAtSubdiv_mC7241405B7787ADEE9A494F37CB79670527727B6 (void);
// 0x00000071 System.Boolean UnityEngine.Experimental.Rendering.ProbeReferenceVolume::GetCellIndexUpdate(UnityEngine.Experimental.Rendering.ProbeReferenceVolume/Cell,UnityEngine.Experimental.Rendering.ProbeBrickIndex/CellIndexUpdateInfo&)
extern void ProbeReferenceVolume_GetCellIndexUpdate_m5F32FFA6A185E250CA69C49B1CE881A2C21C7282 (void);
// 0x00000072 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::LoadPendingCells(System.Boolean)
extern void ProbeReferenceVolume_LoadPendingCells_m5A516A3ECD5B8A3E98F091BECD0997122EE77D4B (void);
// 0x00000073 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::PerformPendingOperations(System.Boolean)
extern void ProbeReferenceVolume_PerformPendingOperations_mC5519B44064DD7C71E6A60EF117E11BC632CF98C (void);
// 0x00000074 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::InitProbeReferenceVolume(System.Int32,UnityEngine.Experimental.Rendering.ProbeVolumeTextureMemoryBudget,UnityEngine.Experimental.Rendering.ProbeVolumeSHBands)
extern void ProbeReferenceVolume_InitProbeReferenceVolume_m8396C4E41214B049F2382F6C56A71C7AA4787A3E (void);
// 0x00000075 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::SortPendingCells(UnityEngine.Vector3)
extern void ProbeReferenceVolume_SortPendingCells_m2F51DC96E68B5D82D019FE55C35270F097EF295B (void);
// 0x00000076 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::.ctor()
extern void ProbeReferenceVolume__ctor_m6A7FC7CD15FFB29AEEEDE07D8BC12D20F54934CA (void);
// 0x00000077 UnityEngine.Experimental.Rendering.ProbeReferenceVolume/RuntimeResources UnityEngine.Experimental.Rendering.ProbeReferenceVolume::GetRuntimeResources()
extern void ProbeReferenceVolume_GetRuntimeResources_mFAFA8BFAA13C5F2A44156150FB9706AC7D0783BB (void);
// 0x00000078 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::SetTRS(UnityEngine.Vector3,UnityEngine.Quaternion,System.Single)
extern void ProbeReferenceVolume_SetTRS_m942EB8F2721EA1D608CD24A5BF0367362703CAB6 (void);
// 0x00000079 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::SetMaxSubdivision(System.Int32)
extern void ProbeReferenceVolume_SetMaxSubdivision_m18D69D8668C3E597E98DDC49F890E4B212F601FA (void);
// 0x0000007A System.Int32 UnityEngine.Experimental.Rendering.ProbeReferenceVolume::CellSize(System.Int32)
extern void ProbeReferenceVolume_CellSize_mD207959EFA5248246AA6B601F0D763AB9A0A222A (void);
// 0x0000007B System.Single UnityEngine.Experimental.Rendering.ProbeReferenceVolume::BrickSize(System.Int32)
extern void ProbeReferenceVolume_BrickSize_mDCA73ED08C95C324438DD58CDB612BDF11F58FCB (void);
// 0x0000007C System.Single UnityEngine.Experimental.Rendering.ProbeReferenceVolume::MinBrickSize()
extern void ProbeReferenceVolume_MinBrickSize_m7F68ECE8192C147F1FD88A7084613CE914BA88D3 (void);
// 0x0000007D System.Single UnityEngine.Experimental.Rendering.ProbeReferenceVolume::MaxBrickSize()
extern void ProbeReferenceVolume_MaxBrickSize_m46CBCA6A0DB5E9DF939931596A0AF80E66FDC586 (void);
// 0x0000007E UnityEngine.Matrix4x4 UnityEngine.Experimental.Rendering.ProbeReferenceVolume::GetRefSpaceToWS()
extern void ProbeReferenceVolume_GetRefSpaceToWS_m705979650EE8BE432367669D8BF29474F8E345BF (void);
// 0x0000007F UnityEngine.Experimental.Rendering.ProbeReferenceVolume/RefVolTransform UnityEngine.Experimental.Rendering.ProbeReferenceVolume::GetTransform()
extern void ProbeReferenceVolume_GetTransform_m46DB6F40F6AEEDBEF5603019105B63912FB41D60 (void);
// 0x00000080 System.Int32 UnityEngine.Experimental.Rendering.ProbeReferenceVolume::GetMaxSubdivision()
extern void ProbeReferenceVolume_GetMaxSubdivision_m023EA6A3411AE69AEC9E9DBF9A3FF9A64D6A655E (void);
// 0x00000081 System.Int32 UnityEngine.Experimental.Rendering.ProbeReferenceVolume::GetMaxSubdivision(System.Single)
extern void ProbeReferenceVolume_GetMaxSubdivision_m4226527EFCC91A55AE575D7261C653F62A90F572 (void);
// 0x00000082 System.Single UnityEngine.Experimental.Rendering.ProbeReferenceVolume::GetDistanceBetweenProbes(System.Int32)
extern void ProbeReferenceVolume_GetDistanceBetweenProbes_m4DA724F7EC834805EBF6811DD4BCCB3D9FE09B77 (void);
// 0x00000083 System.Single UnityEngine.Experimental.Rendering.ProbeReferenceVolume::MinDistanceBetweenProbes()
extern void ProbeReferenceVolume_MinDistanceBetweenProbes_m8D4E69D8DBDBAE871A41001A5034F3F73DF8FE3D (void);
// 0x00000084 System.Boolean UnityEngine.Experimental.Rendering.ProbeReferenceVolume::DataHasBeenLoaded()
extern void ProbeReferenceVolume_DataHasBeenLoaded_m1CA78B6A3D0473BAA991E43AC7C75F2865365119 (void);
// 0x00000085 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::Clear()
extern void ProbeReferenceVolume_Clear_mEFC86AD464BA6A183AD6FFBE151885143C0ECC2E (void);
// 0x00000086 UnityEngine.Experimental.Rendering.ProbeReferenceVolume/RegId UnityEngine.Experimental.Rendering.ProbeReferenceVolume::AddBricks(System.Collections.Generic.List`1<UnityEngine.Experimental.Rendering.ProbeBrickIndex/Brick>,UnityEngine.Experimental.Rendering.ProbeBrickPool/DataLocation,UnityEngine.Experimental.Rendering.ProbeBrickIndex/CellIndexUpdateInfo,System.Collections.Generic.List`1<UnityEngine.Experimental.Rendering.ProbeBrickPool/BrickChunkAlloc>&)
extern void ProbeReferenceVolume_AddBricks_m04EEF96F0D5C2861661C99F2E75C5E7580C1D446 (void);
// 0x00000087 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::ReleaseBricks(UnityEngine.Experimental.Rendering.ProbeReferenceVolume/RegId)
extern void ProbeReferenceVolume_ReleaseBricks_m7BB16DFF13B76370E1EADDC7AAC79EF41848704D (void);
// 0x00000088 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::UpdateConstantBuffer(UnityEngine.Rendering.CommandBuffer,UnityEngine.Experimental.Rendering.ProbeVolumeShadingParameters)
extern void ProbeReferenceVolume_UpdateConstantBuffer_m1EC669416A811F48A8E8A35F9D49AEF93397CD8E (void);
// 0x00000089 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::CleanupLoadedData()
extern void ProbeReferenceVolume_CleanupLoadedData_m468450BDD6457065635A939ED04CF2748D861406 (void);
// 0x0000008A UnityEngine.Experimental.Rendering.ProbeVolumeDebug UnityEngine.Experimental.Rendering.ProbeReferenceVolume::get_debugDisplay()
extern void ProbeReferenceVolume_get_debugDisplay_m3B5AC8256B172A7F328C8BB71052B58A1E31F33D (void);
// 0x0000008B UnityEngine.Color[] UnityEngine.Experimental.Rendering.ProbeReferenceVolume::get_subdivisionDebugColors()
extern void ProbeReferenceVolume_get_subdivisionDebugColors_m14CCC5D30B08F40A298620B0A52D73B5DF17838C (void);
// 0x0000008C System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::RenderDebug(UnityEngine.Camera)
extern void ProbeReferenceVolume_RenderDebug_mB5940E1289F5AC9BF893E2ECD0000B824B87F480 (void);
// 0x0000008D System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::InitializeDebug(UnityEngine.Mesh,UnityEngine.Shader)
extern void ProbeReferenceVolume_InitializeDebug_m5576BAAC9A89F89AD454682006A303A6E9E9E16A (void);
// 0x0000008E System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::CleanupDebug()
extern void ProbeReferenceVolume_CleanupDebug_m87FDB580BDBC8351FECEB41FC0AEC172245C0780 (void);
// 0x0000008F System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::RefreshDebug(UnityEngine.Rendering.DebugUI/Field`1<T>,T)
// 0x00000090 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::DebugCellIndexChanged(UnityEngine.Rendering.DebugUI/Field`1<T>,T)
// 0x00000091 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::RegisterDebug()
extern void ProbeReferenceVolume_RegisterDebug_mD0A161B88AD53352C8963DC9BD27342C7E860A65 (void);
// 0x00000092 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::UnregisterDebug(System.Boolean)
extern void ProbeReferenceVolume_UnregisterDebug_m3F056A2F836F6655E1E1445C916C9E0E3361F79E (void);
// 0x00000093 System.Boolean UnityEngine.Experimental.Rendering.ProbeReferenceVolume::ShouldCullCell(UnityEngine.Vector3,UnityEngine.Transform,UnityEngine.Plane[])
extern void ProbeReferenceVolume_ShouldCullCell_m9715280AEB3617FBD09C00FB2D4F7171D7538F4F (void);
// 0x00000094 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::DrawProbeDebug(UnityEngine.Camera)
extern void ProbeReferenceVolume_DrawProbeDebug_mA8A39F3E467AACFB8D9464875641560CF61C045B (void);
// 0x00000095 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::ClearDebugData()
extern void ProbeReferenceVolume_ClearDebugData_m254D017F2183A194216423BB841397BDDF1C4DC8 (void);
// 0x00000096 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::CreateInstancedProbes()
extern void ProbeReferenceVolume_CreateInstancedProbes_m806975916734F25072124FAD76BCBA10168947AD (void);
// 0x00000097 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::OnClearLightingdata()
extern void ProbeReferenceVolume_OnClearLightingdata_m30C6E85A9543A4B86541BF45AE9574BE8893F252 (void);
// 0x00000098 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::.cctor()
extern void ProbeReferenceVolume__cctor_m581E007F00827823E1613E4B0CEE7EE324E1DFEC (void);
// 0x00000099 System.Boolean UnityEngine.Experimental.Rendering.ProbeReferenceVolume::<RegisterDebug>b__119_0()
extern void ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_0_m1FEF43C8C9257393BB00F23599D338C52C1209F1 (void);
// 0x0000009A System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::<RegisterDebug>b__119_1(System.Boolean)
extern void ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_1_m838B64743C17C84AD7D800DEB38520F5C5613618 (void);
// 0x0000009B System.Boolean UnityEngine.Experimental.Rendering.ProbeReferenceVolume::<RegisterDebug>b__119_2()
extern void ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_2_m08AD6589C129153D509EF8BD795B857CD2012D25 (void);
// 0x0000009C System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::<RegisterDebug>b__119_3(System.Boolean)
extern void ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_3_mFAE8C73291A450AAB6EC112A429FA260163B398D (void);
// 0x0000009D System.Single UnityEngine.Experimental.Rendering.ProbeReferenceVolume::<RegisterDebug>b__119_4()
extern void ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_4_m69477F076DA430E890DCDEC5FD4332539C3AA181 (void);
// 0x0000009E System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::<RegisterDebug>b__119_5(System.Single)
extern void ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_5_m20351FBA28D54261AFE1CFA4B1ADF6462D85B2F5 (void);
// 0x0000009F System.Boolean UnityEngine.Experimental.Rendering.ProbeReferenceVolume::<RegisterDebug>b__119_7()
extern void ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_7_m78E56FD68CE1EAD67F6A352BDED5D5017AB3882C (void);
// 0x000000A0 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::<RegisterDebug>b__119_8(System.Boolean)
extern void ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_8_m622E41A1FBAD4841237A25A02F20FB905CAC4109 (void);
// 0x000000A1 System.Int32 UnityEngine.Experimental.Rendering.ProbeReferenceVolume::<RegisterDebug>b__119_9()
extern void ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_9_m3BC9939FA36AE2ED9E3F6CDA1C5AE689B5D8AA08 (void);
// 0x000000A2 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::<RegisterDebug>b__119_10(System.Int32)
extern void ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_10_m79BF09226B0DA9942A5161198E24AA2A4E7BB82D (void);
// 0x000000A3 System.Int32 UnityEngine.Experimental.Rendering.ProbeReferenceVolume::<RegisterDebug>b__119_11()
extern void ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_11_m9BADEECA3912AA581326B967997E4A0179DA483F (void);
// 0x000000A4 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::<RegisterDebug>b__119_12(System.Int32)
extern void ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_12_mAD8CA099159B1D4F1BC3678F3D670ED8BBE0E36D (void);
// 0x000000A5 System.Single UnityEngine.Experimental.Rendering.ProbeReferenceVolume::<RegisterDebug>b__119_13()
extern void ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_13_mEDA1CFED7D779CBA54CF4A70BCC4804D1075B4A8 (void);
// 0x000000A6 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::<RegisterDebug>b__119_14(System.Single)
extern void ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_14_m4C0370437FDB51EAD81A9253FD5951FC02D4F6C4 (void);
// 0x000000A7 System.Single UnityEngine.Experimental.Rendering.ProbeReferenceVolume::<RegisterDebug>b__119_17()
extern void ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_17_mE8905DB432C1780EF995219604D3D86C59E279D5 (void);
// 0x000000A8 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::<RegisterDebug>b__119_18(System.Single)
extern void ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_18_m5E715FD0DA77C56C3B77D5274B771943EE345079 (void);
// 0x000000A9 System.Single UnityEngine.Experimental.Rendering.ProbeReferenceVolume::<RegisterDebug>b__119_19()
extern void ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_19_mBB862AA761431F2CD7B2DD6DDAF1445E24379BBA (void);
// 0x000000AA System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::<RegisterDebug>b__119_20(System.Single)
extern void ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_20_m582275190D2F770D8C40085ED3BC1F4A99B55A5D (void);
// 0x000000AB System.Int32 UnityEngine.Experimental.Rendering.ProbeReferenceVolume::<RegisterDebug>b__119_22()
extern void ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_22_mEA9E3063D4EA99AC22841A5D83694F97F0C9650A (void);
// 0x000000AC System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume::<RegisterDebug>b__119_23(System.Int32)
extern void ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_23_m8EF41C0C654286DE20CA52E6631DE19B5B824F6B (void);
// 0x000000AD System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume/Cell::.ctor()
extern void Cell__ctor_m824A6EBAD74E1A1616A81B2598406D1A6663B7EF (void);
// 0x000000AE System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume/CellChunkInfo::.ctor()
extern void CellChunkInfo__ctor_m7E1C749DBADA4CB21473B1A39E986AEEDDAB678E (void);
// 0x000000AF System.Int32 UnityEngine.Experimental.Rendering.ProbeReferenceVolume/CellSortInfo::CompareTo(System.Object)
extern void CellSortInfo_CompareTo_m863AFCCBD5F7AFBF8701D1949F0BC4CAC81191A8 (void);
// 0x000000B0 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume/CellSortInfo::.ctor()
extern void CellSortInfo__ctor_m5871F49B1A019D1B007A5132580B6599434971BE (void);
// 0x000000B1 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume/Volume::.ctor(UnityEngine.Matrix4x4,System.Single,System.Single)
extern void Volume__ctor_m157BAF82255C35F2C38F19544B2E95570161E332 (void);
// 0x000000B2 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume/Volume::.ctor(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single)
extern void Volume__ctor_m4FDB6EEEA74A5B99555110CAA3B12282432CC15D (void);
// 0x000000B3 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume/Volume::.ctor(UnityEngine.Experimental.Rendering.ProbeReferenceVolume/Volume)
extern void Volume__ctor_m0746CD2A7E66B698B86D7486756406F7F3FAB857 (void);
// 0x000000B4 UnityEngine.Bounds UnityEngine.Experimental.Rendering.ProbeReferenceVolume/Volume::CalculateAABB()
extern void Volume_CalculateAABB_mBDDD2C2420FDF8879AA3E83BAEBB3D2888AACFB4 (void);
// 0x000000B5 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume/Volume::CalculateCenterAndSize(UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void Volume_CalculateCenterAndSize_m1DADCCCFB55DCDFD8BEC9FBBA0C566D7E4DA0E4A (void);
// 0x000000B6 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume/Volume::Transform(UnityEngine.Matrix4x4)
extern void Volume_Transform_m12D69F2254CDE720482AAC13285DF1204D3147A9 (void);
// 0x000000B7 System.String UnityEngine.Experimental.Rendering.ProbeReferenceVolume/Volume::ToString()
extern void Volume_ToString_m98DA1A8AE24508B153D48275417D33006A179D54 (void);
// 0x000000B8 System.Boolean UnityEngine.Experimental.Rendering.ProbeReferenceVolume/Volume::Equals(UnityEngine.Experimental.Rendering.ProbeReferenceVolume/Volume)
extern void Volume_Equals_m0779B6B9E04131377F97A134517B72F4FFA82D3E (void);
// 0x000000B9 System.Boolean UnityEngine.Experimental.Rendering.ProbeReferenceVolume/RegId::IsValid()
extern void RegId_IsValid_m36BF6BB4B5534FCE342CC11E1EE32774E60C59B4 (void);
// 0x000000BA System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume/RegId::Invalidate()
extern void RegId_Invalidate_m1933F3829E449BAB0908DCE60AA6C1612FB0D8BA (void);
// 0x000000BB System.Boolean UnityEngine.Experimental.Rendering.ProbeReferenceVolume/RegId::op_Equality(UnityEngine.Experimental.Rendering.ProbeReferenceVolume/RegId,UnityEngine.Experimental.Rendering.ProbeReferenceVolume/RegId)
extern void RegId_op_Equality_m221776DC5C85B27789D99AF0DC8F1B605834FA87 (void);
// 0x000000BC System.Boolean UnityEngine.Experimental.Rendering.ProbeReferenceVolume/RegId::op_Inequality(UnityEngine.Experimental.Rendering.ProbeReferenceVolume/RegId,UnityEngine.Experimental.Rendering.ProbeReferenceVolume/RegId)
extern void RegId_op_Inequality_m5A3B7093270A74036495D32ABBD5BB83F5BE6762 (void);
// 0x000000BD System.Boolean UnityEngine.Experimental.Rendering.ProbeReferenceVolume/RegId::Equals(System.Object)
extern void RegId_Equals_m42741BC96AB73BD66C8E071FC56669D05BE78681 (void);
// 0x000000BE System.Int32 UnityEngine.Experimental.Rendering.ProbeReferenceVolume/RegId::GetHashCode()
extern void RegId_GetHashCode_m85D1E25F3792C7049063C2A7C4C1AC7D2F6FE449 (void);
// 0x000000BF System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume/CellInstancedDebugProbes::.ctor()
extern void CellInstancedDebugProbes__ctor_m44EA2D56ABD51F06B333CCC0C0017FD99757ED7E (void);
// 0x000000C0 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume/<>c::.cctor()
extern void U3CU3Ec__cctor_mA8649E64A33FB38928F9D043A502C9F5968E2F93 (void);
// 0x000000C1 System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolume/<>c::.ctor()
extern void U3CU3Ec__ctor_mF0EC848664DD41AE0CCDBF2F241C5C6A546D36D4 (void);
// 0x000000C2 System.Single UnityEngine.Experimental.Rendering.ProbeReferenceVolume/<>c::<RegisterDebug>b__119_6()
extern void U3CU3Ec_U3CRegisterDebugU3Eb__119_6_m6E8E407837C57C4260D9489B041ED9484DEE7DFC (void);
// 0x000000C3 System.Single UnityEngine.Experimental.Rendering.ProbeReferenceVolume/<>c::<RegisterDebug>b__119_15()
extern void U3CU3Ec_U3CRegisterDebugU3Eb__119_15_mACFEE7D12234C56D4B155F5C6ACD53736E3C160B (void);
// 0x000000C4 System.Single UnityEngine.Experimental.Rendering.ProbeReferenceVolume/<>c::<RegisterDebug>b__119_16()
extern void U3CU3Ec_U3CRegisterDebugU3Eb__119_16_mB4AAC3D53ABE490937C833F6969630C2FF4CB975 (void);
// 0x000000C5 System.Single UnityEngine.Experimental.Rendering.ProbeReferenceVolume/<>c::<RegisterDebug>b__119_21()
extern void U3CU3Ec_U3CRegisterDebugU3Eb__119_21_m6B35AAA316CF654D597351DA53502340E951100C (void);
// 0x000000C6 System.Int32 UnityEngine.Experimental.Rendering.ProbeReferenceVolume/<>c::<RegisterDebug>b__119_24()
extern void U3CU3Ec_U3CRegisterDebugU3Eb__119_24_mF332A62004E2F4AFDD64A7F5C629E5EFC3BF53B4 (void);
// 0x000000C7 System.Int32 UnityEngine.Experimental.Rendering.ProbeReferenceVolume/<>c::<RegisterDebug>b__119_25()
extern void U3CU3Ec_U3CRegisterDebugU3Eb__119_25_m4CE1255AD20E72D40153F8FBC1E9515285EA9201 (void);
// 0x000000C8 System.Void UnityEngine.Experimental.Rendering.ProbeVolumeDebug::.ctor()
extern void ProbeVolumeDebug__ctor_m708DA28435771F8ACB4930A38D58CBF1BCA1C000 (void);
// 0x000000C9 System.Int32 UnityEngine.Experimental.Rendering.ProbeReferenceVolumeProfile::get_cellSizeInBricks()
extern void ProbeReferenceVolumeProfile_get_cellSizeInBricks_m7F3B891F7A7B29639D078C918D846547935E1145 (void);
// 0x000000CA System.Int32 UnityEngine.Experimental.Rendering.ProbeReferenceVolumeProfile::get_maxSubdivision()
extern void ProbeReferenceVolumeProfile_get_maxSubdivision_m4FB3D73C94C5DEB8B4BCCBF05F63665FD2A52CAF (void);
// 0x000000CB System.Single UnityEngine.Experimental.Rendering.ProbeReferenceVolumeProfile::get_minBrickSize()
extern void ProbeReferenceVolumeProfile_get_minBrickSize_m2CCDD0EE00F450E9DDB4E2501F5FA90B673BDAD0 (void);
// 0x000000CC System.Single UnityEngine.Experimental.Rendering.ProbeReferenceVolumeProfile::get_cellSizeInMeters()
extern void ProbeReferenceVolumeProfile_get_cellSizeInMeters_mCEACEC12BCFE79F8DD0666EAA9A4F01E9228D817 (void);
// 0x000000CD System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolumeProfile::OnEnable()
extern void ProbeReferenceVolumeProfile_OnEnable_m07E993D2BFBBEBE408A171A58EF2A18FA47C60D3 (void);
// 0x000000CE System.Boolean UnityEngine.Experimental.Rendering.ProbeReferenceVolumeProfile::IsEquivalent(UnityEngine.Experimental.Rendering.ProbeReferenceVolumeProfile)
extern void ProbeReferenceVolumeProfile_IsEquivalent_m44EC1FC61D1F55A9A5547C876AE81BA4248D1975 (void);
// 0x000000CF System.Void UnityEngine.Experimental.Rendering.ProbeReferenceVolumeProfile::.ctor()
extern void ProbeReferenceVolumeProfile__ctor_mFA26873741A8E40621D22413547FEA6486C6407D (void);
// 0x000000D0 System.Void UnityEngine.Experimental.Rendering.ProbeVolume::.ctor()
extern void ProbeVolume__ctor_m737F5BD975F6AF4D1451BA8BBC4BE77832C2C282 (void);
// 0x000000D1 System.Int32 UnityEngine.Experimental.Rendering.ProbeVolumeAsset::get_Version()
extern void ProbeVolumeAsset_get_Version_m5081E5AFF96380FDA4A8223668368668E9818002 (void);
// 0x000000D2 System.Int32 UnityEngine.Experimental.Rendering.ProbeVolumeAsset::get_maxSubdivision()
extern void ProbeVolumeAsset_get_maxSubdivision_m25E44F3E71147B9737FC2F4A41E32C91CFB1DDE7 (void);
// 0x000000D3 System.Single UnityEngine.Experimental.Rendering.ProbeVolumeAsset::get_minBrickSize()
extern void ProbeVolumeAsset_get_minBrickSize_m64AB321C43569B209B7D4204FA7ADD218BB6438E (void);
// 0x000000D4 System.Boolean UnityEngine.Experimental.Rendering.ProbeVolumeAsset::CompatibleWith(UnityEngine.Experimental.Rendering.ProbeVolumeAsset)
extern void ProbeVolumeAsset_CompatibleWith_m5AD9B31F161A973E7E73935A7CC7BED920FE3F70 (void);
// 0x000000D5 System.String UnityEngine.Experimental.Rendering.ProbeVolumeAsset::GetSerializedFullPath()
extern void ProbeVolumeAsset_GetSerializedFullPath_mB4EE47E9598C9CB3DBF89987B5EDAA8350AEC7F5 (void);
// 0x000000D6 System.Void UnityEngine.Experimental.Rendering.ProbeVolumeAsset::.ctor()
extern void ProbeVolumeAsset__ctor_mE8BE9371AB032B37B201D07D3715FB7E2EB64385 (void);
// 0x000000D7 System.Void UnityEngine.Experimental.Rendering.ProbeVolumePerSceneData::OnAfterDeserialize()
extern void ProbeVolumePerSceneData_OnAfterDeserialize_m3ECAEC030DE8D59C3DD350AA65598E5444F53C25 (void);
// 0x000000D8 System.Void UnityEngine.Experimental.Rendering.ProbeVolumePerSceneData::OnBeforeSerialize()
extern void ProbeVolumePerSceneData_OnBeforeSerialize_mBA3F5C603A8C72A38E8560BF06504F30F0450F61 (void);
// 0x000000D9 System.Void UnityEngine.Experimental.Rendering.ProbeVolumePerSceneData::StoreAssetForState(UnityEngine.Experimental.Rendering.ProbeVolumeState,UnityEngine.Experimental.Rendering.ProbeVolumeAsset)
extern void ProbeVolumePerSceneData_StoreAssetForState_m17DD640B885E480290E2B65162F739567D9D608A (void);
// 0x000000DA System.Void UnityEngine.Experimental.Rendering.ProbeVolumePerSceneData::InvalidateAllAssets()
extern void ProbeVolumePerSceneData_InvalidateAllAssets_m10D2679D74E77770FB9504CA0263BCA41DC48C88 (void);
// 0x000000DB UnityEngine.Experimental.Rendering.ProbeVolumeAsset UnityEngine.Experimental.Rendering.ProbeVolumePerSceneData::GetCurrentStateAsset()
extern void ProbeVolumePerSceneData_GetCurrentStateAsset_m9EB714892D89A2F5081BB6ADEA72280A7995E899 (void);
// 0x000000DC System.Void UnityEngine.Experimental.Rendering.ProbeVolumePerSceneData::QueueAssetLoading()
extern void ProbeVolumePerSceneData_QueueAssetLoading_mB3CCF900B7CA8F944D9438889CF686C42E8BCEF6 (void);
// 0x000000DD System.Void UnityEngine.Experimental.Rendering.ProbeVolumePerSceneData::QueueAssetRemoval()
extern void ProbeVolumePerSceneData_QueueAssetRemoval_mB76429F8B335178B57FAEDB49ECED6DC194CB66D (void);
// 0x000000DE System.Void UnityEngine.Experimental.Rendering.ProbeVolumePerSceneData::OnEnable()
extern void ProbeVolumePerSceneData_OnEnable_m24345BC9A440EB8E1FFA9340851172013F0658AC (void);
// 0x000000DF System.Void UnityEngine.Experimental.Rendering.ProbeVolumePerSceneData::OnDisable()
extern void ProbeVolumePerSceneData_OnDisable_m70BFB2B9F03D9C4447050BF257894531E4C53231 (void);
// 0x000000E0 System.Void UnityEngine.Experimental.Rendering.ProbeVolumePerSceneData::OnDestroy()
extern void ProbeVolumePerSceneData_OnDestroy_m9AF9F2870FBBC5776F0B9D10510A4793D84A7CC0 (void);
// 0x000000E1 System.Void UnityEngine.Experimental.Rendering.ProbeVolumePerSceneData::Update()
extern void ProbeVolumePerSceneData_Update_m445730F8F5BDF5266887E8DA96EFDA8CD33F6DD9 (void);
// 0x000000E2 System.Void UnityEngine.Experimental.Rendering.ProbeVolumePerSceneData::.ctor()
extern void ProbeVolumePerSceneData__ctor_m9408DF107AA7456681BA0C04F8A8E9A4E0EAF5B7 (void);
// 0x000000E3 System.String UnityEngine.Experimental.Rendering.ProbeVolumeSceneData::GetSceneGUID(UnityEngine.SceneManagement.Scene)
extern void ProbeVolumeSceneData_GetSceneGUID_mEDF1CDD66EF5B4D894D922F3C919AC7EE628DABF (void);
// 0x000000E4 System.Void UnityEngine.Experimental.Rendering.ProbeVolumeSceneData::.ctor(UnityEngine.Object,System.String)
extern void ProbeVolumeSceneData__ctor_mC79958FE45F62F76DDD7046F40ABABBD8D88E4D8 (void);
// 0x000000E5 System.Void UnityEngine.Experimental.Rendering.ProbeVolumeSceneData::SetParentObject(UnityEngine.Object,System.String)
extern void ProbeVolumeSceneData_SetParentObject_m06049317E4479E7CA1A5BD7BA24A207B993CAED6 (void);
// 0x000000E6 System.Void UnityEngine.Experimental.Rendering.ProbeVolumeSceneData::OnAfterDeserialize()
extern void ProbeVolumeSceneData_OnAfterDeserialize_mA98482FCCA743C9D4883DAAC401D92370F0BDEE6 (void);
// 0x000000E7 System.Void UnityEngine.Experimental.Rendering.ProbeVolumeSceneData::UpdateBakingSets()
extern void ProbeVolumeSceneData_UpdateBakingSets_mA6C61749305923922789F8507BAD28CDF85E4769 (void);
// 0x000000E8 System.Void UnityEngine.Experimental.Rendering.ProbeVolumeSceneData::OnBeforeSerialize()
extern void ProbeVolumeSceneData_OnBeforeSerialize_mD933127ABD743AE08BB9623133D4BD2459EE95D7 (void);
// 0x000000E9 UnityEngine.Experimental.Rendering.ProbeVolumeSceneData/BakingSet UnityEngine.Experimental.Rendering.ProbeVolumeSceneData::CreateNewBakingSet(System.String)
extern void ProbeVolumeSceneData_CreateNewBakingSet_mD9E5E51600BC457D481FFDEE50C892120F6E354A (void);
// 0x000000EA System.Void UnityEngine.Experimental.Rendering.ProbeVolumeSceneData::InitializeBakingSet(UnityEngine.Experimental.Rendering.ProbeVolumeSceneData/BakingSet,System.String)
extern void ProbeVolumeSceneData_InitializeBakingSet_m6493E5485804047422125EAD079D8B3C6DEDB500 (void);
// 0x000000EB System.Void UnityEngine.Experimental.Rendering.ProbeVolumeSceneData::SyncBakingSetSettings()
extern void ProbeVolumeSceneData_SyncBakingSetSettings_m30FE1CEA523CFFFCA27F69D546C22CDE80E455D7 (void);
// 0x000000EC System.Void UnityEngine.Experimental.Rendering.ProbeVolumeSceneData::.cctor()
extern void ProbeVolumeSceneData__cctor_m23CA3899125A3FCB1F01FA2A2F5FB1F10E28B86F (void);
// 0x000000ED System.Void UnityEngine.Experimental.Rendering.ProbeVolumeSceneData/BakingSet::.ctor()
extern void BakingSet__ctor_m601231463B459E0CF1447D5A1D022AABFCA2980B (void);
// 0x000000EE System.Void UnityEngine.Experimental.Rendering.ProbeVolumeSceneData/<>c::.cctor()
extern void U3CU3Ec__cctor_mB28E86029A10C11C8BB3AB4D831C52C6CD52C156 (void);
// 0x000000EF System.Void UnityEngine.Experimental.Rendering.ProbeVolumeSceneData/<>c::.ctor()
extern void U3CU3Ec__ctor_m3C5DA28363F4562D232FF0D55ED8DC2DF669C3E3 (void);
// 0x000000F0 System.String UnityEngine.Experimental.Rendering.ProbeVolumeSceneData/<>c::<UpdateBakingSets>b__22_0(UnityEngine.Experimental.Rendering.ProbeVolumeSceneData/SerializablePVProfile)
extern void U3CU3Ec_U3CUpdateBakingSetsU3Eb__22_0_mC7641AC5D1E5C3C4E6626308BB731C5A03A0D85C (void);
// 0x000000F1 System.Boolean UnityEngine.Experimental.Rendering.RendererList::get_isValid()
extern void RendererList_get_isValid_mD49D7348F5E73DD10528CA33E7E47D045F59ABA4 (void);
// 0x000000F2 System.Void UnityEngine.Experimental.Rendering.RendererList::set_isValid(System.Boolean)
extern void RendererList_set_isValid_m5A13F01C3632E0EA366E89F731C758D9416458E4 (void);
// 0x000000F3 UnityEngine.Experimental.Rendering.RendererList UnityEngine.Experimental.Rendering.RendererList::Create(UnityEngine.Experimental.Rendering.RendererListDesc&)
extern void RendererList_Create_mF62DD90614DB1DF03AF5B8ECFF6C81D0F44F2996 (void);
// 0x000000F4 System.Void UnityEngine.Experimental.Rendering.RendererList::.cctor()
extern void RendererList__cctor_mF580866A1CDFFB29AB85A713748A5D935A32BC5B (void);
// 0x000000F5 UnityEngine.Rendering.CullingResults UnityEngine.Experimental.Rendering.RendererListDesc::get_cullingResult()
extern void RendererListDesc_get_cullingResult_m1A24ED379AEDF626576FD7D25A2C4C7EC731583D (void);
// 0x000000F6 System.Void UnityEngine.Experimental.Rendering.RendererListDesc::set_cullingResult(UnityEngine.Rendering.CullingResults)
extern void RendererListDesc_set_cullingResult_mE8327030ABADA58F7278D2E0A53AA24B85FE0D38 (void);
// 0x000000F7 UnityEngine.Camera UnityEngine.Experimental.Rendering.RendererListDesc::get_camera()
extern void RendererListDesc_get_camera_mA2374241B35A95DCE62E723B25CC991D6DF44360 (void);
// 0x000000F8 System.Void UnityEngine.Experimental.Rendering.RendererListDesc::set_camera(UnityEngine.Camera)
extern void RendererListDesc_set_camera_m5622A8534724C11905739E4717F697C4E79A50C3 (void);
// 0x000000F9 UnityEngine.Rendering.ShaderTagId UnityEngine.Experimental.Rendering.RendererListDesc::get_passName()
extern void RendererListDesc_get_passName_m2ABCDEA61E228A46952E7F12895B65C10AB874FA (void);
// 0x000000FA System.Void UnityEngine.Experimental.Rendering.RendererListDesc::set_passName(UnityEngine.Rendering.ShaderTagId)
extern void RendererListDesc_set_passName_m48E2013C7D08B499D53125C5791F9FF5540F9BD0 (void);
// 0x000000FB UnityEngine.Rendering.ShaderTagId[] UnityEngine.Experimental.Rendering.RendererListDesc::get_passNames()
extern void RendererListDesc_get_passNames_mC78CE5AC5BAB6381686AEB1CCDBAAFDEEB020FC0 (void);
// 0x000000FC System.Void UnityEngine.Experimental.Rendering.RendererListDesc::set_passNames(UnityEngine.Rendering.ShaderTagId[])
extern void RendererListDesc_set_passNames_m1E72B7C01C5EA221BE6CEE9694384319FD67919C (void);
// 0x000000FD System.Void UnityEngine.Experimental.Rendering.RendererListDesc::.ctor(UnityEngine.Rendering.ShaderTagId,UnityEngine.Rendering.CullingResults,UnityEngine.Camera)
extern void RendererListDesc__ctor_mEDAF51BE78BCD5D4F4A2055C75B52C0BDB7448C2 (void);
// 0x000000FE System.Void UnityEngine.Experimental.Rendering.RendererListDesc::.ctor(UnityEngine.Rendering.ShaderTagId[],UnityEngine.Rendering.CullingResults,UnityEngine.Camera)
extern void RendererListDesc__ctor_mD7954B9620C618E46313FE4AACDAE9A777652794 (void);
// 0x000000FF System.Boolean UnityEngine.Experimental.Rendering.RendererListDesc::IsValid()
extern void RendererListDesc_IsValid_m424FC29A8206B9F2D11EC1C937762D1E1ABACAA5 (void);
// 0x00000100 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphContext::.ctor()
extern void RenderGraphContext__ctor_mE362BBACE6D5A945C9CC34B7AAEA715F7DFB9BF6 (void);
// 0x00000101 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphExecution::.ctor(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph)
extern void RenderGraphExecution__ctor_m6F5D9030833807A2480E493C092CD067D6CD042E (void);
// 0x00000102 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphExecution::Dispose()
extern void RenderGraphExecution_Dispose_m2A4832CC0BAA3642B791D033538C6E97FBAE3D67 (void);
// 0x00000103 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDebugParams::RegisterDebug(System.String,UnityEngine.Rendering.DebugUI/Panel)
extern void RenderGraphDebugParams_RegisterDebug_m51C8C65167E33516E765B3D8FEF39DA518959500 (void);
// 0x00000104 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDebugParams::UnRegisterDebug(System.String)
extern void RenderGraphDebugParams_UnRegisterDebug_mDAB7FCE72ABFC96BCA3D299794D8017AE8D05D73 (void);
// 0x00000105 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDebugParams::.ctor()
extern void RenderGraphDebugParams__ctor_m174FCBE11F53D73C56586A51B98AC56C6BAEDF3D (void);
// 0x00000106 System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDebugParams::<RegisterDebug>b__10_0()
extern void RenderGraphDebugParams_U3CRegisterDebugU3Eb__10_0_m515BE24E9CB99FEF73990F99C9C4CFCF5BD97568 (void);
// 0x00000107 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDebugParams::<RegisterDebug>b__10_1(System.Boolean)
extern void RenderGraphDebugParams_U3CRegisterDebugU3Eb__10_1_m53C6672B4B92C97F61D7D24E50DAD0D8750A9C91 (void);
// 0x00000108 System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDebugParams::<RegisterDebug>b__10_2()
extern void RenderGraphDebugParams_U3CRegisterDebugU3Eb__10_2_m1C26FD7DF27A18C57067A2F339479A854CE93BCD (void);
// 0x00000109 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDebugParams::<RegisterDebug>b__10_3(System.Boolean)
extern void RenderGraphDebugParams_U3CRegisterDebugU3Eb__10_3_m5CFDDCA3F495056CBE68775752C840672D5B4F6D (void);
// 0x0000010A System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDebugParams::<RegisterDebug>b__10_4()
extern void RenderGraphDebugParams_U3CRegisterDebugU3Eb__10_4_m86E5D492172D8428AF2102DAA2FF198585C99DF2 (void);
// 0x0000010B System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDebugParams::<RegisterDebug>b__10_5(System.Boolean)
extern void RenderGraphDebugParams_U3CRegisterDebugU3Eb__10_5_m7D05EDCCFE8AC1D6B11A10F6361B27788A5B3844 (void);
// 0x0000010C System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDebugParams::<RegisterDebug>b__10_6()
extern void RenderGraphDebugParams_U3CRegisterDebugU3Eb__10_6_mD4C4027444FFC2AEF974557E7896ECBCABD9E3E0 (void);
// 0x0000010D System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDebugParams::<RegisterDebug>b__10_7(System.Boolean)
extern void RenderGraphDebugParams_U3CRegisterDebugU3Eb__10_7_m628CB428D0BEEC1EB1B1AA34E7CFA4B688DE7411 (void);
// 0x0000010E System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDebugParams::<RegisterDebug>b__10_8()
extern void RenderGraphDebugParams_U3CRegisterDebugU3Eb__10_8_m1266BEC68718D058CD4D7BAA205D64CE57253775 (void);
// 0x0000010F System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDebugParams::<RegisterDebug>b__10_9()
extern void RenderGraphDebugParams_U3CRegisterDebugU3Eb__10_9_m50F3726EADBCE25A641CCE4BA38E56F9893AA18D (void);
// 0x00000110 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDebugParams/Strings::.cctor()
extern void Strings__cctor_m17897CC58A382F5F3C5B9F5AAAA84158483E37EB (void);
// 0x00000111 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderFunc`1::.ctor(System.Object,System.IntPtr)
// 0x00000112 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderFunc`1::Invoke(PassData,UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphContext)
// 0x00000113 System.IAsyncResult UnityEngine.Experimental.Rendering.RenderGraphModule.RenderFunc`1::BeginInvoke(PassData,UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphContext,System.AsyncCallback,System.Object)
// 0x00000114 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderFunc`1::EndInvoke(System.IAsyncResult)
// 0x00000115 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDebugData::Clear()
extern void RenderGraphDebugData_Clear_m657D4C201FBC74990BFDCB39028E506F76C7FB89 (void);
// 0x00000116 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDebugData::.ctor()
extern void RenderGraphDebugData__ctor_m801AC7375A90EF3C120F18F1080B3C8B37ACBDFA (void);
// 0x00000117 System.String UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::get_name()
extern void RenderGraph_get_name_mC4A86F3C3445D41324598444AD9C35152B1415D9 (void);
// 0x00000118 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::set_name(System.String)
extern void RenderGraph_set_name_m5B537C5BD0514C94A202FA6D91E33E0FF8D3BC35 (void);
// 0x00000119 System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::get_requireDebugData()
extern void RenderGraph_get_requireDebugData_m299B15A8D7F053AB63B036CD1E29E6E9CBA5A052 (void);
// 0x0000011A System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::set_requireDebugData(System.Boolean)
extern void RenderGraph_set_requireDebugData_m4038058EA46EBEFCF4137B5A59A66FCBB6D55050 (void);
// 0x0000011B UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::get_defaultResources()
extern void RenderGraph_get_defaultResources_mAF14CF66D8EEB8E7BE53241437E9D7005C662E17 (void);
// 0x0000011C System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::.ctor(System.String)
extern void RenderGraph__ctor_m8E28DE4BAE8C24B9FC9C71526B5DA8E3BF216318 (void);
// 0x0000011D System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::Cleanup()
extern void RenderGraph_Cleanup_m1FBACDF1EC2B2FE4372A2B1CA4A3E0AD811A98E7 (void);
// 0x0000011E System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::RegisterDebug(UnityEngine.Rendering.DebugUI/Panel)
extern void RenderGraph_RegisterDebug_mFD45ABD9F1F32C4959827350213615F13AC51E84 (void);
// 0x0000011F System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::UnRegisterDebug()
extern void RenderGraph_UnRegisterDebug_mF5F358A8AD539BB8EE38311974F863EDCBBCCA57 (void);
// 0x00000120 System.Collections.Generic.List`1<UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph> UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::GetRegisteredRenderGraphs()
extern void RenderGraph_GetRegisteredRenderGraphs_m6139A25BC24D96370556B9F85BC2D16963A48B12 (void);
// 0x00000121 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDebugData UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::GetDebugData(System.String)
extern void RenderGraph_GetDebugData_mC0F5A0B530BEE7BA47958E52F5EBCC1DCFD0EA29 (void);
// 0x00000122 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::EndFrame()
extern void RenderGraph_EndFrame_m8F0177400497B5A5BDC0775733EFC226C7BC0738 (void);
// 0x00000123 UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::ImportTexture(UnityEngine.Rendering.RTHandle)
extern void RenderGraph_ImportTexture_m295CC3D6BDBC43559F09E006FFF6B46DE85214A4 (void);
// 0x00000124 UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::ImportBackbuffer(UnityEngine.Rendering.RenderTargetIdentifier)
extern void RenderGraph_ImportBackbuffer_mE4923F3B0BC4CBEC1943F8ED1B9E8DE22ACFAD8E (void);
// 0x00000125 UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::CreateTexture(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureDesc&)
extern void RenderGraph_CreateTexture_m07CDAF13A95DB913C44DD1FF0C1AE8B8F00E449D (void);
// 0x00000126 UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::CreateSharedTexture(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureDesc&,System.Boolean)
extern void RenderGraph_CreateSharedTexture_mD8134A13CA15AF8FC996DD684BCA1D68B5373458 (void);
// 0x00000127 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::ReleaseSharedTexture(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle)
extern void RenderGraph_ReleaseSharedTexture_m92F19DDC5582AF56B03F3F96C1F4507FB42496CF (void);
// 0x00000128 UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::CreateTexture(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle)
extern void RenderGraph_CreateTexture_m330C23C19354F500907E91D67CDCD2F80D07F9C1 (void);
// 0x00000129 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::CreateTextureIfInvalid(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureDesc&,UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle&)
extern void RenderGraph_CreateTextureIfInvalid_m51DCBC54B88B235A04ABC91E76AA4187AFE80CED (void);
// 0x0000012A UnityEngine.Experimental.Rendering.RenderGraphModule.TextureDesc UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::GetTextureDesc(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle)
extern void RenderGraph_GetTextureDesc_m85050E98790D28024E3F6018482ADE5A68B76E21 (void);
// 0x0000012B UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::CreateRendererList(UnityEngine.Rendering.RendererUtils.RendererListDesc&)
extern void RenderGraph_CreateRendererList_mC345302092D73FC40883DD4299A02157901D01A4 (void);
// 0x0000012C UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::ImportComputeBuffer(UnityEngine.ComputeBuffer)
extern void RenderGraph_ImportComputeBuffer_mF773FE1CFF9FA2EDC0CEBC609A7397236E81A7E5 (void);
// 0x0000012D UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::CreateComputeBuffer(UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferDesc&)
extern void RenderGraph_CreateComputeBuffer_m58DF8F141D7D9DFAAD1E7A16928DC28F14B3BF5F (void);
// 0x0000012E UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::CreateComputeBuffer(UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle&)
extern void RenderGraph_CreateComputeBuffer_m0091B1FE0C84982F40EB7E6B9A5B617B3AA1EAFA (void);
// 0x0000012F UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferDesc UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::GetComputeBufferDesc(UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle&)
extern void RenderGraph_GetComputeBufferDesc_mDB7040D7800CAD0C2CC23A94AAE2251767E70FF1 (void);
// 0x00000130 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::AddRenderPass(System.String,PassData&,UnityEngine.Rendering.ProfilingSampler)
// 0x00000131 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::AddRenderPass(System.String,PassData&)
// 0x00000132 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphExecution UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::RecordAndExecute(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphParameters&)
extern void RenderGraph_RecordAndExecute_mABC2B51A63CA24C4CD32BA867B54879FCE48EF6E (void);
// 0x00000133 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::Execute()
extern void RenderGraph_Execute_m3A7348FDC7FCE5C9EAE32410C4A8F3E06CD0C9A0 (void);
// 0x00000134 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::BeginProfilingSampler(UnityEngine.Rendering.ProfilingSampler)
extern void RenderGraph_BeginProfilingSampler_m080E79B3E0E59C9791E59149FE65048B3A75F21F (void);
// 0x00000135 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::EndProfilingSampler(UnityEngine.Rendering.ProfilingSampler)
extern void RenderGraph_EndProfilingSampler_m7D8308D0AD1C7E10F2F21AADE8FD8A55B56127D5 (void);
// 0x00000136 UnityEngine.Rendering.DynamicArray`1<UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/CompiledPassInfo> UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::GetCompiledPassInfos()
extern void RenderGraph_GetCompiledPassInfos_m23F7801BED40A4F9940B371D7CD193E66040BD76 (void);
// 0x00000137 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::ClearCompiledGraph()
extern void RenderGraph_ClearCompiledGraph_m0DE88504194BD409BF8DF5283796C1BD510A9393 (void);
// 0x00000138 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::InvalidateContext()
extern void RenderGraph_InvalidateContext_m1A18ACC5B65EB13EA2B839837A2DC6EE844DE481 (void);
// 0x00000139 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::OnPassAdded(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass)
extern void RenderGraph_OnPassAdded_mD1E58984AA84ED4DC78BF2E11A9C6D482F47C8F6 (void);
// 0x0000013A System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::add_onGraphRegistered(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/OnGraphRegisteredDelegate)
extern void RenderGraph_add_onGraphRegistered_m0D0C254927D1D710A20590044BF0ED12CB10F87A (void);
// 0x0000013B System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::remove_onGraphRegistered(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/OnGraphRegisteredDelegate)
extern void RenderGraph_remove_onGraphRegistered_m2569676235DE7FEF0C70D89413F6DCF63C44F3B3 (void);
// 0x0000013C System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::add_onGraphUnregistered(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/OnGraphRegisteredDelegate)
extern void RenderGraph_add_onGraphUnregistered_mEED68801F08877C5D913946285D2CC37F62FBCDD (void);
// 0x0000013D System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::remove_onGraphUnregistered(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/OnGraphRegisteredDelegate)
extern void RenderGraph_remove_onGraphUnregistered_m7D4E732FC2B618A4D884062BD90B5E4E0A6F3F81 (void);
// 0x0000013E System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::add_onExecutionRegistered(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/OnExecutionRegisteredDelegate)
extern void RenderGraph_add_onExecutionRegistered_mD7F36AB7CB81CB3F98A89F8DBFF7835B72766060 (void);
// 0x0000013F System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::remove_onExecutionRegistered(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/OnExecutionRegisteredDelegate)
extern void RenderGraph_remove_onExecutionRegistered_mE863BB6C6FF6F4F067F8C9E27DC7E73DB62BAC0B (void);
// 0x00000140 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::add_onExecutionUnregistered(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/OnExecutionRegisteredDelegate)
extern void RenderGraph_add_onExecutionUnregistered_m2FEE3AB55CFC3DED7AC9A1863694AD6CAB05C833 (void);
// 0x00000141 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::remove_onExecutionUnregistered(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/OnExecutionRegisteredDelegate)
extern void RenderGraph_remove_onExecutionUnregistered_m295401B259C64E12C8C8F865082FFB614269C102 (void);
// 0x00000142 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::InitResourceInfosData(UnityEngine.Rendering.DynamicArray`1<UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/CompiledResourceInfo>,System.Int32)
extern void RenderGraph_InitResourceInfosData_m3EFB0384E5DA0045B7FBF29FD05DCFE2963BE9DB (void);
// 0x00000143 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::InitializeCompilationData()
extern void RenderGraph_InitializeCompilationData_mF068DA94C4DF2E138784B78B1D8D090AF1302851 (void);
// 0x00000144 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::CountReferences()
extern void RenderGraph_CountReferences_m9DC624F39709CBA8D2CBBF4B4D906B1A61FA3EC9 (void);
// 0x00000145 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::CullUnusedPasses()
extern void RenderGraph_CullUnusedPasses_m64210243D88F8DB8A3D715AFA329A0C7A73E88F5 (void);
// 0x00000146 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::UpdatePassSynchronization(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/CompiledPassInfo&,UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/CompiledPassInfo&,System.Int32,System.Int32,System.Int32&)
extern void RenderGraph_UpdatePassSynchronization_m8DBDEA74E81751778977198189A8A6FF60565956 (void);
// 0x00000147 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::UpdateResourceSynchronization(System.Int32&,System.Int32&,System.Int32,UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/CompiledResourceInfo&)
extern void RenderGraph_UpdateResourceSynchronization_m625302659B60F575732E9F62557F87B321C0F159 (void);
// 0x00000148 System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::GetLatestProducerIndex(System.Int32,UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/CompiledResourceInfo&)
extern void RenderGraph_GetLatestProducerIndex_m01A352F68254570D2DD917A81335DE75A76769C1 (void);
// 0x00000149 System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::GetLatestValidReadIndex(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/CompiledResourceInfo&)
extern void RenderGraph_GetLatestValidReadIndex_mAB6EBE37C8C9215BD9BF88FB7358D6E6C55EC3F3 (void);
// 0x0000014A System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::GetFirstValidWriteIndex(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/CompiledResourceInfo&)
extern void RenderGraph_GetFirstValidWriteIndex_mC093325F0690ABF05180FAAC5E977FD08B2632ED (void);
// 0x0000014B System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::GetLatestValidWriteIndex(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/CompiledResourceInfo&)
extern void RenderGraph_GetLatestValidWriteIndex_m4CEDB92D670D89F208C6BA6F53010B6EDF9948A7 (void);
// 0x0000014C System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::CreateRendererLists()
extern void RenderGraph_CreateRendererLists_mEEAD372353B35077B070CB1BAA74835584B55C51 (void);
// 0x0000014D System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::UpdateResourceAllocationAndSynchronization()
extern void RenderGraph_UpdateResourceAllocationAndSynchronization_mB7D2F33083A27279542DD9E8441ACD321E4CA4D6 (void);
// 0x0000014E System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::AreRendererListsEmpty(System.Collections.Generic.List`1<UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListHandle>)
extern void RenderGraph_AreRendererListsEmpty_m91D5C2C7847B0C80F1FA3F9702584B4A4CFE17AB (void);
// 0x0000014F System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::TryCullPassAtIndex(System.Int32)
extern void RenderGraph_TryCullPassAtIndex_m639A11CCD33AC494CF80729B119D96AD66B170EF (void);
// 0x00000150 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::CullRendererLists()
extern void RenderGraph_CullRendererLists_mC9C6AABBB3746B088D3780AE69B43B06DED42376 (void);
// 0x00000151 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::CompileRenderGraph()
extern void RenderGraph_CompileRenderGraph_mEEBE1E435ED4B9A20825249E815B69F44539591B (void);
// 0x00000152 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/CompiledPassInfo& UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::CompilePassImmediatly(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass)
extern void RenderGraph_CompilePassImmediatly_m92E065229F1EF3C25D1230A580667D8018820E2F (void);
// 0x00000153 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::ExecutePassImmediatly(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass)
extern void RenderGraph_ExecutePassImmediatly_mD99F62E498775D67EC8CC417961D6A7E4429F22E (void);
// 0x00000154 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::ExecuteCompiledPass(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/CompiledPassInfo&,System.Int32)
extern void RenderGraph_ExecuteCompiledPass_m7CBD442272FF60B36465B84E876666208DF08FA3 (void);
// 0x00000155 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::ExecuteRenderGraph()
extern void RenderGraph_ExecuteRenderGraph_mE44E864C7A9B048462C97FED00FAD7DF70573596 (void);
// 0x00000156 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::PreRenderPassSetRenderTargets(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/CompiledPassInfo&,UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphContext)
extern void RenderGraph_PreRenderPassSetRenderTargets_m0F0E5AAFE38BB32E0ACE34E280AC7AD12A8A89F5 (void);
// 0x00000157 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::PreRenderPassExecute(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/CompiledPassInfo&,UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphContext)
extern void RenderGraph_PreRenderPassExecute_mEF0EFA297299022E67CEF87AC8BD3EDF78A5667C (void);
// 0x00000158 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::PostRenderPassExecute(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/CompiledPassInfo&,UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphContext)
extern void RenderGraph_PostRenderPassExecute_mE6A75DA79257A9010C88CF6B2C823F1873088EC5 (void);
// 0x00000159 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::ClearRenderPasses()
extern void RenderGraph_ClearRenderPasses_m123192412280C189D7980A24D7127A7D59B1656C (void);
// 0x0000015A System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::ReleaseImmediateModeResources()
extern void RenderGraph_ReleaseImmediateModeResources_m355F6460365E667F706125B7517086DAA05F7A85 (void);
// 0x0000015B System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::LogFrameInformation()
extern void RenderGraph_LogFrameInformation_mB13932F07DC2BAE648A3A058BB493BDDA53C36DD (void);
// 0x0000015C System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::LogRendererListsCreation()
extern void RenderGraph_LogRendererListsCreation_m87AFBC726B030CB909743F6EC01C8E39298B8ECF (void);
// 0x0000015D System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::LogRenderPassBegin(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/CompiledPassInfo&)
extern void RenderGraph_LogRenderPassBegin_mD26259CB5E7D98663701A629BFE91432F7D6DB35 (void);
// 0x0000015E System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::LogCulledPasses()
extern void RenderGraph_LogCulledPasses_m22B819CF1E35F1A037D215E5B1B28C2819BBB51E (void);
// 0x0000015F UnityEngine.Rendering.ProfilingSampler UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::GetDefaultProfilingSampler(System.String)
extern void RenderGraph_GetDefaultProfilingSampler_m7B7625ADCAE0FF51ED32E646959D4137C2B5C437 (void);
// 0x00000160 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::UpdateImportedResourceLifeTime(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDebugData/ResourceDebugData&,System.Collections.Generic.List`1<System.Int32>)
extern void RenderGraph_UpdateImportedResourceLifeTime_mBE3EDE5D4C257716779709B5ABB8BF27417C9DAA (void);
// 0x00000161 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::GenerateDebugData()
extern void RenderGraph_GenerateDebugData_mBC7800454D14E60A58AF27105635C6B3B9A62174 (void);
// 0x00000162 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::CleanupDebugData()
extern void RenderGraph_CleanupDebugData_mB0804703AF2CFA8C4D2584E030BD58ACF049DFC1 (void);
// 0x00000163 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph::.cctor()
extern void RenderGraph__cctor_m57CC05DB7D321025041B3AC45C7F9D18F70301AD (void);
// 0x00000164 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/CompiledResourceInfo::Reset()
extern void CompiledResourceInfo_Reset_m37F299281DE9EEB99B9ADBC35125F59765D77A7E (void);
// 0x00000165 System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/CompiledPassInfo::get_allowPassCulling()
extern void CompiledPassInfo_get_allowPassCulling_m19A371EF46D18F2FB95B569004344184EE159F3A (void);
// 0x00000166 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/CompiledPassInfo::Reset(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass)
extern void CompiledPassInfo_Reset_mD739628D66EE219B4039E42DC685D5AAD09FCCD5 (void);
// 0x00000167 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/ProfilingScopePassData::.ctor()
extern void ProfilingScopePassData__ctor_mE65C7FE9C6F68526E7C52033349A32C8412C54BF (void);
// 0x00000168 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/OnGraphRegisteredDelegate::.ctor(System.Object,System.IntPtr)
extern void OnGraphRegisteredDelegate__ctor_mBF475B620BDA057E27E35DF0D2E2B635B5F7A1F7 (void);
// 0x00000169 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/OnGraphRegisteredDelegate::Invoke(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph)
extern void OnGraphRegisteredDelegate_Invoke_mC9549D2FDF84731F604FEC183A1991248D14AA2C (void);
// 0x0000016A System.IAsyncResult UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/OnGraphRegisteredDelegate::BeginInvoke(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph,System.AsyncCallback,System.Object)
extern void OnGraphRegisteredDelegate_BeginInvoke_m721B71F047A8E1912DF5C565FEC9E4FF512A4412 (void);
// 0x0000016B System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/OnGraphRegisteredDelegate::EndInvoke(System.IAsyncResult)
extern void OnGraphRegisteredDelegate_EndInvoke_m9FAF8CC04036C4FCA52B31D800C8E169E1724D3C (void);
// 0x0000016C System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/OnExecutionRegisteredDelegate::.ctor(System.Object,System.IntPtr)
extern void OnExecutionRegisteredDelegate__ctor_m381043C04E0B63FAA6A7D116018B634481B201CB (void);
// 0x0000016D System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/OnExecutionRegisteredDelegate::Invoke(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph,System.String)
extern void OnExecutionRegisteredDelegate_Invoke_m02D2B7F3514909A2E1DD5C17C5F8770BEF828CE1 (void);
// 0x0000016E System.IAsyncResult UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/OnExecutionRegisteredDelegate::BeginInvoke(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph,System.String,System.AsyncCallback,System.Object)
extern void OnExecutionRegisteredDelegate_BeginInvoke_m181019B8E8810BC94A25060D80852015DE4B0D2A (void);
// 0x0000016F System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/OnExecutionRegisteredDelegate::EndInvoke(System.IAsyncResult)
extern void OnExecutionRegisteredDelegate_EndInvoke_m46D98B4FDD6D5D73D62758651E178705BCC3A27E (void);
// 0x00000170 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/<>c::.cctor()
extern void U3CU3Ec__cctor_m0832A40A190394AD9FB5175A83F9E475F3E35B6E (void);
// 0x00000171 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/<>c::.ctor()
extern void U3CU3Ec__ctor_m5E46E3271E2445F78FB3B0F9150A302F1D323B15 (void);
// 0x00000172 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/<>c::<BeginProfilingSampler>b__61_0(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/ProfilingScopePassData,UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphContext)
extern void U3CU3Ec_U3CBeginProfilingSamplerU3Eb__61_0_m59488D9D6AEA1CED8C5043FAA1ED7043BADEC627 (void);
// 0x00000173 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/<>c::<EndProfilingSampler>b__62_0(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph/ProfilingScopePassData,UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphContext)
extern void U3CU3Ec_U3CEndProfilingSamplerU3Eb__62_0_mF7F5701CC58F1FBF0468B1DD7A9407E1E5E0752B (void);
// 0x00000174 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphProfilingScope::.ctor(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph,UnityEngine.Rendering.ProfilingSampler)
extern void RenderGraphProfilingScope__ctor_m33361E4872EC1955DC1C93B1252729C6F8AF2086 (void);
// 0x00000175 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphProfilingScope::Dispose()
extern void RenderGraphProfilingScope_Dispose_mF856703A7FA42EB3DDBE8EA78BA08DCEF8AAC971 (void);
// 0x00000176 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphProfilingScope::Dispose(System.Boolean)
extern void RenderGraphProfilingScope_Dispose_mD7AE540A4B899A562FD851CFABAFE458F1E9A5A7 (void);
// 0x00000177 UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::UseColorBuffer(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle&,System.Int32)
extern void RenderGraphBuilder_UseColorBuffer_mBAFAA9789D8E5085F01F2E8798746E0A4C48D5B3 (void);
// 0x00000178 UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::UseDepthBuffer(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle&,UnityEngine.Experimental.Rendering.RenderGraphModule.DepthAccess)
extern void RenderGraphBuilder_UseDepthBuffer_m52A44A353C52E10E3DBFAF26A87F86EB08310604 (void);
// 0x00000179 UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::ReadTexture(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle&)
extern void RenderGraphBuilder_ReadTexture_m30A338D1203C736F18E9EDFE24A4208384D0925F (void);
// 0x0000017A UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::WriteTexture(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle&)
extern void RenderGraphBuilder_WriteTexture_m506070A8AC6CD4948CBB01FC02E2B2FF2D002920 (void);
// 0x0000017B UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::ReadWriteTexture(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle&)
extern void RenderGraphBuilder_ReadWriteTexture_mEA66A932C42979F8EE0C1F402E5A6ED084F01836 (void);
// 0x0000017C UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::CreateTransientTexture(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureDesc&)
extern void RenderGraphBuilder_CreateTransientTexture_m703B7C4E31B2F4B2857E05B8FE4E9993157163D0 (void);
// 0x0000017D UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::CreateTransientTexture(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle&)
extern void RenderGraphBuilder_CreateTransientTexture_mC507AB02FE73C2F38389C79D9099EDC7F704688C (void);
// 0x0000017E UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::UseRendererList(UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListHandle&)
extern void RenderGraphBuilder_UseRendererList_mB0614B837677977DF8A14FDBF95146A74B3EE284 (void);
// 0x0000017F UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::ReadComputeBuffer(UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle&)
extern void RenderGraphBuilder_ReadComputeBuffer_mA630B01D686BE9AB88772818404667D1E69F05D4 (void);
// 0x00000180 UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::WriteComputeBuffer(UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle&)
extern void RenderGraphBuilder_WriteComputeBuffer_mCD7FAF2B083871011645D4CCD2E4A92781F7B495 (void);
// 0x00000181 UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::CreateTransientComputeBuffer(UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferDesc&)
extern void RenderGraphBuilder_CreateTransientComputeBuffer_mCFBDA8024544593AFE98147876B902E4753AFB7D (void);
// 0x00000182 UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::CreateTransientComputeBuffer(UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle&)
extern void RenderGraphBuilder_CreateTransientComputeBuffer_m59F48C032018CBE9FF26DCDF27C57B002F2B9A1D (void);
// 0x00000183 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::SetRenderFunc(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderFunc`1<PassData>)
// 0x00000184 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::EnableAsyncCompute(System.Boolean)
extern void RenderGraphBuilder_EnableAsyncCompute_mE27B28C6B8176AD36DBB5B4EE0DA800D90F87B03 (void);
// 0x00000185 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::AllowPassCulling(System.Boolean)
extern void RenderGraphBuilder_AllowPassCulling_m123C799CF19AF7D92A976CCC235C6721F1D8EE86 (void);
// 0x00000186 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::Dispose()
extern void RenderGraphBuilder_Dispose_m6CD2A0E7451C1E81E016C27394732E07F6C53071 (void);
// 0x00000187 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::AllowRendererListCulling(System.Boolean)
extern void RenderGraphBuilder_AllowRendererListCulling_m1D4E879CAC013591F860F5C429D007D6ACF692F2 (void);
// 0x00000188 UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::DependsOn(UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListHandle&)
extern void RenderGraphBuilder_DependsOn_mBF3A650716934BE44D1314668B1EC60CB1A62426 (void);
// 0x00000189 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::.ctor(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass,UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry,UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph)
extern void RenderGraphBuilder__ctor_m356E87D6D032DF11F1909F32C011B98CFB16D7DE (void);
// 0x0000018A System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::Dispose(System.Boolean)
extern void RenderGraphBuilder_Dispose_m49A9299AD6BF815801312F85C7B6256C5575085B (void);
// 0x0000018B System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::CheckResource(UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle&,System.Boolean)
extern void RenderGraphBuilder_CheckResource_m5BF5C4956D9B0FA14EBBE35D84650212A2F0F7C6 (void);
// 0x0000018C System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphBuilder::GenerateDebugData(System.Boolean)
extern void RenderGraphBuilder_GenerateDebugData_mA7FBEB0EDD92133A1B737F8805349D57A368B6FC (void);
// 0x0000018D UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::get_blackTexture()
extern void RenderGraphDefaultResources_get_blackTexture_m958B2388E4F81582528BFB5A627A8996A11803C7 (void);
// 0x0000018E System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::set_blackTexture(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle)
extern void RenderGraphDefaultResources_set_blackTexture_m74BF0C27CB9B249D083B3659C985A952EC3B4759 (void);
// 0x0000018F UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::get_whiteTexture()
extern void RenderGraphDefaultResources_get_whiteTexture_mA110B74B58D4E59C7DBD489FAFA8F2648AC7C0CF (void);
// 0x00000190 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::set_whiteTexture(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle)
extern void RenderGraphDefaultResources_set_whiteTexture_m0CBA5992252D94A798EC0F5C2D8E5C740665BF80 (void);
// 0x00000191 UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::get_clearTextureXR()
extern void RenderGraphDefaultResources_get_clearTextureXR_m8D433C546AD5EBBA8005CC6FACF2BE8CE3ABBCC5 (void);
// 0x00000192 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::set_clearTextureXR(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle)
extern void RenderGraphDefaultResources_set_clearTextureXR_m58EC34F05A82BED1A96F9AB405D74BA9FB0F6531 (void);
// 0x00000193 UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::get_magentaTextureXR()
extern void RenderGraphDefaultResources_get_magentaTextureXR_m215CC94319969BF117853F0F2C10134CFA116867 (void);
// 0x00000194 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::set_magentaTextureXR(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle)
extern void RenderGraphDefaultResources_set_magentaTextureXR_m86AA147802A13D59DC3FEB19786C756587E086FB (void);
// 0x00000195 UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::get_blackTextureXR()
extern void RenderGraphDefaultResources_get_blackTextureXR_m7F3BED63C3F3A123D2539291E627AD370C3BEE7D (void);
// 0x00000196 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::set_blackTextureXR(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle)
extern void RenderGraphDefaultResources_set_blackTextureXR_mBC67F3C0CFAF725BD6AD9F00655D0F7D28AB481F (void);
// 0x00000197 UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::get_blackTextureArrayXR()
extern void RenderGraphDefaultResources_get_blackTextureArrayXR_m9D842DD3FC9C8D92B85A4EA4BF75438D2CB54728 (void);
// 0x00000198 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::set_blackTextureArrayXR(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle)
extern void RenderGraphDefaultResources_set_blackTextureArrayXR_m718E584F8DBCE5CBEF6BF9E6CB3A9BFC93A07B2A (void);
// 0x00000199 UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::get_blackUIntTextureXR()
extern void RenderGraphDefaultResources_get_blackUIntTextureXR_m781231EE0405206EDB142D84568F77392CE989A9 (void);
// 0x0000019A System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::set_blackUIntTextureXR(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle)
extern void RenderGraphDefaultResources_set_blackUIntTextureXR_m76D37B7D7F08B8327498257A9D03B592F77C7BCD (void);
// 0x0000019B UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::get_blackTexture3DXR()
extern void RenderGraphDefaultResources_get_blackTexture3DXR_m43CC668EC2EFFE4A8431667E2FF96EA5425990DA (void);
// 0x0000019C System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::set_blackTexture3DXR(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle)
extern void RenderGraphDefaultResources_set_blackTexture3DXR_m933581BEA26A9B1590991F0E2B9FCF602A0FCF05 (void);
// 0x0000019D UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::get_whiteTextureXR()
extern void RenderGraphDefaultResources_get_whiteTextureXR_m00E23431A45FB09E2C313E79F73AD2AB13483E09 (void);
// 0x0000019E System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::set_whiteTextureXR(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle)
extern void RenderGraphDefaultResources_set_whiteTextureXR_m469DC9C354E94585A837C9D991D1E7D52D166F05 (void);
// 0x0000019F UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::get_defaultShadowTexture()
extern void RenderGraphDefaultResources_get_defaultShadowTexture_m4EA8FB8D0893BC33315B9FE9339E1C37DE050F50 (void);
// 0x000001A0 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::set_defaultShadowTexture(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle)
extern void RenderGraphDefaultResources_set_defaultShadowTexture_m7E6330CB5F85105AA023A6AE1CF093FB7028C418 (void);
// 0x000001A1 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::.ctor()
extern void RenderGraphDefaultResources__ctor_mD6DA3A7AE17F1FE15C63776794E904F8716BF798 (void);
// 0x000001A2 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::Cleanup()
extern void RenderGraphDefaultResources_Cleanup_mF92409946BCC07400255DD355133A79C987C2AED (void);
// 0x000001A3 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDefaultResources::InitializeForRendering(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraph)
extern void RenderGraphDefaultResources_InitializeForRendering_mE0C84DD4903970B6D9352590F1011993801BA8C0 (void);
// 0x000001A4 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphLogIndent::.ctor(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphLogger,System.Int32)
extern void RenderGraphLogIndent__ctor_mB06A09F318DD57E80FDF39F5C443C9703BFB3822 (void);
// 0x000001A5 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphLogIndent::Dispose()
extern void RenderGraphLogIndent_Dispose_m0FFDA3A98E3E736D7A3784C9E9D5C6A97707B2B6 (void);
// 0x000001A6 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphLogIndent::Dispose(System.Boolean)
extern void RenderGraphLogIndent_Dispose_mEA306BC46A6C7A416418B1798FBF749A9F2031DC (void);
// 0x000001A7 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphLogger::Initialize(System.String)
extern void RenderGraphLogger_Initialize_m2C02058B2932844BCB31FC192298B9430675E791 (void);
// 0x000001A8 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphLogger::IncrementIndentation(System.Int32)
extern void RenderGraphLogger_IncrementIndentation_m47F0FB67710EB0DD13E2F7F94C6B9556DADE4A8C (void);
// 0x000001A9 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphLogger::DecrementIndentation(System.Int32)
extern void RenderGraphLogger_DecrementIndentation_m1E0A4A858CAA383C6FB12875B8A87DE37566E318 (void);
// 0x000001AA System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphLogger::LogLine(System.String,System.Object[])
extern void RenderGraphLogger_LogLine_m3502DD261EFC7E7DAFFC3F4C461A6D02D841B5BC (void);
// 0x000001AB System.String UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphLogger::GetLog(System.String)
extern void RenderGraphLogger_GetLog_m69349D845CE72C304B61A6F3F2DF2558C378FC6B (void);
// 0x000001AC System.String UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphLogger::GetAllLogs()
extern void RenderGraphLogger_GetAllLogs_mAC4F351FF8782E057CA13F2BDB37BA3AE483FF20 (void);
// 0x000001AD System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphLogger::.ctor()
extern void RenderGraphLogger__ctor_m5A66A4563DF90447B52CE4B1BADC00B48CC4306F (void);
// 0x000001AE System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphObjectPool::.ctor()
extern void RenderGraphObjectPool__ctor_m810EC4C21F7B2392690CA82BD09FBF23614400FE (void);
// 0x000001AF T[] UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphObjectPool::GetTempArray(System.Int32)
// 0x000001B0 UnityEngine.MaterialPropertyBlock UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphObjectPool::GetTempMaterialPropertyBlock()
extern void RenderGraphObjectPool_GetTempMaterialPropertyBlock_mE4438968C33B6CD66C43B342CD124D0B6C6D9F65 (void);
// 0x000001B1 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphObjectPool::ReleaseAllTempAlloc()
extern void RenderGraphObjectPool_ReleaseAllTempAlloc_mE5AA39993CDCA9A90A624A252C9A37A588A85E2A (void);
// 0x000001B2 T UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphObjectPool::Get()
// 0x000001B3 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphObjectPool::Release(T)
// 0x000001B4 T UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphObjectPool/SharedObjectPool`1::Get()
// 0x000001B5 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphObjectPool/SharedObjectPool`1::Release(T)
// 0x000001B6 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphObjectPool/SharedObjectPool`1<T> UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphObjectPool/SharedObjectPool`1::get_sharedPool()
// 0x000001B7 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphObjectPool/SharedObjectPool`1::.ctor()
// 0x000001B8 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphObjectPool/SharedObjectPool`1::.cctor()
// 0x000001B9 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderFunc`1<PassData> UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::GetExecuteDelegate()
// 0x000001BA System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::Execute(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphContext)
// 0x000001BB System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::Release(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphObjectPool)
// 0x000001BC System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::HasRenderFunc()
// 0x000001BD System.String UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::get_name()
extern void RenderGraphPass_get_name_mBC9E08A5232E33757330806E9E52F8EA924101DB (void);
// 0x000001BE System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::set_name(System.String)
extern void RenderGraphPass_set_name_m56C8D7395B29FC3BD99D82DE5E45450C9C41D55C (void);
// 0x000001BF System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::get_index()
extern void RenderGraphPass_get_index_m6E0D043021918E44294E866A910593C5FC32DEA7 (void);
// 0x000001C0 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::set_index(System.Int32)
extern void RenderGraphPass_set_index_mB6B111B7325EC3F70A56417D620662F1AE2B68D2 (void);
// 0x000001C1 UnityEngine.Rendering.ProfilingSampler UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::get_customSampler()
extern void RenderGraphPass_get_customSampler_m524E1FD5FEEEB3F2B4ABA23D793FDFF3208F9218 (void);
// 0x000001C2 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::set_customSampler(UnityEngine.Rendering.ProfilingSampler)
extern void RenderGraphPass_set_customSampler_m05C5220CF5DC934495123022FED1941A678B41D2 (void);
// 0x000001C3 System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::get_enableAsyncCompute()
extern void RenderGraphPass_get_enableAsyncCompute_mBB6A0D9A2B001BA428945EA247DEF457379EBAE4 (void);
// 0x000001C4 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::set_enableAsyncCompute(System.Boolean)
extern void RenderGraphPass_set_enableAsyncCompute_mFD54F752CC9F0C8D0C93AAEDEBF73123F3E69DC0 (void);
// 0x000001C5 System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::get_allowPassCulling()
extern void RenderGraphPass_get_allowPassCulling_mE559F1DEB80EA60B73CCFFB9B6B9A044ABCCC292 (void);
// 0x000001C6 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::set_allowPassCulling(System.Boolean)
extern void RenderGraphPass_set_allowPassCulling_m28FA3B808526988AF0A322AFC0112C46EF247F73 (void);
// 0x000001C7 UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::get_depthBuffer()
extern void RenderGraphPass_get_depthBuffer_mAB47D705BCC4CAC03894FD18F0982F852534FCB5 (void);
// 0x000001C8 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::set_depthBuffer(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle)
extern void RenderGraphPass_set_depthBuffer_m46E9FF4C57216F3C350642F354EDBDB7DDDAC5EE (void);
// 0x000001C9 UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle[] UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::get_colorBuffers()
extern void RenderGraphPass_get_colorBuffers_m566056C284F90288BDCFE805709BB6B1DB750E60 (void);
// 0x000001CA System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::set_colorBuffers(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle[])
extern void RenderGraphPass_set_colorBuffers_m202BEDE7D90F27DBD440DAEECFFB73E733B34D4F (void);
// 0x000001CB System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::get_colorBufferMaxIndex()
extern void RenderGraphPass_get_colorBufferMaxIndex_m9AB682B3977BBE00CF0FF9E5030A1FA71C220FC5 (void);
// 0x000001CC System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::set_colorBufferMaxIndex(System.Int32)
extern void RenderGraphPass_set_colorBufferMaxIndex_m0A8C152F1E2DC60D9ABBF3E85E7A1808BCF0FD79 (void);
// 0x000001CD System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::get_refCount()
extern void RenderGraphPass_get_refCount_mD6FE631C1208D6A14A47885B37EB7A22562DB766 (void);
// 0x000001CE System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::set_refCount(System.Int32)
extern void RenderGraphPass_set_refCount_m33C073D227A1CDF4E665CC131CF3D93A346A42C2 (void);
// 0x000001CF System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::get_generateDebugData()
extern void RenderGraphPass_get_generateDebugData_m4C5F5F8A6F4F69709B0AEDC14740F6A4D792E9F8 (void);
// 0x000001D0 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::set_generateDebugData(System.Boolean)
extern void RenderGraphPass_set_generateDebugData_m06A8222AC5BB9A409E836BBF16CAE39BCD408755 (void);
// 0x000001D1 System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::get_allowRendererListCulling()
extern void RenderGraphPass_get_allowRendererListCulling_mDCB37A5EE941A7023093E530BF177DB1E30BD26A (void);
// 0x000001D2 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::set_allowRendererListCulling(System.Boolean)
extern void RenderGraphPass_set_allowRendererListCulling_m63CF79D071A52C16BE8DDA35A96471BAB435B671 (void);
// 0x000001D3 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::.ctor()
extern void RenderGraphPass__ctor_mB3B733D0783F9C33FC589E697D858F8AE5D8375F (void);
// 0x000001D4 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::Clear()
extern void RenderGraphPass_Clear_m5E95FA71B8587A0407E38B7C2345A3A95C1DCD6C (void);
// 0x000001D5 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::AddResourceWrite(UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle&)
extern void RenderGraphPass_AddResourceWrite_m77B37DF35F880B3CA9B0F2D93A39AAA381EE8069 (void);
// 0x000001D6 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::AddResourceRead(UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle&)
extern void RenderGraphPass_AddResourceRead_mB1ADB02909484B844C83C50E3A9207712F9261A5 (void);
// 0x000001D7 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::AddTransientResource(UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle&)
extern void RenderGraphPass_AddTransientResource_m308716C330A187EFADEC9399A3FFD6577794B3BD (void);
// 0x000001D8 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::UseRendererList(UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListHandle)
extern void RenderGraphPass_UseRendererList_m4DD9249C7253C3F216715E7957C50606CC1BCD52 (void);
// 0x000001D9 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::DependsOnRendererList(UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListHandle)
extern void RenderGraphPass_DependsOnRendererList_m1717D28AE97E76DF4BD356691E4864707994E1F0 (void);
// 0x000001DA System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::EnableAsyncCompute(System.Boolean)
extern void RenderGraphPass_EnableAsyncCompute_m255E65710FC2330F395571C923DB5D5FBFE16844 (void);
// 0x000001DB System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::AllowPassCulling(System.Boolean)
extern void RenderGraphPass_AllowPassCulling_mC79C9FACC4E23C2EFB45D783462EBA4FCA08DE1A (void);
// 0x000001DC System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::AllowRendererListCulling(System.Boolean)
extern void RenderGraphPass_AllowRendererListCulling_mBDE6711F92D9D4A15841500D1E723559126963F4 (void);
// 0x000001DD System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::GenerateDebugData(System.Boolean)
extern void RenderGraphPass_GenerateDebugData_m59E2BAD0AEA250F2678C8D4D9A9EDFCCA6E6610B (void);
// 0x000001DE System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::SetColorBuffer(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle,System.Int32)
extern void RenderGraphPass_SetColorBuffer_m629290D196287553E5EC84B9A94C48C23C9DAC5B (void);
// 0x000001DF System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass::SetDepthBuffer(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle,UnityEngine.Experimental.Rendering.RenderGraphModule.DepthAccess)
extern void RenderGraphPass_SetDepthBuffer_m0B5F8D52CB7649F774FD2B99F2213D2E0984A7C7 (void);
// 0x000001E0 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass`1::Execute(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphContext)
// 0x000001E1 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass`1::Initialize(System.Int32,PassData,System.String,UnityEngine.Rendering.ProfilingSampler)
// 0x000001E2 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass`1::Release(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphObjectPool)
// 0x000001E3 System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass`1::HasRenderFunc()
// 0x000001E4 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphPass`1::.ctor()
// 0x000001E5 UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle::get_nullHandle()
extern void ComputeBufferHandle_get_nullHandle_m5AD19967D7A4A25F921BED78C48174BB85D07F2B (void);
// 0x000001E6 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle::.ctor(System.Int32,System.Boolean)
extern void ComputeBufferHandle__ctor_m6D965D9809C5D3C7F5F385E54890EE463A81776D (void);
// 0x000001E7 UnityEngine.ComputeBuffer UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle::op_Implicit(UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle)
extern void ComputeBufferHandle_op_Implicit_mB127C7A6F390D76C3DD38F7F073E4AA5AD1B8435 (void);
// 0x000001E8 System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle::IsValid()
extern void ComputeBufferHandle_IsValid_m4D3C4E81EFDD8940200E2B823024D85C6DA8517A (void);
// 0x000001E9 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle::.cctor()
extern void ComputeBufferHandle__cctor_mF6D5698A260C0EE292EB68006B380B00CDCBE513 (void);
// 0x000001EA System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferDesc::.ctor(System.Int32,System.Int32)
extern void ComputeBufferDesc__ctor_mD364A4B1CBED57C895863DAEC68E88D5F3AEC8FD (void);
// 0x000001EB System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferDesc::.ctor(System.Int32,System.Int32,UnityEngine.ComputeBufferType)
extern void ComputeBufferDesc__ctor_m6E762AFC03BBCCB7D7C7B4ECF3D718D7C5606664 (void);
// 0x000001EC System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferDesc::GetHashCode()
extern void ComputeBufferDesc_GetHashCode_m55AB43EE5444280A59027570E310275097E3BDB9 (void);
// 0x000001ED System.String UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferResource::GetName()
extern void ComputeBufferResource_GetName_m80F37D611406AC02D2520003C1EEE19ECAD8B02D (void);
// 0x000001EE System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferResource::CreatePooledGraphicsResource()
extern void ComputeBufferResource_CreatePooledGraphicsResource_m0171BD976D4E9D5B5A9E2879C0A1395C22932695 (void);
// 0x000001EF System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferResource::ReleasePooledGraphicsResource(System.Int32)
extern void ComputeBufferResource_ReleasePooledGraphicsResource_m31E104B57DC4881A3ABADEEC39A35A7009059A13 (void);
// 0x000001F0 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferResource::CreateGraphicsResource(System.String)
extern void ComputeBufferResource_CreateGraphicsResource_mF4FF7838BFB34D9102C71612F3F9FDB0B5842335 (void);
// 0x000001F1 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferResource::ReleaseGraphicsResource()
extern void ComputeBufferResource_ReleaseGraphicsResource_m5931B775F910A6783052B700BDE7279D7C20A9EE (void);
// 0x000001F2 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferResource::LogCreation(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphLogger)
extern void ComputeBufferResource_LogCreation_mD30137A8AE8836D80A66FD99420D7B5133C1A0C0 (void);
// 0x000001F3 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferResource::LogRelease(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphLogger)
extern void ComputeBufferResource_LogRelease_mD0B0364A21342A653FC46EC98027A5187B51780C (void);
// 0x000001F4 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferResource::.ctor()
extern void ComputeBufferResource__ctor_mA03BBFE40BE9457A3F8DA8E8F5369E081DA86395 (void);
// 0x000001F5 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferPool::ReleaseInternalResource(UnityEngine.ComputeBuffer)
extern void ComputeBufferPool_ReleaseInternalResource_m2DBEDACD727065173AE14FC066CB2B7CA7D0F3EE (void);
// 0x000001F6 System.String UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferPool::GetResourceName(UnityEngine.ComputeBuffer)
extern void ComputeBufferPool_GetResourceName_m8F3B467AAB1E56640E445B1EB9F3687C714217DA (void);
// 0x000001F7 System.Int64 UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferPool::GetResourceSize(UnityEngine.ComputeBuffer)
extern void ComputeBufferPool_GetResourceSize_mC4E7725F37DA0BDF6628D8CCF667B689C80C64D8 (void);
// 0x000001F8 System.String UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferPool::GetResourceTypeName()
extern void ComputeBufferPool_GetResourceTypeName_mFF0F53B71C013ECD2AA22F7C3EBB3D9A60ED1A06 (void);
// 0x000001F9 System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferPool::GetSortIndex(UnityEngine.ComputeBuffer)
extern void ComputeBufferPool_GetSortIndex_m55B303A28500F485D2DC06D86DDEA59A899232D3 (void);
// 0x000001FA System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferPool::PurgeUnusedResources(System.Int32)
extern void ComputeBufferPool_PurgeUnusedResources_m0698892370966E0C43D456312178E681381E321D (void);
// 0x000001FB System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferPool::.ctor()
extern void ComputeBufferPool__ctor_m497219862B9FF4E5D7AC392EB0BEF378D8E43A56 (void);
// 0x000001FC System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResourcePool::PurgeUnusedResources(System.Int32)
// 0x000001FD System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResourcePool::Cleanup()
// 0x000001FE System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResourcePool::CheckFrameAllocation(System.Boolean,System.Int32)
// 0x000001FF System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResourcePool::LogResources(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphLogger)
// 0x00000200 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResourcePool::.ctor()
extern void IRenderGraphResourcePool__ctor_m505F033CFC079F0EA1E63BD4E9A813B781072C3E (void);
// 0x00000201 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourcePool`1::ReleaseInternalResource(Type)
// 0x00000202 System.String UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourcePool`1::GetResourceName(Type)
// 0x00000203 System.Int64 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourcePool`1::GetResourceSize(Type)
// 0x00000204 System.String UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourcePool`1::GetResourceTypeName()
// 0x00000205 System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourcePool`1::GetSortIndex(Type)
// 0x00000206 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourcePool`1::ReleaseResource(System.Int32,Type,System.Int32)
// 0x00000207 System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourcePool`1::TryGetResource(System.Int32,Type&)
// 0x00000208 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourcePool`1::Cleanup()
// 0x00000209 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourcePool`1::RegisterFrameAllocation(System.Int32,Type)
// 0x0000020A System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourcePool`1::UnregisterFrameAllocation(System.Int32,Type)
// 0x0000020B System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourcePool`1::CheckFrameAllocation(System.Boolean,System.Int32)
// 0x0000020C System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourcePool`1::LogResources(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphLogger)
// 0x0000020D System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourcePool`1::ShouldReleaseResource(System.Int32,System.Int32)
// 0x0000020E System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourcePool`1::.ctor()
// 0x0000020F System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourcePool`1/<>c::.cctor()
// 0x00000210 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourcePool`1/<>c::.ctor()
// 0x00000211 System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourcePool`1/<>c::<LogResources>b__17_0(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourcePool`1/ResourceLogInfo<Type>,UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourcePool`1/ResourceLogInfo<Type>)
// 0x00000212 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::get_current()
extern void RenderGraphResourceRegistry_get_current_m97F373C58ED6A15ADFFBF8927CAE23D28FAEE707 (void);
// 0x00000213 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::set_current(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry)
extern void RenderGraphResourceRegistry_set_current_mE572A8ACCF0FC395C7549E5955736FBC2A914838 (void);
// 0x00000214 UnityEngine.Rendering.RTHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::GetTexture(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle&)
extern void RenderGraphResourceRegistry_GetTexture_mA0D4C3A6CEAF8647C8AE76D4A90319750D29E43D (void);
// 0x00000215 System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::TextureNeedsFallback(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle&)
extern void RenderGraphResourceRegistry_TextureNeedsFallback_m819A32FA09A5AEE0915E53C2A0752AF67820D75A (void);
// 0x00000216 UnityEngine.Rendering.RendererUtils.RendererList UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::GetRendererList(UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListHandle&)
extern void RenderGraphResourceRegistry_GetRendererList_mEE5905F0C7C1A54B54EDBD3F97DE645534CDDA9D (void);
// 0x00000217 UnityEngine.ComputeBuffer UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::GetComputeBuffer(UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle&)
extern void RenderGraphResourceRegistry_GetComputeBuffer_m0EED9E3B321167D13C91E26B70EB0D85FDE33010 (void);
// 0x00000218 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::.ctor()
extern void RenderGraphResourceRegistry__ctor_m65B64428AC37A1B3C4B6E81E4BDA7265F9031F63 (void);
// 0x00000219 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::.ctor(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphDebugParams,UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphLogger)
extern void RenderGraphResourceRegistry__ctor_m3D24628B5135F00370A97E8F549B13449FE28BFD (void);
// 0x0000021A System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::BeginRenderGraph(System.Int32)
extern void RenderGraphResourceRegistry_BeginRenderGraph_m109C1A8064C64EBB550A307F1DDA1E32AFA92D61 (void);
// 0x0000021B System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::BeginExecute(System.Int32)
extern void RenderGraphResourceRegistry_BeginExecute_m6B9A1BAF2E57480EFF735E50A8AB45BF781BAEFC (void);
// 0x0000021C System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::EndExecute()
extern void RenderGraphResourceRegistry_EndExecute_m54A581B0A8DE32C8094EA4195F294D46F001A625 (void);
// 0x0000021D System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::CheckHandleValidity(UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle&)
extern void RenderGraphResourceRegistry_CheckHandleValidity_m158A4E64E99E375C73D5F0CAC1B113EFE6E55BD9 (void);
// 0x0000021E System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::CheckHandleValidity(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceType,System.Int32)
extern void RenderGraphResourceRegistry_CheckHandleValidity_m7FF4B6FCCAC9C84081F20C819239A2DABB39F242 (void);
// 0x0000021F System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::IncrementWriteCount(UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle&)
extern void RenderGraphResourceRegistry_IncrementWriteCount_m32CCCC2CE84EECFEFBD2A5CE234505BED3D7DCEC (void);
// 0x00000220 System.String UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::GetRenderGraphResourceName(UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle&)
extern void RenderGraphResourceRegistry_GetRenderGraphResourceName_m000367B8EC114CE49B849D6037005B092368C34E (void);
// 0x00000221 System.String UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::GetRenderGraphResourceName(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceType,System.Int32)
extern void RenderGraphResourceRegistry_GetRenderGraphResourceName_m6BE8678CBC929733854088EC9888BD69A9681275 (void);
// 0x00000222 System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::IsRenderGraphResourceImported(UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle&)
extern void RenderGraphResourceRegistry_IsRenderGraphResourceImported_m5FF203E3F02C32A6F12726045B7AFE1397861FF5 (void);
// 0x00000223 System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::IsRenderGraphResourceShared(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceType,System.Int32)
extern void RenderGraphResourceRegistry_IsRenderGraphResourceShared_m0F3BAD8A7BEC39EFBC4AEA1B4BD93E4A7C9A2789 (void);
// 0x00000224 System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::IsGraphicsResourceCreated(UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle&)
extern void RenderGraphResourceRegistry_IsGraphicsResourceCreated_m50B0405E020D24FD2B289583781D3FF572AABE25 (void);
// 0x00000225 System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::IsRendererListCreated(UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListHandle&)
extern void RenderGraphResourceRegistry_IsRendererListCreated_m1A178F8154E4F5DB639A1045B09E845F5379B77D (void);
// 0x00000226 System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::IsRenderGraphResourceImported(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceType,System.Int32)
extern void RenderGraphResourceRegistry_IsRenderGraphResourceImported_m4EBCFCBEC813263D9E399AD7A558A84D05520BE8 (void);
// 0x00000227 System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::GetRenderGraphResourceTransientIndex(UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle&)
extern void RenderGraphResourceRegistry_GetRenderGraphResourceTransientIndex_m0554B2306A87364D556DFD483C14FC8002B4E2D9 (void);
// 0x00000228 UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::ImportTexture(UnityEngine.Rendering.RTHandle)
extern void RenderGraphResourceRegistry_ImportTexture_m81DF7C26F2DEBE95D1391CFAB9AD7E6330039960 (void);
// 0x00000229 UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::CreateSharedTexture(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureDesc&,System.Boolean)
extern void RenderGraphResourceRegistry_CreateSharedTexture_m3A8992CB6C1F797D20E181351290790D840129DF (void);
// 0x0000022A System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::ReleaseSharedTexture(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle)
extern void RenderGraphResourceRegistry_ReleaseSharedTexture_m4FD13BFAD381734BE5254BC14DCD86D0399D651E (void);
// 0x0000022B UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::ImportBackbuffer(UnityEngine.Rendering.RenderTargetIdentifier)
extern void RenderGraphResourceRegistry_ImportBackbuffer_mB707AA8E5A2543978EE0EFED8B3F179479C99B77 (void);
// 0x0000022C UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::CreateTexture(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureDesc&,System.Int32)
extern void RenderGraphResourceRegistry_CreateTexture_mB56D76FBF3BA168425ABD73DA03B78937403EF97 (void);
// 0x0000022D System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::GetTextureResourceCount()
extern void RenderGraphResourceRegistry_GetTextureResourceCount_m9A0358556F0E62ABDE85400838CC760709CBA1F1 (void);
// 0x0000022E UnityEngine.Experimental.Rendering.RenderGraphModule.TextureResource UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::GetTextureResource(UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle&)
extern void RenderGraphResourceRegistry_GetTextureResource_m2F3C125ADA19AE539C96849F62D4941BC494815B (void);
// 0x0000022F UnityEngine.Experimental.Rendering.RenderGraphModule.TextureDesc UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::GetTextureResourceDesc(UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle&)
extern void RenderGraphResourceRegistry_GetTextureResourceDesc_m2C39D5A9FC117474762D89F7AC052300D38D86C9 (void);
// 0x00000230 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::ForceTextureClear(UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle&,UnityEngine.Color)
extern void RenderGraphResourceRegistry_ForceTextureClear_mE89D1B844EF9D79E803AAB8FC04A062F8D82192B (void);
// 0x00000231 UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::CreateRendererList(UnityEngine.Rendering.RendererUtils.RendererListDesc&)
extern void RenderGraphResourceRegistry_CreateRendererList_m5A3D14CA61A7CA5A00BC82E0500ABB1BBE5671FD (void);
// 0x00000232 UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::ImportComputeBuffer(UnityEngine.ComputeBuffer)
extern void RenderGraphResourceRegistry_ImportComputeBuffer_m68A696B824F2878ACE3E44E760E028D61B149ECB (void);
// 0x00000233 UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferHandle UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::CreateComputeBuffer(UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferDesc&,System.Int32)
extern void RenderGraphResourceRegistry_CreateComputeBuffer_m6D7F63A99EB913A133D7E4C5BE6C5022FDD674CC (void);
// 0x00000234 UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferDesc UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::GetComputeBufferResourceDesc(UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle&)
extern void RenderGraphResourceRegistry_GetComputeBufferResourceDesc_m45F37B3D5BD530ECA2DB14CB6AABEFEBED91A2C1 (void);
// 0x00000235 System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::GetComputeBufferResourceCount()
extern void RenderGraphResourceRegistry_GetComputeBufferResourceCount_mFBBEF3A6EEACCA67A6E98067D47839EFE2005D1E (void);
// 0x00000236 UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferResource UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::GetComputeBufferResource(UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle&)
extern void RenderGraphResourceRegistry_GetComputeBufferResource_mB99DACAE007D6E7166228A8974E78BB08B16A807 (void);
// 0x00000237 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::UpdateSharedResourceLastFrameIndex(System.Int32,System.Int32)
extern void RenderGraphResourceRegistry_UpdateSharedResourceLastFrameIndex_m01A8CCDA734B3D604AB0A96C77F519152509288D (void);
// 0x00000238 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::ManageSharedRenderGraphResources()
extern void RenderGraphResourceRegistry_ManageSharedRenderGraphResources_m50EF15E3C7C59411E5C067BE654792E10AFF24A2 (void);
// 0x00000239 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::CreatePooledResource(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphContext,System.Int32,System.Int32)
extern void RenderGraphResourceRegistry_CreatePooledResource_m7A707BFF2BE29D1B8B8103879C8B3EC7B8B7B3BD (void);
// 0x0000023A System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::CreateTextureCallback(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphContext,UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResource)
extern void RenderGraphResourceRegistry_CreateTextureCallback_m1755AA433A8745C3B8C5BA8B67666151AD8AD300 (void);
// 0x0000023B System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::ReleasePooledResource(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphContext,System.Int32,System.Int32)
extern void RenderGraphResourceRegistry_ReleasePooledResource_m2031C38E48A585EB086C244A3D47D44E034C1ABF (void);
// 0x0000023C System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::ReleaseTextureCallback(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphContext,UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResource)
extern void RenderGraphResourceRegistry_ReleaseTextureCallback_mAA581CF5124B152FA95F4A7B5FF297DFD60ACF2B (void);
// 0x0000023D System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::ValidateTextureDesc(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureDesc&)
extern void RenderGraphResourceRegistry_ValidateTextureDesc_mCB8ACB1153374A7AA619006246F237E54D2A38F3 (void);
// 0x0000023E System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::ValidateRendererListDesc(UnityEngine.Rendering.RendererUtils.RendererListDesc&)
extern void RenderGraphResourceRegistry_ValidateRendererListDesc_m4B314D30C4CAB53AF0F638A727EF506BD45CE0BF (void);
// 0x0000023F System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::ValidateComputeBufferDesc(UnityEngine.Experimental.Rendering.RenderGraphModule.ComputeBufferDesc&)
extern void RenderGraphResourceRegistry_ValidateComputeBufferDesc_m8C766FBD5BD48AA70AA7DB385FD8868E0D303AE0 (void);
// 0x00000240 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::CreateRendererLists(System.Collections.Generic.List`1<UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListHandle>,UnityEngine.Rendering.ScriptableRenderContext,System.Boolean)
extern void RenderGraphResourceRegistry_CreateRendererLists_mBE817E97CC7909310E47A54C4FEEA42257AF4AE3 (void);
// 0x00000241 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::Clear(System.Boolean)
extern void RenderGraphResourceRegistry_Clear_mD46E87EC32F4E591732FCD7FB7F69AA1243AF309 (void);
// 0x00000242 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::PurgeUnusedGraphicsResources()
extern void RenderGraphResourceRegistry_PurgeUnusedGraphicsResources_m593279893CD0650F0AAC95859FCE4C5E40C943B5 (void);
// 0x00000243 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::Cleanup()
extern void RenderGraphResourceRegistry_Cleanup_mAF56D87596328355ED31A4C009E0C5F70CE4E979 (void);
// 0x00000244 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::FlushLogs()
extern void RenderGraphResourceRegistry_FlushLogs_m6111629FE7BD896DF076EDE721BBE268DC7F450A (void);
// 0x00000245 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry::LogResources()
extern void RenderGraphResourceRegistry_LogResources_mB4DE5B9AE131FF60064BBA25FBEE6034911165F0 (void);
// 0x00000246 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry/ResourceCallback::.ctor(System.Object,System.IntPtr)
extern void ResourceCallback__ctor_m83ADE3D8CD197E408D138B6414700A036BA0632E (void);
// 0x00000247 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry/ResourceCallback::Invoke(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphContext,UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResource)
extern void ResourceCallback_Invoke_m44975C771B30E3B1D643AA09C8546B54839F9978 (void);
// 0x00000248 System.IAsyncResult UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry/ResourceCallback::BeginInvoke(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphContext,UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResource,System.AsyncCallback,System.Object)
extern void ResourceCallback_BeginInvoke_m5B83C1D642493776276FEFE24718E11B73456D42 (void);
// 0x00000249 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry/ResourceCallback::EndInvoke(System.IAsyncResult)
extern void ResourceCallback_EndInvoke_mFFE27089EF8D2FDFD7D6451D6E207BF5B0BF5E71 (void);
// 0x0000024A System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry/RenderGraphResourcesData::Clear(System.Boolean,System.Int32)
extern void RenderGraphResourcesData_Clear_mD4E3B153DD47FE532CC058AB44F597AB0D4DE56C (void);
// 0x0000024B System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry/RenderGraphResourcesData::Cleanup()
extern void RenderGraphResourcesData_Cleanup_mD6A20FDAFB30E905B4FA0547490E7220BA3A3609 (void);
// 0x0000024C System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry/RenderGraphResourcesData::PurgeUnusedGraphicsResources(System.Int32)
extern void RenderGraphResourcesData_PurgeUnusedGraphicsResources_m24F8F6F3889FC6724341369C51260CC7D367B2AA (void);
// 0x0000024D System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry/RenderGraphResourcesData::AddNewRenderGraphResource(ResType&,System.Boolean)
// 0x0000024E System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceRegistry/RenderGraphResourcesData::.ctor()
extern void RenderGraphResourcesData__ctor_m1D295D8A104963715BAE610F9A17C9F9E33F2682 (void);
// 0x0000024F System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListHandle::get_handle()
extern void RendererListHandle_get_handle_m4D239A48FFDBFA551B8BE7A4448BF19370EEB848 (void);
// 0x00000250 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListHandle::set_handle(System.Int32)
extern void RendererListHandle_set_handle_m0DE76F63C96B25082DA109CB2C5C9EBB99F6D0E3 (void);
// 0x00000251 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListHandle::.ctor(System.Int32)
extern void RendererListHandle__ctor_mCFD25579FE4F4D3687533BE4A366128E0E23B0AF (void);
// 0x00000252 System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListHandle::op_Implicit(UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListHandle)
extern void RendererListHandle_op_Implicit_m67A309DDD452E9C1C024CBACE7A0759B3B3357E0 (void);
// 0x00000253 UnityEngine.Rendering.RendererUtils.RendererList UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListHandle::op_Implicit(UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListHandle)
extern void RendererListHandle_op_Implicit_m773844C3742FA469FDAD459576166538B28ADC25 (void);
// 0x00000254 System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListHandle::IsValid()
extern void RendererListHandle_IsValid_m39DD764115038D342C81E04B5475E957246B08A1 (void);
// 0x00000255 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RendererListResource::.ctor(UnityEngine.Rendering.RendererUtils.RendererListDesc&)
extern void RendererListResource__ctor_mC9EDE12FC17F2685835A6A57E9EF3FEF1629D15A (void);
// 0x00000256 System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle::get_index()
extern void ResourceHandle_get_index_m91DB2195EB1D4B5AF1D37FF737C8B6EF8B4E9E50 (void);
// 0x00000257 UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceType UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle::get_type()
extern void ResourceHandle_get_type_m2A8AF5AC268B8068DF6EB721B4D28A6A82B0C88B (void);
// 0x00000258 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle::set_type(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceType)
extern void ResourceHandle_set_type_m4626071A3B159FDD69989F2C9591A8977CB6454E (void);
// 0x00000259 System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle::get_iType()
extern void ResourceHandle_get_iType_mE93479F8B75DD94FF1B32AC5FAF7E6F923DC63C5 (void);
// 0x0000025A System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle::.ctor(System.Int32,UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResourceType,System.Boolean)
extern void ResourceHandle__ctor_m43993F666EE5128E896AE562EB4AE65263831C5F (void);
// 0x0000025B System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle::op_Implicit(UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle)
extern void ResourceHandle_op_Implicit_mC78D25CDCA754EE189EEF7A357D17E128ECBA84A (void);
// 0x0000025C System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle::IsValid()
extern void ResourceHandle_IsValid_mBC26F92EEC475A8B75722BA104A462E16C6337A2 (void);
// 0x0000025D System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle::NewFrame(System.Int32)
extern void ResourceHandle_NewFrame_m495A2B09AEB23AC518832589E235C91D9AF60497 (void);
// 0x0000025E System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.ResourceHandle::.cctor()
extern void ResourceHandle__cctor_mA1B137FA250B8998012DEE4A779C79F3154BD385 (void);
// 0x0000025F System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResource::Reset(UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResourcePool)
extern void IRenderGraphResource_Reset_m81E9B60C6150975FDFED0428472E8A472FF30627 (void);
// 0x00000260 System.String UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResource::GetName()
extern void IRenderGraphResource_GetName_m5A9737599D755C54E346749D355646E6B9F6A911 (void);
// 0x00000261 System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResource::IsCreated()
extern void IRenderGraphResource_IsCreated_m16C66BC5B46AD970AF5368B8F424021B592A40A8 (void);
// 0x00000262 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResource::IncrementWriteCount()
extern void IRenderGraphResource_IncrementWriteCount_m591E3311ADF6DCC6A07B5401A482C0CBDB04917A (void);
// 0x00000263 System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResource::NeedsFallBack()
extern void IRenderGraphResource_NeedsFallBack_mEC21987B1F714A426BBD1500E5FAC10241F09654 (void);
// 0x00000264 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResource::CreatePooledGraphicsResource()
extern void IRenderGraphResource_CreatePooledGraphicsResource_mB261A2ADFC1ED261F87248C8C07AEE15B0A226F3 (void);
// 0x00000265 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResource::CreateGraphicsResource(System.String)
extern void IRenderGraphResource_CreateGraphicsResource_m26D0C999DA9152D23FF6D5C38509095F96D20766 (void);
// 0x00000266 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResource::ReleasePooledGraphicsResource(System.Int32)
extern void IRenderGraphResource_ReleasePooledGraphicsResource_mCE11733A2622F15CC41392867E92884DA9EEC3D3 (void);
// 0x00000267 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResource::ReleaseGraphicsResource()
extern void IRenderGraphResource_ReleaseGraphicsResource_mA150B18FCCF7EEE7A61CC3B4DC6D3F024B0BEFAB (void);
// 0x00000268 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResource::LogCreation(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphLogger)
extern void IRenderGraphResource_LogCreation_mD97B45EBEB5863A24FBC1A59F3E6537F09DB45BE (void);
// 0x00000269 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResource::LogRelease(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphLogger)
extern void IRenderGraphResource_LogRelease_mBE6D5B8DE2FD3EAF5BFB0F1D28683591A693E0CF (void);
// 0x0000026A System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResource::GetSortIndex()
extern void IRenderGraphResource_GetSortIndex_m56A038268B0ECA06215646E6EA64F979329277FA (void);
// 0x0000026B System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResource::.ctor()
extern void IRenderGraphResource__ctor_m5537D42301A3E59C0168555DE63CD6A29FB6A63E (void);
// 0x0000026C System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResource`2::.ctor()
// 0x0000026D System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResource`2::Reset(UnityEngine.Experimental.Rendering.RenderGraphModule.IRenderGraphResourcePool)
// 0x0000026E System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResource`2::IsCreated()
// 0x0000026F System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphResource`2::ReleaseGraphicsResource()
// 0x00000270 UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle::get_nullHandle()
extern void TextureHandle_get_nullHandle_mF3A03146F64615C041D0877D1E89D3E9FECDA0C0 (void);
// 0x00000271 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle::.ctor(System.Int32,System.Boolean)
extern void TextureHandle__ctor_mC6D0A6B896CC0E8589B88D370869149649031FB0 (void);
// 0x00000272 UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle::op_Implicit(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle)
extern void TextureHandle_op_Implicit_mC29818753DD8EEED56054693514CE10964E580E6 (void);
// 0x00000273 UnityEngine.Texture UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle::op_Implicit(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle)
extern void TextureHandle_op_Implicit_mE367E3278732AE71E80473AB40FF760F20621673 (void);
// 0x00000274 UnityEngine.RenderTexture UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle::op_Implicit(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle)
extern void TextureHandle_op_Implicit_mF08AC03F72EEB69A60C965CF79FCBD332F029FC6 (void);
// 0x00000275 UnityEngine.Rendering.RTHandle UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle::op_Implicit(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle)
extern void TextureHandle_op_Implicit_mA5D8393D6F1ADCFD27E34F979B24F35BAD6BD3CF (void);
// 0x00000276 System.Boolean UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle::IsValid()
extern void TextureHandle_IsValid_m3C2D8F8EB70206A09F3FFADDDD230E00C25269D9 (void);
// 0x00000277 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle::SetFallBackResource(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle)
extern void TextureHandle_SetFallBackResource_m63C811961161AB0BD5C7ECC272EBEF26ABE84EBE (void);
// 0x00000278 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.TextureHandle::.cctor()
extern void TextureHandle__cctor_mC6F25D8B7ED8A1AA3DFC14D43ED2071994A615B2 (void);
// 0x00000279 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.TextureDesc::InitDefaultValues(System.Boolean,System.Boolean)
extern void TextureDesc_InitDefaultValues_mF4DA67529813E66310182D684D50A9FCCA4BE911 (void);
// 0x0000027A System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.TextureDesc::.ctor(System.Int32,System.Int32,System.Boolean,System.Boolean)
extern void TextureDesc__ctor_mAA4AB396BD886053C637CC275E7839B887B44FA3 (void);
// 0x0000027B System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.TextureDesc::.ctor(UnityEngine.Vector2,System.Boolean,System.Boolean)
extern void TextureDesc__ctor_m7DD9D0AB2E909E3E014FA3BFE0433235881031E0 (void);
// 0x0000027C System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.TextureDesc::.ctor(UnityEngine.Rendering.ScaleFunc,System.Boolean,System.Boolean)
extern void TextureDesc__ctor_m524B5F82F524BB71949F24E0436876092BE8B0E0 (void);
// 0x0000027D System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.TextureDesc::.ctor(UnityEngine.Experimental.Rendering.RenderGraphModule.TextureDesc)
extern void TextureDesc__ctor_m55D6822C811DB1361730AA8C0E28564C62F95699 (void);
// 0x0000027E System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.TextureDesc::GetHashCode()
extern void TextureDesc_GetHashCode_m84A013881648FFDEBA578DC743BA617C812130E0 (void);
// 0x0000027F System.String UnityEngine.Experimental.Rendering.RenderGraphModule.TextureResource::GetName()
extern void TextureResource_GetName_mC89D211EB725AE9D25374F813A8F16B64A16ED91 (void);
// 0x00000280 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.TextureResource::CreatePooledGraphicsResource()
extern void TextureResource_CreatePooledGraphicsResource_m27BBE4F4CF511B3881F29BDB02A7EB8E00804465 (void);
// 0x00000281 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.TextureResource::ReleasePooledGraphicsResource(System.Int32)
extern void TextureResource_ReleasePooledGraphicsResource_m2034ACC2EFAC93E7061A920E411FE6655C950552 (void);
// 0x00000282 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.TextureResource::CreateGraphicsResource(System.String)
extern void TextureResource_CreateGraphicsResource_m96734CDAB9AEE1B1616C3B93E145EF059DAA67C7 (void);
// 0x00000283 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.TextureResource::ReleaseGraphicsResource()
extern void TextureResource_ReleaseGraphicsResource_mC2630A1E843565E00B4A5BAED0640BF24C051D47 (void);
// 0x00000284 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.TextureResource::LogCreation(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphLogger)
extern void TextureResource_LogCreation_mCAA0157BCD522230430F557DC2F98CD36E2CAC75 (void);
// 0x00000285 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.TextureResource::LogRelease(UnityEngine.Experimental.Rendering.RenderGraphModule.RenderGraphLogger)
extern void TextureResource_LogRelease_m8B4C211B21EFFFC6ADF082275A2001648F0B05EF (void);
// 0x00000286 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.TextureResource::.ctor()
extern void TextureResource__ctor_m659F978DACAC9671F72A2B7B10D66E1B43B61501 (void);
// 0x00000287 System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.TexturePool::ReleaseInternalResource(UnityEngine.Rendering.RTHandle)
extern void TexturePool_ReleaseInternalResource_m9473BE0C881790CC3CABDA03D48DFDA123C5B004 (void);
// 0x00000288 System.String UnityEngine.Experimental.Rendering.RenderGraphModule.TexturePool::GetResourceName(UnityEngine.Rendering.RTHandle)
extern void TexturePool_GetResourceName_mB31216B01D16305C89FFF4ABAFF269877CADB195 (void);
// 0x00000289 System.Int64 UnityEngine.Experimental.Rendering.RenderGraphModule.TexturePool::GetResourceSize(UnityEngine.Rendering.RTHandle)
extern void TexturePool_GetResourceSize_m86E799D5F54610D987CE10737FE5BBB1D43A2A06 (void);
// 0x0000028A System.String UnityEngine.Experimental.Rendering.RenderGraphModule.TexturePool::GetResourceTypeName()
extern void TexturePool_GetResourceTypeName_m0B614259A4C46737679DE1C6925BDAD352E60620 (void);
// 0x0000028B System.Int32 UnityEngine.Experimental.Rendering.RenderGraphModule.TexturePool::GetSortIndex(UnityEngine.Rendering.RTHandle)
extern void TexturePool_GetSortIndex_m0D47B44E4D16A6119869CD3B0B68B64ACB819F2A (void);
// 0x0000028C System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.TexturePool::PurgeUnusedResources(System.Int32)
extern void TexturePool_PurgeUnusedResources_m994BE8A3177D9AAE636F4D40F4E959C6F9A30945 (void);
// 0x0000028D System.Void UnityEngine.Experimental.Rendering.RenderGraphModule.TexturePool::.ctor()
extern void TexturePool__ctor_m085C992A3A857BC6E0B417512CBE98134B2FFE5E (void);
// 0x0000028E System.Void UnityEngine.Rendering.CameraSwitcher::OnEnable()
extern void CameraSwitcher_OnEnable_m24104E3A78B71F31442A1B8A71F79F2620966BB7 (void);
// 0x0000028F System.Void UnityEngine.Rendering.CameraSwitcher::OnDisable()
extern void CameraSwitcher_OnDisable_mD2920C1486BFE1EC7F87A863B373A17F8954B9D8 (void);
// 0x00000290 System.Int32 UnityEngine.Rendering.CameraSwitcher::GetCameraCount()
extern void CameraSwitcher_GetCameraCount_mC48F44F4BE27326847DE783C7CB6F89D6A4E3CB0 (void);
// 0x00000291 UnityEngine.Camera UnityEngine.Rendering.CameraSwitcher::GetNextCamera()
extern void CameraSwitcher_GetNextCamera_mFD17D7213672960C743C4947E83EAA95ED8F8018 (void);
// 0x00000292 System.Void UnityEngine.Rendering.CameraSwitcher::SetCameraIndex(System.Int32)
extern void CameraSwitcher_SetCameraIndex_mC467AB35FC45BC0FBA09C062B854B4210C682FED (void);
// 0x00000293 System.Void UnityEngine.Rendering.CameraSwitcher::.ctor()
extern void CameraSwitcher__ctor_m58E93E0C44E327A17DC191FAB41AEAE02756F7E0 (void);
// 0x00000294 System.Int32 UnityEngine.Rendering.CameraSwitcher::<OnEnable>b__10_0()
extern void CameraSwitcher_U3COnEnableU3Eb__10_0_mBA0A44912EFBB06862FFE6BFAB473CC8088554B5 (void);
// 0x00000295 System.Void UnityEngine.Rendering.CameraSwitcher::<OnEnable>b__10_1(System.Int32)
extern void CameraSwitcher_U3COnEnableU3Eb__10_1_mED6417B1D873D0CDB7A4AD790D3DE5B816BA64DF (void);
// 0x00000296 System.Int32 UnityEngine.Rendering.CameraSwitcher::<OnEnable>b__10_2()
extern void CameraSwitcher_U3COnEnableU3Eb__10_2_m5FF4CE2227650E8A8EC1FDF82EFA120910C9F651 (void);
// 0x00000297 System.Void UnityEngine.Rendering.CameraSwitcher::<OnEnable>b__10_3(System.Int32)
extern void CameraSwitcher_U3COnEnableU3Eb__10_3_mBEEA1799E253361CAA01E1EB466A05EB1A8CEF60 (void);
// 0x00000298 System.Void UnityEngine.Rendering.FreeCamera::OnEnable()
extern void FreeCamera_OnEnable_mD7CA8EBB7B0281F02AB4CC64606DBE70A82B54AB (void);
// 0x00000299 System.Void UnityEngine.Rendering.FreeCamera::RegisterInputs()
extern void FreeCamera_RegisterInputs_m33CB202F41B9766CC2A375A56704D828C0523AD5 (void);
// 0x0000029A System.Void UnityEngine.Rendering.FreeCamera::UpdateInputs()
extern void FreeCamera_UpdateInputs_m52DB79FEF7076222572E8AA0D651610F89BAB7EA (void);
// 0x0000029B System.Void UnityEngine.Rendering.FreeCamera::Update()
extern void FreeCamera_Update_mB479DC04102D3835894EF87B8C2C1926053267B7 (void);
// 0x0000029C System.Void UnityEngine.Rendering.FreeCamera::.ctor()
extern void FreeCamera__ctor_m60B6098E94DB0A2D70B37A19E0DB1B837BEC9A60 (void);
// 0x0000029D UnityEngine.Rendering.CommandBuffer UnityEngine.Rendering.CommandBufferPool::Get()
extern void CommandBufferPool_Get_m54EBE601AF00C8A5EDCAA503E65380F464BD1355 (void);
// 0x0000029E UnityEngine.Rendering.CommandBuffer UnityEngine.Rendering.CommandBufferPool::Get(System.String)
extern void CommandBufferPool_Get_mC33780CD170099A0E396A2F3A9AFB46509B31625 (void);
// 0x0000029F System.Void UnityEngine.Rendering.CommandBufferPool::Release(UnityEngine.Rendering.CommandBuffer)
extern void CommandBufferPool_Release_mEC46D8373A95DEC68F1FBD2D77FF3F76917631BF (void);
// 0x000002A0 System.Void UnityEngine.Rendering.CommandBufferPool::.cctor()
extern void CommandBufferPool__cctor_m98BCC37031F4485865B612ADEA7A57782D2EF798 (void);
// 0x000002A1 System.Void UnityEngine.Rendering.CommandBufferPool/<>c::.cctor()
extern void U3CU3Ec__cctor_m9E1BD953730391FC027171E4628DB8E2AD59A745 (void);
// 0x000002A2 System.Void UnityEngine.Rendering.CommandBufferPool/<>c::.ctor()
extern void U3CU3Ec__ctor_m5F75A5B7C96F0194D93D30844E235C11C9ABF735 (void);
// 0x000002A3 System.Void UnityEngine.Rendering.CommandBufferPool/<>c::<.cctor>b__4_0(UnityEngine.Rendering.CommandBuffer)
extern void U3CU3Ec_U3C_cctorU3Eb__4_0_mB68D246349C87B64BAAA41AFD0D35D7FCEDA7184 (void);
// 0x000002A4 TType UnityEngine.Rendering.ComponentSingleton`1::get_instance()
// 0x000002A5 System.Void UnityEngine.Rendering.ComponentSingleton`1::Release()
// 0x000002A6 System.Void UnityEngine.Rendering.ConstantBuffer::PushGlobal(UnityEngine.Rendering.CommandBuffer,CBType&,System.Int32)
// 0x000002A7 System.Void UnityEngine.Rendering.ConstantBuffer::PushGlobal(CBType&,System.Int32)
// 0x000002A8 System.Void UnityEngine.Rendering.ConstantBuffer::Push(UnityEngine.Rendering.CommandBuffer,CBType&,UnityEngine.ComputeShader,System.Int32)
// 0x000002A9 System.Void UnityEngine.Rendering.ConstantBuffer::Push(CBType&,UnityEngine.ComputeShader,System.Int32)
// 0x000002AA System.Void UnityEngine.Rendering.ConstantBuffer::Push(UnityEngine.Rendering.CommandBuffer,CBType&,UnityEngine.Material,System.Int32)
// 0x000002AB System.Void UnityEngine.Rendering.ConstantBuffer::Push(CBType&,UnityEngine.Material,System.Int32)
// 0x000002AC System.Void UnityEngine.Rendering.ConstantBuffer::UpdateData(UnityEngine.Rendering.CommandBuffer,CBType&)
// 0x000002AD System.Void UnityEngine.Rendering.ConstantBuffer::UpdateData(CBType&)
// 0x000002AE System.Void UnityEngine.Rendering.ConstantBuffer::SetGlobal(UnityEngine.Rendering.CommandBuffer,System.Int32)
// 0x000002AF System.Void UnityEngine.Rendering.ConstantBuffer::SetGlobal(System.Int32)
// 0x000002B0 System.Void UnityEngine.Rendering.ConstantBuffer::Set(UnityEngine.Rendering.CommandBuffer,UnityEngine.ComputeShader,System.Int32)
// 0x000002B1 System.Void UnityEngine.Rendering.ConstantBuffer::Set(UnityEngine.ComputeShader,System.Int32)
// 0x000002B2 System.Void UnityEngine.Rendering.ConstantBuffer::Set(UnityEngine.Material,System.Int32)
// 0x000002B3 System.Void UnityEngine.Rendering.ConstantBuffer::ReleaseAll()
extern void ConstantBuffer_ReleaseAll_m45705C7C5F462134EE44B8836265C1FEC4B2EE1A (void);
// 0x000002B4 System.Void UnityEngine.Rendering.ConstantBuffer::Register(UnityEngine.Rendering.ConstantBufferBase)
extern void ConstantBuffer_Register_m3140BCED0E179D4866D62AD282FB2A3AB8AAE58C (void);
// 0x000002B5 System.Void UnityEngine.Rendering.ConstantBuffer::.ctor()
extern void ConstantBuffer__ctor_mEA032D1349A00FDB9819C68A091D4ED28B6B592E (void);
// 0x000002B6 System.Void UnityEngine.Rendering.ConstantBuffer::.cctor()
extern void ConstantBuffer__cctor_m112313AF1963DD52DB8744C3BE8229849320BE1A (void);
// 0x000002B7 System.Void UnityEngine.Rendering.ConstantBufferBase::Release()
// 0x000002B8 System.Void UnityEngine.Rendering.ConstantBufferBase::.ctor()
extern void ConstantBufferBase__ctor_m94F35283F61DBA0BE16E974E2E08FE8AF001C633 (void);
// 0x000002B9 System.Void UnityEngine.Rendering.ConstantBuffer`1::.ctor()
// 0x000002BA System.Void UnityEngine.Rendering.ConstantBuffer`1::UpdateData(UnityEngine.Rendering.CommandBuffer,CBType&)
// 0x000002BB System.Void UnityEngine.Rendering.ConstantBuffer`1::UpdateData(CBType&)
// 0x000002BC System.Void UnityEngine.Rendering.ConstantBuffer`1::SetGlobal(UnityEngine.Rendering.CommandBuffer,System.Int32)
// 0x000002BD System.Void UnityEngine.Rendering.ConstantBuffer`1::SetGlobal(System.Int32)
// 0x000002BE System.Void UnityEngine.Rendering.ConstantBuffer`1::Set(UnityEngine.Rendering.CommandBuffer,UnityEngine.ComputeShader,System.Int32)
// 0x000002BF System.Void UnityEngine.Rendering.ConstantBuffer`1::Set(UnityEngine.ComputeShader,System.Int32)
// 0x000002C0 System.Void UnityEngine.Rendering.ConstantBuffer`1::Set(UnityEngine.Material,System.Int32)
// 0x000002C1 System.Void UnityEngine.Rendering.ConstantBuffer`1::PushGlobal(UnityEngine.Rendering.CommandBuffer,CBType&,System.Int32)
// 0x000002C2 System.Void UnityEngine.Rendering.ConstantBuffer`1::PushGlobal(CBType&,System.Int32)
// 0x000002C3 System.Void UnityEngine.Rendering.ConstantBuffer`1::Release()
// 0x000002C4 UnityEngine.Rendering.ConstantBufferSingleton`1<CBType> UnityEngine.Rendering.ConstantBufferSingleton`1::get_instance()
// 0x000002C5 System.Void UnityEngine.Rendering.ConstantBufferSingleton`1::set_instance(UnityEngine.Rendering.ConstantBufferSingleton`1<CBType>)
// 0x000002C6 System.Void UnityEngine.Rendering.ConstantBufferSingleton`1::Release()
// 0x000002C7 System.Void UnityEngine.Rendering.ConstantBufferSingleton`1::.ctor()
// 0x000002C8 System.Void UnityEngine.Rendering.DisplayInfoAttribute::.ctor()
extern void DisplayInfoAttribute__ctor_m32E321F8942CD30E9525DC5625957DA0FAF00CE2 (void);
// 0x000002C9 System.Void UnityEngine.Rendering.AdditionalPropertyAttribute::.ctor()
extern void AdditionalPropertyAttribute__ctor_m26BABC5057FB7B910AA64EF6DBC2A4E345D14DAE (void);
// 0x000002CA System.Void UnityEngine.Rendering.CoreUnsafeUtils::CopyTo(System.Collections.Generic.List`1<T>,System.Void*,System.Int32)
// 0x000002CB System.Void UnityEngine.Rendering.CoreUnsafeUtils::CopyTo(T[],System.Void*,System.Int32)
// 0x000002CC System.Void UnityEngine.Rendering.CoreUnsafeUtils::CalculateRadixParams(System.Int32,System.Int32&)
extern void CoreUnsafeUtils_CalculateRadixParams_mA3F9E5915909C61B4F6AC824AD1251DF6C4DB3D8 (void);
// 0x000002CD System.Int32 UnityEngine.Rendering.CoreUnsafeUtils::CalculateRadixSupportSize(System.Int32,System.Int32)
extern void CoreUnsafeUtils_CalculateRadixSupportSize_m81701201662FE1E5C333847D5983A80CBAFD416A (void);
// 0x000002CE System.Void UnityEngine.Rendering.CoreUnsafeUtils::CalculateRadixSortSupportArrays(System.Int32,System.Int32,System.UInt32*,System.UInt32*&,System.UInt32*&,System.UInt32*&,System.UInt32*&)
extern void CoreUnsafeUtils_CalculateRadixSortSupportArrays_mC48E09FEAB22CC374B552C36DA3DF6A87AF22C25 (void);
// 0x000002CF System.Void UnityEngine.Rendering.CoreUnsafeUtils::MergeSort(System.UInt32*,System.UInt32*,System.Int32)
extern void CoreUnsafeUtils_MergeSort_m0FDAE66D606A6C1E4273AA67835CAE51C3F46C94 (void);
// 0x000002D0 System.Void UnityEngine.Rendering.CoreUnsafeUtils::MergeSort(System.UInt32[],System.Int32,System.UInt32[]&)
extern void CoreUnsafeUtils_MergeSort_m3B869BAE2FB12C54B19B6F05C1FF4878B0119E09 (void);
// 0x000002D1 System.Void UnityEngine.Rendering.CoreUnsafeUtils::MergeSort(Unity.Collections.NativeArray`1<System.UInt32>,System.Int32,Unity.Collections.NativeArray`1<System.UInt32>&)
extern void CoreUnsafeUtils_MergeSort_mAA0EE8D9A240D5FFA96B5B0017F2DE21CE7B9EF5 (void);
// 0x000002D2 System.Void UnityEngine.Rendering.CoreUnsafeUtils::InsertionSort(System.UInt32*,System.Int32)
extern void CoreUnsafeUtils_InsertionSort_m7F608794B8D35BA45C7B0C09A4F2A4E6B736428F (void);
// 0x000002D3 System.Void UnityEngine.Rendering.CoreUnsafeUtils::InsertionSort(System.UInt32[],System.Int32)
extern void CoreUnsafeUtils_InsertionSort_m8D93071E60687FC60F1C2BC6DCCA41774C71497E (void);
// 0x000002D4 System.Void UnityEngine.Rendering.CoreUnsafeUtils::InsertionSort(Unity.Collections.NativeArray`1<System.UInt32>,System.Int32)
extern void CoreUnsafeUtils_InsertionSort_mF4D8EC3E0CBFB402D6A67FA10722FC875E3C6AB0 (void);
// 0x000002D5 System.Void UnityEngine.Rendering.CoreUnsafeUtils::RadixSort(System.UInt32*,System.UInt32*,System.Int32,System.Int32,System.Int32)
extern void CoreUnsafeUtils_RadixSort_m9ACC1FB4CE50A62FE646E4B3567E1EE0BF0F8DBD (void);
// 0x000002D6 System.Void UnityEngine.Rendering.CoreUnsafeUtils::RadixSort(System.UInt32[],System.Int32,System.UInt32[]&,System.Int32)
extern void CoreUnsafeUtils_RadixSort_m341659CBED64B8068DCF727CB71A0105F70710C0 (void);
// 0x000002D7 System.Void UnityEngine.Rendering.CoreUnsafeUtils::RadixSort(Unity.Collections.NativeArray`1<System.UInt32>,System.Int32,Unity.Collections.NativeArray`1<System.UInt32>&,System.Int32)
extern void CoreUnsafeUtils_RadixSort_m174FB1EFF8086D361EF80E4235950616CC175C3B (void);
// 0x000002D8 System.Void UnityEngine.Rendering.CoreUnsafeUtils::QuickSort(System.UInt32[],System.Int32,System.Int32)
extern void CoreUnsafeUtils_QuickSort_m0992D344EEB55A4BCD122213544AD209E8F76994 (void);
// 0x000002D9 System.Void UnityEngine.Rendering.CoreUnsafeUtils::QuickSort(System.Int32,System.Void*)
// 0x000002DA System.Void UnityEngine.Rendering.CoreUnsafeUtils::QuickSort(System.Int32,System.Void*)
// 0x000002DB System.Void UnityEngine.Rendering.CoreUnsafeUtils::QuickSort(System.Void*,System.Int32,System.Int32)
// 0x000002DC System.Int32 UnityEngine.Rendering.CoreUnsafeUtils::IndexOf(System.Void*,System.Int32,T)
// 0x000002DD System.Int32 UnityEngine.Rendering.CoreUnsafeUtils::CompareHashes(System.Int32,System.Void*,System.Int32,System.Void*,System.Int32*,System.Int32*,System.Int32&,System.Int32&)
// 0x000002DE System.Int32 UnityEngine.Rendering.CoreUnsafeUtils::CompareHashes(System.Int32,UnityEngine.Hash128*,System.Int32,UnityEngine.Hash128*,System.Int32*,System.Int32*,System.Int32&,System.Int32&)
extern void CoreUnsafeUtils_CompareHashes_m3E86391DEDC1888FF118F75ED9BAE3CD88376686 (void);
// 0x000002DF System.Void UnityEngine.Rendering.CoreUnsafeUtils::CombineHashes(System.Int32,System.Void*,UnityEngine.Hash128*)
// 0x000002E0 System.Void UnityEngine.Rendering.CoreUnsafeUtils::CombineHashes(System.Int32,UnityEngine.Hash128*,UnityEngine.Hash128*)
extern void CoreUnsafeUtils_CombineHashes_mFF93250C6EA10674584172B9DA8E37F65DE24D4B (void);
// 0x000002E1 System.Int32 UnityEngine.Rendering.CoreUnsafeUtils::Partition(System.Void*,System.Int32,System.Int32)
// 0x000002E2 System.Boolean UnityEngine.Rendering.CoreUnsafeUtils::HaveDuplicates(System.Int32[])
extern void CoreUnsafeUtils_HaveDuplicates_m6CC59043E94B6D20208D5EACBB42378109102418 (void);
// 0x000002E3 System.Int32 UnityEngine.Rendering.CoreUnsafeUtils/FixedBufferStringQueue::get_Count()
extern void FixedBufferStringQueue_get_Count_mD76761535F559C02B70B4D5D2307258723BB34F9 (void);
// 0x000002E4 System.Void UnityEngine.Rendering.CoreUnsafeUtils/FixedBufferStringQueue::set_Count(System.Int32)
extern void FixedBufferStringQueue_set_Count_m6E44F205107949D343D9C9D27F6CD2BB225D6667 (void);
// 0x000002E5 System.Void UnityEngine.Rendering.CoreUnsafeUtils/FixedBufferStringQueue::.ctor(System.Byte*,System.Int32)
extern void FixedBufferStringQueue__ctor_m02082DF6032DA322E64476C0C762A17BCC4F26DC (void);
// 0x000002E6 System.Boolean UnityEngine.Rendering.CoreUnsafeUtils/FixedBufferStringQueue::TryPush(System.String)
extern void FixedBufferStringQueue_TryPush_m72D763782852C157100DBA747E8F137F4B6B3149 (void);
// 0x000002E7 System.Boolean UnityEngine.Rendering.CoreUnsafeUtils/FixedBufferStringQueue::TryPop(System.String&)
extern void FixedBufferStringQueue_TryPop_mF2BA587E26D93B58FB0BAD59C5125E9E6FB80F09 (void);
// 0x000002E8 System.Void UnityEngine.Rendering.CoreUnsafeUtils/FixedBufferStringQueue::Clear()
extern void FixedBufferStringQueue_Clear_m0B3FFD74689701A352CD3EDFA9C85E9D28ED6DF0 (void);
// 0x000002E9 TKey UnityEngine.Rendering.CoreUnsafeUtils/IKeyGetter`2::Get(TValue&)
// 0x000002EA T UnityEngine.Rendering.CoreUnsafeUtils/DefaultKeyGetter`1::Get(T&)
// 0x000002EB System.UInt32 UnityEngine.Rendering.CoreUnsafeUtils/UintKeyGetter::Get(System.UInt32&)
extern void UintKeyGetter_Get_m76C2635B8A8D4EFDFCF2157D5A691B9C0D7F6141 (void);
// 0x000002EC System.Int32 UnityEngine.Rendering.DynamicArray`1::get_size()
// 0x000002ED System.Void UnityEngine.Rendering.DynamicArray`1::set_size(System.Int32)
// 0x000002EE System.Int32 UnityEngine.Rendering.DynamicArray`1::get_capacity()
// 0x000002EF System.Void UnityEngine.Rendering.DynamicArray`1::.ctor()
// 0x000002F0 System.Void UnityEngine.Rendering.DynamicArray`1::.ctor(System.Int32)
// 0x000002F1 System.Void UnityEngine.Rendering.DynamicArray`1::Clear()
// 0x000002F2 System.Boolean UnityEngine.Rendering.DynamicArray`1::Contains(T)
// 0x000002F3 System.Int32 UnityEngine.Rendering.DynamicArray`1::Add(T&)
// 0x000002F4 System.Void UnityEngine.Rendering.DynamicArray`1::AddRange(UnityEngine.Rendering.DynamicArray`1<T>)
// 0x000002F5 System.Boolean UnityEngine.Rendering.DynamicArray`1::Remove(T)
// 0x000002F6 System.Void UnityEngine.Rendering.DynamicArray`1::RemoveAt(System.Int32)
// 0x000002F7 System.Void UnityEngine.Rendering.DynamicArray`1::RemoveRange(System.Int32,System.Int32)
// 0x000002F8 System.Int32 UnityEngine.Rendering.DynamicArray`1::FindIndex(System.Int32,System.Int32,System.Predicate`1<T>)
// 0x000002F9 System.Int32 UnityEngine.Rendering.DynamicArray`1::IndexOf(T,System.Int32,System.Int32)
// 0x000002FA System.Int32 UnityEngine.Rendering.DynamicArray`1::IndexOf(T,System.Int32)
// 0x000002FB System.Int32 UnityEngine.Rendering.DynamicArray`1::IndexOf(T)
// 0x000002FC System.Void UnityEngine.Rendering.DynamicArray`1::Resize(System.Int32,System.Boolean)
// 0x000002FD System.Void UnityEngine.Rendering.DynamicArray`1::Reserve(System.Int32,System.Boolean)
// 0x000002FE T& UnityEngine.Rendering.DynamicArray`1::get_Item(System.Int32)
// 0x000002FF T[] UnityEngine.Rendering.DynamicArray`1::op_Implicit(UnityEngine.Rendering.DynamicArray`1<T>)
// 0x00000300 System.Int32 UnityEngine.Rendering.DynamicArrayExtensions::Partition(T[],System.Int32,System.Int32)
// 0x00000301 System.Void UnityEngine.Rendering.DynamicArrayExtensions::QuickSort(T[],System.Int32,System.Int32)
// 0x00000302 System.Void UnityEngine.Rendering.DynamicArrayExtensions::QuickSort(UnityEngine.Rendering.DynamicArray`1<T>)
// 0x00000303 System.Void UnityEngine.Rendering.PerformDynamicRes::.ctor(System.Object,System.IntPtr)
extern void PerformDynamicRes__ctor_m6DE404207716B9CF7CB8E08C5C9E59A82B49B40E (void);
// 0x00000304 System.Single UnityEngine.Rendering.PerformDynamicRes::Invoke()
extern void PerformDynamicRes_Invoke_mD407788BCFC1B6B1E3DBE2E28A052EEB0190510B (void);
// 0x00000305 System.IAsyncResult UnityEngine.Rendering.PerformDynamicRes::BeginInvoke(System.AsyncCallback,System.Object)
extern void PerformDynamicRes_BeginInvoke_mAEE0D03993E275FFF28478E712CD340A29719AD6 (void);
// 0x00000306 System.Single UnityEngine.Rendering.PerformDynamicRes::EndInvoke(System.IAsyncResult)
extern void PerformDynamicRes_EndInvoke_m0063049FB2B568344D76DEB0505B3E2E42BE6645 (void);
// 0x00000307 System.Void UnityEngine.Rendering.DynamicResolutionHandler::Reset()
extern void DynamicResolutionHandler_Reset_mCAD8F828B490E47D29551684E9BF919A80D082CC (void);
// 0x00000308 UnityEngine.Rendering.DynamicResUpscaleFilter UnityEngine.Rendering.DynamicResolutionHandler::get_filter()
extern void DynamicResolutionHandler_get_filter_mD3E5D8CCCC4B486123F2CFBECC993E34490AC9AC (void);
// 0x00000309 System.Void UnityEngine.Rendering.DynamicResolutionHandler::set_filter(UnityEngine.Rendering.DynamicResUpscaleFilter)
extern void DynamicResolutionHandler_set_filter_mBE888DA4EDD9D09F8FBC2D7482DF6CA3EC8C01F2 (void);
// 0x0000030A UnityEngine.Vector2Int UnityEngine.Rendering.DynamicResolutionHandler::get_finalViewport()
extern void DynamicResolutionHandler_get_finalViewport_m00EBCB5489C6369B1CB3FDFDC304E2BD1271776A (void);
// 0x0000030B System.Void UnityEngine.Rendering.DynamicResolutionHandler::set_finalViewport(UnityEngine.Vector2Int)
extern void DynamicResolutionHandler_set_finalViewport_mE821C4F8DD1C095D1ED61AFBA0663D2101E88D2B (void);
// 0x0000030C System.Void UnityEngine.Rendering.DynamicResolutionHandler::set_runUpscalerFilterOnFullResolution(System.Boolean)
extern void DynamicResolutionHandler_set_runUpscalerFilterOnFullResolution_mB838E0AE8DA12FEDE11D98C3041C3A618580F89B (void);
// 0x0000030D System.Boolean UnityEngine.Rendering.DynamicResolutionHandler::get_runUpscalerFilterOnFullResolution()
extern void DynamicResolutionHandler_get_runUpscalerFilterOnFullResolution_mB676A5E1BD1FABB5CCACA1E4EB0A8C266CB1CD23 (void);
// 0x0000030E System.Boolean UnityEngine.Rendering.DynamicResolutionHandler::FlushScalableBufferManagerState()
extern void DynamicResolutionHandler_FlushScalableBufferManagerState_mE5CED8D2E09BC0844DB1969D491D35C534379BD1 (void);
// 0x0000030F UnityEngine.Rendering.DynamicResolutionHandler UnityEngine.Rendering.DynamicResolutionHandler::GetOrCreateDrsInstanceHandler(UnityEngine.Camera)
extern void DynamicResolutionHandler_GetOrCreateDrsInstanceHandler_mB7511A48A3C0FC5B90F8512ECB1294F7C6C2267D (void);
// 0x00000310 System.Void UnityEngine.Rendering.DynamicResolutionHandler::set_upsamplerSchedule(UnityEngine.Rendering.DynamicResolutionHandler/UpsamplerScheduleType)
extern void DynamicResolutionHandler_set_upsamplerSchedule_m89200D3DE9B9C5C320A773D8C31635B6BDB0A437 (void);
// 0x00000311 UnityEngine.Rendering.DynamicResolutionHandler/UpsamplerScheduleType UnityEngine.Rendering.DynamicResolutionHandler::get_upsamplerSchedule()
extern void DynamicResolutionHandler_get_upsamplerSchedule_m912966EB7F7528669346F8172C4CC2713421C354 (void);
// 0x00000312 UnityEngine.Rendering.DynamicResolutionHandler UnityEngine.Rendering.DynamicResolutionHandler::get_instance()
extern void DynamicResolutionHandler_get_instance_mB5F7D50D277F853FC0D5ECE14E3EEB3630060A94 (void);
// 0x00000313 System.Void UnityEngine.Rendering.DynamicResolutionHandler::.ctor()
extern void DynamicResolutionHandler__ctor_m8F8CCCC18D6BB56DBD15B129F83EF516C2535B27 (void);
// 0x00000314 System.Single UnityEngine.Rendering.DynamicResolutionHandler::DefaultDynamicResMethod()
extern void DynamicResolutionHandler_DefaultDynamicResMethod_mA21FF171A0064BC217D9ABFE1663189A5D1DBB6E (void);
// 0x00000315 System.Void UnityEngine.Rendering.DynamicResolutionHandler::ProcessSettings(UnityEngine.Rendering.GlobalDynamicResolutionSettings)
extern void DynamicResolutionHandler_ProcessSettings_mB1DA598171628A30DBDEA6F3BE179B894422D7FE (void);
// 0x00000316 UnityEngine.Vector2 UnityEngine.Rendering.DynamicResolutionHandler::GetResolvedScale()
extern void DynamicResolutionHandler_GetResolvedScale_m1F5182A5D9687FACF4F859CB38CD92CB767282D7 (void);
// 0x00000317 System.Single UnityEngine.Rendering.DynamicResolutionHandler::CalculateMipBias(UnityEngine.Vector2Int,UnityEngine.Vector2Int,System.Boolean)
extern void DynamicResolutionHandler_CalculateMipBias_m91211395DCDC11B8AA6569C65033DFF95C31CD7D (void);
// 0x00000318 System.Void UnityEngine.Rendering.DynamicResolutionHandler::SetDynamicResScaler(UnityEngine.Rendering.PerformDynamicRes,UnityEngine.Rendering.DynamicResScalePolicyType)
extern void DynamicResolutionHandler_SetDynamicResScaler_mD4634B44E92248502386D3876E7FA1B7A4075CDD (void);
// 0x00000319 System.Void UnityEngine.Rendering.DynamicResolutionHandler::SetSystemDynamicResScaler(UnityEngine.Rendering.PerformDynamicRes,UnityEngine.Rendering.DynamicResScalePolicyType)
extern void DynamicResolutionHandler_SetSystemDynamicResScaler_mA5DBD3583CAAE8553330C71E33F5767BCBF13E17 (void);
// 0x0000031A System.Void UnityEngine.Rendering.DynamicResolutionHandler::SetActiveDynamicScalerSlot(UnityEngine.Rendering.DynamicResScalerSlot)
extern void DynamicResolutionHandler_SetActiveDynamicScalerSlot_mCE1DAFB721B1323497811B565CB74D210ED4CA72 (void);
// 0x0000031B System.Void UnityEngine.Rendering.DynamicResolutionHandler::ClearSelectedCamera()
extern void DynamicResolutionHandler_ClearSelectedCamera_m7A3DE1CCAFEF8B5AE3686C2DC2FD1D320D3DF353 (void);
// 0x0000031C System.Void UnityEngine.Rendering.DynamicResolutionHandler::SetUpscaleFilter(UnityEngine.Camera,UnityEngine.Rendering.DynamicResUpscaleFilter)
extern void DynamicResolutionHandler_SetUpscaleFilter_m5B1AC58D11657C17C1FBE5D677B5F4CB0559AD62 (void);
// 0x0000031D System.Void UnityEngine.Rendering.DynamicResolutionHandler::SetCurrentCameraRequest(System.Boolean)
extern void DynamicResolutionHandler_SetCurrentCameraRequest_m8AAE061DC0452D48F183C9B6FD9BCB063B542D9B (void);
// 0x0000031E System.Void UnityEngine.Rendering.DynamicResolutionHandler::UpdateAndUseCamera(UnityEngine.Camera,System.Nullable`1<UnityEngine.Rendering.GlobalDynamicResolutionSettings>,System.Action)
extern void DynamicResolutionHandler_UpdateAndUseCamera_mC548CFA8941E1929733E7AE05C492970739E5D44 (void);
// 0x0000031F System.Void UnityEngine.Rendering.DynamicResolutionHandler::Update(UnityEngine.Rendering.GlobalDynamicResolutionSettings,System.Action)
extern void DynamicResolutionHandler_Update_m88523DFEA038541509AE38FAB7A136FC22D0FD24 (void);
// 0x00000320 System.Boolean UnityEngine.Rendering.DynamicResolutionHandler::SoftwareDynamicResIsEnabled()
extern void DynamicResolutionHandler_SoftwareDynamicResIsEnabled_m6D45F7FB372F1E1735A5DA8F1F063DACCB9BDE9C (void);
// 0x00000321 System.Boolean UnityEngine.Rendering.DynamicResolutionHandler::HardwareDynamicResIsEnabled()
extern void DynamicResolutionHandler_HardwareDynamicResIsEnabled_mDD7A039094F7770063A58FB71942B9204E3353CA (void);
// 0x00000322 System.Boolean UnityEngine.Rendering.DynamicResolutionHandler::RequestsHardwareDynamicResolution()
extern void DynamicResolutionHandler_RequestsHardwareDynamicResolution_mE007D198D273487DD581E1D3C675218D9EC082CC (void);
// 0x00000323 System.Boolean UnityEngine.Rendering.DynamicResolutionHandler::DynamicResolutionEnabled()
extern void DynamicResolutionHandler_DynamicResolutionEnabled_m743EA5F78E9E53B4703F8D3E71914677043D6B5C (void);
// 0x00000324 System.Void UnityEngine.Rendering.DynamicResolutionHandler::ForceSoftwareFallback()
extern void DynamicResolutionHandler_ForceSoftwareFallback_m824A0C6626039D48FA74E98910BB7204358AF883 (void);
// 0x00000325 UnityEngine.Vector2Int UnityEngine.Rendering.DynamicResolutionHandler::GetScaledSize(UnityEngine.Vector2Int)
extern void DynamicResolutionHandler_GetScaledSize_mF2F4EF2E56CA1F9977FC929AD538C3F39E3FC688 (void);
// 0x00000326 UnityEngine.Vector2Int UnityEngine.Rendering.DynamicResolutionHandler::ApplyScalesOnSize(UnityEngine.Vector2Int)
extern void DynamicResolutionHandler_ApplyScalesOnSize_m65DBECCBF4C39386564AFFE17573331EAC4B15AB (void);
// 0x00000327 UnityEngine.Vector2Int UnityEngine.Rendering.DynamicResolutionHandler::ApplyScalesOnSize(UnityEngine.Vector2Int,UnityEngine.Vector2)
extern void DynamicResolutionHandler_ApplyScalesOnSize_mD8A58BA1454CF83D34BF0DFCBC4A0B0251C5B240 (void);
// 0x00000328 System.Single UnityEngine.Rendering.DynamicResolutionHandler::GetCurrentScale()
extern void DynamicResolutionHandler_GetCurrentScale_mDF82E24A8DD95C5D205276D372E40B4C02C24F80 (void);
// 0x00000329 UnityEngine.Vector2Int UnityEngine.Rendering.DynamicResolutionHandler::GetLastScaledSize()
extern void DynamicResolutionHandler_GetLastScaledSize_m2EEF34035A43BD49F05DBA104CD496CBE3A9B471 (void);
// 0x0000032A System.Single UnityEngine.Rendering.DynamicResolutionHandler::GetLowResMultiplier(System.Single)
extern void DynamicResolutionHandler_GetLowResMultiplier_mB0FAA125AB58DF5F1F077B45104E840B15893A8D (void);
// 0x0000032B System.Void UnityEngine.Rendering.DynamicResolutionHandler::.cctor()
extern void DynamicResolutionHandler__cctor_mDDAAC32872CD5018D46B52EF8DA295F395AA7EB3 (void);
// 0x0000032C UnityEngine.Rendering.GlobalDynamicResolutionSettings UnityEngine.Rendering.GlobalDynamicResolutionSettings::NewDefault()
extern void GlobalDynamicResolutionSettings_NewDefault_m2348E238A9145B9231F72B63A84E50202F665342 (void);
// 0x0000032D System.Boolean UnityEngine.Rendering.IVirtualTexturingEnabledRenderPipeline::get_virtualTexturingEnabled()
// 0x0000032E T* UnityEngine.Rendering.ListBuffer`1::get_BufferPtr()
// 0x0000032F System.Int32 UnityEngine.Rendering.ListBuffer`1::get_Count()
// 0x00000330 System.Int32 UnityEngine.Rendering.ListBuffer`1::get_Capacity()
// 0x00000331 System.Void UnityEngine.Rendering.ListBuffer`1::.ctor(T*,System.Int32*,System.Int32)
// 0x00000332 T& UnityEngine.Rendering.ListBuffer`1::get_Item(System.Int32&)
// 0x00000333 T& UnityEngine.Rendering.ListBuffer`1::GetUnchecked(System.Int32&)
// 0x00000334 System.Boolean UnityEngine.Rendering.ListBuffer`1::TryAdd(T&)
// 0x00000335 System.Void UnityEngine.Rendering.ListBuffer`1::CopyTo(T*,System.Int32,System.Int32)
// 0x00000336 System.Boolean UnityEngine.Rendering.ListBuffer`1::TryCopyTo(UnityEngine.Rendering.ListBuffer`1<T>)
// 0x00000337 System.Boolean UnityEngine.Rendering.ListBuffer`1::TryCopyFrom(T*,System.Int32)
// 0x00000338 System.Void UnityEngine.Rendering.ListBufferExtensions::QuickSort(UnityEngine.Rendering.ListBuffer`1<T>)
// 0x00000339 System.Int32 UnityEngine.Rendering.ObjectPool`1::get_countAll()
// 0x0000033A System.Void UnityEngine.Rendering.ObjectPool`1::set_countAll(System.Int32)
// 0x0000033B System.Int32 UnityEngine.Rendering.ObjectPool`1::get_countActive()
// 0x0000033C System.Int32 UnityEngine.Rendering.ObjectPool`1::get_countInactive()
// 0x0000033D System.Void UnityEngine.Rendering.ObjectPool`1::.ctor(UnityEngine.Events.UnityAction`1<T>,UnityEngine.Events.UnityAction`1<T>,System.Boolean)
// 0x0000033E T UnityEngine.Rendering.ObjectPool`1::Get()
// 0x0000033F UnityEngine.Rendering.ObjectPool`1/PooledObject<T> UnityEngine.Rendering.ObjectPool`1::Get(T&)
// 0x00000340 System.Void UnityEngine.Rendering.ObjectPool`1::Release(T)
// 0x00000341 System.Void UnityEngine.Rendering.ObjectPool`1/PooledObject::.ctor(T,UnityEngine.Rendering.ObjectPool`1<T>)
// 0x00000342 System.Void UnityEngine.Rendering.ObjectPool`1/PooledObject::System.IDisposable.Dispose()
// 0x00000343 T UnityEngine.Rendering.GenericPool`1::Get()
// 0x00000344 UnityEngine.Rendering.ObjectPool`1/PooledObject<T> UnityEngine.Rendering.GenericPool`1::Get(T&)
// 0x00000345 System.Void UnityEngine.Rendering.GenericPool`1::Release(T)
// 0x00000346 System.Void UnityEngine.Rendering.GenericPool`1::.cctor()
// 0x00000347 T UnityEngine.Rendering.UnsafeGenericPool`1::Get()
// 0x00000348 UnityEngine.Rendering.ObjectPool`1/PooledObject<T> UnityEngine.Rendering.UnsafeGenericPool`1::Get(T&)
// 0x00000349 System.Void UnityEngine.Rendering.UnsafeGenericPool`1::Release(T)
// 0x0000034A System.Void UnityEngine.Rendering.UnsafeGenericPool`1::.cctor()
// 0x0000034B System.Collections.Generic.List`1<T> UnityEngine.Rendering.ListPool`1::Get()
// 0x0000034C UnityEngine.Rendering.ObjectPool`1/PooledObject<System.Collections.Generic.List`1<T>> UnityEngine.Rendering.ListPool`1::Get(System.Collections.Generic.List`1<T>&)
// 0x0000034D System.Void UnityEngine.Rendering.ListPool`1::Release(System.Collections.Generic.List`1<T>)
// 0x0000034E System.Void UnityEngine.Rendering.ListPool`1::.cctor()
// 0x0000034F System.Void UnityEngine.Rendering.ListPool`1/<>c::.cctor()
// 0x00000350 System.Void UnityEngine.Rendering.ListPool`1/<>c::.ctor()
// 0x00000351 System.Void UnityEngine.Rendering.ListPool`1/<>c::<.cctor>b__4_0(System.Collections.Generic.List`1<T>)
// 0x00000352 System.Collections.Generic.HashSet`1<T> UnityEngine.Rendering.HashSetPool`1::Get()
// 0x00000353 UnityEngine.Rendering.ObjectPool`1/PooledObject<System.Collections.Generic.HashSet`1<T>> UnityEngine.Rendering.HashSetPool`1::Get(System.Collections.Generic.HashSet`1<T>&)
// 0x00000354 System.Void UnityEngine.Rendering.HashSetPool`1::Release(System.Collections.Generic.HashSet`1<T>)
// 0x00000355 System.Void UnityEngine.Rendering.HashSetPool`1::.cctor()
// 0x00000356 System.Void UnityEngine.Rendering.HashSetPool`1/<>c::.cctor()
// 0x00000357 System.Void UnityEngine.Rendering.HashSetPool`1/<>c::.ctor()
// 0x00000358 System.Void UnityEngine.Rendering.HashSetPool`1/<>c::<.cctor>b__4_0(System.Collections.Generic.HashSet`1<T>)
// 0x00000359 System.Collections.Generic.Dictionary`2<TKey,TValue> UnityEngine.Rendering.DictionaryPool`2::Get()
// 0x0000035A UnityEngine.Rendering.ObjectPool`1/PooledObject<System.Collections.Generic.Dictionary`2<TKey,TValue>> UnityEngine.Rendering.DictionaryPool`2::Get(System.Collections.Generic.Dictionary`2<TKey,TValue>&)
// 0x0000035B System.Void UnityEngine.Rendering.DictionaryPool`2::Release(System.Collections.Generic.Dictionary`2<TKey,TValue>)
// 0x0000035C System.Void UnityEngine.Rendering.DictionaryPool`2::.cctor()
// 0x0000035D System.Void UnityEngine.Rendering.DictionaryPool`2/<>c::.cctor()
// 0x0000035E System.Void UnityEngine.Rendering.DictionaryPool`2/<>c::.ctor()
// 0x0000035F System.Void UnityEngine.Rendering.DictionaryPool`2/<>c::<.cctor>b__4_0(System.Collections.Generic.Dictionary`2<TKey,TValue>)
// 0x00000360 System.Void UnityEngine.Rendering.ListChangedEventArgs`1::.ctor(System.Int32,T)
// 0x00000361 System.Void UnityEngine.Rendering.ListChangedEventHandler`1::.ctor(System.Object,System.IntPtr)
// 0x00000362 System.Void UnityEngine.Rendering.ListChangedEventHandler`1::Invoke(UnityEngine.Rendering.ObservableList`1<T>,UnityEngine.Rendering.ListChangedEventArgs`1<T>)
// 0x00000363 System.IAsyncResult UnityEngine.Rendering.ListChangedEventHandler`1::BeginInvoke(UnityEngine.Rendering.ObservableList`1<T>,UnityEngine.Rendering.ListChangedEventArgs`1<T>,System.AsyncCallback,System.Object)
// 0x00000364 System.Void UnityEngine.Rendering.ListChangedEventHandler`1::EndInvoke(System.IAsyncResult)
// 0x00000365 System.Void UnityEngine.Rendering.ObservableList`1::add_ItemAdded(UnityEngine.Rendering.ListChangedEventHandler`1<T>)
// 0x00000366 System.Void UnityEngine.Rendering.ObservableList`1::remove_ItemAdded(UnityEngine.Rendering.ListChangedEventHandler`1<T>)
// 0x00000367 System.Void UnityEngine.Rendering.ObservableList`1::add_ItemRemoved(UnityEngine.Rendering.ListChangedEventHandler`1<T>)
// 0x00000368 System.Void UnityEngine.Rendering.ObservableList`1::remove_ItemRemoved(UnityEngine.Rendering.ListChangedEventHandler`1<T>)
// 0x00000369 T UnityEngine.Rendering.ObservableList`1::get_Item(System.Int32)
// 0x0000036A System.Void UnityEngine.Rendering.ObservableList`1::set_Item(System.Int32,T)
// 0x0000036B System.Int32 UnityEngine.Rendering.ObservableList`1::get_Count()
// 0x0000036C System.Boolean UnityEngine.Rendering.ObservableList`1::get_IsReadOnly()
// 0x0000036D System.Void UnityEngine.Rendering.ObservableList`1::.ctor()
// 0x0000036E System.Void UnityEngine.Rendering.ObservableList`1::.ctor(System.Int32)
// 0x0000036F System.Void UnityEngine.Rendering.ObservableList`1::.ctor(System.Collections.Generic.IEnumerable`1<T>)
// 0x00000370 System.Void UnityEngine.Rendering.ObservableList`1::OnEvent(UnityEngine.Rendering.ListChangedEventHandler`1<T>,System.Int32,T)
// 0x00000371 System.Boolean UnityEngine.Rendering.ObservableList`1::Contains(T)
// 0x00000372 System.Int32 UnityEngine.Rendering.ObservableList`1::IndexOf(T)
// 0x00000373 System.Void UnityEngine.Rendering.ObservableList`1::Add(T)
// 0x00000374 System.Void UnityEngine.Rendering.ObservableList`1::Add(T[])
// 0x00000375 System.Void UnityEngine.Rendering.ObservableList`1::Insert(System.Int32,T)
// 0x00000376 System.Boolean UnityEngine.Rendering.ObservableList`1::Remove(T)
// 0x00000377 System.Int32 UnityEngine.Rendering.ObservableList`1::Remove(T[])
// 0x00000378 System.Void UnityEngine.Rendering.ObservableList`1::RemoveAt(System.Int32)
// 0x00000379 System.Void UnityEngine.Rendering.ObservableList`1::Clear()
// 0x0000037A System.Void UnityEngine.Rendering.ObservableList`1::CopyTo(T[],System.Int32)
// 0x0000037B System.Collections.Generic.IEnumerator`1<T> UnityEngine.Rendering.ObservableList`1::GetEnumerator()
// 0x0000037C System.Collections.IEnumerator UnityEngine.Rendering.ObservableList`1::System.Collections.IEnumerable.GetEnumerator()
// 0x0000037D System.Enum UnityEngine.Rendering.SerializableEnum::get_value()
extern void SerializableEnum_get_value_m847B9970F811A9F7105C31240EF5361847F6E5B3 (void);
// 0x0000037E System.Void UnityEngine.Rendering.SerializableEnum::set_value(System.Enum)
extern void SerializableEnum_set_value_mEC3C9ABD19AAB4AEDCFB10BD76FCB66C67BC4D94 (void);
// 0x0000037F System.Void UnityEngine.Rendering.SerializableEnum::.ctor(System.Type)
extern void SerializableEnum__ctor_m0EC8862E7D14F1C0F50A735A8EE72127AED0ACA0 (void);
// 0x00000380 K UnityEngine.Rendering.SerializedDictionary`2::SerializeKey(K)
// 0x00000381 V UnityEngine.Rendering.SerializedDictionary`2::SerializeValue(V)
// 0x00000382 K UnityEngine.Rendering.SerializedDictionary`2::DeserializeKey(K)
// 0x00000383 V UnityEngine.Rendering.SerializedDictionary`2::DeserializeValue(V)
// 0x00000384 System.Void UnityEngine.Rendering.SerializedDictionary`2::.ctor()
// 0x00000385 SK UnityEngine.Rendering.SerializedDictionary`4::SerializeKey(K)
// 0x00000386 SV UnityEngine.Rendering.SerializedDictionary`4::SerializeValue(V)
// 0x00000387 K UnityEngine.Rendering.SerializedDictionary`4::DeserializeKey(SK)
// 0x00000388 V UnityEngine.Rendering.SerializedDictionary`4::DeserializeValue(SV)
// 0x00000389 System.Void UnityEngine.Rendering.SerializedDictionary`4::OnBeforeSerialize()
// 0x0000038A System.Void UnityEngine.Rendering.SerializedDictionary`4::OnAfterDeserialize()
// 0x0000038B System.Void UnityEngine.Rendering.SerializedDictionary`4::.ctor()
// 0x0000038C System.Single UnityEngine.Rendering.XRGraphics::get_eyeTextureResolutionScale()
extern void XRGraphics_get_eyeTextureResolutionScale_m76C72817BFBBA40F19FFDD78520328F2276C897D (void);
// 0x0000038D System.Void UnityEngine.Rendering.XRGraphics::set_eyeTextureResolutionScale(System.Single)
extern void XRGraphics_set_eyeTextureResolutionScale_mDAA664F075C60B1D9F1CB993F6F596FECD5ED1E2 (void);
// 0x0000038E System.Single UnityEngine.Rendering.XRGraphics::get_renderViewportScale()
extern void XRGraphics_get_renderViewportScale_m692F7AEA96D4FBE101FD5F4E79E067A92DDDAA6F (void);
// 0x0000038F System.Boolean UnityEngine.Rendering.XRGraphics::get_enabled()
extern void XRGraphics_get_enabled_m20C6B9469F10B969FCB5A6C947572018D2EC3682 (void);
// 0x00000390 System.Boolean UnityEngine.Rendering.XRGraphics::get_isDeviceActive()
extern void XRGraphics_get_isDeviceActive_m2C56A0AAC15E7A5EAB13FF166C21656A346D50C3 (void);
// 0x00000391 System.String UnityEngine.Rendering.XRGraphics::get_loadedDeviceName()
extern void XRGraphics_get_loadedDeviceName_mEFE40C069D96EAB1D434396610F448CA04F9BF0C (void);
// 0x00000392 System.String[] UnityEngine.Rendering.XRGraphics::get_supportedDevices()
extern void XRGraphics_get_supportedDevices_m2533C6F7D38AB048753C86CD99246FEE6EB97E51 (void);
// 0x00000393 UnityEngine.Rendering.XRGraphics/StereoRenderingMode UnityEngine.Rendering.XRGraphics::get_stereoRenderingMode()
extern void XRGraphics_get_stereoRenderingMode_m4C79DB2B7BAE5ED2E2A955124CB195D665B4C88D (void);
// 0x00000394 UnityEngine.RenderTextureDescriptor UnityEngine.Rendering.XRGraphics::get_eyeTextureDesc()
extern void XRGraphics_get_eyeTextureDesc_m7DE5587B34A67EFA47A20E0A577782AD24A0B848 (void);
// 0x00000395 System.Int32 UnityEngine.Rendering.XRGraphics::get_eyeTextureWidth()
extern void XRGraphics_get_eyeTextureWidth_mD73772DBAF245376C5FECDA6AF2827FF8519E88D (void);
// 0x00000396 System.Int32 UnityEngine.Rendering.XRGraphics::get_eyeTextureHeight()
extern void XRGraphics_get_eyeTextureHeight_m8665C6F84451DFB48E4DB0CDD87BB920E009EA95 (void);
// 0x00000397 System.Void UnityEngine.Rendering.XRGraphics::.ctor()
extern void XRGraphics__ctor_m3F6CB23F4CCFBDB5B349C5A7D7B5A771E3C91357 (void);
// 0x00000398 System.Void UnityEngine.Rendering.DebugManager::RegisterActions()
extern void DebugManager_RegisterActions_m08A5627380CCCB0192783D05AEED057F817B177C (void);
// 0x00000399 System.Void UnityEngine.Rendering.DebugManager::EnableInputActions()
extern void DebugManager_EnableInputActions_m5889ED24EFA3383E683D452FE45CD434E1611E92 (void);
// 0x0000039A System.Void UnityEngine.Rendering.DebugManager::AddAction(UnityEngine.Rendering.DebugAction,UnityEngine.Rendering.DebugActionDesc)
extern void DebugManager_AddAction_mADAAC2A5B86323625966CC53D0413AA0E4C7E9BB (void);
// 0x0000039B System.Void UnityEngine.Rendering.DebugManager::SampleAction(System.Int32)
extern void DebugManager_SampleAction_mBB1CB238142C6828A7BC49AC6885BD4B5E14185D (void);
// 0x0000039C System.Void UnityEngine.Rendering.DebugManager::UpdateAction(System.Int32)
extern void DebugManager_UpdateAction_mC315562B9E390627E83B59D5CA15DDB0B9AF9375 (void);
// 0x0000039D System.Void UnityEngine.Rendering.DebugManager::UpdateActions()
extern void DebugManager_UpdateActions_mFDFEE466E6EF0295FF22CFFC92738CD80DF6A30F (void);
// 0x0000039E System.Single UnityEngine.Rendering.DebugManager::GetAction(UnityEngine.Rendering.DebugAction)
extern void DebugManager_GetAction_mF49CDA3900720779DADCA26D660A9C08DAC7741C (void);
// 0x0000039F System.Boolean UnityEngine.Rendering.DebugManager::GetActionToggleDebugMenuWithTouch()
extern void DebugManager_GetActionToggleDebugMenuWithTouch_mD00A060C5705334410F83ACE437D7659756D71EB (void);
// 0x000003A0 System.Boolean UnityEngine.Rendering.DebugManager::GetActionReleaseScrollTarget()
extern void DebugManager_GetActionReleaseScrollTarget_mA8742D7420A03055AEF6E99576E359AA6E5FBE77 (void);
// 0x000003A1 System.Void UnityEngine.Rendering.DebugManager::RegisterInputs()
extern void DebugManager_RegisterInputs_m537F22F75442F20A412290FED01B4E4F036EC233 (void);
// 0x000003A2 UnityEngine.Rendering.DebugManager UnityEngine.Rendering.DebugManager::get_instance()
extern void DebugManager_get_instance_mE739109CEF80088D21ED7FCF46D1153097B45086 (void);
// 0x000003A3 System.Void UnityEngine.Rendering.DebugManager::UpdateReadOnlyCollection()
extern void DebugManager_UpdateReadOnlyCollection_m53286D374289908BD8D3A8D5E99661CEEB80AAC5 (void);
// 0x000003A4 System.Collections.ObjectModel.ReadOnlyCollection`1<UnityEngine.Rendering.DebugUI/Panel> UnityEngine.Rendering.DebugManager::get_panels()
extern void DebugManager_get_panels_m6D2F1002F12979053200CD6A29CCED2635F12F6E (void);
// 0x000003A5 System.Void UnityEngine.Rendering.DebugManager::add_onDisplayRuntimeUIChanged(System.Action`1<System.Boolean>)
extern void DebugManager_add_onDisplayRuntimeUIChanged_m9DDCAA67B1F3EDEC672CE08DFF83DA7E25EB0AFD (void);
// 0x000003A6 System.Void UnityEngine.Rendering.DebugManager::remove_onDisplayRuntimeUIChanged(System.Action`1<System.Boolean>)
extern void DebugManager_remove_onDisplayRuntimeUIChanged_m2DC90942AD8C4117BD4569F8659F0C0C928661A9 (void);
// 0x000003A7 System.Void UnityEngine.Rendering.DebugManager::add_onSetDirty(System.Action)
extern void DebugManager_add_onSetDirty_m78A474A63D04359ED435BD03825CCCF2B701CA30 (void);
// 0x000003A8 System.Void UnityEngine.Rendering.DebugManager::remove_onSetDirty(System.Action)
extern void DebugManager_remove_onSetDirty_mD60B9F3EB7FB9308E432F4395BDEF06B59A6A8D1 (void);
// 0x000003A9 System.Void UnityEngine.Rendering.DebugManager::add_resetData(System.Action)
extern void DebugManager_add_resetData_m6195C05AE430E2DF4B8D0FB20D5057552AF24240 (void);
// 0x000003AA System.Void UnityEngine.Rendering.DebugManager::remove_resetData(System.Action)
extern void DebugManager_remove_resetData_m96A67431C2EAF71CAC1E811A13738711BEBE1AC6 (void);
// 0x000003AB System.Boolean UnityEngine.Rendering.DebugManager::get_displayEditorUI()
extern void DebugManager_get_displayEditorUI_mB0BC6CF28FF4569A791579BF6BD22CAD17774792 (void);
// 0x000003AC System.Void UnityEngine.Rendering.DebugManager::ToggleEditorUI(System.Boolean)
extern void DebugManager_ToggleEditorUI_m0A74DA6D686ECB521E6E82F19557955261DDE504 (void);
// 0x000003AD System.Boolean UnityEngine.Rendering.DebugManager::get_enableRuntimeUI()
extern void DebugManager_get_enableRuntimeUI_m2CB2E20F2CCE737FE6AD3214D5DC16D75F2CA532 (void);
// 0x000003AE System.Void UnityEngine.Rendering.DebugManager::set_enableRuntimeUI(System.Boolean)
extern void DebugManager_set_enableRuntimeUI_mBFBBD988EE69074F4E2AFA33770FDBBBC623C201 (void);
// 0x000003AF System.Boolean UnityEngine.Rendering.DebugManager::get_displayRuntimeUI()
extern void DebugManager_get_displayRuntimeUI_m425A05718ADC5F5168D3D862C0FF3CB5D36259A0 (void);
// 0x000003B0 System.Void UnityEngine.Rendering.DebugManager::set_displayRuntimeUI(System.Boolean)
extern void DebugManager_set_displayRuntimeUI_m9D935288B59DE1136DB37985EFE102A35CD4A90A (void);
// 0x000003B1 System.Boolean UnityEngine.Rendering.DebugManager::get_displayPersistentRuntimeUI()
extern void DebugManager_get_displayPersistentRuntimeUI_m7B8B935C5E6D5D0EE734DB112B2178418910EF48 (void);
// 0x000003B2 System.Void UnityEngine.Rendering.DebugManager::set_displayPersistentRuntimeUI(System.Boolean)
extern void DebugManager_set_displayPersistentRuntimeUI_m6EA3817BEF5D31D2000061DBE8E95CF40AA43262 (void);
// 0x000003B3 System.Void UnityEngine.Rendering.DebugManager::.ctor()
extern void DebugManager__ctor_mF476ADDF14866AE360540BE83717892D259CC38E (void);
// 0x000003B4 System.Void UnityEngine.Rendering.DebugManager::RefreshEditor()
extern void DebugManager_RefreshEditor_m212A2648023473D0D7714F88FEF0B6B00357B948 (void);
// 0x000003B5 System.Void UnityEngine.Rendering.DebugManager::Reset()
extern void DebugManager_Reset_m8F235B190A155A4748A6101C46F5654D989C42CA (void);
// 0x000003B6 System.Void UnityEngine.Rendering.DebugManager::ReDrawOnScreenDebug()
extern void DebugManager_ReDrawOnScreenDebug_m743E2E7D187BB39F175DE5D6D21F6BD0676A49F7 (void);
// 0x000003B7 System.Void UnityEngine.Rendering.DebugManager::RegisterData(UnityEngine.Rendering.IDebugData)
extern void DebugManager_RegisterData_m120D9348EE342EEB06177C14D4B4E3E0A0FFF7C0 (void);
// 0x000003B8 System.Void UnityEngine.Rendering.DebugManager::UnregisterData(UnityEngine.Rendering.IDebugData)
extern void DebugManager_UnregisterData_m0E2EFE5940D89CC5A2E2115F56E5D004D8715AAE (void);
// 0x000003B9 System.Int32 UnityEngine.Rendering.DebugManager::GetState()
extern void DebugManager_GetState_mA45CEE821FEFFF5A7546DA822FD046F63FEF37CF (void);
// 0x000003BA System.Void UnityEngine.Rendering.DebugManager::RegisterRootCanvas(UnityEngine.Rendering.UI.DebugUIHandlerCanvas)
extern void DebugManager_RegisterRootCanvas_m17796C585AB91ADE0FA5901FD3B800B75A0C1A18 (void);
// 0x000003BB System.Void UnityEngine.Rendering.DebugManager::ChangeSelection(UnityEngine.Rendering.UI.DebugUIHandlerWidget,System.Boolean)
extern void DebugManager_ChangeSelection_m77C3E5AD1A1B7D9EEFA8C39BFD8A40B1AEEB856A (void);
// 0x000003BC System.Void UnityEngine.Rendering.DebugManager::SetScrollTarget(UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugManager_SetScrollTarget_mA81C5DD4585EF12FD3C966E898549568B603FCE9 (void);
// 0x000003BD System.Void UnityEngine.Rendering.DebugManager::EnsurePersistentCanvas()
extern void DebugManager_EnsurePersistentCanvas_m3EF45D3A10CE2C9CF3AAEA227125FD5C225D8908 (void);
// 0x000003BE System.Void UnityEngine.Rendering.DebugManager::TogglePersistent(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugManager_TogglePersistent_m053E880302A92E891DAEA5AEB7837AD0C58EA540 (void);
// 0x000003BF System.Void UnityEngine.Rendering.DebugManager::OnPanelDirty(UnityEngine.Rendering.DebugUI/Panel)
extern void DebugManager_OnPanelDirty_m131DF174602146B039443A1A28F3DFA62DC1128D (void);
// 0x000003C0 System.Void UnityEngine.Rendering.DebugManager::RequestEditorWindowPanelIndex(System.Int32)
extern void DebugManager_RequestEditorWindowPanelIndex_m83A9C35808CD06610427B39DD3184F4738B7A238 (void);
// 0x000003C1 System.Nullable`1<System.Int32> UnityEngine.Rendering.DebugManager::GetRequestedEditorWindowPanelIndex()
extern void DebugManager_GetRequestedEditorWindowPanelIndex_m0645B6776A0B926D039063CBF97F0146E139E87A (void);
// 0x000003C2 UnityEngine.Rendering.DebugUI/Panel UnityEngine.Rendering.DebugManager::GetPanel(System.String,System.Boolean,System.Int32,System.Boolean)
extern void DebugManager_GetPanel_mD434C1C01EA3E39B3C97783F23C6DDF10E2D4617 (void);
// 0x000003C3 System.Void UnityEngine.Rendering.DebugManager::RemovePanel(System.String)
extern void DebugManager_RemovePanel_m2BA800D60782D86B7D43DCC6BF75A7A644F01AE6 (void);
// 0x000003C4 System.Void UnityEngine.Rendering.DebugManager::RemovePanel(UnityEngine.Rendering.DebugUI/Panel)
extern void DebugManager_RemovePanel_m6A4747CEB9021415FE50E4215B26CDFE6F1FFCF4 (void);
// 0x000003C5 UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.DebugManager::GetItem(System.String)
extern void DebugManager_GetItem_mE1D9B27547C9D486C15B0DD30486FCB78AE9C593 (void);
// 0x000003C6 UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.DebugManager::GetItem(System.String,UnityEngine.Rendering.DebugUI/IContainer)
extern void DebugManager_GetItem_m566B64605B39FCFA874D81BD5FF3EA91826DBF07 (void);
// 0x000003C7 System.Void UnityEngine.Rendering.DebugManager::.cctor()
extern void DebugManager__cctor_m907F8CDAD24776E760732BF95AD18B1D9EC76AEA (void);
// 0x000003C8 System.Void UnityEngine.Rendering.DebugManager/<>c::.cctor()
extern void U3CU3Ec__cctor_mB7CF1D7FA772DAA78896023EC91108D6CE5177E0 (void);
// 0x000003C9 System.Void UnityEngine.Rendering.DebugManager/<>c::.ctor()
extern void U3CU3Ec__ctor_m62A49ED74D0D04ED3D1DCB5CFE60143C140CCA32 (void);
// 0x000003CA System.Void UnityEngine.Rendering.DebugManager/<>c::<.ctor>b__61_0(System.Boolean)
extern void U3CU3Ec_U3C_ctorU3Eb__61_0_m33F5DEA3457FEC99073B87CA24A7E4EA42B04731 (void);
// 0x000003CB System.Void UnityEngine.Rendering.DebugManager/<>c::<.ctor>b__61_1()
extern void U3CU3Ec_U3C_ctorU3Eb__61_1_m448398689B057C28EF2102BA9D3BF5E7B51051AF (void);
// 0x000003CC UnityEngine.Rendering.DebugManager UnityEngine.Rendering.DebugManager/<>c::<.cctor>b__81_0()
extern void U3CU3Ec_U3C_cctorU3Eb__81_0_mF78E83BAC51411EEB68F2464ADBEC56485EA5070 (void);
// 0x000003CD System.Void UnityEngine.Rendering.DebugActionDesc::.ctor()
extern void DebugActionDesc__ctor_m850B5BC98DC18B58B0F5C7549CF58BF020418010 (void);
// 0x000003CE System.Boolean UnityEngine.Rendering.DebugActionState::get_runningAction()
extern void DebugActionState_get_runningAction_mEB9DCBC3068EB129469ECA0CB23A78ECFB79E738 (void);
// 0x000003CF System.Void UnityEngine.Rendering.DebugActionState::set_runningAction(System.Boolean)
extern void DebugActionState_set_runningAction_mC0CBE1248F7AC3282F94479C272FE840EACE6475 (void);
// 0x000003D0 System.Single UnityEngine.Rendering.DebugActionState::get_actionState()
extern void DebugActionState_get_actionState_m7DF4C910BA8D1EB0A09F67889CAC58E68FF7CA5D (void);
// 0x000003D1 System.Void UnityEngine.Rendering.DebugActionState::set_actionState(System.Single)
extern void DebugActionState_set_actionState_mF8B8936D22509EBB2A75CCBE299A7E689F35F519 (void);
// 0x000003D2 System.Void UnityEngine.Rendering.DebugActionState::Trigger(System.Int32,System.Single)
extern void DebugActionState_Trigger_m6EB1B4962D76B3FC49800703CB441D030515F16D (void);
// 0x000003D3 System.Void UnityEngine.Rendering.DebugActionState::TriggerWithButton(UnityEngine.InputSystem.InputAction,System.Single)
extern void DebugActionState_TriggerWithButton_m55E14EC67214E15DBF4F2119828892DD4E2A90FF (void);
// 0x000003D4 System.Void UnityEngine.Rendering.DebugActionState::Reset()
extern void DebugActionState_Reset_m02AC56B80B3E1D2F6168085671463C739A0DFAB5 (void);
// 0x000003D5 System.Void UnityEngine.Rendering.DebugActionState::Update(UnityEngine.Rendering.DebugActionDesc)
extern void DebugActionState_Update_m9E82525978934996DC1DAE8672E949BD7D6EAB9E (void);
// 0x000003D6 System.Void UnityEngine.Rendering.DebugActionState::.ctor()
extern void DebugActionState__ctor_m3C1005EA7D29105C979ECB8FEDBC8114301DFE54 (void);
// 0x000003D7 System.Action UnityEngine.Rendering.IDebugData::GetReset()
// 0x000003D8 UnityEngine.Rendering.DebugShapes UnityEngine.Rendering.DebugShapes::get_instance()
extern void DebugShapes_get_instance_m62A94E93E7E2858686828810507EFF672FB63D09 (void);
// 0x000003D9 System.Void UnityEngine.Rendering.DebugShapes::BuildSphere(UnityEngine.Mesh&,System.Single,System.UInt32,System.UInt32)
extern void DebugShapes_BuildSphere_m2F8DC6F2C41EC71B78426044CB72C9A901564DB2 (void);
// 0x000003DA System.Void UnityEngine.Rendering.DebugShapes::BuildBox(UnityEngine.Mesh&,System.Single,System.Single,System.Single)
extern void DebugShapes_BuildBox_m32A28AE9D970EC49A14B27E8304E3036F9585A78 (void);
// 0x000003DB System.Void UnityEngine.Rendering.DebugShapes::BuildCone(UnityEngine.Mesh&,System.Single,System.Single,System.Single,System.Int32)
extern void DebugShapes_BuildCone_m3B10CB0169CB29F6E7D9B9BFB118FD7533DD0C34 (void);
// 0x000003DC System.Void UnityEngine.Rendering.DebugShapes::BuildPyramid(UnityEngine.Mesh&,System.Single,System.Single,System.Single)
extern void DebugShapes_BuildPyramid_m053C3007C6D480E9FC626DB4269C9176E10826D1 (void);
// 0x000003DD System.Void UnityEngine.Rendering.DebugShapes::BuildShapes()
extern void DebugShapes_BuildShapes_m9EE57CB52AFBE5B256F90A129B7351BEDB76C08B (void);
// 0x000003DE System.Void UnityEngine.Rendering.DebugShapes::RebuildResources()
extern void DebugShapes_RebuildResources_mCC40B2CAAA50D843081A5318223853A7AEA5C894 (void);
// 0x000003DF UnityEngine.Mesh UnityEngine.Rendering.DebugShapes::RequestSphereMesh()
extern void DebugShapes_RequestSphereMesh_mE7A458570F1FBFE176EDCCDB3296938B6630AFAB (void);
// 0x000003E0 UnityEngine.Mesh UnityEngine.Rendering.DebugShapes::RequestBoxMesh()
extern void DebugShapes_RequestBoxMesh_m4D81525EE113A2E28D43484A988F96B1D15C24F5 (void);
// 0x000003E1 UnityEngine.Mesh UnityEngine.Rendering.DebugShapes::RequestConeMesh()
extern void DebugShapes_RequestConeMesh_m928BAFC56E30F7481B6816DBA4B641667C29A020 (void);
// 0x000003E2 UnityEngine.Mesh UnityEngine.Rendering.DebugShapes::RequestPyramidMesh()
extern void DebugShapes_RequestPyramidMesh_m1B04F71D00EF5063AFAB9ACCD42983A6522E3E7E (void);
// 0x000003E3 System.Void UnityEngine.Rendering.DebugShapes::.ctor()
extern void DebugShapes__ctor_m51B4A41AD0E654D2733C4F03EC777F9A1E97CBBA (void);
// 0x000003E4 System.Void UnityEngine.Rendering.DebugUI::.ctor()
extern void DebugUI__ctor_m62AF64F0AA0461E47CDD8DB2BC5396716913FBB4 (void);
// 0x000003E5 UnityEngine.Rendering.ObservableList`1<UnityEngine.Rendering.DebugUI/Widget> UnityEngine.Rendering.DebugUI/Container::get_children()
extern void Container_get_children_mF5C23A0F324E22BEBEF2EA14CE8DA7BEA72D631B (void);
// 0x000003E6 System.Void UnityEngine.Rendering.DebugUI/Container::set_children(UnityEngine.Rendering.ObservableList`1<UnityEngine.Rendering.DebugUI/Widget>)
extern void Container_set_children_mCF89E0F76E568DF6B7D36DF256D31EFA6C0816AF (void);
// 0x000003E7 UnityEngine.Rendering.DebugUI/Panel UnityEngine.Rendering.DebugUI/Container::get_panel()
extern void Container_get_panel_mBA18A8C9B2202AF0D23B87D1BEA4F39C330C51EB (void);
// 0x000003E8 System.Void UnityEngine.Rendering.DebugUI/Container::set_panel(UnityEngine.Rendering.DebugUI/Panel)
extern void Container_set_panel_mCEF38A447DA832758D2216EF5AC6CB2CC7BBEC26 (void);
// 0x000003E9 System.Void UnityEngine.Rendering.DebugUI/Container::.ctor()
extern void Container__ctor_m31E5465D076DCC7A1C932B44B7D2000821C0BFE8 (void);
// 0x000003EA System.Void UnityEngine.Rendering.DebugUI/Container::.ctor(System.String,UnityEngine.Rendering.ObservableList`1<UnityEngine.Rendering.DebugUI/Widget>)
extern void Container__ctor_m46FE992D48A7E41195B54F97C68C6850E4E88638 (void);
// 0x000003EB System.Void UnityEngine.Rendering.DebugUI/Container::GenerateQueryPath()
extern void Container_GenerateQueryPath_m980DFE475B7DC7DD3ACA1AC5434ED4F086671862 (void);
// 0x000003EC System.Void UnityEngine.Rendering.DebugUI/Container::OnItemAdded(UnityEngine.Rendering.ObservableList`1<UnityEngine.Rendering.DebugUI/Widget>,UnityEngine.Rendering.ListChangedEventArgs`1<UnityEngine.Rendering.DebugUI/Widget>)
extern void Container_OnItemAdded_m2A8448259868E7070860EFE2CBBF9903B57AF4BA (void);
// 0x000003ED System.Void UnityEngine.Rendering.DebugUI/Container::OnItemRemoved(UnityEngine.Rendering.ObservableList`1<UnityEngine.Rendering.DebugUI/Widget>,UnityEngine.Rendering.ListChangedEventArgs`1<UnityEngine.Rendering.DebugUI/Widget>)
extern void Container_OnItemRemoved_mE2081F89AA7A0D0FAC294EE0AD59258746DD84C8 (void);
// 0x000003EE System.Int32 UnityEngine.Rendering.DebugUI/Container::GetHashCode()
extern void Container_GetHashCode_m3B58370534C56FEB22EFF02EAEEDCAED265C7F6A (void);
// 0x000003EF System.Boolean UnityEngine.Rendering.DebugUI/Foldout::get_isReadOnly()
extern void Foldout_get_isReadOnly_mA5BD95FD6277027A543E26CBE6BD048CB2A0E886 (void);
// 0x000003F0 System.String[] UnityEngine.Rendering.DebugUI/Foldout::get_columnLabels()
extern void Foldout_get_columnLabels_m668E673185A4DFF88DCA1B1CBA7DCFA59E491F38 (void);
// 0x000003F1 System.Void UnityEngine.Rendering.DebugUI/Foldout::set_columnLabels(System.String[])
extern void Foldout_set_columnLabels_m708C0359BECC9C20EA881B159AA9362000B7BD74 (void);
// 0x000003F2 System.String[] UnityEngine.Rendering.DebugUI/Foldout::get_columnTooltips()
extern void Foldout_get_columnTooltips_m4D3DE909F195D474F81F9A563AE719254E8AF3B3 (void);
// 0x000003F3 System.Void UnityEngine.Rendering.DebugUI/Foldout::set_columnTooltips(System.String[])
extern void Foldout_set_columnTooltips_m461962F856FCF985C404521285F86AC77A7AF02B (void);
// 0x000003F4 System.Void UnityEngine.Rendering.DebugUI/Foldout::.ctor()
extern void Foldout__ctor_m139328695A6D59A234CDE32D0CEDA6B80A4F96D2 (void);
// 0x000003F5 System.Void UnityEngine.Rendering.DebugUI/Foldout::.ctor(System.String,UnityEngine.Rendering.ObservableList`1<UnityEngine.Rendering.DebugUI/Widget>,System.String[],System.String[])
extern void Foldout__ctor_m61E0C79F14925225848625B5787BEBA322D223E6 (void);
// 0x000003F6 System.Boolean UnityEngine.Rendering.DebugUI/Foldout::GetValue()
extern void Foldout_GetValue_m3AC0382B7AEF8DABEA86B4D8076A8ADCD21210B9 (void);
// 0x000003F7 System.Object UnityEngine.Rendering.DebugUI/Foldout::UnityEngine.Rendering.DebugUI.IValueField.GetValue()
extern void Foldout_UnityEngine_Rendering_DebugUI_IValueField_GetValue_m819C151D885BCE3181E2924F01749312B78F680D (void);
// 0x000003F8 System.Void UnityEngine.Rendering.DebugUI/Foldout::SetValue(System.Object)
extern void Foldout_SetValue_mBB92A78DF887960ED4662620AE5131EBD5B91BC1 (void);
// 0x000003F9 System.Object UnityEngine.Rendering.DebugUI/Foldout::ValidateValue(System.Object)
extern void Foldout_ValidateValue_m6045DAD80CC3A35442EA2E881AFEDB6BBF184548 (void);
// 0x000003FA System.Void UnityEngine.Rendering.DebugUI/Foldout::SetValue(System.Boolean)
extern void Foldout_SetValue_m9C7EA58B4CD8DB13304A7F2E23A40CEDA2A1DD7B (void);
// 0x000003FB System.Void UnityEngine.Rendering.DebugUI/HBox::.ctor()
extern void HBox__ctor_m9AE6A2CE7C4A6163433B215CC2C99FAA1FDEF765 (void);
// 0x000003FC System.Void UnityEngine.Rendering.DebugUI/VBox::.ctor()
extern void VBox__ctor_m8F876CB1E7BA14B53CF50B6F9F75D85F617179B5 (void);
// 0x000003FD System.Void UnityEngine.Rendering.DebugUI/Table::.ctor()
extern void Table__ctor_m2C4DA9603E5F18A6A8B9E7B590A88A6319E0D5B5 (void);
// 0x000003FE System.Void UnityEngine.Rendering.DebugUI/Table::SetColumnVisibility(System.Int32,System.Boolean)
extern void Table_SetColumnVisibility_m7BA5263B7234028B87709E33DF273063EF99BEAA (void);
// 0x000003FF System.Boolean UnityEngine.Rendering.DebugUI/Table::GetColumnVisibility(System.Int32)
extern void Table_GetColumnVisibility_mC3485D2148D3BA1D0E9699228A03577D0BB9A935 (void);
// 0x00000400 System.Boolean[] UnityEngine.Rendering.DebugUI/Table::get_VisibleColumns()
extern void Table_get_VisibleColumns_m8E0E5070482E68F4F6C1B01AE62F0B36745ECF65 (void);
// 0x00000401 System.Void UnityEngine.Rendering.DebugUI/Table::OnItemAdded(UnityEngine.Rendering.ObservableList`1<UnityEngine.Rendering.DebugUI/Widget>,UnityEngine.Rendering.ListChangedEventArgs`1<UnityEngine.Rendering.DebugUI/Widget>)
extern void Table_OnItemAdded_m631366817C2BAD7FAC37F6592629C7535FB01923 (void);
// 0x00000402 System.Void UnityEngine.Rendering.DebugUI/Table::OnItemRemoved(UnityEngine.Rendering.ObservableList`1<UnityEngine.Rendering.DebugUI/Widget>,UnityEngine.Rendering.ListChangedEventArgs`1<UnityEngine.Rendering.DebugUI/Widget>)
extern void Table_OnItemRemoved_m38C900B0E73D188AD6517F741241B7DD921F8433 (void);
// 0x00000403 System.Void UnityEngine.Rendering.DebugUI/Table/Row::.ctor()
extern void Row__ctor_m67B21E4FEDB0B9C6A9F75055E37480BFA3681DBE (void);
// 0x00000404 UnityEngine.Rendering.DebugUI/Panel UnityEngine.Rendering.DebugUI/Widget::get_panel()
extern void Widget_get_panel_m4F078DFA48956864635ECE730C8D8EECBD833536 (void);
// 0x00000405 System.Void UnityEngine.Rendering.DebugUI/Widget::set_panel(UnityEngine.Rendering.DebugUI/Panel)
extern void Widget_set_panel_m5D546A0D88061CFADD8C5857F779D6D23E93B187 (void);
// 0x00000406 UnityEngine.Rendering.DebugUI/IContainer UnityEngine.Rendering.DebugUI/Widget::get_parent()
extern void Widget_get_parent_m2A53945D87CC26A262E6C6833795DE7C1E2646D4 (void);
// 0x00000407 System.Void UnityEngine.Rendering.DebugUI/Widget::set_parent(UnityEngine.Rendering.DebugUI/IContainer)
extern void Widget_set_parent_mE73484D4C5B6E8BFF7A4702E9833295128858529 (void);
// 0x00000408 UnityEngine.Rendering.DebugUI/Flags UnityEngine.Rendering.DebugUI/Widget::get_flags()
extern void Widget_get_flags_mEB9026DBB54AF2A1941D478C9A393BBCF958573D (void);
// 0x00000409 System.Void UnityEngine.Rendering.DebugUI/Widget::set_flags(UnityEngine.Rendering.DebugUI/Flags)
extern void Widget_set_flags_m650616AFB473FC82D7B9F85D805317E0B9F6ABCD (void);
// 0x0000040A System.String UnityEngine.Rendering.DebugUI/Widget::get_displayName()
extern void Widget_get_displayName_m1E7836A53BF88619C4815EA70F9243319567F0F4 (void);
// 0x0000040B System.Void UnityEngine.Rendering.DebugUI/Widget::set_displayName(System.String)
extern void Widget_set_displayName_mDCBDC31DD3A041E03DFA4BEA8FCA2A428F4ED921 (void);
// 0x0000040C System.String UnityEngine.Rendering.DebugUI/Widget::get_tooltip()
extern void Widget_get_tooltip_m36AB147BF4618674BD7F3CA0E70FFEF33E0EB463 (void);
// 0x0000040D System.Void UnityEngine.Rendering.DebugUI/Widget::set_tooltip(System.String)
extern void Widget_set_tooltip_m87968E949EAD82E82438D33EAB241C6B8352C37B (void);
// 0x0000040E System.String UnityEngine.Rendering.DebugUI/Widget::get_queryPath()
extern void Widget_get_queryPath_mB3729532CECC96E1EC3F3D8BF51ABA50BAEA84C9 (void);
// 0x0000040F System.Void UnityEngine.Rendering.DebugUI/Widget::set_queryPath(System.String)
extern void Widget_set_queryPath_m9F3323420B75D42329C83F09359E9ED3F90E5DC9 (void);
// 0x00000410 System.Boolean UnityEngine.Rendering.DebugUI/Widget::get_isEditorOnly()
extern void Widget_get_isEditorOnly_m06E01DE2267BB52DB8C4E52ED2EBBF8DC9EE05AE (void);
// 0x00000411 System.Boolean UnityEngine.Rendering.DebugUI/Widget::get_isRuntimeOnly()
extern void Widget_get_isRuntimeOnly_mDA9928932296862108B0CE5E897423F70DD4857A (void);
// 0x00000412 System.Boolean UnityEngine.Rendering.DebugUI/Widget::get_isInactiveInEditor()
extern void Widget_get_isInactiveInEditor_m3C48D7CD02ED7B7365FE1F86888DE649D23AAA3E (void);
// 0x00000413 System.Boolean UnityEngine.Rendering.DebugUI/Widget::get_isHidden()
extern void Widget_get_isHidden_m16EEAA4800FE8ADD122631636B01FBEFBFA95DAB (void);
// 0x00000414 System.Void UnityEngine.Rendering.DebugUI/Widget::GenerateQueryPath()
extern void Widget_GenerateQueryPath_m40520357FEDFC20D4B6905A9C93D20478362C49A (void);
// 0x00000415 System.Int32 UnityEngine.Rendering.DebugUI/Widget::GetHashCode()
extern void Widget_GetHashCode_mCD0D23D37EF54C79160861F227F27821C5F0F504 (void);
// 0x00000416 System.Void UnityEngine.Rendering.DebugUI/Widget::set_nameAndTooltip(UnityEngine.Rendering.DebugUI/Widget/NameAndTooltip)
extern void Widget_set_nameAndTooltip_m6A2AA733173D30AA828D74FAB162ECBCECC7A80A (void);
// 0x00000417 System.Void UnityEngine.Rendering.DebugUI/Widget::.ctor()
extern void Widget__ctor_m376F53A5E652F839D704FE6F6A447C11FA669C66 (void);
// 0x00000418 UnityEngine.Rendering.ObservableList`1<UnityEngine.Rendering.DebugUI/Widget> UnityEngine.Rendering.DebugUI/IContainer::get_children()
// 0x00000419 System.String UnityEngine.Rendering.DebugUI/IContainer::get_displayName()
// 0x0000041A System.Void UnityEngine.Rendering.DebugUI/IContainer::set_displayName(System.String)
// 0x0000041B System.String UnityEngine.Rendering.DebugUI/IContainer::get_queryPath()
// 0x0000041C System.Object UnityEngine.Rendering.DebugUI/IValueField::GetValue()
// 0x0000041D System.Void UnityEngine.Rendering.DebugUI/IValueField::SetValue(System.Object)
// 0x0000041E System.Object UnityEngine.Rendering.DebugUI/IValueField::ValidateValue(System.Object)
// 0x0000041F System.Action UnityEngine.Rendering.DebugUI/Button::get_action()
extern void Button_get_action_m5796CC1DF3A5C10D2538EA5ACF4EEF0DF68DFB13 (void);
// 0x00000420 System.Void UnityEngine.Rendering.DebugUI/Button::set_action(System.Action)
extern void Button_set_action_m5F7843835E47500A6D3A0BFD268F451854D767A7 (void);
// 0x00000421 System.Void UnityEngine.Rendering.DebugUI/Button::.ctor()
extern void Button__ctor_mA34758B11D4DE127E0B126C0D43A656D4D2837DC (void);
// 0x00000422 System.Func`1<System.Object> UnityEngine.Rendering.DebugUI/Value::get_getter()
extern void Value_get_getter_mBB5B000F4470481A61A298E2CD13DF4CBD70B23E (void);
// 0x00000423 System.Void UnityEngine.Rendering.DebugUI/Value::set_getter(System.Func`1<System.Object>)
extern void Value_set_getter_m2184497927F2C23CEB0CCF47480D886AE5237EC4 (void);
// 0x00000424 System.Void UnityEngine.Rendering.DebugUI/Value::.ctor()
extern void Value__ctor_mA90FCDCAC383495356834BFCE0EE2B589B51E07F (void);
// 0x00000425 System.Object UnityEngine.Rendering.DebugUI/Value::GetValue()
extern void Value_GetValue_mD32191C4552B9FB57F0C048785854DBF320C9BAF (void);
// 0x00000426 System.Func`1<T> UnityEngine.Rendering.DebugUI/Field`1::get_getter()
// 0x00000427 System.Void UnityEngine.Rendering.DebugUI/Field`1::set_getter(System.Func`1<T>)
// 0x00000428 System.Action`1<T> UnityEngine.Rendering.DebugUI/Field`1::get_setter()
// 0x00000429 System.Void UnityEngine.Rendering.DebugUI/Field`1::set_setter(System.Action`1<T>)
// 0x0000042A System.Object UnityEngine.Rendering.DebugUI/Field`1::UnityEngine.Rendering.DebugUI.IValueField.ValidateValue(System.Object)
// 0x0000042B T UnityEngine.Rendering.DebugUI/Field`1::ValidateValue(T)
// 0x0000042C System.Object UnityEngine.Rendering.DebugUI/Field`1::UnityEngine.Rendering.DebugUI.IValueField.GetValue()
// 0x0000042D T UnityEngine.Rendering.DebugUI/Field`1::GetValue()
// 0x0000042E System.Void UnityEngine.Rendering.DebugUI/Field`1::SetValue(System.Object)
// 0x0000042F System.Void UnityEngine.Rendering.DebugUI/Field`1::SetValue(T)
// 0x00000430 System.Void UnityEngine.Rendering.DebugUI/Field`1::.ctor()
// 0x00000431 System.Void UnityEngine.Rendering.DebugUI/BoolField::.ctor()
extern void BoolField__ctor_m8C1D78E29A30C2D3844607274207943D3B576E55 (void);
// 0x00000432 System.Func`1<System.Boolean>[] UnityEngine.Rendering.DebugUI/HistoryBoolField::get_historyGetter()
extern void HistoryBoolField_get_historyGetter_m4D7567A18F6A433A3ECE3573D6D875EC02A3963E (void);
// 0x00000433 System.Void UnityEngine.Rendering.DebugUI/HistoryBoolField::set_historyGetter(System.Func`1<System.Boolean>[])
extern void HistoryBoolField_set_historyGetter_m0C1E8D18F182E0BA08169A7A20CA1170D7B3E24F (void);
// 0x00000434 System.Int32 UnityEngine.Rendering.DebugUI/HistoryBoolField::get_historyDepth()
extern void HistoryBoolField_get_historyDepth_m33199CA7A24CD1696636A032118D3513CDFC63A5 (void);
// 0x00000435 System.Boolean UnityEngine.Rendering.DebugUI/HistoryBoolField::GetHistoryValue(System.Int32)
extern void HistoryBoolField_GetHistoryValue_m2C22B47DFF7BC9E386761F54139D8DF9D7B40553 (void);
// 0x00000436 System.Void UnityEngine.Rendering.DebugUI/HistoryBoolField::.ctor()
extern void HistoryBoolField__ctor_m89E7099F44F88D25D35AB246DF2CA64B22EB9031 (void);
// 0x00000437 System.Int32 UnityEngine.Rendering.DebugUI/IntField::ValidateValue(System.Int32)
extern void IntField_ValidateValue_mB3697EE56E5842C8AEA5C02A32684FC0FD95704C (void);
// 0x00000438 System.Void UnityEngine.Rendering.DebugUI/IntField::.ctor()
extern void IntField__ctor_m01170A091DE36EB6E36BD4988B04FC83CE07BA25 (void);
// 0x00000439 System.UInt32 UnityEngine.Rendering.DebugUI/UIntField::ValidateValue(System.UInt32)
extern void UIntField_ValidateValue_m740E8ACC04DAE68BEC4C5A6C3C752611D607272B (void);
// 0x0000043A System.Void UnityEngine.Rendering.DebugUI/UIntField::.ctor()
extern void UIntField__ctor_m2E4B33E952E8A77180C23014DA305B229EA47ED4 (void);
// 0x0000043B System.Single UnityEngine.Rendering.DebugUI/FloatField::ValidateValue(System.Single)
extern void FloatField_ValidateValue_m23A7FA0907187975ADA4E7B132AC8823C47554CC (void);
// 0x0000043C System.Void UnityEngine.Rendering.DebugUI/FloatField::.ctor()
extern void FloatField__ctor_m7F65D8D59BFF5ADB91AA09D8FE3EF063BCF90BD9 (void);
// 0x0000043D UnityEngine.GUIContent[] UnityEngine.Rendering.DebugUI/EnumUtility::MakeEnumNames(System.Type)
extern void EnumUtility_MakeEnumNames_m418CDBDE0BCAFBC3CB15C5DA60157A89763BD140 (void);
// 0x0000043E System.Int32[] UnityEngine.Rendering.DebugUI/EnumUtility::MakeEnumValues(System.Type)
extern void EnumUtility_MakeEnumValues_mFBDB118AAE172BD2C7309F31AEAE8EFFA1875E5A (void);
// 0x0000043F System.Void UnityEngine.Rendering.DebugUI/EnumUtility/<>c::.cctor()
extern void U3CU3Ec__cctor_m450E821002529B4EDC2B709FBD406FCF1734E634 (void);
// 0x00000440 System.Void UnityEngine.Rendering.DebugUI/EnumUtility/<>c::.ctor()
extern void U3CU3Ec__ctor_m5BF6A81593EC440E9C45B6A8C387ABF988A0CE36 (void);
// 0x00000441 UnityEngine.GUIContent UnityEngine.Rendering.DebugUI/EnumUtility/<>c::<MakeEnumNames>b__0_0(System.Reflection.FieldInfo)
extern void U3CU3Ec_U3CMakeEnumNamesU3Eb__0_0_m600F94EEF3D8B7E95561610E9CFC56B456982A33 (void);
// 0x00000442 System.Func`1<System.Int32> UnityEngine.Rendering.DebugUI/EnumField::get_getIndex()
extern void EnumField_get_getIndex_m9D3DADB71BE92C1B54FD5315B8C06BA2D68EE3FD (void);
// 0x00000443 System.Void UnityEngine.Rendering.DebugUI/EnumField::set_getIndex(System.Func`1<System.Int32>)
extern void EnumField_set_getIndex_m1353057A317788EE0157D6559E7EB7178D08C62B (void);
// 0x00000444 System.Action`1<System.Int32> UnityEngine.Rendering.DebugUI/EnumField::get_setIndex()
extern void EnumField_get_setIndex_m72B40AFF93BCB6A72148E36EB14C98F3948C1922 (void);
// 0x00000445 System.Void UnityEngine.Rendering.DebugUI/EnumField::set_setIndex(System.Action`1<System.Int32>)
extern void EnumField_set_setIndex_m5C3DF9F1331972A5B1DA0F62664530BA86344F3D (void);
// 0x00000446 System.Int32 UnityEngine.Rendering.DebugUI/EnumField::get_currentIndex()
extern void EnumField_get_currentIndex_m4D47B593DC586CC3A0806A2987F6464718876802 (void);
// 0x00000447 System.Void UnityEngine.Rendering.DebugUI/EnumField::set_currentIndex(System.Int32)
extern void EnumField_set_currentIndex_mEB5CA5FE86F8F8F9E2CFD3F08EA06DBC0E794FA7 (void);
// 0x00000448 System.Void UnityEngine.Rendering.DebugUI/EnumField::set_autoEnum(System.Type)
extern void EnumField_set_autoEnum_m22B1BF1EE22FF469D5B6B47EB893C80883D0AEDB (void);
// 0x00000449 System.Void UnityEngine.Rendering.DebugUI/EnumField::InitQuickSeparators()
extern void EnumField_InitQuickSeparators_m819096798D533BAFC6541EFCDB7B9DAE8B078D1E (void);
// 0x0000044A System.Void UnityEngine.Rendering.DebugUI/EnumField::InitIndexes()
extern void EnumField_InitIndexes_m5A00CA7100887328361759AF12502AC803E57472 (void);
// 0x0000044B System.Void UnityEngine.Rendering.DebugUI/EnumField::.ctor()
extern void EnumField__ctor_m70AF15D32AC334B12E512298AAE02ED438074C78 (void);
// 0x0000044C System.Void UnityEngine.Rendering.DebugUI/EnumField/<>c::.cctor()
extern void U3CU3Ec__cctor_m9B6DE1A47D1E97C85A4AF4389CB1C242A8414193 (void);
// 0x0000044D System.Void UnityEngine.Rendering.DebugUI/EnumField/<>c::.ctor()
extern void U3CU3Ec__ctor_mB8A8520B3A180E74A7D93029922E79D6AD8C0130 (void);
// 0x0000044E System.String UnityEngine.Rendering.DebugUI/EnumField/<>c::<InitQuickSeparators>b__17_0(UnityEngine.GUIContent)
extern void U3CU3Ec_U3CInitQuickSeparatorsU3Eb__17_0_mFFD8CE9ED1EB00ADCDFE046DF8FF00FAC4C484F4 (void);
// 0x0000044F System.Func`1<System.Int32>[] UnityEngine.Rendering.DebugUI/HistoryEnumField::get_historyIndexGetter()
extern void HistoryEnumField_get_historyIndexGetter_mFE380F5C43EFC29095547306FDF1E61C87D41C1C (void);
// 0x00000450 System.Void UnityEngine.Rendering.DebugUI/HistoryEnumField::set_historyIndexGetter(System.Func`1<System.Int32>[])
extern void HistoryEnumField_set_historyIndexGetter_m32A0FC4FDB681E1F0B7C5EB11FC021A695FCA74F (void);
// 0x00000451 System.Int32 UnityEngine.Rendering.DebugUI/HistoryEnumField::get_historyDepth()
extern void HistoryEnumField_get_historyDepth_mD38724219D2D4B9D17E5F5799DA96AD674CCC5E7 (void);
// 0x00000452 System.Int32 UnityEngine.Rendering.DebugUI/HistoryEnumField::GetHistoryValue(System.Int32)
extern void HistoryEnumField_GetHistoryValue_m1E43C624459622E5963762488452C94839CD738C (void);
// 0x00000453 System.Void UnityEngine.Rendering.DebugUI/HistoryEnumField::.ctor()
extern void HistoryEnumField__ctor_m2E1B5EC38B24CF0E32ECF85FCC65A34279B24611 (void);
// 0x00000454 UnityEngine.GUIContent[] UnityEngine.Rendering.DebugUI/BitField::get_enumNames()
extern void BitField_get_enumNames_m3518C9A0F352E7390CABA60F16E5C2246F12634C (void);
// 0x00000455 System.Void UnityEngine.Rendering.DebugUI/BitField::set_enumNames(UnityEngine.GUIContent[])
extern void BitField_set_enumNames_m16DCD2AEC657E914F549F55710165EC906BF2E7B (void);
// 0x00000456 System.Int32[] UnityEngine.Rendering.DebugUI/BitField::get_enumValues()
extern void BitField_get_enumValues_m5CBA7136A37EBDD8845BF4CE47261201601F9527 (void);
// 0x00000457 System.Void UnityEngine.Rendering.DebugUI/BitField::set_enumValues(System.Int32[])
extern void BitField_set_enumValues_m359E7A2117FA2BE7906B2995F44F0C07DE64A238 (void);
// 0x00000458 System.Type UnityEngine.Rendering.DebugUI/BitField::get_enumType()
extern void BitField_get_enumType_m579A37FEF96B7B00BD32858A935EB6BE21FC9203 (void);
// 0x00000459 System.Void UnityEngine.Rendering.DebugUI/BitField::set_enumType(System.Type)
extern void BitField_set_enumType_mB03F8F62663EF345AAF5474BC3ED67B2A96F8FA1 (void);
// 0x0000045A System.Void UnityEngine.Rendering.DebugUI/BitField::.ctor()
extern void BitField__ctor_m4A3D57F9714E4EF7E2DDE0F8342BD582AA2F304D (void);
// 0x0000045B UnityEngine.Color UnityEngine.Rendering.DebugUI/ColorField::ValidateValue(UnityEngine.Color)
extern void ColorField_ValidateValue_m8D28E0AF4B13D4A656B208C23863E6E790EC073B (void);
// 0x0000045C System.Void UnityEngine.Rendering.DebugUI/ColorField::.ctor()
extern void ColorField__ctor_m65991BD71EF773F511DF30AFB0E49D31C7B8C639 (void);
// 0x0000045D System.Void UnityEngine.Rendering.DebugUI/Vector2Field::.ctor()
extern void Vector2Field__ctor_m1AF0C3B9D667CB0D78B5D5F46B721463B7890DF8 (void);
// 0x0000045E System.Void UnityEngine.Rendering.DebugUI/Vector3Field::.ctor()
extern void Vector3Field__ctor_mFB24C3F634E08686F2ABD472FC6125669ECC9F44 (void);
// 0x0000045F System.Void UnityEngine.Rendering.DebugUI/Vector4Field::.ctor()
extern void Vector4Field__ctor_m2BA663599F835828AC451E2D7E3847861FD70BF5 (void);
// 0x00000460 System.Void UnityEngine.Rendering.DebugUI/MessageBox::.ctor()
extern void MessageBox__ctor_mF48843A6B29FCC39637EF3421D0C8789A2E40D52 (void);
// 0x00000461 UnityEngine.Rendering.DebugUI/Flags UnityEngine.Rendering.DebugUI/Panel::get_flags()
extern void Panel_get_flags_mBC1AB348B149288BC1ACD0D4E7162622829ECE05 (void);
// 0x00000462 System.Void UnityEngine.Rendering.DebugUI/Panel::set_flags(UnityEngine.Rendering.DebugUI/Flags)
extern void Panel_set_flags_mF3DF84780500411054DCFA0D04A9D25BEE99BEB7 (void);
// 0x00000463 System.String UnityEngine.Rendering.DebugUI/Panel::get_displayName()
extern void Panel_get_displayName_m186C10E927B2800035B328BD9A40D8B5FB3D4EE4 (void);
// 0x00000464 System.Void UnityEngine.Rendering.DebugUI/Panel::set_displayName(System.String)
extern void Panel_set_displayName_mE0DE5D17782E9980165F39D8CEC37169D3A8F0B7 (void);
// 0x00000465 System.Int32 UnityEngine.Rendering.DebugUI/Panel::get_groupIndex()
extern void Panel_get_groupIndex_m9BF4D7734CF4BDAB37EA115B037D349AC1883766 (void);
// 0x00000466 System.Void UnityEngine.Rendering.DebugUI/Panel::set_groupIndex(System.Int32)
extern void Panel_set_groupIndex_mFE863A99C9A0E2168E3E24171BBDFB7541E4E64C (void);
// 0x00000467 System.String UnityEngine.Rendering.DebugUI/Panel::get_queryPath()
extern void Panel_get_queryPath_mF5E2D5B66591223DC7A17817CB8A881396066B4A (void);
// 0x00000468 System.Boolean UnityEngine.Rendering.DebugUI/Panel::get_isEditorOnly()
extern void Panel_get_isEditorOnly_m739F502972100D4683F8ED121870319543957E41 (void);
// 0x00000469 System.Boolean UnityEngine.Rendering.DebugUI/Panel::get_isRuntimeOnly()
extern void Panel_get_isRuntimeOnly_m03FC70341EBC84633B6F0F93BFCC961A3470AAEE (void);
// 0x0000046A System.Boolean UnityEngine.Rendering.DebugUI/Panel::get_isInactiveInEditor()
extern void Panel_get_isInactiveInEditor_m085DE5769EBB5B7F1B283FEF611E277ADDDBA506 (void);
// 0x0000046B System.Boolean UnityEngine.Rendering.DebugUI/Panel::get_editorForceUpdate()
extern void Panel_get_editorForceUpdate_mDC9A26D9317C1DAD42A7A3F7034C0188A29E74B1 (void);
// 0x0000046C UnityEngine.Rendering.ObservableList`1<UnityEngine.Rendering.DebugUI/Widget> UnityEngine.Rendering.DebugUI/Panel::get_children()
extern void Panel_get_children_m42233087374A0F3438E9F666F0EBD00922D3018A (void);
// 0x0000046D System.Void UnityEngine.Rendering.DebugUI/Panel::set_children(UnityEngine.Rendering.ObservableList`1<UnityEngine.Rendering.DebugUI/Widget>)
extern void Panel_set_children_mADB01D395A7BFE1B9D5AC10A0D7B602D9EB7F478 (void);
// 0x0000046E System.Void UnityEngine.Rendering.DebugUI/Panel::add_onSetDirty(System.Action`1<UnityEngine.Rendering.DebugUI/Panel>)
extern void Panel_add_onSetDirty_mF68B8AC37258A177F270E8FC7D9B63785E92E711 (void);
// 0x0000046F System.Void UnityEngine.Rendering.DebugUI/Panel::remove_onSetDirty(System.Action`1<UnityEngine.Rendering.DebugUI/Panel>)
extern void Panel_remove_onSetDirty_mDA42D481B964BFBEB6CAC9856AC23E1629F1E02D (void);
// 0x00000470 System.Void UnityEngine.Rendering.DebugUI/Panel::.ctor()
extern void Panel__ctor_m1FC7CE20C8B2968C68E3EE1CFD0410871B3F5F38 (void);
// 0x00000471 System.Void UnityEngine.Rendering.DebugUI/Panel::OnItemAdded(UnityEngine.Rendering.ObservableList`1<UnityEngine.Rendering.DebugUI/Widget>,UnityEngine.Rendering.ListChangedEventArgs`1<UnityEngine.Rendering.DebugUI/Widget>)
extern void Panel_OnItemAdded_m7FB987D85562DF868A6FA6087CB22E6C71243F46 (void);
// 0x00000472 System.Void UnityEngine.Rendering.DebugUI/Panel::OnItemRemoved(UnityEngine.Rendering.ObservableList`1<UnityEngine.Rendering.DebugUI/Widget>,UnityEngine.Rendering.ListChangedEventArgs`1<UnityEngine.Rendering.DebugUI/Widget>)
extern void Panel_OnItemRemoved_m8CD7D1887101C65B50C3117C24FCDF315B7EAFBB (void);
// 0x00000473 System.Void UnityEngine.Rendering.DebugUI/Panel::SetDirty()
extern void Panel_SetDirty_mEC30ADB4136D2F16BAF184FC412796F28B55AC4D (void);
// 0x00000474 System.Int32 UnityEngine.Rendering.DebugUI/Panel::GetHashCode()
extern void Panel_GetHashCode_m5800B9C2C3CB4EE3347ADAB98CEB0B1C83F1E4B5 (void);
// 0x00000475 System.Int32 UnityEngine.Rendering.DebugUI/Panel::System.IComparable<UnityEngine.Rendering.DebugUI.Panel>.CompareTo(UnityEngine.Rendering.DebugUI/Panel)
extern void Panel_System_IComparableU3CUnityEngine_Rendering_DebugUI_PanelU3E_CompareTo_mF038DBAAA67D742B672B5D64E465E2AB619E0864 (void);
// 0x00000476 System.Void UnityEngine.Rendering.DebugUI/Panel/<>c::.cctor()
extern void U3CU3Ec__cctor_m505AF6CFBC7CF4B5249F542C508D1C3771B773EF (void);
// 0x00000477 System.Void UnityEngine.Rendering.DebugUI/Panel/<>c::.ctor()
extern void U3CU3Ec__ctor_mCF8306DAA9B0EB15D331C4D709E0CCCE53B0A88B (void);
// 0x00000478 System.Void UnityEngine.Rendering.DebugUI/Panel/<>c::<.ctor>b__29_0(UnityEngine.Rendering.DebugUI/Panel)
extern void U3CU3Ec_U3C_ctorU3Eb__29_0_m2235200D857D434405F0663E3A1C60D70B41AA12 (void);
// 0x00000479 System.Void UnityEngine.Rendering.DebugUpdater::RuntimeInit()
extern void DebugUpdater_RuntimeInit_mE9ECE0BF0EC053B08D98E0A81AAD2C0440903FEB (void);
// 0x0000047A System.Void UnityEngine.Rendering.DebugUpdater::SetEnabled(System.Boolean)
extern void DebugUpdater_SetEnabled_m22CFD48B212C8976E10FF2DDB0659634F12EC9B0 (void);
// 0x0000047B System.Void UnityEngine.Rendering.DebugUpdater::EnableRuntime()
extern void DebugUpdater_EnableRuntime_mD9C5BEB12354DE0B41E9F8783A8A71C351CA1B93 (void);
// 0x0000047C System.Void UnityEngine.Rendering.DebugUpdater::DisableRuntime()
extern void DebugUpdater_DisableRuntime_m63D549D0863E9A75230105107DF925E5DE3DEA23 (void);
// 0x0000047D System.Void UnityEngine.Rendering.DebugUpdater::HandleInternalEventSystemComponents(System.Boolean)
extern void DebugUpdater_HandleInternalEventSystemComponents_mF661FED6AFDD911D6B831E22B65CD951E8BC4857 (void);
// 0x0000047E System.Void UnityEngine.Rendering.DebugUpdater::EnsureExactlyOneEventSystem()
extern void DebugUpdater_EnsureExactlyOneEventSystem_m5C71D947DFE706B67482E788A3DABD428F7798E1 (void);
// 0x0000047F System.Collections.IEnumerator UnityEngine.Rendering.DebugUpdater::DoAfterInputModuleUpdated(System.Action)
extern void DebugUpdater_DoAfterInputModuleUpdated_mF2ED242089E69D65CAC0B9C7A49061C8928A613D (void);
// 0x00000480 System.Void UnityEngine.Rendering.DebugUpdater::CheckInputModuleExists()
extern void DebugUpdater_CheckInputModuleExists_m1AA5338341C5BB4AE1225AA027A71FE2C693AE93 (void);
// 0x00000481 System.Void UnityEngine.Rendering.DebugUpdater::AssignDefaultActions()
extern void DebugUpdater_AssignDefaultActions_m544E2B25C85619B9FA366E9C58581A31925ED19F (void);
// 0x00000482 System.Void UnityEngine.Rendering.DebugUpdater::CreateDebugEventSystem()
extern void DebugUpdater_CreateDebugEventSystem_mBB31CEA4B7EC553A825B4E9BA4CCD323CB51EDD1 (void);
// 0x00000483 System.Void UnityEngine.Rendering.DebugUpdater::DestroyDebugEventSystem()
extern void DebugUpdater_DestroyDebugEventSystem_m2FB857AD2F317E394C2B37DACBD5003676FD5E80 (void);
// 0x00000484 System.Void UnityEngine.Rendering.DebugUpdater::Update()
extern void DebugUpdater_Update_m4532D8430DE77C9C424562D87951EE357A2D7309 (void);
// 0x00000485 System.Collections.IEnumerator UnityEngine.Rendering.DebugUpdater::RefreshRuntimeUINextFrame()
extern void DebugUpdater_RefreshRuntimeUINextFrame_mFE1601C324C104C743877F1B2A85535CE60B6F97 (void);
// 0x00000486 System.Void UnityEngine.Rendering.DebugUpdater::.ctor()
extern void DebugUpdater__ctor_m4AFAADA0BCEA5FC94938222FCF2C69337E9AA201 (void);
// 0x00000487 System.Void UnityEngine.Rendering.DebugUpdater/<DoAfterInputModuleUpdated>d__9::.ctor(System.Int32)
extern void U3CDoAfterInputModuleUpdatedU3Ed__9__ctor_m9B3F93DFFEBFF104648742F9BF158132E45B1612 (void);
// 0x00000488 System.Void UnityEngine.Rendering.DebugUpdater/<DoAfterInputModuleUpdated>d__9::System.IDisposable.Dispose()
extern void U3CDoAfterInputModuleUpdatedU3Ed__9_System_IDisposable_Dispose_mF93A77F74A1C09D3CBCC8C28608778786B6E1ED3 (void);
// 0x00000489 System.Boolean UnityEngine.Rendering.DebugUpdater/<DoAfterInputModuleUpdated>d__9::MoveNext()
extern void U3CDoAfterInputModuleUpdatedU3Ed__9_MoveNext_m9537B7DEABD35246EF3E28B5106FB39C6AA6D9FB (void);
// 0x0000048A System.Object UnityEngine.Rendering.DebugUpdater/<DoAfterInputModuleUpdated>d__9::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CDoAfterInputModuleUpdatedU3Ed__9_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m3BAAAB9476FF83F7F100545FAEAB28C2F1D61A0D (void);
// 0x0000048B System.Void UnityEngine.Rendering.DebugUpdater/<DoAfterInputModuleUpdated>d__9::System.Collections.IEnumerator.Reset()
extern void U3CDoAfterInputModuleUpdatedU3Ed__9_System_Collections_IEnumerator_Reset_m29D4EFEB3935C7DB1709DC54313B4CDF38E5897D (void);
// 0x0000048C System.Object UnityEngine.Rendering.DebugUpdater/<DoAfterInputModuleUpdated>d__9::System.Collections.IEnumerator.get_Current()
extern void U3CDoAfterInputModuleUpdatedU3Ed__9_System_Collections_IEnumerator_get_Current_m1C1CB4846785E48662EA676E9CABEB9BCC0811D7 (void);
// 0x0000048D System.Void UnityEngine.Rendering.DebugUpdater/<RefreshRuntimeUINextFrame>d__15::.ctor(System.Int32)
extern void U3CRefreshRuntimeUINextFrameU3Ed__15__ctor_m392779311BA7871677A153BC788AE3F7C1E7D9DC (void);
// 0x0000048E System.Void UnityEngine.Rendering.DebugUpdater/<RefreshRuntimeUINextFrame>d__15::System.IDisposable.Dispose()
extern void U3CRefreshRuntimeUINextFrameU3Ed__15_System_IDisposable_Dispose_m9803ADFEEF942AC22E3361820FD2894B83A80E82 (void);
// 0x0000048F System.Boolean UnityEngine.Rendering.DebugUpdater/<RefreshRuntimeUINextFrame>d__15::MoveNext()
extern void U3CRefreshRuntimeUINextFrameU3Ed__15_MoveNext_mF9483E416C04EC5609F48B6161DB805C43945C22 (void);
// 0x00000490 System.Object UnityEngine.Rendering.DebugUpdater/<RefreshRuntimeUINextFrame>d__15::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CRefreshRuntimeUINextFrameU3Ed__15_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m05F5EAA27086EFF2214F25E8D4835C9597ECA1A6 (void);
// 0x00000491 System.Void UnityEngine.Rendering.DebugUpdater/<RefreshRuntimeUINextFrame>d__15::System.Collections.IEnumerator.Reset()
extern void U3CRefreshRuntimeUINextFrameU3Ed__15_System_Collections_IEnumerator_Reset_m3C7EBC0FA8D19456E8BF377495712E73FD485C72 (void);
// 0x00000492 System.Object UnityEngine.Rendering.DebugUpdater/<RefreshRuntimeUINextFrame>d__15::System.Collections.IEnumerator.get_Current()
extern void U3CRefreshRuntimeUINextFrameU3Ed__15_System_Collections_IEnumerator_get_Current_m22BFE8E553B29C84902F0D132AD6B09C37EE6D04 (void);
// 0x00000493 UnityEngine.Rendering.MousePositionDebug UnityEngine.Rendering.MousePositionDebug::get_instance()
extern void MousePositionDebug_get_instance_mE1A381321E1FE73292165B66BF148F06A077F714 (void);
// 0x00000494 System.Void UnityEngine.Rendering.MousePositionDebug::Build()
extern void MousePositionDebug_Build_m171C70914DA1EF2CE398B02A8BF4CA644B74CA56 (void);
// 0x00000495 System.Void UnityEngine.Rendering.MousePositionDebug::Cleanup()
extern void MousePositionDebug_Cleanup_mDE40091BD5CCE74B9207B53D3924CE29CB2A155E (void);
// 0x00000496 UnityEngine.Vector2 UnityEngine.Rendering.MousePositionDebug::GetMousePosition(System.Single,System.Boolean)
extern void MousePositionDebug_GetMousePosition_m705459C449B28534CD4F3826EB2802094E9ECE9C (void);
// 0x00000497 UnityEngine.Vector2 UnityEngine.Rendering.MousePositionDebug::GetInputMousePosition()
extern void MousePositionDebug_GetInputMousePosition_m3B9FAF39E8413360371CA6EFEED7B12A025F45B1 (void);
// 0x00000498 UnityEngine.Vector2 UnityEngine.Rendering.MousePositionDebug::GetMouseClickPosition(System.Single)
extern void MousePositionDebug_GetMouseClickPosition_m2C1BEF32DA9D79DA3DE85B0C433FC496F14D17AA (void);
// 0x00000499 System.Void UnityEngine.Rendering.MousePositionDebug::.ctor()
extern void MousePositionDebug__ctor_m13F1294D652C43F3F1EEC88EB42D66CC51C31DF7 (void);
// 0x0000049A System.Void UnityEngine.Rendering.TProfilingSampler`1::.cctor()
// 0x0000049B System.Void UnityEngine.Rendering.TProfilingSampler`1::.ctor(System.String)
// 0x0000049C UnityEngine.Rendering.ProfilingSampler UnityEngine.Rendering.ProfilingSampler::Get(TEnum)
// 0x0000049D System.Void UnityEngine.Rendering.ProfilingSampler::.ctor(System.String)
extern void ProfilingSampler__ctor_m26500989FCDB07FA33C9A3BB7F215CBD892F5BB7 (void);
// 0x0000049E System.Void UnityEngine.Rendering.ProfilingSampler::Begin(UnityEngine.Rendering.CommandBuffer)
extern void ProfilingSampler_Begin_m8DA3A616057A3BF9ACB1B0CA553273D5CAD9D19B (void);
// 0x0000049F System.Void UnityEngine.Rendering.ProfilingSampler::End(UnityEngine.Rendering.CommandBuffer)
extern void ProfilingSampler_End_mE6456852B82D64D57CDE20BBE06801295CEE5EAE (void);
// 0x000004A0 System.Boolean UnityEngine.Rendering.ProfilingSampler::IsValid()
extern void ProfilingSampler_IsValid_mD25EC5C484B753F1C433BACC5DDEECAF80A0EC16 (void);
// 0x000004A1 UnityEngine.Profiling.CustomSampler UnityEngine.Rendering.ProfilingSampler::get_sampler()
extern void ProfilingSampler_get_sampler_m4AAA7119F8B751DC79115DDEF85028FE9E9E8CC9 (void);
// 0x000004A2 System.Void UnityEngine.Rendering.ProfilingSampler::set_sampler(UnityEngine.Profiling.CustomSampler)
extern void ProfilingSampler_set_sampler_m4BD874D506A5D40A126E01CBE77F6CB1015DDE44 (void);
// 0x000004A3 UnityEngine.Profiling.CustomSampler UnityEngine.Rendering.ProfilingSampler::get_inlineSampler()
extern void ProfilingSampler_get_inlineSampler_mAD22E30685E56EA9768E9D0F6A0D451E32EE8A57 (void);
// 0x000004A4 System.Void UnityEngine.Rendering.ProfilingSampler::set_inlineSampler(UnityEngine.Profiling.CustomSampler)
extern void ProfilingSampler_set_inlineSampler_m4AC1C19296D4282D6BC4D6C09C641A1EB1145E16 (void);
// 0x000004A5 System.String UnityEngine.Rendering.ProfilingSampler::get_name()
extern void ProfilingSampler_get_name_mF1C3E7B9540171DD93186A4DFEF33CE331E92D79 (void);
// 0x000004A6 System.Void UnityEngine.Rendering.ProfilingSampler::set_name(System.String)
extern void ProfilingSampler_set_name_mAEA13BE687F2E8C6698F3FB3A95570A156705FA5 (void);
// 0x000004A7 System.Void UnityEngine.Rendering.ProfilingSampler::set_enableRecording(System.Boolean)
extern void ProfilingSampler_set_enableRecording_m01194E5D273026495629CE911861C31C5FB3A26E (void);
// 0x000004A8 System.Single UnityEngine.Rendering.ProfilingSampler::get_gpuElapsedTime()
extern void ProfilingSampler_get_gpuElapsedTime_mC131D418300561A18825784CEE89BAFB3DDE32C8 (void);
// 0x000004A9 System.Int32 UnityEngine.Rendering.ProfilingSampler::get_gpuSampleCount()
extern void ProfilingSampler_get_gpuSampleCount_m3EBB12146263C4956AB0E4FE1518537FFB3F1CB0 (void);
// 0x000004AA System.Single UnityEngine.Rendering.ProfilingSampler::get_cpuElapsedTime()
extern void ProfilingSampler_get_cpuElapsedTime_m9C3D1C60EED6B27CE71D2A7DB94D496C2F1B328D (void);
// 0x000004AB System.Int32 UnityEngine.Rendering.ProfilingSampler::get_cpuSampleCount()
extern void ProfilingSampler_get_cpuSampleCount_m9C8E94E3CC7AD93B8FD62EBC74E8581A493DA5F3 (void);
// 0x000004AC System.Single UnityEngine.Rendering.ProfilingSampler::get_inlineCpuElapsedTime()
extern void ProfilingSampler_get_inlineCpuElapsedTime_mB4D305E36C2A8EF55F9BFF30747885C10051738B (void);
// 0x000004AD System.Int32 UnityEngine.Rendering.ProfilingSampler::get_inlineCpuSampleCount()
extern void ProfilingSampler_get_inlineCpuSampleCount_m91CB819CD0B6576451BF2DE3749D58DB863D00A0 (void);
// 0x000004AE System.Void UnityEngine.Rendering.ProfilingSampler::.ctor()
extern void ProfilingSampler__ctor_m7CE99F43293A5072467EAC1BC37CF4C335D1C2B2 (void);
// 0x000004AF System.Void UnityEngine.Rendering.ProfilingScope::.ctor(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.ProfilingSampler)
extern void ProfilingScope__ctor_mE15813DF7651C1A3B6AFD6465AD4B973E8F1DBFC (void);
// 0x000004B0 System.Void UnityEngine.Rendering.ProfilingScope::Dispose()
extern void ProfilingScope_Dispose_m4231A2ACA1F8E345BB0078310A9F7601704C8BE4 (void);
// 0x000004B1 System.Void UnityEngine.Rendering.ProfilingSample::.ctor(UnityEngine.Rendering.CommandBuffer,System.String,UnityEngine.Profiling.CustomSampler)
extern void ProfilingSample__ctor_m1F041AA9D15F1B83BDA8B9BA973392D79106B5C1 (void);
// 0x000004B2 System.Void UnityEngine.Rendering.ProfilingSample::.ctor(UnityEngine.Rendering.CommandBuffer,System.String,System.Object)
extern void ProfilingSample__ctor_m281FEAFD2CCCF7A43BE856DAD483F4E46A72B7EA (void);
// 0x000004B3 System.Void UnityEngine.Rendering.ProfilingSample::.ctor(UnityEngine.Rendering.CommandBuffer,System.String,System.Object[])
extern void ProfilingSample__ctor_m50B1BED1079C106B8AE90117F4E866912C3C4E08 (void);
// 0x000004B4 System.Void UnityEngine.Rendering.ProfilingSample::Dispose()
extern void ProfilingSample_Dispose_mD2A4D24A23C63449743B485DEAE2DE4EE240AA40 (void);
// 0x000004B5 System.Void UnityEngine.Rendering.ProfilingSample::Dispose(System.Boolean)
extern void ProfilingSample_Dispose_m59C08E493C70FAD0777836566F3FCF8A2889E388 (void);
// 0x000004B6 System.Void UnityEngine.Rendering.CoreRPHelpURLAttribute::.ctor(System.String,System.String)
extern void CoreRPHelpURLAttribute__ctor_m91B7762A727A0FDC2F10AB2EC6F0225A7A864ED1 (void);
// 0x000004B7 System.String UnityEngine.Rendering.DocumentationInfo::get_version()
extern void DocumentationInfo_get_version_m970EBEC012AB14B795AD5960A51D59B4B0FEF512 (void);
// 0x000004B8 System.String UnityEngine.Rendering.DocumentationInfo::GetPageLink(System.String,System.String)
extern void DocumentationInfo_GetPageLink_mF1CA29477559EA4935033E1323CC89A076175542 (void);
// 0x000004B9 System.Void UnityEngine.Rendering.DocumentationInfo::.ctor()
extern void DocumentationInfo__ctor_mC0375CEF54C6DF14F9288C2AAAC03FAAF3D98479 (void);
// 0x000004BA System.String UnityEngine.Rendering.DocumentationUtils::GetHelpURL(TEnum)
// 0x000004BB UnityEngine.Rendering.SphericalHarmonicsL1 UnityEngine.Rendering.SphericalHarmonicsL1::op_Addition(UnityEngine.Rendering.SphericalHarmonicsL1,UnityEngine.Rendering.SphericalHarmonicsL1)
extern void SphericalHarmonicsL1_op_Addition_m5F486BF8573D468A1DEDEF671F3895ACFE0C596F (void);
// 0x000004BC UnityEngine.Rendering.SphericalHarmonicsL1 UnityEngine.Rendering.SphericalHarmonicsL1::op_Subtraction(UnityEngine.Rendering.SphericalHarmonicsL1,UnityEngine.Rendering.SphericalHarmonicsL1)
extern void SphericalHarmonicsL1_op_Subtraction_m7ADE2737A8BB55042ADCFC9E55EDA00B75CCD465 (void);
// 0x000004BD UnityEngine.Rendering.SphericalHarmonicsL1 UnityEngine.Rendering.SphericalHarmonicsL1::op_Multiply(UnityEngine.Rendering.SphericalHarmonicsL1,System.Single)
extern void SphericalHarmonicsL1_op_Multiply_m50C506E2EF86ADB3B7F47C7ADAE02E59754C2733 (void);
// 0x000004BE UnityEngine.Rendering.SphericalHarmonicsL1 UnityEngine.Rendering.SphericalHarmonicsL1::op_Division(UnityEngine.Rendering.SphericalHarmonicsL1,System.Single)
extern void SphericalHarmonicsL1_op_Division_m5EE01F366EC68943C0B07A8FE686DD7E103B0FD0 (void);
// 0x000004BF System.Boolean UnityEngine.Rendering.SphericalHarmonicsL1::op_Equality(UnityEngine.Rendering.SphericalHarmonicsL1,UnityEngine.Rendering.SphericalHarmonicsL1)
extern void SphericalHarmonicsL1_op_Equality_mACA5CAF29BEDC46B2E445F4499DE00D9743D3245 (void);
// 0x000004C0 System.Boolean UnityEngine.Rendering.SphericalHarmonicsL1::op_Inequality(UnityEngine.Rendering.SphericalHarmonicsL1,UnityEngine.Rendering.SphericalHarmonicsL1)
extern void SphericalHarmonicsL1_op_Inequality_m96D5AF57F6F2B80C53F6B314341CCB7F919C6DF9 (void);
// 0x000004C1 System.Boolean UnityEngine.Rendering.SphericalHarmonicsL1::Equals(System.Object)
extern void SphericalHarmonicsL1_Equals_m156AFF698A92A9425070CFD50F115A1EE6E9CC92 (void);
// 0x000004C2 System.Int32 UnityEngine.Rendering.SphericalHarmonicsL1::GetHashCode()
extern void SphericalHarmonicsL1_GetHashCode_mF419FC901C4CF663FCC3E728A7E7BFC7F9DBB5FA (void);
// 0x000004C3 System.Void UnityEngine.Rendering.SphericalHarmonicsL1::.cctor()
extern void SphericalHarmonicsL1__cctor_m0D79C7945F00392859C7A8184A62AC603985A823 (void);
// 0x000004C4 System.Void UnityEngine.Rendering.SphericalHarmonicsL2Utils::GetL1(UnityEngine.Rendering.SphericalHarmonicsL2,UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void SphericalHarmonicsL2Utils_GetL1_m996A93044CB40B805DA29C46203E849F2415CE57 (void);
// 0x000004C5 System.Void UnityEngine.Rendering.SphericalHarmonicsL2Utils::GetL2(UnityEngine.Rendering.SphericalHarmonicsL2,UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void SphericalHarmonicsL2Utils_GetL2_m3F022EAA5269D2DDA53C8F6975972B945FD209A5 (void);
// 0x000004C6 System.Void UnityEngine.Rendering.SphericalHarmonicsL2Utils::SetL0(UnityEngine.Rendering.SphericalHarmonicsL2&,UnityEngine.Vector3)
extern void SphericalHarmonicsL2Utils_SetL0_m11A2C58FB9BF1A7A2DAB6BCB5CE756D555591DFE (void);
// 0x000004C7 System.Void UnityEngine.Rendering.SphericalHarmonicsL2Utils::SetL1R(UnityEngine.Rendering.SphericalHarmonicsL2&,UnityEngine.Vector3)
extern void SphericalHarmonicsL2Utils_SetL1R_mD1DA154FE693258849DCB4162A09FC13B62745A2 (void);
// 0x000004C8 System.Void UnityEngine.Rendering.SphericalHarmonicsL2Utils::SetL1G(UnityEngine.Rendering.SphericalHarmonicsL2&,UnityEngine.Vector3)
extern void SphericalHarmonicsL2Utils_SetL1G_m9480BF709817944C26A64EC7FB38E63E82FBEA5F (void);
// 0x000004C9 System.Void UnityEngine.Rendering.SphericalHarmonicsL2Utils::SetL1B(UnityEngine.Rendering.SphericalHarmonicsL2&,UnityEngine.Vector3)
extern void SphericalHarmonicsL2Utils_SetL1B_m24C03DBE20D4E95161AB03D2C4F8CEBF43953A7F (void);
// 0x000004CA System.Void UnityEngine.Rendering.SphericalHarmonicsL2Utils::SetL1(UnityEngine.Rendering.SphericalHarmonicsL2&,UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Vector3)
extern void SphericalHarmonicsL2Utils_SetL1_mCD888269417194982CC42CA10501A814DB9F7149 (void);
// 0x000004CB System.Void UnityEngine.Rendering.SphericalHarmonicsL2Utils::SetCoefficient(UnityEngine.Rendering.SphericalHarmonicsL2&,System.Int32,UnityEngine.Vector3)
extern void SphericalHarmonicsL2Utils_SetCoefficient_m73011A91C2FA8DA04A45BD0643A04C569BCA10A9 (void);
// 0x000004CC UnityEngine.Vector3 UnityEngine.Rendering.SphericalHarmonicsL2Utils::GetCoefficient(UnityEngine.Rendering.SphericalHarmonicsL2,System.Int32)
extern void SphericalHarmonicsL2Utils_GetCoefficient_m5B60C04680078BB5E0469EBFD8563C1B7FBD1DD9 (void);
// 0x000004CD System.Void UnityEngine.Rendering.SphericalHarmonicsL2Utils::.ctor()
extern void SphericalHarmonicsL2Utils__ctor_mCA9870FBB489F77FBE19972A417C82C6667FFA15 (void);
// 0x000004CE System.Void UnityEngine.Rendering.LensFlareCommonSRP::.ctor()
extern void LensFlareCommonSRP__ctor_mEAF401FE46DBA464540579E301B041E379D61B22 (void);
// 0x000004CF System.Void UnityEngine.Rendering.LensFlareCommonSRP::Initialize()
extern void LensFlareCommonSRP_Initialize_m2C0C7F50EC74E06BA4747A0C633B4EDA43567358 (void);
// 0x000004D0 System.Void UnityEngine.Rendering.LensFlareCommonSRP::Dispose()
extern void LensFlareCommonSRP_Dispose_mA062D9CB882801065E15BAB85A2B8F4C7884867B (void);
// 0x000004D1 UnityEngine.Rendering.LensFlareCommonSRP UnityEngine.Rendering.LensFlareCommonSRP::get_Instance()
extern void LensFlareCommonSRP_get_Instance_m9AF4EBE53C341469863DC601A5E7A9AE9C231189 (void);
// 0x000004D2 System.Collections.Generic.List`1<UnityEngine.Rendering.LensFlareComponentSRP> UnityEngine.Rendering.LensFlareCommonSRP::get_Data()
extern void LensFlareCommonSRP_get_Data_m8F84F362041F41CF248027CFA39F4E9DFB3EAC06 (void);
// 0x000004D3 System.Collections.Generic.List`1<UnityEngine.Rendering.LensFlareComponentSRP> UnityEngine.Rendering.LensFlareCommonSRP::GetData()
extern void LensFlareCommonSRP_GetData_m26A28FEF8B7E0EE038B730DAB917BC9DE1D1D558 (void);
// 0x000004D4 System.Boolean UnityEngine.Rendering.LensFlareCommonSRP::IsEmpty()
extern void LensFlareCommonSRP_IsEmpty_m10C9D536E29439EA829486AA85748609DD7106E0 (void);
// 0x000004D5 System.Void UnityEngine.Rendering.LensFlareCommonSRP::AddData(UnityEngine.Rendering.LensFlareComponentSRP)
extern void LensFlareCommonSRP_AddData_m1E33BD73205092DB2D140BAAC48383303BCBCA72 (void);
// 0x000004D6 System.Single UnityEngine.Rendering.LensFlareCommonSRP::ShapeAttenuationPointLight()
extern void LensFlareCommonSRP_ShapeAttenuationPointLight_mA80238D6D566E980ED1AE255C9BC91022182D2DE (void);
// 0x000004D7 System.Single UnityEngine.Rendering.LensFlareCommonSRP::ShapeAttenuationDirLight(UnityEngine.Vector3,UnityEngine.Vector3)
extern void LensFlareCommonSRP_ShapeAttenuationDirLight_mB2D51F3B3CC80632ECC96578C1ADB468E2B9E621 (void);
// 0x000004D8 System.Single UnityEngine.Rendering.LensFlareCommonSRP::ShapeAttenuationSpotConeLight(UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Single)
extern void LensFlareCommonSRP_ShapeAttenuationSpotConeLight_mDE84D26A73023F57D52694A3F8FB6E0B0FB8D138 (void);
// 0x000004D9 System.Single UnityEngine.Rendering.LensFlareCommonSRP::ShapeAttenuationSpotBoxLight(UnityEngine.Vector3,UnityEngine.Vector3)
extern void LensFlareCommonSRP_ShapeAttenuationSpotBoxLight_m0412849BF84760934EC681464147178B703E4ED6 (void);
// 0x000004DA System.Single UnityEngine.Rendering.LensFlareCommonSRP::ShapeAttenuationSpotPyramidLight(UnityEngine.Vector3,UnityEngine.Vector3)
extern void LensFlareCommonSRP_ShapeAttenuationSpotPyramidLight_m5B302D458B7A118CC682CCE543AA243F1FFBA890 (void);
// 0x000004DB System.Single UnityEngine.Rendering.LensFlareCommonSRP::ShapeAttenuationAreaTubeLight(UnityEngine.Vector3,UnityEngine.Vector3,System.Single,UnityEngine.Camera)
extern void LensFlareCommonSRP_ShapeAttenuationAreaTubeLight_mEC46B3A21A0115238359F9BEE31788358583AC1C (void);
// 0x000004DC System.Single UnityEngine.Rendering.LensFlareCommonSRP::ShapeAttenuationAreaRectangleLight(UnityEngine.Vector3,UnityEngine.Vector3)
extern void LensFlareCommonSRP_ShapeAttenuationAreaRectangleLight_mEE72D39B39610E683AD08EC8D6FAF5883E2A36AB (void);
// 0x000004DD System.Single UnityEngine.Rendering.LensFlareCommonSRP::ShapeAttenuationAreaDiscLight(UnityEngine.Vector3,UnityEngine.Vector3)
extern void LensFlareCommonSRP_ShapeAttenuationAreaDiscLight_mD1747903D295EA95BB061DDA50E6B633F53A5424 (void);
// 0x000004DE UnityEngine.Vector4 UnityEngine.Rendering.LensFlareCommonSRP::GetFlareData0(UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.Vector2,System.Single,System.Single,System.Single,UnityEngine.Vector2,System.Boolean)
extern void LensFlareCommonSRP_GetFlareData0_m3D5800DB9EAECD5F0A62A6C3A62221814D4982E9 (void);
// 0x000004DF UnityEngine.Vector2 UnityEngine.Rendering.LensFlareCommonSRP::GetLensFlareRayOffset(UnityEngine.Vector2,System.Single,System.Single,System.Single)
extern void LensFlareCommonSRP_GetLensFlareRayOffset_mA8F7249988B5FFE3D2C74C47E66B3862C3B466D6 (void);
// 0x000004E0 UnityEngine.Vector3 UnityEngine.Rendering.LensFlareCommonSRP::WorldToViewport(UnityEngine.Camera,System.Boolean,System.Boolean,UnityEngine.Matrix4x4,UnityEngine.Vector3)
extern void LensFlareCommonSRP_WorldToViewport_m1AA44B97222A147F54DCE7A95971BF40704487F3 (void);
// 0x000004E1 UnityEngine.Vector3 UnityEngine.Rendering.LensFlareCommonSRP::WorldToViewportLocal(System.Boolean,UnityEngine.Matrix4x4,UnityEngine.Vector3,UnityEngine.Vector3)
extern void LensFlareCommonSRP_WorldToViewportLocal_mF91FE2957795C2DB2593CF5AFF8768B421964232 (void);
// 0x000004E2 UnityEngine.Vector3 UnityEngine.Rendering.LensFlareCommonSRP::WorldToViewportDistance(UnityEngine.Camera,UnityEngine.Vector3)
extern void LensFlareCommonSRP_WorldToViewportDistance_m9B26177784C80BA0FB59511F7EE8736E15FB1C71 (void);
// 0x000004E3 System.Void UnityEngine.Rendering.LensFlareCommonSRP::ComputeOcclusion(UnityEngine.Material,UnityEngine.Rendering.LensFlareCommonSRP,UnityEngine.Camera,System.Single,System.Single,System.Boolean,System.Single,System.Single,System.Boolean,UnityEngine.Vector3,UnityEngine.Matrix4x4,UnityEngine.Rendering.CommandBuffer,System.Boolean,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32)
extern void LensFlareCommonSRP_ComputeOcclusion_m5FA6E2E6E5020732F0E5D61FD4E05557158FD7B9 (void);
// 0x000004E4 System.Void UnityEngine.Rendering.LensFlareCommonSRP::DoLensFlareDataDrivenCommon(UnityEngine.Material,UnityEngine.Rendering.LensFlareCommonSRP,UnityEngine.Camera,System.Single,System.Single,System.Boolean,System.Single,System.Single,System.Boolean,UnityEngine.Vector3,UnityEngine.Matrix4x4,UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,System.Func`4<UnityEngine.Light,UnityEngine.Camera,UnityEngine.Vector3,System.Single>,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32,System.Boolean)
extern void LensFlareCommonSRP_DoLensFlareDataDrivenCommon_m15611A3C8EC2005E50C2BD5807A996728E27A65E (void);
// 0x000004E5 System.Void UnityEngine.Rendering.LensFlareCommonSRP::RemoveData(UnityEngine.Rendering.LensFlareComponentSRP)
extern void LensFlareCommonSRP_RemoveData_mF536B8F2F609777F96539159F65750991FE6D8A0 (void);
// 0x000004E6 UnityEngine.Vector2 UnityEngine.Rendering.LensFlareCommonSRP::DoPaniniProjection(UnityEngine.Vector2,System.Single,System.Single,System.Single,System.Single,System.Single)
extern void LensFlareCommonSRP_DoPaniniProjection_m306992D05CE71F2D3F98143B474762546BF8525E (void);
// 0x000004E7 UnityEngine.Vector2 UnityEngine.Rendering.LensFlareCommonSRP::CalcViewExtents(System.Single,System.Single,System.Single)
extern void LensFlareCommonSRP_CalcViewExtents_m8F849C7464F2A4252DB86C3F3A33C524F66B50A6 (void);
// 0x000004E8 UnityEngine.Vector2 UnityEngine.Rendering.LensFlareCommonSRP::CalcCropExtents(System.Single,System.Single,System.Single,System.Single)
extern void LensFlareCommonSRP_CalcCropExtents_mFB9F1FC91183E81078841CBF760463D3889D3925 (void);
// 0x000004E9 UnityEngine.Vector2 UnityEngine.Rendering.LensFlareCommonSRP::Panini_Generic_Inv(UnityEngine.Vector2,System.Single)
extern void LensFlareCommonSRP_Panini_Generic_Inv_mECEC29B887B4DC66F5DCD50B45FD9A30DE20181F (void);
// 0x000004EA System.Void UnityEngine.Rendering.LensFlareCommonSRP::.cctor()
extern void LensFlareCommonSRP__cctor_m098DAAB846459CEED4F03FE6698FF475532BB9AD (void);
// 0x000004EB System.Single UnityEngine.Rendering.LensFlareCommonSRP::<ShapeAttenuationAreaTubeLight>g__Fpo|23_0(System.Single,System.Single)
extern void LensFlareCommonSRP_U3CShapeAttenuationAreaTubeLightU3Eg__FpoU7C23_0_m8A7A75AE0D73CAF8585BE2774094A6F2449A0088 (void);
// 0x000004EC System.Single UnityEngine.Rendering.LensFlareCommonSRP::<ShapeAttenuationAreaTubeLight>g__Fwt|23_1(System.Single,System.Single)
extern void LensFlareCommonSRP_U3CShapeAttenuationAreaTubeLightU3Eg__FwtU7C23_1_m789ACC5B16B32A7FA68CEA3B0ACB5DA482197197 (void);
// 0x000004ED System.Single UnityEngine.Rendering.LensFlareCommonSRP::<ShapeAttenuationAreaTubeLight>g__DiffLineIntegral|23_2(UnityEngine.Vector3,UnityEngine.Vector3)
extern void LensFlareCommonSRP_U3CShapeAttenuationAreaTubeLightU3Eg__DiffLineIntegralU7C23_2_mE0C2F76A88F491B61F98C5994240C874F54E9997 (void);
// 0x000004EE UnityEngine.Vector2 UnityEngine.Rendering.LensFlareCommonSRP::<DoLensFlareDataDrivenCommon>g__ComputeLocalSize|32_0(UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.AnimationCurve,UnityEngine.Rendering.LensFlareCommonSRP/<>c__DisplayClass32_0&,UnityEngine.Rendering.LensFlareCommonSRP/<>c__DisplayClass32_1&)
extern void LensFlareCommonSRP_U3CDoLensFlareDataDrivenCommonU3Eg__ComputeLocalSizeU7C32_0_m26D2BDCCD0FE073947287DBA271E48E8912CC909 (void);
// 0x000004EF System.Single UnityEngine.Rendering.LensFlareCommonSRP::<DoLensFlareDataDrivenCommon>g__RandomRange|32_1(System.Single,System.Single)
extern void LensFlareCommonSRP_U3CDoLensFlareDataDrivenCommonU3Eg__RandomRangeU7C32_1_m60A9634C5D096A623DB6D7508F6AB7EA9CCD302B (void);
// 0x000004F0 UnityEngine.Rendering.LensFlareDataSRP UnityEngine.Rendering.LensFlareComponentSRP::get_lensFlareData()
extern void LensFlareComponentSRP_get_lensFlareData_mD15D77ED234DE0AD076724C2F1D1826EE6D3D84A (void);
// 0x000004F1 System.Void UnityEngine.Rendering.LensFlareComponentSRP::set_lensFlareData(UnityEngine.Rendering.LensFlareDataSRP)
extern void LensFlareComponentSRP_set_lensFlareData_m2EA3F72CD785C3464763CC5C1214D104AA8C840E (void);
// 0x000004F2 System.Single UnityEngine.Rendering.LensFlareComponentSRP::celestialProjectedOcclusionRadius(UnityEngine.Camera)
extern void LensFlareComponentSRP_celestialProjectedOcclusionRadius_m1EAD56AEC83ED782CE84396FF60912005858C29B (void);
// 0x000004F3 System.Void UnityEngine.Rendering.LensFlareComponentSRP::OnEnable()
extern void LensFlareComponentSRP_OnEnable_m8840399D23CFE3D4C2FE087BAE4A9E58C2375BE9 (void);
// 0x000004F4 System.Void UnityEngine.Rendering.LensFlareComponentSRP::OnDisable()
extern void LensFlareComponentSRP_OnDisable_m3421F76197A6F10ED85B61016C4D9B659AF5B27D (void);
// 0x000004F5 System.Void UnityEngine.Rendering.LensFlareComponentSRP::OnValidate()
extern void LensFlareComponentSRP_OnValidate_mA7680090242F1F5D050BC08834871FB2A0E6D43E (void);
// 0x000004F6 System.Void UnityEngine.Rendering.LensFlareComponentSRP::.ctor()
extern void LensFlareComponentSRP__ctor_mAC637A807D761F7EA8739EE110836C95C8769C83 (void);
// 0x000004F7 System.Void UnityEngine.Rendering.LensFlareComponentSRP::.cctor()
extern void LensFlareComponentSRP__cctor_m1310FC4E69925FE59E0BA3E5CBD41482740073B5 (void);
// 0x000004F8 System.Void UnityEngine.Rendering.LensFlareDataElementSRP::.ctor()
extern void LensFlareDataElementSRP__ctor_mBAD9141DFEFB54D462184CC163B5EDE17D91E736 (void);
// 0x000004F9 System.Single UnityEngine.Rendering.LensFlareDataElementSRP::get_localIntensity()
extern void LensFlareDataElementSRP_get_localIntensity_mA75A27674D36D591A42CACEC76E206D41DFD9925 (void);
// 0x000004FA System.Void UnityEngine.Rendering.LensFlareDataElementSRP::set_localIntensity(System.Single)
extern void LensFlareDataElementSRP_set_localIntensity_mE3E298E1A798F39C5D79D37C6E012B63C10E5E71 (void);
// 0x000004FB System.Int32 UnityEngine.Rendering.LensFlareDataElementSRP::get_count()
extern void LensFlareDataElementSRP_get_count_mA7F9CBD150771F1D7B9CBF6896E8E5EF1AA72AA0 (void);
// 0x000004FC System.Void UnityEngine.Rendering.LensFlareDataElementSRP::set_count(System.Int32)
extern void LensFlareDataElementSRP_set_count_mC7D8BD5067BD13DBC60233CD7F659F8531D42A0C (void);
// 0x000004FD System.Single UnityEngine.Rendering.LensFlareDataElementSRP::get_intensityVariation()
extern void LensFlareDataElementSRP_get_intensityVariation_m698B70DFBB0B3F60AD954A228368C4E1CC92C90A (void);
// 0x000004FE System.Void UnityEngine.Rendering.LensFlareDataElementSRP::set_intensityVariation(System.Single)
extern void LensFlareDataElementSRP_set_intensityVariation_m4D80F38F0B0B5C65B21253D20FA6EACD9FC7D1B2 (void);
// 0x000004FF System.Single UnityEngine.Rendering.LensFlareDataElementSRP::get_fallOff()
extern void LensFlareDataElementSRP_get_fallOff_m15C09E622D6F8DC6CE7853C80A4B87E1B4541CAB (void);
// 0x00000500 System.Void UnityEngine.Rendering.LensFlareDataElementSRP::set_fallOff(System.Single)
extern void LensFlareDataElementSRP_set_fallOff_m7BB44EB218C09DAB803C404AB5138304F95BB474 (void);
// 0x00000501 System.Single UnityEngine.Rendering.LensFlareDataElementSRP::get_edgeOffset()
extern void LensFlareDataElementSRP_get_edgeOffset_m75804ACFA229921032474232E75DCD6E9D04DBC2 (void);
// 0x00000502 System.Void UnityEngine.Rendering.LensFlareDataElementSRP::set_edgeOffset(System.Single)
extern void LensFlareDataElementSRP_set_edgeOffset_mCC9746DA5549D79D48019976CE66DFCB3DC4D987 (void);
// 0x00000503 System.Int32 UnityEngine.Rendering.LensFlareDataElementSRP::get_sideCount()
extern void LensFlareDataElementSRP_get_sideCount_m7A462121BBCDD3AAA321F9E20680E2B7065787B2 (void);
// 0x00000504 System.Void UnityEngine.Rendering.LensFlareDataElementSRP::set_sideCount(System.Int32)
extern void LensFlareDataElementSRP_set_sideCount_m8B3FFCDDBE8EA14DA4887438D141A5F79361739B (void);
// 0x00000505 System.Single UnityEngine.Rendering.LensFlareDataElementSRP::get_sdfRoundness()
extern void LensFlareDataElementSRP_get_sdfRoundness_mADCDDD25BDE1929B411DE5244C7B1DCAB3503C6E (void);
// 0x00000506 System.Void UnityEngine.Rendering.LensFlareDataElementSRP::set_sdfRoundness(System.Single)
extern void LensFlareDataElementSRP_set_sdfRoundness_mACF3E40FBABFB46CFA587360F0D3961FBB794CDF (void);
// 0x00000507 System.Void UnityEngine.Rendering.LensFlareDataSRP::.ctor()
extern void LensFlareDataSRP__ctor_mD056E210281E4D1D2FCE4C9D6434983F5F9BFC4C (void);
// 0x00000508 System.String UnityEngine.Rendering.RenderPipelineResources::get_packagePath()
extern void RenderPipelineResources_get_packagePath_m5A693106B4748B9E81C3D5C97434A02214DB0C85 (void);
// 0x00000509 System.String UnityEngine.Rendering.RenderPipelineResources::get_packagePath_Internal()
extern void RenderPipelineResources_get_packagePath_Internal_m95E3708613D98333C168871F7C0FAD9446E66353 (void);
// 0x0000050A System.Void UnityEngine.Rendering.RenderPipelineResources::.ctor()
extern void RenderPipelineResources__ctor_mC03CFC933E25CDB1425A92A3C1C7770E02AD7040 (void);
// 0x0000050B System.Void UnityEngine.Rendering.GenerateHLSL::.ctor(UnityEngine.Rendering.PackingRules,System.Boolean,System.Boolean,System.Boolean,System.Int32,System.Boolean,System.Boolean,System.Boolean,System.Int32,System.String)
extern void GenerateHLSL__ctor_m2A39DDA94C13C40EF4CDD7C921E543F629C03F9C (void);
// 0x0000050C System.Void UnityEngine.Rendering.SurfaceDataAttributes::.ctor(System.String,System.Boolean,System.Boolean,UnityEngine.Rendering.FieldPrecision,System.Boolean,System.String)
extern void SurfaceDataAttributes__ctor_m81636716B07F8C34BCAD27685E93082567BD8783 (void);
// 0x0000050D System.Void UnityEngine.Rendering.SurfaceDataAttributes::.ctor(System.String[],System.Boolean,System.Boolean,UnityEngine.Rendering.FieldPrecision,System.Boolean,System.String)
extern void SurfaceDataAttributes__ctor_mE30568FE5BDB8713FDA54DE93AA8A044BE06705A (void);
// 0x0000050E System.Void UnityEngine.Rendering.HLSLArray::.ctor(System.Int32,System.Type)
extern void HLSLArray__ctor_m331EBC11A2168F124C98463BF17B936B53BDE55F (void);
// 0x0000050F System.Void UnityEngine.Rendering.PackingAttribute::.ctor(System.String[],UnityEngine.Rendering.FieldPacking,System.Int32,System.Int32,System.Single,System.Single,System.Boolean,System.Boolean,System.Boolean,System.String)
extern void PackingAttribute__ctor_mA147203C5536B59467723309207F1410900BE107 (void);
// 0x00000510 System.Void UnityEngine.Rendering.PackingAttribute::.ctor(System.String,UnityEngine.Rendering.FieldPacking,System.Int32,System.Int32,System.Single,System.Single,System.Boolean,System.Boolean,System.Boolean,System.String)
extern void PackingAttribute__ctor_mA2F647F8B256EE9087B498C9BFA015CDB023FA2A (void);
// 0x00000511 System.Int32 UnityEngine.Rendering.BufferedRTHandleSystem::get_maxWidth()
extern void BufferedRTHandleSystem_get_maxWidth_mFE6683CEA6FBCFE1C7A2C75F5C697500CDF2F491 (void);
// 0x00000512 System.Int32 UnityEngine.Rendering.BufferedRTHandleSystem::get_maxHeight()
extern void BufferedRTHandleSystem_get_maxHeight_m4D7141C2C2DDD8C719D9675AABAC387FC1267CED (void);
// 0x00000513 UnityEngine.Rendering.RTHandleProperties UnityEngine.Rendering.BufferedRTHandleSystem::get_rtHandleProperties()
extern void BufferedRTHandleSystem_get_rtHandleProperties_m25518D71F21AFDD266F9B72C4CC4FD372C31B503 (void);
// 0x00000514 UnityEngine.Rendering.RTHandle UnityEngine.Rendering.BufferedRTHandleSystem::GetFrameRT(System.Int32,System.Int32)
extern void BufferedRTHandleSystem_GetFrameRT_mEBD3C29BC51816416974BA1B541C668937F26BF6 (void);
// 0x00000515 System.Void UnityEngine.Rendering.BufferedRTHandleSystem::AllocBuffer(System.Int32,System.Func`3<UnityEngine.Rendering.RTHandleSystem,System.Int32,UnityEngine.Rendering.RTHandle>,System.Int32)
extern void BufferedRTHandleSystem_AllocBuffer_m8A3358B612C23D990A6EF1E7F2CCC10341EFF325 (void);
// 0x00000516 System.Void UnityEngine.Rendering.BufferedRTHandleSystem::ReleaseBuffer(System.Int32)
extern void BufferedRTHandleSystem_ReleaseBuffer_m34658D840B28AAB95C2E6A2DABFE4B0FA24BB39C (void);
// 0x00000517 System.Void UnityEngine.Rendering.BufferedRTHandleSystem::SwapAndSetReferenceSize(System.Int32,System.Int32)
extern void BufferedRTHandleSystem_SwapAndSetReferenceSize_m4305B697B3B3F39A12A784ED9413E29E53512727 (void);
// 0x00000518 System.Void UnityEngine.Rendering.BufferedRTHandleSystem::ResetReferenceSize(System.Int32,System.Int32)
extern void BufferedRTHandleSystem_ResetReferenceSize_mBAFD03AE10BFFD8DC36AD6F58F05A18EA6C6FCC2 (void);
// 0x00000519 System.Int32 UnityEngine.Rendering.BufferedRTHandleSystem::GetNumFramesAllocated(System.Int32)
extern void BufferedRTHandleSystem_GetNumFramesAllocated_m95809130420FD80593A4F447BE45D03911BCDDD2 (void);
// 0x0000051A UnityEngine.Vector2 UnityEngine.Rendering.BufferedRTHandleSystem::CalculateRatioAgainstMaxSize(System.Int32,System.Int32)
extern void BufferedRTHandleSystem_CalculateRatioAgainstMaxSize_m8769859F9AF74D5A880A3F487B1A3CC5B773F159 (void);
// 0x0000051B System.Void UnityEngine.Rendering.BufferedRTHandleSystem::Swap()
extern void BufferedRTHandleSystem_Swap_mFE273AD95CFEAA6D51A4B0BAE50C0E1FFFA05C0A (void);
// 0x0000051C System.Void UnityEngine.Rendering.BufferedRTHandleSystem::Dispose(System.Boolean)
extern void BufferedRTHandleSystem_Dispose_m6DFE7909B7A0C05BE90AF19310E7805B1AAC1759 (void);
// 0x0000051D System.Void UnityEngine.Rendering.BufferedRTHandleSystem::Dispose()
extern void BufferedRTHandleSystem_Dispose_m70E0C163A96627D5DB2AC28338B0FAF30E8EB877 (void);
// 0x0000051E System.Void UnityEngine.Rendering.BufferedRTHandleSystem::ReleaseAll()
extern void BufferedRTHandleSystem_ReleaseAll_m46A33E64928C17336C64D97305A2306BA9B8EFBC (void);
// 0x0000051F System.Void UnityEngine.Rendering.BufferedRTHandleSystem::.ctor()
extern void BufferedRTHandleSystem__ctor_m68CD894EC8EC25ED3B8556A48CE799C0802914DA (void);
// 0x00000520 System.Void UnityEngine.Rendering.PowerOfTwoTextureAtlas::.ctor(System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.FilterMode,System.String,System.Boolean)
extern void PowerOfTwoTextureAtlas__ctor_mA0B1F657FD0560F53AF17A6F29D6BBE9C8C1A5BB (void);
// 0x00000521 System.Int32 UnityEngine.Rendering.PowerOfTwoTextureAtlas::get_mipPadding()
extern void PowerOfTwoTextureAtlas_get_mipPadding_m5B9D6FB4248DD41F9AA9E5469C1A6CC12524496D (void);
// 0x00000522 System.Int32 UnityEngine.Rendering.PowerOfTwoTextureAtlas::GetTexturePadding()
extern void PowerOfTwoTextureAtlas_GetTexturePadding_m85D96D2F38E1B383B35E6161A577AB6B99C67166 (void);
// 0x00000523 UnityEngine.Vector4 UnityEngine.Rendering.PowerOfTwoTextureAtlas::GetPayloadScaleOffset(UnityEngine.Texture,UnityEngine.Vector4&)
extern void PowerOfTwoTextureAtlas_GetPayloadScaleOffset_m8B1202020D137DA5FF0966E5CA18D2C6B13338BA (void);
// 0x00000524 UnityEngine.Vector4 UnityEngine.Rendering.PowerOfTwoTextureAtlas::GetPayloadScaleOffset(UnityEngine.Vector2&,UnityEngine.Vector2&,UnityEngine.Vector4&)
extern void PowerOfTwoTextureAtlas_GetPayloadScaleOffset_m96EA6B589B297199A2F1A008B38AD6A4D5891AF6 (void);
// 0x00000525 System.Void UnityEngine.Rendering.PowerOfTwoTextureAtlas::Blit2DTexture(UnityEngine.Rendering.CommandBuffer,UnityEngine.Vector4,UnityEngine.Texture,UnityEngine.Vector4,System.Boolean,UnityEngine.Rendering.PowerOfTwoTextureAtlas/BlitType)
extern void PowerOfTwoTextureAtlas_Blit2DTexture_m318B160A16693053884CEBD03FE20510B285B86B (void);
// 0x00000526 System.Void UnityEngine.Rendering.PowerOfTwoTextureAtlas::BlitTexture(UnityEngine.Rendering.CommandBuffer,UnityEngine.Vector4,UnityEngine.Texture,UnityEngine.Vector4,System.Boolean,System.Int32)
extern void PowerOfTwoTextureAtlas_BlitTexture_m5D070F026EBC4EFEB0F7D432498746EA01A5BBF1 (void);
// 0x00000527 System.Void UnityEngine.Rendering.PowerOfTwoTextureAtlas::BlitTextureMultiply(UnityEngine.Rendering.CommandBuffer,UnityEngine.Vector4,UnityEngine.Texture,UnityEngine.Vector4,System.Boolean,System.Int32)
extern void PowerOfTwoTextureAtlas_BlitTextureMultiply_mE63DAA75351A7587B55F23FE473A33255C6D1119 (void);
// 0x00000528 System.Void UnityEngine.Rendering.PowerOfTwoTextureAtlas::BlitOctahedralTexture(UnityEngine.Rendering.CommandBuffer,UnityEngine.Vector4,UnityEngine.Texture,UnityEngine.Vector4,System.Boolean,System.Int32)
extern void PowerOfTwoTextureAtlas_BlitOctahedralTexture_m1A14B3C794CAB04AD3DB165F8746B69B36073265 (void);
// 0x00000529 System.Void UnityEngine.Rendering.PowerOfTwoTextureAtlas::BlitOctahedralTextureMultiply(UnityEngine.Rendering.CommandBuffer,UnityEngine.Vector4,UnityEngine.Texture,UnityEngine.Vector4,System.Boolean,System.Int32)
extern void PowerOfTwoTextureAtlas_BlitOctahedralTextureMultiply_m762414D0EC91F1779C3130DE072359A02CD867CB (void);
// 0x0000052A System.Void UnityEngine.Rendering.PowerOfTwoTextureAtlas::TextureSizeToPowerOfTwo(UnityEngine.Texture,System.Int32&,System.Int32&)
extern void PowerOfTwoTextureAtlas_TextureSizeToPowerOfTwo_m227399E874EE9189B6767F2BA8DC5B61DC6237B9 (void);
// 0x0000052B UnityEngine.Vector2 UnityEngine.Rendering.PowerOfTwoTextureAtlas::GetPowerOfTwoTextureSize(UnityEngine.Texture)
extern void PowerOfTwoTextureAtlas_GetPowerOfTwoTextureSize_m2569249A9DA0FD0259C3228186A909760F26DA6E (void);
// 0x0000052C System.Boolean UnityEngine.Rendering.PowerOfTwoTextureAtlas::AllocateTexture(UnityEngine.Rendering.CommandBuffer,UnityEngine.Vector4&,UnityEngine.Texture,System.Int32,System.Int32,System.Int32)
extern void PowerOfTwoTextureAtlas_AllocateTexture_m897D249DB1758DE2AF48415C7E5BA0686091A8FA (void);
// 0x0000052D System.Void UnityEngine.Rendering.PowerOfTwoTextureAtlas::ResetRequestedTexture()
extern void PowerOfTwoTextureAtlas_ResetRequestedTexture_mE1FE41E4A7EEFD4C850F748A9333433DD5F26C33 (void);
// 0x0000052E System.Boolean UnityEngine.Rendering.PowerOfTwoTextureAtlas::ReserveSpace(UnityEngine.Texture)
extern void PowerOfTwoTextureAtlas_ReserveSpace_m11DE443FB8C4046ACC8455546F8D17AAA4A3FFF8 (void);
// 0x0000052F System.Boolean UnityEngine.Rendering.PowerOfTwoTextureAtlas::ReserveSpace(UnityEngine.Texture,System.Int32,System.Int32)
extern void PowerOfTwoTextureAtlas_ReserveSpace_mF15C7D3DEA2B006D85379957930154BF99B04CB1 (void);
// 0x00000530 System.Boolean UnityEngine.Rendering.PowerOfTwoTextureAtlas::ReserveSpace(UnityEngine.Texture,UnityEngine.Texture,System.Int32,System.Int32)
extern void PowerOfTwoTextureAtlas_ReserveSpace_m5E24787C21582ED6A351622BBD4AE127DF4F7D4A (void);
// 0x00000531 System.Boolean UnityEngine.Rendering.PowerOfTwoTextureAtlas::ReserveSpace(System.Int32,System.Int32,System.Int32)
extern void PowerOfTwoTextureAtlas_ReserveSpace_m4D01D2D4735A62E00AADD01588B9415A51AF81F9 (void);
// 0x00000532 System.Boolean UnityEngine.Rendering.PowerOfTwoTextureAtlas::RelayoutEntries()
extern void PowerOfTwoTextureAtlas_RelayoutEntries_m18B76F49CB89789511930E82E1F1666E9CCFCD63 (void);
// 0x00000533 System.Int64 UnityEngine.Rendering.PowerOfTwoTextureAtlas::GetApproxCacheSizeInByte(System.Int32,System.Int32,System.Boolean,UnityEngine.Experimental.Rendering.GraphicsFormat)
extern void PowerOfTwoTextureAtlas_GetApproxCacheSizeInByte_m15BF98F2F213A3A0D8D52155F05802861A497692 (void);
// 0x00000534 System.Int32 UnityEngine.Rendering.PowerOfTwoTextureAtlas::GetMaxCacheSizeForWeightInByte(System.Int32,System.Boolean,UnityEngine.Experimental.Rendering.GraphicsFormat)
extern void PowerOfTwoTextureAtlas_GetMaxCacheSizeForWeightInByte_mFAF390882A513147A5C6CA70E173D23FE8239B4F (void);
// 0x00000535 System.Void UnityEngine.Rendering.PowerOfTwoTextureAtlas/<>c::.cctor()
extern void U3CU3Ec__cctor_mE3978E87892EA59FD00F94355B4308AE7053C33C (void);
// 0x00000536 System.Void UnityEngine.Rendering.PowerOfTwoTextureAtlas/<>c::.ctor()
extern void U3CU3Ec__ctor_m746D67A5F0BE4CBD77C47FAD733248ADA0C26151 (void);
// 0x00000537 System.Int32 UnityEngine.Rendering.PowerOfTwoTextureAtlas/<>c::<RelayoutEntries>b__23_0(System.ValueTuple`2<System.Int32,UnityEngine.Vector2Int>,System.ValueTuple`2<System.Int32,UnityEngine.Vector2Int>)
extern void U3CU3Ec_U3CRelayoutEntriesU3Eb__23_0_mBF9D0BC493979E1C4D66D031B8E12629A6AA208B (void);
// 0x00000538 System.Void UnityEngine.Rendering.RTHandle::SetCustomHandleProperties(UnityEngine.Rendering.RTHandleProperties&)
extern void RTHandle_SetCustomHandleProperties_m7C67C8BCEC388761EDA27F86053551E909633F60 (void);
// 0x00000539 System.Void UnityEngine.Rendering.RTHandle::ClearCustomHandleProperties()
extern void RTHandle_ClearCustomHandleProperties_m460228F7AA2778FBF2AB97234AEF056F74B7F8C6 (void);
// 0x0000053A UnityEngine.Vector2 UnityEngine.Rendering.RTHandle::get_scaleFactor()
extern void RTHandle_get_scaleFactor_mD00E924FBC4B2DC2C9E26D7B24444BDAA6DC5C65 (void);
// 0x0000053B System.Void UnityEngine.Rendering.RTHandle::set_scaleFactor(UnityEngine.Vector2)
extern void RTHandle_set_scaleFactor_m1F6FFA3366846EFFB9F4EAC79F2FF4E00BE75C15 (void);
// 0x0000053C System.Boolean UnityEngine.Rendering.RTHandle::get_useScaling()
extern void RTHandle_get_useScaling_mCDB079A62CC15C0D0F47E3F49D5975202F7B12A1 (void);
// 0x0000053D System.Void UnityEngine.Rendering.RTHandle::set_useScaling(System.Boolean)
extern void RTHandle_set_useScaling_m273446564E3B4FB3919F7C5FC01570029CF6A93A (void);
// 0x0000053E UnityEngine.Vector2Int UnityEngine.Rendering.RTHandle::get_referenceSize()
extern void RTHandle_get_referenceSize_mC92CF605112BBE2C0733AB1E4A9C42B760DCB34B (void);
// 0x0000053F System.Void UnityEngine.Rendering.RTHandle::set_referenceSize(UnityEngine.Vector2Int)
extern void RTHandle_set_referenceSize_mE98B5ED69CDC2C37769532B55D8ED2BA84C84466 (void);
// 0x00000540 UnityEngine.Rendering.RTHandleProperties UnityEngine.Rendering.RTHandle::get_rtHandleProperties()
extern void RTHandle_get_rtHandleProperties_mDD6241F72089E7DCED00F386D771140C9D9BB38D (void);
// 0x00000541 UnityEngine.RenderTexture UnityEngine.Rendering.RTHandle::get_rt()
extern void RTHandle_get_rt_m593F2799E2E6C97979D3B4CD9E992D305922BBE9 (void);
// 0x00000542 UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.RTHandle::get_nameID()
extern void RTHandle_get_nameID_m30AF2567853494DB845D83A8B37D0FB523DA76E9 (void);
// 0x00000543 System.String UnityEngine.Rendering.RTHandle::get_name()
extern void RTHandle_get_name_mF2E7B6B108477C76931BD1E5798BB1DA1F036B7A (void);
// 0x00000544 System.Boolean UnityEngine.Rendering.RTHandle::get_isMSAAEnabled()
extern void RTHandle_get_isMSAAEnabled_mB56F4775BF4FC50DFBAC344DB1DA4C4B91197A9D (void);
// 0x00000545 System.Void UnityEngine.Rendering.RTHandle::.ctor(UnityEngine.Rendering.RTHandleSystem)
extern void RTHandle__ctor_m4B1E60CEC17FB96DC08DE007B11042985DB8E33E (void);
// 0x00000546 UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.RTHandle::op_Implicit(UnityEngine.Rendering.RTHandle)
extern void RTHandle_op_Implicit_m7E42D3EE8A152420027F24913FAC50D9FECECE6A (void);
// 0x00000547 UnityEngine.Texture UnityEngine.Rendering.RTHandle::op_Implicit(UnityEngine.Rendering.RTHandle)
extern void RTHandle_op_Implicit_m4F275BDD5E7B189BAD0F9081A056D9433A8B583E (void);
// 0x00000548 UnityEngine.RenderTexture UnityEngine.Rendering.RTHandle::op_Implicit(UnityEngine.Rendering.RTHandle)
extern void RTHandle_op_Implicit_mCC1B19A781896CDB078D13C11EEE78B27522C0FD (void);
// 0x00000549 System.Void UnityEngine.Rendering.RTHandle::SetRenderTexture(UnityEngine.RenderTexture)
extern void RTHandle_SetRenderTexture_m8325131A37B623C614BE55AF2DE2A29856881F01 (void);
// 0x0000054A System.Void UnityEngine.Rendering.RTHandle::SetTexture(UnityEngine.Texture)
extern void RTHandle_SetTexture_m6F70C921091D39C7377853D6F5045720A6CE49DF (void);
// 0x0000054B System.Void UnityEngine.Rendering.RTHandle::SetTexture(UnityEngine.Rendering.RenderTargetIdentifier)
extern void RTHandle_SetTexture_m3C2728178516E7C86C52BF75EC7303CFDE68CDC6 (void);
// 0x0000054C System.Int32 UnityEngine.Rendering.RTHandle::GetInstanceID()
extern void RTHandle_GetInstanceID_m03B8397D7EADA4B68CDA99A76334A359D238F33F (void);
// 0x0000054D System.Void UnityEngine.Rendering.RTHandle::Release()
extern void RTHandle_Release_m743C2A22FD95D177D2D425E9DF1F3088161F387B (void);
// 0x0000054E UnityEngine.Vector2Int UnityEngine.Rendering.RTHandle::GetScaledSize(UnityEngine.Vector2Int)
extern void RTHandle_GetScaledSize_m58D71FF94244F1EE9BCB5690381DB37C79D3E239 (void);
// 0x0000054F UnityEngine.Vector2Int UnityEngine.Rendering.RTHandle::GetScaledSize()
extern void RTHandle_GetScaledSize_m35984A8A409FE26648E1B7011E9ADEEA9FEC739A (void);
// 0x00000550 System.Void UnityEngine.Rendering.RTHandle::SwitchToFastMemory(UnityEngine.Rendering.CommandBuffer,System.Single,UnityEngine.Rendering.FastMemoryFlags,System.Boolean)
extern void RTHandle_SwitchToFastMemory_m88468F9FF42F96F5192DFE57669B36724AD9C22D (void);
// 0x00000551 System.Void UnityEngine.Rendering.RTHandle::CopyToFastMemory(UnityEngine.Rendering.CommandBuffer,System.Single,UnityEngine.Rendering.FastMemoryFlags)
extern void RTHandle_CopyToFastMemory_mAA75EED26C2206B2D8AAF7AED837FD85801A494F (void);
// 0x00000552 System.Void UnityEngine.Rendering.RTHandle::SwitchOutFastMemory(UnityEngine.Rendering.CommandBuffer,System.Boolean)
extern void RTHandle_SwitchOutFastMemory_mA8413E99B8826F54BFD97AAAE2BAC75E2D69AFF9 (void);
// 0x00000553 System.Int32 UnityEngine.Rendering.RTHandles::get_maxWidth()
extern void RTHandles_get_maxWidth_m39BB3E11C325F26EEB144C8E24E5716C122ADCBB (void);
// 0x00000554 System.Int32 UnityEngine.Rendering.RTHandles::get_maxHeight()
extern void RTHandles_get_maxHeight_mC990063E8472D492D472969121285DEFE5A450B5 (void);
// 0x00000555 UnityEngine.Rendering.RTHandleProperties UnityEngine.Rendering.RTHandles::get_rtHandleProperties()
extern void RTHandles_get_rtHandleProperties_m8F0C48F9154BFFC0C777E6AF0A1DC9F3173763C1 (void);
// 0x00000556 UnityEngine.Rendering.RTHandle UnityEngine.Rendering.RTHandles::Alloc(System.Int32,System.Int32,System.Int32,UnityEngine.Rendering.DepthBits,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.FilterMode,UnityEngine.TextureWrapMode,UnityEngine.Rendering.TextureDimension,System.Boolean,System.Boolean,System.Boolean,System.Boolean,System.Int32,System.Single,UnityEngine.Rendering.MSAASamples,System.Boolean,System.Boolean,UnityEngine.RenderTextureMemoryless,System.String)
extern void RTHandles_Alloc_m95E0AEEEC5E86C190497A80E0471C65645D8C976 (void);
// 0x00000557 UnityEngine.Rendering.RTHandle UnityEngine.Rendering.RTHandles::Alloc(UnityEngine.Vector2,System.Int32,UnityEngine.Rendering.DepthBits,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.FilterMode,UnityEngine.TextureWrapMode,UnityEngine.Rendering.TextureDimension,System.Boolean,System.Boolean,System.Boolean,System.Boolean,System.Int32,System.Single,UnityEngine.Rendering.MSAASamples,System.Boolean,System.Boolean,UnityEngine.RenderTextureMemoryless,System.String)
extern void RTHandles_Alloc_m1F296572CCE89C51BFD3F944EAE0386E8527BB5B (void);
// 0x00000558 UnityEngine.Rendering.RTHandle UnityEngine.Rendering.RTHandles::Alloc(UnityEngine.Rendering.ScaleFunc,System.Int32,UnityEngine.Rendering.DepthBits,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.FilterMode,UnityEngine.TextureWrapMode,UnityEngine.Rendering.TextureDimension,System.Boolean,System.Boolean,System.Boolean,System.Boolean,System.Int32,System.Single,UnityEngine.Rendering.MSAASamples,System.Boolean,System.Boolean,UnityEngine.RenderTextureMemoryless,System.String)
extern void RTHandles_Alloc_m3C30230CC2A85D214A28EE01E558AFC41FB08643 (void);
// 0x00000559 UnityEngine.Rendering.RTHandle UnityEngine.Rendering.RTHandles::Alloc(UnityEngine.Texture)
extern void RTHandles_Alloc_m6C29C447A6F154094BCEDB69E1B874406414095B (void);
// 0x0000055A UnityEngine.Rendering.RTHandle UnityEngine.Rendering.RTHandles::Alloc(UnityEngine.RenderTexture)
extern void RTHandles_Alloc_mFBEA34A4FF2FCF73283FB525C5A38E808C337F33 (void);
// 0x0000055B UnityEngine.Rendering.RTHandle UnityEngine.Rendering.RTHandles::Alloc(UnityEngine.Rendering.RenderTargetIdentifier)
extern void RTHandles_Alloc_m98465B24502DA2755CBD4C633FE72328AE3025B0 (void);
// 0x0000055C UnityEngine.Rendering.RTHandle UnityEngine.Rendering.RTHandles::Alloc(UnityEngine.Rendering.RenderTargetIdentifier,System.String)
extern void RTHandles_Alloc_m2C487A65E4C1C2F343126C90A2895E5EC5E0179B (void);
// 0x0000055D UnityEngine.Rendering.RTHandle UnityEngine.Rendering.RTHandles::Alloc(UnityEngine.Rendering.RTHandle)
extern void RTHandles_Alloc_m5180F8A2883D67E6C5BFCBAA64D415D9F19B442C (void);
// 0x0000055E System.Void UnityEngine.Rendering.RTHandles::Initialize(System.Int32,System.Int32)
extern void RTHandles_Initialize_mA238921491B562B8CF8A74ED67795E547B9BFA60 (void);
// 0x0000055F System.Void UnityEngine.Rendering.RTHandles::Release(UnityEngine.Rendering.RTHandle)
extern void RTHandles_Release_m30F0805D0D28A1EA1C0A661E31E6A0F1B8D26EE4 (void);
// 0x00000560 System.Void UnityEngine.Rendering.RTHandles::SetHardwareDynamicResolutionState(System.Boolean)
extern void RTHandles_SetHardwareDynamicResolutionState_m6AE512F7F24DCFD4F60A19C68E64AD1E9CAD0D81 (void);
// 0x00000561 System.Void UnityEngine.Rendering.RTHandles::SetReferenceSize(System.Int32,System.Int32)
extern void RTHandles_SetReferenceSize_mC312D1638CE3D65FF7D9D6BFE64071DBB83E2C38 (void);
// 0x00000562 System.Void UnityEngine.Rendering.RTHandles::ResetReferenceSize(System.Int32,System.Int32)
extern void RTHandles_ResetReferenceSize_m2637E767B3417745720D24C1C2941F6489D511C0 (void);
// 0x00000563 UnityEngine.Vector2 UnityEngine.Rendering.RTHandles::CalculateRatioAgainstMaxSize(System.Int32,System.Int32)
extern void RTHandles_CalculateRatioAgainstMaxSize_m8515DA39B5F0E24B244B1AC06AD618AB2D60CA20 (void);
// 0x00000564 System.Void UnityEngine.Rendering.RTHandles::.cctor()
extern void RTHandles__cctor_m355F705EBF7266A5F234A28E505FDE729C74957A (void);
// 0x00000565 System.Void UnityEngine.Rendering.ScaleFunc::.ctor(System.Object,System.IntPtr)
extern void ScaleFunc__ctor_m7A304854DDD63F0FF414903BC5B30E201F8DA274 (void);
// 0x00000566 UnityEngine.Vector2Int UnityEngine.Rendering.ScaleFunc::Invoke(UnityEngine.Vector2Int)
extern void ScaleFunc_Invoke_mA7E3B86BA222C817FBBA757306E2FACB14F35987 (void);
// 0x00000567 System.IAsyncResult UnityEngine.Rendering.ScaleFunc::BeginInvoke(UnityEngine.Vector2Int,System.AsyncCallback,System.Object)
extern void ScaleFunc_BeginInvoke_mD82C5E2D4D54D3B9227F56CF6D5BA5D9CC2D1C77 (void);
// 0x00000568 UnityEngine.Vector2Int UnityEngine.Rendering.ScaleFunc::EndInvoke(System.IAsyncResult)
extern void ScaleFunc_EndInvoke_m9E82174B1877772B74231E226E707ACB37476409 (void);
// 0x00000569 UnityEngine.Rendering.RTHandleProperties UnityEngine.Rendering.RTHandleSystem::get_rtHandleProperties()
extern void RTHandleSystem_get_rtHandleProperties_mDDD04BAD83D0BCF0047AD77D88E37C55E64DEF58 (void);
// 0x0000056A System.Void UnityEngine.Rendering.RTHandleSystem::.ctor()
extern void RTHandleSystem__ctor_m22DE6145F3938E359C1FF6A5834BC7B7F93F5022 (void);
// 0x0000056B System.Void UnityEngine.Rendering.RTHandleSystem::Dispose()
extern void RTHandleSystem_Dispose_mB2E8DC8BB5B7BEAD2EF14CAAE4DB4F39ED27D6DC (void);
// 0x0000056C System.Void UnityEngine.Rendering.RTHandleSystem::Initialize(System.Int32,System.Int32)
extern void RTHandleSystem_Initialize_mA4B41213ACE5EABD7C8397780BFDCEA8847BE466 (void);
// 0x0000056D System.Void UnityEngine.Rendering.RTHandleSystem::Release(UnityEngine.Rendering.RTHandle)
extern void RTHandleSystem_Release_mBBF7B7611774D06D330FD609BBAAB3CF50B320EC (void);
// 0x0000056E System.Void UnityEngine.Rendering.RTHandleSystem::Remove(UnityEngine.Rendering.RTHandle)
extern void RTHandleSystem_Remove_m7172E9124FEFA41845AD5000EF50E2AD5F02F9AE (void);
// 0x0000056F System.Void UnityEngine.Rendering.RTHandleSystem::ResetReferenceSize(System.Int32,System.Int32)
extern void RTHandleSystem_ResetReferenceSize_m3D2804C653042B20B7D36E4D71BDCEABBAC25E51 (void);
// 0x00000570 System.Void UnityEngine.Rendering.RTHandleSystem::SetReferenceSize(System.Int32,System.Int32)
extern void RTHandleSystem_SetReferenceSize_m98A5DC18BAD37DA203641820D499F7B580DEA34C (void);
// 0x00000571 System.Void UnityEngine.Rendering.RTHandleSystem::SetReferenceSize(System.Int32,System.Int32,System.Boolean)
extern void RTHandleSystem_SetReferenceSize_m6C8D719235F158FC6AAF642165F8CE6DE1A727C4 (void);
// 0x00000572 UnityEngine.Vector2 UnityEngine.Rendering.RTHandleSystem::CalculateRatioAgainstMaxSize(UnityEngine.Vector2Int&)
extern void RTHandleSystem_CalculateRatioAgainstMaxSize_mB33735DE03F6CBCD0F3A95D966B9D41854591A31 (void);
// 0x00000573 System.Void UnityEngine.Rendering.RTHandleSystem::SetHardwareDynamicResolutionState(System.Boolean)
extern void RTHandleSystem_SetHardwareDynamicResolutionState_mC81924D30922025B3BBCF3EA0B30FC860CAAE803 (void);
// 0x00000574 System.Void UnityEngine.Rendering.RTHandleSystem::SwitchResizeMode(UnityEngine.Rendering.RTHandle,UnityEngine.Rendering.RTHandleSystem/ResizeMode)
extern void RTHandleSystem_SwitchResizeMode_mAF90A695546828FB285F35879E93C902702BB814 (void);
// 0x00000575 System.Void UnityEngine.Rendering.RTHandleSystem::DemandResize(UnityEngine.Rendering.RTHandle)
extern void RTHandleSystem_DemandResize_m8928BEA538900C426875E38F2D616BC06D62CCAD (void);
// 0x00000576 System.Int32 UnityEngine.Rendering.RTHandleSystem::GetMaxWidth()
extern void RTHandleSystem_GetMaxWidth_m0AE3E07285C0CAA906B0EBF879FDB5A916E43C43 (void);
// 0x00000577 System.Int32 UnityEngine.Rendering.RTHandleSystem::GetMaxHeight()
extern void RTHandleSystem_GetMaxHeight_mF753F115CBC21DF020B828C67164F203FB92AAE1 (void);
// 0x00000578 System.Void UnityEngine.Rendering.RTHandleSystem::Dispose(System.Boolean)
extern void RTHandleSystem_Dispose_m6B61D081716B87F79D110A62C3E57696179F3A31 (void);
// 0x00000579 System.Void UnityEngine.Rendering.RTHandleSystem::Resize(System.Int32,System.Int32,System.Boolean)
extern void RTHandleSystem_Resize_mDBCE61412B84ECAFC4FD2B29C8AE012D427DA968 (void);
// 0x0000057A UnityEngine.Rendering.RTHandle UnityEngine.Rendering.RTHandleSystem::Alloc(System.Int32,System.Int32,System.Int32,UnityEngine.Rendering.DepthBits,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.FilterMode,UnityEngine.TextureWrapMode,UnityEngine.Rendering.TextureDimension,System.Boolean,System.Boolean,System.Boolean,System.Boolean,System.Int32,System.Single,UnityEngine.Rendering.MSAASamples,System.Boolean,System.Boolean,UnityEngine.RenderTextureMemoryless,System.String)
extern void RTHandleSystem_Alloc_mC3E802DD2ADECF640BBBAF1511279735F34CAD28 (void);
// 0x0000057B UnityEngine.Rendering.RTHandle UnityEngine.Rendering.RTHandleSystem::Alloc(UnityEngine.Vector2,System.Int32,UnityEngine.Rendering.DepthBits,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.FilterMode,UnityEngine.TextureWrapMode,UnityEngine.Rendering.TextureDimension,System.Boolean,System.Boolean,System.Boolean,System.Boolean,System.Int32,System.Single,UnityEngine.Rendering.MSAASamples,System.Boolean,System.Boolean,UnityEngine.RenderTextureMemoryless,System.String)
extern void RTHandleSystem_Alloc_m930D047EFBB716887CAA28AB1CD8A427CF92E7C7 (void);
// 0x0000057C UnityEngine.Rendering.RTHandle UnityEngine.Rendering.RTHandleSystem::Alloc(UnityEngine.Rendering.ScaleFunc,System.Int32,UnityEngine.Rendering.DepthBits,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.FilterMode,UnityEngine.TextureWrapMode,UnityEngine.Rendering.TextureDimension,System.Boolean,System.Boolean,System.Boolean,System.Boolean,System.Int32,System.Single,UnityEngine.Rendering.MSAASamples,System.Boolean,System.Boolean,UnityEngine.RenderTextureMemoryless,System.String)
extern void RTHandleSystem_Alloc_m979E71B4FB5665A89BBF4E6316AF24311838944F (void);
// 0x0000057D UnityEngine.Rendering.RTHandle UnityEngine.Rendering.RTHandleSystem::AllocAutoSizedRenderTexture(System.Int32,System.Int32,System.Int32,UnityEngine.Rendering.DepthBits,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.FilterMode,UnityEngine.TextureWrapMode,UnityEngine.Rendering.TextureDimension,System.Boolean,System.Boolean,System.Boolean,System.Boolean,System.Int32,System.Single,UnityEngine.Rendering.MSAASamples,System.Boolean,System.Boolean,UnityEngine.RenderTextureMemoryless,System.String)
extern void RTHandleSystem_AllocAutoSizedRenderTexture_m1A1A2B79B291035C0403BB3B8D8E68B151C40C6B (void);
// 0x0000057E UnityEngine.Rendering.RTHandle UnityEngine.Rendering.RTHandleSystem::Alloc(UnityEngine.RenderTexture)
extern void RTHandleSystem_Alloc_m6220A7F43011B0D3277FFBED674A310002DAB3EC (void);
// 0x0000057F UnityEngine.Rendering.RTHandle UnityEngine.Rendering.RTHandleSystem::Alloc(UnityEngine.Texture)
extern void RTHandleSystem_Alloc_m8813228D1C9D34992E020DDD8956CDF9AF2A3665 (void);
// 0x00000580 UnityEngine.Rendering.RTHandle UnityEngine.Rendering.RTHandleSystem::Alloc(UnityEngine.Rendering.RenderTargetIdentifier)
extern void RTHandleSystem_Alloc_m86DF1C13114BD43774CC6108930D2BC1FABAD5BF (void);
// 0x00000581 UnityEngine.Rendering.RTHandle UnityEngine.Rendering.RTHandleSystem::Alloc(UnityEngine.Rendering.RenderTargetIdentifier,System.String)
extern void RTHandleSystem_Alloc_m9325CFF23333D599F8BD6BA274CB435CFC8A5D58 (void);
// 0x00000582 UnityEngine.Rendering.RTHandle UnityEngine.Rendering.RTHandleSystem::Alloc(UnityEngine.Rendering.RTHandle)
extern void RTHandleSystem_Alloc_mD9352D9C828335E70B063E1DE4CF57AFE8AEDBBE (void);
// 0x00000583 System.String UnityEngine.Rendering.RTHandleSystem::DumpRTInfo()
extern void RTHandleSystem_DumpRTInfo_m8F58815EE6F64F6782A27A76AB59CD756F862D31 (void);
// 0x00000584 System.Void UnityEngine.Rendering.AtlasAllocator::.ctor(System.Int32,System.Int32,System.Boolean)
extern void AtlasAllocator__ctor_m5F1B4A78BD5489FCC8100F2D0AC721CC42272BEB (void);
// 0x00000585 System.Boolean UnityEngine.Rendering.AtlasAllocator::Allocate(UnityEngine.Vector4&,System.Int32,System.Int32)
extern void AtlasAllocator_Allocate_m4CAB1873DB9D4E4CC5C0CF6581E0B4AEFCED19C6 (void);
// 0x00000586 System.Void UnityEngine.Rendering.AtlasAllocator::Reset()
extern void AtlasAllocator_Reset_mF10CD4D29A6CB93FAA43BDCA6680C87166E84989 (void);
// 0x00000587 UnityEngine.Rendering.AtlasAllocator/AtlasNode UnityEngine.Rendering.AtlasAllocator/AtlasNode::Allocate(UnityEngine.Rendering.ObjectPool`1<UnityEngine.Rendering.AtlasAllocator/AtlasNode>&,System.Int32,System.Int32,System.Boolean)
extern void AtlasNode_Allocate_m2BDA3A3172B54122AE5A862692103B7AEB5DA014 (void);
// 0x00000588 System.Void UnityEngine.Rendering.AtlasAllocator/AtlasNode::Release(UnityEngine.Rendering.ObjectPool`1<UnityEngine.Rendering.AtlasAllocator/AtlasNode>&)
extern void AtlasNode_Release_m6710C2233272E0EFEBD120970FA83453684D1BAA (void);
// 0x00000589 System.Void UnityEngine.Rendering.AtlasAllocator/AtlasNode::.ctor()
extern void AtlasNode__ctor_mB6D5CFB4511F82EBF3BB82CD666B0C2B3B2CC76B (void);
// 0x0000058A System.Void UnityEngine.Rendering.AtlasAllocator/<>c::.cctor()
extern void U3CU3Ec__cctor_mD58A602DF54D9A856FC000844D1F689E0B3273C0 (void);
// 0x0000058B System.Void UnityEngine.Rendering.AtlasAllocator/<>c::.ctor()
extern void U3CU3Ec__ctor_m6DFD93D6692A1B46CDBCC2CCD89F031D086AD221 (void);
// 0x0000058C System.Void UnityEngine.Rendering.AtlasAllocator/<>c::<.ctor>b__6_0(UnityEngine.Rendering.AtlasAllocator/AtlasNode)
extern void U3CU3Ec_U3C_ctorU3Eb__6_0_mEE6E87AE529F16564D6A203353BE0BF274FEED70 (void);
// 0x0000058D System.Void UnityEngine.Rendering.AtlasAllocator/<>c::<.ctor>b__6_1(UnityEngine.Rendering.AtlasAllocator/AtlasNode)
extern void U3CU3Ec_U3C_ctorU3Eb__6_1_mCB0411FC9901BAFC4F1272C563E40879E9881F45 (void);
// 0x0000058E System.Int32 UnityEngine.Rendering.Texture2DAtlas::get_maxMipLevelPadding()
extern void Texture2DAtlas_get_maxMipLevelPadding_m2F9C5CD50662D4374217BCB3571AB1BF919F761F (void);
// 0x0000058F UnityEngine.Rendering.RTHandle UnityEngine.Rendering.Texture2DAtlas::get_AtlasTexture()
extern void Texture2DAtlas_get_AtlasTexture_m7768401CB1687EDDACF3A103E476F2C217C69C8C (void);
// 0x00000590 System.Void UnityEngine.Rendering.Texture2DAtlas::.ctor(System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.FilterMode,System.Boolean,System.String,System.Boolean)
extern void Texture2DAtlas__ctor_mB0FB5774A1037C4F0AE42B5255C966B64688B54A (void);
// 0x00000591 System.Void UnityEngine.Rendering.Texture2DAtlas::Release()
extern void Texture2DAtlas_Release_mE23245C71F1E00D6AE6C57DC61B3CEE8D5C7CC17 (void);
// 0x00000592 System.Void UnityEngine.Rendering.Texture2DAtlas::ResetAllocator()
extern void Texture2DAtlas_ResetAllocator_m5930577CC814DC28121C8678204D3566783FCDE7 (void);
// 0x00000593 System.Void UnityEngine.Rendering.Texture2DAtlas::ClearTarget(UnityEngine.Rendering.CommandBuffer)
extern void Texture2DAtlas_ClearTarget_mDC234897D6E1A06F28E1A4DF6DE9E9FD98692BBA (void);
// 0x00000594 System.Int32 UnityEngine.Rendering.Texture2DAtlas::GetTextureMipmapCount(System.Int32,System.Int32)
extern void Texture2DAtlas_GetTextureMipmapCount_mD097894ECA68A2E85D291B9CF7A156FEA9C5B7BF (void);
// 0x00000595 System.Boolean UnityEngine.Rendering.Texture2DAtlas::Is2D(UnityEngine.Texture)
extern void Texture2DAtlas_Is2D_m0F89CF0AD3A0ED6A12C5036A922F97DBAF66B14F (void);
// 0x00000596 System.Boolean UnityEngine.Rendering.Texture2DAtlas::IsSingleChannelBlit(UnityEngine.Texture,UnityEngine.Texture)
extern void Texture2DAtlas_IsSingleChannelBlit_m36A444AD8A5BECBF02CC38EB8C67EF34025BBF3E (void);
// 0x00000597 System.Void UnityEngine.Rendering.Texture2DAtlas::Blit2DTexture(UnityEngine.Rendering.CommandBuffer,UnityEngine.Vector4,UnityEngine.Texture,UnityEngine.Vector4,System.Boolean,UnityEngine.Rendering.Texture2DAtlas/BlitType)
extern void Texture2DAtlas_Blit2DTexture_m70934965558F0FFAE19E97C84B527E94D044440B (void);
// 0x00000598 System.Void UnityEngine.Rendering.Texture2DAtlas::MarkGPUTextureValid(System.Int32,System.Boolean)
extern void Texture2DAtlas_MarkGPUTextureValid_mF402EAFB808A49DCAB232E44B400DA131481344A (void);
// 0x00000599 System.Void UnityEngine.Rendering.Texture2DAtlas::MarkGPUTextureInvalid(System.Int32)
extern void Texture2DAtlas_MarkGPUTextureInvalid_m8EBA5CAADA72E99FAED3D20C6C49A1D1360564ED (void);
// 0x0000059A System.Void UnityEngine.Rendering.Texture2DAtlas::BlitTexture(UnityEngine.Rendering.CommandBuffer,UnityEngine.Vector4,UnityEngine.Texture,UnityEngine.Vector4,System.Boolean,System.Int32)
extern void Texture2DAtlas_BlitTexture_mB5ABFBE98460A97AE9B4DB0DBDF8A6A440C06DB1 (void);
// 0x0000059B System.Void UnityEngine.Rendering.Texture2DAtlas::BlitOctahedralTexture(UnityEngine.Rendering.CommandBuffer,UnityEngine.Vector4,UnityEngine.Texture,UnityEngine.Vector4,System.Boolean,System.Int32)
extern void Texture2DAtlas_BlitOctahedralTexture_mF1369305082B2D023FF45176A64D4E2ECD7094CE (void);
// 0x0000059C System.Void UnityEngine.Rendering.Texture2DAtlas::BlitCubeTexture2D(UnityEngine.Rendering.CommandBuffer,UnityEngine.Vector4,UnityEngine.Texture,System.Boolean,System.Int32)
extern void Texture2DAtlas_BlitCubeTexture2D_m7314E241BE55A44A687A7DF69A838EB7830A0350 (void);
// 0x0000059D System.Boolean UnityEngine.Rendering.Texture2DAtlas::AllocateTexture(UnityEngine.Rendering.CommandBuffer,UnityEngine.Vector4&,UnityEngine.Texture,System.Int32,System.Int32,System.Int32)
extern void Texture2DAtlas_AllocateTexture_mF1FDB3F2BE25762FC61DEF882514E85D239649CA (void);
// 0x0000059E System.Boolean UnityEngine.Rendering.Texture2DAtlas::AllocateTextureWithoutBlit(UnityEngine.Texture,System.Int32,System.Int32,UnityEngine.Vector4&)
extern void Texture2DAtlas_AllocateTextureWithoutBlit_m6C78FBCE1123E73B2DC327E300A687BA2F38BFBA (void);
// 0x0000059F System.Boolean UnityEngine.Rendering.Texture2DAtlas::AllocateTextureWithoutBlit(System.Int32,System.Int32,System.Int32,UnityEngine.Vector4&)
extern void Texture2DAtlas_AllocateTextureWithoutBlit_m458E981155A8758EB9D669306D61A01C3A892910 (void);
// 0x000005A0 System.Int32 UnityEngine.Rendering.Texture2DAtlas::GetTextureHash(UnityEngine.Texture,UnityEngine.Texture)
extern void Texture2DAtlas_GetTextureHash_mF19A8BC40CD6B6681BBB3B5A3DA9FD113C708A1A (void);
// 0x000005A1 System.Int32 UnityEngine.Rendering.Texture2DAtlas::GetTextureID(UnityEngine.Texture)
extern void Texture2DAtlas_GetTextureID_mE87B21A6574D318E9E4C240DD80BBFBFB1E7963B (void);
// 0x000005A2 System.Int32 UnityEngine.Rendering.Texture2DAtlas::GetTextureID(UnityEngine.Texture,UnityEngine.Texture)
extern void Texture2DAtlas_GetTextureID_mC3B186580F3138AC25F5FDA6016FF4435023CC29 (void);
// 0x000005A3 System.Boolean UnityEngine.Rendering.Texture2DAtlas::IsCached(UnityEngine.Vector4&,UnityEngine.Texture,UnityEngine.Texture)
extern void Texture2DAtlas_IsCached_m26C4E0F45A65963FA56EAC22F40E76BD1353E426 (void);
// 0x000005A4 System.Boolean UnityEngine.Rendering.Texture2DAtlas::IsCached(UnityEngine.Vector4&,UnityEngine.Texture)
extern void Texture2DAtlas_IsCached_m7B54023CE1A4C8BFF99CB0E76A8240A4248B2556 (void);
// 0x000005A5 System.Boolean UnityEngine.Rendering.Texture2DAtlas::IsCached(UnityEngine.Vector4&,System.Int32)
extern void Texture2DAtlas_IsCached_m4B4781C1DA4FF2E1F7E49F7358BF6EFEF629A57A (void);
// 0x000005A6 UnityEngine.Vector2Int UnityEngine.Rendering.Texture2DAtlas::GetCachedTextureSize(System.Int32)
extern void Texture2DAtlas_GetCachedTextureSize_m4C26C916F8599CD4FAEB2481EDEFC59709F5F8BD (void);
// 0x000005A7 System.Boolean UnityEngine.Rendering.Texture2DAtlas::NeedsUpdate(UnityEngine.Texture,System.Boolean)
extern void Texture2DAtlas_NeedsUpdate_mC4400C203B33A8E349F55FEB32CDFDB5C70C9BB9 (void);
// 0x000005A8 System.Boolean UnityEngine.Rendering.Texture2DAtlas::NeedsUpdate(UnityEngine.Texture,UnityEngine.Texture,System.Boolean)
extern void Texture2DAtlas_NeedsUpdate_m6906FEF78BC34F7246181C6F4EF208E6D095F2E7 (void);
// 0x000005A9 System.Boolean UnityEngine.Rendering.Texture2DAtlas::AddTexture(UnityEngine.Rendering.CommandBuffer,UnityEngine.Vector4&,UnityEngine.Texture)
extern void Texture2DAtlas_AddTexture_m173ABA0D0F69CE3D63BBFBB57B39061813A5F928 (void);
// 0x000005AA System.Boolean UnityEngine.Rendering.Texture2DAtlas::UpdateTexture(UnityEngine.Rendering.CommandBuffer,UnityEngine.Texture,UnityEngine.Texture,UnityEngine.Vector4&,UnityEngine.Vector4,System.Boolean,System.Boolean)
extern void Texture2DAtlas_UpdateTexture_mAA7E89665582543A3D34D2AF10F520DFF2E68DD9 (void);
// 0x000005AB System.Boolean UnityEngine.Rendering.Texture2DAtlas::UpdateTexture(UnityEngine.Rendering.CommandBuffer,UnityEngine.Texture,UnityEngine.Vector4&,System.Boolean,System.Boolean)
extern void Texture2DAtlas_UpdateTexture_mFDD2BDBB6B05E9BC03B132A9490D426C053ED6B2 (void);
// 0x000005AC System.Boolean UnityEngine.Rendering.Texture2DAtlas::EnsureTextureSlot(System.Boolean&,UnityEngine.Vector4&,System.Int32,System.Int32,System.Int32)
extern void Texture2DAtlas_EnsureTextureSlot_mA671255AC3FE44365706656DA6895E396C39CD2C (void);
// 0x000005AD System.Void UnityEngine.Rendering.Texture2DAtlas::.cctor()
extern void Texture2DAtlas__cctor_m91EE154122A88004E03425354202DE1EAD402797 (void);
// 0x000005AE System.Void UnityEngine.Rendering.AtlasAllocatorDynamic::.ctor(System.Int32,System.Int32,System.Int32)
extern void AtlasAllocatorDynamic__ctor_mAAB00F112B923640812220262633F2B59C8B7BB4 (void);
// 0x000005AF System.Boolean UnityEngine.Rendering.AtlasAllocatorDynamic::Allocate(UnityEngine.Vector4&,System.Int32,System.Int32,System.Int32)
extern void AtlasAllocatorDynamic_Allocate_mCB0BE9CC01255B8019E1EB0AF10818F65C97A537 (void);
// 0x000005B0 System.Void UnityEngine.Rendering.AtlasAllocatorDynamic::Release(System.Int32)
extern void AtlasAllocatorDynamic_Release_m66405964817DEC615B19E29F831A741E60DAE537 (void);
// 0x000005B1 System.Void UnityEngine.Rendering.AtlasAllocatorDynamic::Release()
extern void AtlasAllocatorDynamic_Release_m8458B490232D8C3FFF90F84483B9E7C10400205D (void);
// 0x000005B2 System.String UnityEngine.Rendering.AtlasAllocatorDynamic::DebugStringFromRoot(System.Int32)
extern void AtlasAllocatorDynamic_DebugStringFromRoot_mB566719762843EF35C69990C48714428644B40AD (void);
// 0x000005B3 System.Void UnityEngine.Rendering.AtlasAllocatorDynamic::DebugStringFromNode(System.String&,System.Int16,System.Int32,System.Int32)
extern void AtlasAllocatorDynamic_DebugStringFromNode_m5051017F1F7E5381DE412AFA6D3CB22EE1AC2423 (void);
// 0x000005B4 System.Void UnityEngine.Rendering.AtlasAllocatorDynamic/AtlasNodePool::.ctor(System.Int16)
extern void AtlasNodePool__ctor_m22C2652C4D29136D79798422530C9A5D9E8CC69D (void);
// 0x000005B5 System.Void UnityEngine.Rendering.AtlasAllocatorDynamic/AtlasNodePool::Dispose()
extern void AtlasNodePool_Dispose_m655F49046B7605E8FCE3A1553C74C0386ED6D746 (void);
// 0x000005B6 System.Void UnityEngine.Rendering.AtlasAllocatorDynamic/AtlasNodePool::Clear()
extern void AtlasNodePool_Clear_mE8DEA3A08060A6BD5DB3767066D1543C0DD77984 (void);
// 0x000005B7 System.Int16 UnityEngine.Rendering.AtlasAllocatorDynamic/AtlasNodePool::AtlasNodeCreate(System.Int16)
extern void AtlasNodePool_AtlasNodeCreate_mCB3CA729969FC4DC8787F4F1CB6AF136E20514DF (void);
// 0x000005B8 System.Void UnityEngine.Rendering.AtlasAllocatorDynamic/AtlasNodePool::AtlasNodeFree(System.Int16)
extern void AtlasNodePool_AtlasNodeFree_m8439BC672727D5205BD768CCF3A26C3E924D53EF (void);
// 0x000005B9 System.Void UnityEngine.Rendering.AtlasAllocatorDynamic/AtlasNode::.ctor(System.Int16,System.Int16)
extern void AtlasNode__ctor_mFFF2DBE5F81BD41BFF58E221F82DA5D3EF3B8C05 (void);
// 0x000005BA System.Boolean UnityEngine.Rendering.AtlasAllocatorDynamic/AtlasNode::IsOccupied()
extern void AtlasNode_IsOccupied_m4DAB3793E66F89B97D1521DA6A639A0B16C8BEE1 (void);
// 0x000005BB System.Void UnityEngine.Rendering.AtlasAllocatorDynamic/AtlasNode::SetIsOccupied()
extern void AtlasNode_SetIsOccupied_mDE0F696F9119A0A840D300CFF9BFDC5844C37DEB (void);
// 0x000005BC System.Void UnityEngine.Rendering.AtlasAllocatorDynamic/AtlasNode::ClearIsOccupied()
extern void AtlasNode_ClearIsOccupied_m15C4CF7573BF45C8472AAE6C72D93496F69F74B6 (void);
// 0x000005BD System.Boolean UnityEngine.Rendering.AtlasAllocatorDynamic/AtlasNode::IsLeafNode()
extern void AtlasNode_IsLeafNode_m026D9501AB6E24CF82AD67D96AD9B08F164F5925 (void);
// 0x000005BE System.Int16 UnityEngine.Rendering.AtlasAllocatorDynamic/AtlasNode::Allocate(UnityEngine.Rendering.AtlasAllocatorDynamic/AtlasNodePool,System.Int32,System.Int32)
extern void AtlasNode_Allocate_mA96F58D6ED00C8AED33E570BD38FC508D11A3A07 (void);
// 0x000005BF System.Void UnityEngine.Rendering.AtlasAllocatorDynamic/AtlasNode::ReleaseChildren(UnityEngine.Rendering.AtlasAllocatorDynamic/AtlasNodePool)
extern void AtlasNode_ReleaseChildren_m1B0112B1DD2DCFF5E204BE80B8F7C9BC91E7BB6B (void);
// 0x000005C0 System.Void UnityEngine.Rendering.AtlasAllocatorDynamic/AtlasNode::ReleaseAndMerge(UnityEngine.Rendering.AtlasAllocatorDynamic/AtlasNodePool)
extern void AtlasNode_ReleaseAndMerge_mF3EA698E178F2042996A9C630D05723A4B3E11AF (void);
// 0x000005C1 System.Boolean UnityEngine.Rendering.AtlasAllocatorDynamic/AtlasNode::IsMergeNeeded(UnityEngine.Rendering.AtlasAllocatorDynamic/AtlasNodePool)
extern void AtlasNode_IsMergeNeeded_m70B87CDC5F874B42D73D0A5D889F7E86AD44A8AE (void);
// 0x000005C2 UnityEngine.Rendering.RTHandle UnityEngine.Rendering.Texture2DAtlasDynamic::get_AtlasTexture()
extern void Texture2DAtlasDynamic_get_AtlasTexture_mAE927AA3791B87C4D51E202BE0245B5A83243B80 (void);
// 0x000005C3 System.Void UnityEngine.Rendering.Texture2DAtlasDynamic::.ctor(System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat)
extern void Texture2DAtlasDynamic__ctor_mC9820B0906E6000B52062287587B7DEBC56240BA (void);
// 0x000005C4 System.Void UnityEngine.Rendering.Texture2DAtlasDynamic::.ctor(System.Int32,System.Int32,System.Int32,UnityEngine.Rendering.RTHandle)
extern void Texture2DAtlasDynamic__ctor_m336C4EA6736F484F44512865CD888655B552FCAB (void);
// 0x000005C5 System.Void UnityEngine.Rendering.Texture2DAtlasDynamic::Release()
extern void Texture2DAtlasDynamic_Release_m1812DA4BB82F8D3D65B3F9CD51D4A66ED93E7F3E (void);
// 0x000005C6 System.Void UnityEngine.Rendering.Texture2DAtlasDynamic::ResetAllocator()
extern void Texture2DAtlasDynamic_ResetAllocator_m896AD6D2A4BC73A314AC6EF64136EC6A3A239CC5 (void);
// 0x000005C7 System.Boolean UnityEngine.Rendering.Texture2DAtlasDynamic::AddTexture(UnityEngine.Rendering.CommandBuffer,UnityEngine.Vector4&,UnityEngine.Texture)
extern void Texture2DAtlasDynamic_AddTexture_mA2A1D2AED36157C9A0994953D4E4E4EC00D43D92 (void);
// 0x000005C8 System.Boolean UnityEngine.Rendering.Texture2DAtlasDynamic::IsCached(UnityEngine.Vector4&,System.Int32)
extern void Texture2DAtlasDynamic_IsCached_m09E0FB48076CA53709A7E8296EDBD0A1C040A898 (void);
// 0x000005C9 System.Boolean UnityEngine.Rendering.Texture2DAtlasDynamic::EnsureTextureSlot(System.Boolean&,UnityEngine.Vector4&,System.Int32,System.Int32,System.Int32)
extern void Texture2DAtlasDynamic_EnsureTextureSlot_mCE0B6C1445851861E89135B087000B8817CE21FF (void);
// 0x000005CA System.Void UnityEngine.Rendering.Texture2DAtlasDynamic::ReleaseTextureSlot(System.Int32)
extern void Texture2DAtlasDynamic_ReleaseTextureSlot_m64D7A4CD2351FADA1AC1EB5C336B449D7E0C6845 (void);
// 0x000005CB System.Void UnityEngine.Rendering.TextureXR::set_maxViews(System.Int32)
extern void TextureXR_set_maxViews_m372FF3225D53990EB6982ACD1096F613BDE69922 (void);
// 0x000005CC System.Int32 UnityEngine.Rendering.TextureXR::get_slices()
extern void TextureXR_get_slices_m062BCCD9A0A99529F1EBF01068F87C12908FD260 (void);
// 0x000005CD System.Boolean UnityEngine.Rendering.TextureXR::get_useTexArray()
extern void TextureXR_get_useTexArray_m03D653E1B7E284DE7655BF617102C8D3CB47A77D (void);
// 0x000005CE UnityEngine.Rendering.TextureDimension UnityEngine.Rendering.TextureXR::get_dimension()
extern void TextureXR_get_dimension_mF5451652AD01DE1A917D0C4078E4EBDD451A5AE5 (void);
// 0x000005CF UnityEngine.Rendering.RTHandle UnityEngine.Rendering.TextureXR::GetBlackUIntTexture()
extern void TextureXR_GetBlackUIntTexture_m9F4F07C63375F1200E69DEF0C50B173354DBAF73 (void);
// 0x000005D0 UnityEngine.Rendering.RTHandle UnityEngine.Rendering.TextureXR::GetClearTexture()
extern void TextureXR_GetClearTexture_mF064CE808953BF4FAF6275FA37FC64FC6C32047A (void);
// 0x000005D1 UnityEngine.Rendering.RTHandle UnityEngine.Rendering.TextureXR::GetMagentaTexture()
extern void TextureXR_GetMagentaTexture_m540F2F78494398B2CD2667B458CFEDB45357E626 (void);
// 0x000005D2 UnityEngine.Rendering.RTHandle UnityEngine.Rendering.TextureXR::GetBlackTexture()
extern void TextureXR_GetBlackTexture_mC8BC117CF59ED27F57A66F0CA34758647098C46D (void);
// 0x000005D3 UnityEngine.Rendering.RTHandle UnityEngine.Rendering.TextureXR::GetBlackTextureArray()
extern void TextureXR_GetBlackTextureArray_m854E06ABA457E2C6BB7345BAC0E49C2477667967 (void);
// 0x000005D4 UnityEngine.Rendering.RTHandle UnityEngine.Rendering.TextureXR::GetBlackTexture3D()
extern void TextureXR_GetBlackTexture3D_m8D80CB8404ED895D0A2D5E4B73B4FAA9689BF5C2 (void);
// 0x000005D5 UnityEngine.Rendering.RTHandle UnityEngine.Rendering.TextureXR::GetWhiteTexture()
extern void TextureXR_GetWhiteTexture_m6280FF7F2A9425E90DB30809B7067ADE05D7A9FB (void);
// 0x000005D6 System.Void UnityEngine.Rendering.TextureXR::Initialize(UnityEngine.Rendering.CommandBuffer,UnityEngine.ComputeShader)
extern void TextureXR_Initialize_m3FBDB7039F1DA5958BD87DB420A3A495FD4D7E9B (void);
// 0x000005D7 UnityEngine.Texture2DArray UnityEngine.Rendering.TextureXR::CreateTexture2DArrayFromTexture2D(UnityEngine.Texture2D,System.String)
extern void TextureXR_CreateTexture2DArrayFromTexture2D_mE2D47790EDF8E296A4BD08D68A2EC845D533CD63 (void);
// 0x000005D8 UnityEngine.Texture UnityEngine.Rendering.TextureXR::CreateBlackUIntTextureArray(UnityEngine.Rendering.CommandBuffer,UnityEngine.ComputeShader)
extern void TextureXR_CreateBlackUIntTextureArray_m31C723201EE5836D79EAC9547B2717525E3B7A3D (void);
// 0x000005D9 UnityEngine.Texture UnityEngine.Rendering.TextureXR::CreateBlackUintTexture(UnityEngine.Rendering.CommandBuffer,UnityEngine.ComputeShader)
extern void TextureXR_CreateBlackUintTexture_mA6A75A180C5B5FBB68B8C8CD8C703E8C472C6F17 (void);
// 0x000005DA UnityEngine.Texture3D UnityEngine.Rendering.TextureXR::CreateBlackTexture3D(System.String)
extern void TextureXR_CreateBlackTexture3D_m70E166C61FADBE1D1F29A91FA821D89B17802F9F (void);
// 0x000005DB System.Void UnityEngine.Rendering.TextureXR::.cctor()
extern void TextureXR__cctor_mE878B10D1BF0795040F3EE53CA670752192BAA7F (void);
// 0x000005DC System.Void UnityEngine.Rendering.ArrayExtensions::ResizeArray(Unity.Collections.NativeArray`1<T>&,System.Int32)
// 0x000005DD System.Void UnityEngine.Rendering.ArrayExtensions::ResizeArray(UnityEngine.Jobs.TransformAccessArray&,System.Int32)
extern void ArrayExtensions_ResizeArray_m652C33E2C6CC635B812F158A1AA9FEB54E8F7488 (void);
// 0x000005DE System.Void UnityEngine.Rendering.ArrayExtensions::ResizeArray(T[]&,System.Int32)
// 0x000005DF System.UInt32 UnityEngine.Rendering.IBitArray::get_capacity()
// 0x000005E0 System.Boolean UnityEngine.Rendering.IBitArray::get_allFalse()
// 0x000005E1 System.Boolean UnityEngine.Rendering.IBitArray::get_allTrue()
// 0x000005E2 System.Boolean UnityEngine.Rendering.IBitArray::get_Item(System.UInt32)
// 0x000005E3 System.Void UnityEngine.Rendering.IBitArray::set_Item(System.UInt32,System.Boolean)
// 0x000005E4 System.String UnityEngine.Rendering.IBitArray::get_humanizedData()
// 0x000005E5 UnityEngine.Rendering.IBitArray UnityEngine.Rendering.IBitArray::BitAnd(UnityEngine.Rendering.IBitArray)
// 0x000005E6 UnityEngine.Rendering.IBitArray UnityEngine.Rendering.IBitArray::BitOr(UnityEngine.Rendering.IBitArray)
// 0x000005E7 UnityEngine.Rendering.IBitArray UnityEngine.Rendering.IBitArray::BitNot()
// 0x000005E8 System.UInt32 UnityEngine.Rendering.BitArray8::get_capacity()
extern void BitArray8_get_capacity_mA3B76B8563ED73CE2ACAA6248BB1659EFE18EE01 (void);
// 0x000005E9 System.Boolean UnityEngine.Rendering.BitArray8::get_allFalse()
extern void BitArray8_get_allFalse_m90DB2959D94946C2EFE34547AD6E2B8F10168463 (void);
// 0x000005EA System.Boolean UnityEngine.Rendering.BitArray8::get_allTrue()
extern void BitArray8_get_allTrue_m793F5AAF8F83DAB21C0308F738147A29FFF08451 (void);
// 0x000005EB System.String UnityEngine.Rendering.BitArray8::get_humanizedData()
extern void BitArray8_get_humanizedData_mF2404C0DEFF15E9DA20FC99071CA3A5900F4E791 (void);
// 0x000005EC System.Boolean UnityEngine.Rendering.BitArray8::get_Item(System.UInt32)
extern void BitArray8_get_Item_m4A05F5141C4554B92AE97D5487224C7840EC4D53 (void);
// 0x000005ED System.Void UnityEngine.Rendering.BitArray8::set_Item(System.UInt32,System.Boolean)
extern void BitArray8_set_Item_m547A700177E97C60883197FE03D3DD03CBDE5F08 (void);
// 0x000005EE System.Void UnityEngine.Rendering.BitArray8::.ctor(System.Byte)
extern void BitArray8__ctor_m86747787EF4C4E385B761101DD9B40EF6174F69A (void);
// 0x000005EF System.Void UnityEngine.Rendering.BitArray8::.ctor(System.Collections.Generic.IEnumerable`1<System.UInt32>)
extern void BitArray8__ctor_m831CBA0141A7161831057654C9363F50C0AF6151 (void);
// 0x000005F0 UnityEngine.Rendering.BitArray8 UnityEngine.Rendering.BitArray8::op_OnesComplement(UnityEngine.Rendering.BitArray8)
extern void BitArray8_op_OnesComplement_m74BED0A30CDF3A69F4EB66CF9BFE87F6A6047A4E (void);
// 0x000005F1 UnityEngine.Rendering.BitArray8 UnityEngine.Rendering.BitArray8::op_BitwiseOr(UnityEngine.Rendering.BitArray8,UnityEngine.Rendering.BitArray8)
extern void BitArray8_op_BitwiseOr_m3A5FAC9E1115587DE663A36FCE6B3E342E8C7EC4 (void);
// 0x000005F2 UnityEngine.Rendering.BitArray8 UnityEngine.Rendering.BitArray8::op_BitwiseAnd(UnityEngine.Rendering.BitArray8,UnityEngine.Rendering.BitArray8)
extern void BitArray8_op_BitwiseAnd_mA7AF39894148406CCDAA991F455582F36365FA9D (void);
// 0x000005F3 UnityEngine.Rendering.IBitArray UnityEngine.Rendering.BitArray8::BitAnd(UnityEngine.Rendering.IBitArray)
extern void BitArray8_BitAnd_mB8BFBCC7ED08AE63C8DCD56F224FC2A887666536 (void);
// 0x000005F4 UnityEngine.Rendering.IBitArray UnityEngine.Rendering.BitArray8::BitOr(UnityEngine.Rendering.IBitArray)
extern void BitArray8_BitOr_m18AF19D6C292BF095EDC795C3018099B3A8CD121 (void);
// 0x000005F5 UnityEngine.Rendering.IBitArray UnityEngine.Rendering.BitArray8::BitNot()
extern void BitArray8_BitNot_mB1E3ADFBDB897ED040CE28C797CD868DE95B9B26 (void);
// 0x000005F6 System.Boolean UnityEngine.Rendering.BitArray8::op_Equality(UnityEngine.Rendering.BitArray8,UnityEngine.Rendering.BitArray8)
extern void BitArray8_op_Equality_mC7A4D257AC7A3ED7FDDEB381DBF8F5C6971299A5 (void);
// 0x000005F7 System.Boolean UnityEngine.Rendering.BitArray8::op_Inequality(UnityEngine.Rendering.BitArray8,UnityEngine.Rendering.BitArray8)
extern void BitArray8_op_Inequality_m5E8187711DCF9A91EA8F3D662BA702A10EAECD74 (void);
// 0x000005F8 System.Boolean UnityEngine.Rendering.BitArray8::Equals(System.Object)
extern void BitArray8_Equals_m86ADBD06E76F1B28D197017F091F13F063B453EB (void);
// 0x000005F9 System.Int32 UnityEngine.Rendering.BitArray8::GetHashCode()
extern void BitArray8_GetHashCode_m0226A2FAF19B61AEBC5CC60F87DC272CCCF20A77 (void);
// 0x000005FA System.UInt32 UnityEngine.Rendering.BitArray16::get_capacity()
extern void BitArray16_get_capacity_mA5EE007A81C601C9A3552D8A504747CD6BBF5B9D (void);
// 0x000005FB System.Boolean UnityEngine.Rendering.BitArray16::get_allFalse()
extern void BitArray16_get_allFalse_mB74A351DF512549357B62F578F8745861E768BCA (void);
// 0x000005FC System.Boolean UnityEngine.Rendering.BitArray16::get_allTrue()
extern void BitArray16_get_allTrue_mA4CFAC20D5338EA36278D5762FEF1879DEF44298 (void);
// 0x000005FD System.String UnityEngine.Rendering.BitArray16::get_humanizedData()
extern void BitArray16_get_humanizedData_m12F476DEF544F28CCD2579475DE167820BD88E87 (void);
// 0x000005FE System.Boolean UnityEngine.Rendering.BitArray16::get_Item(System.UInt32)
extern void BitArray16_get_Item_mCA32C50FD252F47DCBFD7262435245238430A180 (void);
// 0x000005FF System.Void UnityEngine.Rendering.BitArray16::set_Item(System.UInt32,System.Boolean)
extern void BitArray16_set_Item_m9457F4B8745BC1C5285574EE23FDD05A4BA2F088 (void);
// 0x00000600 System.Void UnityEngine.Rendering.BitArray16::.ctor(System.UInt16)
extern void BitArray16__ctor_m4A508EBDA58B7006D1463EAE199114B2D2E1249C (void);
// 0x00000601 System.Void UnityEngine.Rendering.BitArray16::.ctor(System.Collections.Generic.IEnumerable`1<System.UInt32>)
extern void BitArray16__ctor_m337D042A8EE2131DED83B273A8CC47843E17CBF6 (void);
// 0x00000602 UnityEngine.Rendering.BitArray16 UnityEngine.Rendering.BitArray16::op_OnesComplement(UnityEngine.Rendering.BitArray16)
extern void BitArray16_op_OnesComplement_mE37C83AB8E876316835FBECBA1A1C5EF5979E814 (void);
// 0x00000603 UnityEngine.Rendering.BitArray16 UnityEngine.Rendering.BitArray16::op_BitwiseOr(UnityEngine.Rendering.BitArray16,UnityEngine.Rendering.BitArray16)
extern void BitArray16_op_BitwiseOr_m72716C6C58CCAB01CB72A57BB96DA350FBA57AFA (void);
// 0x00000604 UnityEngine.Rendering.BitArray16 UnityEngine.Rendering.BitArray16::op_BitwiseAnd(UnityEngine.Rendering.BitArray16,UnityEngine.Rendering.BitArray16)
extern void BitArray16_op_BitwiseAnd_m53F60BC19E6F05FA7072F201EF25FFF17FFEACB8 (void);
// 0x00000605 UnityEngine.Rendering.IBitArray UnityEngine.Rendering.BitArray16::BitAnd(UnityEngine.Rendering.IBitArray)
extern void BitArray16_BitAnd_mD1AFD4C59ED599951E61A3E8BA716D5A3FFD04EC (void);
// 0x00000606 UnityEngine.Rendering.IBitArray UnityEngine.Rendering.BitArray16::BitOr(UnityEngine.Rendering.IBitArray)
extern void BitArray16_BitOr_mD788B0B73A61E66973D6B4160729C868D5BE8B35 (void);
// 0x00000607 UnityEngine.Rendering.IBitArray UnityEngine.Rendering.BitArray16::BitNot()
extern void BitArray16_BitNot_m7FB6BD7B74C796E05A9E7BA6FFEF58F6F23F10BC (void);
// 0x00000608 System.Boolean UnityEngine.Rendering.BitArray16::op_Equality(UnityEngine.Rendering.BitArray16,UnityEngine.Rendering.BitArray16)
extern void BitArray16_op_Equality_m112E0FEB5F1BFAAA410B9CD83DD34B34C9D4A9E6 (void);
// 0x00000609 System.Boolean UnityEngine.Rendering.BitArray16::op_Inequality(UnityEngine.Rendering.BitArray16,UnityEngine.Rendering.BitArray16)
extern void BitArray16_op_Inequality_m2FE623FD7D66E837B410D60B8996121A4C8874CB (void);
// 0x0000060A System.Boolean UnityEngine.Rendering.BitArray16::Equals(System.Object)
extern void BitArray16_Equals_mD170A00318A901D23C1F17444D5022FF947586D2 (void);
// 0x0000060B System.Int32 UnityEngine.Rendering.BitArray16::GetHashCode()
extern void BitArray16_GetHashCode_m018CAECA54A403343CE08C2F4225670FE5780E6D (void);
// 0x0000060C System.UInt32 UnityEngine.Rendering.BitArray32::get_capacity()
extern void BitArray32_get_capacity_m312BE2BAA06E75492376361E9299510314755AE5 (void);
// 0x0000060D System.Boolean UnityEngine.Rendering.BitArray32::get_allFalse()
extern void BitArray32_get_allFalse_m01D83A39CE7D6FBDEA9D5E57044285FF55E8260F (void);
// 0x0000060E System.Boolean UnityEngine.Rendering.BitArray32::get_allTrue()
extern void BitArray32_get_allTrue_m9AA64C6C9B386B1806BD0A9F83113055AA0967EB (void);
// 0x0000060F System.String UnityEngine.Rendering.BitArray32::get_humanizedVersion()
extern void BitArray32_get_humanizedVersion_m56C96176FE170F18CEC3327A7D19E1A774325228 (void);
// 0x00000610 System.String UnityEngine.Rendering.BitArray32::get_humanizedData()
extern void BitArray32_get_humanizedData_m38DE7DAE7EE5527EC6C6FDD518253031DFF2374F (void);
// 0x00000611 System.Boolean UnityEngine.Rendering.BitArray32::get_Item(System.UInt32)
extern void BitArray32_get_Item_mC8CEDEAB87139CA781BADBD4FBB1E84930F19FFE (void);
// 0x00000612 System.Void UnityEngine.Rendering.BitArray32::set_Item(System.UInt32,System.Boolean)
extern void BitArray32_set_Item_m6248824F85F4FCD452DE48E6B714AEB52D07AF44 (void);
// 0x00000613 System.Void UnityEngine.Rendering.BitArray32::.ctor(System.UInt32)
extern void BitArray32__ctor_m0982C7BD4F185BA648120E2ADA794E7D778B995D (void);
// 0x00000614 System.Void UnityEngine.Rendering.BitArray32::.ctor(System.Collections.Generic.IEnumerable`1<System.UInt32>)
extern void BitArray32__ctor_m410177CA4D679011D0A4653FC28A4B83B39A1EF1 (void);
// 0x00000615 UnityEngine.Rendering.IBitArray UnityEngine.Rendering.BitArray32::BitAnd(UnityEngine.Rendering.IBitArray)
extern void BitArray32_BitAnd_m050354D3A87E2A90324EEB8AA7D1156A482E058A (void);
// 0x00000616 UnityEngine.Rendering.IBitArray UnityEngine.Rendering.BitArray32::BitOr(UnityEngine.Rendering.IBitArray)
extern void BitArray32_BitOr_mFB1856DBA7D371F7C6C04FD475577C3A9E15D62F (void);
// 0x00000617 UnityEngine.Rendering.IBitArray UnityEngine.Rendering.BitArray32::BitNot()
extern void BitArray32_BitNot_mA3731229D50D6F6F4ACB1B80EB1EBA5610C656E8 (void);
// 0x00000618 UnityEngine.Rendering.BitArray32 UnityEngine.Rendering.BitArray32::op_OnesComplement(UnityEngine.Rendering.BitArray32)
extern void BitArray32_op_OnesComplement_m898623FAA720F5ECDC16B448A976CE40F53301DB (void);
// 0x00000619 UnityEngine.Rendering.BitArray32 UnityEngine.Rendering.BitArray32::op_BitwiseOr(UnityEngine.Rendering.BitArray32,UnityEngine.Rendering.BitArray32)
extern void BitArray32_op_BitwiseOr_mDDA7BE99A4D5A25FE02467C8301740B60B9A4177 (void);
// 0x0000061A UnityEngine.Rendering.BitArray32 UnityEngine.Rendering.BitArray32::op_BitwiseAnd(UnityEngine.Rendering.BitArray32,UnityEngine.Rendering.BitArray32)
extern void BitArray32_op_BitwiseAnd_m0B7FDD7E86B52E16FA45E774E64CFC26C745C1B9 (void);
// 0x0000061B System.Boolean UnityEngine.Rendering.BitArray32::op_Equality(UnityEngine.Rendering.BitArray32,UnityEngine.Rendering.BitArray32)
extern void BitArray32_op_Equality_m2BEFFBC78F7F63B1FEA0C6C9BBA636F7D89991FE (void);
// 0x0000061C System.Boolean UnityEngine.Rendering.BitArray32::op_Inequality(UnityEngine.Rendering.BitArray32,UnityEngine.Rendering.BitArray32)
extern void BitArray32_op_Inequality_m33D0A690929501F09D4EB423FBB7330BB5B240A8 (void);
// 0x0000061D System.Boolean UnityEngine.Rendering.BitArray32::Equals(System.Object)
extern void BitArray32_Equals_mE94B4571565F0D7243127EB6070E76B8A958781C (void);
// 0x0000061E System.Int32 UnityEngine.Rendering.BitArray32::GetHashCode()
extern void BitArray32_GetHashCode_m918359D3BC8DF9C6F2BA72085B422BED8B7AA5EC (void);
// 0x0000061F System.UInt32 UnityEngine.Rendering.BitArray64::get_capacity()
extern void BitArray64_get_capacity_mE0D7937E14B27EFB5580F024329871EA9F6F61A9 (void);
// 0x00000620 System.Boolean UnityEngine.Rendering.BitArray64::get_allFalse()
extern void BitArray64_get_allFalse_m066B324DA3D868A839C4C000E923D590D09FC40B (void);
// 0x00000621 System.Boolean UnityEngine.Rendering.BitArray64::get_allTrue()
extern void BitArray64_get_allTrue_mD2AA9BCA8BD30CEE7F6648362CA4493BC81318CF (void);
// 0x00000622 System.String UnityEngine.Rendering.BitArray64::get_humanizedData()
extern void BitArray64_get_humanizedData_m3D2C299930B49D326C92EE0B0BA574DFF3C74891 (void);
// 0x00000623 System.Boolean UnityEngine.Rendering.BitArray64::get_Item(System.UInt32)
extern void BitArray64_get_Item_m44EA8594329A57FA9400342251411BCE62B54453 (void);
// 0x00000624 System.Void UnityEngine.Rendering.BitArray64::set_Item(System.UInt32,System.Boolean)
extern void BitArray64_set_Item_mDEB0D2418675CD4FEAA1CDBDDDEA70A5CD35E44D (void);
// 0x00000625 System.Void UnityEngine.Rendering.BitArray64::.ctor(System.UInt64)
extern void BitArray64__ctor_m41D38225ACEAF7A0D4201AB8AE9F781CD736DA04 (void);
// 0x00000626 System.Void UnityEngine.Rendering.BitArray64::.ctor(System.Collections.Generic.IEnumerable`1<System.UInt32>)
extern void BitArray64__ctor_m8745536B9B0A03C956553C54B7F425604CF60E37 (void);
// 0x00000627 UnityEngine.Rendering.BitArray64 UnityEngine.Rendering.BitArray64::op_OnesComplement(UnityEngine.Rendering.BitArray64)
extern void BitArray64_op_OnesComplement_m299275129C52E24E06DFF482EBFCA64C08042736 (void);
// 0x00000628 UnityEngine.Rendering.BitArray64 UnityEngine.Rendering.BitArray64::op_BitwiseOr(UnityEngine.Rendering.BitArray64,UnityEngine.Rendering.BitArray64)
extern void BitArray64_op_BitwiseOr_m861E7D4EC020CF3606364C4F65BEFBBD2C6F6C01 (void);
// 0x00000629 UnityEngine.Rendering.BitArray64 UnityEngine.Rendering.BitArray64::op_BitwiseAnd(UnityEngine.Rendering.BitArray64,UnityEngine.Rendering.BitArray64)
extern void BitArray64_op_BitwiseAnd_mB51BF8ABF7AC1F151D3B8C67A12BE48A78F0D345 (void);
// 0x0000062A UnityEngine.Rendering.IBitArray UnityEngine.Rendering.BitArray64::BitAnd(UnityEngine.Rendering.IBitArray)
extern void BitArray64_BitAnd_m578053826382B2ACB7E67872F4DB1E475C12B707 (void);
// 0x0000062B UnityEngine.Rendering.IBitArray UnityEngine.Rendering.BitArray64::BitOr(UnityEngine.Rendering.IBitArray)
extern void BitArray64_BitOr_mC80A8A2E27FE8E3614F1ECFB64C7D38BFA7ADC10 (void);
// 0x0000062C UnityEngine.Rendering.IBitArray UnityEngine.Rendering.BitArray64::BitNot()
extern void BitArray64_BitNot_mDEA129C39BEEE912882F8F2F6D79277ED3B2CED6 (void);
// 0x0000062D System.Boolean UnityEngine.Rendering.BitArray64::op_Equality(UnityEngine.Rendering.BitArray64,UnityEngine.Rendering.BitArray64)
extern void BitArray64_op_Equality_m59409ED14A3934D73FEDA580942271660B1136EE (void);
// 0x0000062E System.Boolean UnityEngine.Rendering.BitArray64::op_Inequality(UnityEngine.Rendering.BitArray64,UnityEngine.Rendering.BitArray64)
extern void BitArray64_op_Inequality_m23DC59DB0C8811D62FEA4B2C7F819AF6CA14D9C3 (void);
// 0x0000062F System.Boolean UnityEngine.Rendering.BitArray64::Equals(System.Object)
extern void BitArray64_Equals_m302E3D444E2E2F74D865409C90AD08ECF3228498 (void);
// 0x00000630 System.Int32 UnityEngine.Rendering.BitArray64::GetHashCode()
extern void BitArray64_GetHashCode_mC01786968B8E26CD78AF9F6BA8D9DDFA1A56AB14 (void);
// 0x00000631 System.UInt32 UnityEngine.Rendering.BitArray128::get_capacity()
extern void BitArray128_get_capacity_mF8B9300884F70FA7D2E5424DF4B844F98224105B (void);
// 0x00000632 System.Boolean UnityEngine.Rendering.BitArray128::get_allFalse()
extern void BitArray128_get_allFalse_mD54F8D614FE56898CAC736E0D471E03CF27DE84D (void);
// 0x00000633 System.Boolean UnityEngine.Rendering.BitArray128::get_allTrue()
extern void BitArray128_get_allTrue_m613B6531E734903771CB400313E3C58324095EC3 (void);
// 0x00000634 System.String UnityEngine.Rendering.BitArray128::get_humanizedData()
extern void BitArray128_get_humanizedData_mFBE6722FC3146F9439687F1D23B26B8BBA497588 (void);
// 0x00000635 System.Boolean UnityEngine.Rendering.BitArray128::get_Item(System.UInt32)
extern void BitArray128_get_Item_m2056FC3D3AE3A6650545407C0961C91621453676 (void);
// 0x00000636 System.Void UnityEngine.Rendering.BitArray128::set_Item(System.UInt32,System.Boolean)
extern void BitArray128_set_Item_mACDC728AC1CA0A2114008187840DC3242CC0C8E8 (void);
// 0x00000637 System.Void UnityEngine.Rendering.BitArray128::.ctor(System.UInt64,System.UInt64)
extern void BitArray128__ctor_m269F0551193B6E3990A4BC6209012C6BF6D9A867 (void);
// 0x00000638 System.Void UnityEngine.Rendering.BitArray128::.ctor(System.Collections.Generic.IEnumerable`1<System.UInt32>)
extern void BitArray128__ctor_m48BF375FF417816E116009DA45CF3B498929AF4B (void);
// 0x00000639 UnityEngine.Rendering.BitArray128 UnityEngine.Rendering.BitArray128::op_OnesComplement(UnityEngine.Rendering.BitArray128)
extern void BitArray128_op_OnesComplement_mA128D42CCD0E8146CBF8E53299DF10C67FC33436 (void);
// 0x0000063A UnityEngine.Rendering.BitArray128 UnityEngine.Rendering.BitArray128::op_BitwiseOr(UnityEngine.Rendering.BitArray128,UnityEngine.Rendering.BitArray128)
extern void BitArray128_op_BitwiseOr_m03022DB05D521B8BEF13B293D2783BD6509F06FC (void);
// 0x0000063B UnityEngine.Rendering.BitArray128 UnityEngine.Rendering.BitArray128::op_BitwiseAnd(UnityEngine.Rendering.BitArray128,UnityEngine.Rendering.BitArray128)
extern void BitArray128_op_BitwiseAnd_m7E6FE8D5303DE1D218A17522BD54E774DBD1E019 (void);
// 0x0000063C UnityEngine.Rendering.IBitArray UnityEngine.Rendering.BitArray128::BitAnd(UnityEngine.Rendering.IBitArray)
extern void BitArray128_BitAnd_m573069987C6CD28B9045D0A34BB9384A7D943404 (void);
// 0x0000063D UnityEngine.Rendering.IBitArray UnityEngine.Rendering.BitArray128::BitOr(UnityEngine.Rendering.IBitArray)
extern void BitArray128_BitOr_m0621F3B8EB34A40324EE7559AA4B3104B04264F1 (void);
// 0x0000063E UnityEngine.Rendering.IBitArray UnityEngine.Rendering.BitArray128::BitNot()
extern void BitArray128_BitNot_m9D31DF47F85C778B39C77B7FC96725F5B7DAFCF5 (void);
// 0x0000063F System.Boolean UnityEngine.Rendering.BitArray128::op_Equality(UnityEngine.Rendering.BitArray128,UnityEngine.Rendering.BitArray128)
extern void BitArray128_op_Equality_mBBF2BCBAAF22ADC9585EEB1D8661308E449DF64C (void);
// 0x00000640 System.Boolean UnityEngine.Rendering.BitArray128::op_Inequality(UnityEngine.Rendering.BitArray128,UnityEngine.Rendering.BitArray128)
extern void BitArray128_op_Inequality_m62B44C09197F1D944695176B340A89EC14512A14 (void);
// 0x00000641 System.Boolean UnityEngine.Rendering.BitArray128::Equals(System.Object)
extern void BitArray128_Equals_m7BBE0682933DA4AB8B2605AD8428AE845154C5C2 (void);
// 0x00000642 System.Int32 UnityEngine.Rendering.BitArray128::GetHashCode()
extern void BitArray128_GetHashCode_mB8C12AF9AAC59655B4AFA06D4A0F204157FF5320 (void);
// 0x00000643 System.UInt32 UnityEngine.Rendering.BitArray256::get_capacity()
extern void BitArray256_get_capacity_mBEEC883503CA5B2F2ED0E5EE4E917B3E20902676 (void);
// 0x00000644 System.Boolean UnityEngine.Rendering.BitArray256::get_allFalse()
extern void BitArray256_get_allFalse_mC89BB118740CCF24F251D5C89DC15C54E02137CF (void);
// 0x00000645 System.Boolean UnityEngine.Rendering.BitArray256::get_allTrue()
extern void BitArray256_get_allTrue_m7467D31E9239CA8F8D067A048A272424855A8139 (void);
// 0x00000646 System.String UnityEngine.Rendering.BitArray256::get_humanizedData()
extern void BitArray256_get_humanizedData_m35B5547DD137D862F789A03722AA192DA3E1B748 (void);
// 0x00000647 System.Boolean UnityEngine.Rendering.BitArray256::get_Item(System.UInt32)
extern void BitArray256_get_Item_m97E7E356A32515F35B77F5310BCB350A63EF0287 (void);
// 0x00000648 System.Void UnityEngine.Rendering.BitArray256::set_Item(System.UInt32,System.Boolean)
extern void BitArray256_set_Item_mE6BF23C525D050DF66970DFFAB563A34323226B2 (void);
// 0x00000649 System.Void UnityEngine.Rendering.BitArray256::.ctor(System.UInt64,System.UInt64,System.UInt64,System.UInt64)
extern void BitArray256__ctor_m0D5A2405F5460958E0CDEFE16C962079B8DAD5DC (void);
// 0x0000064A System.Void UnityEngine.Rendering.BitArray256::.ctor(System.Collections.Generic.IEnumerable`1<System.UInt32>)
extern void BitArray256__ctor_m67548173CE100A6542C2BD45BD9D04B04760B0A4 (void);
// 0x0000064B UnityEngine.Rendering.BitArray256 UnityEngine.Rendering.BitArray256::op_OnesComplement(UnityEngine.Rendering.BitArray256)
extern void BitArray256_op_OnesComplement_m260EB2662B64747EDC89042792941A983D0E94E9 (void);
// 0x0000064C UnityEngine.Rendering.BitArray256 UnityEngine.Rendering.BitArray256::op_BitwiseOr(UnityEngine.Rendering.BitArray256,UnityEngine.Rendering.BitArray256)
extern void BitArray256_op_BitwiseOr_m036B626BD8173B53B9D4ADDAAE516BF2A9A9906D (void);
// 0x0000064D UnityEngine.Rendering.BitArray256 UnityEngine.Rendering.BitArray256::op_BitwiseAnd(UnityEngine.Rendering.BitArray256,UnityEngine.Rendering.BitArray256)
extern void BitArray256_op_BitwiseAnd_m4FDAD6E0FDAECAE2CD3D742329D7A243000BF372 (void);
// 0x0000064E UnityEngine.Rendering.IBitArray UnityEngine.Rendering.BitArray256::BitAnd(UnityEngine.Rendering.IBitArray)
extern void BitArray256_BitAnd_mDC9F06C7E0E0BA44380F19BADCE0C54CA6301A1F (void);
// 0x0000064F UnityEngine.Rendering.IBitArray UnityEngine.Rendering.BitArray256::BitOr(UnityEngine.Rendering.IBitArray)
extern void BitArray256_BitOr_m991E6FDFEF4405D82BBFC2F907B9F7B0AEB9CE66 (void);
// 0x00000650 UnityEngine.Rendering.IBitArray UnityEngine.Rendering.BitArray256::BitNot()
extern void BitArray256_BitNot_m2DB60E7421D37CB7808A363E0B23D579A61B993E (void);
// 0x00000651 System.Boolean UnityEngine.Rendering.BitArray256::op_Equality(UnityEngine.Rendering.BitArray256,UnityEngine.Rendering.BitArray256)
extern void BitArray256_op_Equality_mCD0A130308E3166549830861B3DEF91109A00BDC (void);
// 0x00000652 System.Boolean UnityEngine.Rendering.BitArray256::op_Inequality(UnityEngine.Rendering.BitArray256,UnityEngine.Rendering.BitArray256)
extern void BitArray256_op_Inequality_m5C9A0C7540B6D9945503203065DEA9B430C189F3 (void);
// 0x00000653 System.Boolean UnityEngine.Rendering.BitArray256::Equals(System.Object)
extern void BitArray256_Equals_m6723D6D291F588EDD9861D7C58247F246E94417F (void);
// 0x00000654 System.Int32 UnityEngine.Rendering.BitArray256::GetHashCode()
extern void BitArray256_GetHashCode_mCB0868DFC6212118B07731906DAB0BBF2AC38F7C (void);
// 0x00000655 System.Boolean UnityEngine.Rendering.BitArrayUtilities::Get8(System.UInt32,System.Byte)
extern void BitArrayUtilities_Get8_m9D48D91A431CEF3FFA4C4A8CD5ACAF4E0744580D (void);
// 0x00000656 System.Boolean UnityEngine.Rendering.BitArrayUtilities::Get16(System.UInt32,System.UInt16)
extern void BitArrayUtilities_Get16_m066D2B1DAEDCAFF7F410EACD5685646F0CEBFF99 (void);
// 0x00000657 System.Boolean UnityEngine.Rendering.BitArrayUtilities::Get32(System.UInt32,System.UInt32)
extern void BitArrayUtilities_Get32_m3105A06D66A28B263CC53E3F714F72FD7244EAE1 (void);
// 0x00000658 System.Boolean UnityEngine.Rendering.BitArrayUtilities::Get64(System.UInt32,System.UInt64)
extern void BitArrayUtilities_Get64_m6D4980C3A87139E97BB03FBBDCF0C1693CA2F6DA (void);
// 0x00000659 System.Boolean UnityEngine.Rendering.BitArrayUtilities::Get128(System.UInt32,System.UInt64,System.UInt64)
extern void BitArrayUtilities_Get128_mA21152D99D5617A4B11C84526E83FC410783D4D1 (void);
// 0x0000065A System.Boolean UnityEngine.Rendering.BitArrayUtilities::Get256(System.UInt32,System.UInt64,System.UInt64,System.UInt64,System.UInt64)
extern void BitArrayUtilities_Get256_m28697BC1E2CB8E4F0BFCD5947BC459603E680149 (void);
// 0x0000065B System.Void UnityEngine.Rendering.BitArrayUtilities::Set8(System.UInt32,System.Byte&,System.Boolean)
extern void BitArrayUtilities_Set8_m4BC480ABC2E8827779655B035B29D2F3E29507CD (void);
// 0x0000065C System.Void UnityEngine.Rendering.BitArrayUtilities::Set16(System.UInt32,System.UInt16&,System.Boolean)
extern void BitArrayUtilities_Set16_mB599DC5FF7486C291CF767FAE66A796B007A35FF (void);
// 0x0000065D System.Void UnityEngine.Rendering.BitArrayUtilities::Set32(System.UInt32,System.UInt32&,System.Boolean)
extern void BitArrayUtilities_Set32_m3A905DABCE191DACC520ACF62EDB2D7501AF3CCB (void);
// 0x0000065E System.Void UnityEngine.Rendering.BitArrayUtilities::Set64(System.UInt32,System.UInt64&,System.Boolean)
extern void BitArrayUtilities_Set64_m386E330CC480D74FD497AB0B695EA5C86DA04AF0 (void);
// 0x0000065F System.Void UnityEngine.Rendering.BitArrayUtilities::Set128(System.UInt32,System.UInt64&,System.UInt64&,System.Boolean)
extern void BitArrayUtilities_Set128_m0D4C44ED0B3AD702E25C60A6B53F6774121C2CD1 (void);
// 0x00000660 System.Void UnityEngine.Rendering.BitArrayUtilities::Set256(System.UInt32,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.Boolean)
extern void BitArrayUtilities_Set256_m2C69FC76E54B7DFAFB89BDD5DCD2E8749FF7520F (void);
// 0x00000661 System.Void UnityEngine.Rendering.Blitter::Initialize(UnityEngine.Shader,UnityEngine.Shader)
extern void Blitter_Initialize_m75B8676F1846666ECD90019E091D9A2A95BA6377 (void);
// 0x00000662 System.Void UnityEngine.Rendering.Blitter::Cleanup()
extern void Blitter_Cleanup_m900786CC658E1966677B4D3BF50044766C204CEA (void);
// 0x00000663 UnityEngine.Material UnityEngine.Rendering.Blitter::GetBlitMaterial(UnityEngine.Rendering.TextureDimension,System.Boolean)
extern void Blitter_GetBlitMaterial_m7139641E860546D39127F3A17C158CA63DB28958 (void);
// 0x00000664 System.Void UnityEngine.Rendering.Blitter::DrawTriangle(UnityEngine.Rendering.CommandBuffer,UnityEngine.Material,System.Int32)
extern void Blitter_DrawTriangle_m96C9657CFBFD17632584A0663AF00A73B12C009B (void);
// 0x00000665 System.Void UnityEngine.Rendering.Blitter::DrawQuad(UnityEngine.Rendering.CommandBuffer,UnityEngine.Material,System.Int32)
extern void Blitter_DrawQuad_m577F64758AB57805FAD01012FD8C97A2BABDA035 (void);
// 0x00000666 System.Void UnityEngine.Rendering.Blitter::BlitTexture(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RTHandle,UnityEngine.Vector4,System.Single,System.Boolean)
extern void Blitter_BlitTexture_mCE6C5259E6FC80F39D17499862DD3AEC31ADA534 (void);
// 0x00000667 System.Void UnityEngine.Rendering.Blitter::BlitTexture2D(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RTHandle,UnityEngine.Vector4,System.Single,System.Boolean)
extern void Blitter_BlitTexture2D_mDC79E2CB57C632E3F4382172AB75F63C9DDC7359 (void);
// 0x00000668 System.Void UnityEngine.Rendering.Blitter::BlitColorAndDepth(UnityEngine.Rendering.CommandBuffer,UnityEngine.Texture,UnityEngine.RenderTexture,UnityEngine.Vector4,System.Single,System.Boolean)
extern void Blitter_BlitColorAndDepth_mE53779B748F96B8A45F2ACA2F5838C6BAD18F00A (void);
// 0x00000669 System.Void UnityEngine.Rendering.Blitter::BlitTexture(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RTHandle,UnityEngine.Vector4,UnityEngine.Material,System.Int32)
extern void Blitter_BlitTexture_mDDF2CA8C4C33D434A8FBB60D796CC3B67F87C732 (void);
// 0x0000066A System.Void UnityEngine.Rendering.Blitter::BlitCameraTexture(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RTHandle,UnityEngine.Rendering.RTHandle,System.Single,System.Boolean)
extern void Blitter_BlitCameraTexture_m3F1485AE7C5731A5259C0DD2E6918219D5363BAC (void);
// 0x0000066B System.Void UnityEngine.Rendering.Blitter::BlitCameraTexture2D(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RTHandle,UnityEngine.Rendering.RTHandle,System.Single,System.Boolean)
extern void Blitter_BlitCameraTexture2D_m9BC6F13FA1CBE7C8B8B218E82DED130FE5649A2D (void);
// 0x0000066C System.Void UnityEngine.Rendering.Blitter::BlitCameraTexture(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RTHandle,UnityEngine.Rendering.RTHandle,UnityEngine.Material,System.Int32)
extern void Blitter_BlitCameraTexture_m4CD0B64F751ABDEAB2041D7C2F30D455D21FE71F (void);
// 0x0000066D System.Void UnityEngine.Rendering.Blitter::BlitCameraTexture(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RTHandle,UnityEngine.Rendering.RTHandle,UnityEngine.Vector4,System.Single,System.Boolean)
extern void Blitter_BlitCameraTexture_m7AB14A79F45722CF5E6A4D9CD2434814A4BF12AD (void);
// 0x0000066E System.Void UnityEngine.Rendering.Blitter::BlitCameraTexture(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RTHandle,UnityEngine.Rendering.RTHandle,UnityEngine.Rect,System.Single,System.Boolean)
extern void Blitter_BlitCameraTexture_mC74719097E5FE8C62249CD2C59F6E3B4986D83C6 (void);
// 0x0000066F System.Void UnityEngine.Rendering.Blitter::BlitQuad(UnityEngine.Rendering.CommandBuffer,UnityEngine.Texture,UnityEngine.Vector4,UnityEngine.Vector4,System.Int32,System.Boolean)
extern void Blitter_BlitQuad_mCBF7991C0C986458A76146822A145C2977359008 (void);
// 0x00000670 System.Void UnityEngine.Rendering.Blitter::BlitQuadWithPadding(UnityEngine.Rendering.CommandBuffer,UnityEngine.Texture,UnityEngine.Vector2,UnityEngine.Vector4,UnityEngine.Vector4,System.Int32,System.Boolean,System.Int32)
extern void Blitter_BlitQuadWithPadding_m85E33D5B48E3D2FCF8FDE7D6B83521BF8BC4AC0C (void);
// 0x00000671 System.Void UnityEngine.Rendering.Blitter::BlitQuadWithPaddingMultiply(UnityEngine.Rendering.CommandBuffer,UnityEngine.Texture,UnityEngine.Vector2,UnityEngine.Vector4,UnityEngine.Vector4,System.Int32,System.Boolean,System.Int32)
extern void Blitter_BlitQuadWithPaddingMultiply_m2432047128A86D8CAA3052FEB74619E0E0D71558 (void);
// 0x00000672 System.Void UnityEngine.Rendering.Blitter::BlitOctahedralWithPadding(UnityEngine.Rendering.CommandBuffer,UnityEngine.Texture,UnityEngine.Vector2,UnityEngine.Vector4,UnityEngine.Vector4,System.Int32,System.Boolean,System.Int32)
extern void Blitter_BlitOctahedralWithPadding_mE5AD943D0378F7BB5B535D7A68D1EE41654ACEC3 (void);
// 0x00000673 System.Void UnityEngine.Rendering.Blitter::BlitOctahedralWithPaddingMultiply(UnityEngine.Rendering.CommandBuffer,UnityEngine.Texture,UnityEngine.Vector2,UnityEngine.Vector4,UnityEngine.Vector4,System.Int32,System.Boolean,System.Int32)
extern void Blitter_BlitOctahedralWithPaddingMultiply_m27215AF98C85E90D39D298FB304DF27B1DC353E4 (void);
// 0x00000674 System.Void UnityEngine.Rendering.Blitter::BlitCubeToOctahedral2DQuad(UnityEngine.Rendering.CommandBuffer,UnityEngine.Texture,UnityEngine.Vector4,System.Int32)
extern void Blitter_BlitCubeToOctahedral2DQuad_m406F5BA9EAE4985E613E80465614FC051E16BB16 (void);
// 0x00000675 System.Void UnityEngine.Rendering.Blitter::BlitCubeToOctahedral2DQuadSingleChannel(UnityEngine.Rendering.CommandBuffer,UnityEngine.Texture,UnityEngine.Vector4,System.Int32)
extern void Blitter_BlitCubeToOctahedral2DQuadSingleChannel_m6A42740206DB7A4F66756D00E9054E3BFA7CEDC3 (void);
// 0x00000676 System.Void UnityEngine.Rendering.Blitter::BlitQuadSingleChannel(UnityEngine.Rendering.CommandBuffer,UnityEngine.Texture,UnityEngine.Vector4,UnityEngine.Vector4,System.Int32)
extern void Blitter_BlitQuadSingleChannel_mC14750B1B6DC1C7A1362ACDB112A2A72ED4D88C9 (void);
// 0x00000677 System.Void UnityEngine.Rendering.Blitter::.cctor()
extern void Blitter__cctor_m45E11ACBC4F705A5F8CC30D49BE421BFDB51BE2A (void);
// 0x00000678 UnityEngine.Vector3[] UnityEngine.Rendering.Blitter::<Initialize>g__GetFullScreenTriangleVertexPosition|8_0(System.Single)
extern void Blitter_U3CInitializeU3Eg__GetFullScreenTriangleVertexPositionU7C8_0_mCDED15E354E9F60A216FCD5027B7521183575FA0 (void);
// 0x00000679 UnityEngine.Vector2[] UnityEngine.Rendering.Blitter::<Initialize>g__GetFullScreenTriangleTexCoord|8_1()
extern void Blitter_U3CInitializeU3Eg__GetFullScreenTriangleTexCoordU7C8_1_m23B785ECE01FA6D217CD165A5FF3D5DAB12E98A9 (void);
// 0x0000067A UnityEngine.Vector3[] UnityEngine.Rendering.Blitter::<Initialize>g__GetQuadVertexPosition|8_2(System.Single)
extern void Blitter_U3CInitializeU3Eg__GetQuadVertexPositionU7C8_2_m22515FA8B1C1C002FF8364F55A1023C730D7784F (void);
// 0x0000067B UnityEngine.Vector2[] UnityEngine.Rendering.Blitter::<Initialize>g__GetQuadTexCoord|8_3()
extern void Blitter_U3CInitializeU3Eg__GetQuadTexCoordU7C8_3_mD5AE97A26B4D470981CA48A776E61813C645A638 (void);
// 0x0000067C System.Void UnityEngine.Rendering.Blitter/BlitShaderIDs::.cctor()
extern void BlitShaderIDs__cctor_m60EF46970735B8591A0AE5982A402557DD1C7E60 (void);
// 0x0000067D System.Boolean UnityEngine.Rendering.CameraCaptureBridge::get_enabled()
extern void CameraCaptureBridge_get_enabled_m31A62E528795334E5A0894BDF36EB1F09B1EA793 (void);
// 0x0000067E System.Void UnityEngine.Rendering.CameraCaptureBridge::set_enabled(System.Boolean)
extern void CameraCaptureBridge_set_enabled_m80055B22F08CB1BE8D850D32535BE260904FA6E5 (void);
// 0x0000067F System.Collections.Generic.IEnumerator`1<System.Action`2<UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.CommandBuffer>> UnityEngine.Rendering.CameraCaptureBridge::GetCaptureActions(UnityEngine.Camera)
extern void CameraCaptureBridge_GetCaptureActions_m94B65C4562A66D19BD66CCFCFFE42843E86D3117 (void);
// 0x00000680 System.Void UnityEngine.Rendering.CameraCaptureBridge::AddCaptureAction(UnityEngine.Camera,System.Action`2<UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.CommandBuffer>)
extern void CameraCaptureBridge_AddCaptureAction_m2E0FC4F221D3CBBA99C184FF1A01DCD6CB391429 (void);
// 0x00000681 System.Void UnityEngine.Rendering.CameraCaptureBridge::RemoveCaptureAction(UnityEngine.Camera,System.Action`2<UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.CommandBuffer>)
extern void CameraCaptureBridge_RemoveCaptureAction_m064D5E5E7FC0EDF4037E2C341FCEE32F3B50EEC0 (void);
// 0x00000682 System.Void UnityEngine.Rendering.CameraCaptureBridge::.cctor()
extern void CameraCaptureBridge__cctor_m3FBB4A85B914490F465ADF3063280D06365E362B (void);
// 0x00000683 System.Single UnityEngine.Rendering.ColorUtils::get_lensImperfectionExposureScale()
extern void ColorUtils_get_lensImperfectionExposureScale_m010ADD67B5701B40DED2B3E12AD32BCE5B093ADF (void);
// 0x00000684 System.Single UnityEngine.Rendering.ColorUtils::StandardIlluminantY(System.Single)
extern void ColorUtils_StandardIlluminantY_mFD230DBEFCB34E96CC10AC6D973A0785F94C334B (void);
// 0x00000685 UnityEngine.Vector3 UnityEngine.Rendering.ColorUtils::CIExyToLMS(System.Single,System.Single)
extern void ColorUtils_CIExyToLMS_mEF4695F158057988801E4D033A919BA1F9A6B74E (void);
// 0x00000686 UnityEngine.Vector3 UnityEngine.Rendering.ColorUtils::ColorBalanceToLMSCoeffs(System.Single,System.Single)
extern void ColorUtils_ColorBalanceToLMSCoeffs_mCD34C9A8E62064DADAAE9C49E73936E4248C65F7 (void);
// 0x00000687 System.ValueTuple`3<UnityEngine.Vector4,UnityEngine.Vector4,UnityEngine.Vector4> UnityEngine.Rendering.ColorUtils::PrepareShadowsMidtonesHighlights(UnityEngine.Vector4&,UnityEngine.Vector4&,UnityEngine.Vector4&)
extern void ColorUtils_PrepareShadowsMidtonesHighlights_m1BBF326D2A4386DD2A05CAFCAC4897D7E90E27AF (void);
// 0x00000688 System.ValueTuple`3<UnityEngine.Vector4,UnityEngine.Vector4,UnityEngine.Vector4> UnityEngine.Rendering.ColorUtils::PrepareLiftGammaGain(UnityEngine.Vector4&,UnityEngine.Vector4&,UnityEngine.Vector4&)
extern void ColorUtils_PrepareLiftGammaGain_m8DE08DF4B1C60AD451017945439ABC14EBA81D00 (void);
// 0x00000689 System.ValueTuple`2<UnityEngine.Vector4,UnityEngine.Vector4> UnityEngine.Rendering.ColorUtils::PrepareSplitToning(UnityEngine.Vector4&,UnityEngine.Vector4&,System.Single)
extern void ColorUtils_PrepareSplitToning_m411AEE689BFA3C919CA846EC6703948F7079056B (void);
// 0x0000068A System.Single UnityEngine.Rendering.ColorUtils::Luminance(UnityEngine.Color&)
extern void ColorUtils_Luminance_mF356655EDE24C312306A119C4509A9F15C1E7D02 (void);
// 0x0000068B System.Single UnityEngine.Rendering.ColorUtils::ComputeEV100(System.Single,System.Single,System.Single)
extern void ColorUtils_ComputeEV100_mC4D00D6BF6877A5737BA67D8AA8063191DF09231 (void);
// 0x0000068C System.Single UnityEngine.Rendering.ColorUtils::ConvertEV100ToExposure(System.Single)
extern void ColorUtils_ConvertEV100ToExposure_m3023C6FA9AA0763EE40ADF49BC1EC5170EC11E04 (void);
// 0x0000068D System.Single UnityEngine.Rendering.ColorUtils::ConvertExposureToEV100(System.Single)
extern void ColorUtils_ConvertExposureToEV100_m740ADE7309C04DF6B4D2A36457BE5CF0F8C4145A (void);
// 0x0000068E System.Single UnityEngine.Rendering.ColorUtils::ComputeEV100FromAvgLuminance(System.Single)
extern void ColorUtils_ComputeEV100FromAvgLuminance_mC12A1AA21540FF9F1DF1AA4516D3E95A05E6DCB4 (void);
// 0x0000068F System.Single UnityEngine.Rendering.ColorUtils::ComputeISO(System.Single,System.Single,System.Single)
extern void ColorUtils_ComputeISO_m5812533C3821469F706DD99CDEBB345B4C711B03 (void);
// 0x00000690 System.UInt32 UnityEngine.Rendering.ColorUtils::ToHex(UnityEngine.Color)
extern void ColorUtils_ToHex_m7D27910C357EF794ACB410EFD10D62C730F8FF52 (void);
// 0x00000691 UnityEngine.Color UnityEngine.Rendering.ColorUtils::ToRGBA(System.UInt32)
extern void ColorUtils_ToRGBA_m8303D8CD2828AA21EDE0192E1BD5F301625C48D1 (void);
// 0x00000692 System.Void UnityEngine.Rendering.ColorUtils::.cctor()
extern void ColorUtils__cctor_mC580048A58631243CC07B9A087F03D9298792F12 (void);
// 0x00000693 System.Void UnityEngine.Rendering.CoreMatrixUtils::MatrixTimesTranslation(UnityEngine.Matrix4x4&,UnityEngine.Vector3)
extern void CoreMatrixUtils_MatrixTimesTranslation_m23B43D3D63C1490BB9A079490D440ECFC26943FA (void);
// 0x00000694 System.Void UnityEngine.Rendering.CoreMatrixUtils::TranslationTimesMatrix(UnityEngine.Matrix4x4&,UnityEngine.Vector3)
extern void CoreMatrixUtils_TranslationTimesMatrix_m1D64B396FEBBA07A2619720BBD05976625B53C1F (void);
// 0x00000695 UnityEngine.Matrix4x4 UnityEngine.Rendering.CoreMatrixUtils::MultiplyPerspectiveMatrix(UnityEngine.Matrix4x4,UnityEngine.Matrix4x4)
extern void CoreMatrixUtils_MultiplyPerspectiveMatrix_m4674F50DAE5D50F2F92A400247C29B9065C2A576 (void);
// 0x00000696 UnityEngine.Matrix4x4 UnityEngine.Rendering.CoreMatrixUtils::MultiplyOrthoMatrixCentered(UnityEngine.Matrix4x4,UnityEngine.Matrix4x4)
extern void CoreMatrixUtils_MultiplyOrthoMatrixCentered_mD2863C48C17219ED31CA7AFAE19B82B2509518D0 (void);
// 0x00000697 UnityEngine.Matrix4x4 UnityEngine.Rendering.CoreMatrixUtils::MultiplyGenericOrthoMatrix(UnityEngine.Matrix4x4,UnityEngine.Matrix4x4)
extern void CoreMatrixUtils_MultiplyGenericOrthoMatrix_m53C5BA7BD6E9E62F1A0962B4999C5418D07A5A14 (void);
// 0x00000698 UnityEngine.Matrix4x4 UnityEngine.Rendering.CoreMatrixUtils::MultiplyOrthoMatrix(UnityEngine.Matrix4x4,UnityEngine.Matrix4x4,System.Boolean)
extern void CoreMatrixUtils_MultiplyOrthoMatrix_m778C48F70AEB68EE2699EF50745144A41E9D7612 (void);
// 0x00000699 UnityEngine.Matrix4x4 UnityEngine.Rendering.CoreMatrixUtils::MultiplyProjectionMatrix(UnityEngine.Matrix4x4,UnityEngine.Matrix4x4,System.Boolean)
extern void CoreMatrixUtils_MultiplyProjectionMatrix_mBA742A4025DC1C373B22FD60E77768FCDAD55678 (void);
// 0x0000069A UnityEngine.Cubemap UnityEngine.Rendering.CoreUtils::get_blackCubeTexture()
extern void CoreUtils_get_blackCubeTexture_m57766E4307BDAAA469A5BF2AFF9AE71C01E5015D (void);
// 0x0000069B UnityEngine.Cubemap UnityEngine.Rendering.CoreUtils::get_magentaCubeTexture()
extern void CoreUtils_get_magentaCubeTexture_m950639FD91B0DA84FE95F1C1054160E8EB47FE8F (void);
// 0x0000069C UnityEngine.CubemapArray UnityEngine.Rendering.CoreUtils::get_magentaCubeTextureArray()
extern void CoreUtils_get_magentaCubeTextureArray_mBB47BE385E4159F226D2BA318EB5D2DD0BF5B891 (void);
// 0x0000069D UnityEngine.Cubemap UnityEngine.Rendering.CoreUtils::get_whiteCubeTexture()
extern void CoreUtils_get_whiteCubeTexture_m3DFF82D157B5ADAB18C422007160170CDDB221A7 (void);
// 0x0000069E UnityEngine.RenderTexture UnityEngine.Rendering.CoreUtils::get_emptyUAV()
extern void CoreUtils_get_emptyUAV_m5971F9C81C7D6EBEC8B5CB10FB4AFA2B9B32CC89 (void);
// 0x0000069F UnityEngine.Texture3D UnityEngine.Rendering.CoreUtils::get_blackVolumeTexture()
extern void CoreUtils_get_blackVolumeTexture_mAC5B366BA94F2943C375E398B3FC280CF7B77214 (void);
// 0x000006A0 System.Void UnityEngine.Rendering.CoreUtils::ClearRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.ClearFlag,UnityEngine.Color)
extern void CoreUtils_ClearRenderTarget_m8D7F1299276232B80DB768A8F372C495A09F8103 (void);
// 0x000006A1 System.Int32 UnityEngine.Rendering.CoreUtils::FixupDepthSlice(System.Int32,UnityEngine.Rendering.RTHandle)
extern void CoreUtils_FixupDepthSlice_m2BFC1680099E788CE5E3C8710950266180290A17 (void);
// 0x000006A2 System.Int32 UnityEngine.Rendering.CoreUtils::FixupDepthSlice(System.Int32,UnityEngine.CubemapFace)
extern void CoreUtils_FixupDepthSlice_m867298EDF226CD749E87096C28F9581B8D235130 (void);
// 0x000006A3 System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.ClearFlag,UnityEngine.Color,System.Int32,UnityEngine.CubemapFace,System.Int32)
extern void CoreUtils_SetRenderTarget_m6CE0BBF5E5D16ED93D0FEAE483F3DB6A69ED3D8D (void);
// 0x000006A4 System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.ClearFlag,System.Int32,UnityEngine.CubemapFace,System.Int32)
extern void CoreUtils_SetRenderTarget_m6F98A950575D6AAAA280CBFD85495B7A554F367A (void);
// 0x000006A5 System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,System.Int32,UnityEngine.CubemapFace,System.Int32)
extern void CoreUtils_SetRenderTarget_mEEFF3082D095E30261FE5416357B1FB156B30E9B (void);
// 0x000006A6 System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.ClearFlag,System.Int32,UnityEngine.CubemapFace,System.Int32)
extern void CoreUtils_SetRenderTarget_mC737DD5F9CF60E7FC2D48EDCD4F7020A5C4D1502 (void);
// 0x000006A7 System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.ClearFlag,UnityEngine.Color,System.Int32,UnityEngine.CubemapFace,System.Int32)
extern void CoreUtils_SetRenderTarget_m929338F2F9D6CB3813526A5BA6409B54FD461B56 (void);
// 0x000006A8 System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier[],UnityEngine.Rendering.RenderTargetIdentifier)
extern void CoreUtils_SetRenderTarget_m138826BDE3B52178379A1D586AA6C114E64FE973 (void);
// 0x000006A9 System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier[],UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.ClearFlag)
extern void CoreUtils_SetRenderTarget_m0083869AE29068E193C72594E742DD18AD73C27E (void);
// 0x000006AA System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier[],UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.ClearFlag,UnityEngine.Color)
extern void CoreUtils_SetRenderTarget_m69ECACBA48FEC53BE5691E5A1F8F7B640DDABA37 (void);
// 0x000006AB System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction,UnityEngine.Rendering.ClearFlag,UnityEngine.Color)
extern void CoreUtils_SetRenderTarget_m7C82A292875AA22F474887FAF9129351DA7035B7 (void);
// 0x000006AC System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction,UnityEngine.Rendering.ClearFlag)
extern void CoreUtils_SetRenderTarget_m3B7236EA7455EB36DD24E9A4E283E9AC38B11E3E (void);
// 0x000006AD System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction,UnityEngine.Rendering.ClearFlag,UnityEngine.Color)
extern void CoreUtils_SetRenderTarget_m03DF45FB5DF653277879D290B90A284F6EFC2257 (void);
// 0x000006AE System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction,UnityEngine.Rendering.ClearFlag,UnityEngine.Color)
extern void CoreUtils_SetRenderTarget_m2516642B197452D4EF18B42C42193A820DBB9AAD (void);
// 0x000006AF System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction,UnityEngine.Rendering.ClearFlag)
extern void CoreUtils_SetRenderTarget_mA08D357B4CCFB91EFFE380E7282D0DC52938024D (void);
// 0x000006B0 System.Void UnityEngine.Rendering.CoreUtils::SetViewportAndClear(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RTHandle,UnityEngine.Rendering.ClearFlag,UnityEngine.Color)
extern void CoreUtils_SetViewportAndClear_m73C5B9E647E73062251839230C94D82E401CA712 (void);
// 0x000006B1 System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RTHandle,UnityEngine.Rendering.ClearFlag,UnityEngine.Color,System.Int32,UnityEngine.CubemapFace,System.Int32)
extern void CoreUtils_SetRenderTarget_m21FAE62EC0EE884521A2F8C0A94758CFB30D8A80 (void);
// 0x000006B2 System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RTHandle,UnityEngine.Rendering.ClearFlag,System.Int32,UnityEngine.CubemapFace,System.Int32)
extern void CoreUtils_SetRenderTarget_m8E1C5D42853E5D83DCB4D9AA899BE41CB4C2BDA8 (void);
// 0x000006B3 System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RTHandle,UnityEngine.Rendering.RTHandle,System.Int32,UnityEngine.CubemapFace,System.Int32)
extern void CoreUtils_SetRenderTarget_m16FE3A9C3F8775A82C3DF097DDBFCF6FEAF583AD (void);
// 0x000006B4 System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RTHandle,UnityEngine.Rendering.RTHandle,UnityEngine.Rendering.ClearFlag,System.Int32,UnityEngine.CubemapFace,System.Int32)
extern void CoreUtils_SetRenderTarget_m3A19887350C8A8D862A1B5A50DC30BE0629FBF9B (void);
// 0x000006B5 System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RTHandle,UnityEngine.Rendering.RTHandle,UnityEngine.Rendering.ClearFlag,UnityEngine.Color,System.Int32,UnityEngine.CubemapFace,System.Int32)
extern void CoreUtils_SetRenderTarget_mDBD8F90E95612618F02AA57FF827919E7E0E50BA (void);
// 0x000006B6 System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier[],UnityEngine.Rendering.RTHandle)
extern void CoreUtils_SetRenderTarget_mBEE62CA207D8EFA1B01BE64BC81F2E22C41280EB (void);
// 0x000006B7 System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier[],UnityEngine.Rendering.RTHandle,UnityEngine.Rendering.ClearFlag)
extern void CoreUtils_SetRenderTarget_mC2F20C9F8D78BFF96A924529457C5473A0D67090 (void);
// 0x000006B8 System.Void UnityEngine.Rendering.CoreUtils::SetRenderTarget(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RenderTargetIdentifier[],UnityEngine.Rendering.RTHandle,UnityEngine.Rendering.ClearFlag,UnityEngine.Color)
extern void CoreUtils_SetRenderTarget_mE276987C50257C39A3F838027B59A91C1A3C0FE6 (void);
// 0x000006B9 System.Void UnityEngine.Rendering.CoreUtils::SetViewport(UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RTHandle)
extern void CoreUtils_SetViewport_m92C82E5708AB8C69C3F2A02A5398929A7FCA2F8C (void);
// 0x000006BA System.String UnityEngine.Rendering.CoreUtils::GetRenderTargetAutoName(System.Int32,System.Int32,System.Int32,UnityEngine.RenderTextureFormat,System.String,System.Boolean,System.Boolean,UnityEngine.Rendering.MSAASamples)
extern void CoreUtils_GetRenderTargetAutoName_m53CCC53CB33DF2917FE8B2927EC479AF17E74B57 (void);
// 0x000006BB System.String UnityEngine.Rendering.CoreUtils::GetRenderTargetAutoName(System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,System.String,System.Boolean,System.Boolean,UnityEngine.Rendering.MSAASamples)
extern void CoreUtils_GetRenderTargetAutoName_m8B3FC796A9869D3EC31497190FCF1BC83BD6A5F6 (void);
// 0x000006BC System.String UnityEngine.Rendering.CoreUtils::GetRenderTargetAutoName(System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Rendering.TextureDimension,System.String,System.Boolean,System.Boolean,UnityEngine.Rendering.MSAASamples,System.Boolean)
extern void CoreUtils_GetRenderTargetAutoName_m19285318502CDF11B7E15A45844D4D2814440D33 (void);
// 0x000006BD System.String UnityEngine.Rendering.CoreUtils::GetRenderTargetAutoName(System.Int32,System.Int32,System.Int32,System.String,UnityEngine.Rendering.TextureDimension,System.String,System.Boolean,System.Boolean,UnityEngine.Rendering.MSAASamples,System.Boolean)
extern void CoreUtils_GetRenderTargetAutoName_m6ED1EFF259EB08ECAB656DBEFEA3C04C3788E2F9 (void);
// 0x000006BE System.String UnityEngine.Rendering.CoreUtils::GetTextureAutoName(System.Int32,System.Int32,UnityEngine.TextureFormat,UnityEngine.Rendering.TextureDimension,System.String,System.Boolean,System.Int32)
extern void CoreUtils_GetTextureAutoName_mDD7EDBAD7F7F3C66018989C89D1487F37305875E (void);
// 0x000006BF System.String UnityEngine.Rendering.CoreUtils::GetTextureAutoName(System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Rendering.TextureDimension,System.String,System.Boolean,System.Int32)
extern void CoreUtils_GetTextureAutoName_m1BAA4A0E7F36BCBAA011CFBBE9A4DBB251EA9803 (void);
// 0x000006C0 System.String UnityEngine.Rendering.CoreUtils::GetTextureAutoName(System.Int32,System.Int32,System.String,UnityEngine.Rendering.TextureDimension,System.String,System.Boolean,System.Int32)
extern void CoreUtils_GetTextureAutoName_m7E0742D6C5C6537DA118ED3D575FD92E52D9A4CA (void);
// 0x000006C1 System.Void UnityEngine.Rendering.CoreUtils::ClearCubemap(UnityEngine.Rendering.CommandBuffer,UnityEngine.RenderTexture,UnityEngine.Color,System.Boolean)
extern void CoreUtils_ClearCubemap_mAD098131D233101899796B39552A945518E5D02F (void);
// 0x000006C2 System.Void UnityEngine.Rendering.CoreUtils::DrawFullScreen(UnityEngine.Rendering.CommandBuffer,UnityEngine.Material,UnityEngine.MaterialPropertyBlock,System.Int32)
extern void CoreUtils_DrawFullScreen_mB804E8C68BB78F402C36CCDC75F13FB0708D7F30 (void);
// 0x000006C3 System.Void UnityEngine.Rendering.CoreUtils::DrawFullScreen(UnityEngine.Rendering.CommandBuffer,UnityEngine.Material,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.MaterialPropertyBlock,System.Int32)
extern void CoreUtils_DrawFullScreen_m0463B1ED1EBE8A4D374DF2B12F5482473BE6CD30 (void);
// 0x000006C4 System.Void UnityEngine.Rendering.CoreUtils::DrawFullScreen(UnityEngine.Rendering.CommandBuffer,UnityEngine.Material,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.MaterialPropertyBlock,System.Int32)
extern void CoreUtils_DrawFullScreen_m15EB480803B7BD1189ABB4CE8792CCD2334ABFDA (void);
// 0x000006C5 System.Void UnityEngine.Rendering.CoreUtils::DrawFullScreen(UnityEngine.Rendering.CommandBuffer,UnityEngine.Material,UnityEngine.Rendering.RenderTargetIdentifier[],UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.MaterialPropertyBlock,System.Int32)
extern void CoreUtils_DrawFullScreen_m7D1D649DE10628F304644AD43659B0E8A4681AD7 (void);
// 0x000006C6 System.Void UnityEngine.Rendering.CoreUtils::DrawFullScreen(UnityEngine.Rendering.CommandBuffer,UnityEngine.Material,UnityEngine.Rendering.RenderTargetIdentifier[],UnityEngine.MaterialPropertyBlock,System.Int32)
extern void CoreUtils_DrawFullScreen_m82DA00DB70D9F75C1630B7CA0424F6ACE1C1FE9B (void);
// 0x000006C7 UnityEngine.Color UnityEngine.Rendering.CoreUtils::ConvertSRGBToActiveColorSpace(UnityEngine.Color)
extern void CoreUtils_ConvertSRGBToActiveColorSpace_m5CFB24D7E2DEF496FD2B4FE02EF95FFF7C3E80AD (void);
// 0x000006C8 UnityEngine.Color UnityEngine.Rendering.CoreUtils::ConvertLinearToActiveColorSpace(UnityEngine.Color)
extern void CoreUtils_ConvertLinearToActiveColorSpace_m54A871040A0AA45F009CCE3D34490409F60AE908 (void);
// 0x000006C9 UnityEngine.Material UnityEngine.Rendering.CoreUtils::CreateEngineMaterial(System.String)
extern void CoreUtils_CreateEngineMaterial_m34B5A3DC1142E177DA75BA6071A585798ED95E5A (void);
// 0x000006CA UnityEngine.Material UnityEngine.Rendering.CoreUtils::CreateEngineMaterial(UnityEngine.Shader)
extern void CoreUtils_CreateEngineMaterial_mAA09043C35B14C19847AD32F4864260DCE381791 (void);
// 0x000006CB System.Boolean UnityEngine.Rendering.CoreUtils::HasFlag(T,T)
// 0x000006CC System.Void UnityEngine.Rendering.CoreUtils::Swap(T&,T&)
// 0x000006CD System.Void UnityEngine.Rendering.CoreUtils::SetKeyword(UnityEngine.Rendering.CommandBuffer,System.String,System.Boolean)
extern void CoreUtils_SetKeyword_m491002FF7BF17F6C0EDFE60D456DB424CC221FA2 (void);
// 0x000006CE System.Void UnityEngine.Rendering.CoreUtils::SetKeyword(UnityEngine.Material,System.String,System.Boolean)
extern void CoreUtils_SetKeyword_m32774A5307241CBA36042A0ADC4385D1FB998710 (void);
// 0x000006CF System.Void UnityEngine.Rendering.CoreUtils::SetKeyword(UnityEngine.ComputeShader,System.String,System.Boolean)
extern void CoreUtils_SetKeyword_m70CC262562C483EAE444FCF610684E18D4DE82EB (void);
// 0x000006D0 System.Void UnityEngine.Rendering.CoreUtils::Destroy(UnityEngine.Object)
extern void CoreUtils_Destroy_mE6CB8C65A5BA214BE6B7788F2AE388723D7EAC65 (void);
// 0x000006D1 System.Collections.Generic.IEnumerable`1<System.Type> UnityEngine.Rendering.CoreUtils::GetAllAssemblyTypes()
extern void CoreUtils_GetAllAssemblyTypes_mDBDF1257E7266F7002AA7297415F24EB7F148211 (void);
// 0x000006D2 System.Collections.Generic.IEnumerable`1<System.Type> UnityEngine.Rendering.CoreUtils::GetAllTypesDerivedFrom()
// 0x000006D3 System.Void UnityEngine.Rendering.CoreUtils::SafeRelease(UnityEngine.ComputeBuffer)
extern void CoreUtils_SafeRelease_mC80169C4ECDE45459608C6645DDD7C63F3B779D4 (void);
// 0x000006D4 UnityEngine.Mesh UnityEngine.Rendering.CoreUtils::CreateCubeMesh(UnityEngine.Vector3,UnityEngine.Vector3)
extern void CoreUtils_CreateCubeMesh_mBED721BD2C0D62378BF6DB95F8DBA744A918D1B0 (void);
// 0x000006D5 System.Boolean UnityEngine.Rendering.CoreUtils::ArePostProcessesEnabled(UnityEngine.Camera)
extern void CoreUtils_ArePostProcessesEnabled_m415BD9B645BEFB3C4815F3BACECDAAC3206500D8 (void);
// 0x000006D6 System.Boolean UnityEngine.Rendering.CoreUtils::AreAnimatedMaterialsEnabled(UnityEngine.Camera)
extern void CoreUtils_AreAnimatedMaterialsEnabled_mF9DEB7F5F3190310E4A24F2A84A8441C3E45BA25 (void);
// 0x000006D7 System.Boolean UnityEngine.Rendering.CoreUtils::IsSceneLightingDisabled(UnityEngine.Camera)
extern void CoreUtils_IsSceneLightingDisabled_m4555A3DEC018BBEC1AF8C8414267E9BEAA2E9C3C (void);
// 0x000006D8 System.Boolean UnityEngine.Rendering.CoreUtils::IsLightOverlapDebugEnabled(UnityEngine.Camera)
extern void CoreUtils_IsLightOverlapDebugEnabled_m6C8280778303F3F2C98737110A73502735C3884D (void);
// 0x000006D9 System.Boolean UnityEngine.Rendering.CoreUtils::IsSceneViewFogEnabled(UnityEngine.Camera)
extern void CoreUtils_IsSceneViewFogEnabled_m98CA6228158DACCC6E99E1AF0B8F98C99638A7FC (void);
// 0x000006DA System.Boolean UnityEngine.Rendering.CoreUtils::IsSceneFilteringEnabled()
extern void CoreUtils_IsSceneFilteringEnabled_mB0F7A9BC472A8EC3A9EF462E2407230CEB5D0C15 (void);
// 0x000006DB System.Void UnityEngine.Rendering.CoreUtils::DrawRendererList(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.CommandBuffer,UnityEngine.Experimental.Rendering.RendererList)
extern void CoreUtils_DrawRendererList_mC201FC8EAA8924BD19EC90085F054EB1EA94E8ED (void);
// 0x000006DC System.Void UnityEngine.Rendering.CoreUtils::DrawRendererList(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Rendering.CommandBuffer,UnityEngine.Rendering.RendererUtils.RendererList)
extern void CoreUtils_DrawRendererList_m072BB1E8D0EADE4C99888FB33B13FC59ECA52496 (void);
// 0x000006DD System.Int32 UnityEngine.Rendering.CoreUtils::GetTextureHash(UnityEngine.Texture)
extern void CoreUtils_GetTextureHash_m5F6B2346A6C7C45663765F0256AADA1D46C9B300 (void);
// 0x000006DE System.Int32 UnityEngine.Rendering.CoreUtils::PreviousPowerOfTwo(System.Int32)
extern void CoreUtils_PreviousPowerOfTwo_mE2BCF2C5BDA5E45A6269A2CF82E27C1D36C31350 (void);
// 0x000006DF T UnityEngine.Rendering.CoreUtils::GetLastEnumValue()
// 0x000006E0 System.String UnityEngine.Rendering.CoreUtils::GetCorePath()
extern void CoreUtils_GetCorePath_m3D173E546A282CCA64560B2915C916957915B7BD (void);
// 0x000006E1 System.Void UnityEngine.Rendering.CoreUtils::.cctor()
extern void CoreUtils__cctor_m75AA14595D6A8F4E2048E1C51CBE3FD37B8BAE66 (void);
// 0x000006E2 System.Void UnityEngine.Rendering.CoreUtils/<>c::.cctor()
extern void U3CU3Ec__cctor_mFAFD8AC18E5BF973FAD94A967354EDFDE2A0CC16 (void);
// 0x000006E3 System.Void UnityEngine.Rendering.CoreUtils/<>c::.ctor()
extern void U3CU3Ec__ctor_m63FCDA748E14E0F9C9219BC0BDC490716CA2207C (void);
// 0x000006E4 System.Collections.Generic.IEnumerable`1<System.Type> UnityEngine.Rendering.CoreUtils/<>c::<GetAllAssemblyTypes>b__81_0(System.Reflection.Assembly)
extern void U3CU3Ec_U3CGetAllAssemblyTypesU3Eb__81_0_m49BAC9B1A4D1E04F4AB5B5A08D1804D4C80887FC (void);
// 0x000006E5 System.Void UnityEngine.Rendering.CoreUtils/<>c__82`1::.cctor()
// 0x000006E6 System.Void UnityEngine.Rendering.CoreUtils/<>c__82`1::.ctor()
// 0x000006E7 System.Boolean UnityEngine.Rendering.CoreUtils/<>c__82`1::<GetAllTypesDerivedFrom>b__82_0(System.Type)
// 0x000006E8 System.Delegate UnityEngine.Rendering.DelegateUtility::Cast(System.Delegate,System.Type)
extern void DelegateUtility_Cast_m7C8232312728679EE6DC10DD0150159495C92B1B (void);
// 0x000006E9 System.Single UnityEngine.Rendering.HableCurve::get_whitePoint()
extern void HableCurve_get_whitePoint_m4ED2079F06DAD46C16148C39EC95CBEF2305462C (void);
// 0x000006EA System.Void UnityEngine.Rendering.HableCurve::set_whitePoint(System.Single)
extern void HableCurve_set_whitePoint_m178C9CC10D68A74D67DFB3A167EFA72911615BC0 (void);
// 0x000006EB System.Single UnityEngine.Rendering.HableCurve::get_inverseWhitePoint()
extern void HableCurve_get_inverseWhitePoint_m5F59401B566306A949B32D661F869075981E50DA (void);
// 0x000006EC System.Void UnityEngine.Rendering.HableCurve::set_inverseWhitePoint(System.Single)
extern void HableCurve_set_inverseWhitePoint_m1A0666ED505D2CE050EB41256F9F5295A2286820 (void);
// 0x000006ED System.Single UnityEngine.Rendering.HableCurve::get_x0()
extern void HableCurve_get_x0_m6B5D5E0670C8B9CBEEC20B68A75DB35BC1C6E509 (void);
// 0x000006EE System.Void UnityEngine.Rendering.HableCurve::set_x0(System.Single)
extern void HableCurve_set_x0_m23752EEB60CAFE7B808783F8C21139157C9CA3BB (void);
// 0x000006EF System.Single UnityEngine.Rendering.HableCurve::get_x1()
extern void HableCurve_get_x1_m6C889E5A754B5BA6439F913BA64A4A053F8BE1A2 (void);
// 0x000006F0 System.Void UnityEngine.Rendering.HableCurve::set_x1(System.Single)
extern void HableCurve_set_x1_m6D171AB75E179893656FB10E41AA73E50DA498B6 (void);
// 0x000006F1 System.Void UnityEngine.Rendering.HableCurve::.ctor()
extern void HableCurve__ctor_mD8850D35C1BD379C30FEFAB2907D89708FD95564 (void);
// 0x000006F2 System.Single UnityEngine.Rendering.HableCurve::Eval(System.Single)
extern void HableCurve_Eval_mCF80F93ED7637D742B04B5212A29EA981FF84ED8 (void);
// 0x000006F3 System.Void UnityEngine.Rendering.HableCurve::Init(System.Single,System.Single,System.Single,System.Single,System.Single,System.Single)
extern void HableCurve_Init_m3C28DA7DD1F46E1BF41A6A1B7FE2ACB2ED9F3F21 (void);
// 0x000006F4 System.Void UnityEngine.Rendering.HableCurve::InitSegments(UnityEngine.Rendering.HableCurve/DirectParams)
extern void HableCurve_InitSegments_m934CDA943CD74A520E387BEF57E6821279A6CB02 (void);
// 0x000006F5 System.Void UnityEngine.Rendering.HableCurve::SolveAB(System.Single&,System.Single&,System.Single,System.Single,System.Single)
extern void HableCurve_SolveAB_m92A4CDE2D58A4B13FFE40416B8A2092CE579E1B0 (void);
// 0x000006F6 System.Void UnityEngine.Rendering.HableCurve::AsSlopeIntercept(System.Single&,System.Single&,System.Single,System.Single,System.Single,System.Single)
extern void HableCurve_AsSlopeIntercept_mCF42D98D9AA26AFD4BD4F84BE46C562C1B44E7FC (void);
// 0x000006F7 System.Single UnityEngine.Rendering.HableCurve::EvalDerivativeLinearGamma(System.Single,System.Single,System.Single,System.Single)
extern void HableCurve_EvalDerivativeLinearGamma_mCB43DA2C80D623957C9226E8901EF35F9DBD5028 (void);
// 0x000006F8 System.Single UnityEngine.Rendering.HableCurve/Segment::Eval(System.Single)
extern void Segment_Eval_m9B9E078B5AAD56567D62AFCDA502B313C9954FCD (void);
// 0x000006F9 System.Void UnityEngine.Rendering.HableCurve/Segment::.ctor()
extern void Segment__ctor_m3BD236F840ED5C6DFE5FFA54BC6B86C9D12C5457 (void);
// 0x000006FA System.Void UnityEngine.Rendering.HableCurve/Uniforms::.ctor(UnityEngine.Rendering.HableCurve)
extern void Uniforms__ctor_mBEA943A03EC891EB56969AFAF36E54BC9D5F125C (void);
// 0x000006FB UnityEngine.Vector4 UnityEngine.Rendering.HableCurve/Uniforms::get_curve()
extern void Uniforms_get_curve_m4E9B26978696D7175E4E57754125CDFC9F6CCEEF (void);
// 0x000006FC UnityEngine.Vector4 UnityEngine.Rendering.HableCurve/Uniforms::get_toeSegmentA()
extern void Uniforms_get_toeSegmentA_mECE73BE08EAC2967E4DEF4AAC78BA7B71AFE458E (void);
// 0x000006FD UnityEngine.Vector4 UnityEngine.Rendering.HableCurve/Uniforms::get_toeSegmentB()
extern void Uniforms_get_toeSegmentB_m034FF8C7447281256A8621187D7266FC50335DA0 (void);
// 0x000006FE UnityEngine.Vector4 UnityEngine.Rendering.HableCurve/Uniforms::get_midSegmentA()
extern void Uniforms_get_midSegmentA_m2CA374C5C02D1EF77615192DC04E8F5BAA05A8A9 (void);
// 0x000006FF UnityEngine.Vector4 UnityEngine.Rendering.HableCurve/Uniforms::get_midSegmentB()
extern void Uniforms_get_midSegmentB_m9E284F3B0F3BEC58343B10D29504FAACD01A5145 (void);
// 0x00000700 UnityEngine.Vector4 UnityEngine.Rendering.HableCurve/Uniforms::get_shoSegmentA()
extern void Uniforms_get_shoSegmentA_mD7459F493CBA1AAEAF21CD40919DAD00BD20804B (void);
// 0x00000701 UnityEngine.Vector4 UnityEngine.Rendering.HableCurve/Uniforms::get_shoSegmentB()
extern void Uniforms_get_shoSegmentB_mACCC8C284E2464874C5641726F4B963867934472 (void);
// 0x00000702 System.Single UnityEngine.Rendering.HaltonSequence::Get(System.Int32,System.Int32)
extern void HaltonSequence_Get_m3049054912DE115D0379D13190046BB03DF47CDA (void);
// 0x00000703 UnityEngine.Rendering.MaterialQuality UnityEngine.Rendering.MaterialQualityUtilities::GetHighestQuality(UnityEngine.Rendering.MaterialQuality)
extern void MaterialQualityUtilities_GetHighestQuality_m6DCA350DFA22C7DCD8062D826A1FFA99B0762E0E (void);
// 0x00000704 UnityEngine.Rendering.MaterialQuality UnityEngine.Rendering.MaterialQualityUtilities::GetClosestQuality(UnityEngine.Rendering.MaterialQuality,UnityEngine.Rendering.MaterialQuality)
extern void MaterialQualityUtilities_GetClosestQuality_mD07507CECEACD6E8BA4518DEE37DCC681FAE7D4D (void);
// 0x00000705 System.Void UnityEngine.Rendering.MaterialQualityUtilities::SetGlobalShaderKeywords(UnityEngine.Rendering.MaterialQuality)
extern void MaterialQualityUtilities_SetGlobalShaderKeywords_m5CDA681853E4131EE913EAA59BF499E71C546333 (void);
// 0x00000706 System.Void UnityEngine.Rendering.MaterialQualityUtilities::SetGlobalShaderKeywords(UnityEngine.Rendering.MaterialQuality,UnityEngine.Rendering.CommandBuffer)
extern void MaterialQualityUtilities_SetGlobalShaderKeywords_m34D1ADC3D4DFEF2B84B4A0091449B504DF749423 (void);
// 0x00000707 System.Int32 UnityEngine.Rendering.MaterialQualityUtilities::ToFirstIndex(UnityEngine.Rendering.MaterialQuality)
extern void MaterialQualityUtilities_ToFirstIndex_m63F534D84D7A3604D109965E0A656F22A5C6C0A1 (void);
// 0x00000708 UnityEngine.Rendering.MaterialQuality UnityEngine.Rendering.MaterialQualityUtilities::FromIndex(System.Int32)
extern void MaterialQualityUtilities_FromIndex_m38CCD6AAA9914A7CAB83E6D0B800F912D132B6B2 (void);
// 0x00000709 System.Void UnityEngine.Rendering.MaterialQualityUtilities::.cctor()
extern void MaterialQualityUtilities__cctor_mF4B3C5EEFB133019CD4241244FC5E6B436016D79 (void);
// 0x0000070A System.Void UnityEngine.Rendering.MeshGizmo::.ctor(System.Int32)
extern void MeshGizmo__ctor_m59D912AE9D2EF001AE92CE0E6C848B1BF3DDCD3B (void);
// 0x0000070B System.Void UnityEngine.Rendering.MeshGizmo::Clear()
extern void MeshGizmo_Clear_m5E847CC0D5F8C16E2C5BB97BD4005BF5147F4031 (void);
// 0x0000070C System.Void UnityEngine.Rendering.MeshGizmo::AddWireCube(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Color)
extern void MeshGizmo_AddWireCube_m723795D9A503E7C9218F0DDAB2A196FF4756E5D9 (void);
// 0x0000070D System.Void UnityEngine.Rendering.MeshGizmo::DrawMesh(UnityEngine.Matrix4x4,UnityEngine.Material,UnityEngine.MeshTopology,UnityEngine.Rendering.CompareFunction,System.String)
extern void MeshGizmo_DrawMesh_m51F998C29B5BB02DCC77497F1781D387E0891E03 (void);
// 0x0000070E System.Void UnityEngine.Rendering.MeshGizmo::RenderWireframe(UnityEngine.Matrix4x4,UnityEngine.Rendering.CompareFunction,System.String)
extern void MeshGizmo_RenderWireframe_m87941903D49C3AA5AFA04A8AB8A282F6AF00C430 (void);
// 0x0000070F System.Void UnityEngine.Rendering.MeshGizmo::Dispose()
extern void MeshGizmo_Dispose_mFE7AB5D16D81E1C986E64BC5B612EEAF668145BB (void);
// 0x00000710 System.Void UnityEngine.Rendering.MeshGizmo::.cctor()
extern void MeshGizmo__cctor_m1052539AC0F41748EA861BFCE055BF54C1817526 (void);
// 0x00000711 System.Void UnityEngine.Rendering.MeshGizmo::<AddWireCube>g__AddEdge|10_0(UnityEngine.Vector3,UnityEngine.Vector3,UnityEngine.Rendering.MeshGizmo/<>c__DisplayClass10_0&)
extern void MeshGizmo_U3CAddWireCubeU3Eg__AddEdgeU7C10_0_mA0BE9440782DC696EC3246591D8EF5BBFB315B4D (void);
// 0x00000712 System.Void UnityEngine.Rendering.ReloadAttribute::.ctor(System.String[],UnityEngine.Rendering.ReloadAttribute/Package)
extern void ReloadAttribute__ctor_m2F8424FF3711E1D39A46E4F5CDBBB398403862BA (void);
// 0x00000713 System.Void UnityEngine.Rendering.ReloadAttribute::.ctor(System.String,UnityEngine.Rendering.ReloadAttribute/Package)
extern void ReloadAttribute__ctor_m455053E20E4919190C8D730FA407CBBFD04954D5 (void);
// 0x00000714 System.Void UnityEngine.Rendering.ReloadAttribute::.ctor(System.String,System.Int32,System.Int32,UnityEngine.Rendering.ReloadAttribute/Package)
extern void ReloadAttribute__ctor_m003D5F3B4BFD559042B47110AE491BBD204A9129 (void);
// 0x00000715 System.Void UnityEngine.Rendering.ReloadGroupAttribute::.ctor()
extern void ReloadGroupAttribute__ctor_m2CA4E9B6F8D9958E4518CDE9E50041482F2415EB (void);
// 0x00000716 System.Int32 UnityEngine.Rendering.TextureCurve::get_length()
extern void TextureCurve_get_length_m782E158DA1DCF67FCB1E87FB4FAA73F3F925F2BE (void);
// 0x00000717 System.Void UnityEngine.Rendering.TextureCurve::set_length(System.Int32)
extern void TextureCurve_set_length_mC14849BC756150B20666024F26855DCF1BCC2E4C (void);
// 0x00000718 UnityEngine.Keyframe UnityEngine.Rendering.TextureCurve::get_Item(System.Int32)
extern void TextureCurve_get_Item_m6F977BB96BF70DE9A5C9F7B65EE96B616F81F356 (void);
// 0x00000719 System.Void UnityEngine.Rendering.TextureCurve::.ctor(UnityEngine.AnimationCurve,System.Single,System.Boolean,UnityEngine.Vector2&)
extern void TextureCurve__ctor_m0D4F2EFA617C6906A248D6D19AF43EE72BEC3E33 (void);
// 0x0000071A System.Void UnityEngine.Rendering.TextureCurve::.ctor(UnityEngine.Keyframe[],System.Single,System.Boolean,UnityEngine.Vector2&)
extern void TextureCurve__ctor_mEDE480C070DD74CECD663A2573F549C27566CEFF (void);
// 0x0000071B System.Void UnityEngine.Rendering.TextureCurve::Finalize()
extern void TextureCurve_Finalize_m9A483B2870325BC142982D6CAEC0191F6DD4A8CB (void);
// 0x0000071C System.Void UnityEngine.Rendering.TextureCurve::Dispose()
extern void TextureCurve_Dispose_mFBA215E12C4830A1642EE45C3931320E4FBFA895 (void);
// 0x0000071D System.Void UnityEngine.Rendering.TextureCurve::Release()
extern void TextureCurve_Release_mAC8365162C577183C3CDF8FA9BA2410E963D497A (void);
// 0x0000071E System.Void UnityEngine.Rendering.TextureCurve::SetDirty()
extern void TextureCurve_SetDirty_mB9C387DE227B5B94937B19FD1125C2D5FEFC501F (void);
// 0x0000071F UnityEngine.Experimental.Rendering.GraphicsFormat UnityEngine.Rendering.TextureCurve::GetTextureFormat()
extern void TextureCurve_GetTextureFormat_mB1F8D8AE2AD4AFAEDEFC3390658598E3945F8255 (void);
// 0x00000720 UnityEngine.Texture2D UnityEngine.Rendering.TextureCurve::GetTexture()
extern void TextureCurve_GetTexture_m24AA2C84F80EF15DADF73903E4699234BBBDA6DB (void);
// 0x00000721 System.Single UnityEngine.Rendering.TextureCurve::Evaluate(System.Single)
extern void TextureCurve_Evaluate_m02868520B678BDAE582E9D2A3EA243B20624AF2B (void);
// 0x00000722 System.Int32 UnityEngine.Rendering.TextureCurve::AddKey(System.Single,System.Single)
extern void TextureCurve_AddKey_m02CEE561F77061709C32F5087CCAA6A200A9F187 (void);
// 0x00000723 System.Int32 UnityEngine.Rendering.TextureCurve::MoveKey(System.Int32,UnityEngine.Keyframe&)
extern void TextureCurve_MoveKey_m4E07DDD361B7016563D092BF072A8215B741E5E9 (void);
// 0x00000724 System.Void UnityEngine.Rendering.TextureCurve::RemoveKey(System.Int32)
extern void TextureCurve_RemoveKey_m32D21D2B80F0E053100FAF82E567C1DFAE94DB60 (void);
// 0x00000725 System.Void UnityEngine.Rendering.TextureCurve::SmoothTangents(System.Int32,System.Single)
extern void TextureCurve_SmoothTangents_m24C847A870703BF0DFA7F577D4484E5D334A8DDE (void);
// 0x00000726 System.Void UnityEngine.Rendering.TextureCurveParameter::.ctor(UnityEngine.Rendering.TextureCurve,System.Boolean)
extern void TextureCurveParameter__ctor_m935E3FB0FF6318680EEF7D96081D576D5864D886 (void);
// 0x00000727 System.Void UnityEngine.Rendering.TextureCurveParameter::Release()
extern void TextureCurveParameter_Release_mF74E8BB7621ADD4F5A877911D8BCD8876FFBA2DB (void);
// 0x00000728 System.Boolean UnityEngine.Rendering.TileLayoutUtils::TryLayoutByTiles(UnityEngine.RectInt,System.UInt32,UnityEngine.RectInt&,UnityEngine.RectInt&,UnityEngine.RectInt&,UnityEngine.RectInt&)
extern void TileLayoutUtils_TryLayoutByTiles_m544B85EA1C124107699C41E255C21BB2EC0534AA (void);
// 0x00000729 System.Boolean UnityEngine.Rendering.TileLayoutUtils::TryLayoutByRow(UnityEngine.RectInt,System.UInt32,UnityEngine.RectInt&,UnityEngine.RectInt&)
extern void TileLayoutUtils_TryLayoutByRow_mF2190BCFB19C0CA99DC329CB0B88D1696181B030 (void);
// 0x0000072A System.Boolean UnityEngine.Rendering.TileLayoutUtils::TryLayoutByCol(UnityEngine.RectInt,System.UInt32,UnityEngine.RectInt&,UnityEngine.RectInt&)
extern void TileLayoutUtils_TryLayoutByCol_m05DF2D984DC2204F08AD8E1610C804A03319F5BB (void);
// 0x0000072B System.Void UnityEngine.Rendering.XRUtils::DrawOcclusionMesh(UnityEngine.Rendering.CommandBuffer,UnityEngine.Camera,System.Boolean)
extern void XRUtils_DrawOcclusionMesh_mE70EF55D6E0A824FCAECAC17B72D8B108DC806F2 (void);
// 0x0000072C System.Boolean UnityEngine.Rendering.IVolume::get_isGlobal()
// 0x0000072D System.Void UnityEngine.Rendering.IVolume::set_isGlobal(System.Boolean)
// 0x0000072E System.Collections.Generic.List`1<UnityEngine.Collider> UnityEngine.Rendering.IVolume::get_colliders()
// 0x0000072F System.Boolean UnityEngine.Rendering.Volume::get_isGlobal()
extern void Volume_get_isGlobal_m09C1E1FB39D06DD9EC78DF276DE9A1FBE3E42763 (void);
// 0x00000730 System.Void UnityEngine.Rendering.Volume::set_isGlobal(System.Boolean)
extern void Volume_set_isGlobal_m5E2B89583386E5A6C63AD61D2A8DBCAB5533BF15 (void);
// 0x00000731 UnityEngine.Rendering.VolumeProfile UnityEngine.Rendering.Volume::get_profile()
extern void Volume_get_profile_mB157C4D67D52CE6D3E8211D6587B0EF71102E43D (void);
// 0x00000732 System.Void UnityEngine.Rendering.Volume::set_profile(UnityEngine.Rendering.VolumeProfile)
extern void Volume_set_profile_m89709CBB66123E4DD821570E2CC4D9AE3D42E769 (void);
// 0x00000733 System.Collections.Generic.List`1<UnityEngine.Collider> UnityEngine.Rendering.Volume::get_colliders()
extern void Volume_get_colliders_m0950CE61A71643C572215A4598F769824E1C2E4C (void);
// 0x00000734 UnityEngine.Rendering.VolumeProfile UnityEngine.Rendering.Volume::get_profileRef()
extern void Volume_get_profileRef_mE3A46DB4994923FE1B7E12987DD09462AEE7CCCE (void);
// 0x00000735 System.Boolean UnityEngine.Rendering.Volume::HasInstantiatedProfile()
extern void Volume_HasInstantiatedProfile_mA1547160C1B93EC28AB7FDBDD23ED967B9B7A8F4 (void);
// 0x00000736 System.Void UnityEngine.Rendering.Volume::OnEnable()
extern void Volume_OnEnable_mC8C06B2F8E7BAEC731FDC11C098FD1CBED1C38DA (void);
// 0x00000737 System.Void UnityEngine.Rendering.Volume::OnDisable()
extern void Volume_OnDisable_m84BF8533696B6CF5EAA648CD89A0ACC6BFA90CC8 (void);
// 0x00000738 System.Void UnityEngine.Rendering.Volume::Update()
extern void Volume_Update_m838C358C05E44E8F3E64CFFF23BF632B877FC92B (void);
// 0x00000739 System.Void UnityEngine.Rendering.Volume::UpdateLayer()
extern void Volume_UpdateLayer_m3D56B2D4679CF161A7BBB8FDB279544A3F602EF5 (void);
// 0x0000073A System.Void UnityEngine.Rendering.Volume::.ctor()
extern void Volume__ctor_m85DA9885CC8CF9A0C66249607DA2C8EEA37FBD73 (void);
// 0x0000073B System.Void UnityEngine.Rendering.VolumeComponentMenu::.ctor(System.String)
extern void VolumeComponentMenu__ctor_m8633FE8960007D11F8017F8B43574AF87A2701AC (void);
// 0x0000073C System.Type[] UnityEngine.Rendering.VolumeComponentMenuForRenderPipeline::get_pipelineTypes()
extern void VolumeComponentMenuForRenderPipeline_get_pipelineTypes_m3531E903B834E47340394FFA8CBC7B75516E45F4 (void);
// 0x0000073D System.Void UnityEngine.Rendering.VolumeComponentMenuForRenderPipeline::.ctor(System.String,System.Type[])
extern void VolumeComponentMenuForRenderPipeline__ctor_mF3581756460F6824053836AC13083EC1FFF439D9 (void);
// 0x0000073E System.Void UnityEngine.Rendering.VolumeComponentDeprecated::.ctor()
extern void VolumeComponentDeprecated__ctor_m14782C4B7B4C56C5D1E546D70EE4856592C3ADD8 (void);
// 0x0000073F System.String UnityEngine.Rendering.VolumeComponent::get_displayName()
extern void VolumeComponent_get_displayName_m9EE2FC2DCD2294F46468DEA90EE71419B34CEBEA (void);
// 0x00000740 System.Void UnityEngine.Rendering.VolumeComponent::set_displayName(System.String)
extern void VolumeComponent_set_displayName_m7490689389D1F847A6FFCF257C536175817AC1AF (void);
// 0x00000741 System.Collections.ObjectModel.ReadOnlyCollection`1<UnityEngine.Rendering.VolumeParameter> UnityEngine.Rendering.VolumeComponent::get_parameters()
extern void VolumeComponent_get_parameters_m4F91CF01C924BB1C3730706F6C16D752CCE63043 (void);
// 0x00000742 System.Void UnityEngine.Rendering.VolumeComponent::set_parameters(System.Collections.ObjectModel.ReadOnlyCollection`1<UnityEngine.Rendering.VolumeParameter>)
extern void VolumeComponent_set_parameters_mF276CB5B28110A8E62A0C3B2921FF3904D94CD09 (void);
// 0x00000743 System.Void UnityEngine.Rendering.VolumeComponent::FindParameters(System.Object,System.Collections.Generic.List`1<UnityEngine.Rendering.VolumeParameter>,System.Func`2<System.Reflection.FieldInfo,System.Boolean>)
extern void VolumeComponent_FindParameters_m091D5D04E70F1CF4D4F1EAC60463DBD22E0B64E0 (void);
// 0x00000744 System.Void UnityEngine.Rendering.VolumeComponent::OnEnable()
extern void VolumeComponent_OnEnable_m0FA91C466EE1AB7D54AC1CB65AF7D9E8D04C51AB (void);
// 0x00000745 System.Void UnityEngine.Rendering.VolumeComponent::OnDisable()
extern void VolumeComponent_OnDisable_m4E2210BFCEE538FBFDE0EBBEC38023FDA5789484 (void);
// 0x00000746 System.Void UnityEngine.Rendering.VolumeComponent::Override(UnityEngine.Rendering.VolumeComponent,System.Single)
extern void VolumeComponent_Override_m3680A57E931545C0FD7D4FD11CDE41C5097F2584 (void);
// 0x00000747 System.Void UnityEngine.Rendering.VolumeComponent::SetAllOverridesTo(System.Boolean)
extern void VolumeComponent_SetAllOverridesTo_mF825E40D5821ABDBFFBC2861C488A14E728FC87C (void);
// 0x00000748 System.Void UnityEngine.Rendering.VolumeComponent::SetOverridesTo(System.Collections.Generic.IEnumerable`1<UnityEngine.Rendering.VolumeParameter>,System.Boolean)
extern void VolumeComponent_SetOverridesTo_m77276D5A09805A24F619760F40987304D1F9531E (void);
// 0x00000749 System.Int32 UnityEngine.Rendering.VolumeComponent::GetHashCode()
extern void VolumeComponent_GetHashCode_mC97714D145AEEC233376DF154C93D69FF3EAF87C (void);
// 0x0000074A System.Void UnityEngine.Rendering.VolumeComponent::OnDestroy()
extern void VolumeComponent_OnDestroy_m761258E97BB0DECE99ECC6F2F266B51EA0CEA9E1 (void);
// 0x0000074B System.Void UnityEngine.Rendering.VolumeComponent::Release()
extern void VolumeComponent_Release_m57BFC682C5A2802DBD41FDA73DB9929727792CB9 (void);
// 0x0000074C System.Void UnityEngine.Rendering.VolumeComponent::.ctor()
extern void VolumeComponent__ctor_m6A9A4A9F8E91AFC664A381409CFE117D4E0111EB (void);
// 0x0000074D System.Void UnityEngine.Rendering.VolumeComponent/Indent::.ctor(System.Int32)
extern void Indent__ctor_m7D602088CDE705BA4ACCC882A798B77AC957B1AF (void);
// 0x0000074E System.Void UnityEngine.Rendering.VolumeComponent/<>c::.cctor()
extern void U3CU3Ec__cctor_m312DA08B400C1CD6334FC9E74F80CD5666466368 (void);
// 0x0000074F System.Void UnityEngine.Rendering.VolumeComponent/<>c::.ctor()
extern void U3CU3Ec__ctor_m0DA022586EF7D98F17249543DEF4D5012EFC5292 (void);
// 0x00000750 System.Int32 UnityEngine.Rendering.VolumeComponent/<>c::<FindParameters>b__10_0(System.Reflection.FieldInfo)
extern void U3CU3Ec_U3CFindParametersU3Eb__10_0_m386CF821AF832AEF1368036212E249D2DD766B2E (void);
// 0x00000751 UnityEngine.Rendering.VolumeManager UnityEngine.Rendering.VolumeManager::get_instance()
extern void VolumeManager_get_instance_m39B7AEF8823427A6BE8B1DD542CDC4472D8D5904 (void);
// 0x00000752 UnityEngine.Rendering.VolumeStack UnityEngine.Rendering.VolumeManager::get_stack()
extern void VolumeManager_get_stack_m5F7B366D1E7FE168EF4CA04A17531D34DD200266 (void);
// 0x00000753 System.Void UnityEngine.Rendering.VolumeManager::set_stack(UnityEngine.Rendering.VolumeStack)
extern void VolumeManager_set_stack_mDA55AC84E57EC2FE6D2A25EBB977A20EBD227156 (void);
// 0x00000754 System.Collections.Generic.IEnumerable`1<System.Type> UnityEngine.Rendering.VolumeManager::get_baseComponentTypes()
extern void VolumeManager_get_baseComponentTypes_m2860DEF58F61A01DC1796AE9AF3B1F55C31F2DFF (void);
// 0x00000755 System.Void UnityEngine.Rendering.VolumeManager::set_baseComponentTypes(System.Collections.Generic.IEnumerable`1<System.Type>)
extern void VolumeManager_set_baseComponentTypes_mD45041AC16A7D2DA82933912999F3669BB615A7B (void);
// 0x00000756 System.Type[] UnityEngine.Rendering.VolumeManager::get_baseComponentTypeArray()
extern void VolumeManager_get_baseComponentTypeArray_mA7074538EEBCE5CA3CBAD4A72919B3BB8B6095C4 (void);
// 0x00000757 System.Void UnityEngine.Rendering.VolumeManager::set_baseComponentTypeArray(System.Type[])
extern void VolumeManager_set_baseComponentTypeArray_mBB0F61A0058E8889334B4FC361688C3910B9FD54 (void);
// 0x00000758 System.Void UnityEngine.Rendering.VolumeManager::.ctor()
extern void VolumeManager__ctor_m4FD966D420A802BECB643C97876F286053AAB510 (void);
// 0x00000759 UnityEngine.Rendering.VolumeStack UnityEngine.Rendering.VolumeManager::CreateStack()
extern void VolumeManager_CreateStack_m7EACF7BD773893B2344DB8DFA1ACF4557FBB38B4 (void);
// 0x0000075A System.Void UnityEngine.Rendering.VolumeManager::ResetMainStack()
extern void VolumeManager_ResetMainStack_mF68ECEEC5A6D07ED24F5F77D798465A03DE364C7 (void);
// 0x0000075B System.Void UnityEngine.Rendering.VolumeManager::DestroyStack(UnityEngine.Rendering.VolumeStack)
extern void VolumeManager_DestroyStack_mFB8C5FA985F64DB8C4A322818E8C6FDCAD547AA6 (void);
// 0x0000075C System.Void UnityEngine.Rendering.VolumeManager::ReloadBaseTypes()
extern void VolumeManager_ReloadBaseTypes_mF05B36FEF13C5117FD56C399CB006E6ACA5C1F3E (void);
// 0x0000075D System.Void UnityEngine.Rendering.VolumeManager::Register(UnityEngine.Rendering.Volume,System.Int32)
extern void VolumeManager_Register_m03EB301A26ED63AC0436B2629823184FA51E3A12 (void);
// 0x0000075E System.Void UnityEngine.Rendering.VolumeManager::Unregister(UnityEngine.Rendering.Volume,System.Int32)
extern void VolumeManager_Unregister_m13977E5D10CE32234CC88E0C70FC8ED7BD3ECB93 (void);
// 0x0000075F System.Boolean UnityEngine.Rendering.VolumeManager::IsComponentActiveInMask(UnityEngine.LayerMask)
// 0x00000760 System.Void UnityEngine.Rendering.VolumeManager::SetLayerDirty(System.Int32)
extern void VolumeManager_SetLayerDirty_mC890A8B7C87D55DA92F0AE02DE758ED0C662A76B (void);
// 0x00000761 System.Void UnityEngine.Rendering.VolumeManager::UpdateVolumeLayer(UnityEngine.Rendering.Volume,System.Int32,System.Int32)
extern void VolumeManager_UpdateVolumeLayer_mA0F6077F117E1DAC32E5C2CC392C605BD331A23E (void);
// 0x00000762 System.Void UnityEngine.Rendering.VolumeManager::OverrideData(UnityEngine.Rendering.VolumeStack,System.Collections.Generic.List`1<UnityEngine.Rendering.VolumeComponent>,System.Single)
extern void VolumeManager_OverrideData_m6FDE271C5759140EB3229AA0EF36470453745CB7 (void);
// 0x00000763 System.Void UnityEngine.Rendering.VolumeManager::ReplaceData(UnityEngine.Rendering.VolumeStack,System.Collections.Generic.List`1<UnityEngine.Rendering.VolumeComponent>)
extern void VolumeManager_ReplaceData_mC32366C3D53A9B349186410A95215ECC433BD690 (void);
// 0x00000764 System.Void UnityEngine.Rendering.VolumeManager::CheckBaseTypes()
extern void VolumeManager_CheckBaseTypes_m3598A8722F3AAFB27B30DA521BA37AAE00D003F0 (void);
// 0x00000765 System.Void UnityEngine.Rendering.VolumeManager::CheckStack(UnityEngine.Rendering.VolumeStack)
extern void VolumeManager_CheckStack_m86DA4666E3D7CC889512DECC1061AE50E904CA0F (void);
// 0x00000766 System.Void UnityEngine.Rendering.VolumeManager::Update(UnityEngine.Transform,UnityEngine.LayerMask)
extern void VolumeManager_Update_m80D06A996F422CBF95CF7B7FB7EB687D75450E7F (void);
// 0x00000767 System.Void UnityEngine.Rendering.VolumeManager::Update(UnityEngine.Rendering.VolumeStack,UnityEngine.Transform,UnityEngine.LayerMask)
extern void VolumeManager_Update_m0AD4F65D0737393F3DF85F77D4A799D794C9FBC5 (void);
// 0x00000768 UnityEngine.Rendering.Volume[] UnityEngine.Rendering.VolumeManager::GetVolumes(UnityEngine.LayerMask)
extern void VolumeManager_GetVolumes_mCD6F01BC37F4C6833FF56635904021D3E087BBDA (void);
// 0x00000769 System.Collections.Generic.List`1<UnityEngine.Rendering.Volume> UnityEngine.Rendering.VolumeManager::GrabVolumes(UnityEngine.LayerMask)
extern void VolumeManager_GrabVolumes_m3E182E42A41D762A000FF23E49D2C6CFDCD8A9ED (void);
// 0x0000076A System.Void UnityEngine.Rendering.VolumeManager::SortByPriority(System.Collections.Generic.List`1<UnityEngine.Rendering.Volume>)
extern void VolumeManager_SortByPriority_m9CBB6E5C4C0D5685C8693865D4119114B3C75130 (void);
// 0x0000076B System.Boolean UnityEngine.Rendering.VolumeManager::IsVolumeRenderedByCamera(UnityEngine.Rendering.Volume,UnityEngine.Camera)
extern void VolumeManager_IsVolumeRenderedByCamera_m7B6E205268B231DFFEE198CDC6DAABAF0967E5E9 (void);
// 0x0000076C System.Void UnityEngine.Rendering.VolumeManager::.cctor()
extern void VolumeManager__cctor_m27EBAFF65D0A2E0A7E99E145BD72AC1237EAD91D (void);
// 0x0000076D System.Void UnityEngine.Rendering.VolumeManager/<>c::.cctor()
extern void U3CU3Ec__cctor_m4F6DA144B7FFAE9BC642E81C79EDE8A1536DCACF (void);
// 0x0000076E System.Void UnityEngine.Rendering.VolumeManager/<>c::.ctor()
extern void U3CU3Ec__ctor_mB089A6F9C8405F20786EAF00508B21C80753FAF5 (void);
// 0x0000076F System.Boolean UnityEngine.Rendering.VolumeManager/<>c::<ReloadBaseTypes>b__25_0(System.Type)
extern void U3CU3Ec_U3CReloadBaseTypesU3Eb__25_0_mC8950B6BB17E541E241A2034460F5CC5B77AFA10 (void);
// 0x00000770 System.Boolean UnityEngine.Rendering.VolumeManager/<>c::<GetVolumes>b__37_0(UnityEngine.Rendering.Volume)
extern void U3CU3Ec_U3CGetVolumesU3Eb__37_0_m5B62E3B295076FE91FAF61F31B7D37FCAB17B31C (void);
// 0x00000771 UnityEngine.Rendering.VolumeManager UnityEngine.Rendering.VolumeManager/<>c::<.cctor>b__41_0()
extern void U3CU3Ec_U3C_cctorU3Eb__41_0_m3B9EEE930E2698688F41F786649E23418703BD0E (void);
// 0x00000772 System.Void UnityEngine.Rendering.VolumeIsolationScope::.ctor(System.Boolean)
extern void VolumeIsolationScope__ctor_m01620738B9C04C8237155E3843C60A195C179498 (void);
// 0x00000773 System.Void UnityEngine.Rendering.VolumeIsolationScope::System.IDisposable.Dispose()
extern void VolumeIsolationScope_System_IDisposable_Dispose_m1351187D1678129A678C6AAD3FCD237147438BC4 (void);
// 0x00000774 System.Boolean UnityEngine.Rendering.VolumeParameter::get_overrideState()
extern void VolumeParameter_get_overrideState_mA355B3AA60CF5775142D57F8C48AC2283DD89170 (void);
// 0x00000775 System.Void UnityEngine.Rendering.VolumeParameter::set_overrideState(System.Boolean)
extern void VolumeParameter_set_overrideState_m20E185DE102F9BCF46759CCDBACEA7832730E83A (void);
// 0x00000776 System.Void UnityEngine.Rendering.VolumeParameter::Interp(UnityEngine.Rendering.VolumeParameter,UnityEngine.Rendering.VolumeParameter,System.Single)
// 0x00000777 T UnityEngine.Rendering.VolumeParameter::GetValue()
// 0x00000778 System.Void UnityEngine.Rendering.VolumeParameter::SetValue(UnityEngine.Rendering.VolumeParameter)
// 0x00000779 System.Void UnityEngine.Rendering.VolumeParameter::OnEnable()
extern void VolumeParameter_OnEnable_m0A1ACF10A6885EAF8A33DDC1103AFE8A9B8B8A60 (void);
// 0x0000077A System.Void UnityEngine.Rendering.VolumeParameter::OnDisable()
extern void VolumeParameter_OnDisable_m019429EE1025F4E1A3A3F1900D78B6D4BD0E4470 (void);
// 0x0000077B System.Boolean UnityEngine.Rendering.VolumeParameter::IsObjectParameter(System.Type)
extern void VolumeParameter_IsObjectParameter_m6D4BC5FFC3B2A2DC5CC92FC6C0B87CE5E8DE78D4 (void);
// 0x0000077C System.Void UnityEngine.Rendering.VolumeParameter::Release()
extern void VolumeParameter_Release_mA95DED0C57364D4C9C9D98B9613D035C18FFE155 (void);
// 0x0000077D System.Void UnityEngine.Rendering.VolumeParameter::.ctor()
extern void VolumeParameter__ctor_m1A76B3C6C284C912F55F7C7E6EF21A18AF3930D2 (void);
// 0x0000077E T UnityEngine.Rendering.VolumeParameter`1::get_value()
// 0x0000077F System.Void UnityEngine.Rendering.VolumeParameter`1::set_value(T)
// 0x00000780 System.Void UnityEngine.Rendering.VolumeParameter`1::.ctor()
// 0x00000781 System.Void UnityEngine.Rendering.VolumeParameter`1::.ctor(T,System.Boolean)
// 0x00000782 System.Void UnityEngine.Rendering.VolumeParameter`1::Interp(UnityEngine.Rendering.VolumeParameter,UnityEngine.Rendering.VolumeParameter,System.Single)
// 0x00000783 System.Void UnityEngine.Rendering.VolumeParameter`1::Interp(T,T,System.Single)
// 0x00000784 System.Void UnityEngine.Rendering.VolumeParameter`1::Override(T)
// 0x00000785 System.Void UnityEngine.Rendering.VolumeParameter`1::SetValue(UnityEngine.Rendering.VolumeParameter)
// 0x00000786 System.Int32 UnityEngine.Rendering.VolumeParameter`1::GetHashCode()
// 0x00000787 System.String UnityEngine.Rendering.VolumeParameter`1::ToString()
// 0x00000788 System.Boolean UnityEngine.Rendering.VolumeParameter`1::op_Equality(UnityEngine.Rendering.VolumeParameter`1<T>,T)
// 0x00000789 System.Boolean UnityEngine.Rendering.VolumeParameter`1::op_Inequality(UnityEngine.Rendering.VolumeParameter`1<T>,T)
// 0x0000078A System.Boolean UnityEngine.Rendering.VolumeParameter`1::Equals(UnityEngine.Rendering.VolumeParameter`1<T>)
// 0x0000078B System.Boolean UnityEngine.Rendering.VolumeParameter`1::Equals(System.Object)
// 0x0000078C T UnityEngine.Rendering.VolumeParameter`1::op_Explicit(UnityEngine.Rendering.VolumeParameter`1<T>)
// 0x0000078D System.Void UnityEngine.Rendering.BoolParameter::.ctor(System.Boolean,System.Boolean)
extern void BoolParameter__ctor_m2355BE07CF2E06B525D26161B1E0C357CE772190 (void);
// 0x0000078E System.Void UnityEngine.Rendering.LayerMaskParameter::.ctor(UnityEngine.LayerMask,System.Boolean)
extern void LayerMaskParameter__ctor_m8F8196A3800C793D3B236D6AD4A914F2CE5B9206 (void);
// 0x0000078F System.Void UnityEngine.Rendering.IntParameter::.ctor(System.Int32,System.Boolean)
extern void IntParameter__ctor_m67FBC21D721C250E279747AEB87DDFBB1AF11F57 (void);
// 0x00000790 System.Void UnityEngine.Rendering.IntParameter::Interp(System.Int32,System.Int32,System.Single)
extern void IntParameter_Interp_mDC423D4C404192EE3DB1409787DFACC7326C67FC (void);
// 0x00000791 System.Void UnityEngine.Rendering.NoInterpIntParameter::.ctor(System.Int32,System.Boolean)
extern void NoInterpIntParameter__ctor_m90649C51973C965712112CD7BABD9E259EA5804A (void);
// 0x00000792 System.Int32 UnityEngine.Rendering.MinIntParameter::get_value()
extern void MinIntParameter_get_value_m186AC9E61EB01D361426269260C5A1B2ECEB6206 (void);
// 0x00000793 System.Void UnityEngine.Rendering.MinIntParameter::set_value(System.Int32)
extern void MinIntParameter_set_value_mC0ED8E817428CCE3C943FA3C617A9A8DEA994D09 (void);
// 0x00000794 System.Void UnityEngine.Rendering.MinIntParameter::.ctor(System.Int32,System.Int32,System.Boolean)
extern void MinIntParameter__ctor_m503915F572DD7883610AD4107C2B8C08E7FF2E57 (void);
// 0x00000795 System.Int32 UnityEngine.Rendering.NoInterpMinIntParameter::get_value()
extern void NoInterpMinIntParameter_get_value_mCD45893150FE0FFFBDA55B2066A6908810EBD574 (void);
// 0x00000796 System.Void UnityEngine.Rendering.NoInterpMinIntParameter::set_value(System.Int32)
extern void NoInterpMinIntParameter_set_value_mE0CB3103510DD3AA324439A5FAC30B75509E6097 (void);
// 0x00000797 System.Void UnityEngine.Rendering.NoInterpMinIntParameter::.ctor(System.Int32,System.Int32,System.Boolean)
extern void NoInterpMinIntParameter__ctor_m6962CF0672226874984520D8227E7BEC783BAB07 (void);
// 0x00000798 System.Int32 UnityEngine.Rendering.MaxIntParameter::get_value()
extern void MaxIntParameter_get_value_m0D77F6896765E8898301E88B4B36896785C3196F (void);
// 0x00000799 System.Void UnityEngine.Rendering.MaxIntParameter::set_value(System.Int32)
extern void MaxIntParameter_set_value_m5B5583396506E5FEA828895D3E1985F3CE0E2BAC (void);
// 0x0000079A System.Void UnityEngine.Rendering.MaxIntParameter::.ctor(System.Int32,System.Int32,System.Boolean)
extern void MaxIntParameter__ctor_m8D89FC483C8D8203FFB0A8436CF2C45D93C8FA8C (void);
// 0x0000079B System.Int32 UnityEngine.Rendering.NoInterpMaxIntParameter::get_value()
extern void NoInterpMaxIntParameter_get_value_m2055E30B9F44765EEFB7DB18731A0A5EBC7E57EE (void);
// 0x0000079C System.Void UnityEngine.Rendering.NoInterpMaxIntParameter::set_value(System.Int32)
extern void NoInterpMaxIntParameter_set_value_m609E4B1372022A9239F7D7FBDF9C40D921501691 (void);
// 0x0000079D System.Void UnityEngine.Rendering.NoInterpMaxIntParameter::.ctor(System.Int32,System.Int32,System.Boolean)
extern void NoInterpMaxIntParameter__ctor_mAE456C5846B27CC7D63254BA778F905D6B498217 (void);
// 0x0000079E System.Int32 UnityEngine.Rendering.ClampedIntParameter::get_value()
extern void ClampedIntParameter_get_value_m34AE11973506069525F62716647B890CFA0A3AC4 (void);
// 0x0000079F System.Void UnityEngine.Rendering.ClampedIntParameter::set_value(System.Int32)
extern void ClampedIntParameter_set_value_m590DDB07ED64AE69840607D1005FDC5790282B39 (void);
// 0x000007A0 System.Void UnityEngine.Rendering.ClampedIntParameter::.ctor(System.Int32,System.Int32,System.Int32,System.Boolean)
extern void ClampedIntParameter__ctor_mF0B73AD8EF805C194DCE64ED205B9968D58BA6D6 (void);
// 0x000007A1 System.Int32 UnityEngine.Rendering.NoInterpClampedIntParameter::get_value()
extern void NoInterpClampedIntParameter_get_value_m0EA1E9A8144DF33899F8FA553C448B7BF52700E4 (void);
// 0x000007A2 System.Void UnityEngine.Rendering.NoInterpClampedIntParameter::set_value(System.Int32)
extern void NoInterpClampedIntParameter_set_value_m07FFEF923D294F6D3E76864AAD0512FCF182DE2D (void);
// 0x000007A3 System.Void UnityEngine.Rendering.NoInterpClampedIntParameter::.ctor(System.Int32,System.Int32,System.Int32,System.Boolean)
extern void NoInterpClampedIntParameter__ctor_mF8B3120B4D7C9E1F2830F9B424B6A694F242615E (void);
// 0x000007A4 System.Void UnityEngine.Rendering.FloatParameter::.ctor(System.Single,System.Boolean)
extern void FloatParameter__ctor_mC453DAC155DBDF014599DD3C2A92E2653378F7AB (void);
// 0x000007A5 System.Void UnityEngine.Rendering.FloatParameter::Interp(System.Single,System.Single,System.Single)
extern void FloatParameter_Interp_m5EEABBCB6D5C74CD027D14CB1940BADF46DF8B8C (void);
// 0x000007A6 System.Void UnityEngine.Rendering.NoInterpFloatParameter::.ctor(System.Single,System.Boolean)
extern void NoInterpFloatParameter__ctor_mC5FF8F8C6923CADFCC30BE1C66D11B665B2F4650 (void);
// 0x000007A7 System.Single UnityEngine.Rendering.MinFloatParameter::get_value()
extern void MinFloatParameter_get_value_m2BEF75BB125497127385C3FEA91F295F56CF96C1 (void);
// 0x000007A8 System.Void UnityEngine.Rendering.MinFloatParameter::set_value(System.Single)
extern void MinFloatParameter_set_value_mFEE3E60FA643148A1548A5C1DF00EB0659FA9C95 (void);
// 0x000007A9 System.Void UnityEngine.Rendering.MinFloatParameter::.ctor(System.Single,System.Single,System.Boolean)
extern void MinFloatParameter__ctor_m854E3294B712BB55CBED061C73BF617FAC983AB9 (void);
// 0x000007AA System.Single UnityEngine.Rendering.NoInterpMinFloatParameter::get_value()
extern void NoInterpMinFloatParameter_get_value_m63F82DF77BD44C45CBE001FDE8E561A3C993981F (void);
// 0x000007AB System.Void UnityEngine.Rendering.NoInterpMinFloatParameter::set_value(System.Single)
extern void NoInterpMinFloatParameter_set_value_mF338F3AC7FC964EE6F13CA24BA81857A017810F6 (void);
// 0x000007AC System.Void UnityEngine.Rendering.NoInterpMinFloatParameter::.ctor(System.Single,System.Single,System.Boolean)
extern void NoInterpMinFloatParameter__ctor_mD6661EA495B98AA034513C11FC0443EF4A274802 (void);
// 0x000007AD System.Single UnityEngine.Rendering.MaxFloatParameter::get_value()
extern void MaxFloatParameter_get_value_mA6BABE32B5AC8B348C729E12666382F4FAF07E00 (void);
// 0x000007AE System.Void UnityEngine.Rendering.MaxFloatParameter::set_value(System.Single)
extern void MaxFloatParameter_set_value_mF8BAB011F885367EB3D8C4E0C7AF695DDF14AB8B (void);
// 0x000007AF System.Void UnityEngine.Rendering.MaxFloatParameter::.ctor(System.Single,System.Single,System.Boolean)
extern void MaxFloatParameter__ctor_mA56D698D4B059FB5C3E76ABC7805E72D2B19E248 (void);
// 0x000007B0 System.Single UnityEngine.Rendering.NoInterpMaxFloatParameter::get_value()
extern void NoInterpMaxFloatParameter_get_value_mB8F3D827D20C50AB609F887C270E35D3FC1622E9 (void);
// 0x000007B1 System.Void UnityEngine.Rendering.NoInterpMaxFloatParameter::set_value(System.Single)
extern void NoInterpMaxFloatParameter_set_value_mDDF917E8CD3B661D304EDC248B01FC2BEE7FE594 (void);
// 0x000007B2 System.Void UnityEngine.Rendering.NoInterpMaxFloatParameter::.ctor(System.Single,System.Single,System.Boolean)
extern void NoInterpMaxFloatParameter__ctor_mE9A5ED98EA3E61769C30FC1D3DF99ECF5E38657C (void);
// 0x000007B3 System.Single UnityEngine.Rendering.ClampedFloatParameter::get_value()
extern void ClampedFloatParameter_get_value_m61D80F063384761A7C113BF99AE4E6D72BA39D8A (void);
// 0x000007B4 System.Void UnityEngine.Rendering.ClampedFloatParameter::set_value(System.Single)
extern void ClampedFloatParameter_set_value_m407E77C2AABD9AF3AD81373BFEB764188A8DC763 (void);
// 0x000007B5 System.Void UnityEngine.Rendering.ClampedFloatParameter::.ctor(System.Single,System.Single,System.Single,System.Boolean)
extern void ClampedFloatParameter__ctor_mFC9EF54EFA2A6B51F252CB98A6F6D66C768F3CE5 (void);
// 0x000007B6 System.Single UnityEngine.Rendering.NoInterpClampedFloatParameter::get_value()
extern void NoInterpClampedFloatParameter_get_value_m2B9F89DFAB9796DD5341354DDC5BDCC1E3318DA5 (void);
// 0x000007B7 System.Void UnityEngine.Rendering.NoInterpClampedFloatParameter::set_value(System.Single)
extern void NoInterpClampedFloatParameter_set_value_mD21081AF32ADDC677AEA5F27F8CFC9EEB2F966CD (void);
// 0x000007B8 System.Void UnityEngine.Rendering.NoInterpClampedFloatParameter::.ctor(System.Single,System.Single,System.Single,System.Boolean)
extern void NoInterpClampedFloatParameter__ctor_m8AEF6628B5863799A40D5647649D779D8BCAA81C (void);
// 0x000007B9 UnityEngine.Vector2 UnityEngine.Rendering.FloatRangeParameter::get_value()
extern void FloatRangeParameter_get_value_m25B1C4761DBF5FED042ECA668FFF00BBC35DD925 (void);
// 0x000007BA System.Void UnityEngine.Rendering.FloatRangeParameter::set_value(UnityEngine.Vector2)
extern void FloatRangeParameter_set_value_mF98828AA823A3F6A4B0A2D32E211698AAD587829 (void);
// 0x000007BB System.Void UnityEngine.Rendering.FloatRangeParameter::.ctor(UnityEngine.Vector2,System.Single,System.Single,System.Boolean)
extern void FloatRangeParameter__ctor_mB17094FAECFA22F0494B606A2531EBC73AB0DB31 (void);
// 0x000007BC System.Void UnityEngine.Rendering.FloatRangeParameter::Interp(UnityEngine.Vector2,UnityEngine.Vector2,System.Single)
extern void FloatRangeParameter_Interp_m49C2EAA6296B9C8BDE3A56810A606EE459388F78 (void);
// 0x000007BD UnityEngine.Vector2 UnityEngine.Rendering.NoInterpFloatRangeParameter::get_value()
extern void NoInterpFloatRangeParameter_get_value_m5C29069EBA216300A415ADEC1A7DD1CE5E633B01 (void);
// 0x000007BE System.Void UnityEngine.Rendering.NoInterpFloatRangeParameter::set_value(UnityEngine.Vector2)
extern void NoInterpFloatRangeParameter_set_value_mC8C880583FA80C2B7895560C0E9BC2965F91A26D (void);
// 0x000007BF System.Void UnityEngine.Rendering.NoInterpFloatRangeParameter::.ctor(UnityEngine.Vector2,System.Single,System.Single,System.Boolean)
extern void NoInterpFloatRangeParameter__ctor_mC9294487DBF1F2C1A18F6C3EF586DEABB249652B (void);
// 0x000007C0 System.Void UnityEngine.Rendering.ColorParameter::.ctor(UnityEngine.Color,System.Boolean)
extern void ColorParameter__ctor_mD47039CB27B4A8F5EAECBCC844B2140719C50386 (void);
// 0x000007C1 System.Void UnityEngine.Rendering.ColorParameter::.ctor(UnityEngine.Color,System.Boolean,System.Boolean,System.Boolean,System.Boolean)
extern void ColorParameter__ctor_mA9A003084B8D70C30995E95B65B29A136C66096D (void);
// 0x000007C2 System.Void UnityEngine.Rendering.ColorParameter::Interp(UnityEngine.Color,UnityEngine.Color,System.Single)
extern void ColorParameter_Interp_mEB18527D660650893F9BD4B60B8BEB548B18E772 (void);
// 0x000007C3 System.Void UnityEngine.Rendering.NoInterpColorParameter::.ctor(UnityEngine.Color,System.Boolean)
extern void NoInterpColorParameter__ctor_m511A9D9F6127C758B0EFF479E9D3C367FB8C03F5 (void);
// 0x000007C4 System.Void UnityEngine.Rendering.NoInterpColorParameter::.ctor(UnityEngine.Color,System.Boolean,System.Boolean,System.Boolean,System.Boolean)
extern void NoInterpColorParameter__ctor_mF53E2D8AFB3A645C40CE9A0FFE28C1309E08257A (void);
// 0x000007C5 System.Void UnityEngine.Rendering.Vector2Parameter::.ctor(UnityEngine.Vector2,System.Boolean)
extern void Vector2Parameter__ctor_m34C59043C7CB4CCF438E61F1F50D81F15E4FE4B6 (void);
// 0x000007C6 System.Void UnityEngine.Rendering.Vector2Parameter::Interp(UnityEngine.Vector2,UnityEngine.Vector2,System.Single)
extern void Vector2Parameter_Interp_mB09C819117EC228387E17D4AF66B999805DAC321 (void);
// 0x000007C7 System.Void UnityEngine.Rendering.NoInterpVector2Parameter::.ctor(UnityEngine.Vector2,System.Boolean)
extern void NoInterpVector2Parameter__ctor_m0023AB35D338B1370F97CE6635DB33B7D3174EAE (void);
// 0x000007C8 System.Void UnityEngine.Rendering.Vector3Parameter::.ctor(UnityEngine.Vector3,System.Boolean)
extern void Vector3Parameter__ctor_m2A3477C2E556645131EB0475AEE4E9728841BE9C (void);
// 0x000007C9 System.Void UnityEngine.Rendering.Vector3Parameter::Interp(UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void Vector3Parameter_Interp_mB5B50D808D2FAFF04558AA92A854A5587717E159 (void);
// 0x000007CA System.Void UnityEngine.Rendering.NoInterpVector3Parameter::.ctor(UnityEngine.Vector3,System.Boolean)
extern void NoInterpVector3Parameter__ctor_m57423AC9510F99C56BC5AAB1A95B86481A9148EC (void);
// 0x000007CB System.Void UnityEngine.Rendering.Vector4Parameter::.ctor(UnityEngine.Vector4,System.Boolean)
extern void Vector4Parameter__ctor_m741CC228E74AF9EA20C77D6209BDF264F2C17452 (void);
// 0x000007CC System.Void UnityEngine.Rendering.Vector4Parameter::Interp(UnityEngine.Vector4,UnityEngine.Vector4,System.Single)
extern void Vector4Parameter_Interp_m156F7A8256CF5C6DCECAA5CF2F99A920C30BEB66 (void);
// 0x000007CD System.Void UnityEngine.Rendering.NoInterpVector4Parameter::.ctor(UnityEngine.Vector4,System.Boolean)
extern void NoInterpVector4Parameter__ctor_mBCC94D3B29ADB6D1C6F730D26850D37F3F35A185 (void);
// 0x000007CE System.Void UnityEngine.Rendering.TextureParameter::.ctor(UnityEngine.Texture,System.Boolean)
extern void TextureParameter__ctor_m5756E1DFAB73C37D64AA6CA329F6D1C55971A71A (void);
// 0x000007CF System.Void UnityEngine.Rendering.NoInterpTextureParameter::.ctor(UnityEngine.Texture,System.Boolean)
extern void NoInterpTextureParameter__ctor_mAE3B412887E5CDE015065A6B6E0F3E78F8106E88 (void);
// 0x000007D0 System.Void UnityEngine.Rendering.Texture2DParameter::.ctor(UnityEngine.Texture,System.Boolean)
extern void Texture2DParameter__ctor_m3A6EBCB797C3FD5ACFE6D5029704887DB17B492A (void);
// 0x000007D1 System.Void UnityEngine.Rendering.Texture3DParameter::.ctor(UnityEngine.Texture,System.Boolean)
extern void Texture3DParameter__ctor_mC5EB1FCDE9F1426770783EF2C7242C0E221D8A93 (void);
// 0x000007D2 System.Void UnityEngine.Rendering.RenderTextureParameter::.ctor(UnityEngine.RenderTexture,System.Boolean)
extern void RenderTextureParameter__ctor_mFA2947C5B4BB2C80603711DD6F881A1E0880BB96 (void);
// 0x000007D3 System.Void UnityEngine.Rendering.NoInterpRenderTextureParameter::.ctor(UnityEngine.RenderTexture,System.Boolean)
extern void NoInterpRenderTextureParameter__ctor_m20B3C73CD6A11B1198BB7A21CE33DC908ABC46C0 (void);
// 0x000007D4 System.Void UnityEngine.Rendering.CubemapParameter::.ctor(UnityEngine.Texture,System.Boolean)
extern void CubemapParameter__ctor_m44BF9295F2F3C4168BCBDF746B59F057E46BE9F6 (void);
// 0x000007D5 System.Void UnityEngine.Rendering.NoInterpCubemapParameter::.ctor(UnityEngine.Cubemap,System.Boolean)
extern void NoInterpCubemapParameter__ctor_mFE94AFC6850C280614C720CAE234E75C6AC40D1A (void);
// 0x000007D6 System.Collections.ObjectModel.ReadOnlyCollection`1<UnityEngine.Rendering.VolumeParameter> UnityEngine.Rendering.ObjectParameter`1::get_parameters()
// 0x000007D7 System.Void UnityEngine.Rendering.ObjectParameter`1::set_parameters(System.Collections.ObjectModel.ReadOnlyCollection`1<UnityEngine.Rendering.VolumeParameter>)
// 0x000007D8 System.Boolean UnityEngine.Rendering.ObjectParameter`1::get_overrideState()
// 0x000007D9 System.Void UnityEngine.Rendering.ObjectParameter`1::set_overrideState(System.Boolean)
// 0x000007DA T UnityEngine.Rendering.ObjectParameter`1::get_value()
// 0x000007DB System.Void UnityEngine.Rendering.ObjectParameter`1::set_value(T)
// 0x000007DC System.Void UnityEngine.Rendering.ObjectParameter`1::.ctor(T)
// 0x000007DD System.Void UnityEngine.Rendering.ObjectParameter`1::Interp(UnityEngine.Rendering.VolumeParameter,UnityEngine.Rendering.VolumeParameter,System.Single)
// 0x000007DE UnityEngine.Rendering.VolumeParameter UnityEngine.Rendering.ObjectParameter`1::<set_value>b__9_2(System.Reflection.FieldInfo)
// 0x000007DF System.Void UnityEngine.Rendering.ObjectParameter`1/<>c::.cctor()
// 0x000007E0 System.Void UnityEngine.Rendering.ObjectParameter`1/<>c::.ctor()
// 0x000007E1 System.Boolean UnityEngine.Rendering.ObjectParameter`1/<>c::<set_value>b__9_0(System.Reflection.FieldInfo)
// 0x000007E2 System.Int32 UnityEngine.Rendering.ObjectParameter`1/<>c::<set_value>b__9_1(System.Reflection.FieldInfo)
// 0x000007E3 System.Void UnityEngine.Rendering.AnimationCurveParameter::.ctor(UnityEngine.AnimationCurve,System.Boolean)
extern void AnimationCurveParameter__ctor_m7D096129215A4302F4FA02A25F8043C58BF44A96 (void);
// 0x000007E4 System.Void UnityEngine.Rendering.VolumeProfile::OnEnable()
extern void VolumeProfile_OnEnable_m1A8EC150A4A44E6BB4B7596681CBCF7D5CEF3293 (void);
// 0x000007E5 System.Void UnityEngine.Rendering.VolumeProfile::Reset()
extern void VolumeProfile_Reset_m56821F268C7DF9B2AD8423094839E0C53BCECC89 (void);
// 0x000007E6 T UnityEngine.Rendering.VolumeProfile::Add(System.Boolean)
// 0x000007E7 UnityEngine.Rendering.VolumeComponent UnityEngine.Rendering.VolumeProfile::Add(System.Type,System.Boolean)
extern void VolumeProfile_Add_mDF517026750FFACF3E21FCC135510FEBEB12BE1B (void);
// 0x000007E8 System.Void UnityEngine.Rendering.VolumeProfile::Remove()
// 0x000007E9 System.Void UnityEngine.Rendering.VolumeProfile::Remove(System.Type)
extern void VolumeProfile_Remove_m9E5CA5F7CA22167AD235A88515C4315F68A579E7 (void);
// 0x000007EA System.Boolean UnityEngine.Rendering.VolumeProfile::Has()
// 0x000007EB System.Boolean UnityEngine.Rendering.VolumeProfile::Has(System.Type)
extern void VolumeProfile_Has_m58F53E1D8EC2C8D8D97ADF7AEEB6C432FFE9C8BC (void);
// 0x000007EC System.Boolean UnityEngine.Rendering.VolumeProfile::HasSubclassOf(System.Type)
extern void VolumeProfile_HasSubclassOf_m920D79BA16A14B8026649BAFA32A8C017DE0F02F (void);
// 0x000007ED System.Boolean UnityEngine.Rendering.VolumeProfile::TryGet(T&)
// 0x000007EE System.Boolean UnityEngine.Rendering.VolumeProfile::TryGet(System.Type,T&)
// 0x000007EF System.Boolean UnityEngine.Rendering.VolumeProfile::TryGetSubclassOf(System.Type,T&)
// 0x000007F0 System.Boolean UnityEngine.Rendering.VolumeProfile::TryGetAllSubclassOf(System.Type,System.Collections.Generic.List`1<T>)
// 0x000007F1 System.Int32 UnityEngine.Rendering.VolumeProfile::GetHashCode()
extern void VolumeProfile_GetHashCode_mFFE471DEA166D1EBC418F1EF97D3FB5FFD627ECF (void);
// 0x000007F2 System.Int32 UnityEngine.Rendering.VolumeProfile::GetComponentListHashCode()
extern void VolumeProfile_GetComponentListHashCode_m8AB8D068D1F104706ADD8CA0207E3B3526D527C1 (void);
// 0x000007F3 System.Void UnityEngine.Rendering.VolumeProfile::Sanitize()
extern void VolumeProfile_Sanitize_m288F3AFCFE9A6F6653F7FFC87CA08E17D425A305 (void);
// 0x000007F4 System.Void UnityEngine.Rendering.VolumeProfile::.ctor()
extern void VolumeProfile__ctor_m3981FB5EB5E02F57E8C1C58AD34187402D7A7FFB (void);
// 0x000007F5 System.Void UnityEngine.Rendering.VolumeProfile/<>c::.cctor()
extern void U3CU3Ec__cctor_m7E0B1F83A34449300AB2DB8208AAF13B59451A1E (void);
// 0x000007F6 System.Void UnityEngine.Rendering.VolumeProfile/<>c::.ctor()
extern void U3CU3Ec__ctor_mAEAED8F15ADB4E2A3D53D6D63BB7D9AEFDB3462E (void);
// 0x000007F7 System.Boolean UnityEngine.Rendering.VolumeProfile/<>c::<OnEnable>b__2_0(UnityEngine.Rendering.VolumeComponent)
extern void U3CU3Ec_U3COnEnableU3Eb__2_0_m01AFBC2281C9D0F419F9158C17BCA7A47E0012DE (void);
// 0x000007F8 System.Void UnityEngine.Rendering.VolumeStack::.ctor()
extern void VolumeStack__ctor_mC6D6B63557B0EFF135F33B4E3868BC7BE1F35C58 (void);
// 0x000007F9 System.Void UnityEngine.Rendering.VolumeStack::Reload(System.Type[])
extern void VolumeStack_Reload_m74FD3C7E2C4DA948F2DE94036348527C44C55CF5 (void);
// 0x000007FA T UnityEngine.Rendering.VolumeStack::GetComponent()
// 0x000007FB UnityEngine.Rendering.VolumeComponent UnityEngine.Rendering.VolumeStack::GetComponent(System.Type)
extern void VolumeStack_GetComponent_mC7A2CE27A8A6F6A6A4B4B6EF14E190085A343844 (void);
// 0x000007FC System.Void UnityEngine.Rendering.VolumeStack::Dispose()
extern void VolumeStack_Dispose_m4DF004B6DEA09DECF79AFF8E2A7CE7386EC32B43 (void);
// 0x000007FD System.Boolean UnityEngine.Rendering.XRGraphicsAutomatedTests::get_activatedFromCommandLine()
extern void XRGraphicsAutomatedTests_get_activatedFromCommandLine_m0B64CC2FA51C178F0038436532184BD748E011D5 (void);
// 0x000007FE System.Boolean UnityEngine.Rendering.XRGraphicsAutomatedTests::get_enabled()
extern void XRGraphicsAutomatedTests_get_enabled_mED2B45610E9C762FDF0D89932D14A2BEA5390B82 (void);
// 0x000007FF System.Void UnityEngine.Rendering.XRGraphicsAutomatedTests::.cctor()
extern void XRGraphicsAutomatedTests__cctor_mA5D3CFA7660CE819738ADE99B2B9181374F04B09 (void);
// 0x00000800 System.Void UnityEngine.Rendering.LookDev.IDataProvider::FirstInitScene(UnityEngine.Rendering.LookDev.StageRuntimeInterface)
// 0x00000801 System.Void UnityEngine.Rendering.LookDev.IDataProvider::UpdateSky(UnityEngine.Camera,UnityEngine.Rendering.LookDev.Sky,UnityEngine.Rendering.LookDev.StageRuntimeInterface)
// 0x00000802 System.Collections.Generic.IEnumerable`1<System.String> UnityEngine.Rendering.LookDev.IDataProvider::get_supportedDebugModes()
// 0x00000803 System.Void UnityEngine.Rendering.LookDev.IDataProvider::UpdateDebugMode(System.Int32)
// 0x00000804 System.Void UnityEngine.Rendering.LookDev.IDataProvider::GetShadowMask(UnityEngine.RenderTexture&,UnityEngine.Rendering.LookDev.StageRuntimeInterface)
// 0x00000805 System.Void UnityEngine.Rendering.LookDev.IDataProvider::OnBeginRendering(UnityEngine.Rendering.LookDev.StageRuntimeInterface)
// 0x00000806 System.Void UnityEngine.Rendering.LookDev.IDataProvider::OnEndRendering(UnityEngine.Rendering.LookDev.StageRuntimeInterface)
// 0x00000807 System.Void UnityEngine.Rendering.LookDev.IDataProvider::Cleanup(UnityEngine.Rendering.LookDev.StageRuntimeInterface)
// 0x00000808 System.Void UnityEngine.Rendering.LookDev.StageRuntimeInterface::.ctor(System.Func`2<System.Boolean,UnityEngine.GameObject>,System.Func`1<UnityEngine.Camera>,System.Func`1<UnityEngine.Light>)
extern void StageRuntimeInterface__ctor_m77ED24F527202E13B5FF938C2BF1C7E4E0173661 (void);
// 0x00000809 UnityEngine.GameObject UnityEngine.Rendering.LookDev.StageRuntimeInterface::AddGameObject(System.Boolean)
extern void StageRuntimeInterface_AddGameObject_mBA0539C875795229002891A57B2AB97543FB314D (void);
// 0x0000080A UnityEngine.Camera UnityEngine.Rendering.LookDev.StageRuntimeInterface::get_camera()
extern void StageRuntimeInterface_get_camera_mD25AB28B41CDED30E6D478BBC00E631B938AF1A0 (void);
// 0x0000080B UnityEngine.Light UnityEngine.Rendering.LookDev.StageRuntimeInterface::get_sunLight()
extern void StageRuntimeInterface_get_sunLight_mD1B5AB2BB6B385D2AE0D4A6660D402D8319C4B86 (void);
// 0x0000080C System.Void UnityEngine.Rendering.UI.DebugUIHandlerBitField::SetWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugUIHandlerBitField_SetWidget_mC9A7F8C4B39F05BFA164FA25C5C811106EFFEDA5 (void);
// 0x0000080D System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerBitField::GetValue(System.Int32)
extern void DebugUIHandlerBitField_GetValue_m83486BB1A30BD81A1BC807D8CCD979FB7009306A (void);
// 0x0000080E System.Void UnityEngine.Rendering.UI.DebugUIHandlerBitField::SetValue(System.Int32,System.Boolean)
extern void DebugUIHandlerBitField_SetValue_mE5AF66449A807CD3704C70057C54662FE1F9B5A2 (void);
// 0x0000080F System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerBitField::OnSelection(System.Boolean,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerBitField_OnSelection_m11DE74FFB02ED64DBB4A40EDF0C27A5FD8F52AD0 (void);
// 0x00000810 System.Void UnityEngine.Rendering.UI.DebugUIHandlerBitField::OnDeselection()
extern void DebugUIHandlerBitField_OnDeselection_m6503BAFA10C4FA983C294370C405B50CD32D3008 (void);
// 0x00000811 System.Void UnityEngine.Rendering.UI.DebugUIHandlerBitField::OnIncrement(System.Boolean)
extern void DebugUIHandlerBitField_OnIncrement_m4C54446147993E50B939A1111F0EE2E40264663E (void);
// 0x00000812 System.Void UnityEngine.Rendering.UI.DebugUIHandlerBitField::OnDecrement(System.Boolean)
extern void DebugUIHandlerBitField_OnDecrement_m7A7522DB09A33E214B84AD1AB34CFE9B2513761C (void);
// 0x00000813 System.Void UnityEngine.Rendering.UI.DebugUIHandlerBitField::OnAction()
extern void DebugUIHandlerBitField_OnAction_m05B63A9FC76EB4DF6203C2DDDDE4D816BD2307B3 (void);
// 0x00000814 UnityEngine.Rendering.UI.DebugUIHandlerWidget UnityEngine.Rendering.UI.DebugUIHandlerBitField::Next()
extern void DebugUIHandlerBitField_Next_m6EC5781F4884FBEF25226F957C2011C8D17291BD (void);
// 0x00000815 System.Void UnityEngine.Rendering.UI.DebugUIHandlerBitField::.ctor()
extern void DebugUIHandlerBitField__ctor_mA489C3E5573EEEB6A429E55DACA850EF4CD3768A (void);
// 0x00000816 System.Void UnityEngine.Rendering.UI.DebugUIHandlerButton::SetWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugUIHandlerButton_SetWidget_mB1AEC7776B1E2D838441E957ACE6973849F10780 (void);
// 0x00000817 System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerButton::OnSelection(System.Boolean,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerButton_OnSelection_mDB94CC63682FF286935252FB0471C520D6502F5F (void);
// 0x00000818 System.Void UnityEngine.Rendering.UI.DebugUIHandlerButton::OnDeselection()
extern void DebugUIHandlerButton_OnDeselection_m06297EBFD0C4B8858B1FF36EBD2F167931893074 (void);
// 0x00000819 System.Void UnityEngine.Rendering.UI.DebugUIHandlerButton::OnAction()
extern void DebugUIHandlerButton_OnAction_m2B245BDA71B32B5F8BD1208C0CC6C9DF6E969E65 (void);
// 0x0000081A System.Void UnityEngine.Rendering.UI.DebugUIHandlerButton::.ctor()
extern void DebugUIHandlerButton__ctor_mB0A7B33C44011CE96C5B101E391C2C233E56CEB0 (void);
// 0x0000081B System.Void UnityEngine.Rendering.UI.DebugUIPrefabBundle::.ctor()
extern void DebugUIPrefabBundle__ctor_m871F8F84F6E1DD549EACAA3E911D32C92DEC3B49 (void);
// 0x0000081C System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas::OnEnable()
extern void DebugUIHandlerCanvas_OnEnable_mEDB28828751EBF1C982CA3E6C45B84406E4E5563 (void);
// 0x0000081D System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas::Update()
extern void DebugUIHandlerCanvas_Update_m824889AC55699E3EED275361E755D61623ABC514 (void);
// 0x0000081E System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas::RequestHierarchyReset()
extern void DebugUIHandlerCanvas_RequestHierarchyReset_m795844483B9DE139935276CB7BB5015E9868071B (void);
// 0x0000081F System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas::ResetAllHierarchy()
extern void DebugUIHandlerCanvas_ResetAllHierarchy_m7583874C16AC780324D02B6728DBD9F38EF5D079 (void);
// 0x00000820 System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas::Rebuild()
extern void DebugUIHandlerCanvas_Rebuild_m035E60DC55732E3B23E7082C4E7518DB72B756ED (void);
// 0x00000821 System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas::Traverse(UnityEngine.Rendering.DebugUI/IContainer,UnityEngine.Transform,UnityEngine.Rendering.UI.DebugUIHandlerWidget,UnityEngine.Rendering.UI.DebugUIHandlerWidget&)
extern void DebugUIHandlerCanvas_Traverse_m7C1AB7935DE310A3493083E3B42DABECD756907D (void);
// 0x00000822 UnityEngine.Rendering.UI.DebugUIHandlerWidget UnityEngine.Rendering.UI.DebugUIHandlerCanvas::GetWidgetFromPath(System.String)
extern void DebugUIHandlerCanvas_GetWidgetFromPath_mD5CB2171F21E6300C270800005853C2D32D3095C (void);
// 0x00000823 System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas::ActivatePanel(System.Int32,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerCanvas_ActivatePanel_mA608E38437FBD80E35B37FC859CE5E8C4741D808 (void);
// 0x00000824 System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas::ChangeSelection(UnityEngine.Rendering.UI.DebugUIHandlerWidget,System.Boolean)
extern void DebugUIHandlerCanvas_ChangeSelection_mE3D51E1E6390B8C7B5926F26122F8AF2588BF03D (void);
// 0x00000825 System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas::SelectPreviousItem()
extern void DebugUIHandlerCanvas_SelectPreviousItem_mFD931025553965A1F5D279142A18F271A0F87D84 (void);
// 0x00000826 System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas::SelectNextPanel()
extern void DebugUIHandlerCanvas_SelectNextPanel_mDEAC3EE25EEEB60C1B1CFBDF0693F629BC6CAE36 (void);
// 0x00000827 System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas::SelectPreviousPanel()
extern void DebugUIHandlerCanvas_SelectPreviousPanel_m8BC52AA79EF5DCDDC00BBBB42AFDB89AEB7D7F34 (void);
// 0x00000828 System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas::SelectNextItem()
extern void DebugUIHandlerCanvas_SelectNextItem_mF022DBBBACE5AE3F83DACC62AFAE5C74AD29131A (void);
// 0x00000829 System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas::ChangeSelectionValue(System.Single)
extern void DebugUIHandlerCanvas_ChangeSelectionValue_m74FA9A84A4B35EC27B0BCB8F936A829D37F4A5EB (void);
// 0x0000082A System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas::ActivateSelection()
extern void DebugUIHandlerCanvas_ActivateSelection_m930DEED7D808635689EC11BA9C0C40BDCB31EC88 (void);
// 0x0000082B System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas::HandleInput()
extern void DebugUIHandlerCanvas_HandleInput_m68428B2A6A70270746D6B490A99D6AD51F112C98 (void);
// 0x0000082C System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas::SetScrollTarget(UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerCanvas_SetScrollTarget_mD305DF6EA8FC2C84F08EDCAE2336DDD15C2E3E86 (void);
// 0x0000082D System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas::.ctor()
extern void DebugUIHandlerCanvas__ctor_m98615720A510A28352CA09B092C5AF43FC27C776 (void);
// 0x0000082E System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas/<>c::.cctor()
extern void U3CU3Ec__cctor_mECD64740EFDF549A390BD7FA9403F7D9F96B8153 (void);
// 0x0000082F System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas/<>c::.ctor()
extern void U3CU3Ec__ctor_m775C4B6FC2C623756041294726B7DA41A73D4926 (void);
// 0x00000830 System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerCanvas/<>c::<Rebuild>b__12_0(UnityEngine.Rendering.DebugUI/Widget)
extern void U3CU3Ec_U3CRebuildU3Eb__12_0_m0B768BF30ADC6380A48FEBAAE47297DE18E12394 (void);
// 0x00000831 System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas/<>c::<ActivatePanel>b__15_0(UnityEngine.Rendering.UI.DebugUIHandlerPanel)
extern void U3CU3Ec_U3CActivatePanelU3Eb__15_0_m178DE0B54B076B42EE28B1256BC18545966CA344 (void);
// 0x00000832 System.Void UnityEngine.Rendering.UI.DebugUIHandlerCanvas/<>c__DisplayClass14_0::.ctor()
extern void U3CU3Ec__DisplayClass14_0__ctor_m861EA10CA07D6929E70405A3BA2BA284C590C739 (void);
// 0x00000833 System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerCanvas/<>c__DisplayClass14_0::<GetWidgetFromPath>b__0(UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void U3CU3Ec__DisplayClass14_0_U3CGetWidgetFromPathU3Eb__0_mF4214EF157153DCDF6CDE37D01DD63581EF7AF63 (void);
// 0x00000834 System.Void UnityEngine.Rendering.UI.DebugUIHandlerColor::SetWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugUIHandlerColor_SetWidget_mFBE0123D585E284425748A780F55D4FB030388CD (void);
// 0x00000835 System.Void UnityEngine.Rendering.UI.DebugUIHandlerColor::SetValue(System.Single,System.Boolean,System.Boolean,System.Boolean,System.Boolean)
extern void DebugUIHandlerColor_SetValue_m076FEA35FD3244F27C5B751CD68071091FFD0B60 (void);
// 0x00000836 System.Void UnityEngine.Rendering.UI.DebugUIHandlerColor::SetupSettings(UnityEngine.Rendering.UI.DebugUIHandlerIndirectFloatField)
extern void DebugUIHandlerColor_SetupSettings_mE3ED3D6152635D1EEB1D5076089E0588957E9E46 (void);
// 0x00000837 System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerColor::OnSelection(System.Boolean,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerColor_OnSelection_mFA64A94310860C1D786BB00CAE00D4203B323394 (void);
// 0x00000838 System.Void UnityEngine.Rendering.UI.DebugUIHandlerColor::OnDeselection()
extern void DebugUIHandlerColor_OnDeselection_mCFF411453C3E08A1091DA1A89742DE5AC06921F1 (void);
// 0x00000839 System.Void UnityEngine.Rendering.UI.DebugUIHandlerColor::OnIncrement(System.Boolean)
extern void DebugUIHandlerColor_OnIncrement_m1591CEE2831C84A155719FCA0665C1C4AD877046 (void);
// 0x0000083A System.Void UnityEngine.Rendering.UI.DebugUIHandlerColor::OnDecrement(System.Boolean)
extern void DebugUIHandlerColor_OnDecrement_m993B7499D6E2772D6DBA43EDAA40B90550D3F2F1 (void);
// 0x0000083B System.Void UnityEngine.Rendering.UI.DebugUIHandlerColor::OnAction()
extern void DebugUIHandlerColor_OnAction_m2E3B5E2D0D52E3F30759F91754378EA92BC0BD06 (void);
// 0x0000083C System.Void UnityEngine.Rendering.UI.DebugUIHandlerColor::UpdateColor()
extern void DebugUIHandlerColor_UpdateColor_m0D7C0E504BECE85E4E0A47F9D69DA52B2E7ABD94 (void);
// 0x0000083D UnityEngine.Rendering.UI.DebugUIHandlerWidget UnityEngine.Rendering.UI.DebugUIHandlerColor::Next()
extern void DebugUIHandlerColor_Next_mE601A99ACB9E92FC1A40C2C952744C5C9372230A (void);
// 0x0000083E System.Void UnityEngine.Rendering.UI.DebugUIHandlerColor::.ctor()
extern void DebugUIHandlerColor__ctor_mD6AF38D964CAAC9CC0759F2DE6DC077ABCA25ED6 (void);
// 0x0000083F System.Single UnityEngine.Rendering.UI.DebugUIHandlerColor::<SetWidget>b__9_0()
extern void DebugUIHandlerColor_U3CSetWidgetU3Eb__9_0_mBAFD5BD05F214AC2AB8E17AEBEB13FA1381E17EC (void);
// 0x00000840 System.Void UnityEngine.Rendering.UI.DebugUIHandlerColor::<SetWidget>b__9_1(System.Single)
extern void DebugUIHandlerColor_U3CSetWidgetU3Eb__9_1_m2967C435E96AB4E261D1338BA62BF4D99A6D4CE3 (void);
// 0x00000841 System.Single UnityEngine.Rendering.UI.DebugUIHandlerColor::<SetWidget>b__9_2()
extern void DebugUIHandlerColor_U3CSetWidgetU3Eb__9_2_m69B6AA580A85659F23F70B1460442019B83343C6 (void);
// 0x00000842 System.Void UnityEngine.Rendering.UI.DebugUIHandlerColor::<SetWidget>b__9_3(System.Single)
extern void DebugUIHandlerColor_U3CSetWidgetU3Eb__9_3_m54A73A1D77BCC317E3F597AD6A2E7829739304C3 (void);
// 0x00000843 System.Single UnityEngine.Rendering.UI.DebugUIHandlerColor::<SetWidget>b__9_4()
extern void DebugUIHandlerColor_U3CSetWidgetU3Eb__9_4_m408843B0828821EE347D7DE706C7A405F0FDC871 (void);
// 0x00000844 System.Void UnityEngine.Rendering.UI.DebugUIHandlerColor::<SetWidget>b__9_5(System.Single)
extern void DebugUIHandlerColor_U3CSetWidgetU3Eb__9_5_m436E90BB8D0498318BD2634574361FB231DFF66D (void);
// 0x00000845 System.Single UnityEngine.Rendering.UI.DebugUIHandlerColor::<SetWidget>b__9_6()
extern void DebugUIHandlerColor_U3CSetWidgetU3Eb__9_6_mADC9E3769B689A784BAE829BD1B84EF6F0FEFE94 (void);
// 0x00000846 System.Void UnityEngine.Rendering.UI.DebugUIHandlerColor::<SetWidget>b__9_7(System.Single)
extern void DebugUIHandlerColor_U3CSetWidgetU3Eb__9_7_m8D466921CECBD6390902A54733F9CD84DE7C7209 (void);
// 0x00000847 System.Single UnityEngine.Rendering.UI.DebugUIHandlerColor::<SetupSettings>b__11_0()
extern void DebugUIHandlerColor_U3CSetupSettingsU3Eb__11_0_m1650683DE2689FA919F5F23D7B3E37C1D1C698FC (void);
// 0x00000848 System.Single UnityEngine.Rendering.UI.DebugUIHandlerColor::<SetupSettings>b__11_1()
extern void DebugUIHandlerColor_U3CSetupSettingsU3Eb__11_1_mFB55DFA1E3A700E6C138C5FBC65EB9A73E7F2970 (void);
// 0x00000849 System.Single UnityEngine.Rendering.UI.DebugUIHandlerColor::<SetupSettings>b__11_2()
extern void DebugUIHandlerColor_U3CSetupSettingsU3Eb__11_2_mAE4CAA0731F89269A24512B33CFDDD31CD325412 (void);
// 0x0000084A UnityEngine.Rendering.UI.DebugUIHandlerWidget UnityEngine.Rendering.UI.DebugUIHandlerContainer::GetFirstItem()
extern void DebugUIHandlerContainer_GetFirstItem_m6218F40059CE4BA28F39DA27F7FC12A59C225F80 (void);
// 0x0000084B UnityEngine.Rendering.UI.DebugUIHandlerWidget UnityEngine.Rendering.UI.DebugUIHandlerContainer::GetLastItem()
extern void DebugUIHandlerContainer_GetLastItem_m19783039A96D0E481190EC168D1147EA34C353FB (void);
// 0x0000084C System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerContainer::IsDirectChild(UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerContainer_IsDirectChild_mCD24A410A0F20F48BDCBE21A6878072614B9F7FB (void);
// 0x0000084D System.Collections.Generic.List`1<UnityEngine.Rendering.UI.DebugUIHandlerWidget> UnityEngine.Rendering.UI.DebugUIHandlerContainer::GetActiveChildren()
extern void DebugUIHandlerContainer_GetActiveChildren_mB84ADFB63E20AA9B27EF865FE730DC75432598F9 (void);
// 0x0000084E System.Void UnityEngine.Rendering.UI.DebugUIHandlerContainer::.ctor()
extern void DebugUIHandlerContainer__ctor_m19965C49C75B009FBA764A4802430855741F3310 (void);
// 0x0000084F System.Void UnityEngine.Rendering.UI.DebugUIHandlerContainer/<>c__DisplayClass3_0::.ctor()
extern void U3CU3Ec__DisplayClass3_0__ctor_m7C972827CF4936AA55AB609E47F79190416DDD2E (void);
// 0x00000850 System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerContainer/<>c__DisplayClass3_0::<IsDirectChild>b__0(UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void U3CU3Ec__DisplayClass3_0_U3CIsDirectChildU3Eb__0_mE86B269F22B9D136B3B900B71A6540059D336A60 (void);
// 0x00000851 System.Void UnityEngine.Rendering.UI.DebugUIHandlerEnumField::SetWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugUIHandlerEnumField_SetWidget_m87B596B3F7F6281BBEBE571BE69B7555C7F6A44A (void);
// 0x00000852 System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerEnumField::OnSelection(System.Boolean,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerEnumField_OnSelection_mA059DD228D6EAD4D8CD76572424A2CAE8F8B9B59 (void);
// 0x00000853 System.Void UnityEngine.Rendering.UI.DebugUIHandlerEnumField::OnDeselection()
extern void DebugUIHandlerEnumField_OnDeselection_m8F23BC6DA12275BA2FB6DE84EC1835E5A7E433F8 (void);
// 0x00000854 System.Void UnityEngine.Rendering.UI.DebugUIHandlerEnumField::OnAction()
extern void DebugUIHandlerEnumField_OnAction_m48070D90F714A776FD5D0FBEC7DD5246DCF8C407 (void);
// 0x00000855 System.Void UnityEngine.Rendering.UI.DebugUIHandlerEnumField::OnIncrement(System.Boolean)
extern void DebugUIHandlerEnumField_OnIncrement_m4339F79F70A2975F699FD3CBEF4865A1E451B5BE (void);
// 0x00000856 System.Void UnityEngine.Rendering.UI.DebugUIHandlerEnumField::OnDecrement(System.Boolean)
extern void DebugUIHandlerEnumField_OnDecrement_mADC546644129D9B435D96D6CC681B29A31ACDF62 (void);
// 0x00000857 System.Void UnityEngine.Rendering.UI.DebugUIHandlerEnumField::UpdateValueLabel()
extern void DebugUIHandlerEnumField_UpdateValueLabel_m36CA0D43AB06505769BF6D0B38D975D0D42612A3 (void);
// 0x00000858 System.Void UnityEngine.Rendering.UI.DebugUIHandlerEnumField::.ctor()
extern void DebugUIHandlerEnumField__ctor_mF6183B378AF80A25041E59C7116A05CA64F50813 (void);
// 0x00000859 System.Void UnityEngine.Rendering.UI.DebugUIHandlerEnumHistory::SetWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugUIHandlerEnumHistory_SetWidget_m63DB0958ED2BF1EDB8253A3A9F6DB85672438B39 (void);
// 0x0000085A System.Void UnityEngine.Rendering.UI.DebugUIHandlerEnumHistory::UpdateValueLabel()
extern void DebugUIHandlerEnumHistory_UpdateValueLabel_m8BE6CCDBC0005E5C81A3463462393713D95B2614 (void);
// 0x0000085B System.Collections.IEnumerator UnityEngine.Rendering.UI.DebugUIHandlerEnumHistory::RefreshAfterSanitization()
extern void DebugUIHandlerEnumHistory_RefreshAfterSanitization_m9BAE31D9C443E5C930847EDD01B99FB78A77ACF2 (void);
// 0x0000085C System.Void UnityEngine.Rendering.UI.DebugUIHandlerEnumHistory::.ctor()
extern void DebugUIHandlerEnumHistory__ctor_m0916E2112F932065DBBAF9F3813C9364E8CA7CE2 (void);
// 0x0000085D System.Void UnityEngine.Rendering.UI.DebugUIHandlerEnumHistory/<RefreshAfterSanitization>d__4::.ctor(System.Int32)
extern void U3CRefreshAfterSanitizationU3Ed__4__ctor_mA1B6468C0591D678F9997F3BC24D9FBB77DC8C7B (void);
// 0x0000085E System.Void UnityEngine.Rendering.UI.DebugUIHandlerEnumHistory/<RefreshAfterSanitization>d__4::System.IDisposable.Dispose()
extern void U3CRefreshAfterSanitizationU3Ed__4_System_IDisposable_Dispose_mC1C26EC8604D476A3D451C15B9F9470753A5FE16 (void);
// 0x0000085F System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerEnumHistory/<RefreshAfterSanitization>d__4::MoveNext()
extern void U3CRefreshAfterSanitizationU3Ed__4_MoveNext_m9C60488CBAA36235D58584F9B11FA56A5E43E90C (void);
// 0x00000860 System.Object UnityEngine.Rendering.UI.DebugUIHandlerEnumHistory/<RefreshAfterSanitization>d__4::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CRefreshAfterSanitizationU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m187EBBE4E909383FD956756EC3A3ED66B408DF7E (void);
// 0x00000861 System.Void UnityEngine.Rendering.UI.DebugUIHandlerEnumHistory/<RefreshAfterSanitization>d__4::System.Collections.IEnumerator.Reset()
extern void U3CRefreshAfterSanitizationU3Ed__4_System_Collections_IEnumerator_Reset_mC899145E1B57D3F7A421DBD5CA16505B7948E91A (void);
// 0x00000862 System.Object UnityEngine.Rendering.UI.DebugUIHandlerEnumHistory/<RefreshAfterSanitization>d__4::System.Collections.IEnumerator.get_Current()
extern void U3CRefreshAfterSanitizationU3Ed__4_System_Collections_IEnumerator_get_Current_m080AE81866B34CC4BEDD1D0B670929DD58FA78BA (void);
// 0x00000863 System.Void UnityEngine.Rendering.UI.DebugUIHandlerFloatField::SetWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugUIHandlerFloatField_SetWidget_mEC7E9E29D290619CEE8E85A87B6E299D41B51D4F (void);
// 0x00000864 System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerFloatField::OnSelection(System.Boolean,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerFloatField_OnSelection_m20116B3240DAC17E1A866FFF9762BFC7E5F59D3E (void);
// 0x00000865 System.Void UnityEngine.Rendering.UI.DebugUIHandlerFloatField::OnDeselection()
extern void DebugUIHandlerFloatField_OnDeselection_m597ACA65A33D50B70B712F95B687D782FF2187C9 (void);
// 0x00000866 System.Void UnityEngine.Rendering.UI.DebugUIHandlerFloatField::OnIncrement(System.Boolean)
extern void DebugUIHandlerFloatField_OnIncrement_mE2FBC3591F6E33EE3000061CE6FBB4410340B904 (void);
// 0x00000867 System.Void UnityEngine.Rendering.UI.DebugUIHandlerFloatField::OnDecrement(System.Boolean)
extern void DebugUIHandlerFloatField_OnDecrement_m6DF136E8C97089F9782AD7A295AF9ED038371AC4 (void);
// 0x00000868 System.Void UnityEngine.Rendering.UI.DebugUIHandlerFloatField::ChangeValue(System.Boolean,System.Single)
extern void DebugUIHandlerFloatField_ChangeValue_m2D26CF4F074BFC3E8A2699EC4C4F79692FBE986B (void);
// 0x00000869 System.Void UnityEngine.Rendering.UI.DebugUIHandlerFloatField::UpdateValueLabel()
extern void DebugUIHandlerFloatField_UpdateValueLabel_m82D62BFA0C18D2A4B2B1A6869F059FD2B7E836B1 (void);
// 0x0000086A System.Void UnityEngine.Rendering.UI.DebugUIHandlerFloatField::.ctor()
extern void DebugUIHandlerFloatField__ctor_mA3216AEFF7C140CB330D3E43C590438DA39265C3 (void);
// 0x0000086B System.Void UnityEngine.Rendering.UI.DebugUIHandlerFoldout::SetWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugUIHandlerFoldout_SetWidget_m828CBD39A3BD5745A713D2EA05DDA1BACC7B33F5 (void);
// 0x0000086C System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerFoldout::OnSelection(System.Boolean,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerFoldout_OnSelection_m0328778E15A4BE0ACF3915E9C27B15E4EE9B5551 (void);
// 0x0000086D System.Void UnityEngine.Rendering.UI.DebugUIHandlerFoldout::OnDeselection()
extern void DebugUIHandlerFoldout_OnDeselection_mA9BBD048A4139295D54316BA19A69BB73BD6D327 (void);
// 0x0000086E System.Void UnityEngine.Rendering.UI.DebugUIHandlerFoldout::OnIncrement(System.Boolean)
extern void DebugUIHandlerFoldout_OnIncrement_m0F9F9643478577474FA6CEB857FCDFEC50E1C767 (void);
// 0x0000086F System.Void UnityEngine.Rendering.UI.DebugUIHandlerFoldout::OnDecrement(System.Boolean)
extern void DebugUIHandlerFoldout_OnDecrement_mCB9E8525619929BFC7CC55C44BE5A56459C1CB7D (void);
// 0x00000870 System.Void UnityEngine.Rendering.UI.DebugUIHandlerFoldout::OnAction()
extern void DebugUIHandlerFoldout_OnAction_mDEBF59190697160E20C69825947CE9D5DEC30FB0 (void);
// 0x00000871 System.Void UnityEngine.Rendering.UI.DebugUIHandlerFoldout::UpdateValue()
extern void DebugUIHandlerFoldout_UpdateValue_m8CE29D10B0F61188598331EBD881B8BA05B8B40E (void);
// 0x00000872 UnityEngine.Rendering.UI.DebugUIHandlerWidget UnityEngine.Rendering.UI.DebugUIHandlerFoldout::Next()
extern void DebugUIHandlerFoldout_Next_m35EC9520B4E86C3FA7BC8A969C8227BCBFB10EBC (void);
// 0x00000873 System.Void UnityEngine.Rendering.UI.DebugUIHandlerFoldout::.ctor()
extern void DebugUIHandlerFoldout__ctor_m8EA66D76CD7E71558FDA92201638EC736F33FB66 (void);
// 0x00000874 System.Void UnityEngine.Rendering.UI.DebugUIHandlerGroup::SetWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugUIHandlerGroup_SetWidget_m9D7EA85B890C75998306B269A787E181B5102C65 (void);
// 0x00000875 System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerGroup::OnSelection(System.Boolean,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerGroup_OnSelection_mB089F2E1461618C744B0A54A28B5CFB07EFAB701 (void);
// 0x00000876 UnityEngine.Rendering.UI.DebugUIHandlerWidget UnityEngine.Rendering.UI.DebugUIHandlerGroup::Next()
extern void DebugUIHandlerGroup_Next_m0E5C76D1C72B2FC74608AEDD3F7A687D0E17033A (void);
// 0x00000877 System.Void UnityEngine.Rendering.UI.DebugUIHandlerGroup::.ctor()
extern void DebugUIHandlerGroup__ctor_m087A8C431E01E7AF80211A308D54B25FA5BD2250 (void);
// 0x00000878 System.Void UnityEngine.Rendering.UI.DebugUIHandlerHBox::SetWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugUIHandlerHBox_SetWidget_m6FFBC1ED54189C8973415D2954E02C269A278779 (void);
// 0x00000879 System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerHBox::OnSelection(System.Boolean,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerHBox_OnSelection_mE4201C3C243D3EAE0A64EFF5987F9537206B4167 (void);
// 0x0000087A UnityEngine.Rendering.UI.DebugUIHandlerWidget UnityEngine.Rendering.UI.DebugUIHandlerHBox::Next()
extern void DebugUIHandlerHBox_Next_m1C398F0C0D1CDC97A08B3CA7C04D7AFCF32F5EEB (void);
// 0x0000087B System.Void UnityEngine.Rendering.UI.DebugUIHandlerHBox::.ctor()
extern void DebugUIHandlerHBox__ctor_m744194D9207EF339C9D586A969050830503A51F6 (void);
// 0x0000087C System.Void UnityEngine.Rendering.UI.DebugUIHandlerIndirectFloatField::Init()
extern void DebugUIHandlerIndirectFloatField_Init_m8297DF272ED8D2435861EDB77AABF58290B96840 (void);
// 0x0000087D System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerIndirectFloatField::OnSelection(System.Boolean,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerIndirectFloatField_OnSelection_mA239F05E325E92B8BD5D359DAD11F6DC87260848 (void);
// 0x0000087E System.Void UnityEngine.Rendering.UI.DebugUIHandlerIndirectFloatField::OnDeselection()
extern void DebugUIHandlerIndirectFloatField_OnDeselection_m6C75859C026A3CA540B14970E007348B8747586A (void);
// 0x0000087F System.Void UnityEngine.Rendering.UI.DebugUIHandlerIndirectFloatField::OnIncrement(System.Boolean)
extern void DebugUIHandlerIndirectFloatField_OnIncrement_mC97828C6D3D2591BB9C2547ADBE03BC2C6C96F23 (void);
// 0x00000880 System.Void UnityEngine.Rendering.UI.DebugUIHandlerIndirectFloatField::OnDecrement(System.Boolean)
extern void DebugUIHandlerIndirectFloatField_OnDecrement_mFC9FE6DCC32C5C15652B0976D8D40C251538D0AD (void);
// 0x00000881 System.Void UnityEngine.Rendering.UI.DebugUIHandlerIndirectFloatField::ChangeValue(System.Boolean,System.Single)
extern void DebugUIHandlerIndirectFloatField_ChangeValue_m03670DD0C17DA24ACED728FE0D405138C9D40A40 (void);
// 0x00000882 System.Void UnityEngine.Rendering.UI.DebugUIHandlerIndirectFloatField::UpdateValueLabel()
extern void DebugUIHandlerIndirectFloatField_UpdateValueLabel_mC1801ED586636474218A11B89D795A6FF50E9CE8 (void);
// 0x00000883 System.Void UnityEngine.Rendering.UI.DebugUIHandlerIndirectFloatField::.ctor()
extern void DebugUIHandlerIndirectFloatField__ctor_m0ACC509CE6DC880F0F7D9F92BD4C651E3C48C065 (void);
// 0x00000884 System.Void UnityEngine.Rendering.UI.DebugUIHandlerIndirectToggle::Init()
extern void DebugUIHandlerIndirectToggle_Init_mFB2213D89BCF29671F255C37E862F94F31F12506 (void);
// 0x00000885 System.Void UnityEngine.Rendering.UI.DebugUIHandlerIndirectToggle::OnToggleValueChanged(System.Boolean)
extern void DebugUIHandlerIndirectToggle_OnToggleValueChanged_m4B8562DBAD02E683C51D2E3E293F948139D8103F (void);
// 0x00000886 System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerIndirectToggle::OnSelection(System.Boolean,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerIndirectToggle_OnSelection_m9AB28E2FE889601DC2241D2F9FF205DA416E5238 (void);
// 0x00000887 System.Void UnityEngine.Rendering.UI.DebugUIHandlerIndirectToggle::OnDeselection()
extern void DebugUIHandlerIndirectToggle_OnDeselection_m29103A2BDD465341E0FBFD47E23D0A0C77F7DD78 (void);
// 0x00000888 System.Void UnityEngine.Rendering.UI.DebugUIHandlerIndirectToggle::OnAction()
extern void DebugUIHandlerIndirectToggle_OnAction_mE8B5245408FFB96A5AC3CAD66913ECC288647683 (void);
// 0x00000889 System.Void UnityEngine.Rendering.UI.DebugUIHandlerIndirectToggle::UpdateValueLabel()
extern void DebugUIHandlerIndirectToggle_UpdateValueLabel_mECFCCF09947AA410A2D6F756F08BB6CDDCD05AAC (void);
// 0x0000088A System.Void UnityEngine.Rendering.UI.DebugUIHandlerIndirectToggle::.ctor()
extern void DebugUIHandlerIndirectToggle__ctor_m8C396EBDCA669A7559520174C0BECE948E2E6964 (void);
// 0x0000088B System.Void UnityEngine.Rendering.UI.DebugUIHandlerIntField::SetWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugUIHandlerIntField_SetWidget_mECE6C25B51EE73AF198E2A839B99A12107174225 (void);
// 0x0000088C System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerIntField::OnSelection(System.Boolean,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerIntField_OnSelection_m6275F31B59253780EEA5A158D1074EF63131AAA4 (void);
// 0x0000088D System.Void UnityEngine.Rendering.UI.DebugUIHandlerIntField::OnDeselection()
extern void DebugUIHandlerIntField_OnDeselection_m56D7C9510BABBB401C6E3FAD31553FE48BE98A6C (void);
// 0x0000088E System.Void UnityEngine.Rendering.UI.DebugUIHandlerIntField::OnIncrement(System.Boolean)
extern void DebugUIHandlerIntField_OnIncrement_mDB8DB60DDFD35E5521CAD4BCDB4BC6A3B1ADF072 (void);
// 0x0000088F System.Void UnityEngine.Rendering.UI.DebugUIHandlerIntField::OnDecrement(System.Boolean)
extern void DebugUIHandlerIntField_OnDecrement_m31C3683D87F62142EA82E3345E9F41F7B6861642 (void);
// 0x00000890 System.Void UnityEngine.Rendering.UI.DebugUIHandlerIntField::ChangeValue(System.Boolean,System.Int32)
extern void DebugUIHandlerIntField_ChangeValue_mD8057A2A9FD94293116182A6407B63B5A21EAE13 (void);
// 0x00000891 System.Void UnityEngine.Rendering.UI.DebugUIHandlerIntField::UpdateValueLabel()
extern void DebugUIHandlerIntField_UpdateValueLabel_mE37F658D4F377685F119C9C2139970567BBACD79 (void);
// 0x00000892 System.Void UnityEngine.Rendering.UI.DebugUIHandlerIntField::.ctor()
extern void DebugUIHandlerIntField__ctor_m3DE21A5DC240FA90CCAA3C2473B740EA5DB6795D (void);
// 0x00000893 System.Void UnityEngine.Rendering.UI.DebugUIHandlerMessageBox::SetWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugUIHandlerMessageBox_SetWidget_mDD74A0DBC434597426FEE13BC29072D50CBC9A06 (void);
// 0x00000894 System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerMessageBox::OnSelection(System.Boolean,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerMessageBox_OnSelection_mD6864FB70FACC2CAEE460F1539A13C3BF77CE037 (void);
// 0x00000895 System.Void UnityEngine.Rendering.UI.DebugUIHandlerMessageBox::.ctor()
extern void DebugUIHandlerMessageBox__ctor_m62554FDCA7615AE940839BCFB47CB6D08E70EA3A (void);
// 0x00000896 System.Void UnityEngine.Rendering.UI.DebugUIHandlerMessageBox::.cctor()
extern void DebugUIHandlerMessageBox__cctor_m83DAEFEA945E20EC7C855A640A2A9EDD46B254F6 (void);
// 0x00000897 System.Void UnityEngine.Rendering.UI.DebugUIHandlerPanel::OnEnable()
extern void DebugUIHandlerPanel_OnEnable_m69DF0926526D7445EBE1E32FE4404A81BABBCDFD (void);
// 0x00000898 System.Void UnityEngine.Rendering.UI.DebugUIHandlerPanel::SetPanel(UnityEngine.Rendering.DebugUI/Panel)
extern void DebugUIHandlerPanel_SetPanel_mC9EE00598AED6937770AE24C09F5305B7EBDE271 (void);
// 0x00000899 UnityEngine.Rendering.DebugUI/Panel UnityEngine.Rendering.UI.DebugUIHandlerPanel::GetPanel()
extern void DebugUIHandlerPanel_GetPanel_m0A0D797F47E06C4AA2786605A367F93F0033291C (void);
// 0x0000089A System.Void UnityEngine.Rendering.UI.DebugUIHandlerPanel::SelectNextItem()
extern void DebugUIHandlerPanel_SelectNextItem_mE8441685CAA9F387EF2CE85F0891BE31AAA02D22 (void);
// 0x0000089B System.Void UnityEngine.Rendering.UI.DebugUIHandlerPanel::SelectPreviousItem()
extern void DebugUIHandlerPanel_SelectPreviousItem_m663163976D65D0D2DC673C57045428EC6A8A3D07 (void);
// 0x0000089C System.Void UnityEngine.Rendering.UI.DebugUIHandlerPanel::OnScrollbarClicked()
extern void DebugUIHandlerPanel_OnScrollbarClicked_m59907071BBE4297C3A0129488E8037487E957BD5 (void);
// 0x0000089D System.Void UnityEngine.Rendering.UI.DebugUIHandlerPanel::SetScrollTarget(UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerPanel_SetScrollTarget_mBF5B2C49CA07FBD4E66F98A8A66B371548371E1D (void);
// 0x0000089E System.Void UnityEngine.Rendering.UI.DebugUIHandlerPanel::UpdateScroll()
extern void DebugUIHandlerPanel_UpdateScroll_m09894F7991090ADDF2CA28D1427902B13315E2AD (void);
// 0x0000089F System.Single UnityEngine.Rendering.UI.DebugUIHandlerPanel::GetYPosInScroll(UnityEngine.RectTransform)
extern void DebugUIHandlerPanel_GetYPosInScroll_mF30290CAB64304041EE4B2F5A04CDAF03E3E7397 (void);
// 0x000008A0 UnityEngine.Rendering.UI.DebugUIHandlerWidget UnityEngine.Rendering.UI.DebugUIHandlerPanel::GetFirstItem()
extern void DebugUIHandlerPanel_GetFirstItem_mABA1E55122FE52BB4A783346971540AC19CF37A0 (void);
// 0x000008A1 System.Void UnityEngine.Rendering.UI.DebugUIHandlerPanel::ResetDebugManager()
extern void DebugUIHandlerPanel_ResetDebugManager_m71122CF385993479CBC5C89B730A14AB60A6A35F (void);
// 0x000008A2 System.Void UnityEngine.Rendering.UI.DebugUIHandlerPanel::.ctor()
extern void DebugUIHandlerPanel__ctor_mB233BB0C2B6784DC0B893D1ECB6BF9E02534BB01 (void);
// 0x000008A3 System.Void UnityEngine.Rendering.UI.DebugUIHandlerPersistentCanvas::Toggle(UnityEngine.Rendering.DebugUI/Value)
extern void DebugUIHandlerPersistentCanvas_Toggle_m29203DB1C46DF26C0B2726B6340DB0CEC27A15D8 (void);
// 0x000008A4 System.Void UnityEngine.Rendering.UI.DebugUIHandlerPersistentCanvas::Clear()
extern void DebugUIHandlerPersistentCanvas_Clear_m2A4309CDFE971AA52847D9072DE808798DB1C580 (void);
// 0x000008A5 System.Void UnityEngine.Rendering.UI.DebugUIHandlerPersistentCanvas::.ctor()
extern void DebugUIHandlerPersistentCanvas__ctor_mA5D2326C74A1A72C5E9802691ED667CF5991841E (void);
// 0x000008A6 System.Void UnityEngine.Rendering.UI.DebugUIHandlerPersistentCanvas/<>c__DisplayClass3_0::.ctor()
extern void U3CU3Ec__DisplayClass3_0__ctor_m36CB7670C22CE2BC7AEBDF17C15A238D1917B014 (void);
// 0x000008A7 System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerPersistentCanvas/<>c__DisplayClass3_0::<Toggle>b__0(UnityEngine.Rendering.UI.DebugUIHandlerValue)
extern void U3CU3Ec__DisplayClass3_0_U3CToggleU3Eb__0_mCAEB7CF73BAB66E6DDA60AF4E42AFC9F760B4B63 (void);
// 0x000008A8 System.Void UnityEngine.Rendering.UI.DebugUIHandlerRow::OnEnable()
extern void DebugUIHandlerRow_OnEnable_m49F4F79E8882BB233938663A86135EF0F997B32B (void);
// 0x000008A9 System.Void UnityEngine.Rendering.UI.DebugUIHandlerRow::Update()
extern void DebugUIHandlerRow_Update_mBE152302B758037599B09EDD65EA506773BD20DA (void);
// 0x000008AA System.Void UnityEngine.Rendering.UI.DebugUIHandlerRow::.ctor()
extern void DebugUIHandlerRow__ctor_m25AA9A1DE431B4C5C7CFED066F3DC0721EB6DF32 (void);
// 0x000008AB System.Void UnityEngine.Rendering.UI.DebugUIHandlerToggle::SetWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugUIHandlerToggle_SetWidget_mB013EB6AEA2897CEA4522F3D1306B1A376C62BC8 (void);
// 0x000008AC System.Void UnityEngine.Rendering.UI.DebugUIHandlerToggle::OnToggleValueChanged(System.Boolean)
extern void DebugUIHandlerToggle_OnToggleValueChanged_m547F4E123162D824FD6BF35941CFB92DBA301B06 (void);
// 0x000008AD System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerToggle::OnSelection(System.Boolean,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerToggle_OnSelection_mC8CB6EA7DEB61BAF4F426B059218915AEA157115 (void);
// 0x000008AE System.Void UnityEngine.Rendering.UI.DebugUIHandlerToggle::OnDeselection()
extern void DebugUIHandlerToggle_OnDeselection_m5DC6563E07ABC6CD640C94827FC876D5E8068797 (void);
// 0x000008AF System.Void UnityEngine.Rendering.UI.DebugUIHandlerToggle::OnAction()
extern void DebugUIHandlerToggle_OnAction_m4891CDA4A337AD1DA6B047E3DF4A363B2ED07ABE (void);
// 0x000008B0 System.Void UnityEngine.Rendering.UI.DebugUIHandlerToggle::UpdateValueLabel()
extern void DebugUIHandlerToggle_UpdateValueLabel_mA8DDCA729EAEF8AA280CA7746033DA73A25D2D59 (void);
// 0x000008B1 System.Void UnityEngine.Rendering.UI.DebugUIHandlerToggle::.ctor()
extern void DebugUIHandlerToggle__ctor_m7B4B26A73C24FF78F61592F9911F87650F0A7687 (void);
// 0x000008B2 System.Void UnityEngine.Rendering.UI.DebugUIHandlerToggleHistory::SetWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugUIHandlerToggleHistory_SetWidget_mF1C6F29B86AA5367D2C4B5BFF537F3F566B3E7DC (void);
// 0x000008B3 System.Void UnityEngine.Rendering.UI.DebugUIHandlerToggleHistory::UpdateValueLabel()
extern void DebugUIHandlerToggleHistory_UpdateValueLabel_m53680DAC7821FA5564196843381D8F885E3F428D (void);
// 0x000008B4 System.Collections.IEnumerator UnityEngine.Rendering.UI.DebugUIHandlerToggleHistory::RefreshAfterSanitization()
extern void DebugUIHandlerToggleHistory_RefreshAfterSanitization_mB09CBD9491CC001A16B22FD2F7333153BF612506 (void);
// 0x000008B5 System.Void UnityEngine.Rendering.UI.DebugUIHandlerToggleHistory::.ctor()
extern void DebugUIHandlerToggleHistory__ctor_m1D0260C9C7CFB872A3E21524715444ED3F6FEFBC (void);
// 0x000008B6 System.Void UnityEngine.Rendering.UI.DebugUIHandlerToggleHistory/<RefreshAfterSanitization>d__4::.ctor(System.Int32)
extern void U3CRefreshAfterSanitizationU3Ed__4__ctor_mE7A3146511E19C2501D1087E3FCFBE75837DCBAB (void);
// 0x000008B7 System.Void UnityEngine.Rendering.UI.DebugUIHandlerToggleHistory/<RefreshAfterSanitization>d__4::System.IDisposable.Dispose()
extern void U3CRefreshAfterSanitizationU3Ed__4_System_IDisposable_Dispose_m916C7561F787139BCAAEB10C8D43BB643B125514 (void);
// 0x000008B8 System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerToggleHistory/<RefreshAfterSanitization>d__4::MoveNext()
extern void U3CRefreshAfterSanitizationU3Ed__4_MoveNext_m631C0808EE7D82FA1D6F0B8039D3AA93965C29F1 (void);
// 0x000008B9 System.Object UnityEngine.Rendering.UI.DebugUIHandlerToggleHistory/<RefreshAfterSanitization>d__4::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CRefreshAfterSanitizationU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mC83DF44B95C3BEFEAE450D2F2699A606E94F935F (void);
// 0x000008BA System.Void UnityEngine.Rendering.UI.DebugUIHandlerToggleHistory/<RefreshAfterSanitization>d__4::System.Collections.IEnumerator.Reset()
extern void U3CRefreshAfterSanitizationU3Ed__4_System_Collections_IEnumerator_Reset_m97EA3023930C1F29E1086F7D141B93ED488E219C (void);
// 0x000008BB System.Object UnityEngine.Rendering.UI.DebugUIHandlerToggleHistory/<RefreshAfterSanitization>d__4::System.Collections.IEnumerator.get_Current()
extern void U3CRefreshAfterSanitizationU3Ed__4_System_Collections_IEnumerator_get_Current_m70EEB9C8257E30C1EB8730D7C52F5B24DD5860F1 (void);
// 0x000008BC System.Void UnityEngine.Rendering.UI.DebugUIHandlerUIntField::SetWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugUIHandlerUIntField_SetWidget_mE43AAC56A1B3EE0B80878651978FA58835204D43 (void);
// 0x000008BD System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerUIntField::OnSelection(System.Boolean,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerUIntField_OnSelection_mC17408F0DF4132756C3356AC3DDB3DDE41615018 (void);
// 0x000008BE System.Void UnityEngine.Rendering.UI.DebugUIHandlerUIntField::OnDeselection()
extern void DebugUIHandlerUIntField_OnDeselection_m2AE7C5834668EC7592BAC21B28A92EF2B63873BE (void);
// 0x000008BF System.Void UnityEngine.Rendering.UI.DebugUIHandlerUIntField::OnIncrement(System.Boolean)
extern void DebugUIHandlerUIntField_OnIncrement_m54BF1BBC4C764649885CB3FA3FBC45B858554DB8 (void);
// 0x000008C0 System.Void UnityEngine.Rendering.UI.DebugUIHandlerUIntField::OnDecrement(System.Boolean)
extern void DebugUIHandlerUIntField_OnDecrement_m13F770A6F4E10B94952256F87A4E6DAA63F8AF9F (void);
// 0x000008C1 System.Void UnityEngine.Rendering.UI.DebugUIHandlerUIntField::ChangeValue(System.Boolean,System.Int32)
extern void DebugUIHandlerUIntField_ChangeValue_m3CC1A7386C1805CF9113C4016BD888392EA1ED77 (void);
// 0x000008C2 System.Void UnityEngine.Rendering.UI.DebugUIHandlerUIntField::UpdateValueLabel()
extern void DebugUIHandlerUIntField_UpdateValueLabel_mC8087A6A5B7CC2A625EB2B037E7C3223EF9AE72F (void);
// 0x000008C3 System.Void UnityEngine.Rendering.UI.DebugUIHandlerUIntField::.ctor()
extern void DebugUIHandlerUIntField__ctor_mF43B3EE4A84D70A5066F52B5B50845F41BE687FC (void);
// 0x000008C4 System.Void UnityEngine.Rendering.UI.DebugUIHandlerValue::OnEnable()
extern void DebugUIHandlerValue_OnEnable_m7038D3F49F5D49DAC0ED5F377D6A15A6EC68D69B (void);
// 0x000008C5 System.Void UnityEngine.Rendering.UI.DebugUIHandlerValue::SetWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugUIHandlerValue_SetWidget_mA142AE7CCB143CA40E3E63E03CCED6EF916A445A (void);
// 0x000008C6 System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerValue::OnSelection(System.Boolean,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerValue_OnSelection_mEF84CDA2A38FA0FBC19C8E93B42542223145E36B (void);
// 0x000008C7 System.Void UnityEngine.Rendering.UI.DebugUIHandlerValue::OnDeselection()
extern void DebugUIHandlerValue_OnDeselection_m0EA789B780B5D638F66A1DACC0AE45CA94466BC3 (void);
// 0x000008C8 System.Void UnityEngine.Rendering.UI.DebugUIHandlerValue::Update()
extern void DebugUIHandlerValue_Update_mE41E37D577A414A9EB1FF35937B92F4A3F5B3AFC (void);
// 0x000008C9 System.Void UnityEngine.Rendering.UI.DebugUIHandlerValue::.ctor()
extern void DebugUIHandlerValue__ctor_mFAC0D77BD1806745E3234F08069159AA0E89933A (void);
// 0x000008CA System.Void UnityEngine.Rendering.UI.DebugUIHandlerVBox::SetWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugUIHandlerVBox_SetWidget_mC00F497831E97C0E451298B026A0E0015C09810D (void);
// 0x000008CB System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerVBox::OnSelection(System.Boolean,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerVBox_OnSelection_mF51E61D686F63DFE7788D34F438B090C83685606 (void);
// 0x000008CC UnityEngine.Rendering.UI.DebugUIHandlerWidget UnityEngine.Rendering.UI.DebugUIHandlerVBox::Next()
extern void DebugUIHandlerVBox_Next_mF6722FDBA8AD3554A1838B7FF305D0468699C7B9 (void);
// 0x000008CD System.Void UnityEngine.Rendering.UI.DebugUIHandlerVBox::.ctor()
extern void DebugUIHandlerVBox__ctor_m64FA47D67C1E274862860178B57B7D62028779C8 (void);
// 0x000008CE System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector2::SetWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugUIHandlerVector2_SetWidget_mBC7196017B1F462C0A6C4D59156725BDF0F21CFF (void);
// 0x000008CF System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector2::SetValue(System.Single,System.Boolean,System.Boolean)
extern void DebugUIHandlerVector2_SetValue_m62F288A92EB3B3804703359D741236CA57F01468 (void);
// 0x000008D0 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector2::SetupSettings(UnityEngine.Rendering.UI.DebugUIHandlerIndirectFloatField)
extern void DebugUIHandlerVector2_SetupSettings_m030AF4AD168A09C5FE2447B0F7F3D560FDF74086 (void);
// 0x000008D1 System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerVector2::OnSelection(System.Boolean,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerVector2_OnSelection_m7AFD01CE9D04771B069EDA118F28905C3A2BD2BA (void);
// 0x000008D2 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector2::OnDeselection()
extern void DebugUIHandlerVector2_OnDeselection_m73F49E75445B6A2B9FE2569D2BD3242E467191C5 (void);
// 0x000008D3 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector2::OnIncrement(System.Boolean)
extern void DebugUIHandlerVector2_OnIncrement_m03B6B3999DB0B5E6E0AAAC929F7CF703D2C8F361 (void);
// 0x000008D4 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector2::OnDecrement(System.Boolean)
extern void DebugUIHandlerVector2_OnDecrement_m863DAB569083D5930357BC892524B8E3080A392B (void);
// 0x000008D5 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector2::OnAction()
extern void DebugUIHandlerVector2_OnAction_m50C6E7ABC27523886E25FA460DCEA1A3E3817212 (void);
// 0x000008D6 UnityEngine.Rendering.UI.DebugUIHandlerWidget UnityEngine.Rendering.UI.DebugUIHandlerVector2::Next()
extern void DebugUIHandlerVector2_Next_mD9DB032D3A4C0F049B9759E5182EACECD0417EBE (void);
// 0x000008D7 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector2::.ctor()
extern void DebugUIHandlerVector2__ctor_m7FFA0AB89BD22952D133B159892D93DFB0289C95 (void);
// 0x000008D8 System.Single UnityEngine.Rendering.UI.DebugUIHandlerVector2::<SetWidget>b__6_0()
extern void DebugUIHandlerVector2_U3CSetWidgetU3Eb__6_0_m40766D6438349BCCD397A409FD47D6DF7D627E95 (void);
// 0x000008D9 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector2::<SetWidget>b__6_1(System.Single)
extern void DebugUIHandlerVector2_U3CSetWidgetU3Eb__6_1_mDC687994C1C6D34598870969A1C929ED67C3D2AD (void);
// 0x000008DA System.Single UnityEngine.Rendering.UI.DebugUIHandlerVector2::<SetWidget>b__6_2()
extern void DebugUIHandlerVector2_U3CSetWidgetU3Eb__6_2_mF99FF85396E7934B035370C2B77BECD5828073BF (void);
// 0x000008DB System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector2::<SetWidget>b__6_3(System.Single)
extern void DebugUIHandlerVector2_U3CSetWidgetU3Eb__6_3_mEC21ACEA4E8A9B81D5EE772B1E0117834DC3C921 (void);
// 0x000008DC System.Single UnityEngine.Rendering.UI.DebugUIHandlerVector2::<SetupSettings>b__8_0()
extern void DebugUIHandlerVector2_U3CSetupSettingsU3Eb__8_0_mE4033438C35E72EE5CBBF1F35A04BBEE9CB4B207 (void);
// 0x000008DD System.Single UnityEngine.Rendering.UI.DebugUIHandlerVector2::<SetupSettings>b__8_1()
extern void DebugUIHandlerVector2_U3CSetupSettingsU3Eb__8_1_m5098326D73A3D982ED62D3DA8F591F1CC68DEABD (void);
// 0x000008DE System.Single UnityEngine.Rendering.UI.DebugUIHandlerVector2::<SetupSettings>b__8_2()
extern void DebugUIHandlerVector2_U3CSetupSettingsU3Eb__8_2_m6024441393B4D412E29E62645E4E3AE6E41AC107 (void);
// 0x000008DF System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector3::SetWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugUIHandlerVector3_SetWidget_m51C9378CD3689FA2AE11828984E4EE630A23C092 (void);
// 0x000008E0 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector3::SetValue(System.Single,System.Boolean,System.Boolean,System.Boolean)
extern void DebugUIHandlerVector3_SetValue_m4D9723FBDE1075AD99708C9BDDA5F7EF1749EE02 (void);
// 0x000008E1 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector3::SetupSettings(UnityEngine.Rendering.UI.DebugUIHandlerIndirectFloatField)
extern void DebugUIHandlerVector3_SetupSettings_m681D4F4C06C60CF01EA0305923C351134A583494 (void);
// 0x000008E2 System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerVector3::OnSelection(System.Boolean,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerVector3_OnSelection_mC678FC573B0C47D7CA67D22621B503036BF51398 (void);
// 0x000008E3 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector3::OnDeselection()
extern void DebugUIHandlerVector3_OnDeselection_m441D4222C4429198D8A935B78E0D83C544511023 (void);
// 0x000008E4 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector3::OnIncrement(System.Boolean)
extern void DebugUIHandlerVector3_OnIncrement_mC053EC7624798FB68ED978E92BF251117E30E0D1 (void);
// 0x000008E5 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector3::OnDecrement(System.Boolean)
extern void DebugUIHandlerVector3_OnDecrement_mD51DBE51C01228D2C0F1ADB74C93F0E35ECC71F3 (void);
// 0x000008E6 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector3::OnAction()
extern void DebugUIHandlerVector3_OnAction_m59987EEEA08CA2D312FCFFD4B6945A6F3F1CF351 (void);
// 0x000008E7 UnityEngine.Rendering.UI.DebugUIHandlerWidget UnityEngine.Rendering.UI.DebugUIHandlerVector3::Next()
extern void DebugUIHandlerVector3_Next_mC9CB584A704F41B945432F643549DC068B8C5048 (void);
// 0x000008E8 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector3::.ctor()
extern void DebugUIHandlerVector3__ctor_mE28CE6E9E387BB4C4AD0DA6CBF3DBEA1AA3C34B6 (void);
// 0x000008E9 System.Single UnityEngine.Rendering.UI.DebugUIHandlerVector3::<SetWidget>b__7_0()
extern void DebugUIHandlerVector3_U3CSetWidgetU3Eb__7_0_mAB6B7CD5EB1A3BDAD9022F1E34F6B3E5FD6AB198 (void);
// 0x000008EA System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector3::<SetWidget>b__7_1(System.Single)
extern void DebugUIHandlerVector3_U3CSetWidgetU3Eb__7_1_m6C8891791339BFC4674E7F6ACA93407BB01742E5 (void);
// 0x000008EB System.Single UnityEngine.Rendering.UI.DebugUIHandlerVector3::<SetWidget>b__7_2()
extern void DebugUIHandlerVector3_U3CSetWidgetU3Eb__7_2_mE180B24E364395A808BDAEF108C3B5CCC7B34A8F (void);
// 0x000008EC System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector3::<SetWidget>b__7_3(System.Single)
extern void DebugUIHandlerVector3_U3CSetWidgetU3Eb__7_3_mE87B8C4818974E2A09F967C07693A5EE4E279543 (void);
// 0x000008ED System.Single UnityEngine.Rendering.UI.DebugUIHandlerVector3::<SetWidget>b__7_4()
extern void DebugUIHandlerVector3_U3CSetWidgetU3Eb__7_4_m0A890E89CA123AF98F3675599F42983DFFF6BED3 (void);
// 0x000008EE System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector3::<SetWidget>b__7_5(System.Single)
extern void DebugUIHandlerVector3_U3CSetWidgetU3Eb__7_5_m6F02ECC974164F8BD416D09591C0A7FC562D9E00 (void);
// 0x000008EF System.Single UnityEngine.Rendering.UI.DebugUIHandlerVector3::<SetupSettings>b__9_0()
extern void DebugUIHandlerVector3_U3CSetupSettingsU3Eb__9_0_m8A2F0E9E84CEDEF51C39FC2064AE4A567D536B5E (void);
// 0x000008F0 System.Single UnityEngine.Rendering.UI.DebugUIHandlerVector3::<SetupSettings>b__9_1()
extern void DebugUIHandlerVector3_U3CSetupSettingsU3Eb__9_1_m8817E674DE9AA44BDA955FCBAE74FCE86AE00D69 (void);
// 0x000008F1 System.Single UnityEngine.Rendering.UI.DebugUIHandlerVector3::<SetupSettings>b__9_2()
extern void DebugUIHandlerVector3_U3CSetupSettingsU3Eb__9_2_mEF5F59D1C0046A69401A520E2EA72E08E51683A7 (void);
// 0x000008F2 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector4::SetWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugUIHandlerVector4_SetWidget_m0ACF9FA8301635E697FAD1F98F39B3430ADF2F30 (void);
// 0x000008F3 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector4::SetValue(System.Single,System.Boolean,System.Boolean,System.Boolean,System.Boolean)
extern void DebugUIHandlerVector4_SetValue_mDDE5A79FCB5E7FC86F7F59BFF4ED7D08B419A1ED (void);
// 0x000008F4 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector4::SetupSettings(UnityEngine.Rendering.UI.DebugUIHandlerIndirectFloatField)
extern void DebugUIHandlerVector4_SetupSettings_m6E1D7C8A778144AEC0FED0B4B5F65834B03CFABF (void);
// 0x000008F5 System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerVector4::OnSelection(System.Boolean,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerVector4_OnSelection_m13FAB6F972E9526565914FC704E535C45A1D58C1 (void);
// 0x000008F6 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector4::OnDeselection()
extern void DebugUIHandlerVector4_OnDeselection_m848522A1837716ACEDBA77E7C40F965E7A69717C (void);
// 0x000008F7 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector4::OnIncrement(System.Boolean)
extern void DebugUIHandlerVector4_OnIncrement_m7C040482A50C8BA301CF8AECE0B380DC01AA36A4 (void);
// 0x000008F8 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector4::OnDecrement(System.Boolean)
extern void DebugUIHandlerVector4_OnDecrement_mD7C8F3016A697A94C281400CC3B98A06F6E2FF69 (void);
// 0x000008F9 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector4::OnAction()
extern void DebugUIHandlerVector4_OnAction_m0189C1E29F75BC018C2D5BF6732F1EB3ABB35BD3 (void);
// 0x000008FA UnityEngine.Rendering.UI.DebugUIHandlerWidget UnityEngine.Rendering.UI.DebugUIHandlerVector4::Next()
extern void DebugUIHandlerVector4_Next_m27898CC501B5F74A1FFF47D030B187FEB2956DFF (void);
// 0x000008FB System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector4::.ctor()
extern void DebugUIHandlerVector4__ctor_m45C4574D831F218759A99BF64E570281E91BCABC (void);
// 0x000008FC System.Single UnityEngine.Rendering.UI.DebugUIHandlerVector4::<SetWidget>b__8_0()
extern void DebugUIHandlerVector4_U3CSetWidgetU3Eb__8_0_m08BEFA85D371D04F0B038DF845898F2B2E1361CC (void);
// 0x000008FD System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector4::<SetWidget>b__8_1(System.Single)
extern void DebugUIHandlerVector4_U3CSetWidgetU3Eb__8_1_mB0D840131A3B9F0174D378AAB9C31B2D46EFCBA8 (void);
// 0x000008FE System.Single UnityEngine.Rendering.UI.DebugUIHandlerVector4::<SetWidget>b__8_2()
extern void DebugUIHandlerVector4_U3CSetWidgetU3Eb__8_2_m259CA925AB02780A7FC19E6E00ECD27A8D9492EB (void);
// 0x000008FF System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector4::<SetWidget>b__8_3(System.Single)
extern void DebugUIHandlerVector4_U3CSetWidgetU3Eb__8_3_m43586D00F180DB14B0A50C3470181CE50013D28C (void);
// 0x00000900 System.Single UnityEngine.Rendering.UI.DebugUIHandlerVector4::<SetWidget>b__8_4()
extern void DebugUIHandlerVector4_U3CSetWidgetU3Eb__8_4_mEE993AC3EDBF96F1A45843A1AAC8CD4600128D19 (void);
// 0x00000901 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector4::<SetWidget>b__8_5(System.Single)
extern void DebugUIHandlerVector4_U3CSetWidgetU3Eb__8_5_m2380D05D15DD6A2D525A4465ADFF4D1C8F0C21E7 (void);
// 0x00000902 System.Single UnityEngine.Rendering.UI.DebugUIHandlerVector4::<SetWidget>b__8_6()
extern void DebugUIHandlerVector4_U3CSetWidgetU3Eb__8_6_mB5AE87731664D5FF4407F389918BCAE29C29E66F (void);
// 0x00000903 System.Void UnityEngine.Rendering.UI.DebugUIHandlerVector4::<SetWidget>b__8_7(System.Single)
extern void DebugUIHandlerVector4_U3CSetWidgetU3Eb__8_7_mFC96D46A98F25512F5BE486E12F504F4ACC1D592 (void);
// 0x00000904 System.Single UnityEngine.Rendering.UI.DebugUIHandlerVector4::<SetupSettings>b__10_0()
extern void DebugUIHandlerVector4_U3CSetupSettingsU3Eb__10_0_m2294F14B1936842ABAD989616BD8FFFB9D19960C (void);
// 0x00000905 System.Single UnityEngine.Rendering.UI.DebugUIHandlerVector4::<SetupSettings>b__10_1()
extern void DebugUIHandlerVector4_U3CSetupSettingsU3Eb__10_1_m87F6A7549919BF2D29BED6A03DCFB2F5A5CE30D3 (void);
// 0x00000906 System.Single UnityEngine.Rendering.UI.DebugUIHandlerVector4::<SetupSettings>b__10_2()
extern void DebugUIHandlerVector4_U3CSetupSettingsU3Eb__10_2_m33E9FAAEBEE26FA4A43E670F562C48F3169CFEFF (void);
// 0x00000907 UnityEngine.Rendering.UI.DebugUIHandlerWidget UnityEngine.Rendering.UI.DebugUIHandlerWidget::get_parentUIHandler()
extern void DebugUIHandlerWidget_get_parentUIHandler_m2F40C42629AB71EDAEE402C22FE160B76D78D8AE (void);
// 0x00000908 System.Void UnityEngine.Rendering.UI.DebugUIHandlerWidget::set_parentUIHandler(UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerWidget_set_parentUIHandler_mF23913A3178CA556A5709A8E5782585240A4E784 (void);
// 0x00000909 UnityEngine.Rendering.UI.DebugUIHandlerWidget UnityEngine.Rendering.UI.DebugUIHandlerWidget::get_previousUIHandler()
extern void DebugUIHandlerWidget_get_previousUIHandler_m618D35DF8E71F7E7EEAD6ED05F77EA51A5214C34 (void);
// 0x0000090A System.Void UnityEngine.Rendering.UI.DebugUIHandlerWidget::set_previousUIHandler(UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerWidget_set_previousUIHandler_m7F60E1430A65740C8EFCCD87F1724CB08BE2F422 (void);
// 0x0000090B UnityEngine.Rendering.UI.DebugUIHandlerWidget UnityEngine.Rendering.UI.DebugUIHandlerWidget::get_nextUIHandler()
extern void DebugUIHandlerWidget_get_nextUIHandler_m2DFDEE3BE43A204B29BC39087AF60AA86D09BE90 (void);
// 0x0000090C System.Void UnityEngine.Rendering.UI.DebugUIHandlerWidget::set_nextUIHandler(UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerWidget_set_nextUIHandler_m84F82CC75B6BCF91986150F4DE1D96D963E78CC8 (void);
// 0x0000090D System.Void UnityEngine.Rendering.UI.DebugUIHandlerWidget::OnEnable()
extern void DebugUIHandlerWidget_OnEnable_m97D5414C310F4E3DB00053EEE5DADBFED53C960C (void);
// 0x0000090E System.Void UnityEngine.Rendering.UI.DebugUIHandlerWidget::SetWidget(UnityEngine.Rendering.DebugUI/Widget)
extern void DebugUIHandlerWidget_SetWidget_mEE5CAA4C4DCDD02ACBF70B35B23F81CF8DE60F5A (void);
// 0x0000090F UnityEngine.Rendering.DebugUI/Widget UnityEngine.Rendering.UI.DebugUIHandlerWidget::GetWidget()
extern void DebugUIHandlerWidget_GetWidget_m2B98AD3E32CE71B3F39C93BD7E7C0BEA5897033C (void);
// 0x00000910 T UnityEngine.Rendering.UI.DebugUIHandlerWidget::CastWidget()
// 0x00000911 System.Boolean UnityEngine.Rendering.UI.DebugUIHandlerWidget::OnSelection(System.Boolean,UnityEngine.Rendering.UI.DebugUIHandlerWidget)
extern void DebugUIHandlerWidget_OnSelection_m378D3DE45EB78D9C684239E3D9B53DF27D257F27 (void);
// 0x00000912 System.Void UnityEngine.Rendering.UI.DebugUIHandlerWidget::OnDeselection()
extern void DebugUIHandlerWidget_OnDeselection_mBF3AF27B21F180E69D3A57D44CB26F7CB20ECCD9 (void);
// 0x00000913 System.Void UnityEngine.Rendering.UI.DebugUIHandlerWidget::OnAction()
extern void DebugUIHandlerWidget_OnAction_m5561D81BF72FC055972C2D14BC92E221EA9294EC (void);
// 0x00000914 System.Void UnityEngine.Rendering.UI.DebugUIHandlerWidget::OnIncrement(System.Boolean)
extern void DebugUIHandlerWidget_OnIncrement_m4128084E64169D31815E5C0BF79DB25A08A75F22 (void);
// 0x00000915 System.Void UnityEngine.Rendering.UI.DebugUIHandlerWidget::OnDecrement(System.Boolean)
extern void DebugUIHandlerWidget_OnDecrement_mEFF4903ADBBEE2E4C99AE09FFD83718DBBA12894 (void);
// 0x00000916 UnityEngine.Rendering.UI.DebugUIHandlerWidget UnityEngine.Rendering.UI.DebugUIHandlerWidget::Previous()
extern void DebugUIHandlerWidget_Previous_mE43110A6F1E2AABBCE916D5CDE8523E7C543E4E3 (void);
// 0x00000917 UnityEngine.Rendering.UI.DebugUIHandlerWidget UnityEngine.Rendering.UI.DebugUIHandlerWidget::Next()
extern void DebugUIHandlerWidget_Next_mCCCE23E0DBA851BCF1D6169678B52037FE5D9DC3 (void);
// 0x00000918 System.Void UnityEngine.Rendering.UI.DebugUIHandlerWidget::.ctor()
extern void DebugUIHandlerWidget__ctor_m2105E00AE3370003AE9303EDDA5ABB544CE420E5 (void);
// 0x00000919 System.Void UnityEngine.Rendering.UI.UIFoldout::Start()
extern void UIFoldout_Start_m031F3AF5DA5840E25AB29B054311BABBC425FA7D (void);
// 0x0000091A System.Void UnityEngine.Rendering.UI.UIFoldout::OnValidate()
extern void UIFoldout_OnValidate_mE61A4777FD785B1EC726B57B32C96C2E88767E4C (void);
// 0x0000091B System.Void UnityEngine.Rendering.UI.UIFoldout::SetState(System.Boolean)
extern void UIFoldout_SetState_m041BAB7EB961B7D84E99C388E6405D4B62FEFC32 (void);
// 0x0000091C System.Void UnityEngine.Rendering.UI.UIFoldout::SetState(System.Boolean,System.Boolean)
extern void UIFoldout_SetState_m169A04E74F6DFC0F376CD2D233CA5111E6F165B8 (void);
// 0x0000091D System.Void UnityEngine.Rendering.UI.UIFoldout::.ctor()
extern void UIFoldout__ctor_mD1494EF8AB928679E6683D9C1C58B6953EB2D1E8 (void);
static Il2CppMethodPointer s_methodPointers[2333] = 
{
	EmbeddedAttribute__ctor_mFDDD3801DF1C9072A93E9D0E0245AD6614296A93,
	IsUnmanagedAttribute__ctor_mC5A39467E97231F69EDDB82CEFF55799769D4831,
	SceneRenderPipeline_OnEnable_m8DFB5817C811BD572F50828E2BC1846C33C563E0,
	SceneRenderPipeline_OnValidate_m3431ACFDD2D051C2154E438CF8F238039EED461F,
	SceneRenderPipeline__ctor_mA2BACFC1F9E1D784A1D22C33989F37AB2992B705,
	LightAnchor_get_yaw_m52ED0E5D97F44A13F5CDCE97B075943DF19C2C75,
	LightAnchor_set_yaw_m9057876C5E232D78615173514C79C8CC793456FB,
	LightAnchor_get_pitch_mEFF8824F48601C924A9FFFE53A037ABC94F0A457,
	LightAnchor_set_pitch_mA6089A7741A4DF514CC7D1898CDC3B8395470AEF,
	LightAnchor_get_roll_m9E394A7FD38D78F77D9AF6D487ACE354AA0208BE,
	LightAnchor_set_roll_m32BB11BB51EFACF5FA9ECD6EFA6D85326570261A,
	LightAnchor_get_distance_m77FE40AC57D00C6BA1182ED786A03F65E31127D3,
	LightAnchor_set_distance_m42E748EB369DBF850588C22C6918FE3FED37FA7A,
	LightAnchor_get_frameSpace_m44EDEFB1FE2D9935DF530548D473257FE92B59AE,
	LightAnchor_set_frameSpace_m54BC03751526C7A6DC82478572424CF514CA539F,
	LightAnchor_get_anchorPosition_mEA9BCD0D6DC5F9D09946B603B002AAABED4931FB,
	LightAnchor_get_anchorPositionOverride_m882CAD2DDBE5562E4A398A7A4F9AB5F9AFAC25F8,
	LightAnchor_set_anchorPositionOverride_mC73D18D10951021DD39425772B455DD8E4433744,
	LightAnchor_get_anchorPositionOffset_m910D76FFBFFA8F1AC3863655ADA17A979EDA6841,
	LightAnchor_set_anchorPositionOffset_m1487F1C37C65F2935E8159883EFEF1FBBF52E292,
	LightAnchor_NormalizeAngleDegree_m5E4EDD421FBEF855BBC993F4771F6D8BBB5C23F8,
	LightAnchor_SynchronizeOnTransform_m34289C96616C858B40E5FC8881CE9B41F344C3A5,
	LightAnchor_UpdateTransform_mDE72D1F5D3DB08833FD7447BC8936D0DB3E51889,
	LightAnchor_GetWorldSpaceAxes_m5F7DC28223C9BF5A32D3EEB8343F0FBBAEBADC4D,
	LightAnchor_Update_m5A4E89DCC8E263D6574969883FCE75622779B966,
	LightAnchor_OnDrawGizmosSelected_m8F7EDABE68EF7A8BC2959CB2A209A0F8C02C9CE7,
	LightAnchor_UpdateTransform_mF959E83F9B4FA3352C03C2493697A8B869E63CF3,
	LightAnchor__ctor_mB0DD0C850B18562E6EE38F12E415F3917E3BBEAA,
	ProbeBrickIndex_get_estimatedVMemCost_mFE477FD4F261500F38775DFE0B7DAB5A277A0BF1,
	ProbeBrickIndex_set_estimatedVMemCost_mC11B8A5219EA4A78BD8A5D71CC8673F7479DEDF1,
	ProbeBrickIndex_GetVoxelSubdivLevel_m3DC209B48D96D26959FAEEF4D16B88281981BDF7,
	ProbeBrickIndex_SizeOfPhysicalIndexFromBudget_m7DD0531B067B5A9648EEA759AC150947B3870674,
	ProbeBrickIndex__ctor_m05E67CF09FD73EB9674D8B0B028DF5DCA499B5D3,
	ProbeBrickIndex_UploadIndexData_m0C39F1400DAF3A9411424EF4B19821A2922E7AC9,
	ProbeBrickIndex_Clear_mF2C59212EC570181C8BE1B101F3EE2D489A37D27,
	ProbeBrickIndex_MapBrickToVoxels_mE65C9F64C0CA2072358C43696988CF1C09AB96BE,
	ProbeBrickIndex_ClearVoxel_m7E65631F45A9E7081D6F04F2042EC7067FEE0B12,
	ProbeBrickIndex_GetRuntimeResources_m4C9914510D15AEBFF7710344B0149875D121AC63,
	ProbeBrickIndex_Cleanup_mB651AFFD1CB092785FE27879A0A4A3DE234E0D58,
	ProbeBrickIndex_MergeIndex_m85D414F58BE14560CE051F7C79AC843F45F00B94,
	ProbeBrickIndex_AssignIndexChunksToCell_m8552299678638EAC75180BB5F988C3B0F5AB3AF9,
	ProbeBrickIndex_AddBricks_m7D03B36F02CDA5D5136C77A4EC0F1CD6ED7EBBB7,
	ProbeBrickIndex_RemoveBricks_mDB11AA33F8351FD7C3D0EFD946CA85E07636A170,
	ProbeBrickIndex_UpdateIndexForVoxel_m0E276C69C80F441BA39B5EC8FAEC2A8E6D0B419D,
	ProbeBrickIndex_UpdatePhysicalIndex_mF7C71DF7BC9173BFEBB5040740D76B66272E1232,
	ProbeBrickIndex_ClipToIndexSpace_m67EAB9AAB95C4E9ED856432B480BA5181842C029,
	ProbeBrickIndex_UpdateIndexForVoxel_m53C95CF74CFB0C44713B9578FF8D717ACCC1E2D2,
	Brick__ctor_mF1384DE2A301E1649AA0B75AF1726649F330500B,
	Brick_Equals_m51973370DE321FB79FE83BA500E6100A3676A62C,
	U3CU3Ec__DisplayClass31_0__ctor_m0D41A2E28E6C6807487A8C9F04742BD6C0FCC46D,
	U3CU3Ec__DisplayClass31_0_U3CAddBricksU3Eb__0_m4F62CA8F719AB83BB63600FF826BFC6D870DC03A,
	U3CU3Ec__DisplayClass32_0__ctor_mF894CFB004316B0FFCCB871803FFAEBD8DB3A380,
	U3CU3Ec__DisplayClass32_0_U3CRemoveBricksU3Eb__0_mD7DC90ECA9CC7934699D1846AAB1FFBF5A7A4634,
	ProbeBrickPool_get_estimatedVMemCost_m034678F278DC295B79596DB95A91C56DD2A93F16,
	ProbeBrickPool_set_estimatedVMemCost_m6E4F705AFAB407937129B0DF5DF6ED9A3BB7E242,
	ProbeBrickPool__ctor_m0BD314B82E2BB586AEE10C0E6829076837A63E91,
	ProbeBrickPool_EnsureTextureValidity_m2D85061C632966FCF8FF4A205F01AE394E16D905,
	ProbeBrickPool_GetChunkSize_m90C51A268641D7068187025F7BCFCCCE5048E79B,
	ProbeBrickPool_GetChunkSizeInProbeCount_m89EE5CA53CC2200A0895C88692B475C2269EA6E6,
	ProbeBrickPool_GetPoolWidth_mC106DF0FAAA0AEC8CD200467EDB68F84CF9BCD15,
	ProbeBrickPool_GetPoolHeight_mC6582BAE0F1295E712B6DCDE03FA9252D8A0DCF5,
	ProbeBrickPool_GetPoolDimensions_m5FD1928EF8018F8795556D04EEA5945126962FF7,
	ProbeBrickPool_GetRuntimeResources_mE1285A7706A4EB2FC4E1C42212207FF172E74C15,
	ProbeBrickPool_Clear_m4AFA82638D01D1BFDDEAA2ADB2E7044F4A5BA0BD,
	ProbeBrickPool_Allocate_m6B017BDC77944EF981C7BA24117549595D54D9C6,
	ProbeBrickPool_Deallocate_mD129B65B3D591BBC9E7A6092B877429807A23CC9,
	ProbeBrickPool_Update_mD19C587DA7D045D80AA6B4ADFB482D1318912ED9,
	ProbeBrickPool_ProbeCountToDataLocSize_mFB4FFBD7A584D6A533A39F1CC1B4DD0CDEDA80F1,
	ProbeBrickPool_CreateDataLocation_m69E2A8A785E5FFE755A213542EE2CDBC8040237D,
	ProbeBrickPool_SetPixel_mBB676A7FFB5A8A92C24D4AC350FC72D678108C7F,
	ProbeBrickPool_FillDataLocation_m749F98CDC969320C029782CA95FA381A8267C095,
	ProbeBrickPool_DerivePoolSizeFromBudget_m252784923D233C370B31CAF376822B0A8B4F0DEE,
	ProbeBrickPool_Cleanup_m7DDF8B0DA3D29B59D8D3F9E53211B205B5CBCFAA,
	BrickChunkAlloc_flattenIndex_mDDF83B6500BFACBB3DF4327BD285E912749664DD,
	DataLocation_Cleanup_mD3D6DFF36870590F6A6DEBAB39E65BF71BB17FBF,
	ProbeCellIndices_get_estimatedVMemCost_m5F027C6A9242F582122F2DFD593D9728D99C970B,
	ProbeCellIndices_set_estimatedVMemCost_m48C6C4530C2AB4BEB48C85C0AC18CBABBF79D945,
	ProbeCellIndices_GetCellIndexDimension_m9E93661F7B58589CA0557D3B07A8FB635232B3D5,
	ProbeCellIndices_GetCellMinPosition_m2F7C085192B5E67252677C7B3C0D79DF7FADBC54,
	ProbeCellIndices_GetFlatIndex_m6847AC7311DF2F831B2A92995F8C6FC68F13BBAE,
	ProbeCellIndices__ctor_mB2B093549B9F43B1A624F277B91EA10651A14F30,
	ProbeCellIndices_GetFlatIdxForCell_m0E8103CD210C64D23927C96BD86BB349EFEFCD67,
	ProbeCellIndices_AddCell_mB5C00D8EF3DAA8EA55A78E58B255F9F2E0ADD8BD,
	ProbeCellIndices_MarkCellAsUnloaded_mF2C9BE87210AB183AE9F4649A1562F19EB3EE4E5,
	ProbeCellIndices_PushComputeData_m647D18E694F7DBFC7FA1386157C862C422B4D36F,
	ProbeCellIndices_GetRuntimeResources_mC562C8F0D3EB039D60A752D91E8106F2011BA428,
	ProbeCellIndices_Cleanup_mE9FAE4FD94D9AFF389980F80D6254A657E9987E5,
	IndexMetaData_Pack_mD890E178B9204BB2B438B3AF6D328086BDAF7056,
	ProbeReferenceVolume_InvalidateAllCellRefs_mC9899CBE0BD02C52065E4ACB1D4B871D0870B467,
	ProbeReferenceVolume_get_isInitialized_mF23A464CC55545B81DCF87CD846DDBB1D083F656,
	ProbeReferenceVolume_get_enabledBySRP_m4EDBD40DD9C008D5BE71C8B63E4734AB80CADFCC,
	ProbeReferenceVolume_get_shBands_m4226E70293AB7D461B40DCBA788C3936574604E7,
	ProbeReferenceVolume_get_memoryBudget_mE288C614ADB6D076B824FA6F794DF6E43A08FA20,
	ProbeReferenceVolume_get_instance_m2C37B082CAD0E7ED8A9A063B553DB456B89D8FFC,
	ProbeReferenceVolume_SetNumberOfCellsLoadedPerFrame_m05295E2EC6686E43BC6E3A25C7A222A9817B5E46,
	ProbeReferenceVolume_Initialize_mFC60AE4AB09643D221CE0E6EA3EB68FEB0A4D458,
	ProbeReferenceVolume_SetEnableStateFromSRP_m6ABC5B2B94635F9E1EE218F9191564B527D421AD,
	ProbeReferenceVolume_ForceSHBand_m6242CF41956912A6D6E08C244CE21EFF90963FF2,
	ProbeReferenceVolume_Cleanup_m371AE89841E21926498188BC77064602AADE4B0A,
	ProbeReferenceVolume_GetVideoMemoryCost_m1D5387B5E18210B12414D2D2872DF894BC35F0AF,
	ProbeReferenceVolume_RemoveCell_m5A0D41776583972976AAB53206FE1CA079156396,
	ProbeReferenceVolume_AddCell_mE2159918E79C6C8134BAACED69C3E0ECEB8DCCCD,
	ProbeReferenceVolume_CheckCompatibilityWithCollection_m08A5838880203FA8D70E253A887B28E85FB6A517,
	ProbeReferenceVolume_AddPendingAssetLoading_m7EF404D492670EE60C0CF10A66C5F9015A38F1B7,
	ProbeReferenceVolume_AddPendingAssetRemoval_mBD95A44765631D66376763508952902BDD03A8DD,
	ProbeReferenceVolume_RemovePendingAsset_m6570DA934E9ACE3DA84E10783816ED6157B98762,
	ProbeReferenceVolume_PerformPendingIndexChangeAndInit_m31E431668BAEA4F76051C3F4F08BCBF7893F3341,
	ProbeReferenceVolume_SetMinBrickAndMaxSubdiv_m88473F4B1337645D2F5B6F9AA6B60D20CB1AC078,
	ProbeReferenceVolume_LoadAsset_m6762ED235290551AF23A3A741A5AB44DCC635DC7,
	ProbeReferenceVolume_PerformPendingLoading_m3A0D300661A997E2026BDFB631C1C02037A5F621,
	ProbeReferenceVolume_PerformPendingDeletion_m394606ACC70C20888F50E08C3EB940DB8B87F6EA,
	ProbeReferenceVolume_GetNumberOfBricksAtSubdiv_mC7241405B7787ADEE9A494F37CB79670527727B6,
	ProbeReferenceVolume_GetCellIndexUpdate_m5F32FFA6A185E250CA69C49B1CE881A2C21C7282,
	ProbeReferenceVolume_LoadPendingCells_m5A516A3ECD5B8A3E98F091BECD0997122EE77D4B,
	ProbeReferenceVolume_PerformPendingOperations_mC5519B44064DD7C71E6A60EF117E11BC632CF98C,
	ProbeReferenceVolume_InitProbeReferenceVolume_m8396C4E41214B049F2382F6C56A71C7AA4787A3E,
	ProbeReferenceVolume_SortPendingCells_m2F51DC96E68B5D82D019FE55C35270F097EF295B,
	ProbeReferenceVolume__ctor_m6A7FC7CD15FFB29AEEEDE07D8BC12D20F54934CA,
	ProbeReferenceVolume_GetRuntimeResources_mFAFA8BFAA13C5F2A44156150FB9706AC7D0783BB,
	ProbeReferenceVolume_SetTRS_m942EB8F2721EA1D608CD24A5BF0367362703CAB6,
	ProbeReferenceVolume_SetMaxSubdivision_m18D69D8668C3E597E98DDC49F890E4B212F601FA,
	ProbeReferenceVolume_CellSize_mD207959EFA5248246AA6B601F0D763AB9A0A222A,
	ProbeReferenceVolume_BrickSize_mDCA73ED08C95C324438DD58CDB612BDF11F58FCB,
	ProbeReferenceVolume_MinBrickSize_m7F68ECE8192C147F1FD88A7084613CE914BA88D3,
	ProbeReferenceVolume_MaxBrickSize_m46CBCA6A0DB5E9DF939931596A0AF80E66FDC586,
	ProbeReferenceVolume_GetRefSpaceToWS_m705979650EE8BE432367669D8BF29474F8E345BF,
	ProbeReferenceVolume_GetTransform_m46DB6F40F6AEEDBEF5603019105B63912FB41D60,
	ProbeReferenceVolume_GetMaxSubdivision_m023EA6A3411AE69AEC9E9DBF9A3FF9A64D6A655E,
	ProbeReferenceVolume_GetMaxSubdivision_m4226527EFCC91A55AE575D7261C653F62A90F572,
	ProbeReferenceVolume_GetDistanceBetweenProbes_m4DA724F7EC834805EBF6811DD4BCCB3D9FE09B77,
	ProbeReferenceVolume_MinDistanceBetweenProbes_m8D4E69D8DBDBAE871A41001A5034F3F73DF8FE3D,
	ProbeReferenceVolume_DataHasBeenLoaded_m1CA78B6A3D0473BAA991E43AC7C75F2865365119,
	ProbeReferenceVolume_Clear_mEFC86AD464BA6A183AD6FFBE151885143C0ECC2E,
	ProbeReferenceVolume_AddBricks_m04EEF96F0D5C2861661C99F2E75C5E7580C1D446,
	ProbeReferenceVolume_ReleaseBricks_m7BB16DFF13B76370E1EADDC7AAC79EF41848704D,
	ProbeReferenceVolume_UpdateConstantBuffer_m1EC669416A811F48A8E8A35F9D49AEF93397CD8E,
	ProbeReferenceVolume_CleanupLoadedData_m468450BDD6457065635A939ED04CF2748D861406,
	ProbeReferenceVolume_get_debugDisplay_m3B5AC8256B172A7F328C8BB71052B58A1E31F33D,
	ProbeReferenceVolume_get_subdivisionDebugColors_m14CCC5D30B08F40A298620B0A52D73B5DF17838C,
	ProbeReferenceVolume_RenderDebug_mB5940E1289F5AC9BF893E2ECD0000B824B87F480,
	ProbeReferenceVolume_InitializeDebug_m5576BAAC9A89F89AD454682006A303A6E9E9E16A,
	ProbeReferenceVolume_CleanupDebug_m87FDB580BDBC8351FECEB41FC0AEC172245C0780,
	NULL,
	NULL,
	ProbeReferenceVolume_RegisterDebug_mD0A161B88AD53352C8963DC9BD27342C7E860A65,
	ProbeReferenceVolume_UnregisterDebug_m3F056A2F836F6655E1E1445C916C9E0E3361F79E,
	ProbeReferenceVolume_ShouldCullCell_m9715280AEB3617FBD09C00FB2D4F7171D7538F4F,
	ProbeReferenceVolume_DrawProbeDebug_mA8A39F3E467AACFB8D9464875641560CF61C045B,
	ProbeReferenceVolume_ClearDebugData_m254D017F2183A194216423BB841397BDDF1C4DC8,
	ProbeReferenceVolume_CreateInstancedProbes_m806975916734F25072124FAD76BCBA10168947AD,
	ProbeReferenceVolume_OnClearLightingdata_m30C6E85A9543A4B86541BF45AE9574BE8893F252,
	ProbeReferenceVolume__cctor_m581E007F00827823E1613E4B0CEE7EE324E1DFEC,
	ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_0_m1FEF43C8C9257393BB00F23599D338C52C1209F1,
	ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_1_m838B64743C17C84AD7D800DEB38520F5C5613618,
	ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_2_m08AD6589C129153D509EF8BD795B857CD2012D25,
	ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_3_mFAE8C73291A450AAB6EC112A429FA260163B398D,
	ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_4_m69477F076DA430E890DCDEC5FD4332539C3AA181,
	ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_5_m20351FBA28D54261AFE1CFA4B1ADF6462D85B2F5,
	ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_7_m78E56FD68CE1EAD67F6A352BDED5D5017AB3882C,
	ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_8_m622E41A1FBAD4841237A25A02F20FB905CAC4109,
	ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_9_m3BC9939FA36AE2ED9E3F6CDA1C5AE689B5D8AA08,
	ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_10_m79BF09226B0DA9942A5161198E24AA2A4E7BB82D,
	ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_11_m9BADEECA3912AA581326B967997E4A0179DA483F,
	ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_12_mAD8CA099159B1D4F1BC3678F3D670ED8BBE0E36D,
	ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_13_mEDA1CFED7D779CBA54CF4A70BCC4804D1075B4A8,
	ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_14_m4C0370437FDB51EAD81A9253FD5951FC02D4F6C4,
	ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_17_mE8905DB432C1780EF995219604D3D86C59E279D5,
	ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_18_m5E715FD0DA77C56C3B77D5274B771943EE345079,
	ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_19_mBB862AA761431F2CD7B2DD6DDAF1445E24379BBA,
	ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_20_m582275190D2F770D8C40085ED3BC1F4A99B55A5D,
	ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_22_mEA9E3063D4EA99AC22841A5D83694F97F0C9650A,
	ProbeReferenceVolume_U3CRegisterDebugU3Eb__119_23_m8EF41C0C654286DE20CA52E6631DE19B5B824F6B,
	Cell__ctor_m824A6EBAD74E1A1616A81B2598406D1A6663B7EF,
	CellChunkInfo__ctor_m7E1C749DBADA4CB21473B1A39E986AEEDDAB678E,
	CellSortInfo_CompareTo_m863AFCCBD5F7AFBF8701D1949F0BC4CAC81191A8,
	CellSortInfo__ctor_m5871F49B1A019D1B007A5132580B6599434971BE,
	Volume__ctor_m157BAF82255C35F2C38F19544B2E95570161E332,
	Volume__ctor_m4FDB6EEEA74A5B99555110CAA3B12282432CC15D,
	Volume__ctor_m0746CD2A7E66B698B86D7486756406F7F3FAB857,
	Volume_CalculateAABB_mBDDD2C2420FDF8879AA3E83BAEBB3D2888AACFB4,
	Volume_CalculateCenterAndSize_m1DADCCCFB55DCDFD8BEC9FBBA0C566D7E4DA0E4A,
	Volume_Transform_m12D69F2254CDE720482AAC13285DF1204D3147A9,
	Volume_ToString_m98DA1A8AE24508B153D48275417D33006A179D54,
	Volume_Equals_m0779B6B9E04131377F97A134517B72F4FFA82D3E,
	RegId_IsValid_m36BF6BB4B5534FCE342CC11E1EE32774E60C59B4,
	RegId_Invalidate_m1933F3829E449BAB0908DCE60AA6C1612FB0D8BA,
	RegId_op_Equality_m221776DC5C85B27789D99AF0DC8F1B605834FA87,
	RegId_op_Inequality_m5A3B7093270A74036495D32ABBD5BB83F5BE6762,
	RegId_Equals_m42741BC96AB73BD66C8E071FC56669D05BE78681,
	RegId_GetHashCode_m85D1E25F3792C7049063C2A7C4C1AC7D2F6FE449,
	CellInstancedDebugProbes__ctor_m44EA2D56ABD51F06B333CCC0C0017FD99757ED7E,
	U3CU3Ec__cctor_mA8649E64A33FB38928F9D043A502C9F5968E2F93,
	U3CU3Ec__ctor_mF0EC848664DD41AE0CCDBF2F241C5C6A546D36D4,
	U3CU3Ec_U3CRegisterDebugU3Eb__119_6_m6E8E407837C57C4260D9489B041ED9484DEE7DFC,
	U3CU3Ec_U3CRegisterDebugU3Eb__119_15_mACFEE7D12234C56D4B155F5C6ACD53736E3C160B,
	U3CU3Ec_U3CRegisterDebugU3Eb__119_16_mB4AAC3D53ABE490937C833F6969630C2FF4CB975,
	U3CU3Ec_U3CRegisterDebugU3Eb__119_21_m6B35AAA316CF654D597351DA53502340E951100C,
	U3CU3Ec_U3CRegisterDebugU3Eb__119_24_mF332A62004E2F4AFDD64A7F5C629E5EFC3BF53B4,
	U3CU3Ec_U3CRegisterDebugU3Eb__119_25_m4CE1255AD20E72D40153F8FBC1E9515285EA9201,
	ProbeVolumeDebug__ctor_m708DA28435771F8ACB4930A38D58CBF1BCA1C000,
	ProbeReferenceVolumeProfile_get_cellSizeInBricks_m7F3B891F7A7B29639D078C918D846547935E1145,
	ProbeReferenceVolumeProfile_get_maxSubdivision_m4FB3D73C94C5DEB8B4BCCBF05F63665FD2A52CAF,
	ProbeReferenceVolumeProfile_get_minBrickSize_m2CCDD0EE00F450E9DDB4E2501F5FA90B673BDAD0,
	ProbeReferenceVolumeProfile_get_cellSizeInMeters_mCEACEC12BCFE79F8DD0666EAA9A4F01E9228D817,
	ProbeReferenceVolumeProfile_OnEnable_m07E993D2BFBBEBE408A171A58EF2A18FA47C60D3,
	ProbeReferenceVolumeProfile_IsEquivalent_m44EC1FC61D1F55A9A5547C876AE81BA4248D1975,
	ProbeReferenceVolumeProfile__ctor_mFA26873741A8E40621D22413547FEA6486C6407D,
	ProbeVolume__ctor_m737F5BD975F6AF4D1451BA8BBC4BE77832C2C282,
	ProbeVolumeAsset_get_Version_m5081E5AFF96380FDA4A8223668368668E9818002,
	ProbeVolumeAsset_get_maxSubdivision_m25E44F3E71147B9737FC2F4A41E32C91CFB1DDE7,
	ProbeVolumeAsset_get_minBrickSize_m64AB321C43569B209B7D4204FA7ADD218BB6438E,
	ProbeVolumeAsset_CompatibleWith_m5AD9B31F161A973E7E73935A7CC7BED920FE3F70,
	ProbeVolumeAsset_GetSerializedFullPath_mB4EE47E9598C9CB3DBF89987B5EDAA8350AEC7F5,
	ProbeVolumeAsset__ctor_mE8BE9371AB032B37B201D07D3715FB7E2EB64385,
	ProbeVolumePerSceneData_OnAfterDeserialize_m3ECAEC030DE8D59C3DD350AA65598E5444F53C25,
	ProbeVolumePerSceneData_OnBeforeSerialize_mBA3F5C603A8C72A38E8560BF06504F30F0450F61,
	ProbeVolumePerSceneData_StoreAssetForState_m17DD640B885E480290E2B65162F739567D9D608A,
	ProbeVolumePerSceneData_InvalidateAllAssets_m10D2679D74E77770FB9504CA0263BCA41DC48C88,
	ProbeVolumePerSceneData_GetCurrentStateAsset_m9EB714892D89A2F5081BB6ADEA72280A7995E899,
	ProbeVolumePerSceneData_QueueAssetLoading_mB3CCF900B7CA8F944D9438889CF686C42E8BCEF6,
	ProbeVolumePerSceneData_QueueAssetRemoval_mB76429F8B335178B57FAEDB49ECED6DC194CB66D,
	ProbeVolumePerSceneData_OnEnable_m24345BC9A440EB8E1FFA9340851172013F0658AC,
	ProbeVolumePerSceneData_OnDisable_m70BFB2B9F03D9C4447050BF257894531E4C53231,
	ProbeVolumePerSceneData_OnDestroy_m9AF9F2870FBBC5776F0B9D10510A4793D84A7CC0,
	ProbeVolumePerSceneData_Update_m445730F8F5BDF5266887E8DA96EFDA8CD33F6DD9,
	ProbeVolumePerSceneData__ctor_m9408DF107AA7456681BA0C04F8A8E9A4E0EAF5B7,
	ProbeVolumeSceneData_GetSceneGUID_mEDF1CDD66EF5B4D894D922F3C919AC7EE628DABF,
	ProbeVolumeSceneData__ctor_mC79958FE45F62F76DDD7046F40ABABBD8D88E4D8,
	ProbeVolumeSceneData_SetParentObject_m06049317E4479E7CA1A5BD7BA24A207B993CAED6,
	ProbeVolumeSceneData_OnAfterDeserialize_mA98482FCCA743C9D4883DAAC401D92370F0BDEE6,
	ProbeVolumeSceneData_UpdateBakingSets_mA6C61749305923922789F8507BAD28CDF85E4769,
	ProbeVolumeSceneData_OnBeforeSerialize_mD933127ABD743AE08BB9623133D4BD2459EE95D7,
	ProbeVolumeSceneData_CreateNewBakingSet_mD9E5E51600BC457D481FFDEE50C892120F6E354A,
	ProbeVolumeSceneData_InitializeBakingSet_m6493E5485804047422125EAD079D8B3C6DEDB500,
	ProbeVolumeSceneData_SyncBakingSetSettings_m30FE1CEA523CFFFCA27F69D546C22CDE80E455D7,
	ProbeVolumeSceneData__cctor_m23CA3899125A3FCB1F01FA2A2F5FB1F10E28B86F,
	BakingSet__ctor_m601231463B459E0CF1447D5A1D022AABFCA2980B,
	U3CU3Ec__cctor_mB28E86029A10C11C8BB3AB4D831C52C6CD52C156,
	U3CU3Ec__ctor_m3C5DA28363F4562D232FF0D55ED8DC2DF669C3E3,
	U3CU3Ec_U3CUpdateBakingSetsU3Eb__22_0_mC7641AC5D1E5C3C4E6626308BB731C5A03A0D85C,
	RendererList_get_isValid_mD49D7348F5E73DD10528CA33E7E47D045F59ABA4,
	RendererList_set_isValid_m5A13F01C3632E0EA366E89F731C758D9416458E4,
	RendererList_Create_mF62DD90614DB1DF03AF5B8ECFF6C81D0F44F2996,
	RendererList__cctor_mF580866A1CDFFB29AB85A713748A5D935A32BC5B,
	RendererListDesc_get_cullingResult_m1A24ED379AEDF626576FD7D25A2C4C7EC731583D,
	RendererListDesc_set_cullingResult_mE8327030ABADA58F7278D2E0A53AA24B85FE0D38,
	RendererListDesc_get_camera_mA2374241B35A95DCE62E723B25CC991D6DF44360,
	RendererListDesc_set_camera_m5622A8534724C11905739E4717F697C4E79A50C3,
	RendererListDesc_get_passName_m2ABCDEA61E228A46952E7F12895B65C10AB874FA,
	RendererListDesc_set_passName_m48E2013C7D08B499D53125C5791F9FF5540F9BD0,
	RendererListDesc_get_passNames_mC78CE5AC5BAB6381686AEB1CCDBAAFDEEB020FC0,
	RendererListDesc_set_passNames_m1E72B7C01C5EA221BE6CEE9694384319FD67919C,
	RendererListDesc__ctor_mEDAF51BE78BCD5D4F4A2055C75B52C0BDB7448C2,
	RendererListDesc__ctor_mD7954B9620C618E46313FE4AACDAE9A777652794,
	RendererListDesc_IsValid_m424FC29A8206B9F2D11EC1C937762D1E1ABACAA5,
	RenderGraphContext__ctor_mE362BBACE6D5A945C9CC34B7AAEA715F7DFB9BF6,
	RenderGraphExecution__ctor_m6F5D9030833807A2480E493C092CD067D6CD042E,
	RenderGraphExecution_Dispose_m2A4832CC0BAA3642B791D033538C6E97FBAE3D67,
	RenderGraphDebugParams_RegisterDebug_m51C8C65167E33516E765B3D8FEF39DA518959500,
	RenderGraphDebugParams_UnRegisterDebug_mDAB7FCE72ABFC96BCA3D299794D8017AE8D05D73,
	RenderGraphDebugParams__ctor_m174FCBE11F53D73C56586A51B98AC56C6BAEDF3D,
	RenderGraphDebugParams_U3CRegisterDebugU3Eb__10_0_m515BE24E9CB99FEF73990F99C9C4CFCF5BD97568,
	RenderGraphDebugParams_U3CRegisterDebugU3Eb__10_1_m53C6672B4B92C97F61D7D24E50DAD0D8750A9C91,
	RenderGraphDebugParams_U3CRegisterDebugU3Eb__10_2_m1C26FD7DF27A18C57067A2F339479A854CE93BCD,
	RenderGraphDebugParams_U3CRegisterDebugU3Eb__10_3_m5CFDDCA3F495056CBE68775752C840672D5B4F6D,
	RenderGraphDebugParams_U3CRegisterDebugU3Eb__10_4_m86E5D492172D8428AF2102DAA2FF198585C99DF2,
	RenderGraphDebugParams_U3CRegisterDebugU3Eb__10_5_m7D05EDCCFE8AC1D6B11A10F6361B27788A5B3844,
	RenderGraphDebugParams_U3CRegisterDebugU3Eb__10_6_mD4C4027444FFC2AEF974557E7896ECBCABD9E3E0,
	RenderGraphDebugParams_U3CRegisterDebugU3Eb__10_7_m628CB428D0BEEC1EB1B1AA34E7CFA4B688DE7411,
	RenderGraphDebugParams_U3CRegisterDebugU3Eb__10_8_m1266BEC68718D058CD4D7BAA205D64CE57253775,
	RenderGraphDebugParams_U3CRegisterDebugU3Eb__10_9_m50F3726EADBCE25A641CCE4BA38E56F9893AA18D,
	Strings__cctor_m17897CC58A382F5F3C5B9F5AAAA84158483E37EB,
	NULL,
	NULL,
	NULL,
	NULL,
	RenderGraphDebugData_Clear_m657D4C201FBC74990BFDCB39028E506F76C7FB89,
	RenderGraphDebugData__ctor_m801AC7375A90EF3C120F18F1080B3C8B37ACBDFA,
	RenderGraph_get_name_mC4A86F3C3445D41324598444AD9C35152B1415D9,
	RenderGraph_set_name_m5B537C5BD0514C94A202FA6D91E33E0FF8D3BC35,
	RenderGraph_get_requireDebugData_m299B15A8D7F053AB63B036CD1E29E6E9CBA5A052,
	RenderGraph_set_requireDebugData_m4038058EA46EBEFCF4137B5A59A66FCBB6D55050,
	RenderGraph_get_defaultResources_mAF14CF66D8EEB8E7BE53241437E9D7005C662E17,
	RenderGraph__ctor_m8E28DE4BAE8C24B9FC9C71526B5DA8E3BF216318,
	RenderGraph_Cleanup_m1FBACDF1EC2B2FE4372A2B1CA4A3E0AD811A98E7,
	RenderGraph_RegisterDebug_mFD45ABD9F1F32C4959827350213615F13AC51E84,
	RenderGraph_UnRegisterDebug_mF5F358A8AD539BB8EE38311974F863EDCBBCCA57,
	RenderGraph_GetRegisteredRenderGraphs_m6139A25BC24D96370556B9F85BC2D16963A48B12,
	RenderGraph_GetDebugData_mC0F5A0B530BEE7BA47958E52F5EBCC1DCFD0EA29,
	RenderGraph_EndFrame_m8F0177400497B5A5BDC0775733EFC226C7BC0738,
	RenderGraph_ImportTexture_m295CC3D6BDBC43559F09E006FFF6B46DE85214A4,
	RenderGraph_ImportBackbuffer_mE4923F3B0BC4CBEC1943F8ED1B9E8DE22ACFAD8E,
	RenderGraph_CreateTexture_m07CDAF13A95DB913C44DD1FF0C1AE8B8F00E449D,
	RenderGraph_CreateSharedTexture_mD8134A13CA15AF8FC996DD684BCA1D68B5373458,
	RenderGraph_ReleaseSharedTexture_m92F19DDC5582AF56B03F3F96C1F4507FB42496CF,
	RenderGraph_CreateTexture_m330C23C19354F500907E91D67CDCD2F80D07F9C1,
	RenderGraph_CreateTextureIfInvalid_m51DCBC54B88B235A04ABC91E76AA4187AFE80CED,
	RenderGraph_GetTextureDesc_m85050E98790D28024E3F6018482ADE5A68B76E21,
	RenderGraph_CreateRendererList_mC345302092D73FC40883DD4299A02157901D01A4,
	RenderGraph_ImportComputeBuffer_mF773FE1CFF9FA2EDC0CEBC609A7397236E81A7E5,
	RenderGraph_CreateComputeBuffer_m58DF8F141D7D9DFAAD1E7A16928DC28F14B3BF5F,
	RenderGraph_CreateComputeBuffer_m0091B1FE0C84982F40EB7E6B9A5B617B3AA1EAFA,
	RenderGraph_GetComputeBufferDesc_mDB7040D7800CAD0C2CC23A94AAE2251767E70FF1,
	NULL,
	NULL,
	RenderGraph_RecordAndExecute_mABC2B51A63CA24C4CD32BA867B54879FCE48EF6E,
	RenderGraph_Execute_m3A7348FDC7FCE5C9EAE32410C4A8F3E06CD0C9A0,
	RenderGraph_BeginProfilingSampler_m080E79B3E0E59C9791E59149FE65048B3A75F21F,
	RenderGraph_EndProfilingSampler_m7D8308D0AD1C7E10F2F21AADE8FD8A55B56127D5,
	RenderGraph_GetCompiledPassInfos_m23F7801BED40A4F9940B371D7CD193E66040BD76,
	RenderGraph_ClearCompiledGraph_m0DE88504194BD409BF8DF5283796C1BD510A9393,
	RenderGraph_InvalidateContext_m1A18ACC5B65EB13EA2B839837A2DC6EE844DE481,
	RenderGraph_OnPassAdded_mD1E58984AA84ED4DC78BF2E11A9C6D482F47C8F6,
	RenderGraph_add_onGraphRegistered_m0D0C254927D1D710A20590044BF0ED12CB10F87A,
	RenderGraph_remove_onGraphRegistered_m2569676235DE7FEF0C70D89413F6DCF63C44F3B3,
	RenderGraph_add_onGraphUnregistered_mEED68801F08877C5D913946285D2CC37F62FBCDD,
	RenderGraph_remove_onGraphUnregistered_m7D4E732FC2B618A4D884062BD90B5E4E0A6F3F81,
	RenderGraph_add_onExecutionRegistered_mD7F36AB7CB81CB3F98A89F8DBFF7835B72766060,
	RenderGraph_remove_onExecutionRegistered_mE863BB6C6FF6F4F067F8C9E27DC7E73DB62BAC0B,
	RenderGraph_add_onExecutionUnregistered_m2FEE3AB55CFC3DED7AC9A1863694AD6CAB05C833,
	RenderGraph_remove_onExecutionUnregistered_m295401B259C64E12C8C8F865082FFB614269C102,
	RenderGraph_InitResourceInfosData_m3EFB0384E5DA0045B7FBF29FD05DCFE2963BE9DB,
	RenderGraph_InitializeCompilationData_mF068DA94C4DF2E138784B78B1D8D090AF1302851,
	RenderGraph_CountReferences_m9DC624F39709CBA8D2CBBF4B4D906B1A61FA3EC9,
	RenderGraph_CullUnusedPasses_m64210243D88F8DB8A3D715AFA329A0C7A73E88F5,
	RenderGraph_UpdatePassSynchronization_m8DBDEA74E81751778977198189A8A6FF60565956,
	RenderGraph_UpdateResourceSynchronization_m625302659B60F575732E9F62557F87B321C0F159,
	RenderGraph_GetLatestProducerIndex_m01A352F68254570D2DD917A81335DE75A76769C1,
	RenderGraph_GetLatestValidReadIndex_mAB6EBE37C8C9215BD9BF88FB7358D6E6C55EC3F3,
	RenderGraph_GetFirstValidWriteIndex_mC093325F0690ABF05180FAAC5E977FD08B2632ED,
	RenderGraph_GetLatestValidWriteIndex_m4CEDB92D670D89F208C6BA6F53010B6EDF9948A7,
	RenderGraph_CreateRendererLists_mEEAD372353B35077B070CB1BAA74835584B55C51,
	RenderGraph_UpdateResourceAllocationAndSynchronization_mB7D2F33083A27279542DD9E8441ACD321E4CA4D6,
	RenderGraph_AreRendererListsEmpty_m91D5C2C7847B0C80F1FA3F9702584B4A4CFE17AB,
	RenderGraph_TryCullPassAtIndex_m639A11CCD33AC494CF80729B119D96AD66B170EF,
	RenderGraph_CullRendererLists_mC9C6AABBB3746B088D3780AE69B43B06DED42376,
	RenderGraph_CompileRenderGraph_mEEBE1E435ED4B9A20825249E815B69F44539591B,
	RenderGraph_CompilePassImmediatly_m92E065229F1EF3C25D1230A580667D8018820E2F,
	RenderGraph_ExecutePassImmediatly_mD99F62E498775D67EC8CC417961D6A7E4429F22E,
	RenderGraph_ExecuteCompiledPass_m7CBD442272FF60B36465B84E876666208DF08FA3,
	RenderGraph_ExecuteRenderGraph_mE44E864C7A9B048462C97FED00FAD7DF70573596,
	RenderGraph_PreRenderPassSetRenderTargets_m0F0E5AAFE38BB32E0ACE34E280AC7AD12A8A89F5,
	RenderGraph_PreRenderPassExecute_mEF0EFA297299022E67CEF87AC8BD3EDF78A5667C,
	RenderGraph_PostRenderPassExecute_mE6A75DA79257A9010C88CF6B2C823F1873088EC5,
	RenderGraph_ClearRenderPasses_m123192412280C189D7980A24D7127A7D59B1656C,
	RenderGraph_ReleaseImmediateModeResources_m355F6460365E667F706125B7517086DAA05F7A85,
	RenderGraph_LogFrameInformation_mB13932F07DC2BAE648A3A058BB493BDDA53C36DD,
	RenderGraph_LogRendererListsCreation_m87AFBC726B030CB909743F6EC01C8E39298B8ECF,
	RenderGraph_LogRenderPassBegin_mD26259CB5E7D98663701A629BFE91432F7D6DB35,
	RenderGraph_LogCulledPasses_m22B819CF1E35F1A037D215E5B1B28C2819BBB51E,
	RenderGraph_GetDefaultProfilingSampler_m7B7625ADCAE0FF51ED32E646959D4137C2B5C437,
	RenderGraph_UpdateImportedResourceLifeTime_mBE3EDE5D4C257716779709B5ABB8BF27417C9DAA,
	RenderGraph_GenerateDebugData_mBC7800454D14E60A58AF27105635C6B3B9A62174,
	RenderGraph_CleanupDebugData_mB0804703AF2CFA8C4D2584E030BD58ACF049DFC1,
	RenderGraph__cctor_m57CC05DB7D321025041B3AC45C7F9D18F70301AD,
	CompiledResourceInfo_Reset_m37F299281DE9EEB99B9ADBC35125F59765D77A7E,
	CompiledPassInfo_get_allowPassCulling_m19A371EF46D18F2FB95B569004344184EE159F3A,
	CompiledPassInfo_Reset_mD739628D66EE219B4039E42DC685D5AAD09FCCD5,
	ProfilingScopePassData__ctor_mE65C7FE9C6F68526E7C52033349A32C8412C54BF,
	OnGraphRegisteredDelegate__ctor_mBF475B620BDA057E27E35DF0D2E2B635B5F7A1F7,
	OnGraphRegisteredDelegate_Invoke_mC9549D2FDF84731F604FEC183A1991248D14AA2C,
	OnGraphRegisteredDelegate_BeginInvoke_m721B71F047A8E1912DF5C565FEC9E4FF512A4412,
	OnGraphRegisteredDelegate_EndInvoke_m9FAF8CC04036C4FCA52B31D800C8E169E1724D3C,
	OnExecutionRegisteredDelegate__ctor_m381043C04E0B63FAA6A7D116018B634481B201CB,
	OnExecutionRegisteredDelegate_Invoke_m02D2B7F3514909A2E1DD5C17C5F8770BEF828CE1,
	OnExecutionRegisteredDelegate_BeginInvoke_m181019B8E8810BC94A25060D80852015DE4B0D2A,
	OnExecutionRegisteredDelegate_EndInvoke_m46D98B4FDD6D5D73D62758651E178705BCC3A27E,
	U3CU3Ec__cctor_m0832A40A190394AD9FB5175A83F9E475F3E35B6E,
	U3CU3Ec__ctor_m5E46E3271E2445F78FB3B0F9150A302F1D323B15,
	U3CU3Ec_U3CBeginProfilingSamplerU3Eb__61_0_m59488D9D6AEA1CED8C5043FAA1ED7043BADEC627,
	U3CU3Ec_U3CEndProfilingSamplerU3Eb__62_0_mF7F5701CC58F1FBF0468B1DD7A9407E1E5E0752B,
	RenderGraphProfilingScope__ctor_m33361E4872EC1955DC1C93B1252729C6F8AF2086,
	RenderGraphProfilingScope_Dispose_mF856703A7FA42EB3DDBE8EA78BA08DCEF8AAC971,
	RenderGraphProfilingScope_Dispose_mD7AE540A4B899A562FD851CFABAFE458F1E9A5A7,
	RenderGraphBuilder_UseColorBuffer_mBAFAA9789D8E5085F01F2E8798746E0A4C48D5B3,
	RenderGraphBuilder_UseDepthBuffer_m52A44A353C52E10E3DBFAF26A87F86EB08310604,
	RenderGraphBuilder_ReadTexture_m30A338D1203C736F18E9EDFE24A4208384D0925F,
	RenderGraphBuilder_WriteTexture_m506070A8AC6CD4948CBB01FC02E2B2FF2D002920,
	RenderGraphBuilder_ReadWriteTexture_mEA66A932C42979F8EE0C1F402E5A6ED084F01836,
	RenderGraphBuilder_CreateTransientTexture_m703B7C4E31B2F4B2857E05B8FE4E9993157163D0,
	RenderGraphBuilder_CreateTransientTexture_mC507AB02FE73C2F38389C79D9099EDC7F704688C,
	RenderGraphBuilder_UseRendererList_mB0614B837677977DF8A14FDBF95146A74B3EE284,
	RenderGraphBuilder_ReadComputeBuffer_mA630B01D686BE9AB88772818404667D1E69F05D4,
	RenderGraphBuilder_WriteComputeBuffer_mCD7FAF2B083871011645D4CCD2E4A92781F7B495,
	RenderGraphBuilder_CreateTransientComputeBuffer_mCFBDA8024544593AFE98147876B902E4753AFB7D,
	RenderGraphBuilder_CreateTransientComputeBuffer_m59F48C032018CBE9FF26DCDF27C57B002F2B9A1D,
	NULL,
	RenderGraphBuilder_EnableAsyncCompute_mE27B28C6B8176AD36DBB5B4EE0DA800D90F87B03,
	RenderGraphBuilder_AllowPassCulling_m123C799CF19AF7D92A976CCC235C6721F1D8EE86,
	RenderGraphBuilder_Dispose_m6CD2A0E7451C1E81E016C27394732E07F6C53071,
	RenderGraphBuilder_AllowRendererListCulling_m1D4E879CAC013591F860F5C429D007D6ACF692F2,
	RenderGraphBuilder_DependsOn_mBF3A650716934BE44D1314668B1EC60CB1A62426,
	RenderGraphBuilder__ctor_m356E87D6D032DF11F1909F32C011B98CFB16D7DE,
	RenderGraphBuilder_Dispose_m49A9299AD6BF815801312F85C7B6256C5575085B,
	RenderGraphBuilder_CheckResource_m5BF5C4956D9B0FA14EBBE35D84650212A2F0F7C6,
	RenderGraphBuilder_GenerateDebugData_mA7FBEB0EDD92133A1B737F8805349D57A368B6FC,
	RenderGraphDefaultResources_get_blackTexture_m958B2388E4F81582528BFB5A627A8996A11803C7,
	RenderGraphDefaultResources_set_blackTexture_m74BF0C27CB9B249D083B3659C985A952EC3B4759,
	RenderGraphDefaultResources_get_whiteTexture_mA110B74B58D4E59C7DBD489FAFA8F2648AC7C0CF,
	RenderGraphDefaultResources_set_whiteTexture_m0CBA5992252D94A798EC0F5C2D8E5C740665BF80,
	RenderGraphDefaultResources_get_clearTextureXR_m8D433C546AD5EBBA8005CC6FACF2BE8CE3ABBCC5,
	RenderGraphDefaultResources_set_clearTextureXR_m58EC34F05A82BED1A96F9AB405D74BA9FB0F6531,
	RenderGraphDefaultResources_get_magentaTextureXR_m215CC94319969BF117853F0F2C10134CFA116867,
	RenderGraphDefaultResources_set_magentaTextureXR_m86AA147802A13D59DC3FEB19786C756587E086FB,
	RenderGraphDefaultResources_get_blackTextureXR_m7F3BED63C3F3A123D2539291E627AD370C3BEE7D,
	RenderGraphDefaultResources_set_blackTextureXR_mBC67F3C0CFAF725BD6AD9F00655D0F7D28AB481F,
	RenderGraphDefaultResources_get_blackTextureArrayXR_m9D842DD3FC9C8D92B85A4EA4BF75438D2CB54728,
	RenderGraphDefaultResources_set_blackTextureArrayXR_m718E584F8DBCE5CBEF6BF9E6CB3A9BFC93A07B2A,
	RenderGraphDefaultResources_get_blackUIntTextureXR_m781231EE0405206EDB142D84568F77392CE989A9,
	RenderGraphDefaultResources_set_blackUIntTextureXR_m76D37B7D7F08B8327498257A9D03B592F77C7BCD,
	RenderGraphDefaultResources_get_blackTexture3DXR_m43CC668EC2EFFE4A8431667E2FF96EA5425990DA,
	RenderGraphDefaultResources_set_blackTexture3DXR_m933581BEA26A9B1590991F0E2B9FCF602A0FCF05,
	RenderGraphDefaultResources_get_whiteTextureXR_m00E23431A45FB09E2C313E79F73AD2AB13483E09,
	RenderGraphDefaultResources_set_whiteTextureXR_m469DC9C354E94585A837C9D991D1E7D52D166F05,
	RenderGraphDefaultResources_get_defaultShadowTexture_m4EA8FB8D0893BC33315B9FE9339E1C37DE050F50,
	RenderGraphDefaultResources_set_defaultShadowTexture_m7E6330CB5F85105AA023A6AE1CF093FB7028C418,
	RenderGraphDefaultResources__ctor_mD6DA3A7AE17F1FE15C63776794E904F8716BF798,
	RenderGraphDefaultResources_Cleanup_mF92409946BCC07400255DD355133A79C987C2AED,
	RenderGraphDefaultResources_InitializeForRendering_mE0C84DD4903970B6D9352590F1011993801BA8C0,
	RenderGraphLogIndent__ctor_mB06A09F318DD57E80FDF39F5C443C9703BFB3822,
	RenderGraphLogIndent_Dispose_m0FFDA3A98E3E736D7A3784C9E9D5C6A97707B2B6,
	RenderGraphLogIndent_Dispose_mEA306BC46A6C7A416418B1798FBF749A9F2031DC,
	RenderGraphLogger_Initialize_m2C02058B2932844BCB31FC192298B9430675E791,
	RenderGraphLogger_IncrementIndentation_m47F0FB67710EB0DD13E2F7F94C6B9556DADE4A8C,
	RenderGraphLogger_DecrementIndentation_m1E0A4A858CAA383C6FB12875B8A87DE37566E318,
	RenderGraphLogger_LogLine_m3502DD261EFC7E7DAFFC3F4C461A6D02D841B5BC,
	RenderGraphLogger_GetLog_m69349D845CE72C304B61A6F3F2DF2558C378FC6B,
	RenderGraphLogger_GetAllLogs_mAC4F351FF8782E057CA13F2BDB37BA3AE483FF20,
	RenderGraphLogger__ctor_m5A66A4563DF90447B52CE4B1BADC00B48CC4306F,
	RenderGraphObjectPool__ctor_m810EC4C21F7B2392690CA82BD09FBF23614400FE,
	NULL,
	RenderGraphObjectPool_GetTempMaterialPropertyBlock_mE4438968C33B6CD66C43B342CD124D0B6C6D9F65,
	RenderGraphObjectPool_ReleaseAllTempAlloc_mE5AA39993CDCA9A90A624A252C9A37A588A85E2A,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	RenderGraphPass_get_name_mBC9E08A5232E33757330806E9E52F8EA924101DB,
	RenderGraphPass_set_name_m56C8D7395B29FC3BD99D82DE5E45450C9C41D55C,
	RenderGraphPass_get_index_m6E0D043021918E44294E866A910593C5FC32DEA7,
	RenderGraphPass_set_index_mB6B111B7325EC3F70A56417D620662F1AE2B68D2,
	RenderGraphPass_get_customSampler_m524E1FD5FEEEB3F2B4ABA23D793FDFF3208F9218,
	RenderGraphPass_set_customSampler_m05C5220CF5DC934495123022FED1941A678B41D2,
	RenderGraphPass_get_enableAsyncCompute_mBB6A0D9A2B001BA428945EA247DEF457379EBAE4,
	RenderGraphPass_set_enableAsyncCompute_mFD54F752CC9F0C8D0C93AAEDEBF73123F3E69DC0,
	RenderGraphPass_get_allowPassCulling_mE559F1DEB80EA60B73CCFFB9B6B9A044ABCCC292,
	RenderGraphPass_set_allowPassCulling_m28FA3B808526988AF0A322AFC0112C46EF247F73,
	RenderGraphPass_get_depthBuffer_mAB47D705BCC4CAC03894FD18F0982F852534FCB5,
	RenderGraphPass_set_depthBuffer_m46E9FF4C57216F3C350642F354EDBDB7DDDAC5EE,
	RenderGraphPass_get_colorBuffers_m566056C284F90288BDCFE805709BB6B1DB750E60,
	RenderGraphPass_set_colorBuffers_m202BEDE7D90F27DBD440DAEECFFB73E733B34D4F,
	RenderGraphPass_get_colorBufferMaxIndex_m9AB682B3977BBE00CF0FF9E5030A1FA71C220FC5,
	RenderGraphPass_set_colorBufferMaxIndex_m0A8C152F1E2DC60D9ABBF3E85E7A1808BCF0FD79,
	RenderGraphPass_get_refCount_mD6FE631C1208D6A14A47885B37EB7A22562DB766,
	RenderGraphPass_set_refCount_m33C073D227A1CDF4E665CC131CF3D93A346A42C2,
	RenderGraphPass_get_generateDebugData_m4C5F5F8A6F4F69709B0AEDC14740F6A4D792E9F8,
	RenderGraphPass_set_generateDebugData_m06A8222AC5BB9A409E836BBF16CAE39BCD408755,
	RenderGraphPass_get_allowRendererListCulling_mDCB37A5EE941A7023093E530BF177DB1E30BD26A,
	RenderGraphPass_set_allowRendererListCulling_m63CF79D071A52C16BE8DDA35A96471BAB435B671,
	RenderGraphPass__ctor_mB3B733D0783F9C33FC589E697D858F8AE5D8375F,
	RenderGraphPass_Clear_m5E95FA71B8587A0407E38B7C2345A3A95C1DCD6C,
	RenderGraphPass_AddResourceWrite_m77B37DF35F880B3CA9B0F2D93A39AAA381EE8069,
	RenderGraphPass_AddResourceRead_mB1ADB02909484B844C83C50E3A9207712F9261A5,
	RenderGraphPass_AddTransientResource_m308716C330A187EFADEC9399A3FFD6577794B3BD,
	RenderGraphPass_UseRendererList_m4DD9249C7253C3F216715E7957C50606CC1BCD52,
	RenderGraphPass_DependsOnRendererList_m1717D28AE97E76DF4BD356691E4864707994E1F0,
	RenderGraphPass_EnableAsyncCompute_m255E65710FC2330F395571C923DB5D5FBFE16844,
	RenderGraphPass_AllowPassCulling_mC79C9FACC4E23C2EFB45D783462EBA4FCA08DE1A,
	RenderGraphPass_AllowRendererListCulling_mBDE6711F92D9D4A15841500D1E723559126963F4,
	RenderGraphPass_GenerateDebugData_m59E2BAD0AEA250F2678C8D4D9A9EDFCCA6E6610B,
	RenderGraphPass_SetColorBuffer_m629290D196287553E5EC84B9A94C48C23C9DAC5B,
	RenderGraphPass_SetDepthBuffer_m0B5F8D52CB7649F774FD2B99F2213D2E0984A7C7,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	ComputeBufferHandle_get_nullHandle_m5AD19967D7A4A25F921BED78C48174BB85D07F2B,
	ComputeBufferHandle__ctor_m6D965D9809C5D3C7F5F385E54890EE463A81776D,
	ComputeBufferHandle_op_Implicit_mB127C7A6F390D76C3DD38F7F073E4AA5AD1B8435,
	ComputeBufferHandle_IsValid_m4D3C4E81EFDD8940200E2B823024D85C6DA8517A,
	ComputeBufferHandle__cctor_mF6D5698A260C0EE292EB68006B380B00CDCBE513,
	ComputeBufferDesc__ctor_mD364A4B1CBED57C895863DAEC68E88D5F3AEC8FD,
	ComputeBufferDesc__ctor_m6E762AFC03BBCCB7D7C7B4ECF3D718D7C5606664,
	ComputeBufferDesc_GetHashCode_m55AB43EE5444280A59027570E310275097E3BDB9,
	ComputeBufferResource_GetName_m80F37D611406AC02D2520003C1EEE19ECAD8B02D,
	ComputeBufferResource_CreatePooledGraphicsResource_m0171BD976D4E9D5B5A9E2879C0A1395C22932695,
	ComputeBufferResource_ReleasePooledGraphicsResource_m31E104B57DC4881A3ABADEEC39A35A7009059A13,
	ComputeBufferResource_CreateGraphicsResource_mF4FF7838BFB34D9102C71612F3F9FDB0B5842335,
	ComputeBufferResource_ReleaseGraphicsResource_m5931B775F910A6783052B700BDE7279D7C20A9EE,
	ComputeBufferResource_LogCreation_mD30137A8AE8836D80A66FD99420D7B5133C1A0C0,
	ComputeBufferResource_LogRelease_mD0B0364A21342A653FC46EC98027A5187B51780C,
	ComputeBufferResource__ctor_mA03BBFE40BE9457A3F8DA8E8F5369E081DA86395,
	ComputeBufferPool_ReleaseInternalResource_m2DBEDACD727065173AE14FC066CB2B7CA7D0F3EE,
	ComputeBufferPool_GetResourceName_m8F3B467AAB1E56640E445B1EB9F3687C714217DA,
	ComputeBufferPool_GetResourceSize_mC4E7725F37DA0BDF6628D8CCF667B689C80C64D8,
	ComputeBufferPool_GetResourceTypeName_mFF0F53B71C013ECD2AA22F7C3EBB3D9A60ED1A06,
	ComputeBufferPool_GetSortIndex_m55B303A28500F485D2DC06D86DDEA59A899232D3,
	ComputeBufferPool_PurgeUnusedResources_m0698892370966E0C43D456312178E681381E321D,
	ComputeBufferPool__ctor_m497219862B9FF4E5D7AC392EB0BEF378D8E43A56,
	NULL,
	NULL,
	NULL,
	NULL,
	IRenderGraphResourcePool__ctor_m505F033CFC079F0EA1E63BD4E9A813B781072C3E,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	RenderGraphResourceRegistry_get_current_m97F373C58ED6A15ADFFBF8927CAE23D28FAEE707,
	RenderGraphResourceRegistry_set_current_mE572A8ACCF0FC395C7549E5955736FBC2A914838,
	RenderGraphResourceRegistry_GetTexture_mA0D4C3A6CEAF8647C8AE76D4A90319750D29E43D,
	RenderGraphResourceRegistry_TextureNeedsFallback_m819A32FA09A5AEE0915E53C2A0752AF67820D75A,
	RenderGraphResourceRegistry_GetRendererList_mEE5905F0C7C1A54B54EDBD3F97DE645534CDDA9D,
	RenderGraphResourceRegistry_GetComputeBuffer_m0EED9E3B321167D13C91E26B70EB0D85FDE33010,
	RenderGraphResourceRegistry__ctor_m65B64428AC37A1B3C4B6E81E4BDA7265F9031F63,
	RenderGraphResourceRegistry__ctor_m3D24628B5135F00370A97E8F549B13449FE28BFD,
	RenderGraphResourceRegistry_BeginRenderGraph_m109C1A8064C64EBB550A307F1DDA1E32AFA92D61,
	RenderGraphResourceRegistry_BeginExecute_m6B9A1BAF2E57480EFF735E50A8AB45BF781BAEFC,
	RenderGraphResourceRegistry_EndExecute_m54A581B0A8DE32C8094EA4195F294D46F001A625,
	RenderGraphResourceRegistry_CheckHandleValidity_m158A4E64E99E375C73D5F0CAC1B113EFE6E55BD9,
	RenderGraphResourceRegistry_CheckHandleValidity_m7FF4B6FCCAC9C84081F20C819239A2DABB39F242,
	RenderGraphResourceRegistry_IncrementWriteCount_m32CCCC2CE84EECFEFBD2A5CE234505BED3D7DCEC,
	RenderGraphResourceRegistry_GetRenderGraphResourceName_m000367B8EC114CE49B849D6037005B092368C34E,
	RenderGraphResourceRegistry_GetRenderGraphResourceName_m6BE8678CBC929733854088EC9888BD69A9681275,
	RenderGraphResourceRegistry_IsRenderGraphResourceImported_m5FF203E3F02C32A6F12726045B7AFE1397861FF5,
	RenderGraphResourceRegistry_IsRenderGraphResourceShared_m0F3BAD8A7BEC39EFBC4AEA1B4BD93E4A7C9A2789,
	RenderGraphResourceRegistry_IsGraphicsResourceCreated_m50B0405E020D24FD2B289583781D3FF572AABE25,
	RenderGraphResourceRegistry_IsRendererListCreated_m1A178F8154E4F5DB639A1045B09E845F5379B77D,
	RenderGraphResourceRegistry_IsRenderGraphResourceImported_m4EBCFCBEC813263D9E399AD7A558A84D05520BE8,
	RenderGraphResourceRegistry_GetRenderGraphResourceTransientIndex_m0554B2306A87364D556DFD483C14FC8002B4E2D9,
	RenderGraphResourceRegistry_ImportTexture_m81DF7C26F2DEBE95D1391CFAB9AD7E6330039960,
	RenderGraphResourceRegistry_CreateSharedTexture_m3A8992CB6C1F797D20E181351290790D840129DF,
	RenderGraphResourceRegistry_ReleaseSharedTexture_m4FD13BFAD381734BE5254BC14DCD86D0399D651E,
	RenderGraphResourceRegistry_ImportBackbuffer_mB707AA8E5A2543978EE0EFED8B3F179479C99B77,
	RenderGraphResourceRegistry_CreateTexture_mB56D76FBF3BA168425ABD73DA03B78937403EF97,
	RenderGraphResourceRegistry_GetTextureResourceCount_m9A0358556F0E62ABDE85400838CC760709CBA1F1,
	RenderGraphResourceRegistry_GetTextureResource_m2F3C125ADA19AE539C96849F62D4941BC494815B,
	RenderGraphResourceRegistry_GetTextureResourceDesc_m2C39D5A9FC117474762D89F7AC052300D38D86C9,
	RenderGraphResourceRegistry_ForceTextureClear_mE89D1B844EF9D79E803AAB8FC04A062F8D82192B,
	RenderGraphResourceRegistry_CreateRendererList_m5A3D14CA61A7CA5A00BC82E0500ABB1BBE5671FD,
	RenderGraphResourceRegistry_ImportComputeBuffer_m68A696B824F2878ACE3E44E760E028D61B149ECB,
	RenderGraphResourceRegistry_CreateComputeBuffer_m6D7F63A99EB913A133D7E4C5BE6C5022FDD674CC,
	RenderGraphResourceRegistry_GetComputeBufferResourceDesc_m45F37B3D5BD530ECA2DB14CB6AABEFEBED91A2C1,
	RenderGraphResourceRegistry_GetComputeBufferResourceCount_mFBBEF3A6EEACCA67A6E98067D47839EFE2005D1E,
	RenderGraphResourceRegistry_GetComputeBufferResource_mB99DACAE007D6E7166228A8974E78BB08B16A807,
	RenderGraphResourceRegistry_UpdateSharedResourceLastFrameIndex_m01A8CCDA734B3D604AB0A96C77F519152509288D,
	RenderGraphResourceRegistry_ManageSharedRenderGraphResources_m50EF15E3C7C59411E5C067BE654792E10AFF24A2,
	RenderGraphResourceRegistry_CreatePooledResource_m7A707BFF2BE29D1B8B8103879C8B3EC7B8B7B3BD,
	RenderGraphResourceRegistry_CreateTextureCallback_m1755AA433A8745C3B8C5BA8B67666151AD8AD300,
	RenderGraphResourceRegistry_ReleasePooledResource_m2031C38E48A585EB086C244A3D47D44E034C1ABF,
	RenderGraphResourceRegistry_ReleaseTextureCallback_mAA581CF5124B152FA95F4A7B5FF297DFD60ACF2B,
	RenderGraphResourceRegistry_ValidateTextureDesc_mCB8ACB1153374A7AA619006246F237E54D2A38F3,
	RenderGraphResourceRegistry_ValidateRendererListDesc_m4B314D30C4CAB53AF0F638A727EF506BD45CE0BF,
	RenderGraphResourceRegistry_ValidateComputeBufferDesc_m8C766FBD5BD48AA70AA7DB385FD8868E0D303AE0,
	RenderGraphResourceRegistry_CreateRendererLists_mBE817E97CC7909310E47A54C4FEEA42257AF4AE3,
	RenderGraphResourceRegistry_Clear_mD46E87EC32F4E591732FCD7FB7F69AA1243AF309,
	RenderGraphResourceRegistry_PurgeUnusedGraphicsResources_m593279893CD0650F0AAC95859FCE4C5E40C943B5,
	RenderGraphResourceRegistry_Cleanup_mAF56D87596328355ED31A4C009E0C5F70CE4E979,
	RenderGraphResourceRegistry_FlushLogs_m6111629FE7BD896DF076EDE721BBE268DC7F450A,
	RenderGraphResourceRegistry_LogResources_mB4DE5B9AE131FF60064BBA25FBEE6034911165F0,
	ResourceCallback__ctor_m83ADE3D8CD197E408D138B6414700A036BA0632E,
	ResourceCallback_Invoke_m44975C771B30E3B1D643AA09C8546B54839F9978,
	ResourceCallback_BeginInvoke_m5B83C1D642493776276FEFE24718E11B73456D42,
	ResourceCallback_EndInvoke_mFFE27089EF8D2FDFD7D6451D6E207BF5B0BF5E71,
	RenderGraphResourcesData_Clear_mD4E3B153DD47FE532CC058AB44F597AB0D4DE56C,
	RenderGraphResourcesData_Cleanup_mD6A20FDAFB30E905B4FA0547490E7220BA3A3609,
	RenderGraphResourcesData_PurgeUnusedGraphicsResources_m24F8F6F3889FC6724341369C51260CC7D367B2AA,
	NULL,
	RenderGraphResourcesData__ctor_m1D295D8A104963715BAE610F9A17C9F9E33F2682,
	RendererListHandle_get_handle_m4D239A48FFDBFA551B8BE7A4448BF19370EEB848,
	RendererListHandle_set_handle_m0DE76F63C96B25082DA109CB2C5C9EBB99F6D0E3,
	RendererListHandle__ctor_mCFD25579FE4F4D3687533BE4A366128E0E23B0AF,
	RendererListHandle_op_Implicit_m67A309DDD452E9C1C024CBACE7A0759B3B3357E0,
	RendererListHandle_op_Implicit_m773844C3742FA469FDAD459576166538B28ADC25,
	RendererListHandle_IsValid_m39DD764115038D342C81E04B5475E957246B08A1,
	RendererListResource__ctor_mC9EDE12FC17F2685835A6A57E9EF3FEF1629D15A,
	ResourceHandle_get_index_m91DB2195EB1D4B5AF1D37FF737C8B6EF8B4E9E50,
	ResourceHandle_get_type_m2A8AF5AC268B8068DF6EB721B4D28A6A82B0C88B,
	ResourceHandle_set_type_m4626071A3B159FDD69989F2C9591A8977CB6454E,
	ResourceHandle_get_iType_mE93479F8B75DD94FF1B32AC5FAF7E6F923DC63C5,
	ResourceHandle__ctor_m43993F666EE5128E896AE562EB4AE65263831C5F,
	ResourceHandle_op_Implicit_mC78D25CDCA754EE189EEF7A357D17E128ECBA84A,
	ResourceHandle_IsValid_mBC26F92EEC475A8B75722BA104A462E16C6337A2,
	ResourceHandle_NewFrame_m495A2B09AEB23AC518832589E235C91D9AF60497,
	ResourceHandle__cctor_mA1B137FA250B8998012DEE4A779C79F3154BD385,
	IRenderGraphResource_Reset_m81E9B60C6150975FDFED0428472E8A472FF30627,
	IRenderGraphResource_GetName_m5A9737599D755C54E346749D355646E6B9F6A911,
	IRenderGraphResource_IsCreated_m16C66BC5B46AD970AF5368B8F424021B592A40A8,
	IRenderGraphResource_IncrementWriteCount_m591E3311ADF6DCC6A07B5401A482C0CBDB04917A,
	IRenderGraphResource_NeedsFallBack_mEC21987B1F714A426BBD1500E5FAC10241F09654,
	IRenderGraphResource_CreatePooledGraphicsResource_mB261A2ADFC1ED261F87248C8C07AEE15B0A226F3,
	IRenderGraphResource_CreateGraphicsResource_m26D0C999DA9152D23FF6D5C38509095F96D20766,
	IRenderGraphResource_ReleasePooledGraphicsResource_mCE11733A2622F15CC41392867E92884DA9EEC3D3,
	IRenderGraphResource_ReleaseGraphicsResource_mA150B18FCCF7EEE7A61CC3B4DC6D3F024B0BEFAB,
	IRenderGraphResource_LogCreation_mD97B45EBEB5863A24FBC1A59F3E6537F09DB45BE,
	IRenderGraphResource_LogRelease_mBE6D5B8DE2FD3EAF5BFB0F1D28683591A693E0CF,
	IRenderGraphResource_GetSortIndex_m56A038268B0ECA06215646E6EA64F979329277FA,
	IRenderGraphResource__ctor_m5537D42301A3E59C0168555DE63CD6A29FB6A63E,
	NULL,
	NULL,
	NULL,
	NULL,
	TextureHandle_get_nullHandle_mF3A03146F64615C041D0877D1E89D3E9FECDA0C0,
	TextureHandle__ctor_mC6D0A6B896CC0E8589B88D370869149649031FB0,
	TextureHandle_op_Implicit_mC29818753DD8EEED56054693514CE10964E580E6,
	TextureHandle_op_Implicit_mE367E3278732AE71E80473AB40FF760F20621673,
	TextureHandle_op_Implicit_mF08AC03F72EEB69A60C965CF79FCBD332F029FC6,
	TextureHandle_op_Implicit_mA5D8393D6F1ADCFD27E34F979B24F35BAD6BD3CF,
	TextureHandle_IsValid_m3C2D8F8EB70206A09F3FFADDDD230E00C25269D9,
	TextureHandle_SetFallBackResource_m63C811961161AB0BD5C7ECC272EBEF26ABE84EBE,
	TextureHandle__cctor_mC6F25D8B7ED8A1AA3DFC14D43ED2071994A615B2,
	TextureDesc_InitDefaultValues_mF4DA67529813E66310182D684D50A9FCCA4BE911,
	TextureDesc__ctor_mAA4AB396BD886053C637CC275E7839B887B44FA3,
	TextureDesc__ctor_m7DD9D0AB2E909E3E014FA3BFE0433235881031E0,
	TextureDesc__ctor_m524B5F82F524BB71949F24E0436876092BE8B0E0,
	TextureDesc__ctor_m55D6822C811DB1361730AA8C0E28564C62F95699,
	TextureDesc_GetHashCode_m84A013881648FFDEBA578DC743BA617C812130E0,
	TextureResource_GetName_mC89D211EB725AE9D25374F813A8F16B64A16ED91,
	TextureResource_CreatePooledGraphicsResource_m27BBE4F4CF511B3881F29BDB02A7EB8E00804465,
	TextureResource_ReleasePooledGraphicsResource_m2034ACC2EFAC93E7061A920E411FE6655C950552,
	TextureResource_CreateGraphicsResource_m96734CDAB9AEE1B1616C3B93E145EF059DAA67C7,
	TextureResource_ReleaseGraphicsResource_mC2630A1E843565E00B4A5BAED0640BF24C051D47,
	TextureResource_LogCreation_mCAA0157BCD522230430F557DC2F98CD36E2CAC75,
	TextureResource_LogRelease_m8B4C211B21EFFFC6ADF082275A2001648F0B05EF,
	TextureResource__ctor_m659F978DACAC9671F72A2B7B10D66E1B43B61501,
	TexturePool_ReleaseInternalResource_m9473BE0C881790CC3CABDA03D48DFDA123C5B004,
	TexturePool_GetResourceName_mB31216B01D16305C89FFF4ABAFF269877CADB195,
	TexturePool_GetResourceSize_m86E799D5F54610D987CE10737FE5BBB1D43A2A06,
	TexturePool_GetResourceTypeName_m0B614259A4C46737679DE1C6925BDAD352E60620,
	TexturePool_GetSortIndex_m0D47B44E4D16A6119869CD3B0B68B64ACB819F2A,
	TexturePool_PurgeUnusedResources_m994BE8A3177D9AAE636F4D40F4E959C6F9A30945,
	TexturePool__ctor_m085C992A3A857BC6E0B417512CBE98134B2FFE5E,
	CameraSwitcher_OnEnable_m24104E3A78B71F31442A1B8A71F79F2620966BB7,
	CameraSwitcher_OnDisable_mD2920C1486BFE1EC7F87A863B373A17F8954B9D8,
	CameraSwitcher_GetCameraCount_mC48F44F4BE27326847DE783C7CB6F89D6A4E3CB0,
	CameraSwitcher_GetNextCamera_mFD17D7213672960C743C4947E83EAA95ED8F8018,
	CameraSwitcher_SetCameraIndex_mC467AB35FC45BC0FBA09C062B854B4210C682FED,
	CameraSwitcher__ctor_m58E93E0C44E327A17DC191FAB41AEAE02756F7E0,
	CameraSwitcher_U3COnEnableU3Eb__10_0_mBA0A44912EFBB06862FFE6BFAB473CC8088554B5,
	CameraSwitcher_U3COnEnableU3Eb__10_1_mED6417B1D873D0CDB7A4AD790D3DE5B816BA64DF,
	CameraSwitcher_U3COnEnableU3Eb__10_2_m5FF4CE2227650E8A8EC1FDF82EFA120910C9F651,
	CameraSwitcher_U3COnEnableU3Eb__10_3_mBEEA1799E253361CAA01E1EB466A05EB1A8CEF60,
	FreeCamera_OnEnable_mD7CA8EBB7B0281F02AB4CC64606DBE70A82B54AB,
	FreeCamera_RegisterInputs_m33CB202F41B9766CC2A375A56704D828C0523AD5,
	FreeCamera_UpdateInputs_m52DB79FEF7076222572E8AA0D651610F89BAB7EA,
	FreeCamera_Update_mB479DC04102D3835894EF87B8C2C1926053267B7,
	FreeCamera__ctor_m60B6098E94DB0A2D70B37A19E0DB1B837BEC9A60,
	CommandBufferPool_Get_m54EBE601AF00C8A5EDCAA503E65380F464BD1355,
	CommandBufferPool_Get_mC33780CD170099A0E396A2F3A9AFB46509B31625,
	CommandBufferPool_Release_mEC46D8373A95DEC68F1FBD2D77FF3F76917631BF,
	CommandBufferPool__cctor_m98BCC37031F4485865B612ADEA7A57782D2EF798,
	U3CU3Ec__cctor_m9E1BD953730391FC027171E4628DB8E2AD59A745,
	U3CU3Ec__ctor_m5F75A5B7C96F0194D93D30844E235C11C9ABF735,
	U3CU3Ec_U3C_cctorU3Eb__4_0_mB68D246349C87B64BAAA41AFD0D35D7FCEDA7184,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	ConstantBuffer_ReleaseAll_m45705C7C5F462134EE44B8836265C1FEC4B2EE1A,
	ConstantBuffer_Register_m3140BCED0E179D4866D62AD282FB2A3AB8AAE58C,
	ConstantBuffer__ctor_mEA032D1349A00FDB9819C68A091D4ED28B6B592E,
	ConstantBuffer__cctor_m112313AF1963DD52DB8744C3BE8229849320BE1A,
	NULL,
	ConstantBufferBase__ctor_m94F35283F61DBA0BE16E974E2E08FE8AF001C633,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	DisplayInfoAttribute__ctor_m32E321F8942CD30E9525DC5625957DA0FAF00CE2,
	AdditionalPropertyAttribute__ctor_m26BABC5057FB7B910AA64EF6DBC2A4E345D14DAE,
	NULL,
	NULL,
	CoreUnsafeUtils_CalculateRadixParams_mA3F9E5915909C61B4F6AC824AD1251DF6C4DB3D8,
	CoreUnsafeUtils_CalculateRadixSupportSize_m81701201662FE1E5C333847D5983A80CBAFD416A,
	CoreUnsafeUtils_CalculateRadixSortSupportArrays_mC48E09FEAB22CC374B552C36DA3DF6A87AF22C25,
	CoreUnsafeUtils_MergeSort_m0FDAE66D606A6C1E4273AA67835CAE51C3F46C94,
	CoreUnsafeUtils_MergeSort_m3B869BAE2FB12C54B19B6F05C1FF4878B0119E09,
	CoreUnsafeUtils_MergeSort_mAA0EE8D9A240D5FFA96B5B0017F2DE21CE7B9EF5,
	CoreUnsafeUtils_InsertionSort_m7F608794B8D35BA45C7B0C09A4F2A4E6B736428F,
	CoreUnsafeUtils_InsertionSort_m8D93071E60687FC60F1C2BC6DCCA41774C71497E,
	CoreUnsafeUtils_InsertionSort_mF4D8EC3E0CBFB402D6A67FA10722FC875E3C6AB0,
	CoreUnsafeUtils_RadixSort_m9ACC1FB4CE50A62FE646E4B3567E1EE0BF0F8DBD,
	CoreUnsafeUtils_RadixSort_m341659CBED64B8068DCF727CB71A0105F70710C0,
	CoreUnsafeUtils_RadixSort_m174FB1EFF8086D361EF80E4235950616CC175C3B,
	CoreUnsafeUtils_QuickSort_m0992D344EEB55A4BCD122213544AD209E8F76994,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	CoreUnsafeUtils_CompareHashes_m3E86391DEDC1888FF118F75ED9BAE3CD88376686,
	NULL,
	CoreUnsafeUtils_CombineHashes_mFF93250C6EA10674584172B9DA8E37F65DE24D4B,
	NULL,
	CoreUnsafeUtils_HaveDuplicates_m6CC59043E94B6D20208D5EACBB42378109102418,
	FixedBufferStringQueue_get_Count_mD76761535F559C02B70B4D5D2307258723BB34F9,
	FixedBufferStringQueue_set_Count_m6E44F205107949D343D9C9D27F6CD2BB225D6667,
	FixedBufferStringQueue__ctor_m02082DF6032DA322E64476C0C762A17BCC4F26DC,
	FixedBufferStringQueue_TryPush_m72D763782852C157100DBA747E8F137F4B6B3149,
	FixedBufferStringQueue_TryPop_mF2BA587E26D93B58FB0BAD59C5125E9E6FB80F09,
	FixedBufferStringQueue_Clear_m0B3FFD74689701A352CD3EDFA9C85E9D28ED6DF0,
	NULL,
	NULL,
	UintKeyGetter_Get_m76C2635B8A8D4EFDFCF2157D5A691B9C0D7F6141,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	PerformDynamicRes__ctor_m6DE404207716B9CF7CB8E08C5C9E59A82B49B40E,
	PerformDynamicRes_Invoke_mD407788BCFC1B6B1E3DBE2E28A052EEB0190510B,
	PerformDynamicRes_BeginInvoke_mAEE0D03993E275FFF28478E712CD340A29719AD6,
	PerformDynamicRes_EndInvoke_m0063049FB2B568344D76DEB0505B3E2E42BE6645,
	DynamicResolutionHandler_Reset_mCAD8F828B490E47D29551684E9BF919A80D082CC,
	DynamicResolutionHandler_get_filter_mD3E5D8CCCC4B486123F2CFBECC993E34490AC9AC,
	DynamicResolutionHandler_set_filter_mBE888DA4EDD9D09F8FBC2D7482DF6CA3EC8C01F2,
	DynamicResolutionHandler_get_finalViewport_m00EBCB5489C6369B1CB3FDFDC304E2BD1271776A,
	DynamicResolutionHandler_set_finalViewport_mE821C4F8DD1C095D1ED61AFBA0663D2101E88D2B,
	DynamicResolutionHandler_set_runUpscalerFilterOnFullResolution_mB838E0AE8DA12FEDE11D98C3041C3A618580F89B,
	DynamicResolutionHandler_get_runUpscalerFilterOnFullResolution_mB676A5E1BD1FABB5CCACA1E4EB0A8C266CB1CD23,
	DynamicResolutionHandler_FlushScalableBufferManagerState_mE5CED8D2E09BC0844DB1969D491D35C534379BD1,
	DynamicResolutionHandler_GetOrCreateDrsInstanceHandler_mB7511A48A3C0FC5B90F8512ECB1294F7C6C2267D,
	DynamicResolutionHandler_set_upsamplerSchedule_m89200D3DE9B9C5C320A773D8C31635B6BDB0A437,
	DynamicResolutionHandler_get_upsamplerSchedule_m912966EB7F7528669346F8172C4CC2713421C354,
	DynamicResolutionHandler_get_instance_mB5F7D50D277F853FC0D5ECE14E3EEB3630060A94,
	DynamicResolutionHandler__ctor_m8F8CCCC18D6BB56DBD15B129F83EF516C2535B27,
	DynamicResolutionHandler_DefaultDynamicResMethod_mA21FF171A0064BC217D9ABFE1663189A5D1DBB6E,
	DynamicResolutionHandler_ProcessSettings_mB1DA598171628A30DBDEA6F3BE179B894422D7FE,
	DynamicResolutionHandler_GetResolvedScale_m1F5182A5D9687FACF4F859CB38CD92CB767282D7,
	DynamicResolutionHandler_CalculateMipBias_m91211395DCDC11B8AA6569C65033DFF95C31CD7D,
	DynamicResolutionHandler_SetDynamicResScaler_mD4634B44E92248502386D3876E7FA1B7A4075CDD,
	DynamicResolutionHandler_SetSystemDynamicResScaler_mA5DBD3583CAAE8553330C71E33F5767BCBF13E17,
	DynamicResolutionHandler_SetActiveDynamicScalerSlot_mCE1DAFB721B1323497811B565CB74D210ED4CA72,
	DynamicResolutionHandler_ClearSelectedCamera_m7A3DE1CCAFEF8B5AE3686C2DC2FD1D320D3DF353,
	DynamicResolutionHandler_SetUpscaleFilter_m5B1AC58D11657C17C1FBE5D677B5F4CB0559AD62,
	DynamicResolutionHandler_SetCurrentCameraRequest_m8AAE061DC0452D48F183C9B6FD9BCB063B542D9B,
	DynamicResolutionHandler_UpdateAndUseCamera_mC548CFA8941E1929733E7AE05C492970739E5D44,
	DynamicResolutionHandler_Update_m88523DFEA038541509AE38FAB7A136FC22D0FD24,
	DynamicResolutionHandler_SoftwareDynamicResIsEnabled_m6D45F7FB372F1E1735A5DA8F1F063DACCB9BDE9C,
	DynamicResolutionHandler_HardwareDynamicResIsEnabled_mDD7A039094F7770063A58FB71942B9204E3353CA,
	DynamicResolutionHandler_RequestsHardwareDynamicResolution_mE007D198D273487DD581E1D3C675218D9EC082CC,
	DynamicResolutionHandler_DynamicResolutionEnabled_m743EA5F78E9E53B4703F8D3E71914677043D6B5C,
	DynamicResolutionHandler_ForceSoftwareFallback_m824A0C6626039D48FA74E98910BB7204358AF883,
	DynamicResolutionHandler_GetScaledSize_mF2F4EF2E56CA1F9977FC929AD538C3F39E3FC688,
	DynamicResolutionHandler_ApplyScalesOnSize_m65DBECCBF4C39386564AFFE17573331EAC4B15AB,
	DynamicResolutionHandler_ApplyScalesOnSize_mD8A58BA1454CF83D34BF0DFCBC4A0B0251C5B240,
	DynamicResolutionHandler_GetCurrentScale_mDF82E24A8DD95C5D205276D372E40B4C02C24F80,
	DynamicResolutionHandler_GetLastScaledSize_m2EEF34035A43BD49F05DBA104CD496CBE3A9B471,
	DynamicResolutionHandler_GetLowResMultiplier_mB0FAA125AB58DF5F1F077B45104E840B15893A8D,
	DynamicResolutionHandler__cctor_mDDAAC32872CD5018D46B52EF8DA295F395AA7EB3,
	GlobalDynamicResolutionSettings_NewDefault_m2348E238A9145B9231F72B63A84E50202F665342,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	SerializableEnum_get_value_m847B9970F811A9F7105C31240EF5361847F6E5B3,
	SerializableEnum_set_value_mEC3C9ABD19AAB4AEDCFB10BD76FCB66C67BC4D94,
	SerializableEnum__ctor_m0EC8862E7D14F1C0F50A735A8EE72127AED0ACA0,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	XRGraphics_get_eyeTextureResolutionScale_m76C72817BFBBA40F19FFDD78520328F2276C897D,
	XRGraphics_set_eyeTextureResolutionScale_mDAA664F075C60B1D9F1CB993F6F596FECD5ED1E2,
	XRGraphics_get_renderViewportScale_m692F7AEA96D4FBE101FD5F4E79E067A92DDDAA6F,
	XRGraphics_get_enabled_m20C6B9469F10B969FCB5A6C947572018D2EC3682,
	XRGraphics_get_isDeviceActive_m2C56A0AAC15E7A5EAB13FF166C21656A346D50C3,
	XRGraphics_get_loadedDeviceName_mEFE40C069D96EAB1D434396610F448CA04F9BF0C,
	XRGraphics_get_supportedDevices_m2533C6F7D38AB048753C86CD99246FEE6EB97E51,
	XRGraphics_get_stereoRenderingMode_m4C79DB2B7BAE5ED2E2A955124CB195D665B4C88D,
	XRGraphics_get_eyeTextureDesc_m7DE5587B34A67EFA47A20E0A577782AD24A0B848,
	XRGraphics_get_eyeTextureWidth_mD73772DBAF245376C5FECDA6AF2827FF8519E88D,
	XRGraphics_get_eyeTextureHeight_m8665C6F84451DFB48E4DB0CDD87BB920E009EA95,
	XRGraphics__ctor_m3F6CB23F4CCFBDB5B349C5A7D7B5A771E3C91357,
	DebugManager_RegisterActions_m08A5627380CCCB0192783D05AEED057F817B177C,
	DebugManager_EnableInputActions_m5889ED24EFA3383E683D452FE45CD434E1611E92,
	DebugManager_AddAction_mADAAC2A5B86323625966CC53D0413AA0E4C7E9BB,
	DebugManager_SampleAction_mBB1CB238142C6828A7BC49AC6885BD4B5E14185D,
	DebugManager_UpdateAction_mC315562B9E390627E83B59D5CA15DDB0B9AF9375,
	DebugManager_UpdateActions_mFDFEE466E6EF0295FF22CFFC92738CD80DF6A30F,
	DebugManager_GetAction_mF49CDA3900720779DADCA26D660A9C08DAC7741C,
	DebugManager_GetActionToggleDebugMenuWithTouch_mD00A060C5705334410F83ACE437D7659756D71EB,
	DebugManager_GetActionReleaseScrollTarget_mA8742D7420A03055AEF6E99576E359AA6E5FBE77,
	DebugManager_RegisterInputs_m537F22F75442F20A412290FED01B4E4F036EC233,
	DebugManager_get_instance_mE739109CEF80088D21ED7FCF46D1153097B45086,
	DebugManager_UpdateReadOnlyCollection_m53286D374289908BD8D3A8D5E99661CEEB80AAC5,
	DebugManager_get_panels_m6D2F1002F12979053200CD6A29CCED2635F12F6E,
	DebugManager_add_onDisplayRuntimeUIChanged_m9DDCAA67B1F3EDEC672CE08DFF83DA7E25EB0AFD,
	DebugManager_remove_onDisplayRuntimeUIChanged_m2DC90942AD8C4117BD4569F8659F0C0C928661A9,
	DebugManager_add_onSetDirty_m78A474A63D04359ED435BD03825CCCF2B701CA30,
	DebugManager_remove_onSetDirty_mD60B9F3EB7FB9308E432F4395BDEF06B59A6A8D1,
	DebugManager_add_resetData_m6195C05AE430E2DF4B8D0FB20D5057552AF24240,
	DebugManager_remove_resetData_m96A67431C2EAF71CAC1E811A13738711BEBE1AC6,
	DebugManager_get_displayEditorUI_mB0BC6CF28FF4569A791579BF6BD22CAD17774792,
	DebugManager_ToggleEditorUI_m0A74DA6D686ECB521E6E82F19557955261DDE504,
	DebugManager_get_enableRuntimeUI_m2CB2E20F2CCE737FE6AD3214D5DC16D75F2CA532,
	DebugManager_set_enableRuntimeUI_mBFBBD988EE69074F4E2AFA33770FDBBBC623C201,
	DebugManager_get_displayRuntimeUI_m425A05718ADC5F5168D3D862C0FF3CB5D36259A0,
	DebugManager_set_displayRuntimeUI_m9D935288B59DE1136DB37985EFE102A35CD4A90A,
	DebugManager_get_displayPersistentRuntimeUI_m7B8B935C5E6D5D0EE734DB112B2178418910EF48,
	DebugManager_set_displayPersistentRuntimeUI_m6EA3817BEF5D31D2000061DBE8E95CF40AA43262,
	DebugManager__ctor_mF476ADDF14866AE360540BE83717892D259CC38E,
	DebugManager_RefreshEditor_m212A2648023473D0D7714F88FEF0B6B00357B948,
	DebugManager_Reset_m8F235B190A155A4748A6101C46F5654D989C42CA,
	DebugManager_ReDrawOnScreenDebug_m743E2E7D187BB39F175DE5D6D21F6BD0676A49F7,
	DebugManager_RegisterData_m120D9348EE342EEB06177C14D4B4E3E0A0FFF7C0,
	DebugManager_UnregisterData_m0E2EFE5940D89CC5A2E2115F56E5D004D8715AAE,
	DebugManager_GetState_mA45CEE821FEFFF5A7546DA822FD046F63FEF37CF,
	DebugManager_RegisterRootCanvas_m17796C585AB91ADE0FA5901FD3B800B75A0C1A18,
	DebugManager_ChangeSelection_m77C3E5AD1A1B7D9EEFA8C39BFD8A40B1AEEB856A,
	DebugManager_SetScrollTarget_mA81C5DD4585EF12FD3C966E898549568B603FCE9,
	DebugManager_EnsurePersistentCanvas_m3EF45D3A10CE2C9CF3AAEA227125FD5C225D8908,
	DebugManager_TogglePersistent_m053E880302A92E891DAEA5AEB7837AD0C58EA540,
	DebugManager_OnPanelDirty_m131DF174602146B039443A1A28F3DFA62DC1128D,
	DebugManager_RequestEditorWindowPanelIndex_m83A9C35808CD06610427B39DD3184F4738B7A238,
	DebugManager_GetRequestedEditorWindowPanelIndex_m0645B6776A0B926D039063CBF97F0146E139E87A,
	DebugManager_GetPanel_mD434C1C01EA3E39B3C97783F23C6DDF10E2D4617,
	DebugManager_RemovePanel_m2BA800D60782D86B7D43DCC6BF75A7A644F01AE6,
	DebugManager_RemovePanel_m6A4747CEB9021415FE50E4215B26CDFE6F1FFCF4,
	DebugManager_GetItem_mE1D9B27547C9D486C15B0DD30486FCB78AE9C593,
	DebugManager_GetItem_m566B64605B39FCFA874D81BD5FF3EA91826DBF07,
	DebugManager__cctor_m907F8CDAD24776E760732BF95AD18B1D9EC76AEA,
	U3CU3Ec__cctor_mB7CF1D7FA772DAA78896023EC91108D6CE5177E0,
	U3CU3Ec__ctor_m62A49ED74D0D04ED3D1DCB5CFE60143C140CCA32,
	U3CU3Ec_U3C_ctorU3Eb__61_0_m33F5DEA3457FEC99073B87CA24A7E4EA42B04731,
	U3CU3Ec_U3C_ctorU3Eb__61_1_m448398689B057C28EF2102BA9D3BF5E7B51051AF,
	U3CU3Ec_U3C_cctorU3Eb__81_0_mF78E83BAC51411EEB68F2464ADBEC56485EA5070,
	DebugActionDesc__ctor_m850B5BC98DC18B58B0F5C7549CF58BF020418010,
	DebugActionState_get_runningAction_mEB9DCBC3068EB129469ECA0CB23A78ECFB79E738,
	DebugActionState_set_runningAction_mC0CBE1248F7AC3282F94479C272FE840EACE6475,
	DebugActionState_get_actionState_m7DF4C910BA8D1EB0A09F67889CAC58E68FF7CA5D,
	DebugActionState_set_actionState_mF8B8936D22509EBB2A75CCBE299A7E689F35F519,
	DebugActionState_Trigger_m6EB1B4962D76B3FC49800703CB441D030515F16D,
	DebugActionState_TriggerWithButton_m55E14EC67214E15DBF4F2119828892DD4E2A90FF,
	DebugActionState_Reset_m02AC56B80B3E1D2F6168085671463C739A0DFAB5,
	DebugActionState_Update_m9E82525978934996DC1DAE8672E949BD7D6EAB9E,
	DebugActionState__ctor_m3C1005EA7D29105C979ECB8FEDBC8114301DFE54,
	NULL,
	DebugShapes_get_instance_m62A94E93E7E2858686828810507EFF672FB63D09,
	DebugShapes_BuildSphere_m2F8DC6F2C41EC71B78426044CB72C9A901564DB2,
	DebugShapes_BuildBox_m32A28AE9D970EC49A14B27E8304E3036F9585A78,
	DebugShapes_BuildCone_m3B10CB0169CB29F6E7D9B9BFB118FD7533DD0C34,
	DebugShapes_BuildPyramid_m053C3007C6D480E9FC626DB4269C9176E10826D1,
	DebugShapes_BuildShapes_m9EE57CB52AFBE5B256F90A129B7351BEDB76C08B,
	DebugShapes_RebuildResources_mCC40B2CAAA50D843081A5318223853A7AEA5C894,
	DebugShapes_RequestSphereMesh_mE7A458570F1FBFE176EDCCDB3296938B6630AFAB,
	DebugShapes_RequestBoxMesh_m4D81525EE113A2E28D43484A988F96B1D15C24F5,
	DebugShapes_RequestConeMesh_m928BAFC56E30F7481B6816DBA4B641667C29A020,
	DebugShapes_RequestPyramidMesh_m1B04F71D00EF5063AFAB9ACCD42983A6522E3E7E,
	DebugShapes__ctor_m51B4A41AD0E654D2733C4F03EC777F9A1E97CBBA,
	DebugUI__ctor_m62AF64F0AA0461E47CDD8DB2BC5396716913FBB4,
	Container_get_children_mF5C23A0F324E22BEBEF2EA14CE8DA7BEA72D631B,
	Container_set_children_mCF89E0F76E568DF6B7D36DF256D31EFA6C0816AF,
	Container_get_panel_mBA18A8C9B2202AF0D23B87D1BEA4F39C330C51EB,
	Container_set_panel_mCEF38A447DA832758D2216EF5AC6CB2CC7BBEC26,
	Container__ctor_m31E5465D076DCC7A1C932B44B7D2000821C0BFE8,
	Container__ctor_m46FE992D48A7E41195B54F97C68C6850E4E88638,
	Container_GenerateQueryPath_m980DFE475B7DC7DD3ACA1AC5434ED4F086671862,
	Container_OnItemAdded_m2A8448259868E7070860EFE2CBBF9903B57AF4BA,
	Container_OnItemRemoved_mE2081F89AA7A0D0FAC294EE0AD59258746DD84C8,
	Container_GetHashCode_m3B58370534C56FEB22EFF02EAEEDCAED265C7F6A,
	Foldout_get_isReadOnly_mA5BD95FD6277027A543E26CBE6BD048CB2A0E886,
	Foldout_get_columnLabels_m668E673185A4DFF88DCA1B1CBA7DCFA59E491F38,
	Foldout_set_columnLabels_m708C0359BECC9C20EA881B159AA9362000B7BD74,
	Foldout_get_columnTooltips_m4D3DE909F195D474F81F9A563AE719254E8AF3B3,
	Foldout_set_columnTooltips_m461962F856FCF985C404521285F86AC77A7AF02B,
	Foldout__ctor_m139328695A6D59A234CDE32D0CEDA6B80A4F96D2,
	Foldout__ctor_m61E0C79F14925225848625B5787BEBA322D223E6,
	Foldout_GetValue_m3AC0382B7AEF8DABEA86B4D8076A8ADCD21210B9,
	Foldout_UnityEngine_Rendering_DebugUI_IValueField_GetValue_m819C151D885BCE3181E2924F01749312B78F680D,
	Foldout_SetValue_mBB92A78DF887960ED4662620AE5131EBD5B91BC1,
	Foldout_ValidateValue_m6045DAD80CC3A35442EA2E881AFEDB6BBF184548,
	Foldout_SetValue_m9C7EA58B4CD8DB13304A7F2E23A40CEDA2A1DD7B,
	HBox__ctor_m9AE6A2CE7C4A6163433B215CC2C99FAA1FDEF765,
	VBox__ctor_m8F876CB1E7BA14B53CF50B6F9F75D85F617179B5,
	Table__ctor_m2C4DA9603E5F18A6A8B9E7B590A88A6319E0D5B5,
	Table_SetColumnVisibility_m7BA5263B7234028B87709E33DF273063EF99BEAA,
	Table_GetColumnVisibility_mC3485D2148D3BA1D0E9699228A03577D0BB9A935,
	Table_get_VisibleColumns_m8E0E5070482E68F4F6C1B01AE62F0B36745ECF65,
	Table_OnItemAdded_m631366817C2BAD7FAC37F6592629C7535FB01923,
	Table_OnItemRemoved_m38C900B0E73D188AD6517F741241B7DD921F8433,
	Row__ctor_m67B21E4FEDB0B9C6A9F75055E37480BFA3681DBE,
	Widget_get_panel_m4F078DFA48956864635ECE730C8D8EECBD833536,
	Widget_set_panel_m5D546A0D88061CFADD8C5857F779D6D23E93B187,
	Widget_get_parent_m2A53945D87CC26A262E6C6833795DE7C1E2646D4,
	Widget_set_parent_mE73484D4C5B6E8BFF7A4702E9833295128858529,
	Widget_get_flags_mEB9026DBB54AF2A1941D478C9A393BBCF958573D,
	Widget_set_flags_m650616AFB473FC82D7B9F85D805317E0B9F6ABCD,
	Widget_get_displayName_m1E7836A53BF88619C4815EA70F9243319567F0F4,
	Widget_set_displayName_mDCBDC31DD3A041E03DFA4BEA8FCA2A428F4ED921,
	Widget_get_tooltip_m36AB147BF4618674BD7F3CA0E70FFEF33E0EB463,
	Widget_set_tooltip_m87968E949EAD82E82438D33EAB241C6B8352C37B,
	Widget_get_queryPath_mB3729532CECC96E1EC3F3D8BF51ABA50BAEA84C9,
	Widget_set_queryPath_m9F3323420B75D42329C83F09359E9ED3F90E5DC9,
	Widget_get_isEditorOnly_m06E01DE2267BB52DB8C4E52ED2EBBF8DC9EE05AE,
	Widget_get_isRuntimeOnly_mDA9928932296862108B0CE5E897423F70DD4857A,
	Widget_get_isInactiveInEditor_m3C48D7CD02ED7B7365FE1F86888DE649D23AAA3E,
	Widget_get_isHidden_m16EEAA4800FE8ADD122631636B01FBEFBFA95DAB,
	Widget_GenerateQueryPath_m40520357FEDFC20D4B6905A9C93D20478362C49A,
	Widget_GetHashCode_mCD0D23D37EF54C79160861F227F27821C5F0F504,
	Widget_set_nameAndTooltip_m6A2AA733173D30AA828D74FAB162ECBCECC7A80A,
	Widget__ctor_m376F53A5E652F839D704FE6F6A447C11FA669C66,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	Button_get_action_m5796CC1DF3A5C10D2538EA5ACF4EEF0DF68DFB13,
	Button_set_action_m5F7843835E47500A6D3A0BFD268F451854D767A7,
	Button__ctor_mA34758B11D4DE127E0B126C0D43A656D4D2837DC,
	Value_get_getter_mBB5B000F4470481A61A298E2CD13DF4CBD70B23E,
	Value_set_getter_m2184497927F2C23CEB0CCF47480D886AE5237EC4,
	Value__ctor_mA90FCDCAC383495356834BFCE0EE2B589B51E07F,
	Value_GetValue_mD32191C4552B9FB57F0C048785854DBF320C9BAF,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	BoolField__ctor_m8C1D78E29A30C2D3844607274207943D3B576E55,
	HistoryBoolField_get_historyGetter_m4D7567A18F6A433A3ECE3573D6D875EC02A3963E,
	HistoryBoolField_set_historyGetter_m0C1E8D18F182E0BA08169A7A20CA1170D7B3E24F,
	HistoryBoolField_get_historyDepth_m33199CA7A24CD1696636A032118D3513CDFC63A5,
	HistoryBoolField_GetHistoryValue_m2C22B47DFF7BC9E386761F54139D8DF9D7B40553,
	HistoryBoolField__ctor_m89E7099F44F88D25D35AB246DF2CA64B22EB9031,
	IntField_ValidateValue_mB3697EE56E5842C8AEA5C02A32684FC0FD95704C,
	IntField__ctor_m01170A091DE36EB6E36BD4988B04FC83CE07BA25,
	UIntField_ValidateValue_m740E8ACC04DAE68BEC4C5A6C3C752611D607272B,
	UIntField__ctor_m2E4B33E952E8A77180C23014DA305B229EA47ED4,
	FloatField_ValidateValue_m23A7FA0907187975ADA4E7B132AC8823C47554CC,
	FloatField__ctor_m7F65D8D59BFF5ADB91AA09D8FE3EF063BCF90BD9,
	EnumUtility_MakeEnumNames_m418CDBDE0BCAFBC3CB15C5DA60157A89763BD140,
	EnumUtility_MakeEnumValues_mFBDB118AAE172BD2C7309F31AEAE8EFFA1875E5A,
	U3CU3Ec__cctor_m450E821002529B4EDC2B709FBD406FCF1734E634,
	U3CU3Ec__ctor_m5BF6A81593EC440E9C45B6A8C387ABF988A0CE36,
	U3CU3Ec_U3CMakeEnumNamesU3Eb__0_0_m600F94EEF3D8B7E95561610E9CFC56B456982A33,
	EnumField_get_getIndex_m9D3DADB71BE92C1B54FD5315B8C06BA2D68EE3FD,
	EnumField_set_getIndex_m1353057A317788EE0157D6559E7EB7178D08C62B,
	EnumField_get_setIndex_m72B40AFF93BCB6A72148E36EB14C98F3948C1922,
	EnumField_set_setIndex_m5C3DF9F1331972A5B1DA0F62664530BA86344F3D,
	EnumField_get_currentIndex_m4D47B593DC586CC3A0806A2987F6464718876802,
	EnumField_set_currentIndex_mEB5CA5FE86F8F8F9E2CFD3F08EA06DBC0E794FA7,
	EnumField_set_autoEnum_m22B1BF1EE22FF469D5B6B47EB893C80883D0AEDB,
	EnumField_InitQuickSeparators_m819096798D533BAFC6541EFCDB7B9DAE8B078D1E,
	EnumField_InitIndexes_m5A00CA7100887328361759AF12502AC803E57472,
	EnumField__ctor_m70AF15D32AC334B12E512298AAE02ED438074C78,
	U3CU3Ec__cctor_m9B6DE1A47D1E97C85A4AF4389CB1C242A8414193,
	U3CU3Ec__ctor_mB8A8520B3A180E74A7D93029922E79D6AD8C0130,
	U3CU3Ec_U3CInitQuickSeparatorsU3Eb__17_0_mFFD8CE9ED1EB00ADCDFE046DF8FF00FAC4C484F4,
	HistoryEnumField_get_historyIndexGetter_mFE380F5C43EFC29095547306FDF1E61C87D41C1C,
	HistoryEnumField_set_historyIndexGetter_m32A0FC4FDB681E1F0B7C5EB11FC021A695FCA74F,
	HistoryEnumField_get_historyDepth_mD38724219D2D4B9D17E5F5799DA96AD674CCC5E7,
	HistoryEnumField_GetHistoryValue_m1E43C624459622E5963762488452C94839CD738C,
	HistoryEnumField__ctor_m2E1B5EC38B24CF0E32ECF85FCC65A34279B24611,
	BitField_get_enumNames_m3518C9A0F352E7390CABA60F16E5C2246F12634C,
	BitField_set_enumNames_m16DCD2AEC657E914F549F55710165EC906BF2E7B,
	BitField_get_enumValues_m5CBA7136A37EBDD8845BF4CE47261201601F9527,
	BitField_set_enumValues_m359E7A2117FA2BE7906B2995F44F0C07DE64A238,
	BitField_get_enumType_m579A37FEF96B7B00BD32858A935EB6BE21FC9203,
	BitField_set_enumType_mB03F8F62663EF345AAF5474BC3ED67B2A96F8FA1,
	BitField__ctor_m4A3D57F9714E4EF7E2DDE0F8342BD582AA2F304D,
	ColorField_ValidateValue_m8D28E0AF4B13D4A656B208C23863E6E790EC073B,
	ColorField__ctor_m65991BD71EF773F511DF30AFB0E49D31C7B8C639,
	Vector2Field__ctor_m1AF0C3B9D667CB0D78B5D5F46B721463B7890DF8,
	Vector3Field__ctor_mFB24C3F634E08686F2ABD472FC6125669ECC9F44,
	Vector4Field__ctor_m2BA663599F835828AC451E2D7E3847861FD70BF5,
	MessageBox__ctor_mF48843A6B29FCC39637EF3421D0C8789A2E40D52,
	Panel_get_flags_mBC1AB348B149288BC1ACD0D4E7162622829ECE05,
	Panel_set_flags_mF3DF84780500411054DCFA0D04A9D25BEE99BEB7,
	Panel_get_displayName_m186C10E927B2800035B328BD9A40D8B5FB3D4EE4,
	Panel_set_displayName_mE0DE5D17782E9980165F39D8CEC37169D3A8F0B7,
	Panel_get_groupIndex_m9BF4D7734CF4BDAB37EA115B037D349AC1883766,
	Panel_set_groupIndex_mFE863A99C9A0E2168E3E24171BBDFB7541E4E64C,
	Panel_get_queryPath_mF5E2D5B66591223DC7A17817CB8A881396066B4A,
	Panel_get_isEditorOnly_m739F502972100D4683F8ED121870319543957E41,
	Panel_get_isRuntimeOnly_m03FC70341EBC84633B6F0F93BFCC961A3470AAEE,
	Panel_get_isInactiveInEditor_m085DE5769EBB5B7F1B283FEF611E277ADDDBA506,
	Panel_get_editorForceUpdate_mDC9A26D9317C1DAD42A7A3F7034C0188A29E74B1,
	Panel_get_children_m42233087374A0F3438E9F666F0EBD00922D3018A,
	Panel_set_children_mADB01D395A7BFE1B9D5AC10A0D7B602D9EB7F478,
	Panel_add_onSetDirty_mF68B8AC37258A177F270E8FC7D9B63785E92E711,
	Panel_remove_onSetDirty_mDA42D481B964BFBEB6CAC9856AC23E1629F1E02D,
	Panel__ctor_m1FC7CE20C8B2968C68E3EE1CFD0410871B3F5F38,
	Panel_OnItemAdded_m7FB987D85562DF868A6FA6087CB22E6C71243F46,
	Panel_OnItemRemoved_m8CD7D1887101C65B50C3117C24FCDF315B7EAFBB,
	Panel_SetDirty_mEC30ADB4136D2F16BAF184FC412796F28B55AC4D,
	Panel_GetHashCode_m5800B9C2C3CB4EE3347ADAB98CEB0B1C83F1E4B5,
	Panel_System_IComparableU3CUnityEngine_Rendering_DebugUI_PanelU3E_CompareTo_mF038DBAAA67D742B672B5D64E465E2AB619E0864,
	U3CU3Ec__cctor_m505AF6CFBC7CF4B5249F542C508D1C3771B773EF,
	U3CU3Ec__ctor_mCF8306DAA9B0EB15D331C4D709E0CCCE53B0A88B,
	U3CU3Ec_U3C_ctorU3Eb__29_0_m2235200D857D434405F0663E3A1C60D70B41AA12,
	DebugUpdater_RuntimeInit_mE9ECE0BF0EC053B08D98E0A81AAD2C0440903FEB,
	DebugUpdater_SetEnabled_m22CFD48B212C8976E10FF2DDB0659634F12EC9B0,
	DebugUpdater_EnableRuntime_mD9C5BEB12354DE0B41E9F8783A8A71C351CA1B93,
	DebugUpdater_DisableRuntime_m63D549D0863E9A75230105107DF925E5DE3DEA23,
	DebugUpdater_HandleInternalEventSystemComponents_mF661FED6AFDD911D6B831E22B65CD951E8BC4857,
	DebugUpdater_EnsureExactlyOneEventSystem_m5C71D947DFE706B67482E788A3DABD428F7798E1,
	DebugUpdater_DoAfterInputModuleUpdated_mF2ED242089E69D65CAC0B9C7A49061C8928A613D,
	DebugUpdater_CheckInputModuleExists_m1AA5338341C5BB4AE1225AA027A71FE2C693AE93,
	DebugUpdater_AssignDefaultActions_m544E2B25C85619B9FA366E9C58581A31925ED19F,
	DebugUpdater_CreateDebugEventSystem_mBB31CEA4B7EC553A825B4E9BA4CCD323CB51EDD1,
	DebugUpdater_DestroyDebugEventSystem_m2FB857AD2F317E394C2B37DACBD5003676FD5E80,
	DebugUpdater_Update_m4532D8430DE77C9C424562D87951EE357A2D7309,
	DebugUpdater_RefreshRuntimeUINextFrame_mFE1601C324C104C743877F1B2A85535CE60B6F97,
	DebugUpdater__ctor_m4AFAADA0BCEA5FC94938222FCF2C69337E9AA201,
	U3CDoAfterInputModuleUpdatedU3Ed__9__ctor_m9B3F93DFFEBFF104648742F9BF158132E45B1612,
	U3CDoAfterInputModuleUpdatedU3Ed__9_System_IDisposable_Dispose_mF93A77F74A1C09D3CBCC8C28608778786B6E1ED3,
	U3CDoAfterInputModuleUpdatedU3Ed__9_MoveNext_m9537B7DEABD35246EF3E28B5106FB39C6AA6D9FB,
	U3CDoAfterInputModuleUpdatedU3Ed__9_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m3BAAAB9476FF83F7F100545FAEAB28C2F1D61A0D,
	U3CDoAfterInputModuleUpdatedU3Ed__9_System_Collections_IEnumerator_Reset_m29D4EFEB3935C7DB1709DC54313B4CDF38E5897D,
	U3CDoAfterInputModuleUpdatedU3Ed__9_System_Collections_IEnumerator_get_Current_m1C1CB4846785E48662EA676E9CABEB9BCC0811D7,
	U3CRefreshRuntimeUINextFrameU3Ed__15__ctor_m392779311BA7871677A153BC788AE3F7C1E7D9DC,
	U3CRefreshRuntimeUINextFrameU3Ed__15_System_IDisposable_Dispose_m9803ADFEEF942AC22E3361820FD2894B83A80E82,
	U3CRefreshRuntimeUINextFrameU3Ed__15_MoveNext_mF9483E416C04EC5609F48B6161DB805C43945C22,
	U3CRefreshRuntimeUINextFrameU3Ed__15_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m05F5EAA27086EFF2214F25E8D4835C9597ECA1A6,
	U3CRefreshRuntimeUINextFrameU3Ed__15_System_Collections_IEnumerator_Reset_m3C7EBC0FA8D19456E8BF377495712E73FD485C72,
	U3CRefreshRuntimeUINextFrameU3Ed__15_System_Collections_IEnumerator_get_Current_m22BFE8E553B29C84902F0D132AD6B09C37EE6D04,
	MousePositionDebug_get_instance_mE1A381321E1FE73292165B66BF148F06A077F714,
	MousePositionDebug_Build_m171C70914DA1EF2CE398B02A8BF4CA644B74CA56,
	MousePositionDebug_Cleanup_mDE40091BD5CCE74B9207B53D3924CE29CB2A155E,
	MousePositionDebug_GetMousePosition_m705459C449B28534CD4F3826EB2802094E9ECE9C,
	MousePositionDebug_GetInputMousePosition_m3B9FAF39E8413360371CA6EFEED7B12A025F45B1,
	MousePositionDebug_GetMouseClickPosition_m2C1BEF32DA9D79DA3DE85B0C433FC496F14D17AA,
	MousePositionDebug__ctor_m13F1294D652C43F3F1EEC88EB42D66CC51C31DF7,
	NULL,
	NULL,
	NULL,
	ProfilingSampler__ctor_m26500989FCDB07FA33C9A3BB7F215CBD892F5BB7,
	ProfilingSampler_Begin_m8DA3A616057A3BF9ACB1B0CA553273D5CAD9D19B,
	ProfilingSampler_End_mE6456852B82D64D57CDE20BBE06801295CEE5EAE,
	ProfilingSampler_IsValid_mD25EC5C484B753F1C433BACC5DDEECAF80A0EC16,
	ProfilingSampler_get_sampler_m4AAA7119F8B751DC79115DDEF85028FE9E9E8CC9,
	ProfilingSampler_set_sampler_m4BD874D506A5D40A126E01CBE77F6CB1015DDE44,
	ProfilingSampler_get_inlineSampler_mAD22E30685E56EA9768E9D0F6A0D451E32EE8A57,
	ProfilingSampler_set_inlineSampler_m4AC1C19296D4282D6BC4D6C09C641A1EB1145E16,
	ProfilingSampler_get_name_mF1C3E7B9540171DD93186A4DFEF33CE331E92D79,
	ProfilingSampler_set_name_mAEA13BE687F2E8C6698F3FB3A95570A156705FA5,
	ProfilingSampler_set_enableRecording_m01194E5D273026495629CE911861C31C5FB3A26E,
	ProfilingSampler_get_gpuElapsedTime_mC131D418300561A18825784CEE89BAFB3DDE32C8,
	ProfilingSampler_get_gpuSampleCount_m3EBB12146263C4956AB0E4FE1518537FFB3F1CB0,
	ProfilingSampler_get_cpuElapsedTime_m9C3D1C60EED6B27CE71D2A7DB94D496C2F1B328D,
	ProfilingSampler_get_cpuSampleCount_m9C8E94E3CC7AD93B8FD62EBC74E8581A493DA5F3,
	ProfilingSampler_get_inlineCpuElapsedTime_mB4D305E36C2A8EF55F9BFF30747885C10051738B,
	ProfilingSampler_get_inlineCpuSampleCount_m91CB819CD0B6576451BF2DE3749D58DB863D00A0,
	ProfilingSampler__ctor_m7CE99F43293A5072467EAC1BC37CF4C335D1C2B2,
	ProfilingScope__ctor_mE15813DF7651C1A3B6AFD6465AD4B973E8F1DBFC,
	ProfilingScope_Dispose_m4231A2ACA1F8E345BB0078310A9F7601704C8BE4,
	ProfilingSample__ctor_m1F041AA9D15F1B83BDA8B9BA973392D79106B5C1,
	ProfilingSample__ctor_m281FEAFD2CCCF7A43BE856DAD483F4E46A72B7EA,
	ProfilingSample__ctor_m50B1BED1079C106B8AE90117F4E866912C3C4E08,
	ProfilingSample_Dispose_mD2A4D24A23C63449743B485DEAE2DE4EE240AA40,
	ProfilingSample_Dispose_m59C08E493C70FAD0777836566F3FCF8A2889E388,
	CoreRPHelpURLAttribute__ctor_m91B7762A727A0FDC2F10AB2EC6F0225A7A864ED1,
	DocumentationInfo_get_version_m970EBEC012AB14B795AD5960A51D59B4B0FEF512,
	DocumentationInfo_GetPageLink_mF1CA29477559EA4935033E1323CC89A076175542,
	DocumentationInfo__ctor_mC0375CEF54C6DF14F9288C2AAAC03FAAF3D98479,
	NULL,
	SphericalHarmonicsL1_op_Addition_m5F486BF8573D468A1DEDEF671F3895ACFE0C596F,
	SphericalHarmonicsL1_op_Subtraction_m7ADE2737A8BB55042ADCFC9E55EDA00B75CCD465,
	SphericalHarmonicsL1_op_Multiply_m50C506E2EF86ADB3B7F47C7ADAE02E59754C2733,
	SphericalHarmonicsL1_op_Division_m5EE01F366EC68943C0B07A8FE686DD7E103B0FD0,
	SphericalHarmonicsL1_op_Equality_mACA5CAF29BEDC46B2E445F4499DE00D9743D3245,
	SphericalHarmonicsL1_op_Inequality_m96D5AF57F6F2B80C53F6B314341CCB7F919C6DF9,
	SphericalHarmonicsL1_Equals_m156AFF698A92A9425070CFD50F115A1EE6E9CC92,
	SphericalHarmonicsL1_GetHashCode_mF419FC901C4CF663FCC3E728A7E7BFC7F9DBB5FA,
	SphericalHarmonicsL1__cctor_m0D79C7945F00392859C7A8184A62AC603985A823,
	SphericalHarmonicsL2Utils_GetL1_m996A93044CB40B805DA29C46203E849F2415CE57,
	SphericalHarmonicsL2Utils_GetL2_m3F022EAA5269D2DDA53C8F6975972B945FD209A5,
	SphericalHarmonicsL2Utils_SetL0_m11A2C58FB9BF1A7A2DAB6BCB5CE756D555591DFE,
	SphericalHarmonicsL2Utils_SetL1R_mD1DA154FE693258849DCB4162A09FC13B62745A2,
	SphericalHarmonicsL2Utils_SetL1G_m9480BF709817944C26A64EC7FB38E63E82FBEA5F,
	SphericalHarmonicsL2Utils_SetL1B_m24C03DBE20D4E95161AB03D2C4F8CEBF43953A7F,
	SphericalHarmonicsL2Utils_SetL1_mCD888269417194982CC42CA10501A814DB9F7149,
	SphericalHarmonicsL2Utils_SetCoefficient_m73011A91C2FA8DA04A45BD0643A04C569BCA10A9,
	SphericalHarmonicsL2Utils_GetCoefficient_m5B60C04680078BB5E0469EBFD8563C1B7FBD1DD9,
	SphericalHarmonicsL2Utils__ctor_mCA9870FBB489F77FBE19972A417C82C6667FFA15,
	LensFlareCommonSRP__ctor_mEAF401FE46DBA464540579E301B041E379D61B22,
	LensFlareCommonSRP_Initialize_m2C0C7F50EC74E06BA4747A0C633B4EDA43567358,
	LensFlareCommonSRP_Dispose_mA062D9CB882801065E15BAB85A2B8F4C7884867B,
	LensFlareCommonSRP_get_Instance_m9AF4EBE53C341469863DC601A5E7A9AE9C231189,
	LensFlareCommonSRP_get_Data_m8F84F362041F41CF248027CFA39F4E9DFB3EAC06,
	LensFlareCommonSRP_GetData_m26A28FEF8B7E0EE038B730DAB917BC9DE1D1D558,
	LensFlareCommonSRP_IsEmpty_m10C9D536E29439EA829486AA85748609DD7106E0,
	LensFlareCommonSRP_AddData_m1E33BD73205092DB2D140BAAC48383303BCBCA72,
	LensFlareCommonSRP_ShapeAttenuationPointLight_mA80238D6D566E980ED1AE255C9BC91022182D2DE,
	LensFlareCommonSRP_ShapeAttenuationDirLight_mB2D51F3B3CC80632ECC96578C1ADB468E2B9E621,
	LensFlareCommonSRP_ShapeAttenuationSpotConeLight_mDE84D26A73023F57D52694A3F8FB6E0B0FB8D138,
	LensFlareCommonSRP_ShapeAttenuationSpotBoxLight_m0412849BF84760934EC681464147178B703E4ED6,
	LensFlareCommonSRP_ShapeAttenuationSpotPyramidLight_m5B302D458B7A118CC682CCE543AA243F1FFBA890,
	LensFlareCommonSRP_ShapeAttenuationAreaTubeLight_mEC46B3A21A0115238359F9BEE31788358583AC1C,
	LensFlareCommonSRP_ShapeAttenuationAreaRectangleLight_mEE72D39B39610E683AD08EC8D6FAF5883E2A36AB,
	LensFlareCommonSRP_ShapeAttenuationAreaDiscLight_mD1747903D295EA95BB061DDA50E6B633F53A5424,
	LensFlareCommonSRP_GetFlareData0_m3D5800DB9EAECD5F0A62A6C3A62221814D4982E9,
	LensFlareCommonSRP_GetLensFlareRayOffset_mA8F7249988B5FFE3D2C74C47E66B3862C3B466D6,
	LensFlareCommonSRP_WorldToViewport_m1AA44B97222A147F54DCE7A95971BF40704487F3,
	LensFlareCommonSRP_WorldToViewportLocal_mF91FE2957795C2DB2593CF5AFF8768B421964232,
	LensFlareCommonSRP_WorldToViewportDistance_m9B26177784C80BA0FB59511F7EE8736E15FB1C71,
	LensFlareCommonSRP_ComputeOcclusion_m5FA6E2E6E5020732F0E5D61FD4E05557158FD7B9,
	LensFlareCommonSRP_DoLensFlareDataDrivenCommon_m15611A3C8EC2005E50C2BD5807A996728E27A65E,
	LensFlareCommonSRP_RemoveData_mF536B8F2F609777F96539159F65750991FE6D8A0,
	LensFlareCommonSRP_DoPaniniProjection_m306992D05CE71F2D3F98143B474762546BF8525E,
	LensFlareCommonSRP_CalcViewExtents_m8F849C7464F2A4252DB86C3F3A33C524F66B50A6,
	LensFlareCommonSRP_CalcCropExtents_mFB9F1FC91183E81078841CBF760463D3889D3925,
	LensFlareCommonSRP_Panini_Generic_Inv_mECEC29B887B4DC66F5DCD50B45FD9A30DE20181F,
	LensFlareCommonSRP__cctor_m098DAAB846459CEED4F03FE6698FF475532BB9AD,
	LensFlareCommonSRP_U3CShapeAttenuationAreaTubeLightU3Eg__FpoU7C23_0_m8A7A75AE0D73CAF8585BE2774094A6F2449A0088,
	LensFlareCommonSRP_U3CShapeAttenuationAreaTubeLightU3Eg__FwtU7C23_1_m789ACC5B16B32A7FA68CEA3B0ACB5DA482197197,
	LensFlareCommonSRP_U3CShapeAttenuationAreaTubeLightU3Eg__DiffLineIntegralU7C23_2_mE0C2F76A88F491B61F98C5994240C874F54E9997,
	LensFlareCommonSRP_U3CDoLensFlareDataDrivenCommonU3Eg__ComputeLocalSizeU7C32_0_m26D2BDCCD0FE073947287DBA271E48E8912CC909,
	LensFlareCommonSRP_U3CDoLensFlareDataDrivenCommonU3Eg__RandomRangeU7C32_1_m60A9634C5D096A623DB6D7508F6AB7EA9CCD302B,
	LensFlareComponentSRP_get_lensFlareData_mD15D77ED234DE0AD076724C2F1D1826EE6D3D84A,
	LensFlareComponentSRP_set_lensFlareData_m2EA3F72CD785C3464763CC5C1214D104AA8C840E,
	LensFlareComponentSRP_celestialProjectedOcclusionRadius_m1EAD56AEC83ED782CE84396FF60912005858C29B,
	LensFlareComponentSRP_OnEnable_m8840399D23CFE3D4C2FE087BAE4A9E58C2375BE9,
	LensFlareComponentSRP_OnDisable_m3421F76197A6F10ED85B61016C4D9B659AF5B27D,
	LensFlareComponentSRP_OnValidate_mA7680090242F1F5D050BC08834871FB2A0E6D43E,
	LensFlareComponentSRP__ctor_mAC637A807D761F7EA8739EE110836C95C8769C83,
	LensFlareComponentSRP__cctor_m1310FC4E69925FE59E0BA3E5CBD41482740073B5,
	LensFlareDataElementSRP__ctor_mBAD9141DFEFB54D462184CC163B5EDE17D91E736,
	LensFlareDataElementSRP_get_localIntensity_mA75A27674D36D591A42CACEC76E206D41DFD9925,
	LensFlareDataElementSRP_set_localIntensity_mE3E298E1A798F39C5D79D37C6E012B63C10E5E71,
	LensFlareDataElementSRP_get_count_mA7F9CBD150771F1D7B9CBF6896E8E5EF1AA72AA0,
	LensFlareDataElementSRP_set_count_mC7D8BD5067BD13DBC60233CD7F659F8531D42A0C,
	LensFlareDataElementSRP_get_intensityVariation_m698B70DFBB0B3F60AD954A228368C4E1CC92C90A,
	LensFlareDataElementSRP_set_intensityVariation_m4D80F38F0B0B5C65B21253D20FA6EACD9FC7D1B2,
	LensFlareDataElementSRP_get_fallOff_m15C09E622D6F8DC6CE7853C80A4B87E1B4541CAB,
	LensFlareDataElementSRP_set_fallOff_m7BB44EB218C09DAB803C404AB5138304F95BB474,
	LensFlareDataElementSRP_get_edgeOffset_m75804ACFA229921032474232E75DCD6E9D04DBC2,
	LensFlareDataElementSRP_set_edgeOffset_mCC9746DA5549D79D48019976CE66DFCB3DC4D987,
	LensFlareDataElementSRP_get_sideCount_m7A462121BBCDD3AAA321F9E20680E2B7065787B2,
	LensFlareDataElementSRP_set_sideCount_m8B3FFCDDBE8EA14DA4887438D141A5F79361739B,
	LensFlareDataElementSRP_get_sdfRoundness_mADCDDD25BDE1929B411DE5244C7B1DCAB3503C6E,
	LensFlareDataElementSRP_set_sdfRoundness_mACF3E40FBABFB46CFA587360F0D3961FBB794CDF,
	LensFlareDataSRP__ctor_mD056E210281E4D1D2FCE4C9D6434983F5F9BFC4C,
	RenderPipelineResources_get_packagePath_m5A693106B4748B9E81C3D5C97434A02214DB0C85,
	RenderPipelineResources_get_packagePath_Internal_m95E3708613D98333C168871F7C0FAD9446E66353,
	RenderPipelineResources__ctor_mC03CFC933E25CDB1425A92A3C1C7770E02AD7040,
	GenerateHLSL__ctor_m2A39DDA94C13C40EF4CDD7C921E543F629C03F9C,
	SurfaceDataAttributes__ctor_m81636716B07F8C34BCAD27685E93082567BD8783,
	SurfaceDataAttributes__ctor_mE30568FE5BDB8713FDA54DE93AA8A044BE06705A,
	HLSLArray__ctor_m331EBC11A2168F124C98463BF17B936B53BDE55F,
	PackingAttribute__ctor_mA147203C5536B59467723309207F1410900BE107,
	PackingAttribute__ctor_mA2F647F8B256EE9087B498C9BFA015CDB023FA2A,
	BufferedRTHandleSystem_get_maxWidth_mFE6683CEA6FBCFE1C7A2C75F5C697500CDF2F491,
	BufferedRTHandleSystem_get_maxHeight_m4D7141C2C2DDD8C719D9675AABAC387FC1267CED,
	BufferedRTHandleSystem_get_rtHandleProperties_m25518D71F21AFDD266F9B72C4CC4FD372C31B503,
	BufferedRTHandleSystem_GetFrameRT_mEBD3C29BC51816416974BA1B541C668937F26BF6,
	BufferedRTHandleSystem_AllocBuffer_m8A3358B612C23D990A6EF1E7F2CCC10341EFF325,
	BufferedRTHandleSystem_ReleaseBuffer_m34658D840B28AAB95C2E6A2DABFE4B0FA24BB39C,
	BufferedRTHandleSystem_SwapAndSetReferenceSize_m4305B697B3B3F39A12A784ED9413E29E53512727,
	BufferedRTHandleSystem_ResetReferenceSize_mBAFD03AE10BFFD8DC36AD6F58F05A18EA6C6FCC2,
	BufferedRTHandleSystem_GetNumFramesAllocated_m95809130420FD80593A4F447BE45D03911BCDDD2,
	BufferedRTHandleSystem_CalculateRatioAgainstMaxSize_m8769859F9AF74D5A880A3F487B1A3CC5B773F159,
	BufferedRTHandleSystem_Swap_mFE273AD95CFEAA6D51A4B0BAE50C0E1FFFA05C0A,
	BufferedRTHandleSystem_Dispose_m6DFE7909B7A0C05BE90AF19310E7805B1AAC1759,
	BufferedRTHandleSystem_Dispose_m70E0C163A96627D5DB2AC28338B0FAF30E8EB877,
	BufferedRTHandleSystem_ReleaseAll_m46A33E64928C17336C64D97305A2306BA9B8EFBC,
	BufferedRTHandleSystem__ctor_m68CD894EC8EC25ED3B8556A48CE799C0802914DA,
	PowerOfTwoTextureAtlas__ctor_mA0B1F657FD0560F53AF17A6F29D6BBE9C8C1A5BB,
	PowerOfTwoTextureAtlas_get_mipPadding_m5B9D6FB4248DD41F9AA9E5469C1A6CC12524496D,
	PowerOfTwoTextureAtlas_GetTexturePadding_m85D96D2F38E1B383B35E6161A577AB6B99C67166,
	PowerOfTwoTextureAtlas_GetPayloadScaleOffset_m8B1202020D137DA5FF0966E5CA18D2C6B13338BA,
	PowerOfTwoTextureAtlas_GetPayloadScaleOffset_m96EA6B589B297199A2F1A008B38AD6A4D5891AF6,
	PowerOfTwoTextureAtlas_Blit2DTexture_m318B160A16693053884CEBD03FE20510B285B86B,
	PowerOfTwoTextureAtlas_BlitTexture_m5D070F026EBC4EFEB0F7D432498746EA01A5BBF1,
	PowerOfTwoTextureAtlas_BlitTextureMultiply_mE63DAA75351A7587B55F23FE473A33255C6D1119,
	PowerOfTwoTextureAtlas_BlitOctahedralTexture_m1A14B3C794CAB04AD3DB165F8746B69B36073265,
	PowerOfTwoTextureAtlas_BlitOctahedralTextureMultiply_m762414D0EC91F1779C3130DE072359A02CD867CB,
	PowerOfTwoTextureAtlas_TextureSizeToPowerOfTwo_m227399E874EE9189B6767F2BA8DC5B61DC6237B9,
	PowerOfTwoTextureAtlas_GetPowerOfTwoTextureSize_m2569249A9DA0FD0259C3228186A909760F26DA6E,
	PowerOfTwoTextureAtlas_AllocateTexture_m897D249DB1758DE2AF48415C7E5BA0686091A8FA,
	PowerOfTwoTextureAtlas_ResetRequestedTexture_mE1FE41E4A7EEFD4C850F748A9333433DD5F26C33,
	PowerOfTwoTextureAtlas_ReserveSpace_m11DE443FB8C4046ACC8455546F8D17AAA4A3FFF8,
	PowerOfTwoTextureAtlas_ReserveSpace_mF15C7D3DEA2B006D85379957930154BF99B04CB1,
	PowerOfTwoTextureAtlas_ReserveSpace_m5E24787C21582ED6A351622BBD4AE127DF4F7D4A,
	PowerOfTwoTextureAtlas_ReserveSpace_m4D01D2D4735A62E00AADD01588B9415A51AF81F9,
	PowerOfTwoTextureAtlas_RelayoutEntries_m18B76F49CB89789511930E82E1F1666E9CCFCD63,
	PowerOfTwoTextureAtlas_GetApproxCacheSizeInByte_m15BF98F2F213A3A0D8D52155F05802861A497692,
	PowerOfTwoTextureAtlas_GetMaxCacheSizeForWeightInByte_mFAF390882A513147A5C6CA70E173D23FE8239B4F,
	U3CU3Ec__cctor_mE3978E87892EA59FD00F94355B4308AE7053C33C,
	U3CU3Ec__ctor_m746D67A5F0BE4CBD77C47FAD733248ADA0C26151,
	U3CU3Ec_U3CRelayoutEntriesU3Eb__23_0_mBF9D0BC493979E1C4D66D031B8E12629A6AA208B,
	RTHandle_SetCustomHandleProperties_m7C67C8BCEC388761EDA27F86053551E909633F60,
	RTHandle_ClearCustomHandleProperties_m460228F7AA2778FBF2AB97234AEF056F74B7F8C6,
	RTHandle_get_scaleFactor_mD00E924FBC4B2DC2C9E26D7B24444BDAA6DC5C65,
	RTHandle_set_scaleFactor_m1F6FFA3366846EFFB9F4EAC79F2FF4E00BE75C15,
	RTHandle_get_useScaling_mCDB079A62CC15C0D0F47E3F49D5975202F7B12A1,
	RTHandle_set_useScaling_m273446564E3B4FB3919F7C5FC01570029CF6A93A,
	RTHandle_get_referenceSize_mC92CF605112BBE2C0733AB1E4A9C42B760DCB34B,
	RTHandle_set_referenceSize_mE98B5ED69CDC2C37769532B55D8ED2BA84C84466,
	RTHandle_get_rtHandleProperties_mDD6241F72089E7DCED00F386D771140C9D9BB38D,
	RTHandle_get_rt_m593F2799E2E6C97979D3B4CD9E992D305922BBE9,
	RTHandle_get_nameID_m30AF2567853494DB845D83A8B37D0FB523DA76E9,
	RTHandle_get_name_mF2E7B6B108477C76931BD1E5798BB1DA1F036B7A,
	RTHandle_get_isMSAAEnabled_mB56F4775BF4FC50DFBAC344DB1DA4C4B91197A9D,
	RTHandle__ctor_m4B1E60CEC17FB96DC08DE007B11042985DB8E33E,
	RTHandle_op_Implicit_m7E42D3EE8A152420027F24913FAC50D9FECECE6A,
	RTHandle_op_Implicit_m4F275BDD5E7B189BAD0F9081A056D9433A8B583E,
	RTHandle_op_Implicit_mCC1B19A781896CDB078D13C11EEE78B27522C0FD,
	RTHandle_SetRenderTexture_m8325131A37B623C614BE55AF2DE2A29856881F01,
	RTHandle_SetTexture_m6F70C921091D39C7377853D6F5045720A6CE49DF,
	RTHandle_SetTexture_m3C2728178516E7C86C52BF75EC7303CFDE68CDC6,
	RTHandle_GetInstanceID_m03B8397D7EADA4B68CDA99A76334A359D238F33F,
	RTHandle_Release_m743C2A22FD95D177D2D425E9DF1F3088161F387B,
	RTHandle_GetScaledSize_m58D71FF94244F1EE9BCB5690381DB37C79D3E239,
	RTHandle_GetScaledSize_m35984A8A409FE26648E1B7011E9ADEEA9FEC739A,
	RTHandle_SwitchToFastMemory_m88468F9FF42F96F5192DFE57669B36724AD9C22D,
	RTHandle_CopyToFastMemory_mAA75EED26C2206B2D8AAF7AED837FD85801A494F,
	RTHandle_SwitchOutFastMemory_mA8413E99B8826F54BFD97AAAE2BAC75E2D69AFF9,
	RTHandles_get_maxWidth_m39BB3E11C325F26EEB144C8E24E5716C122ADCBB,
	RTHandles_get_maxHeight_mC990063E8472D492D472969121285DEFE5A450B5,
	RTHandles_get_rtHandleProperties_m8F0C48F9154BFFC0C777E6AF0A1DC9F3173763C1,
	RTHandles_Alloc_m95E0AEEEC5E86C190497A80E0471C65645D8C976,
	RTHandles_Alloc_m1F296572CCE89C51BFD3F944EAE0386E8527BB5B,
	RTHandles_Alloc_m3C30230CC2A85D214A28EE01E558AFC41FB08643,
	RTHandles_Alloc_m6C29C447A6F154094BCEDB69E1B874406414095B,
	RTHandles_Alloc_mFBEA34A4FF2FCF73283FB525C5A38E808C337F33,
	RTHandles_Alloc_m98465B24502DA2755CBD4C633FE72328AE3025B0,
	RTHandles_Alloc_m2C487A65E4C1C2F343126C90A2895E5EC5E0179B,
	RTHandles_Alloc_m5180F8A2883D67E6C5BFCBAA64D415D9F19B442C,
	RTHandles_Initialize_mA238921491B562B8CF8A74ED67795E547B9BFA60,
	RTHandles_Release_m30F0805D0D28A1EA1C0A661E31E6A0F1B8D26EE4,
	RTHandles_SetHardwareDynamicResolutionState_m6AE512F7F24DCFD4F60A19C68E64AD1E9CAD0D81,
	RTHandles_SetReferenceSize_mC312D1638CE3D65FF7D9D6BFE64071DBB83E2C38,
	RTHandles_ResetReferenceSize_m2637E767B3417745720D24C1C2941F6489D511C0,
	RTHandles_CalculateRatioAgainstMaxSize_m8515DA39B5F0E24B244B1AC06AD618AB2D60CA20,
	RTHandles__cctor_m355F705EBF7266A5F234A28E505FDE729C74957A,
	ScaleFunc__ctor_m7A304854DDD63F0FF414903BC5B30E201F8DA274,
	ScaleFunc_Invoke_mA7E3B86BA222C817FBBA757306E2FACB14F35987,
	ScaleFunc_BeginInvoke_mD82C5E2D4D54D3B9227F56CF6D5BA5D9CC2D1C77,
	ScaleFunc_EndInvoke_m9E82174B1877772B74231E226E707ACB37476409,
	RTHandleSystem_get_rtHandleProperties_mDDD04BAD83D0BCF0047AD77D88E37C55E64DEF58,
	RTHandleSystem__ctor_m22DE6145F3938E359C1FF6A5834BC7B7F93F5022,
	RTHandleSystem_Dispose_mB2E8DC8BB5B7BEAD2EF14CAAE4DB4F39ED27D6DC,
	RTHandleSystem_Initialize_mA4B41213ACE5EABD7C8397780BFDCEA8847BE466,
	RTHandleSystem_Release_mBBF7B7611774D06D330FD609BBAAB3CF50B320EC,
	RTHandleSystem_Remove_m7172E9124FEFA41845AD5000EF50E2AD5F02F9AE,
	RTHandleSystem_ResetReferenceSize_m3D2804C653042B20B7D36E4D71BDCEABBAC25E51,
	RTHandleSystem_SetReferenceSize_m98A5DC18BAD37DA203641820D499F7B580DEA34C,
	RTHandleSystem_SetReferenceSize_m6C8D719235F158FC6AAF642165F8CE6DE1A727C4,
	RTHandleSystem_CalculateRatioAgainstMaxSize_mB33735DE03F6CBCD0F3A95D966B9D41854591A31,
	RTHandleSystem_SetHardwareDynamicResolutionState_mC81924D30922025B3BBCF3EA0B30FC860CAAE803,
	RTHandleSystem_SwitchResizeMode_mAF90A695546828FB285F35879E93C902702BB814,
	RTHandleSystem_DemandResize_m8928BEA538900C426875E38F2D616BC06D62CCAD,
	RTHandleSystem_GetMaxWidth_m0AE3E07285C0CAA906B0EBF879FDB5A916E43C43,
	RTHandleSystem_GetMaxHeight_mF753F115CBC21DF020B828C67164F203FB92AAE1,
	RTHandleSystem_Dispose_m6B61D081716B87F79D110A62C3E57696179F3A31,
	RTHandleSystem_Resize_mDBCE61412B84ECAFC4FD2B29C8AE012D427DA968,
	RTHandleSystem_Alloc_mC3E802DD2ADECF640BBBAF1511279735F34CAD28,
	RTHandleSystem_Alloc_m930D047EFBB716887CAA28AB1CD8A427CF92E7C7,
	RTHandleSystem_Alloc_m979E71B4FB5665A89BBF4E6316AF24311838944F,
	RTHandleSystem_AllocAutoSizedRenderTexture_m1A1A2B79B291035C0403BB3B8D8E68B151C40C6B,
	RTHandleSystem_Alloc_m6220A7F43011B0D3277FFBED674A310002DAB3EC,
	RTHandleSystem_Alloc_m8813228D1C9D34992E020DDD8956CDF9AF2A3665,
	RTHandleSystem_Alloc_m86DF1C13114BD43774CC6108930D2BC1FABAD5BF,
	RTHandleSystem_Alloc_m9325CFF23333D599F8BD6BA274CB435CFC8A5D58,
	RTHandleSystem_Alloc_mD9352D9C828335E70B063E1DE4CF57AFE8AEDBBE,
	RTHandleSystem_DumpRTInfo_m8F58815EE6F64F6782A27A76AB59CD756F862D31,
	AtlasAllocator__ctor_m5F1B4A78BD5489FCC8100F2D0AC721CC42272BEB,
	AtlasAllocator_Allocate_m4CAB1873DB9D4E4CC5C0CF6581E0B4AEFCED19C6,
	AtlasAllocator_Reset_mF10CD4D29A6CB93FAA43BDCA6680C87166E84989,
	AtlasNode_Allocate_m2BDA3A3172B54122AE5A862692103B7AEB5DA014,
	AtlasNode_Release_m6710C2233272E0EFEBD120970FA83453684D1BAA,
	AtlasNode__ctor_mB6D5CFB4511F82EBF3BB82CD666B0C2B3B2CC76B,
	U3CU3Ec__cctor_mD58A602DF54D9A856FC000844D1F689E0B3273C0,
	U3CU3Ec__ctor_m6DFD93D6692A1B46CDBCC2CCD89F031D086AD221,
	U3CU3Ec_U3C_ctorU3Eb__6_0_mEE6E87AE529F16564D6A203353BE0BF274FEED70,
	U3CU3Ec_U3C_ctorU3Eb__6_1_mCB0411FC9901BAFC4F1272C563E40879E9881F45,
	Texture2DAtlas_get_maxMipLevelPadding_m2F9C5CD50662D4374217BCB3571AB1BF919F761F,
	Texture2DAtlas_get_AtlasTexture_m7768401CB1687EDDACF3A103E476F2C217C69C8C,
	Texture2DAtlas__ctor_mB0FB5774A1037C4F0AE42B5255C966B64688B54A,
	Texture2DAtlas_Release_mE23245C71F1E00D6AE6C57DC61B3CEE8D5C7CC17,
	Texture2DAtlas_ResetAllocator_m5930577CC814DC28121C8678204D3566783FCDE7,
	Texture2DAtlas_ClearTarget_mDC234897D6E1A06F28E1A4DF6DE9E9FD98692BBA,
	Texture2DAtlas_GetTextureMipmapCount_mD097894ECA68A2E85D291B9CF7A156FEA9C5B7BF,
	Texture2DAtlas_Is2D_m0F89CF0AD3A0ED6A12C5036A922F97DBAF66B14F,
	Texture2DAtlas_IsSingleChannelBlit_m36A444AD8A5BECBF02CC38EB8C67EF34025BBF3E,
	Texture2DAtlas_Blit2DTexture_m70934965558F0FFAE19E97C84B527E94D044440B,
	Texture2DAtlas_MarkGPUTextureValid_mF402EAFB808A49DCAB232E44B400DA131481344A,
	Texture2DAtlas_MarkGPUTextureInvalid_m8EBA5CAADA72E99FAED3D20C6C49A1D1360564ED,
	Texture2DAtlas_BlitTexture_mB5ABFBE98460A97AE9B4DB0DBDF8A6A440C06DB1,
	Texture2DAtlas_BlitOctahedralTexture_mF1369305082B2D023FF45176A64D4E2ECD7094CE,
	Texture2DAtlas_BlitCubeTexture2D_m7314E241BE55A44A687A7DF69A838EB7830A0350,
	Texture2DAtlas_AllocateTexture_mF1FDB3F2BE25762FC61DEF882514E85D239649CA,
	Texture2DAtlas_AllocateTextureWithoutBlit_m6C78FBCE1123E73B2DC327E300A687BA2F38BFBA,
	Texture2DAtlas_AllocateTextureWithoutBlit_m458E981155A8758EB9D669306D61A01C3A892910,
	Texture2DAtlas_GetTextureHash_mF19A8BC40CD6B6681BBB3B5A3DA9FD113C708A1A,
	Texture2DAtlas_GetTextureID_mE87B21A6574D318E9E4C240DD80BBFBFB1E7963B,
	Texture2DAtlas_GetTextureID_mC3B186580F3138AC25F5FDA6016FF4435023CC29,
	Texture2DAtlas_IsCached_m26C4E0F45A65963FA56EAC22F40E76BD1353E426,
	Texture2DAtlas_IsCached_m7B54023CE1A4C8BFF99CB0E76A8240A4248B2556,
	Texture2DAtlas_IsCached_m4B4781C1DA4FF2E1F7E49F7358BF6EFEF629A57A,
	Texture2DAtlas_GetCachedTextureSize_m4C26C916F8599CD4FAEB2481EDEFC59709F5F8BD,
	Texture2DAtlas_NeedsUpdate_mC4400C203B33A8E349F55FEB32CDFDB5C70C9BB9,
	Texture2DAtlas_NeedsUpdate_m6906FEF78BC34F7246181C6F4EF208E6D095F2E7,
	Texture2DAtlas_AddTexture_m173ABA0D0F69CE3D63BBFBB57B39061813A5F928,
	Texture2DAtlas_UpdateTexture_mAA7E89665582543A3D34D2AF10F520DFF2E68DD9,
	Texture2DAtlas_UpdateTexture_mFDD2BDBB6B05E9BC03B132A9490D426C053ED6B2,
	Texture2DAtlas_EnsureTextureSlot_mA671255AC3FE44365706656DA6895E396C39CD2C,
	Texture2DAtlas__cctor_m91EE154122A88004E03425354202DE1EAD402797,
	AtlasAllocatorDynamic__ctor_mAAB00F112B923640812220262633F2B59C8B7BB4,
	AtlasAllocatorDynamic_Allocate_mCB0BE9CC01255B8019E1EB0AF10818F65C97A537,
	AtlasAllocatorDynamic_Release_m66405964817DEC615B19E29F831A741E60DAE537,
	AtlasAllocatorDynamic_Release_m8458B490232D8C3FFF90F84483B9E7C10400205D,
	AtlasAllocatorDynamic_DebugStringFromRoot_mB566719762843EF35C69990C48714428644B40AD,
	AtlasAllocatorDynamic_DebugStringFromNode_m5051017F1F7E5381DE412AFA6D3CB22EE1AC2423,
	AtlasNodePool__ctor_m22C2652C4D29136D79798422530C9A5D9E8CC69D,
	AtlasNodePool_Dispose_m655F49046B7605E8FCE3A1553C74C0386ED6D746,
	AtlasNodePool_Clear_mE8DEA3A08060A6BD5DB3767066D1543C0DD77984,
	AtlasNodePool_AtlasNodeCreate_mCB3CA729969FC4DC8787F4F1CB6AF136E20514DF,
	AtlasNodePool_AtlasNodeFree_m8439BC672727D5205BD768CCF3A26C3E924D53EF,
	AtlasNode__ctor_mFFF2DBE5F81BD41BFF58E221F82DA5D3EF3B8C05,
	AtlasNode_IsOccupied_m4DAB3793E66F89B97D1521DA6A639A0B16C8BEE1,
	AtlasNode_SetIsOccupied_mDE0F696F9119A0A840D300CFF9BFDC5844C37DEB,
	AtlasNode_ClearIsOccupied_m15C4CF7573BF45C8472AAE6C72D93496F69F74B6,
	AtlasNode_IsLeafNode_m026D9501AB6E24CF82AD67D96AD9B08F164F5925,
	AtlasNode_Allocate_mA96F58D6ED00C8AED33E570BD38FC508D11A3A07,
	AtlasNode_ReleaseChildren_m1B0112B1DD2DCFF5E204BE80B8F7C9BC91E7BB6B,
	AtlasNode_ReleaseAndMerge_mF3EA698E178F2042996A9C630D05723A4B3E11AF,
	AtlasNode_IsMergeNeeded_m70B87CDC5F874B42D73D0A5D889F7E86AD44A8AE,
	Texture2DAtlasDynamic_get_AtlasTexture_mAE927AA3791B87C4D51E202BE0245B5A83243B80,
	Texture2DAtlasDynamic__ctor_mC9820B0906E6000B52062287587B7DEBC56240BA,
	Texture2DAtlasDynamic__ctor_m336C4EA6736F484F44512865CD888655B552FCAB,
	Texture2DAtlasDynamic_Release_m1812DA4BB82F8D3D65B3F9CD51D4A66ED93E7F3E,
	Texture2DAtlasDynamic_ResetAllocator_m896AD6D2A4BC73A314AC6EF64136EC6A3A239CC5,
	Texture2DAtlasDynamic_AddTexture_mA2A1D2AED36157C9A0994953D4E4E4EC00D43D92,
	Texture2DAtlasDynamic_IsCached_m09E0FB48076CA53709A7E8296EDBD0A1C040A898,
	Texture2DAtlasDynamic_EnsureTextureSlot_mCE0B6C1445851861E89135B087000B8817CE21FF,
	Texture2DAtlasDynamic_ReleaseTextureSlot_m64D7A4CD2351FADA1AC1EB5C336B449D7E0C6845,
	TextureXR_set_maxViews_m372FF3225D53990EB6982ACD1096F613BDE69922,
	TextureXR_get_slices_m062BCCD9A0A99529F1EBF01068F87C12908FD260,
	TextureXR_get_useTexArray_m03D653E1B7E284DE7655BF617102C8D3CB47A77D,
	TextureXR_get_dimension_mF5451652AD01DE1A917D0C4078E4EBDD451A5AE5,
	TextureXR_GetBlackUIntTexture_m9F4F07C63375F1200E69DEF0C50B173354DBAF73,
	TextureXR_GetClearTexture_mF064CE808953BF4FAF6275FA37FC64FC6C32047A,
	TextureXR_GetMagentaTexture_m540F2F78494398B2CD2667B458CFEDB45357E626,
	TextureXR_GetBlackTexture_mC8BC117CF59ED27F57A66F0CA34758647098C46D,
	TextureXR_GetBlackTextureArray_m854E06ABA457E2C6BB7345BAC0E49C2477667967,
	TextureXR_GetBlackTexture3D_m8D80CB8404ED895D0A2D5E4B73B4FAA9689BF5C2,
	TextureXR_GetWhiteTexture_m6280FF7F2A9425E90DB30809B7067ADE05D7A9FB,
	TextureXR_Initialize_m3FBDB7039F1DA5958BD87DB420A3A495FD4D7E9B,
	TextureXR_CreateTexture2DArrayFromTexture2D_mE2D47790EDF8E296A4BD08D68A2EC845D533CD63,
	TextureXR_CreateBlackUIntTextureArray_m31C723201EE5836D79EAC9547B2717525E3B7A3D,
	TextureXR_CreateBlackUintTexture_mA6A75A180C5B5FBB68B8C8CD8C703E8C472C6F17,
	TextureXR_CreateBlackTexture3D_m70E166C61FADBE1D1F29A91FA821D89B17802F9F,
	TextureXR__cctor_mE878B10D1BF0795040F3EE53CA670752192BAA7F,
	NULL,
	ArrayExtensions_ResizeArray_m652C33E2C6CC635B812F158A1AA9FEB54E8F7488,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	BitArray8_get_capacity_mA3B76B8563ED73CE2ACAA6248BB1659EFE18EE01,
	BitArray8_get_allFalse_m90DB2959D94946C2EFE34547AD6E2B8F10168463,
	BitArray8_get_allTrue_m793F5AAF8F83DAB21C0308F738147A29FFF08451,
	BitArray8_get_humanizedData_mF2404C0DEFF15E9DA20FC99071CA3A5900F4E791,
	BitArray8_get_Item_m4A05F5141C4554B92AE97D5487224C7840EC4D53,
	BitArray8_set_Item_m547A700177E97C60883197FE03D3DD03CBDE5F08,
	BitArray8__ctor_m86747787EF4C4E385B761101DD9B40EF6174F69A,
	BitArray8__ctor_m831CBA0141A7161831057654C9363F50C0AF6151,
	BitArray8_op_OnesComplement_m74BED0A30CDF3A69F4EB66CF9BFE87F6A6047A4E,
	BitArray8_op_BitwiseOr_m3A5FAC9E1115587DE663A36FCE6B3E342E8C7EC4,
	BitArray8_op_BitwiseAnd_mA7AF39894148406CCDAA991F455582F36365FA9D,
	BitArray8_BitAnd_mB8BFBCC7ED08AE63C8DCD56F224FC2A887666536,
	BitArray8_BitOr_m18AF19D6C292BF095EDC795C3018099B3A8CD121,
	BitArray8_BitNot_mB1E3ADFBDB897ED040CE28C797CD868DE95B9B26,
	BitArray8_op_Equality_mC7A4D257AC7A3ED7FDDEB381DBF8F5C6971299A5,
	BitArray8_op_Inequality_m5E8187711DCF9A91EA8F3D662BA702A10EAECD74,
	BitArray8_Equals_m86ADBD06E76F1B28D197017F091F13F063B453EB,
	BitArray8_GetHashCode_m0226A2FAF19B61AEBC5CC60F87DC272CCCF20A77,
	BitArray16_get_capacity_mA5EE007A81C601C9A3552D8A504747CD6BBF5B9D,
	BitArray16_get_allFalse_mB74A351DF512549357B62F578F8745861E768BCA,
	BitArray16_get_allTrue_mA4CFAC20D5338EA36278D5762FEF1879DEF44298,
	BitArray16_get_humanizedData_m12F476DEF544F28CCD2579475DE167820BD88E87,
	BitArray16_get_Item_mCA32C50FD252F47DCBFD7262435245238430A180,
	BitArray16_set_Item_m9457F4B8745BC1C5285574EE23FDD05A4BA2F088,
	BitArray16__ctor_m4A508EBDA58B7006D1463EAE199114B2D2E1249C,
	BitArray16__ctor_m337D042A8EE2131DED83B273A8CC47843E17CBF6,
	BitArray16_op_OnesComplement_mE37C83AB8E876316835FBECBA1A1C5EF5979E814,
	BitArray16_op_BitwiseOr_m72716C6C58CCAB01CB72A57BB96DA350FBA57AFA,
	BitArray16_op_BitwiseAnd_m53F60BC19E6F05FA7072F201EF25FFF17FFEACB8,
	BitArray16_BitAnd_mD1AFD4C59ED599951E61A3E8BA716D5A3FFD04EC,
	BitArray16_BitOr_mD788B0B73A61E66973D6B4160729C868D5BE8B35,
	BitArray16_BitNot_m7FB6BD7B74C796E05A9E7BA6FFEF58F6F23F10BC,
	BitArray16_op_Equality_m112E0FEB5F1BFAAA410B9CD83DD34B34C9D4A9E6,
	BitArray16_op_Inequality_m2FE623FD7D66E837B410D60B8996121A4C8874CB,
	BitArray16_Equals_mD170A00318A901D23C1F17444D5022FF947586D2,
	BitArray16_GetHashCode_m018CAECA54A403343CE08C2F4225670FE5780E6D,
	BitArray32_get_capacity_m312BE2BAA06E75492376361E9299510314755AE5,
	BitArray32_get_allFalse_m01D83A39CE7D6FBDEA9D5E57044285FF55E8260F,
	BitArray32_get_allTrue_m9AA64C6C9B386B1806BD0A9F83113055AA0967EB,
	BitArray32_get_humanizedVersion_m56C96176FE170F18CEC3327A7D19E1A774325228,
	BitArray32_get_humanizedData_m38DE7DAE7EE5527EC6C6FDD518253031DFF2374F,
	BitArray32_get_Item_mC8CEDEAB87139CA781BADBD4FBB1E84930F19FFE,
	BitArray32_set_Item_m6248824F85F4FCD452DE48E6B714AEB52D07AF44,
	BitArray32__ctor_m0982C7BD4F185BA648120E2ADA794E7D778B995D,
	BitArray32__ctor_m410177CA4D679011D0A4653FC28A4B83B39A1EF1,
	BitArray32_BitAnd_m050354D3A87E2A90324EEB8AA7D1156A482E058A,
	BitArray32_BitOr_mFB1856DBA7D371F7C6C04FD475577C3A9E15D62F,
	BitArray32_BitNot_mA3731229D50D6F6F4ACB1B80EB1EBA5610C656E8,
	BitArray32_op_OnesComplement_m898623FAA720F5ECDC16B448A976CE40F53301DB,
	BitArray32_op_BitwiseOr_mDDA7BE99A4D5A25FE02467C8301740B60B9A4177,
	BitArray32_op_BitwiseAnd_m0B7FDD7E86B52E16FA45E774E64CFC26C745C1B9,
	BitArray32_op_Equality_m2BEFFBC78F7F63B1FEA0C6C9BBA636F7D89991FE,
	BitArray32_op_Inequality_m33D0A690929501F09D4EB423FBB7330BB5B240A8,
	BitArray32_Equals_mE94B4571565F0D7243127EB6070E76B8A958781C,
	BitArray32_GetHashCode_m918359D3BC8DF9C6F2BA72085B422BED8B7AA5EC,
	BitArray64_get_capacity_mE0D7937E14B27EFB5580F024329871EA9F6F61A9,
	BitArray64_get_allFalse_m066B324DA3D868A839C4C000E923D590D09FC40B,
	BitArray64_get_allTrue_mD2AA9BCA8BD30CEE7F6648362CA4493BC81318CF,
	BitArray64_get_humanizedData_m3D2C299930B49D326C92EE0B0BA574DFF3C74891,
	BitArray64_get_Item_m44EA8594329A57FA9400342251411BCE62B54453,
	BitArray64_set_Item_mDEB0D2418675CD4FEAA1CDBDDDEA70A5CD35E44D,
	BitArray64__ctor_m41D38225ACEAF7A0D4201AB8AE9F781CD736DA04,
	BitArray64__ctor_m8745536B9B0A03C956553C54B7F425604CF60E37,
	BitArray64_op_OnesComplement_m299275129C52E24E06DFF482EBFCA64C08042736,
	BitArray64_op_BitwiseOr_m861E7D4EC020CF3606364C4F65BEFBBD2C6F6C01,
	BitArray64_op_BitwiseAnd_mB51BF8ABF7AC1F151D3B8C67A12BE48A78F0D345,
	BitArray64_BitAnd_m578053826382B2ACB7E67872F4DB1E475C12B707,
	BitArray64_BitOr_mC80A8A2E27FE8E3614F1ECFB64C7D38BFA7ADC10,
	BitArray64_BitNot_mDEA129C39BEEE912882F8F2F6D79277ED3B2CED6,
	BitArray64_op_Equality_m59409ED14A3934D73FEDA580942271660B1136EE,
	BitArray64_op_Inequality_m23DC59DB0C8811D62FEA4B2C7F819AF6CA14D9C3,
	BitArray64_Equals_m302E3D444E2E2F74D865409C90AD08ECF3228498,
	BitArray64_GetHashCode_mC01786968B8E26CD78AF9F6BA8D9DDFA1A56AB14,
	BitArray128_get_capacity_mF8B9300884F70FA7D2E5424DF4B844F98224105B,
	BitArray128_get_allFalse_mD54F8D614FE56898CAC736E0D471E03CF27DE84D,
	BitArray128_get_allTrue_m613B6531E734903771CB400313E3C58324095EC3,
	BitArray128_get_humanizedData_mFBE6722FC3146F9439687F1D23B26B8BBA497588,
	BitArray128_get_Item_m2056FC3D3AE3A6650545407C0961C91621453676,
	BitArray128_set_Item_mACDC728AC1CA0A2114008187840DC3242CC0C8E8,
	BitArray128__ctor_m269F0551193B6E3990A4BC6209012C6BF6D9A867,
	BitArray128__ctor_m48BF375FF417816E116009DA45CF3B498929AF4B,
	BitArray128_op_OnesComplement_mA128D42CCD0E8146CBF8E53299DF10C67FC33436,
	BitArray128_op_BitwiseOr_m03022DB05D521B8BEF13B293D2783BD6509F06FC,
	BitArray128_op_BitwiseAnd_m7E6FE8D5303DE1D218A17522BD54E774DBD1E019,
	BitArray128_BitAnd_m573069987C6CD28B9045D0A34BB9384A7D943404,
	BitArray128_BitOr_m0621F3B8EB34A40324EE7559AA4B3104B04264F1,
	BitArray128_BitNot_m9D31DF47F85C778B39C77B7FC96725F5B7DAFCF5,
	BitArray128_op_Equality_mBBF2BCBAAF22ADC9585EEB1D8661308E449DF64C,
	BitArray128_op_Inequality_m62B44C09197F1D944695176B340A89EC14512A14,
	BitArray128_Equals_m7BBE0682933DA4AB8B2605AD8428AE845154C5C2,
	BitArray128_GetHashCode_mB8C12AF9AAC59655B4AFA06D4A0F204157FF5320,
	BitArray256_get_capacity_mBEEC883503CA5B2F2ED0E5EE4E917B3E20902676,
	BitArray256_get_allFalse_mC89BB118740CCF24F251D5C89DC15C54E02137CF,
	BitArray256_get_allTrue_m7467D31E9239CA8F8D067A048A272424855A8139,
	BitArray256_get_humanizedData_m35B5547DD137D862F789A03722AA192DA3E1B748,
	BitArray256_get_Item_m97E7E356A32515F35B77F5310BCB350A63EF0287,
	BitArray256_set_Item_mE6BF23C525D050DF66970DFFAB563A34323226B2,
	BitArray256__ctor_m0D5A2405F5460958E0CDEFE16C962079B8DAD5DC,
	BitArray256__ctor_m67548173CE100A6542C2BD45BD9D04B04760B0A4,
	BitArray256_op_OnesComplement_m260EB2662B64747EDC89042792941A983D0E94E9,
	BitArray256_op_BitwiseOr_m036B626BD8173B53B9D4ADDAAE516BF2A9A9906D,
	BitArray256_op_BitwiseAnd_m4FDAD6E0FDAECAE2CD3D742329D7A243000BF372,
	BitArray256_BitAnd_mDC9F06C7E0E0BA44380F19BADCE0C54CA6301A1F,
	BitArray256_BitOr_m991E6FDFEF4405D82BBFC2F907B9F7B0AEB9CE66,
	BitArray256_BitNot_m2DB60E7421D37CB7808A363E0B23D579A61B993E,
	BitArray256_op_Equality_mCD0A130308E3166549830861B3DEF91109A00BDC,
	BitArray256_op_Inequality_m5C9A0C7540B6D9945503203065DEA9B430C189F3,
	BitArray256_Equals_m6723D6D291F588EDD9861D7C58247F246E94417F,
	BitArray256_GetHashCode_mCB0868DFC6212118B07731906DAB0BBF2AC38F7C,
	BitArrayUtilities_Get8_m9D48D91A431CEF3FFA4C4A8CD5ACAF4E0744580D,
	BitArrayUtilities_Get16_m066D2B1DAEDCAFF7F410EACD5685646F0CEBFF99,
	BitArrayUtilities_Get32_m3105A06D66A28B263CC53E3F714F72FD7244EAE1,
	BitArrayUtilities_Get64_m6D4980C3A87139E97BB03FBBDCF0C1693CA2F6DA,
	BitArrayUtilities_Get128_mA21152D99D5617A4B11C84526E83FC410783D4D1,
	BitArrayUtilities_Get256_m28697BC1E2CB8E4F0BFCD5947BC459603E680149,
	BitArrayUtilities_Set8_m4BC480ABC2E8827779655B035B29D2F3E29507CD,
	BitArrayUtilities_Set16_mB599DC5FF7486C291CF767FAE66A796B007A35FF,
	BitArrayUtilities_Set32_m3A905DABCE191DACC520ACF62EDB2D7501AF3CCB,
	BitArrayUtilities_Set64_m386E330CC480D74FD497AB0B695EA5C86DA04AF0,
	BitArrayUtilities_Set128_m0D4C44ED0B3AD702E25C60A6B53F6774121C2CD1,
	BitArrayUtilities_Set256_m2C69FC76E54B7DFAFB89BDD5DCD2E8749FF7520F,
	Blitter_Initialize_m75B8676F1846666ECD90019E091D9A2A95BA6377,
	Blitter_Cleanup_m900786CC658E1966677B4D3BF50044766C204CEA,
	Blitter_GetBlitMaterial_m7139641E860546D39127F3A17C158CA63DB28958,
	Blitter_DrawTriangle_m96C9657CFBFD17632584A0663AF00A73B12C009B,
	Blitter_DrawQuad_m577F64758AB57805FAD01012FD8C97A2BABDA035,
	Blitter_BlitTexture_mCE6C5259E6FC80F39D17499862DD3AEC31ADA534,
	Blitter_BlitTexture2D_mDC79E2CB57C632E3F4382172AB75F63C9DDC7359,
	Blitter_BlitColorAndDepth_mE53779B748F96B8A45F2ACA2F5838C6BAD18F00A,
	Blitter_BlitTexture_mDDF2CA8C4C33D434A8FBB60D796CC3B67F87C732,
	Blitter_BlitCameraTexture_m3F1485AE7C5731A5259C0DD2E6918219D5363BAC,
	Blitter_BlitCameraTexture2D_m9BC6F13FA1CBE7C8B8B218E82DED130FE5649A2D,
	Blitter_BlitCameraTexture_m4CD0B64F751ABDEAB2041D7C2F30D455D21FE71F,
	Blitter_BlitCameraTexture_m7AB14A79F45722CF5E6A4D9CD2434814A4BF12AD,
	Blitter_BlitCameraTexture_mC74719097E5FE8C62249CD2C59F6E3B4986D83C6,
	Blitter_BlitQuad_mCBF7991C0C986458A76146822A145C2977359008,
	Blitter_BlitQuadWithPadding_m85E33D5B48E3D2FCF8FDE7D6B83521BF8BC4AC0C,
	Blitter_BlitQuadWithPaddingMultiply_m2432047128A86D8CAA3052FEB74619E0E0D71558,
	Blitter_BlitOctahedralWithPadding_mE5AD943D0378F7BB5B535D7A68D1EE41654ACEC3,
	Blitter_BlitOctahedralWithPaddingMultiply_m27215AF98C85E90D39D298FB304DF27B1DC353E4,
	Blitter_BlitCubeToOctahedral2DQuad_m406F5BA9EAE4985E613E80465614FC051E16BB16,
	Blitter_BlitCubeToOctahedral2DQuadSingleChannel_m6A42740206DB7A4F66756D00E9054E3BFA7CEDC3,
	Blitter_BlitQuadSingleChannel_mC14750B1B6DC1C7A1362ACDB112A2A72ED4D88C9,
	Blitter__cctor_m45E11ACBC4F705A5F8CC30D49BE421BFDB51BE2A,
	Blitter_U3CInitializeU3Eg__GetFullScreenTriangleVertexPositionU7C8_0_mCDED15E354E9F60A216FCD5027B7521183575FA0,
	Blitter_U3CInitializeU3Eg__GetFullScreenTriangleTexCoordU7C8_1_m23B785ECE01FA6D217CD165A5FF3D5DAB12E98A9,
	Blitter_U3CInitializeU3Eg__GetQuadVertexPositionU7C8_2_m22515FA8B1C1C002FF8364F55A1023C730D7784F,
	Blitter_U3CInitializeU3Eg__GetQuadTexCoordU7C8_3_mD5AE97A26B4D470981CA48A776E61813C645A638,
	BlitShaderIDs__cctor_m60EF46970735B8591A0AE5982A402557DD1C7E60,
	CameraCaptureBridge_get_enabled_m31A62E528795334E5A0894BDF36EB1F09B1EA793,
	CameraCaptureBridge_set_enabled_m80055B22F08CB1BE8D850D32535BE260904FA6E5,
	CameraCaptureBridge_GetCaptureActions_m94B65C4562A66D19BD66CCFCFFE42843E86D3117,
	CameraCaptureBridge_AddCaptureAction_m2E0FC4F221D3CBBA99C184FF1A01DCD6CB391429,
	CameraCaptureBridge_RemoveCaptureAction_m064D5E5E7FC0EDF4037E2C341FCEE32F3B50EEC0,
	CameraCaptureBridge__cctor_m3FBB4A85B914490F465ADF3063280D06365E362B,
	ColorUtils_get_lensImperfectionExposureScale_m010ADD67B5701B40DED2B3E12AD32BCE5B093ADF,
	ColorUtils_StandardIlluminantY_mFD230DBEFCB34E96CC10AC6D973A0785F94C334B,
	ColorUtils_CIExyToLMS_mEF4695F158057988801E4D033A919BA1F9A6B74E,
	ColorUtils_ColorBalanceToLMSCoeffs_mCD34C9A8E62064DADAAE9C49E73936E4248C65F7,
	ColorUtils_PrepareShadowsMidtonesHighlights_m1BBF326D2A4386DD2A05CAFCAC4897D7E90E27AF,
	ColorUtils_PrepareLiftGammaGain_m8DE08DF4B1C60AD451017945439ABC14EBA81D00,
	ColorUtils_PrepareSplitToning_m411AEE689BFA3C919CA846EC6703948F7079056B,
	ColorUtils_Luminance_mF356655EDE24C312306A119C4509A9F15C1E7D02,
	ColorUtils_ComputeEV100_mC4D00D6BF6877A5737BA67D8AA8063191DF09231,
	ColorUtils_ConvertEV100ToExposure_m3023C6FA9AA0763EE40ADF49BC1EC5170EC11E04,
	ColorUtils_ConvertExposureToEV100_m740ADE7309C04DF6B4D2A36457BE5CF0F8C4145A,
	ColorUtils_ComputeEV100FromAvgLuminance_mC12A1AA21540FF9F1DF1AA4516D3E95A05E6DCB4,
	ColorUtils_ComputeISO_m5812533C3821469F706DD99CDEBB345B4C711B03,
	ColorUtils_ToHex_m7D27910C357EF794ACB410EFD10D62C730F8FF52,
	ColorUtils_ToRGBA_m8303D8CD2828AA21EDE0192E1BD5F301625C48D1,
	ColorUtils__cctor_mC580048A58631243CC07B9A087F03D9298792F12,
	CoreMatrixUtils_MatrixTimesTranslation_m23B43D3D63C1490BB9A079490D440ECFC26943FA,
	CoreMatrixUtils_TranslationTimesMatrix_m1D64B396FEBBA07A2619720BBD05976625B53C1F,
	CoreMatrixUtils_MultiplyPerspectiveMatrix_m4674F50DAE5D50F2F92A400247C29B9065C2A576,
	CoreMatrixUtils_MultiplyOrthoMatrixCentered_mD2863C48C17219ED31CA7AFAE19B82B2509518D0,
	CoreMatrixUtils_MultiplyGenericOrthoMatrix_m53C5BA7BD6E9E62F1A0962B4999C5418D07A5A14,
	CoreMatrixUtils_MultiplyOrthoMatrix_m778C48F70AEB68EE2699EF50745144A41E9D7612,
	CoreMatrixUtils_MultiplyProjectionMatrix_mBA742A4025DC1C373B22FD60E77768FCDAD55678,
	CoreUtils_get_blackCubeTexture_m57766E4307BDAAA469A5BF2AFF9AE71C01E5015D,
	CoreUtils_get_magentaCubeTexture_m950639FD91B0DA84FE95F1C1054160E8EB47FE8F,
	CoreUtils_get_magentaCubeTextureArray_mBB47BE385E4159F226D2BA318EB5D2DD0BF5B891,
	CoreUtils_get_whiteCubeTexture_m3DFF82D157B5ADAB18C422007160170CDDB221A7,
	CoreUtils_get_emptyUAV_m5971F9C81C7D6EBEC8B5CB10FB4AFA2B9B32CC89,
	CoreUtils_get_blackVolumeTexture_mAC5B366BA94F2943C375E398B3FC280CF7B77214,
	CoreUtils_ClearRenderTarget_m8D7F1299276232B80DB768A8F372C495A09F8103,
	CoreUtils_FixupDepthSlice_m2BFC1680099E788CE5E3C8710950266180290A17,
	CoreUtils_FixupDepthSlice_m867298EDF226CD749E87096C28F9581B8D235130,
	CoreUtils_SetRenderTarget_m6CE0BBF5E5D16ED93D0FEAE483F3DB6A69ED3D8D,
	CoreUtils_SetRenderTarget_m6F98A950575D6AAAA280CBFD85495B7A554F367A,
	CoreUtils_SetRenderTarget_mEEFF3082D095E30261FE5416357B1FB156B30E9B,
	CoreUtils_SetRenderTarget_mC737DD5F9CF60E7FC2D48EDCD4F7020A5C4D1502,
	CoreUtils_SetRenderTarget_m929338F2F9D6CB3813526A5BA6409B54FD461B56,
	CoreUtils_SetRenderTarget_m138826BDE3B52178379A1D586AA6C114E64FE973,
	CoreUtils_SetRenderTarget_m0083869AE29068E193C72594E742DD18AD73C27E,
	CoreUtils_SetRenderTarget_m69ECACBA48FEC53BE5691E5A1F8F7B640DDABA37,
	CoreUtils_SetRenderTarget_m7C82A292875AA22F474887FAF9129351DA7035B7,
	CoreUtils_SetRenderTarget_m3B7236EA7455EB36DD24E9A4E283E9AC38B11E3E,
	CoreUtils_SetRenderTarget_m03DF45FB5DF653277879D290B90A284F6EFC2257,
	CoreUtils_SetRenderTarget_m2516642B197452D4EF18B42C42193A820DBB9AAD,
	CoreUtils_SetRenderTarget_mA08D357B4CCFB91EFFE380E7282D0DC52938024D,
	CoreUtils_SetViewportAndClear_m73C5B9E647E73062251839230C94D82E401CA712,
	CoreUtils_SetRenderTarget_m21FAE62EC0EE884521A2F8C0A94758CFB30D8A80,
	CoreUtils_SetRenderTarget_m8E1C5D42853E5D83DCB4D9AA899BE41CB4C2BDA8,
	CoreUtils_SetRenderTarget_m16FE3A9C3F8775A82C3DF097DDBFCF6FEAF583AD,
	CoreUtils_SetRenderTarget_m3A19887350C8A8D862A1B5A50DC30BE0629FBF9B,
	CoreUtils_SetRenderTarget_mDBD8F90E95612618F02AA57FF827919E7E0E50BA,
	CoreUtils_SetRenderTarget_mBEE62CA207D8EFA1B01BE64BC81F2E22C41280EB,
	CoreUtils_SetRenderTarget_mC2F20C9F8D78BFF96A924529457C5473A0D67090,
	CoreUtils_SetRenderTarget_mE276987C50257C39A3F838027B59A91C1A3C0FE6,
	CoreUtils_SetViewport_m92C82E5708AB8C69C3F2A02A5398929A7FCA2F8C,
	CoreUtils_GetRenderTargetAutoName_m53CCC53CB33DF2917FE8B2927EC479AF17E74B57,
	CoreUtils_GetRenderTargetAutoName_m8B3FC796A9869D3EC31497190FCF1BC83BD6A5F6,
	CoreUtils_GetRenderTargetAutoName_m19285318502CDF11B7E15A45844D4D2814440D33,
	CoreUtils_GetRenderTargetAutoName_m6ED1EFF259EB08ECAB656DBEFEA3C04C3788E2F9,
	CoreUtils_GetTextureAutoName_mDD7EDBAD7F7F3C66018989C89D1487F37305875E,
	CoreUtils_GetTextureAutoName_m1BAA4A0E7F36BCBAA011CFBBE9A4DBB251EA9803,
	CoreUtils_GetTextureAutoName_m7E0742D6C5C6537DA118ED3D575FD92E52D9A4CA,
	CoreUtils_ClearCubemap_mAD098131D233101899796B39552A945518E5D02F,
	CoreUtils_DrawFullScreen_mB804E8C68BB78F402C36CCDC75F13FB0708D7F30,
	CoreUtils_DrawFullScreen_m0463B1ED1EBE8A4D374DF2B12F5482473BE6CD30,
	CoreUtils_DrawFullScreen_m15EB480803B7BD1189ABB4CE8792CCD2334ABFDA,
	CoreUtils_DrawFullScreen_m7D1D649DE10628F304644AD43659B0E8A4681AD7,
	CoreUtils_DrawFullScreen_m82DA00DB70D9F75C1630B7CA0424F6ACE1C1FE9B,
	CoreUtils_ConvertSRGBToActiveColorSpace_m5CFB24D7E2DEF496FD2B4FE02EF95FFF7C3E80AD,
	CoreUtils_ConvertLinearToActiveColorSpace_m54A871040A0AA45F009CCE3D34490409F60AE908,
	CoreUtils_CreateEngineMaterial_m34B5A3DC1142E177DA75BA6071A585798ED95E5A,
	CoreUtils_CreateEngineMaterial_mAA09043C35B14C19847AD32F4864260DCE381791,
	NULL,
	NULL,
	CoreUtils_SetKeyword_m491002FF7BF17F6C0EDFE60D456DB424CC221FA2,
	CoreUtils_SetKeyword_m32774A5307241CBA36042A0ADC4385D1FB998710,
	CoreUtils_SetKeyword_m70CC262562C483EAE444FCF610684E18D4DE82EB,
	CoreUtils_Destroy_mE6CB8C65A5BA214BE6B7788F2AE388723D7EAC65,
	CoreUtils_GetAllAssemblyTypes_mDBDF1257E7266F7002AA7297415F24EB7F148211,
	NULL,
	CoreUtils_SafeRelease_mC80169C4ECDE45459608C6645DDD7C63F3B779D4,
	CoreUtils_CreateCubeMesh_mBED721BD2C0D62378BF6DB95F8DBA744A918D1B0,
	CoreUtils_ArePostProcessesEnabled_m415BD9B645BEFB3C4815F3BACECDAAC3206500D8,
	CoreUtils_AreAnimatedMaterialsEnabled_mF9DEB7F5F3190310E4A24F2A84A8441C3E45BA25,
	CoreUtils_IsSceneLightingDisabled_m4555A3DEC018BBEC1AF8C8414267E9BEAA2E9C3C,
	CoreUtils_IsLightOverlapDebugEnabled_m6C8280778303F3F2C98737110A73502735C3884D,
	CoreUtils_IsSceneViewFogEnabled_m98CA6228158DACCC6E99E1AF0B8F98C99638A7FC,
	CoreUtils_IsSceneFilteringEnabled_mB0F7A9BC472A8EC3A9EF462E2407230CEB5D0C15,
	CoreUtils_DrawRendererList_mC201FC8EAA8924BD19EC90085F054EB1EA94E8ED,
	CoreUtils_DrawRendererList_m072BB1E8D0EADE4C99888FB33B13FC59ECA52496,
	CoreUtils_GetTextureHash_m5F6B2346A6C7C45663765F0256AADA1D46C9B300,
	CoreUtils_PreviousPowerOfTwo_mE2BCF2C5BDA5E45A6269A2CF82E27C1D36C31350,
	NULL,
	CoreUtils_GetCorePath_m3D173E546A282CCA64560B2915C916957915B7BD,
	CoreUtils__cctor_m75AA14595D6A8F4E2048E1C51CBE3FD37B8BAE66,
	U3CU3Ec__cctor_mFAFD8AC18E5BF973FAD94A967354EDFDE2A0CC16,
	U3CU3Ec__ctor_m63FCDA748E14E0F9C9219BC0BDC490716CA2207C,
	U3CU3Ec_U3CGetAllAssemblyTypesU3Eb__81_0_m49BAC9B1A4D1E04F4AB5B5A08D1804D4C80887FC,
	NULL,
	NULL,
	NULL,
	DelegateUtility_Cast_m7C8232312728679EE6DC10DD0150159495C92B1B,
	HableCurve_get_whitePoint_m4ED2079F06DAD46C16148C39EC95CBEF2305462C,
	HableCurve_set_whitePoint_m178C9CC10D68A74D67DFB3A167EFA72911615BC0,
	HableCurve_get_inverseWhitePoint_m5F59401B566306A949B32D661F869075981E50DA,
	HableCurve_set_inverseWhitePoint_m1A0666ED505D2CE050EB41256F9F5295A2286820,
	HableCurve_get_x0_m6B5D5E0670C8B9CBEEC20B68A75DB35BC1C6E509,
	HableCurve_set_x0_m23752EEB60CAFE7B808783F8C21139157C9CA3BB,
	HableCurve_get_x1_m6C889E5A754B5BA6439F913BA64A4A053F8BE1A2,
	HableCurve_set_x1_m6D171AB75E179893656FB10E41AA73E50DA498B6,
	HableCurve__ctor_mD8850D35C1BD379C30FEFAB2907D89708FD95564,
	HableCurve_Eval_mCF80F93ED7637D742B04B5212A29EA981FF84ED8,
	HableCurve_Init_m3C28DA7DD1F46E1BF41A6A1B7FE2ACB2ED9F3F21,
	HableCurve_InitSegments_m934CDA943CD74A520E387BEF57E6821279A6CB02,
	HableCurve_SolveAB_m92A4CDE2D58A4B13FFE40416B8A2092CE579E1B0,
	HableCurve_AsSlopeIntercept_mCF42D98D9AA26AFD4BD4F84BE46C562C1B44E7FC,
	HableCurve_EvalDerivativeLinearGamma_mCB43DA2C80D623957C9226E8901EF35F9DBD5028,
	Segment_Eval_m9B9E078B5AAD56567D62AFCDA502B313C9954FCD,
	Segment__ctor_m3BD236F840ED5C6DFE5FFA54BC6B86C9D12C5457,
	Uniforms__ctor_mBEA943A03EC891EB56969AFAF36E54BC9D5F125C,
	Uniforms_get_curve_m4E9B26978696D7175E4E57754125CDFC9F6CCEEF,
	Uniforms_get_toeSegmentA_mECE73BE08EAC2967E4DEF4AAC78BA7B71AFE458E,
	Uniforms_get_toeSegmentB_m034FF8C7447281256A8621187D7266FC50335DA0,
	Uniforms_get_midSegmentA_m2CA374C5C02D1EF77615192DC04E8F5BAA05A8A9,
	Uniforms_get_midSegmentB_m9E284F3B0F3BEC58343B10D29504FAACD01A5145,
	Uniforms_get_shoSegmentA_mD7459F493CBA1AAEAF21CD40919DAD00BD20804B,
	Uniforms_get_shoSegmentB_mACCC8C284E2464874C5641726F4B963867934472,
	HaltonSequence_Get_m3049054912DE115D0379D13190046BB03DF47CDA,
	MaterialQualityUtilities_GetHighestQuality_m6DCA350DFA22C7DCD8062D826A1FFA99B0762E0E,
	MaterialQualityUtilities_GetClosestQuality_mD07507CECEACD6E8BA4518DEE37DCC681FAE7D4D,
	MaterialQualityUtilities_SetGlobalShaderKeywords_m5CDA681853E4131EE913EAA59BF499E71C546333,
	MaterialQualityUtilities_SetGlobalShaderKeywords_m34D1ADC3D4DFEF2B84B4A0091449B504DF749423,
	MaterialQualityUtilities_ToFirstIndex_m63F534D84D7A3604D109965E0A656F22A5C6C0A1,
	MaterialQualityUtilities_FromIndex_m38CCD6AAA9914A7CAB83E6D0B800F912D132B6B2,
	MaterialQualityUtilities__cctor_mF4B3C5EEFB133019CD4241244FC5E6B436016D79,
	MeshGizmo__ctor_m59D912AE9D2EF001AE92CE0E6C848B1BF3DDCD3B,
	MeshGizmo_Clear_m5E847CC0D5F8C16E2C5BB97BD4005BF5147F4031,
	MeshGizmo_AddWireCube_m723795D9A503E7C9218F0DDAB2A196FF4756E5D9,
	MeshGizmo_DrawMesh_m51F998C29B5BB02DCC77497F1781D387E0891E03,
	MeshGizmo_RenderWireframe_m87941903D49C3AA5AFA04A8AB8A282F6AF00C430,
	MeshGizmo_Dispose_mFE7AB5D16D81E1C986E64BC5B612EEAF668145BB,
	MeshGizmo__cctor_m1052539AC0F41748EA861BFCE055BF54C1817526,
	MeshGizmo_U3CAddWireCubeU3Eg__AddEdgeU7C10_0_mA0BE9440782DC696EC3246591D8EF5BBFB315B4D,
	ReloadAttribute__ctor_m2F8424FF3711E1D39A46E4F5CDBBB398403862BA,
	ReloadAttribute__ctor_m455053E20E4919190C8D730FA407CBBFD04954D5,
	ReloadAttribute__ctor_m003D5F3B4BFD559042B47110AE491BBD204A9129,
	ReloadGroupAttribute__ctor_m2CA4E9B6F8D9958E4518CDE9E50041482F2415EB,
	TextureCurve_get_length_m782E158DA1DCF67FCB1E87FB4FAA73F3F925F2BE,
	TextureCurve_set_length_mC14849BC756150B20666024F26855DCF1BCC2E4C,
	TextureCurve_get_Item_m6F977BB96BF70DE9A5C9F7B65EE96B616F81F356,
	TextureCurve__ctor_m0D4F2EFA617C6906A248D6D19AF43EE72BEC3E33,
	TextureCurve__ctor_mEDE480C070DD74CECD663A2573F549C27566CEFF,
	TextureCurve_Finalize_m9A483B2870325BC142982D6CAEC0191F6DD4A8CB,
	TextureCurve_Dispose_mFBA215E12C4830A1642EE45C3931320E4FBFA895,
	TextureCurve_Release_mAC8365162C577183C3CDF8FA9BA2410E963D497A,
	TextureCurve_SetDirty_mB9C387DE227B5B94937B19FD1125C2D5FEFC501F,
	TextureCurve_GetTextureFormat_mB1F8D8AE2AD4AFAEDEFC3390658598E3945F8255,
	TextureCurve_GetTexture_m24AA2C84F80EF15DADF73903E4699234BBBDA6DB,
	TextureCurve_Evaluate_m02868520B678BDAE582E9D2A3EA243B20624AF2B,
	TextureCurve_AddKey_m02CEE561F77061709C32F5087CCAA6A200A9F187,
	TextureCurve_MoveKey_m4E07DDD361B7016563D092BF072A8215B741E5E9,
	TextureCurve_RemoveKey_m32D21D2B80F0E053100FAF82E567C1DFAE94DB60,
	TextureCurve_SmoothTangents_m24C847A870703BF0DFA7F577D4484E5D334A8DDE,
	TextureCurveParameter__ctor_m935E3FB0FF6318680EEF7D96081D576D5864D886,
	TextureCurveParameter_Release_mF74E8BB7621ADD4F5A877911D8BCD8876FFBA2DB,
	TileLayoutUtils_TryLayoutByTiles_m544B85EA1C124107699C41E255C21BB2EC0534AA,
	TileLayoutUtils_TryLayoutByRow_mF2190BCFB19C0CA99DC329CB0B88D1696181B030,
	TileLayoutUtils_TryLayoutByCol_m05DF2D984DC2204F08AD8E1610C804A03319F5BB,
	XRUtils_DrawOcclusionMesh_mE70EF55D6E0A824FCAECAC17B72D8B108DC806F2,
	NULL,
	NULL,
	NULL,
	Volume_get_isGlobal_m09C1E1FB39D06DD9EC78DF276DE9A1FBE3E42763,
	Volume_set_isGlobal_m5E2B89583386E5A6C63AD61D2A8DBCAB5533BF15,
	Volume_get_profile_mB157C4D67D52CE6D3E8211D6587B0EF71102E43D,
	Volume_set_profile_m89709CBB66123E4DD821570E2CC4D9AE3D42E769,
	Volume_get_colliders_m0950CE61A71643C572215A4598F769824E1C2E4C,
	Volume_get_profileRef_mE3A46DB4994923FE1B7E12987DD09462AEE7CCCE,
	Volume_HasInstantiatedProfile_mA1547160C1B93EC28AB7FDBDD23ED967B9B7A8F4,
	Volume_OnEnable_mC8C06B2F8E7BAEC731FDC11C098FD1CBED1C38DA,
	Volume_OnDisable_m84BF8533696B6CF5EAA648CD89A0ACC6BFA90CC8,
	Volume_Update_m838C358C05E44E8F3E64CFFF23BF632B877FC92B,
	Volume_UpdateLayer_m3D56B2D4679CF161A7BBB8FDB279544A3F602EF5,
	Volume__ctor_m85DA9885CC8CF9A0C66249607DA2C8EEA37FBD73,
	VolumeComponentMenu__ctor_m8633FE8960007D11F8017F8B43574AF87A2701AC,
	VolumeComponentMenuForRenderPipeline_get_pipelineTypes_m3531E903B834E47340394FFA8CBC7B75516E45F4,
	VolumeComponentMenuForRenderPipeline__ctor_mF3581756460F6824053836AC13083EC1FFF439D9,
	VolumeComponentDeprecated__ctor_m14782C4B7B4C56C5D1E546D70EE4856592C3ADD8,
	VolumeComponent_get_displayName_m9EE2FC2DCD2294F46468DEA90EE71419B34CEBEA,
	VolumeComponent_set_displayName_m7490689389D1F847A6FFCF257C536175817AC1AF,
	VolumeComponent_get_parameters_m4F91CF01C924BB1C3730706F6C16D752CCE63043,
	VolumeComponent_set_parameters_mF276CB5B28110A8E62A0C3B2921FF3904D94CD09,
	VolumeComponent_FindParameters_m091D5D04E70F1CF4D4F1EAC60463DBD22E0B64E0,
	VolumeComponent_OnEnable_m0FA91C466EE1AB7D54AC1CB65AF7D9E8D04C51AB,
	VolumeComponent_OnDisable_m4E2210BFCEE538FBFDE0EBBEC38023FDA5789484,
	VolumeComponent_Override_m3680A57E931545C0FD7D4FD11CDE41C5097F2584,
	VolumeComponent_SetAllOverridesTo_mF825E40D5821ABDBFFBC2861C488A14E728FC87C,
	VolumeComponent_SetOverridesTo_m77276D5A09805A24F619760F40987304D1F9531E,
	VolumeComponent_GetHashCode_mC97714D145AEEC233376DF154C93D69FF3EAF87C,
	VolumeComponent_OnDestroy_m761258E97BB0DECE99ECC6F2F266B51EA0CEA9E1,
	VolumeComponent_Release_m57BFC682C5A2802DBD41FDA73DB9929727792CB9,
	VolumeComponent__ctor_m6A9A4A9F8E91AFC664A381409CFE117D4E0111EB,
	Indent__ctor_m7D602088CDE705BA4ACCC882A798B77AC957B1AF,
	U3CU3Ec__cctor_m312DA08B400C1CD6334FC9E74F80CD5666466368,
	U3CU3Ec__ctor_m0DA022586EF7D98F17249543DEF4D5012EFC5292,
	U3CU3Ec_U3CFindParametersU3Eb__10_0_m386CF821AF832AEF1368036212E249D2DD766B2E,
	VolumeManager_get_instance_m39B7AEF8823427A6BE8B1DD542CDC4472D8D5904,
	VolumeManager_get_stack_m5F7B366D1E7FE168EF4CA04A17531D34DD200266,
	VolumeManager_set_stack_mDA55AC84E57EC2FE6D2A25EBB977A20EBD227156,
	VolumeManager_get_baseComponentTypes_m2860DEF58F61A01DC1796AE9AF3B1F55C31F2DFF,
	VolumeManager_set_baseComponentTypes_mD45041AC16A7D2DA82933912999F3669BB615A7B,
	VolumeManager_get_baseComponentTypeArray_mA7074538EEBCE5CA3CBAD4A72919B3BB8B6095C4,
	VolumeManager_set_baseComponentTypeArray_mBB0F61A0058E8889334B4FC361688C3910B9FD54,
	VolumeManager__ctor_m4FD966D420A802BECB643C97876F286053AAB510,
	VolumeManager_CreateStack_m7EACF7BD773893B2344DB8DFA1ACF4557FBB38B4,
	VolumeManager_ResetMainStack_mF68ECEEC5A6D07ED24F5F77D798465A03DE364C7,
	VolumeManager_DestroyStack_mFB8C5FA985F64DB8C4A322818E8C6FDCAD547AA6,
	VolumeManager_ReloadBaseTypes_mF05B36FEF13C5117FD56C399CB006E6ACA5C1F3E,
	VolumeManager_Register_m03EB301A26ED63AC0436B2629823184FA51E3A12,
	VolumeManager_Unregister_m13977E5D10CE32234CC88E0C70FC8ED7BD3ECB93,
	NULL,
	VolumeManager_SetLayerDirty_mC890A8B7C87D55DA92F0AE02DE758ED0C662A76B,
	VolumeManager_UpdateVolumeLayer_mA0F6077F117E1DAC32E5C2CC392C605BD331A23E,
	VolumeManager_OverrideData_m6FDE271C5759140EB3229AA0EF36470453745CB7,
	VolumeManager_ReplaceData_mC32366C3D53A9B349186410A95215ECC433BD690,
	VolumeManager_CheckBaseTypes_m3598A8722F3AAFB27B30DA521BA37AAE00D003F0,
	VolumeManager_CheckStack_m86DA4666E3D7CC889512DECC1061AE50E904CA0F,
	VolumeManager_Update_m80D06A996F422CBF95CF7B7FB7EB687D75450E7F,
	VolumeManager_Update_m0AD4F65D0737393F3DF85F77D4A799D794C9FBC5,
	VolumeManager_GetVolumes_mCD6F01BC37F4C6833FF56635904021D3E087BBDA,
	VolumeManager_GrabVolumes_m3E182E42A41D762A000FF23E49D2C6CFDCD8A9ED,
	VolumeManager_SortByPriority_m9CBB6E5C4C0D5685C8693865D4119114B3C75130,
	VolumeManager_IsVolumeRenderedByCamera_m7B6E205268B231DFFEE198CDC6DAABAF0967E5E9,
	VolumeManager__cctor_m27EBAFF65D0A2E0A7E99E145BD72AC1237EAD91D,
	U3CU3Ec__cctor_m4F6DA144B7FFAE9BC642E81C79EDE8A1536DCACF,
	U3CU3Ec__ctor_mB089A6F9C8405F20786EAF00508B21C80753FAF5,
	U3CU3Ec_U3CReloadBaseTypesU3Eb__25_0_mC8950B6BB17E541E241A2034460F5CC5B77AFA10,
	U3CU3Ec_U3CGetVolumesU3Eb__37_0_m5B62E3B295076FE91FAF61F31B7D37FCAB17B31C,
	U3CU3Ec_U3C_cctorU3Eb__41_0_m3B9EEE930E2698688F41F786649E23418703BD0E,
	VolumeIsolationScope__ctor_m01620738B9C04C8237155E3843C60A195C179498,
	VolumeIsolationScope_System_IDisposable_Dispose_m1351187D1678129A678C6AAD3FCD237147438BC4,
	VolumeParameter_get_overrideState_mA355B3AA60CF5775142D57F8C48AC2283DD89170,
	VolumeParameter_set_overrideState_m20E185DE102F9BCF46759CCDBACEA7832730E83A,
	NULL,
	NULL,
	NULL,
	VolumeParameter_OnEnable_m0A1ACF10A6885EAF8A33DDC1103AFE8A9B8B8A60,
	VolumeParameter_OnDisable_m019429EE1025F4E1A3A3F1900D78B6D4BD0E4470,
	VolumeParameter_IsObjectParameter_m6D4BC5FFC3B2A2DC5CC92FC6C0B87CE5E8DE78D4,
	VolumeParameter_Release_mA95DED0C57364D4C9C9D98B9613D035C18FFE155,
	VolumeParameter__ctor_m1A76B3C6C284C912F55F7C7E6EF21A18AF3930D2,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	BoolParameter__ctor_m2355BE07CF2E06B525D26161B1E0C357CE772190,
	LayerMaskParameter__ctor_m8F8196A3800C793D3B236D6AD4A914F2CE5B9206,
	IntParameter__ctor_m67FBC21D721C250E279747AEB87DDFBB1AF11F57,
	IntParameter_Interp_mDC423D4C404192EE3DB1409787DFACC7326C67FC,
	NoInterpIntParameter__ctor_m90649C51973C965712112CD7BABD9E259EA5804A,
	MinIntParameter_get_value_m186AC9E61EB01D361426269260C5A1B2ECEB6206,
	MinIntParameter_set_value_mC0ED8E817428CCE3C943FA3C617A9A8DEA994D09,
	MinIntParameter__ctor_m503915F572DD7883610AD4107C2B8C08E7FF2E57,
	NoInterpMinIntParameter_get_value_mCD45893150FE0FFFBDA55B2066A6908810EBD574,
	NoInterpMinIntParameter_set_value_mE0CB3103510DD3AA324439A5FAC30B75509E6097,
	NoInterpMinIntParameter__ctor_m6962CF0672226874984520D8227E7BEC783BAB07,
	MaxIntParameter_get_value_m0D77F6896765E8898301E88B4B36896785C3196F,
	MaxIntParameter_set_value_m5B5583396506E5FEA828895D3E1985F3CE0E2BAC,
	MaxIntParameter__ctor_m8D89FC483C8D8203FFB0A8436CF2C45D93C8FA8C,
	NoInterpMaxIntParameter_get_value_m2055E30B9F44765EEFB7DB18731A0A5EBC7E57EE,
	NoInterpMaxIntParameter_set_value_m609E4B1372022A9239F7D7FBDF9C40D921501691,
	NoInterpMaxIntParameter__ctor_mAE456C5846B27CC7D63254BA778F905D6B498217,
	ClampedIntParameter_get_value_m34AE11973506069525F62716647B890CFA0A3AC4,
	ClampedIntParameter_set_value_m590DDB07ED64AE69840607D1005FDC5790282B39,
	ClampedIntParameter__ctor_mF0B73AD8EF805C194DCE64ED205B9968D58BA6D6,
	NoInterpClampedIntParameter_get_value_m0EA1E9A8144DF33899F8FA553C448B7BF52700E4,
	NoInterpClampedIntParameter_set_value_m07FFEF923D294F6D3E76864AAD0512FCF182DE2D,
	NoInterpClampedIntParameter__ctor_mF8B3120B4D7C9E1F2830F9B424B6A694F242615E,
	FloatParameter__ctor_mC453DAC155DBDF014599DD3C2A92E2653378F7AB,
	FloatParameter_Interp_m5EEABBCB6D5C74CD027D14CB1940BADF46DF8B8C,
	NoInterpFloatParameter__ctor_mC5FF8F8C6923CADFCC30BE1C66D11B665B2F4650,
	MinFloatParameter_get_value_m2BEF75BB125497127385C3FEA91F295F56CF96C1,
	MinFloatParameter_set_value_mFEE3E60FA643148A1548A5C1DF00EB0659FA9C95,
	MinFloatParameter__ctor_m854E3294B712BB55CBED061C73BF617FAC983AB9,
	NoInterpMinFloatParameter_get_value_m63F82DF77BD44C45CBE001FDE8E561A3C993981F,
	NoInterpMinFloatParameter_set_value_mF338F3AC7FC964EE6F13CA24BA81857A017810F6,
	NoInterpMinFloatParameter__ctor_mD6661EA495B98AA034513C11FC0443EF4A274802,
	MaxFloatParameter_get_value_mA6BABE32B5AC8B348C729E12666382F4FAF07E00,
	MaxFloatParameter_set_value_mF8BAB011F885367EB3D8C4E0C7AF695DDF14AB8B,
	MaxFloatParameter__ctor_mA56D698D4B059FB5C3E76ABC7805E72D2B19E248,
	NoInterpMaxFloatParameter_get_value_mB8F3D827D20C50AB609F887C270E35D3FC1622E9,
	NoInterpMaxFloatParameter_set_value_mDDF917E8CD3B661D304EDC248B01FC2BEE7FE594,
	NoInterpMaxFloatParameter__ctor_mE9A5ED98EA3E61769C30FC1D3DF99ECF5E38657C,
	ClampedFloatParameter_get_value_m61D80F063384761A7C113BF99AE4E6D72BA39D8A,
	ClampedFloatParameter_set_value_m407E77C2AABD9AF3AD81373BFEB764188A8DC763,
	ClampedFloatParameter__ctor_mFC9EF54EFA2A6B51F252CB98A6F6D66C768F3CE5,
	NoInterpClampedFloatParameter_get_value_m2B9F89DFAB9796DD5341354DDC5BDCC1E3318DA5,
	NoInterpClampedFloatParameter_set_value_mD21081AF32ADDC677AEA5F27F8CFC9EEB2F966CD,
	NoInterpClampedFloatParameter__ctor_m8AEF6628B5863799A40D5647649D779D8BCAA81C,
	FloatRangeParameter_get_value_m25B1C4761DBF5FED042ECA668FFF00BBC35DD925,
	FloatRangeParameter_set_value_mF98828AA823A3F6A4B0A2D32E211698AAD587829,
	FloatRangeParameter__ctor_mB17094FAECFA22F0494B606A2531EBC73AB0DB31,
	FloatRangeParameter_Interp_m49C2EAA6296B9C8BDE3A56810A606EE459388F78,
	NoInterpFloatRangeParameter_get_value_m5C29069EBA216300A415ADEC1A7DD1CE5E633B01,
	NoInterpFloatRangeParameter_set_value_mC8C880583FA80C2B7895560C0E9BC2965F91A26D,
	NoInterpFloatRangeParameter__ctor_mC9294487DBF1F2C1A18F6C3EF586DEABB249652B,
	ColorParameter__ctor_mD47039CB27B4A8F5EAECBCC844B2140719C50386,
	ColorParameter__ctor_mA9A003084B8D70C30995E95B65B29A136C66096D,
	ColorParameter_Interp_mEB18527D660650893F9BD4B60B8BEB548B18E772,
	NoInterpColorParameter__ctor_m511A9D9F6127C758B0EFF479E9D3C367FB8C03F5,
	NoInterpColorParameter__ctor_mF53E2D8AFB3A645C40CE9A0FFE28C1309E08257A,
	Vector2Parameter__ctor_m34C59043C7CB4CCF438E61F1F50D81F15E4FE4B6,
	Vector2Parameter_Interp_mB09C819117EC228387E17D4AF66B999805DAC321,
	NoInterpVector2Parameter__ctor_m0023AB35D338B1370F97CE6635DB33B7D3174EAE,
	Vector3Parameter__ctor_m2A3477C2E556645131EB0475AEE4E9728841BE9C,
	Vector3Parameter_Interp_mB5B50D808D2FAFF04558AA92A854A5587717E159,
	NoInterpVector3Parameter__ctor_m57423AC9510F99C56BC5AAB1A95B86481A9148EC,
	Vector4Parameter__ctor_m741CC228E74AF9EA20C77D6209BDF264F2C17452,
	Vector4Parameter_Interp_m156F7A8256CF5C6DCECAA5CF2F99A920C30BEB66,
	NoInterpVector4Parameter__ctor_mBCC94D3B29ADB6D1C6F730D26850D37F3F35A185,
	TextureParameter__ctor_m5756E1DFAB73C37D64AA6CA329F6D1C55971A71A,
	NoInterpTextureParameter__ctor_mAE3B412887E5CDE015065A6B6E0F3E78F8106E88,
	Texture2DParameter__ctor_m3A6EBCB797C3FD5ACFE6D5029704887DB17B492A,
	Texture3DParameter__ctor_mC5EB1FCDE9F1426770783EF2C7242C0E221D8A93,
	RenderTextureParameter__ctor_mFA2947C5B4BB2C80603711DD6F881A1E0880BB96,
	NoInterpRenderTextureParameter__ctor_m20B3C73CD6A11B1198BB7A21CE33DC908ABC46C0,
	CubemapParameter__ctor_m44BF9295F2F3C4168BCBDF746B59F057E46BE9F6,
	NoInterpCubemapParameter__ctor_mFE94AFC6850C280614C720CAE234E75C6AC40D1A,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	AnimationCurveParameter__ctor_m7D096129215A4302F4FA02A25F8043C58BF44A96,
	VolumeProfile_OnEnable_m1A8EC150A4A44E6BB4B7596681CBCF7D5CEF3293,
	VolumeProfile_Reset_m56821F268C7DF9B2AD8423094839E0C53BCECC89,
	NULL,
	VolumeProfile_Add_mDF517026750FFACF3E21FCC135510FEBEB12BE1B,
	NULL,
	VolumeProfile_Remove_m9E5CA5F7CA22167AD235A88515C4315F68A579E7,
	NULL,
	VolumeProfile_Has_m58F53E1D8EC2C8D8D97ADF7AEEB6C432FFE9C8BC,
	VolumeProfile_HasSubclassOf_m920D79BA16A14B8026649BAFA32A8C017DE0F02F,
	NULL,
	NULL,
	NULL,
	NULL,
	VolumeProfile_GetHashCode_mFFE471DEA166D1EBC418F1EF97D3FB5FFD627ECF,
	VolumeProfile_GetComponentListHashCode_m8AB8D068D1F104706ADD8CA0207E3B3526D527C1,
	VolumeProfile_Sanitize_m288F3AFCFE9A6F6653F7FFC87CA08E17D425A305,
	VolumeProfile__ctor_m3981FB5EB5E02F57E8C1C58AD34187402D7A7FFB,
	U3CU3Ec__cctor_m7E0B1F83A34449300AB2DB8208AAF13B59451A1E,
	U3CU3Ec__ctor_mAEAED8F15ADB4E2A3D53D6D63BB7D9AEFDB3462E,
	U3CU3Ec_U3COnEnableU3Eb__2_0_m01AFBC2281C9D0F419F9158C17BCA7A47E0012DE,
	VolumeStack__ctor_mC6D6B63557B0EFF135F33B4E3868BC7BE1F35C58,
	VolumeStack_Reload_m74FD3C7E2C4DA948F2DE94036348527C44C55CF5,
	NULL,
	VolumeStack_GetComponent_mC7A2CE27A8A6F6A6A4B4B6EF14E190085A343844,
	VolumeStack_Dispose_m4DF004B6DEA09DECF79AFF8E2A7CE7386EC32B43,
	XRGraphicsAutomatedTests_get_activatedFromCommandLine_m0B64CC2FA51C178F0038436532184BD748E011D5,
	XRGraphicsAutomatedTests_get_enabled_mED2B45610E9C762FDF0D89932D14A2BEA5390B82,
	XRGraphicsAutomatedTests__cctor_mA5D3CFA7660CE819738ADE99B2B9181374F04B09,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	StageRuntimeInterface__ctor_m77ED24F527202E13B5FF938C2BF1C7E4E0173661,
	StageRuntimeInterface_AddGameObject_mBA0539C875795229002891A57B2AB97543FB314D,
	StageRuntimeInterface_get_camera_mD25AB28B41CDED30E6D478BBC00E631B938AF1A0,
	StageRuntimeInterface_get_sunLight_mD1B5AB2BB6B385D2AE0D4A6660D402D8319C4B86,
	DebugUIHandlerBitField_SetWidget_mC9A7F8C4B39F05BFA164FA25C5C811106EFFEDA5,
	DebugUIHandlerBitField_GetValue_m83486BB1A30BD81A1BC807D8CCD979FB7009306A,
	DebugUIHandlerBitField_SetValue_mE5AF66449A807CD3704C70057C54662FE1F9B5A2,
	DebugUIHandlerBitField_OnSelection_m11DE74FFB02ED64DBB4A40EDF0C27A5FD8F52AD0,
	DebugUIHandlerBitField_OnDeselection_m6503BAFA10C4FA983C294370C405B50CD32D3008,
	DebugUIHandlerBitField_OnIncrement_m4C54446147993E50B939A1111F0EE2E40264663E,
	DebugUIHandlerBitField_OnDecrement_m7A7522DB09A33E214B84AD1AB34CFE9B2513761C,
	DebugUIHandlerBitField_OnAction_m05B63A9FC76EB4DF6203C2DDDDE4D816BD2307B3,
	DebugUIHandlerBitField_Next_m6EC5781F4884FBEF25226F957C2011C8D17291BD,
	DebugUIHandlerBitField__ctor_mA489C3E5573EEEB6A429E55DACA850EF4CD3768A,
	DebugUIHandlerButton_SetWidget_mB1AEC7776B1E2D838441E957ACE6973849F10780,
	DebugUIHandlerButton_OnSelection_mDB94CC63682FF286935252FB0471C520D6502F5F,
	DebugUIHandlerButton_OnDeselection_m06297EBFD0C4B8858B1FF36EBD2F167931893074,
	DebugUIHandlerButton_OnAction_m2B245BDA71B32B5F8BD1208C0CC6C9DF6E969E65,
	DebugUIHandlerButton__ctor_mB0A7B33C44011CE96C5B101E391C2C233E56CEB0,
	DebugUIPrefabBundle__ctor_m871F8F84F6E1DD549EACAA3E911D32C92DEC3B49,
	DebugUIHandlerCanvas_OnEnable_mEDB28828751EBF1C982CA3E6C45B84406E4E5563,
	DebugUIHandlerCanvas_Update_m824889AC55699E3EED275361E755D61623ABC514,
	DebugUIHandlerCanvas_RequestHierarchyReset_m795844483B9DE139935276CB7BB5015E9868071B,
	DebugUIHandlerCanvas_ResetAllHierarchy_m7583874C16AC780324D02B6728DBD9F38EF5D079,
	DebugUIHandlerCanvas_Rebuild_m035E60DC55732E3B23E7082C4E7518DB72B756ED,
	DebugUIHandlerCanvas_Traverse_m7C1AB7935DE310A3493083E3B42DABECD756907D,
	DebugUIHandlerCanvas_GetWidgetFromPath_mD5CB2171F21E6300C270800005853C2D32D3095C,
	DebugUIHandlerCanvas_ActivatePanel_mA608E38437FBD80E35B37FC859CE5E8C4741D808,
	DebugUIHandlerCanvas_ChangeSelection_mE3D51E1E6390B8C7B5926F26122F8AF2588BF03D,
	DebugUIHandlerCanvas_SelectPreviousItem_mFD931025553965A1F5D279142A18F271A0F87D84,
	DebugUIHandlerCanvas_SelectNextPanel_mDEAC3EE25EEEB60C1B1CFBDF0693F629BC6CAE36,
	DebugUIHandlerCanvas_SelectPreviousPanel_m8BC52AA79EF5DCDDC00BBBB42AFDB89AEB7D7F34,
	DebugUIHandlerCanvas_SelectNextItem_mF022DBBBACE5AE3F83DACC62AFAE5C74AD29131A,
	DebugUIHandlerCanvas_ChangeSelectionValue_m74FA9A84A4B35EC27B0BCB8F936A829D37F4A5EB,
	DebugUIHandlerCanvas_ActivateSelection_m930DEED7D808635689EC11BA9C0C40BDCB31EC88,
	DebugUIHandlerCanvas_HandleInput_m68428B2A6A70270746D6B490A99D6AD51F112C98,
	DebugUIHandlerCanvas_SetScrollTarget_mD305DF6EA8FC2C84F08EDCAE2336DDD15C2E3E86,
	DebugUIHandlerCanvas__ctor_m98615720A510A28352CA09B092C5AF43FC27C776,
	U3CU3Ec__cctor_mECD64740EFDF549A390BD7FA9403F7D9F96B8153,
	U3CU3Ec__ctor_m775C4B6FC2C623756041294726B7DA41A73D4926,
	U3CU3Ec_U3CRebuildU3Eb__12_0_m0B768BF30ADC6380A48FEBAAE47297DE18E12394,
	U3CU3Ec_U3CActivatePanelU3Eb__15_0_m178DE0B54B076B42EE28B1256BC18545966CA344,
	U3CU3Ec__DisplayClass14_0__ctor_m861EA10CA07D6929E70405A3BA2BA284C590C739,
	U3CU3Ec__DisplayClass14_0_U3CGetWidgetFromPathU3Eb__0_mF4214EF157153DCDF6CDE37D01DD63581EF7AF63,
	DebugUIHandlerColor_SetWidget_mFBE0123D585E284425748A780F55D4FB030388CD,
	DebugUIHandlerColor_SetValue_m076FEA35FD3244F27C5B751CD68071091FFD0B60,
	DebugUIHandlerColor_SetupSettings_mE3ED3D6152635D1EEB1D5076089E0588957E9E46,
	DebugUIHandlerColor_OnSelection_mFA64A94310860C1D786BB00CAE00D4203B323394,
	DebugUIHandlerColor_OnDeselection_mCFF411453C3E08A1091DA1A89742DE5AC06921F1,
	DebugUIHandlerColor_OnIncrement_m1591CEE2831C84A155719FCA0665C1C4AD877046,
	DebugUIHandlerColor_OnDecrement_m993B7499D6E2772D6DBA43EDAA40B90550D3F2F1,
	DebugUIHandlerColor_OnAction_m2E3B5E2D0D52E3F30759F91754378EA92BC0BD06,
	DebugUIHandlerColor_UpdateColor_m0D7C0E504BECE85E4E0A47F9D69DA52B2E7ABD94,
	DebugUIHandlerColor_Next_mE601A99ACB9E92FC1A40C2C952744C5C9372230A,
	DebugUIHandlerColor__ctor_mD6AF38D964CAAC9CC0759F2DE6DC077ABCA25ED6,
	DebugUIHandlerColor_U3CSetWidgetU3Eb__9_0_mBAFD5BD05F214AC2AB8E17AEBEB13FA1381E17EC,
	DebugUIHandlerColor_U3CSetWidgetU3Eb__9_1_m2967C435E96AB4E261D1338BA62BF4D99A6D4CE3,
	DebugUIHandlerColor_U3CSetWidgetU3Eb__9_2_m69B6AA580A85659F23F70B1460442019B83343C6,
	DebugUIHandlerColor_U3CSetWidgetU3Eb__9_3_m54A73A1D77BCC317E3F597AD6A2E7829739304C3,
	DebugUIHandlerColor_U3CSetWidgetU3Eb__9_4_m408843B0828821EE347D7DE706C7A405F0FDC871,
	DebugUIHandlerColor_U3CSetWidgetU3Eb__9_5_m436E90BB8D0498318BD2634574361FB231DFF66D,
	DebugUIHandlerColor_U3CSetWidgetU3Eb__9_6_mADC9E3769B689A784BAE829BD1B84EF6F0FEFE94,
	DebugUIHandlerColor_U3CSetWidgetU3Eb__9_7_m8D466921CECBD6390902A54733F9CD84DE7C7209,
	DebugUIHandlerColor_U3CSetupSettingsU3Eb__11_0_m1650683DE2689FA919F5F23D7B3E37C1D1C698FC,
	DebugUIHandlerColor_U3CSetupSettingsU3Eb__11_1_mFB55DFA1E3A700E6C138C5FBC65EB9A73E7F2970,
	DebugUIHandlerColor_U3CSetupSettingsU3Eb__11_2_mAE4CAA0731F89269A24512B33CFDDD31CD325412,
	DebugUIHandlerContainer_GetFirstItem_m6218F40059CE4BA28F39DA27F7FC12A59C225F80,
	DebugUIHandlerContainer_GetLastItem_m19783039A96D0E481190EC168D1147EA34C353FB,
	DebugUIHandlerContainer_IsDirectChild_mCD24A410A0F20F48BDCBE21A6878072614B9F7FB,
	DebugUIHandlerContainer_GetActiveChildren_mB84ADFB63E20AA9B27EF865FE730DC75432598F9,
	DebugUIHandlerContainer__ctor_m19965C49C75B009FBA764A4802430855741F3310,
	U3CU3Ec__DisplayClass3_0__ctor_m7C972827CF4936AA55AB609E47F79190416DDD2E,
	U3CU3Ec__DisplayClass3_0_U3CIsDirectChildU3Eb__0_mE86B269F22B9D136B3B900B71A6540059D336A60,
	DebugUIHandlerEnumField_SetWidget_m87B596B3F7F6281BBEBE571BE69B7555C7F6A44A,
	DebugUIHandlerEnumField_OnSelection_mA059DD228D6EAD4D8CD76572424A2CAE8F8B9B59,
	DebugUIHandlerEnumField_OnDeselection_m8F23BC6DA12275BA2FB6DE84EC1835E5A7E433F8,
	DebugUIHandlerEnumField_OnAction_m48070D90F714A776FD5D0FBEC7DD5246DCF8C407,
	DebugUIHandlerEnumField_OnIncrement_m4339F79F70A2975F699FD3CBEF4865A1E451B5BE,
	DebugUIHandlerEnumField_OnDecrement_mADC546644129D9B435D96D6CC681B29A31ACDF62,
	DebugUIHandlerEnumField_UpdateValueLabel_m36CA0D43AB06505769BF6D0B38D975D0D42612A3,
	DebugUIHandlerEnumField__ctor_mF6183B378AF80A25041E59C7116A05CA64F50813,
	DebugUIHandlerEnumHistory_SetWidget_m63DB0958ED2BF1EDB8253A3A9F6DB85672438B39,
	DebugUIHandlerEnumHistory_UpdateValueLabel_m8BE6CCDBC0005E5C81A3463462393713D95B2614,
	DebugUIHandlerEnumHistory_RefreshAfterSanitization_m9BAE31D9C443E5C930847EDD01B99FB78A77ACF2,
	DebugUIHandlerEnumHistory__ctor_m0916E2112F932065DBBAF9F3813C9364E8CA7CE2,
	U3CRefreshAfterSanitizationU3Ed__4__ctor_mA1B6468C0591D678F9997F3BC24D9FBB77DC8C7B,
	U3CRefreshAfterSanitizationU3Ed__4_System_IDisposable_Dispose_mC1C26EC8604D476A3D451C15B9F9470753A5FE16,
	U3CRefreshAfterSanitizationU3Ed__4_MoveNext_m9C60488CBAA36235D58584F9B11FA56A5E43E90C,
	U3CRefreshAfterSanitizationU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m187EBBE4E909383FD956756EC3A3ED66B408DF7E,
	U3CRefreshAfterSanitizationU3Ed__4_System_Collections_IEnumerator_Reset_mC899145E1B57D3F7A421DBD5CA16505B7948E91A,
	U3CRefreshAfterSanitizationU3Ed__4_System_Collections_IEnumerator_get_Current_m080AE81866B34CC4BEDD1D0B670929DD58FA78BA,
	DebugUIHandlerFloatField_SetWidget_mEC7E9E29D290619CEE8E85A87B6E299D41B51D4F,
	DebugUIHandlerFloatField_OnSelection_m20116B3240DAC17E1A866FFF9762BFC7E5F59D3E,
	DebugUIHandlerFloatField_OnDeselection_m597ACA65A33D50B70B712F95B687D782FF2187C9,
	DebugUIHandlerFloatField_OnIncrement_mE2FBC3591F6E33EE3000061CE6FBB4410340B904,
	DebugUIHandlerFloatField_OnDecrement_m6DF136E8C97089F9782AD7A295AF9ED038371AC4,
	DebugUIHandlerFloatField_ChangeValue_m2D26CF4F074BFC3E8A2699EC4C4F79692FBE986B,
	DebugUIHandlerFloatField_UpdateValueLabel_m82D62BFA0C18D2A4B2B1A6869F059FD2B7E836B1,
	DebugUIHandlerFloatField__ctor_mA3216AEFF7C140CB330D3E43C590438DA39265C3,
	DebugUIHandlerFoldout_SetWidget_m828CBD39A3BD5745A713D2EA05DDA1BACC7B33F5,
	DebugUIHandlerFoldout_OnSelection_m0328778E15A4BE0ACF3915E9C27B15E4EE9B5551,
	DebugUIHandlerFoldout_OnDeselection_mA9BBD048A4139295D54316BA19A69BB73BD6D327,
	DebugUIHandlerFoldout_OnIncrement_m0F9F9643478577474FA6CEB857FCDFEC50E1C767,
	DebugUIHandlerFoldout_OnDecrement_mCB9E8525619929BFC7CC55C44BE5A56459C1CB7D,
	DebugUIHandlerFoldout_OnAction_mDEBF59190697160E20C69825947CE9D5DEC30FB0,
	DebugUIHandlerFoldout_UpdateValue_m8CE29D10B0F61188598331EBD881B8BA05B8B40E,
	DebugUIHandlerFoldout_Next_m35EC9520B4E86C3FA7BC8A969C8227BCBFB10EBC,
	DebugUIHandlerFoldout__ctor_m8EA66D76CD7E71558FDA92201638EC736F33FB66,
	DebugUIHandlerGroup_SetWidget_m9D7EA85B890C75998306B269A787E181B5102C65,
	DebugUIHandlerGroup_OnSelection_mB089F2E1461618C744B0A54A28B5CFB07EFAB701,
	DebugUIHandlerGroup_Next_m0E5C76D1C72B2FC74608AEDD3F7A687D0E17033A,
	DebugUIHandlerGroup__ctor_m087A8C431E01E7AF80211A308D54B25FA5BD2250,
	DebugUIHandlerHBox_SetWidget_m6FFBC1ED54189C8973415D2954E02C269A278779,
	DebugUIHandlerHBox_OnSelection_mE4201C3C243D3EAE0A64EFF5987F9537206B4167,
	DebugUIHandlerHBox_Next_m1C398F0C0D1CDC97A08B3CA7C04D7AFCF32F5EEB,
	DebugUIHandlerHBox__ctor_m744194D9207EF339C9D586A969050830503A51F6,
	DebugUIHandlerIndirectFloatField_Init_m8297DF272ED8D2435861EDB77AABF58290B96840,
	DebugUIHandlerIndirectFloatField_OnSelection_mA239F05E325E92B8BD5D359DAD11F6DC87260848,
	DebugUIHandlerIndirectFloatField_OnDeselection_m6C75859C026A3CA540B14970E007348B8747586A,
	DebugUIHandlerIndirectFloatField_OnIncrement_mC97828C6D3D2591BB9C2547ADBE03BC2C6C96F23,
	DebugUIHandlerIndirectFloatField_OnDecrement_mFC9FE6DCC32C5C15652B0976D8D40C251538D0AD,
	DebugUIHandlerIndirectFloatField_ChangeValue_m03670DD0C17DA24ACED728FE0D405138C9D40A40,
	DebugUIHandlerIndirectFloatField_UpdateValueLabel_mC1801ED586636474218A11B89D795A6FF50E9CE8,
	DebugUIHandlerIndirectFloatField__ctor_m0ACC509CE6DC880F0F7D9F92BD4C651E3C48C065,
	DebugUIHandlerIndirectToggle_Init_mFB2213D89BCF29671F255C37E862F94F31F12506,
	DebugUIHandlerIndirectToggle_OnToggleValueChanged_m4B8562DBAD02E683C51D2E3E293F948139D8103F,
	DebugUIHandlerIndirectToggle_OnSelection_m9AB28E2FE889601DC2241D2F9FF205DA416E5238,
	DebugUIHandlerIndirectToggle_OnDeselection_m29103A2BDD465341E0FBFD47E23D0A0C77F7DD78,
	DebugUIHandlerIndirectToggle_OnAction_mE8B5245408FFB96A5AC3CAD66913ECC288647683,
	DebugUIHandlerIndirectToggle_UpdateValueLabel_mECFCCF09947AA410A2D6F756F08BB6CDDCD05AAC,
	DebugUIHandlerIndirectToggle__ctor_m8C396EBDCA669A7559520174C0BECE948E2E6964,
	DebugUIHandlerIntField_SetWidget_mECE6C25B51EE73AF198E2A839B99A12107174225,
	DebugUIHandlerIntField_OnSelection_m6275F31B59253780EEA5A158D1074EF63131AAA4,
	DebugUIHandlerIntField_OnDeselection_m56D7C9510BABBB401C6E3FAD31553FE48BE98A6C,
	DebugUIHandlerIntField_OnIncrement_mDB8DB60DDFD35E5521CAD4BCDB4BC6A3B1ADF072,
	DebugUIHandlerIntField_OnDecrement_m31C3683D87F62142EA82E3345E9F41F7B6861642,
	DebugUIHandlerIntField_ChangeValue_mD8057A2A9FD94293116182A6407B63B5A21EAE13,
	DebugUIHandlerIntField_UpdateValueLabel_mE37F658D4F377685F119C9C2139970567BBACD79,
	DebugUIHandlerIntField__ctor_m3DE21A5DC240FA90CCAA3C2473B740EA5DB6795D,
	DebugUIHandlerMessageBox_SetWidget_mDD74A0DBC434597426FEE13BC29072D50CBC9A06,
	DebugUIHandlerMessageBox_OnSelection_mD6864FB70FACC2CAEE460F1539A13C3BF77CE037,
	DebugUIHandlerMessageBox__ctor_m62554FDCA7615AE940839BCFB47CB6D08E70EA3A,
	DebugUIHandlerMessageBox__cctor_m83DAEFEA945E20EC7C855A640A2A9EDD46B254F6,
	DebugUIHandlerPanel_OnEnable_m69DF0926526D7445EBE1E32FE4404A81BABBCDFD,
	DebugUIHandlerPanel_SetPanel_mC9EE00598AED6937770AE24C09F5305B7EBDE271,
	DebugUIHandlerPanel_GetPanel_m0A0D797F47E06C4AA2786605A367F93F0033291C,
	DebugUIHandlerPanel_SelectNextItem_mE8441685CAA9F387EF2CE85F0891BE31AAA02D22,
	DebugUIHandlerPanel_SelectPreviousItem_m663163976D65D0D2DC673C57045428EC6A8A3D07,
	DebugUIHandlerPanel_OnScrollbarClicked_m59907071BBE4297C3A0129488E8037487E957BD5,
	DebugUIHandlerPanel_SetScrollTarget_mBF5B2C49CA07FBD4E66F98A8A66B371548371E1D,
	DebugUIHandlerPanel_UpdateScroll_m09894F7991090ADDF2CA28D1427902B13315E2AD,
	DebugUIHandlerPanel_GetYPosInScroll_mF30290CAB64304041EE4B2F5A04CDAF03E3E7397,
	DebugUIHandlerPanel_GetFirstItem_mABA1E55122FE52BB4A783346971540AC19CF37A0,
	DebugUIHandlerPanel_ResetDebugManager_m71122CF385993479CBC5C89B730A14AB60A6A35F,
	DebugUIHandlerPanel__ctor_mB233BB0C2B6784DC0B893D1ECB6BF9E02534BB01,
	DebugUIHandlerPersistentCanvas_Toggle_m29203DB1C46DF26C0B2726B6340DB0CEC27A15D8,
	DebugUIHandlerPersistentCanvas_Clear_m2A4309CDFE971AA52847D9072DE808798DB1C580,
	DebugUIHandlerPersistentCanvas__ctor_mA5D2326C74A1A72C5E9802691ED667CF5991841E,
	U3CU3Ec__DisplayClass3_0__ctor_m36CB7670C22CE2BC7AEBDF17C15A238D1917B014,
	U3CU3Ec__DisplayClass3_0_U3CToggleU3Eb__0_mCAEB7CF73BAB66E6DDA60AF4E42AFC9F760B4B63,
	DebugUIHandlerRow_OnEnable_m49F4F79E8882BB233938663A86135EF0F997B32B,
	DebugUIHandlerRow_Update_mBE152302B758037599B09EDD65EA506773BD20DA,
	DebugUIHandlerRow__ctor_m25AA9A1DE431B4C5C7CFED066F3DC0721EB6DF32,
	DebugUIHandlerToggle_SetWidget_mB013EB6AEA2897CEA4522F3D1306B1A376C62BC8,
	DebugUIHandlerToggle_OnToggleValueChanged_m547F4E123162D824FD6BF35941CFB92DBA301B06,
	DebugUIHandlerToggle_OnSelection_mC8CB6EA7DEB61BAF4F426B059218915AEA157115,
	DebugUIHandlerToggle_OnDeselection_m5DC6563E07ABC6CD640C94827FC876D5E8068797,
	DebugUIHandlerToggle_OnAction_m4891CDA4A337AD1DA6B047E3DF4A363B2ED07ABE,
	DebugUIHandlerToggle_UpdateValueLabel_mA8DDCA729EAEF8AA280CA7746033DA73A25D2D59,
	DebugUIHandlerToggle__ctor_m7B4B26A73C24FF78F61592F9911F87650F0A7687,
	DebugUIHandlerToggleHistory_SetWidget_mF1C6F29B86AA5367D2C4B5BFF537F3F566B3E7DC,
	DebugUIHandlerToggleHistory_UpdateValueLabel_m53680DAC7821FA5564196843381D8F885E3F428D,
	DebugUIHandlerToggleHistory_RefreshAfterSanitization_mB09CBD9491CC001A16B22FD2F7333153BF612506,
	DebugUIHandlerToggleHistory__ctor_m1D0260C9C7CFB872A3E21524715444ED3F6FEFBC,
	U3CRefreshAfterSanitizationU3Ed__4__ctor_mE7A3146511E19C2501D1087E3FCFBE75837DCBAB,
	U3CRefreshAfterSanitizationU3Ed__4_System_IDisposable_Dispose_m916C7561F787139BCAAEB10C8D43BB643B125514,
	U3CRefreshAfterSanitizationU3Ed__4_MoveNext_m631C0808EE7D82FA1D6F0B8039D3AA93965C29F1,
	U3CRefreshAfterSanitizationU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mC83DF44B95C3BEFEAE450D2F2699A606E94F935F,
	U3CRefreshAfterSanitizationU3Ed__4_System_Collections_IEnumerator_Reset_m97EA3023930C1F29E1086F7D141B93ED488E219C,
	U3CRefreshAfterSanitizationU3Ed__4_System_Collections_IEnumerator_get_Current_m70EEB9C8257E30C1EB8730D7C52F5B24DD5860F1,
	DebugUIHandlerUIntField_SetWidget_mE43AAC56A1B3EE0B80878651978FA58835204D43,
	DebugUIHandlerUIntField_OnSelection_mC17408F0DF4132756C3356AC3DDB3DDE41615018,
	DebugUIHandlerUIntField_OnDeselection_m2AE7C5834668EC7592BAC21B28A92EF2B63873BE,
	DebugUIHandlerUIntField_OnIncrement_m54BF1BBC4C764649885CB3FA3FBC45B858554DB8,
	DebugUIHandlerUIntField_OnDecrement_m13F770A6F4E10B94952256F87A4E6DAA63F8AF9F,
	DebugUIHandlerUIntField_ChangeValue_m3CC1A7386C1805CF9113C4016BD888392EA1ED77,
	DebugUIHandlerUIntField_UpdateValueLabel_mC8087A6A5B7CC2A625EB2B037E7C3223EF9AE72F,
	DebugUIHandlerUIntField__ctor_mF43B3EE4A84D70A5066F52B5B50845F41BE687FC,
	DebugUIHandlerValue_OnEnable_m7038D3F49F5D49DAC0ED5F377D6A15A6EC68D69B,
	DebugUIHandlerValue_SetWidget_mA142AE7CCB143CA40E3E63E03CCED6EF916A445A,
	DebugUIHandlerValue_OnSelection_mEF84CDA2A38FA0FBC19C8E93B42542223145E36B,
	DebugUIHandlerValue_OnDeselection_m0EA789B780B5D638F66A1DACC0AE45CA94466BC3,
	DebugUIHandlerValue_Update_mE41E37D577A414A9EB1FF35937B92F4A3F5B3AFC,
	DebugUIHandlerValue__ctor_mFAC0D77BD1806745E3234F08069159AA0E89933A,
	DebugUIHandlerVBox_SetWidget_mC00F497831E97C0E451298B026A0E0015C09810D,
	DebugUIHandlerVBox_OnSelection_mF51E61D686F63DFE7788D34F438B090C83685606,
	DebugUIHandlerVBox_Next_mF6722FDBA8AD3554A1838B7FF305D0468699C7B9,
	DebugUIHandlerVBox__ctor_m64FA47D67C1E274862860178B57B7D62028779C8,
	DebugUIHandlerVector2_SetWidget_mBC7196017B1F462C0A6C4D59156725BDF0F21CFF,
	DebugUIHandlerVector2_SetValue_m62F288A92EB3B3804703359D741236CA57F01468,
	DebugUIHandlerVector2_SetupSettings_m030AF4AD168A09C5FE2447B0F7F3D560FDF74086,
	DebugUIHandlerVector2_OnSelection_m7AFD01CE9D04771B069EDA118F28905C3A2BD2BA,
	DebugUIHandlerVector2_OnDeselection_m73F49E75445B6A2B9FE2569D2BD3242E467191C5,
	DebugUIHandlerVector2_OnIncrement_m03B6B3999DB0B5E6E0AAAC929F7CF703D2C8F361,
	DebugUIHandlerVector2_OnDecrement_m863DAB569083D5930357BC892524B8E3080A392B,
	DebugUIHandlerVector2_OnAction_m50C6E7ABC27523886E25FA460DCEA1A3E3817212,
	DebugUIHandlerVector2_Next_mD9DB032D3A4C0F049B9759E5182EACECD0417EBE,
	DebugUIHandlerVector2__ctor_m7FFA0AB89BD22952D133B159892D93DFB0289C95,
	DebugUIHandlerVector2_U3CSetWidgetU3Eb__6_0_m40766D6438349BCCD397A409FD47D6DF7D627E95,
	DebugUIHandlerVector2_U3CSetWidgetU3Eb__6_1_mDC687994C1C6D34598870969A1C929ED67C3D2AD,
	DebugUIHandlerVector2_U3CSetWidgetU3Eb__6_2_mF99FF85396E7934B035370C2B77BECD5828073BF,
	DebugUIHandlerVector2_U3CSetWidgetU3Eb__6_3_mEC21ACEA4E8A9B81D5EE772B1E0117834DC3C921,
	DebugUIHandlerVector2_U3CSetupSettingsU3Eb__8_0_mE4033438C35E72EE5CBBF1F35A04BBEE9CB4B207,
	DebugUIHandlerVector2_U3CSetupSettingsU3Eb__8_1_m5098326D73A3D982ED62D3DA8F591F1CC68DEABD,
	DebugUIHandlerVector2_U3CSetupSettingsU3Eb__8_2_m6024441393B4D412E29E62645E4E3AE6E41AC107,
	DebugUIHandlerVector3_SetWidget_m51C9378CD3689FA2AE11828984E4EE630A23C092,
	DebugUIHandlerVector3_SetValue_m4D9723FBDE1075AD99708C9BDDA5F7EF1749EE02,
	DebugUIHandlerVector3_SetupSettings_m681D4F4C06C60CF01EA0305923C351134A583494,
	DebugUIHandlerVector3_OnSelection_mC678FC573B0C47D7CA67D22621B503036BF51398,
	DebugUIHandlerVector3_OnDeselection_m441D4222C4429198D8A935B78E0D83C544511023,
	DebugUIHandlerVector3_OnIncrement_mC053EC7624798FB68ED978E92BF251117E30E0D1,
	DebugUIHandlerVector3_OnDecrement_mD51DBE51C01228D2C0F1ADB74C93F0E35ECC71F3,
	DebugUIHandlerVector3_OnAction_m59987EEEA08CA2D312FCFFD4B6945A6F3F1CF351,
	DebugUIHandlerVector3_Next_mC9CB584A704F41B945432F643549DC068B8C5048,
	DebugUIHandlerVector3__ctor_mE28CE6E9E387BB4C4AD0DA6CBF3DBEA1AA3C34B6,
	DebugUIHandlerVector3_U3CSetWidgetU3Eb__7_0_mAB6B7CD5EB1A3BDAD9022F1E34F6B3E5FD6AB198,
	DebugUIHandlerVector3_U3CSetWidgetU3Eb__7_1_m6C8891791339BFC4674E7F6ACA93407BB01742E5,
	DebugUIHandlerVector3_U3CSetWidgetU3Eb__7_2_mE180B24E364395A808BDAEF108C3B5CCC7B34A8F,
	DebugUIHandlerVector3_U3CSetWidgetU3Eb__7_3_mE87B8C4818974E2A09F967C07693A5EE4E279543,
	DebugUIHandlerVector3_U3CSetWidgetU3Eb__7_4_m0A890E89CA123AF98F3675599F42983DFFF6BED3,
	DebugUIHandlerVector3_U3CSetWidgetU3Eb__7_5_m6F02ECC974164F8BD416D09591C0A7FC562D9E00,
	DebugUIHandlerVector3_U3CSetupSettingsU3Eb__9_0_m8A2F0E9E84CEDEF51C39FC2064AE4A567D536B5E,
	DebugUIHandlerVector3_U3CSetupSettingsU3Eb__9_1_m8817E674DE9AA44BDA955FCBAE74FCE86AE00D69,
	DebugUIHandlerVector3_U3CSetupSettingsU3Eb__9_2_mEF5F59D1C0046A69401A520E2EA72E08E51683A7,
	DebugUIHandlerVector4_SetWidget_m0ACF9FA8301635E697FAD1F98F39B3430ADF2F30,
	DebugUIHandlerVector4_SetValue_mDDE5A79FCB5E7FC86F7F59BFF4ED7D08B419A1ED,
	DebugUIHandlerVector4_SetupSettings_m6E1D7C8A778144AEC0FED0B4B5F65834B03CFABF,
	DebugUIHandlerVector4_OnSelection_m13FAB6F972E9526565914FC704E535C45A1D58C1,
	DebugUIHandlerVector4_OnDeselection_m848522A1837716ACEDBA77E7C40F965E7A69717C,
	DebugUIHandlerVector4_OnIncrement_m7C040482A50C8BA301CF8AECE0B380DC01AA36A4,
	DebugUIHandlerVector4_OnDecrement_mD7C8F3016A697A94C281400CC3B98A06F6E2FF69,
	DebugUIHandlerVector4_OnAction_m0189C1E29F75BC018C2D5BF6732F1EB3ABB35BD3,
	DebugUIHandlerVector4_Next_m27898CC501B5F74A1FFF47D030B187FEB2956DFF,
	DebugUIHandlerVector4__ctor_m45C4574D831F218759A99BF64E570281E91BCABC,
	DebugUIHandlerVector4_U3CSetWidgetU3Eb__8_0_m08BEFA85D371D04F0B038DF845898F2B2E1361CC,
	DebugUIHandlerVector4_U3CSetWidgetU3Eb__8_1_mB0D840131A3B9F0174D378AAB9C31B2D46EFCBA8,
	DebugUIHandlerVector4_U3CSetWidgetU3Eb__8_2_m259CA925AB02780A7FC19E6E00ECD27A8D9492EB,
	DebugUIHandlerVector4_U3CSetWidgetU3Eb__8_3_m43586D00F180DB14B0A50C3470181CE50013D28C,
	DebugUIHandlerVector4_U3CSetWidgetU3Eb__8_4_mEE993AC3EDBF96F1A45843A1AAC8CD4600128D19,
	DebugUIHandlerVector4_U3CSetWidgetU3Eb__8_5_m2380D05D15DD6A2D525A4465ADFF4D1C8F0C21E7,
	DebugUIHandlerVector4_U3CSetWidgetU3Eb__8_6_mB5AE87731664D5FF4407F389918BCAE29C29E66F,
	DebugUIHandlerVector4_U3CSetWidgetU3Eb__8_7_mFC96D46A98F25512F5BE486E12F504F4ACC1D592,
	DebugUIHandlerVector4_U3CSetupSettingsU3Eb__10_0_m2294F14B1936842ABAD989616BD8FFFB9D19960C,
	DebugUIHandlerVector4_U3CSetupSettingsU3Eb__10_1_m87F6A7549919BF2D29BED6A03DCFB2F5A5CE30D3,
	DebugUIHandlerVector4_U3CSetupSettingsU3Eb__10_2_m33E9FAAEBEE26FA4A43E670F562C48F3169CFEFF,
	DebugUIHandlerWidget_get_parentUIHandler_m2F40C42629AB71EDAEE402C22FE160B76D78D8AE,
	DebugUIHandlerWidget_set_parentUIHandler_mF23913A3178CA556A5709A8E5782585240A4E784,
	DebugUIHandlerWidget_get_previousUIHandler_m618D35DF8E71F7E7EEAD6ED05F77EA51A5214C34,
	DebugUIHandlerWidget_set_previousUIHandler_m7F60E1430A65740C8EFCCD87F1724CB08BE2F422,
	DebugUIHandlerWidget_get_nextUIHandler_m2DFDEE3BE43A204B29BC39087AF60AA86D09BE90,
	DebugUIHandlerWidget_set_nextUIHandler_m84F82CC75B6BCF91986150F4DE1D96D963E78CC8,
	DebugUIHandlerWidget_OnEnable_m97D5414C310F4E3DB00053EEE5DADBFED53C960C,
	DebugUIHandlerWidget_SetWidget_mEE5CAA4C4DCDD02ACBF70B35B23F81CF8DE60F5A,
	DebugUIHandlerWidget_GetWidget_m2B98AD3E32CE71B3F39C93BD7E7C0BEA5897033C,
	NULL,
	DebugUIHandlerWidget_OnSelection_m378D3DE45EB78D9C684239E3D9B53DF27D257F27,
	DebugUIHandlerWidget_OnDeselection_mBF3AF27B21F180E69D3A57D44CB26F7CB20ECCD9,
	DebugUIHandlerWidget_OnAction_m5561D81BF72FC055972C2D14BC92E221EA9294EC,
	DebugUIHandlerWidget_OnIncrement_m4128084E64169D31815E5C0BF79DB25A08A75F22,
	DebugUIHandlerWidget_OnDecrement_mEFF4903ADBBEE2E4C99AE09FFD83718DBBA12894,
	DebugUIHandlerWidget_Previous_mE43110A6F1E2AABBCE916D5CDE8523E7C543E4E3,
	DebugUIHandlerWidget_Next_mCCCE23E0DBA851BCF1D6169678B52037FE5D9DC3,
	DebugUIHandlerWidget__ctor_m2105E00AE3370003AE9303EDDA5ABB544CE420E5,
	UIFoldout_Start_m031F3AF5DA5840E25AB29B054311BABBC425FA7D,
	UIFoldout_OnValidate_mE61A4777FD785B1EC726B57B32C96C2E88767E4C,
	UIFoldout_SetState_m041BAB7EB961B7D84E99C388E6405D4B62FEFC32,
	UIFoldout_SetState_m169A04E74F6DFC0F376CD2D233CA5111E6F165B8,
	UIFoldout__ctor_mD1494EF8AB928679E6683D9C1C58B6953EB2D1E8,
};
extern void Brick__ctor_mF1384DE2A301E1649AA0B75AF1726649F330500B_AdjustorThunk (void);
extern void Brick_Equals_m51973370DE321FB79FE83BA500E6100A3676A62C_AdjustorThunk (void);
extern void BrickChunkAlloc_flattenIndex_mDDF83B6500BFACBB3DF4327BD285E912749664DD_AdjustorThunk (void);
extern void DataLocation_Cleanup_mD3D6DFF36870590F6A6DEBAB39E65BF71BB17FBF_AdjustorThunk (void);
extern void IndexMetaData_Pack_mD890E178B9204BB2B438B3AF6D328086BDAF7056_AdjustorThunk (void);
extern void Volume__ctor_m157BAF82255C35F2C38F19544B2E95570161E332_AdjustorThunk (void);
extern void Volume__ctor_m4FDB6EEEA74A5B99555110CAA3B12282432CC15D_AdjustorThunk (void);
extern void Volume__ctor_m0746CD2A7E66B698B86D7486756406F7F3FAB857_AdjustorThunk (void);
extern void Volume_CalculateAABB_mBDDD2C2420FDF8879AA3E83BAEBB3D2888AACFB4_AdjustorThunk (void);
extern void Volume_CalculateCenterAndSize_m1DADCCCFB55DCDFD8BEC9FBBA0C566D7E4DA0E4A_AdjustorThunk (void);
extern void Volume_Transform_m12D69F2254CDE720482AAC13285DF1204D3147A9_AdjustorThunk (void);
extern void Volume_ToString_m98DA1A8AE24508B153D48275417D33006A179D54_AdjustorThunk (void);
extern void Volume_Equals_m0779B6B9E04131377F97A134517B72F4FFA82D3E_AdjustorThunk (void);
extern void RegId_IsValid_m36BF6BB4B5534FCE342CC11E1EE32774E60C59B4_AdjustorThunk (void);
extern void RegId_Invalidate_m1933F3829E449BAB0908DCE60AA6C1612FB0D8BA_AdjustorThunk (void);
extern void RegId_Equals_m42741BC96AB73BD66C8E071FC56669D05BE78681_AdjustorThunk (void);
extern void RegId_GetHashCode_m85D1E25F3792C7049063C2A7C4C1AC7D2F6FE449_AdjustorThunk (void);
extern void RendererList_get_isValid_mD49D7348F5E73DD10528CA33E7E47D045F59ABA4_AdjustorThunk (void);
extern void RendererList_set_isValid_m5A13F01C3632E0EA366E89F731C758D9416458E4_AdjustorThunk (void);
extern void RendererListDesc_get_cullingResult_m1A24ED379AEDF626576FD7D25A2C4C7EC731583D_AdjustorThunk (void);
extern void RendererListDesc_set_cullingResult_mE8327030ABADA58F7278D2E0A53AA24B85FE0D38_AdjustorThunk (void);
extern void RendererListDesc_get_camera_mA2374241B35A95DCE62E723B25CC991D6DF44360_AdjustorThunk (void);
extern void RendererListDesc_set_camera_m5622A8534724C11905739E4717F697C4E79A50C3_AdjustorThunk (void);
extern void RendererListDesc_get_passName_m2ABCDEA61E228A46952E7F12895B65C10AB874FA_AdjustorThunk (void);
extern void RendererListDesc_set_passName_m48E2013C7D08B499D53125C5791F9FF5540F9BD0_AdjustorThunk (void);
extern void RendererListDesc_get_passNames_mC78CE5AC5BAB6381686AEB1CCDBAAFDEEB020FC0_AdjustorThunk (void);
extern void RendererListDesc_set_passNames_m1E72B7C01C5EA221BE6CEE9694384319FD67919C_AdjustorThunk (void);
extern void RendererListDesc__ctor_mEDAF51BE78BCD5D4F4A2055C75B52C0BDB7448C2_AdjustorThunk (void);
extern void RendererListDesc__ctor_mD7954B9620C618E46313FE4AACDAE9A777652794_AdjustorThunk (void);
extern void RendererListDesc_IsValid_m424FC29A8206B9F2D11EC1C937762D1E1ABACAA5_AdjustorThunk (void);
extern void RenderGraphExecution__ctor_m6F5D9030833807A2480E493C092CD067D6CD042E_AdjustorThunk (void);
extern void RenderGraphExecution_Dispose_m2A4832CC0BAA3642B791D033538C6E97FBAE3D67_AdjustorThunk (void);
extern void CompiledResourceInfo_Reset_m37F299281DE9EEB99B9ADBC35125F59765D77A7E_AdjustorThunk (void);
extern void CompiledPassInfo_get_allowPassCulling_m19A371EF46D18F2FB95B569004344184EE159F3A_AdjustorThunk (void);
extern void CompiledPassInfo_Reset_mD739628D66EE219B4039E42DC685D5AAD09FCCD5_AdjustorThunk (void);
extern void RenderGraphProfilingScope__ctor_m33361E4872EC1955DC1C93B1252729C6F8AF2086_AdjustorThunk (void);
extern void RenderGraphProfilingScope_Dispose_mF856703A7FA42EB3DDBE8EA78BA08DCEF8AAC971_AdjustorThunk (void);
extern void RenderGraphProfilingScope_Dispose_mD7AE540A4B899A562FD851CFABAFE458F1E9A5A7_AdjustorThunk (void);
extern void RenderGraphBuilder_UseColorBuffer_mBAFAA9789D8E5085F01F2E8798746E0A4C48D5B3_AdjustorThunk (void);
extern void RenderGraphBuilder_UseDepthBuffer_m52A44A353C52E10E3DBFAF26A87F86EB08310604_AdjustorThunk (void);
extern void RenderGraphBuilder_ReadTexture_m30A338D1203C736F18E9EDFE24A4208384D0925F_AdjustorThunk (void);
extern void RenderGraphBuilder_WriteTexture_m506070A8AC6CD4948CBB01FC02E2B2FF2D002920_AdjustorThunk (void);
extern void RenderGraphBuilder_ReadWriteTexture_mEA66A932C42979F8EE0C1F402E5A6ED084F01836_AdjustorThunk (void);
extern void RenderGraphBuilder_CreateTransientTexture_m703B7C4E31B2F4B2857E05B8FE4E9993157163D0_AdjustorThunk (void);
extern void RenderGraphBuilder_CreateTransientTexture_mC507AB02FE73C2F38389C79D9099EDC7F704688C_AdjustorThunk (void);
extern void RenderGraphBuilder_UseRendererList_mB0614B837677977DF8A14FDBF95146A74B3EE284_AdjustorThunk (void);
extern void RenderGraphBuilder_ReadComputeBuffer_mA630B01D686BE9AB88772818404667D1E69F05D4_AdjustorThunk (void);
extern void RenderGraphBuilder_WriteComputeBuffer_mCD7FAF2B083871011645D4CCD2E4A92781F7B495_AdjustorThunk (void);
extern void RenderGraphBuilder_CreateTransientComputeBuffer_mCFBDA8024544593AFE98147876B902E4753AFB7D_AdjustorThunk (void);
extern void RenderGraphBuilder_CreateTransientComputeBuffer_m59F48C032018CBE9FF26DCDF27C57B002F2B9A1D_AdjustorThunk (void);
extern void RenderGraphBuilder_EnableAsyncCompute_mE27B28C6B8176AD36DBB5B4EE0DA800D90F87B03_AdjustorThunk (void);
extern void RenderGraphBuilder_AllowPassCulling_m123C799CF19AF7D92A976CCC235C6721F1D8EE86_AdjustorThunk (void);
extern void RenderGraphBuilder_Dispose_m6CD2A0E7451C1E81E016C27394732E07F6C53071_AdjustorThunk (void);
extern void RenderGraphBuilder_AllowRendererListCulling_m1D4E879CAC013591F860F5C429D007D6ACF692F2_AdjustorThunk (void);
extern void RenderGraphBuilder_DependsOn_mBF3A650716934BE44D1314668B1EC60CB1A62426_AdjustorThunk (void);
extern void RenderGraphBuilder__ctor_m356E87D6D032DF11F1909F32C011B98CFB16D7DE_AdjustorThunk (void);
extern void RenderGraphBuilder_Dispose_m49A9299AD6BF815801312F85C7B6256C5575085B_AdjustorThunk (void);
extern void RenderGraphBuilder_CheckResource_m5BF5C4956D9B0FA14EBBE35D84650212A2F0F7C6_AdjustorThunk (void);
extern void RenderGraphBuilder_GenerateDebugData_mA7FBEB0EDD92133A1B737F8805349D57A368B6FC_AdjustorThunk (void);
extern void RenderGraphLogIndent__ctor_mB06A09F318DD57E80FDF39F5C443C9703BFB3822_AdjustorThunk (void);
extern void RenderGraphLogIndent_Dispose_m0FFDA3A98E3E736D7A3784C9E9D5C6A97707B2B6_AdjustorThunk (void);
extern void RenderGraphLogIndent_Dispose_mEA306BC46A6C7A416418B1798FBF749A9F2031DC_AdjustorThunk (void);
extern void ComputeBufferHandle__ctor_m6D965D9809C5D3C7F5F385E54890EE463A81776D_AdjustorThunk (void);
extern void ComputeBufferHandle_IsValid_m4D3C4E81EFDD8940200E2B823024D85C6DA8517A_AdjustorThunk (void);
extern void ComputeBufferDesc__ctor_mD364A4B1CBED57C895863DAEC68E88D5F3AEC8FD_AdjustorThunk (void);
extern void ComputeBufferDesc__ctor_m6E762AFC03BBCCB7D7C7B4ECF3D718D7C5606664_AdjustorThunk (void);
extern void ComputeBufferDesc_GetHashCode_m55AB43EE5444280A59027570E310275097E3BDB9_AdjustorThunk (void);
extern void RendererListHandle_get_handle_m4D239A48FFDBFA551B8BE7A4448BF19370EEB848_AdjustorThunk (void);
extern void RendererListHandle_set_handle_m0DE76F63C96B25082DA109CB2C5C9EBB99F6D0E3_AdjustorThunk (void);
extern void RendererListHandle__ctor_mCFD25579FE4F4D3687533BE4A366128E0E23B0AF_AdjustorThunk (void);
extern void RendererListHandle_IsValid_m39DD764115038D342C81E04B5475E957246B08A1_AdjustorThunk (void);
extern void RendererListResource__ctor_mC9EDE12FC17F2685835A6A57E9EF3FEF1629D15A_AdjustorThunk (void);
extern void ResourceHandle_get_index_m91DB2195EB1D4B5AF1D37FF737C8B6EF8B4E9E50_AdjustorThunk (void);
extern void ResourceHandle_get_type_m2A8AF5AC268B8068DF6EB721B4D28A6A82B0C88B_AdjustorThunk (void);
extern void ResourceHandle_set_type_m4626071A3B159FDD69989F2C9591A8977CB6454E_AdjustorThunk (void);
extern void ResourceHandle_get_iType_mE93479F8B75DD94FF1B32AC5FAF7E6F923DC63C5_AdjustorThunk (void);
extern void ResourceHandle__ctor_m43993F666EE5128E896AE562EB4AE65263831C5F_AdjustorThunk (void);
extern void ResourceHandle_IsValid_mBC26F92EEC475A8B75722BA104A462E16C6337A2_AdjustorThunk (void);
extern void TextureHandle__ctor_mC6D0A6B896CC0E8589B88D370869149649031FB0_AdjustorThunk (void);
extern void TextureHandle_IsValid_m3C2D8F8EB70206A09F3FFADDDD230E00C25269D9_AdjustorThunk (void);
extern void TextureHandle_SetFallBackResource_m63C811961161AB0BD5C7ECC272EBEF26ABE84EBE_AdjustorThunk (void);
extern void TextureDesc_InitDefaultValues_mF4DA67529813E66310182D684D50A9FCCA4BE911_AdjustorThunk (void);
extern void TextureDesc__ctor_mAA4AB396BD886053C637CC275E7839B887B44FA3_AdjustorThunk (void);
extern void TextureDesc__ctor_m7DD9D0AB2E909E3E014FA3BFE0433235881031E0_AdjustorThunk (void);
extern void TextureDesc__ctor_m524B5F82F524BB71949F24E0436876092BE8B0E0_AdjustorThunk (void);
extern void TextureDesc__ctor_m55D6822C811DB1361730AA8C0E28564C62F95699_AdjustorThunk (void);
extern void TextureDesc_GetHashCode_m84A013881648FFDEBA578DC743BA617C812130E0_AdjustorThunk (void);
extern void FixedBufferStringQueue_get_Count_mD76761535F559C02B70B4D5D2307258723BB34F9_AdjustorThunk (void);
extern void FixedBufferStringQueue_set_Count_m6E44F205107949D343D9C9D27F6CD2BB225D6667_AdjustorThunk (void);
extern void FixedBufferStringQueue__ctor_m02082DF6032DA322E64476C0C762A17BCC4F26DC_AdjustorThunk (void);
extern void FixedBufferStringQueue_TryPush_m72D763782852C157100DBA747E8F137F4B6B3149_AdjustorThunk (void);
extern void FixedBufferStringQueue_TryPop_mF2BA587E26D93B58FB0BAD59C5125E9E6FB80F09_AdjustorThunk (void);
extern void FixedBufferStringQueue_Clear_m0B3FFD74689701A352CD3EDFA9C85E9D28ED6DF0_AdjustorThunk (void);
extern void UintKeyGetter_Get_m76C2635B8A8D4EFDFCF2157D5A691B9C0D7F6141_AdjustorThunk (void);
extern void ProfilingScope__ctor_mE15813DF7651C1A3B6AFD6465AD4B973E8F1DBFC_AdjustorThunk (void);
extern void ProfilingScope_Dispose_m4231A2ACA1F8E345BB0078310A9F7601704C8BE4_AdjustorThunk (void);
extern void ProfilingSample__ctor_m1F041AA9D15F1B83BDA8B9BA973392D79106B5C1_AdjustorThunk (void);
extern void ProfilingSample__ctor_m281FEAFD2CCCF7A43BE856DAD483F4E46A72B7EA_AdjustorThunk (void);
extern void ProfilingSample__ctor_m50B1BED1079C106B8AE90117F4E866912C3C4E08_AdjustorThunk (void);
extern void ProfilingSample_Dispose_mD2A4D24A23C63449743B485DEAE2DE4EE240AA40_AdjustorThunk (void);
extern void ProfilingSample_Dispose_m59C08E493C70FAD0777836566F3FCF8A2889E388_AdjustorThunk (void);
extern void SphericalHarmonicsL1_Equals_m156AFF698A92A9425070CFD50F115A1EE6E9CC92_AdjustorThunk (void);
extern void SphericalHarmonicsL1_GetHashCode_mF419FC901C4CF663FCC3E728A7E7BFC7F9DBB5FA_AdjustorThunk (void);
extern void AtlasNode__ctor_mFFF2DBE5F81BD41BFF58E221F82DA5D3EF3B8C05_AdjustorThunk (void);
extern void AtlasNode_IsOccupied_m4DAB3793E66F89B97D1521DA6A639A0B16C8BEE1_AdjustorThunk (void);
extern void AtlasNode_SetIsOccupied_mDE0F696F9119A0A840D300CFF9BFDC5844C37DEB_AdjustorThunk (void);
extern void AtlasNode_ClearIsOccupied_m15C4CF7573BF45C8472AAE6C72D93496F69F74B6_AdjustorThunk (void);
extern void AtlasNode_IsLeafNode_m026D9501AB6E24CF82AD67D96AD9B08F164F5925_AdjustorThunk (void);
extern void AtlasNode_Allocate_mA96F58D6ED00C8AED33E570BD38FC508D11A3A07_AdjustorThunk (void);
extern void AtlasNode_ReleaseChildren_m1B0112B1DD2DCFF5E204BE80B8F7C9BC91E7BB6B_AdjustorThunk (void);
extern void AtlasNode_ReleaseAndMerge_mF3EA698E178F2042996A9C630D05723A4B3E11AF_AdjustorThunk (void);
extern void AtlasNode_IsMergeNeeded_m70B87CDC5F874B42D73D0A5D889F7E86AD44A8AE_AdjustorThunk (void);
extern void BitArray8_get_capacity_mA3B76B8563ED73CE2ACAA6248BB1659EFE18EE01_AdjustorThunk (void);
extern void BitArray8_get_allFalse_m90DB2959D94946C2EFE34547AD6E2B8F10168463_AdjustorThunk (void);
extern void BitArray8_get_allTrue_m793F5AAF8F83DAB21C0308F738147A29FFF08451_AdjustorThunk (void);
extern void BitArray8_get_humanizedData_mF2404C0DEFF15E9DA20FC99071CA3A5900F4E791_AdjustorThunk (void);
extern void BitArray8_get_Item_m4A05F5141C4554B92AE97D5487224C7840EC4D53_AdjustorThunk (void);
extern void BitArray8_set_Item_m547A700177E97C60883197FE03D3DD03CBDE5F08_AdjustorThunk (void);
extern void BitArray8__ctor_m86747787EF4C4E385B761101DD9B40EF6174F69A_AdjustorThunk (void);
extern void BitArray8__ctor_m831CBA0141A7161831057654C9363F50C0AF6151_AdjustorThunk (void);
extern void BitArray8_BitAnd_mB8BFBCC7ED08AE63C8DCD56F224FC2A887666536_AdjustorThunk (void);
extern void BitArray8_BitOr_m18AF19D6C292BF095EDC795C3018099B3A8CD121_AdjustorThunk (void);
extern void BitArray8_BitNot_mB1E3ADFBDB897ED040CE28C797CD868DE95B9B26_AdjustorThunk (void);
extern void BitArray8_Equals_m86ADBD06E76F1B28D197017F091F13F063B453EB_AdjustorThunk (void);
extern void BitArray8_GetHashCode_m0226A2FAF19B61AEBC5CC60F87DC272CCCF20A77_AdjustorThunk (void);
extern void BitArray16_get_capacity_mA5EE007A81C601C9A3552D8A504747CD6BBF5B9D_AdjustorThunk (void);
extern void BitArray16_get_allFalse_mB74A351DF512549357B62F578F8745861E768BCA_AdjustorThunk (void);
extern void BitArray16_get_allTrue_mA4CFAC20D5338EA36278D5762FEF1879DEF44298_AdjustorThunk (void);
extern void BitArray16_get_humanizedData_m12F476DEF544F28CCD2579475DE167820BD88E87_AdjustorThunk (void);
extern void BitArray16_get_Item_mCA32C50FD252F47DCBFD7262435245238430A180_AdjustorThunk (void);
extern void BitArray16_set_Item_m9457F4B8745BC1C5285574EE23FDD05A4BA2F088_AdjustorThunk (void);
extern void BitArray16__ctor_m4A508EBDA58B7006D1463EAE199114B2D2E1249C_AdjustorThunk (void);
extern void BitArray16__ctor_m337D042A8EE2131DED83B273A8CC47843E17CBF6_AdjustorThunk (void);
extern void BitArray16_BitAnd_mD1AFD4C59ED599951E61A3E8BA716D5A3FFD04EC_AdjustorThunk (void);
extern void BitArray16_BitOr_mD788B0B73A61E66973D6B4160729C868D5BE8B35_AdjustorThunk (void);
extern void BitArray16_BitNot_m7FB6BD7B74C796E05A9E7BA6FFEF58F6F23F10BC_AdjustorThunk (void);
extern void BitArray16_Equals_mD170A00318A901D23C1F17444D5022FF947586D2_AdjustorThunk (void);
extern void BitArray16_GetHashCode_m018CAECA54A403343CE08C2F4225670FE5780E6D_AdjustorThunk (void);
extern void BitArray32_get_capacity_m312BE2BAA06E75492376361E9299510314755AE5_AdjustorThunk (void);
extern void BitArray32_get_allFalse_m01D83A39CE7D6FBDEA9D5E57044285FF55E8260F_AdjustorThunk (void);
extern void BitArray32_get_allTrue_m9AA64C6C9B386B1806BD0A9F83113055AA0967EB_AdjustorThunk (void);
extern void BitArray32_get_humanizedVersion_m56C96176FE170F18CEC3327A7D19E1A774325228_AdjustorThunk (void);
extern void BitArray32_get_humanizedData_m38DE7DAE7EE5527EC6C6FDD518253031DFF2374F_AdjustorThunk (void);
extern void BitArray32_get_Item_mC8CEDEAB87139CA781BADBD4FBB1E84930F19FFE_AdjustorThunk (void);
extern void BitArray32_set_Item_m6248824F85F4FCD452DE48E6B714AEB52D07AF44_AdjustorThunk (void);
extern void BitArray32__ctor_m0982C7BD4F185BA648120E2ADA794E7D778B995D_AdjustorThunk (void);
extern void BitArray32__ctor_m410177CA4D679011D0A4653FC28A4B83B39A1EF1_AdjustorThunk (void);
extern void BitArray32_BitAnd_m050354D3A87E2A90324EEB8AA7D1156A482E058A_AdjustorThunk (void);
extern void BitArray32_BitOr_mFB1856DBA7D371F7C6C04FD475577C3A9E15D62F_AdjustorThunk (void);
extern void BitArray32_BitNot_mA3731229D50D6F6F4ACB1B80EB1EBA5610C656E8_AdjustorThunk (void);
extern void BitArray32_Equals_mE94B4571565F0D7243127EB6070E76B8A958781C_AdjustorThunk (void);
extern void BitArray32_GetHashCode_m918359D3BC8DF9C6F2BA72085B422BED8B7AA5EC_AdjustorThunk (void);
extern void BitArray64_get_capacity_mE0D7937E14B27EFB5580F024329871EA9F6F61A9_AdjustorThunk (void);
extern void BitArray64_get_allFalse_m066B324DA3D868A839C4C000E923D590D09FC40B_AdjustorThunk (void);
extern void BitArray64_get_allTrue_mD2AA9BCA8BD30CEE7F6648362CA4493BC81318CF_AdjustorThunk (void);
extern void BitArray64_get_humanizedData_m3D2C299930B49D326C92EE0B0BA574DFF3C74891_AdjustorThunk (void);
extern void BitArray64_get_Item_m44EA8594329A57FA9400342251411BCE62B54453_AdjustorThunk (void);
extern void BitArray64_set_Item_mDEB0D2418675CD4FEAA1CDBDDDEA70A5CD35E44D_AdjustorThunk (void);
extern void BitArray64__ctor_m41D38225ACEAF7A0D4201AB8AE9F781CD736DA04_AdjustorThunk (void);
extern void BitArray64__ctor_m8745536B9B0A03C956553C54B7F425604CF60E37_AdjustorThunk (void);
extern void BitArray64_BitAnd_m578053826382B2ACB7E67872F4DB1E475C12B707_AdjustorThunk (void);
extern void BitArray64_BitOr_mC80A8A2E27FE8E3614F1ECFB64C7D38BFA7ADC10_AdjustorThunk (void);
extern void BitArray64_BitNot_mDEA129C39BEEE912882F8F2F6D79277ED3B2CED6_AdjustorThunk (void);
extern void BitArray64_Equals_m302E3D444E2E2F74D865409C90AD08ECF3228498_AdjustorThunk (void);
extern void BitArray64_GetHashCode_mC01786968B8E26CD78AF9F6BA8D9DDFA1A56AB14_AdjustorThunk (void);
extern void BitArray128_get_capacity_mF8B9300884F70FA7D2E5424DF4B844F98224105B_AdjustorThunk (void);
extern void BitArray128_get_allFalse_mD54F8D614FE56898CAC736E0D471E03CF27DE84D_AdjustorThunk (void);
extern void BitArray128_get_allTrue_m613B6531E734903771CB400313E3C58324095EC3_AdjustorThunk (void);
extern void BitArray128_get_humanizedData_mFBE6722FC3146F9439687F1D23B26B8BBA497588_AdjustorThunk (void);
extern void BitArray128_get_Item_m2056FC3D3AE3A6650545407C0961C91621453676_AdjustorThunk (void);
extern void BitArray128_set_Item_mACDC728AC1CA0A2114008187840DC3242CC0C8E8_AdjustorThunk (void);
extern void BitArray128__ctor_m269F0551193B6E3990A4BC6209012C6BF6D9A867_AdjustorThunk (void);
extern void BitArray128__ctor_m48BF375FF417816E116009DA45CF3B498929AF4B_AdjustorThunk (void);
extern void BitArray128_BitAnd_m573069987C6CD28B9045D0A34BB9384A7D943404_AdjustorThunk (void);
extern void BitArray128_BitOr_m0621F3B8EB34A40324EE7559AA4B3104B04264F1_AdjustorThunk (void);
extern void BitArray128_BitNot_m9D31DF47F85C778B39C77B7FC96725F5B7DAFCF5_AdjustorThunk (void);
extern void BitArray128_Equals_m7BBE0682933DA4AB8B2605AD8428AE845154C5C2_AdjustorThunk (void);
extern void BitArray128_GetHashCode_mB8C12AF9AAC59655B4AFA06D4A0F204157FF5320_AdjustorThunk (void);
extern void BitArray256_get_capacity_mBEEC883503CA5B2F2ED0E5EE4E917B3E20902676_AdjustorThunk (void);
extern void BitArray256_get_allFalse_mC89BB118740CCF24F251D5C89DC15C54E02137CF_AdjustorThunk (void);
extern void BitArray256_get_allTrue_m7467D31E9239CA8F8D067A048A272424855A8139_AdjustorThunk (void);
extern void BitArray256_get_humanizedData_m35B5547DD137D862F789A03722AA192DA3E1B748_AdjustorThunk (void);
extern void BitArray256_get_Item_m97E7E356A32515F35B77F5310BCB350A63EF0287_AdjustorThunk (void);
extern void BitArray256_set_Item_mE6BF23C525D050DF66970DFFAB563A34323226B2_AdjustorThunk (void);
extern void BitArray256__ctor_m0D5A2405F5460958E0CDEFE16C962079B8DAD5DC_AdjustorThunk (void);
extern void BitArray256__ctor_m67548173CE100A6542C2BD45BD9D04B04760B0A4_AdjustorThunk (void);
extern void BitArray256_BitAnd_mDC9F06C7E0E0BA44380F19BADCE0C54CA6301A1F_AdjustorThunk (void);
extern void BitArray256_BitOr_m991E6FDFEF4405D82BBFC2F907B9F7B0AEB9CE66_AdjustorThunk (void);
extern void BitArray256_BitNot_m2DB60E7421D37CB7808A363E0B23D579A61B993E_AdjustorThunk (void);
extern void BitArray256_Equals_m6723D6D291F588EDD9861D7C58247F246E94417F_AdjustorThunk (void);
extern void BitArray256_GetHashCode_mCB0868DFC6212118B07731906DAB0BBF2AC38F7C_AdjustorThunk (void);
extern void VolumeIsolationScope__ctor_m01620738B9C04C8237155E3843C60A195C179498_AdjustorThunk (void);
extern void VolumeIsolationScope_System_IDisposable_Dispose_m1351187D1678129A678C6AAD3FCD237147438BC4_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[193] = 
{
	{ 0x06000030, Brick__ctor_mF1384DE2A301E1649AA0B75AF1726649F330500B_AdjustorThunk },
	{ 0x06000031, Brick_Equals_m51973370DE321FB79FE83BA500E6100A3676A62C_AdjustorThunk },
	{ 0x0600004A, BrickChunkAlloc_flattenIndex_mDDF83B6500BFACBB3DF4327BD285E912749664DD_AdjustorThunk },
	{ 0x0600004B, DataLocation_Cleanup_mD3D6DFF36870590F6A6DEBAB39E65BF71BB17FBF_AdjustorThunk },
	{ 0x06000058, IndexMetaData_Pack_mD890E178B9204BB2B438B3AF6D328086BDAF7056_AdjustorThunk },
	{ 0x060000B1, Volume__ctor_m157BAF82255C35F2C38F19544B2E95570161E332_AdjustorThunk },
	{ 0x060000B2, Volume__ctor_m4FDB6EEEA74A5B99555110CAA3B12282432CC15D_AdjustorThunk },
	{ 0x060000B3, Volume__ctor_m0746CD2A7E66B698B86D7486756406F7F3FAB857_AdjustorThunk },
	{ 0x060000B4, Volume_CalculateAABB_mBDDD2C2420FDF8879AA3E83BAEBB3D2888AACFB4_AdjustorThunk },
	{ 0x060000B5, Volume_CalculateCenterAndSize_m1DADCCCFB55DCDFD8BEC9FBBA0C566D7E4DA0E4A_AdjustorThunk },
	{ 0x060000B6, Volume_Transform_m12D69F2254CDE720482AAC13285DF1204D3147A9_AdjustorThunk },
	{ 0x060000B7, Volume_ToString_m98DA1A8AE24508B153D48275417D33006A179D54_AdjustorThunk },
	{ 0x060000B8, Volume_Equals_m0779B6B9E04131377F97A134517B72F4FFA82D3E_AdjustorThunk },
	{ 0x060000B9, RegId_IsValid_m36BF6BB4B5534FCE342CC11E1EE32774E60C59B4_AdjustorThunk },
	{ 0x060000BA, RegId_Invalidate_m1933F3829E449BAB0908DCE60AA6C1612FB0D8BA_AdjustorThunk },
	{ 0x060000BD, RegId_Equals_m42741BC96AB73BD66C8E071FC56669D05BE78681_AdjustorThunk },
	{ 0x060000BE, RegId_GetHashCode_m85D1E25F3792C7049063C2A7C4C1AC7D2F6FE449_AdjustorThunk },
	{ 0x060000F1, RendererList_get_isValid_mD49D7348F5E73DD10528CA33E7E47D045F59ABA4_AdjustorThunk },
	{ 0x060000F2, RendererList_set_isValid_m5A13F01C3632E0EA366E89F731C758D9416458E4_AdjustorThunk },
	{ 0x060000F5, RendererListDesc_get_cullingResult_m1A24ED379AEDF626576FD7D25A2C4C7EC731583D_AdjustorThunk },
	{ 0x060000F6, RendererListDesc_set_cullingResult_mE8327030ABADA58F7278D2E0A53AA24B85FE0D38_AdjustorThunk },
	{ 0x060000F7, RendererListDesc_get_camera_mA2374241B35A95DCE62E723B25CC991D6DF44360_AdjustorThunk },
	{ 0x060000F8, RendererListDesc_set_camera_m5622A8534724C11905739E4717F697C4E79A50C3_AdjustorThunk },
	{ 0x060000F9, RendererListDesc_get_passName_m2ABCDEA61E228A46952E7F12895B65C10AB874FA_AdjustorThunk },
	{ 0x060000FA, RendererListDesc_set_passName_m48E2013C7D08B499D53125C5791F9FF5540F9BD0_AdjustorThunk },
	{ 0x060000FB, RendererListDesc_get_passNames_mC78CE5AC5BAB6381686AEB1CCDBAAFDEEB020FC0_AdjustorThunk },
	{ 0x060000FC, RendererListDesc_set_passNames_m1E72B7C01C5EA221BE6CEE9694384319FD67919C_AdjustorThunk },
	{ 0x060000FD, RendererListDesc__ctor_mEDAF51BE78BCD5D4F4A2055C75B52C0BDB7448C2_AdjustorThunk },
	{ 0x060000FE, RendererListDesc__ctor_mD7954B9620C618E46313FE4AACDAE9A777652794_AdjustorThunk },
	{ 0x060000FF, RendererListDesc_IsValid_m424FC29A8206B9F2D11EC1C937762D1E1ABACAA5_AdjustorThunk },
	{ 0x06000101, RenderGraphExecution__ctor_m6F5D9030833807A2480E493C092CD067D6CD042E_AdjustorThunk },
	{ 0x06000102, RenderGraphExecution_Dispose_m2A4832CC0BAA3642B791D033538C6E97FBAE3D67_AdjustorThunk },
	{ 0x06000164, CompiledResourceInfo_Reset_m37F299281DE9EEB99B9ADBC35125F59765D77A7E_AdjustorThunk },
	{ 0x06000165, CompiledPassInfo_get_allowPassCulling_m19A371EF46D18F2FB95B569004344184EE159F3A_AdjustorThunk },
	{ 0x06000166, CompiledPassInfo_Reset_mD739628D66EE219B4039E42DC685D5AAD09FCCD5_AdjustorThunk },
	{ 0x06000174, RenderGraphProfilingScope__ctor_m33361E4872EC1955DC1C93B1252729C6F8AF2086_AdjustorThunk },
	{ 0x06000175, RenderGraphProfilingScope_Dispose_mF856703A7FA42EB3DDBE8EA78BA08DCEF8AAC971_AdjustorThunk },
	{ 0x06000176, RenderGraphProfilingScope_Dispose_mD7AE540A4B899A562FD851CFABAFE458F1E9A5A7_AdjustorThunk },
	{ 0x06000177, RenderGraphBuilder_UseColorBuffer_mBAFAA9789D8E5085F01F2E8798746E0A4C48D5B3_AdjustorThunk },
	{ 0x06000178, RenderGraphBuilder_UseDepthBuffer_m52A44A353C52E10E3DBFAF26A87F86EB08310604_AdjustorThunk },
	{ 0x06000179, RenderGraphBuilder_ReadTexture_m30A338D1203C736F18E9EDFE24A4208384D0925F_AdjustorThunk },
	{ 0x0600017A, RenderGraphBuilder_WriteTexture_m506070A8AC6CD4948CBB01FC02E2B2FF2D002920_AdjustorThunk },
	{ 0x0600017B, RenderGraphBuilder_ReadWriteTexture_mEA66A932C42979F8EE0C1F402E5A6ED084F01836_AdjustorThunk },
	{ 0x0600017C, RenderGraphBuilder_CreateTransientTexture_m703B7C4E31B2F4B2857E05B8FE4E9993157163D0_AdjustorThunk },
	{ 0x0600017D, RenderGraphBuilder_CreateTransientTexture_mC507AB02FE73C2F38389C79D9099EDC7F704688C_AdjustorThunk },
	{ 0x0600017E, RenderGraphBuilder_UseRendererList_mB0614B837677977DF8A14FDBF95146A74B3EE284_AdjustorThunk },
	{ 0x0600017F, RenderGraphBuilder_ReadComputeBuffer_mA630B01D686BE9AB88772818404667D1E69F05D4_AdjustorThunk },
	{ 0x06000180, RenderGraphBuilder_WriteComputeBuffer_mCD7FAF2B083871011645D4CCD2E4A92781F7B495_AdjustorThunk },
	{ 0x06000181, RenderGraphBuilder_CreateTransientComputeBuffer_mCFBDA8024544593AFE98147876B902E4753AFB7D_AdjustorThunk },
	{ 0x06000182, RenderGraphBuilder_CreateTransientComputeBuffer_m59F48C032018CBE9FF26DCDF27C57B002F2B9A1D_AdjustorThunk },
	{ 0x06000184, RenderGraphBuilder_EnableAsyncCompute_mE27B28C6B8176AD36DBB5B4EE0DA800D90F87B03_AdjustorThunk },
	{ 0x06000185, RenderGraphBuilder_AllowPassCulling_m123C799CF19AF7D92A976CCC235C6721F1D8EE86_AdjustorThunk },
	{ 0x06000186, RenderGraphBuilder_Dispose_m6CD2A0E7451C1E81E016C27394732E07F6C53071_AdjustorThunk },
	{ 0x06000187, RenderGraphBuilder_AllowRendererListCulling_m1D4E879CAC013591F860F5C429D007D6ACF692F2_AdjustorThunk },
	{ 0x06000188, RenderGraphBuilder_DependsOn_mBF3A650716934BE44D1314668B1EC60CB1A62426_AdjustorThunk },
	{ 0x06000189, RenderGraphBuilder__ctor_m356E87D6D032DF11F1909F32C011B98CFB16D7DE_AdjustorThunk },
	{ 0x0600018A, RenderGraphBuilder_Dispose_m49A9299AD6BF815801312F85C7B6256C5575085B_AdjustorThunk },
	{ 0x0600018B, RenderGraphBuilder_CheckResource_m5BF5C4956D9B0FA14EBBE35D84650212A2F0F7C6_AdjustorThunk },
	{ 0x0600018C, RenderGraphBuilder_GenerateDebugData_mA7FBEB0EDD92133A1B737F8805349D57A368B6FC_AdjustorThunk },
	{ 0x060001A4, RenderGraphLogIndent__ctor_mB06A09F318DD57E80FDF39F5C443C9703BFB3822_AdjustorThunk },
	{ 0x060001A5, RenderGraphLogIndent_Dispose_m0FFDA3A98E3E736D7A3784C9E9D5C6A97707B2B6_AdjustorThunk },
	{ 0x060001A6, RenderGraphLogIndent_Dispose_mEA306BC46A6C7A416418B1798FBF749A9F2031DC_AdjustorThunk },
	{ 0x060001E6, ComputeBufferHandle__ctor_m6D965D9809C5D3C7F5F385E54890EE463A81776D_AdjustorThunk },
	{ 0x060001E8, ComputeBufferHandle_IsValid_m4D3C4E81EFDD8940200E2B823024D85C6DA8517A_AdjustorThunk },
	{ 0x060001EA, ComputeBufferDesc__ctor_mD364A4B1CBED57C895863DAEC68E88D5F3AEC8FD_AdjustorThunk },
	{ 0x060001EB, ComputeBufferDesc__ctor_m6E762AFC03BBCCB7D7C7B4ECF3D718D7C5606664_AdjustorThunk },
	{ 0x060001EC, ComputeBufferDesc_GetHashCode_m55AB43EE5444280A59027570E310275097E3BDB9_AdjustorThunk },
	{ 0x0600024F, RendererListHandle_get_handle_m4D239A48FFDBFA551B8BE7A4448BF19370EEB848_AdjustorThunk },
	{ 0x06000250, RendererListHandle_set_handle_m0DE76F63C96B25082DA109CB2C5C9EBB99F6D0E3_AdjustorThunk },
	{ 0x06000251, RendererListHandle__ctor_mCFD25579FE4F4D3687533BE4A366128E0E23B0AF_AdjustorThunk },
	{ 0x06000254, RendererListHandle_IsValid_m39DD764115038D342C81E04B5475E957246B08A1_AdjustorThunk },
	{ 0x06000255, RendererListResource__ctor_mC9EDE12FC17F2685835A6A57E9EF3FEF1629D15A_AdjustorThunk },
	{ 0x06000256, ResourceHandle_get_index_m91DB2195EB1D4B5AF1D37FF737C8B6EF8B4E9E50_AdjustorThunk },
	{ 0x06000257, ResourceHandle_get_type_m2A8AF5AC268B8068DF6EB721B4D28A6A82B0C88B_AdjustorThunk },
	{ 0x06000258, ResourceHandle_set_type_m4626071A3B159FDD69989F2C9591A8977CB6454E_AdjustorThunk },
	{ 0x06000259, ResourceHandle_get_iType_mE93479F8B75DD94FF1B32AC5FAF7E6F923DC63C5_AdjustorThunk },
	{ 0x0600025A, ResourceHandle__ctor_m43993F666EE5128E896AE562EB4AE65263831C5F_AdjustorThunk },
	{ 0x0600025C, ResourceHandle_IsValid_mBC26F92EEC475A8B75722BA104A462E16C6337A2_AdjustorThunk },
	{ 0x06000271, TextureHandle__ctor_mC6D0A6B896CC0E8589B88D370869149649031FB0_AdjustorThunk },
	{ 0x06000276, TextureHandle_IsValid_m3C2D8F8EB70206A09F3FFADDDD230E00C25269D9_AdjustorThunk },
	{ 0x06000277, TextureHandle_SetFallBackResource_m63C811961161AB0BD5C7ECC272EBEF26ABE84EBE_AdjustorThunk },
	{ 0x06000279, TextureDesc_InitDefaultValues_mF4DA67529813E66310182D684D50A9FCCA4BE911_AdjustorThunk },
	{ 0x0600027A, TextureDesc__ctor_mAA4AB396BD886053C637CC275E7839B887B44FA3_AdjustorThunk },
	{ 0x0600027B, TextureDesc__ctor_m7DD9D0AB2E909E3E014FA3BFE0433235881031E0_AdjustorThunk },
	{ 0x0600027C, TextureDesc__ctor_m524B5F82F524BB71949F24E0436876092BE8B0E0_AdjustorThunk },
	{ 0x0600027D, TextureDesc__ctor_m55D6822C811DB1361730AA8C0E28564C62F95699_AdjustorThunk },
	{ 0x0600027E, TextureDesc_GetHashCode_m84A013881648FFDEBA578DC743BA617C812130E0_AdjustorThunk },
	{ 0x060002E3, FixedBufferStringQueue_get_Count_mD76761535F559C02B70B4D5D2307258723BB34F9_AdjustorThunk },
	{ 0x060002E4, FixedBufferStringQueue_set_Count_m6E44F205107949D343D9C9D27F6CD2BB225D6667_AdjustorThunk },
	{ 0x060002E5, FixedBufferStringQueue__ctor_m02082DF6032DA322E64476C0C762A17BCC4F26DC_AdjustorThunk },
	{ 0x060002E6, FixedBufferStringQueue_TryPush_m72D763782852C157100DBA747E8F137F4B6B3149_AdjustorThunk },
	{ 0x060002E7, FixedBufferStringQueue_TryPop_mF2BA587E26D93B58FB0BAD59C5125E9E6FB80F09_AdjustorThunk },
	{ 0x060002E8, FixedBufferStringQueue_Clear_m0B3FFD74689701A352CD3EDFA9C85E9D28ED6DF0_AdjustorThunk },
	{ 0x060002EB, UintKeyGetter_Get_m76C2635B8A8D4EFDFCF2157D5A691B9C0D7F6141_AdjustorThunk },
	{ 0x060004AF, ProfilingScope__ctor_mE15813DF7651C1A3B6AFD6465AD4B973E8F1DBFC_AdjustorThunk },
	{ 0x060004B0, ProfilingScope_Dispose_m4231A2ACA1F8E345BB0078310A9F7601704C8BE4_AdjustorThunk },
	{ 0x060004B1, ProfilingSample__ctor_m1F041AA9D15F1B83BDA8B9BA973392D79106B5C1_AdjustorThunk },
	{ 0x060004B2, ProfilingSample__ctor_m281FEAFD2CCCF7A43BE856DAD483F4E46A72B7EA_AdjustorThunk },
	{ 0x060004B3, ProfilingSample__ctor_m50B1BED1079C106B8AE90117F4E866912C3C4E08_AdjustorThunk },
	{ 0x060004B4, ProfilingSample_Dispose_mD2A4D24A23C63449743B485DEAE2DE4EE240AA40_AdjustorThunk },
	{ 0x060004B5, ProfilingSample_Dispose_m59C08E493C70FAD0777836566F3FCF8A2889E388_AdjustorThunk },
	{ 0x060004C1, SphericalHarmonicsL1_Equals_m156AFF698A92A9425070CFD50F115A1EE6E9CC92_AdjustorThunk },
	{ 0x060004C2, SphericalHarmonicsL1_GetHashCode_mF419FC901C4CF663FCC3E728A7E7BFC7F9DBB5FA_AdjustorThunk },
	{ 0x060005B9, AtlasNode__ctor_mFFF2DBE5F81BD41BFF58E221F82DA5D3EF3B8C05_AdjustorThunk },
	{ 0x060005BA, AtlasNode_IsOccupied_m4DAB3793E66F89B97D1521DA6A639A0B16C8BEE1_AdjustorThunk },
	{ 0x060005BB, AtlasNode_SetIsOccupied_mDE0F696F9119A0A840D300CFF9BFDC5844C37DEB_AdjustorThunk },
	{ 0x060005BC, AtlasNode_ClearIsOccupied_m15C4CF7573BF45C8472AAE6C72D93496F69F74B6_AdjustorThunk },
	{ 0x060005BD, AtlasNode_IsLeafNode_m026D9501AB6E24CF82AD67D96AD9B08F164F5925_AdjustorThunk },
	{ 0x060005BE, AtlasNode_Allocate_mA96F58D6ED00C8AED33E570BD38FC508D11A3A07_AdjustorThunk },
	{ 0x060005BF, AtlasNode_ReleaseChildren_m1B0112B1DD2DCFF5E204BE80B8F7C9BC91E7BB6B_AdjustorThunk },
	{ 0x060005C0, AtlasNode_ReleaseAndMerge_mF3EA698E178F2042996A9C630D05723A4B3E11AF_AdjustorThunk },
	{ 0x060005C1, AtlasNode_IsMergeNeeded_m70B87CDC5F874B42D73D0A5D889F7E86AD44A8AE_AdjustorThunk },
	{ 0x060005E8, BitArray8_get_capacity_mA3B76B8563ED73CE2ACAA6248BB1659EFE18EE01_AdjustorThunk },
	{ 0x060005E9, BitArray8_get_allFalse_m90DB2959D94946C2EFE34547AD6E2B8F10168463_AdjustorThunk },
	{ 0x060005EA, BitArray8_get_allTrue_m793F5AAF8F83DAB21C0308F738147A29FFF08451_AdjustorThunk },
	{ 0x060005EB, BitArray8_get_humanizedData_mF2404C0DEFF15E9DA20FC99071CA3A5900F4E791_AdjustorThunk },
	{ 0x060005EC, BitArray8_get_Item_m4A05F5141C4554B92AE97D5487224C7840EC4D53_AdjustorThunk },
	{ 0x060005ED, BitArray8_set_Item_m547A700177E97C60883197FE03D3DD03CBDE5F08_AdjustorThunk },
	{ 0x060005EE, BitArray8__ctor_m86747787EF4C4E385B761101DD9B40EF6174F69A_AdjustorThunk },
	{ 0x060005EF, BitArray8__ctor_m831CBA0141A7161831057654C9363F50C0AF6151_AdjustorThunk },
	{ 0x060005F3, BitArray8_BitAnd_mB8BFBCC7ED08AE63C8DCD56F224FC2A887666536_AdjustorThunk },
	{ 0x060005F4, BitArray8_BitOr_m18AF19D6C292BF095EDC795C3018099B3A8CD121_AdjustorThunk },
	{ 0x060005F5, BitArray8_BitNot_mB1E3ADFBDB897ED040CE28C797CD868DE95B9B26_AdjustorThunk },
	{ 0x060005F8, BitArray8_Equals_m86ADBD06E76F1B28D197017F091F13F063B453EB_AdjustorThunk },
	{ 0x060005F9, BitArray8_GetHashCode_m0226A2FAF19B61AEBC5CC60F87DC272CCCF20A77_AdjustorThunk },
	{ 0x060005FA, BitArray16_get_capacity_mA5EE007A81C601C9A3552D8A504747CD6BBF5B9D_AdjustorThunk },
	{ 0x060005FB, BitArray16_get_allFalse_mB74A351DF512549357B62F578F8745861E768BCA_AdjustorThunk },
	{ 0x060005FC, BitArray16_get_allTrue_mA4CFAC20D5338EA36278D5762FEF1879DEF44298_AdjustorThunk },
	{ 0x060005FD, BitArray16_get_humanizedData_m12F476DEF544F28CCD2579475DE167820BD88E87_AdjustorThunk },
	{ 0x060005FE, BitArray16_get_Item_mCA32C50FD252F47DCBFD7262435245238430A180_AdjustorThunk },
	{ 0x060005FF, BitArray16_set_Item_m9457F4B8745BC1C5285574EE23FDD05A4BA2F088_AdjustorThunk },
	{ 0x06000600, BitArray16__ctor_m4A508EBDA58B7006D1463EAE199114B2D2E1249C_AdjustorThunk },
	{ 0x06000601, BitArray16__ctor_m337D042A8EE2131DED83B273A8CC47843E17CBF6_AdjustorThunk },
	{ 0x06000605, BitArray16_BitAnd_mD1AFD4C59ED599951E61A3E8BA716D5A3FFD04EC_AdjustorThunk },
	{ 0x06000606, BitArray16_BitOr_mD788B0B73A61E66973D6B4160729C868D5BE8B35_AdjustorThunk },
	{ 0x06000607, BitArray16_BitNot_m7FB6BD7B74C796E05A9E7BA6FFEF58F6F23F10BC_AdjustorThunk },
	{ 0x0600060A, BitArray16_Equals_mD170A00318A901D23C1F17444D5022FF947586D2_AdjustorThunk },
	{ 0x0600060B, BitArray16_GetHashCode_m018CAECA54A403343CE08C2F4225670FE5780E6D_AdjustorThunk },
	{ 0x0600060C, BitArray32_get_capacity_m312BE2BAA06E75492376361E9299510314755AE5_AdjustorThunk },
	{ 0x0600060D, BitArray32_get_allFalse_m01D83A39CE7D6FBDEA9D5E57044285FF55E8260F_AdjustorThunk },
	{ 0x0600060E, BitArray32_get_allTrue_m9AA64C6C9B386B1806BD0A9F83113055AA0967EB_AdjustorThunk },
	{ 0x0600060F, BitArray32_get_humanizedVersion_m56C96176FE170F18CEC3327A7D19E1A774325228_AdjustorThunk },
	{ 0x06000610, BitArray32_get_humanizedData_m38DE7DAE7EE5527EC6C6FDD518253031DFF2374F_AdjustorThunk },
	{ 0x06000611, BitArray32_get_Item_mC8CEDEAB87139CA781BADBD4FBB1E84930F19FFE_AdjustorThunk },
	{ 0x06000612, BitArray32_set_Item_m6248824F85F4FCD452DE48E6B714AEB52D07AF44_AdjustorThunk },
	{ 0x06000613, BitArray32__ctor_m0982C7BD4F185BA648120E2ADA794E7D778B995D_AdjustorThunk },
	{ 0x06000614, BitArray32__ctor_m410177CA4D679011D0A4653FC28A4B83B39A1EF1_AdjustorThunk },
	{ 0x06000615, BitArray32_BitAnd_m050354D3A87E2A90324EEB8AA7D1156A482E058A_AdjustorThunk },
	{ 0x06000616, BitArray32_BitOr_mFB1856DBA7D371F7C6C04FD475577C3A9E15D62F_AdjustorThunk },
	{ 0x06000617, BitArray32_BitNot_mA3731229D50D6F6F4ACB1B80EB1EBA5610C656E8_AdjustorThunk },
	{ 0x0600061D, BitArray32_Equals_mE94B4571565F0D7243127EB6070E76B8A958781C_AdjustorThunk },
	{ 0x0600061E, BitArray32_GetHashCode_m918359D3BC8DF9C6F2BA72085B422BED8B7AA5EC_AdjustorThunk },
	{ 0x0600061F, BitArray64_get_capacity_mE0D7937E14B27EFB5580F024329871EA9F6F61A9_AdjustorThunk },
	{ 0x06000620, BitArray64_get_allFalse_m066B324DA3D868A839C4C000E923D590D09FC40B_AdjustorThunk },
	{ 0x06000621, BitArray64_get_allTrue_mD2AA9BCA8BD30CEE7F6648362CA4493BC81318CF_AdjustorThunk },
	{ 0x06000622, BitArray64_get_humanizedData_m3D2C299930B49D326C92EE0B0BA574DFF3C74891_AdjustorThunk },
	{ 0x06000623, BitArray64_get_Item_m44EA8594329A57FA9400342251411BCE62B54453_AdjustorThunk },
	{ 0x06000624, BitArray64_set_Item_mDEB0D2418675CD4FEAA1CDBDDDEA70A5CD35E44D_AdjustorThunk },
	{ 0x06000625, BitArray64__ctor_m41D38225ACEAF7A0D4201AB8AE9F781CD736DA04_AdjustorThunk },
	{ 0x06000626, BitArray64__ctor_m8745536B9B0A03C956553C54B7F425604CF60E37_AdjustorThunk },
	{ 0x0600062A, BitArray64_BitAnd_m578053826382B2ACB7E67872F4DB1E475C12B707_AdjustorThunk },
	{ 0x0600062B, BitArray64_BitOr_mC80A8A2E27FE8E3614F1ECFB64C7D38BFA7ADC10_AdjustorThunk },
	{ 0x0600062C, BitArray64_BitNot_mDEA129C39BEEE912882F8F2F6D79277ED3B2CED6_AdjustorThunk },
	{ 0x0600062F, BitArray64_Equals_m302E3D444E2E2F74D865409C90AD08ECF3228498_AdjustorThunk },
	{ 0x06000630, BitArray64_GetHashCode_mC01786968B8E26CD78AF9F6BA8D9DDFA1A56AB14_AdjustorThunk },
	{ 0x06000631, BitArray128_get_capacity_mF8B9300884F70FA7D2E5424DF4B844F98224105B_AdjustorThunk },
	{ 0x06000632, BitArray128_get_allFalse_mD54F8D614FE56898CAC736E0D471E03CF27DE84D_AdjustorThunk },
	{ 0x06000633, BitArray128_get_allTrue_m613B6531E734903771CB400313E3C58324095EC3_AdjustorThunk },
	{ 0x06000634, BitArray128_get_humanizedData_mFBE6722FC3146F9439687F1D23B26B8BBA497588_AdjustorThunk },
	{ 0x06000635, BitArray128_get_Item_m2056FC3D3AE3A6650545407C0961C91621453676_AdjustorThunk },
	{ 0x06000636, BitArray128_set_Item_mACDC728AC1CA0A2114008187840DC3242CC0C8E8_AdjustorThunk },
	{ 0x06000637, BitArray128__ctor_m269F0551193B6E3990A4BC6209012C6BF6D9A867_AdjustorThunk },
	{ 0x06000638, BitArray128__ctor_m48BF375FF417816E116009DA45CF3B498929AF4B_AdjustorThunk },
	{ 0x0600063C, BitArray128_BitAnd_m573069987C6CD28B9045D0A34BB9384A7D943404_AdjustorThunk },
	{ 0x0600063D, BitArray128_BitOr_m0621F3B8EB34A40324EE7559AA4B3104B04264F1_AdjustorThunk },
	{ 0x0600063E, BitArray128_BitNot_m9D31DF47F85C778B39C77B7FC96725F5B7DAFCF5_AdjustorThunk },
	{ 0x06000641, BitArray128_Equals_m7BBE0682933DA4AB8B2605AD8428AE845154C5C2_AdjustorThunk },
	{ 0x06000642, BitArray128_GetHashCode_mB8C12AF9AAC59655B4AFA06D4A0F204157FF5320_AdjustorThunk },
	{ 0x06000643, BitArray256_get_capacity_mBEEC883503CA5B2F2ED0E5EE4E917B3E20902676_AdjustorThunk },
	{ 0x06000644, BitArray256_get_allFalse_mC89BB118740CCF24F251D5C89DC15C54E02137CF_AdjustorThunk },
	{ 0x06000645, BitArray256_get_allTrue_m7467D31E9239CA8F8D067A048A272424855A8139_AdjustorThunk },
	{ 0x06000646, BitArray256_get_humanizedData_m35B5547DD137D862F789A03722AA192DA3E1B748_AdjustorThunk },
	{ 0x06000647, BitArray256_get_Item_m97E7E356A32515F35B77F5310BCB350A63EF0287_AdjustorThunk },
	{ 0x06000648, BitArray256_set_Item_mE6BF23C525D050DF66970DFFAB563A34323226B2_AdjustorThunk },
	{ 0x06000649, BitArray256__ctor_m0D5A2405F5460958E0CDEFE16C962079B8DAD5DC_AdjustorThunk },
	{ 0x0600064A, BitArray256__ctor_m67548173CE100A6542C2BD45BD9D04B04760B0A4_AdjustorThunk },
	{ 0x0600064E, BitArray256_BitAnd_mDC9F06C7E0E0BA44380F19BADCE0C54CA6301A1F_AdjustorThunk },
	{ 0x0600064F, BitArray256_BitOr_m991E6FDFEF4405D82BBFC2F907B9F7B0AEB9CE66_AdjustorThunk },
	{ 0x06000650, BitArray256_BitNot_m2DB60E7421D37CB7808A363E0B23D579A61B993E_AdjustorThunk },
	{ 0x06000653, BitArray256_Equals_m6723D6D291F588EDD9861D7C58247F246E94417F_AdjustorThunk },
	{ 0x06000654, BitArray256_GetHashCode_mCB0868DFC6212118B07731906DAB0BBF2AC38F7C_AdjustorThunk },
	{ 0x06000772, VolumeIsolationScope__ctor_m01620738B9C04C8237155E3843C60A195C179498_AdjustorThunk },
	{ 0x06000773, VolumeIsolationScope_System_IDisposable_Dispose_m1351187D1678129A678C6AAD3FCD237147438BC4_AdjustorThunk },
};
static const int32_t s_InvokerIndices[2333] = 
{
	6698,
	6698,
	6698,
	6698,
	6698,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6536,
	5230,
	6687,
	6569,
	5261,
	6687,
	5370,
	10941,
	5261,
	2886,
	5711,
	6698,
	6698,
	1076,
	6698,
	6536,
	5230,
	6536,
	3626,
	5230,
	6698,
	6698,
	3004,
	2958,
	5144,
	6698,
	1697,
	1242,
	175,
	3007,
	2958,
	1078,
	542,
	1077,
	2956,
	4687,
	6698,
	4691,
	6698,
	4691,
	6536,
	5230,
	1378,
	6698,
	6536,
	6536,
	6536,
	6536,
	6688,
	5144,
	6698,
	2605,
	5261,
	1096,
	10995,
	8222,
	7055,
	8759,
	470,
	6698,
	1697,
	6698,
	6536,
	5230,
	6688,
	6688,
	3729,
	1521,
	3729,
	2770,
	5230,
	6698,
	5144,
	6698,
	5144,
	6698,
	6618,
	6618,
	6536,
	6536,
	11786,
	5230,
	5144,
	5305,
	5230,
	6698,
	6536,
	5261,
	2870,
	2085,
	5261,
	5261,
	5261,
	6698,
	2926,
	5261,
	6698,
	6698,
	1126,
	2075,
	5305,
	5305,
	1378,
	5370,
	6698,
	6814,
	1515,
	5230,
	10652,
	4763,
	6628,
	6628,
	6560,
	6812,
	6536,
	3689,
	4763,
	6628,
	6618,
	6698,
	1098,
	5535,
	2873,
	6698,
	6569,
	6569,
	5261,
	2870,
	6698,
	0,
	0,
	6698,
	5305,
	1270,
	5261,
	6698,
	6698,
	6698,
	11833,
	6618,
	5305,
	6618,
	5305,
	6628,
	5316,
	6618,
	5305,
	6536,
	5230,
	6536,
	5230,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6536,
	5230,
	6698,
	6698,
	3652,
	6698,
	1409,
	281,
	5536,
	6463,
	2306,
	5252,
	6569,
	4694,
	6618,
	6698,
	9492,
	9492,
	4427,
	6536,
	6698,
	11833,
	6698,
	6628,
	6628,
	6628,
	6628,
	6536,
	6536,
	6698,
	6536,
	6536,
	6628,
	6628,
	6698,
	4427,
	6698,
	6698,
	6536,
	6536,
	6628,
	4427,
	6569,
	6698,
	6698,
	6698,
	2605,
	6698,
	6569,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	3944,
	2870,
	2870,
	6698,
	6698,
	6698,
	3939,
	2870,
	6698,
	11833,
	6698,
	11833,
	6698,
	3959,
	6618,
	5305,
	10874,
	11833,
	6473,
	5169,
	6569,
	5261,
	6625,
	5312,
	6569,
	5261,
	1501,
	1417,
	6618,
	6698,
	5261,
	6698,
	2870,
	5261,
	6698,
	6618,
	5305,
	6618,
	5305,
	6618,
	5305,
	6618,
	5305,
	6698,
	6698,
	11833,
	0,
	0,
	0,
	0,
	6698,
	6698,
	6569,
	5261,
	11812,
	11021,
	6569,
	5261,
	6698,
	5261,
	6698,
	11786,
	3939,
	6698,
	4813,
	4814,
	4811,
	2270,
	5352,
	4815,
	2306,
	4810,
	4017,
	3303,
	3302,
	3302,
	3301,
	0,
	0,
	4004,
	6698,
	5261,
	5261,
	6569,
	6698,
	6698,
	5261,
	11016,
	11016,
	11016,
	11016,
	11016,
	11016,
	11016,
	11016,
	2862,
	6698,
	6698,
	6698,
	456,
	914,
	1696,
	3576,
	3576,
	3576,
	6698,
	6698,
	4427,
	5230,
	6698,
	6698,
	3272,
	5261,
	2311,
	6698,
	2312,
	2312,
	2312,
	6698,
	6698,
	6698,
	6698,
	5144,
	6698,
	3939,
	2312,
	6698,
	6698,
	11833,
	6698,
	6618,
	5261,
	6698,
	2865,
	5261,
	1168,
	5261,
	2865,
	2870,
	856,
	5261,
	11833,
	6698,
	2870,
	2870,
	2870,
	6698,
	5305,
	2269,
	2269,
	4811,
	4811,
	4811,
	4811,
	4811,
	4017,
	3302,
	3302,
	3302,
	3302,
	0,
	5305,
	5305,
	6698,
	5305,
	4017,
	1449,
	5305,
	2314,
	5305,
	6666,
	5352,
	6666,
	5352,
	6666,
	5352,
	6666,
	5352,
	6666,
	5352,
	6666,
	5352,
	6666,
	5352,
	6666,
	5352,
	6666,
	5352,
	6666,
	5352,
	6698,
	6698,
	5261,
	2862,
	6698,
	5305,
	5261,
	5230,
	5230,
	2870,
	3939,
	6569,
	6698,
	6698,
	0,
	6569,
	6698,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	6569,
	5261,
	6536,
	5230,
	6569,
	5261,
	6618,
	5305,
	6618,
	5305,
	6666,
	5352,
	6569,
	5261,
	6536,
	5230,
	6536,
	5230,
	6618,
	5305,
	6618,
	5305,
	6698,
	6698,
	5144,
	5144,
	5144,
	5296,
	5296,
	5305,
	5305,
	5305,
	5305,
	2936,
	2936,
	0,
	0,
	0,
	0,
	0,
	11755,
	2635,
	10810,
	6618,
	11833,
	2579,
	1378,
	6536,
	6569,
	6698,
	5230,
	5261,
	6698,
	5261,
	5261,
	6698,
	5261,
	3939,
	3870,
	6569,
	3652,
	5230,
	6698,
	0,
	0,
	0,
	0,
	6698,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	11786,
	11016,
	3924,
	4303,
	4013,
	3924,
	6698,
	2870,
	5230,
	5230,
	6698,
	5144,
	2579,
	5144,
	3924,
	1932,
	4303,
	2044,
	4303,
	4303,
	2044,
	3576,
	4813,
	2270,
	5352,
	4814,
	2269,
	6536,
	3924,
	4809,
	2308,
	4017,
	3303,
	1621,
	3301,
	6536,
	3924,
	2579,
	6698,
	1425,
	2870,
	1425,
	2870,
	5144,
	5144,
	5144,
	1466,
	5305,
	6698,
	6698,
	6698,
	6698,
	2865,
	2870,
	856,
	5261,
	2912,
	6698,
	5230,
	0,
	6698,
	6536,
	5230,
	5230,
	10659,
	10875,
	6618,
	5144,
	6536,
	6536,
	5230,
	6536,
	1381,
	10660,
	6618,
	11012,
	11833,
	5261,
	6569,
	6618,
	6698,
	6618,
	6698,
	5261,
	5230,
	6698,
	5261,
	5261,
	6536,
	6698,
	0,
	0,
	0,
	0,
	11823,
	2635,
	10873,
	10833,
	10833,
	10833,
	6618,
	5352,
	11833,
	2914,
	960,
	1509,
	1463,
	5351,
	6536,
	6569,
	6698,
	5230,
	5261,
	6698,
	5261,
	5261,
	6698,
	5261,
	3939,
	3870,
	6569,
	3652,
	5230,
	6698,
	6698,
	6698,
	6536,
	6569,
	5230,
	6698,
	6536,
	5230,
	6536,
	5230,
	6698,
	6698,
	6698,
	6698,
	6698,
	11786,
	10821,
	11016,
	11833,
	11833,
	6698,
	5261,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	11833,
	11016,
	6698,
	11833,
	0,
	6698,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	6698,
	6698,
	0,
	0,
	9691,
	9137,
	7057,
	8708,
	8821,
	8669,
	9675,
	9769,
	9636,
	7542,
	8098,
	8033,
	8824,
	0,
	0,
	0,
	0,
	0,
	6966,
	0,
	8777,
	0,
	10895,
	6536,
	5230,
	2311,
	4427,
	4303,
	6698,
	0,
	0,
	3576,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2865,
	6628,
	1946,
	4764,
	6698,
	6618,
	5305,
	6686,
	5369,
	5305,
	6618,
	6618,
	10821,
	5230,
	6536,
	11786,
	6698,
	11816,
	5200,
	6685,
	1288,
	9769,
	9769,
	11012,
	11833,
	9780,
	5305,
	8809,
	2341,
	6618,
	6618,
	6618,
	6618,
	6698,
	4850,
	4850,
	2282,
	6628,
	6686,
	4766,
	11833,
	11770,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	6569,
	5261,
	5261,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	11816,
	11023,
	11816,
	11812,
	11812,
	11786,
	11786,
	11778,
	11808,
	11778,
	11778,
	6698,
	6698,
	6698,
	2605,
	5230,
	5230,
	6698,
	4763,
	6618,
	6618,
	6698,
	11786,
	6698,
	6569,
	5261,
	5261,
	5261,
	5261,
	5261,
	5261,
	6618,
	5305,
	6618,
	5305,
	6618,
	5305,
	6618,
	5305,
	6698,
	6698,
	6698,
	6698,
	5261,
	5261,
	6536,
	5261,
	2878,
	5261,
	6698,
	5261,
	5261,
	5230,
	6364,
	861,
	5261,
	5261,
	3939,
	1946,
	11833,
	11833,
	6698,
	5305,
	6698,
	6569,
	6698,
	6618,
	5305,
	6628,
	5316,
	2644,
	2879,
	6698,
	5261,
	6698,
	0,
	11786,
	929,
	930,
	462,
	930,
	6698,
	6698,
	6569,
	6569,
	6569,
	6569,
	6698,
	6698,
	6569,
	5261,
	6569,
	5261,
	6698,
	2870,
	6698,
	2870,
	2870,
	6536,
	6618,
	6569,
	5261,
	6569,
	5261,
	6698,
	1030,
	6618,
	6569,
	5261,
	3939,
	5305,
	6698,
	6698,
	6698,
	2635,
	4395,
	6569,
	2870,
	2870,
	6698,
	6569,
	5261,
	6569,
	5261,
	6536,
	5230,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6618,
	6618,
	6618,
	6618,
	6698,
	6536,
	5585,
	6698,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	6569,
	5261,
	6698,
	6569,
	5261,
	6698,
	6569,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	6698,
	6569,
	5261,
	6536,
	4395,
	6698,
	3626,
	6698,
	3626,
	6698,
	4766,
	6698,
	10821,
	10821,
	11833,
	6698,
	3939,
	6569,
	5261,
	6569,
	5261,
	6536,
	5230,
	5261,
	6698,
	6698,
	6698,
	11833,
	6698,
	3939,
	6569,
	5261,
	6536,
	3626,
	6698,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6698,
	3290,
	6698,
	6698,
	6698,
	6698,
	6698,
	6536,
	5230,
	6569,
	5261,
	6536,
	5230,
	6569,
	6618,
	6618,
	6618,
	6618,
	6569,
	5261,
	5261,
	5261,
	6698,
	2870,
	2870,
	6698,
	6536,
	3652,
	11833,
	6698,
	5261,
	11833,
	11021,
	11833,
	11833,
	11021,
	6698,
	3939,
	6698,
	6698,
	6698,
	6698,
	6698,
	11786,
	6698,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	11786,
	6698,
	6698,
	2278,
	6685,
	4846,
	6698,
	0,
	0,
	0,
	5261,
	5261,
	5261,
	6618,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	5305,
	6628,
	6536,
	6628,
	6536,
	6628,
	6536,
	6698,
	2870,
	6698,
	1449,
	1449,
	1449,
	6698,
	5305,
	2870,
	11786,
	9255,
	6698,
	0,
	9530,
	9530,
	9529,
	9529,
	9453,
	9453,
	4427,
	6536,
	11833,
	8150,
	7194,
	9681,
	9681,
	9681,
	9681,
	8068,
	8743,
	9570,
	6698,
	6698,
	11833,
	11833,
	11786,
	6569,
	6569,
	6618,
	5261,
	11816,
	9518,
	8019,
	9518,
	9518,
	8018,
	9518,
	9518,
	6949,
	8025,
	7445,
	8027,
	9565,
	6882,
	6881,
	5261,
	7142,
	8603,
	8024,
	9558,
	11833,
	9516,
	9516,
	9518,
	7143,
	9516,
	6569,
	5261,
	4764,
	6698,
	6698,
	6698,
	6698,
	11833,
	6698,
	6628,
	5316,
	6536,
	5230,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6536,
	5230,
	6628,
	5316,
	6698,
	6569,
	6569,
	6698,
	27,
	269,
	269,
	2605,
	29,
	29,
	6536,
	6536,
	6589,
	1932,
	1387,
	5230,
	2579,
	2579,
	3626,
	2275,
	6698,
	5305,
	6698,
	6698,
	6698,
	231,
	6536,
	6536,
	2286,
	8612,
	271,
	271,
	271,
	271,
	271,
	1411,
	4844,
	210,
	6698,
	4427,
	1243,
	894,
	1210,
	6618,
	7882,
	8354,
	11833,
	6698,
	1656,
	5144,
	6698,
	6685,
	5368,
	6618,
	5305,
	6686,
	5369,
	6589,
	6569,
	6603,
	6569,
	6618,
	5261,
	10872,
	10821,
	10821,
	5261,
	5261,
	5293,
	6536,
	6698,
	4850,
	6686,
	1045,
	1468,
	2878,
	11778,
	11778,
	11802,
	6883,
	6885,
	6884,
	10821,
	10821,
	10824,
	9264,
	10821,
	9693,
	11016,
	11021,
	9693,
	9693,
	9548,
	11833,
	2865,
	4850,
	1181,
	4849,
	6589,
	6698,
	6698,
	2579,
	5261,
	5261,
	2579,
	2579,
	1381,
	4842,
	5305,
	2862,
	5261,
	6536,
	6536,
	5305,
	1381,
	4,
	6,
	5,
	4,
	3939,
	3939,
	3941,
	1948,
	10821,
	6569,
	1381,
	1195,
	6698,
	838,
	5144,
	6698,
	11833,
	6698,
	5261,
	5261,
	11778,
	6569,
	144,
	6698,
	6698,
	5261,
	1697,
	4427,
	2085,
	271,
	2635,
	5230,
	271,
	271,
	530,
	210,
	891,
	878,
	1722,
	3652,
	1722,
	1196,
	2005,
	2004,
	4848,
	2089,
	1247,
	1235,
	132,
	442,
	434,
	11833,
	1378,
	874,
	5230,
	6698,
	3932,
	916,
	5229,
	6698,
	6698,
	3382,
	5229,
	2349,
	6618,
	6698,
	6698,
	6618,
	1112,
	5261,
	5261,
	4427,
	6569,
	951,
	953,
	6698,
	6698,
	1235,
	2004,
	434,
	5230,
	11012,
	11778,
	11812,
	11778,
	11786,
	11786,
	11786,
	11786,
	11786,
	11786,
	11786,
	9775,
	9255,
	9255,
	9255,
	10821,
	11833,
	0,
	9675,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	6536,
	6618,
	6618,
	6569,
	4395,
	2635,
	5305,
	5261,
	10571,
	9041,
	9041,
	3939,
	3939,
	6569,
	9357,
	9357,
	4427,
	6536,
	6536,
	6618,
	6618,
	6569,
	4395,
	2635,
	5229,
	5261,
	10567,
	9037,
	9037,
	3939,
	3939,
	6569,
	9353,
	9353,
	4427,
	6536,
	6536,
	6618,
	6618,
	6569,
	6569,
	4395,
	2635,
	5230,
	5261,
	3939,
	3939,
	6569,
	10569,
	9039,
	9039,
	9355,
	9355,
	4427,
	6536,
	6536,
	6618,
	6618,
	6569,
	4395,
	2635,
	5231,
	5261,
	10570,
	9040,
	9040,
	3939,
	3939,
	6569,
	9356,
	9356,
	4427,
	6536,
	6536,
	6618,
	6618,
	6569,
	4395,
	2635,
	2831,
	5261,
	10566,
	9036,
	9036,
	3939,
	3939,
	6569,
	9352,
	9352,
	4427,
	6536,
	6536,
	6618,
	6618,
	6569,
	4395,
	2635,
	967,
	5261,
	10568,
	9038,
	9038,
	3939,
	3939,
	6569,
	9354,
	9354,
	4427,
	6536,
	9399,
	9394,
	9395,
	9396,
	8521,
	7421,
	8778,
	8778,
	8778,
	8778,
	8073,
	7163,
	9775,
	11833,
	9238,
	8835,
	8835,
	7642,
	7642,
	7181,
	7641,
	7636,
	7636,
	7633,
	7181,
	7179,
	7184,
	6994,
	6994,
	6994,
	6994,
	8126,
	8126,
	7643,
	11833,
	10831,
	11786,
	10831,
	11786,
	11833,
	11812,
	11021,
	10821,
	9775,
	9775,
	11833,
	11816,
	10941,
	9568,
	9568,
	8282,
	8282,
	8281,
	10932,
	8584,
	10941,
	10941,
	10941,
	8584,
	10645,
	10575,
	11833,
	9681,
	9681,
	9217,
	9217,
	9217,
	8426,
	8426,
	11786,
	11786,
	11786,
	11786,
	11786,
	11786,
	8822,
	9139,
	9137,
	7071,
	7187,
	7188,
	7073,
	6997,
	8838,
	8122,
	7638,
	7186,
	7644,
	6955,
	6995,
	6996,
	8112,
	7067,
	7174,
	7178,
	7068,
	6992,
	8837,
	8118,
	7629,
	9775,
	6972,
	6972,
	6926,
	6927,
	7029,
	7029,
	7030,
	8109,
	8118,
	7639,
	7182,
	7180,
	7633,
	10573,
	10573,
	10821,
	10821,
	0,
	0,
	8839,
	8839,
	8839,
	11016,
	11786,
	0,
	11016,
	9277,
	10895,
	10895,
	10895,
	10895,
	10895,
	11812,
	8858,
	8859,
	10657,
	10652,
	0,
	11786,
	11833,
	11833,
	6698,
	3939,
	0,
	0,
	0,
	9255,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6698,
	4766,
	278,
	5481,
	457,
	218,
	902,
	4766,
	6698,
	5261,
	6689,
	6689,
	6689,
	6689,
	6689,
	6689,
	6689,
	9505,
	10652,
	9137,
	11012,
	9697,
	10652,
	10652,
	11833,
	5230,
	6698,
	1518,
	493,
	1408,
	6698,
	11833,
	1517,
	2862,
	2862,
	1008,
	6698,
	6536,
	5230,
	3890,
	1046,
	1046,
	6698,
	6698,
	6698,
	6698,
	11778,
	6569,
	4766,
	1755,
	1696,
	5230,
	2644,
	2878,
	6698,
	7136,
	8004,
	8004,
	8839,
	0,
	0,
	0,
	6618,
	5305,
	6569,
	5261,
	6569,
	6569,
	6618,
	6698,
	6698,
	6698,
	6698,
	6698,
	5261,
	6569,
	2870,
	6698,
	6569,
	5261,
	6569,
	5261,
	8837,
	6698,
	6698,
	2879,
	5305,
	2878,
	6536,
	6698,
	6698,
	6698,
	5230,
	11833,
	6698,
	3652,
	11786,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6698,
	6569,
	6698,
	5261,
	6698,
	2862,
	2862,
	0,
	5230,
	1425,
	1451,
	2870,
	6698,
	5261,
	2867,
	1448,
	3936,
	3936,
	11016,
	9423,
	11833,
	11833,
	6698,
	4427,
	4427,
	6569,
	5305,
	6698,
	6618,
	5305,
	0,
	0,
	0,
	6698,
	6698,
	10895,
	6698,
	6698,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2914,
	2842,
	2635,
	1382,
	2635,
	6536,
	5230,
	1381,
	6536,
	5230,
	1381,
	6536,
	5230,
	1381,
	6536,
	5230,
	1381,
	6536,
	5230,
	954,
	6536,
	5230,
	954,
	2927,
	1505,
	2927,
	6628,
	5316,
	1504,
	6628,
	5316,
	1504,
	6628,
	5316,
	1504,
	6628,
	5316,
	1504,
	6628,
	5316,
	1071,
	6628,
	5316,
	1071,
	6685,
	5368,
	1074,
	1511,
	6685,
	5368,
	1074,
	2327,
	463,
	1333,
	2327,
	463,
	2947,
	1511,
	2947,
	2953,
	1519,
	2953,
	2959,
	1523,
	2959,
	2878,
	2878,
	2878,
	2878,
	2878,
	2878,
	2878,
	2878,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2878,
	6698,
	6698,
	0,
	1947,
	0,
	5261,
	0,
	4427,
	4427,
	0,
	0,
	0,
	0,
	6536,
	6536,
	6698,
	6698,
	11833,
	6698,
	4427,
	6698,
	5261,
	0,
	3939,
	6698,
	11812,
	11812,
	11833,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1449,
	3943,
	6569,
	6569,
	5261,
	4395,
	2635,
	2123,
	6698,
	5305,
	5305,
	6698,
	6569,
	6698,
	5261,
	2123,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	6698,
	1027,
	3939,
	2605,
	2878,
	6698,
	6698,
	6698,
	6698,
	5316,
	6698,
	6698,
	5261,
	6698,
	11833,
	6698,
	4427,
	5261,
	6698,
	4427,
	5261,
	537,
	5261,
	2123,
	6698,
	5305,
	5305,
	6698,
	6698,
	6569,
	6698,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	6628,
	6628,
	6569,
	6569,
	4427,
	6569,
	6698,
	6698,
	4427,
	5261,
	2123,
	6698,
	6698,
	5305,
	5305,
	6698,
	6698,
	5261,
	6698,
	6569,
	6698,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	5261,
	2123,
	6698,
	5305,
	5305,
	2915,
	6698,
	6698,
	5261,
	2123,
	6698,
	5305,
	5305,
	6698,
	6698,
	6569,
	6698,
	5261,
	2123,
	6569,
	6698,
	5261,
	2123,
	6569,
	6698,
	6698,
	2123,
	6698,
	5305,
	5305,
	2915,
	6698,
	6698,
	6698,
	5305,
	2123,
	6698,
	6698,
	6698,
	6698,
	5261,
	2123,
	6698,
	5305,
	5305,
	2912,
	6698,
	6698,
	5261,
	2123,
	6698,
	11833,
	6698,
	5261,
	6569,
	6698,
	6698,
	6698,
	5261,
	6698,
	4764,
	6569,
	6698,
	6698,
	5261,
	6698,
	6698,
	6698,
	4427,
	6698,
	6698,
	6698,
	5261,
	5305,
	2123,
	6698,
	6698,
	6698,
	6698,
	5261,
	6698,
	6569,
	6698,
	5230,
	6698,
	6618,
	6569,
	6698,
	6569,
	5261,
	2123,
	6698,
	5305,
	5305,
	2912,
	6698,
	6698,
	6698,
	5261,
	2123,
	6698,
	6698,
	6698,
	5261,
	2123,
	6569,
	6698,
	5261,
	1502,
	5261,
	2123,
	6698,
	5305,
	5305,
	6698,
	6569,
	6698,
	6628,
	5316,
	6628,
	5316,
	6628,
	6628,
	6628,
	5261,
	1067,
	5261,
	2123,
	6698,
	5305,
	5305,
	6698,
	6569,
	6698,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	6628,
	6628,
	5261,
	537,
	5261,
	2123,
	6698,
	5305,
	5305,
	6698,
	6569,
	6698,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	5316,
	6628,
	6628,
	6628,
	6569,
	5261,
	6569,
	5261,
	6569,
	5261,
	6698,
	5261,
	6569,
	0,
	2123,
	6698,
	6698,
	5305,
	5305,
	6569,
	6569,
	6698,
	6698,
	6698,
	5305,
	2914,
	6698,
};
static const Il2CppTokenRangePair s_rgctxIndices[81] = 
{
	{ 0x02000052, { 17, 10 } },
	{ 0x02000054, { 28, 5 } },
	{ 0x0200005B, { 33, 57 } },
	{ 0x0200005D, { 90, 3 } },
	{ 0x02000066, { 96, 1 } },
	{ 0x02000072, { 97, 4 } },
	{ 0x02000075, { 172, 6 } },
	{ 0x02000076, { 178, 6 } },
	{ 0x0200007F, { 222, 13 } },
	{ 0x0200008C, { 245, 3 } },
	{ 0x0200008E, { 250, 14 } },
	{ 0x0200008F, { 264, 2 } },
	{ 0x02000090, { 266, 6 } },
	{ 0x02000091, { 272, 6 } },
	{ 0x02000092, { 278, 10 } },
	{ 0x02000093, { 288, 5 } },
	{ 0x02000094, { 293, 10 } },
	{ 0x02000095, { 303, 5 } },
	{ 0x02000096, { 308, 10 } },
	{ 0x02000097, { 318, 5 } },
	{ 0x0200009A, { 323, 28 } },
	{ 0x0200009C, { 351, 3 } },
	{ 0x0200009D, { 354, 26 } },
	{ 0x020000B8, { 380, 14 } },
	{ 0x020000D0, { 394, 8 } },
	{ 0x02000116, { 421, 4 } },
	{ 0x02000134, { 429, 15 } },
	{ 0x02000159, { 444, 13 } },
	{ 0x0200015A, { 457, 3 } },
	{ 0x06000130, { 0, 4 } },
	{ 0x06000131, { 4, 1 } },
	{ 0x06000183, { 5, 1 } },
	{ 0x060001AF, { 6, 3 } },
	{ 0x060001B2, { 9, 4 } },
	{ 0x060001B3, { 13, 4 } },
	{ 0x060001B9, { 27, 1 } },
	{ 0x0600024D, { 93, 3 } },
	{ 0x060002A6, { 101, 6 } },
	{ 0x060002A7, { 107, 6 } },
	{ 0x060002A8, { 113, 6 } },
	{ 0x060002A9, { 119, 6 } },
	{ 0x060002AA, { 125, 6 } },
	{ 0x060002AB, { 131, 6 } },
	{ 0x060002AC, { 137, 5 } },
	{ 0x060002AD, { 142, 5 } },
	{ 0x060002AE, { 147, 5 } },
	{ 0x060002AF, { 152, 5 } },
	{ 0x060002B0, { 157, 5 } },
	{ 0x060002B1, { 162, 5 } },
	{ 0x060002B2, { 167, 5 } },
	{ 0x060002CA, { 184, 4 } },
	{ 0x060002CB, { 188, 1 } },
	{ 0x060002D9, { 189, 1 } },
	{ 0x060002DA, { 190, 1 } },
	{ 0x060002DB, { 191, 2 } },
	{ 0x060002DC, { 193, 4 } },
	{ 0x060002DD, { 197, 12 } },
	{ 0x060002DF, { 209, 5 } },
	{ 0x060002E1, { 214, 8 } },
	{ 0x06000300, { 235, 3 } },
	{ 0x06000301, { 238, 2 } },
	{ 0x06000302, { 240, 5 } },
	{ 0x06000338, { 248, 2 } },
	{ 0x0600049C, { 402, 3 } },
	{ 0x060004BA, { 405, 2 } },
	{ 0x060005DC, { 407, 5 } },
	{ 0x060005DE, { 412, 2 } },
	{ 0x060006CB, { 414, 2 } },
	{ 0x060006D2, { 416, 2 } },
	{ 0x060006DF, { 418, 3 } },
	{ 0x0600075F, { 425, 2 } },
	{ 0x06000777, { 427, 2 } },
	{ 0x060007E6, { 460, 2 } },
	{ 0x060007E8, { 462, 1 } },
	{ 0x060007EA, { 463, 1 } },
	{ 0x060007ED, { 464, 2 } },
	{ 0x060007EE, { 466, 1 } },
	{ 0x060007EF, { 467, 1 } },
	{ 0x060007F0, { 468, 4 } },
	{ 0x060007FA, { 472, 2 } },
	{ 0x06000910, { 474, 2 } },
};
extern const uint32_t g_rgctx_RenderGraphObjectPool_Get_TisRenderGraphPass_1_tDC90C59CC338BB2CC653882FCA1F7C536EEBA9A8_m5628FEE192C9BEC08EAE0435BFA0062B5380DAC6;
extern const uint32_t g_rgctx_RenderGraphObjectPool_Get_TisPassData_t823F07F4AC750F4DEA0E82381DE4B2C813603150_mC2B4BD996C7B16FA145521C429F0E901F020744C;
extern const uint32_t g_rgctx_RenderGraphPass_1_tDC90C59CC338BB2CC653882FCA1F7C536EEBA9A8;
extern const uint32_t g_rgctx_RenderGraphPass_1_Initialize_m0D82E782F02566FBF49022010BD7065DC2308842;
extern const uint32_t g_rgctx_RenderGraph_AddRenderPass_TisPassData_t432E687CF081DF0D1EBD2C694958053F9D8B4BEB_m4A4F9AC8FAAED9F9A3FAB2F50F46906589A11A0A;
extern const uint32_t g_rgctx_RenderGraphPass_1_tE194D95486305E70BA99AF068E7DA3512CDB026A;
extern const uint32_t g_rgctx_T_tE29376B6432210CCFA9181A49EC711B45BD09B5D;
extern const uint32_t g_rgctx_TU5BU5D_tDE182CBD876CFABA6A5828DFA4A4CB2DC87C19B5;
extern const uint32_t g_rgctx_TU5BU5D_tDE182CBD876CFABA6A5828DFA4A4CB2DC87C19B5;
extern const uint32_t g_rgctx_SharedObjectPool_1_get_sharedPool_m44CE2BC5C8DE3664FF51C3707527A077319543FB;
extern const uint32_t g_rgctx_SharedObjectPool_1_t9CB85AC4741292D974C13893C1C5EC9372105FE5;
extern const uint32_t g_rgctx_SharedObjectPool_1_t9CB85AC4741292D974C13893C1C5EC9372105FE5;
extern const uint32_t g_rgctx_SharedObjectPool_1_Get_m287E7F688FD8D2F9464F5C5C8D230D6DE3C6E756;
extern const uint32_t g_rgctx_SharedObjectPool_1_get_sharedPool_m116673394BA0174F02B048DEB8A1DB259DA08C71;
extern const uint32_t g_rgctx_SharedObjectPool_1_t8C83EE07258A11E3D8B0634DA81CA3381C174178;
extern const uint32_t g_rgctx_SharedObjectPool_1_t8C83EE07258A11E3D8B0634DA81CA3381C174178;
extern const uint32_t g_rgctx_SharedObjectPool_1_Release_m3E2BD09F712ADD49ADDEFC8AC54A86FE7593BDF2;
extern const uint32_t g_rgctx_Stack_1_t10EB99ED4EA3A7497E32E58AB1DC775AC6014020;
extern const uint32_t g_rgctx_Stack_1_get_Count_m739D92AC7CD1F758D15006701D95B88E33387B2C;
extern const uint32_t g_rgctx_Stack_1_Pop_m09A1A74982679EA0CFEF895BA6D2E641E96120D5;
extern const uint32_t g_rgctx_Activator_CreateInstance_TisT_tD48A4C3976026E7C220D92069E0BF8F9F7B82A92_m6B7D6F8C8AEC1E942660C1093F8A7ECF567FCC72;
extern const uint32_t g_rgctx_Stack_1_Push_m4CD3E89966D24AF04F9F8D6257F4816B9D9BDF03;
extern const uint32_t g_rgctx_SharedObjectPool_1_tF8653AC83BA4C5DF8D83BB1739DD70FCD34DA5B6;
extern const uint32_t g_rgctx_Lazy_1_t7FBF48A4244E5E338B5BA7037970303838271FAF;
extern const uint32_t g_rgctx_Lazy_1_get_Value_m1D0FCCA1D10AE121EBF5973DA85273CBBF1563FE;
extern const uint32_t g_rgctx_Stack_1__ctor_m7E6BD85E00F9321CB5D8AD6B88FED08AACE92140;
extern const uint32_t g_rgctx_Lazy_1__ctor_mACCEDE053C678184B6553ABF3EAE384F3D696BFB;
extern const uint32_t g_rgctx_RenderGraphPass_1_tD0D1B77C9D3C8283C0533D8D661B1883F6A84B5A;
extern const uint32_t g_rgctx_RenderGraphPass_GetExecuteDelegate_TisPassData_tFD22933B2D440EDF944F5286F065793D14B4EC06_m477B199C562376FAF3371639A3655831BE3E33B3;
extern const uint32_t g_rgctx_RenderFunc_1_tFF0A13FDF71DB262147EE1F7E05F281628F6FA79;
extern const uint32_t g_rgctx_RenderFunc_1_Invoke_mA6C1F089A3A9D7E58C8D72E66526CDB6730B94D3;
extern const uint32_t g_rgctx_RenderGraphObjectPool_Release_TisPassData_tFD22933B2D440EDF944F5286F065793D14B4EC06_m1D63FE9D1BC5D717DD339678B8A1AC6FF3345AD2;
extern const uint32_t g_rgctx_RenderGraphObjectPool_Release_TisRenderGraphPass_1_tC3A1193C00578D2A046CD2B932927CEA72D0241C_m723CB0597ED95A75F1E49089F5265478ED4D430A;
extern const uint32_t g_rgctx_Dictionary_2_t38B3F769B17A1D6165E1BC28AB65106A3597FDCD;
extern const uint32_t g_rgctx_Dictionary_2_TryGetValue_mEFD9065F0CC536AB84128615225F4820A60E2E27;
extern const uint32_t g_rgctx_SortedList_2_t6BB9341A97CE606331DE55711A473F8693325779;
extern const uint32_t g_rgctx_SortedList_2__ctor_mB5E039AE28151F12156FCC893D1FE72FE5378F08;
extern const uint32_t g_rgctx_Dictionary_2_Add_mC4B270B3EF7F38431EC1329BC8A2FB30147F8767;
extern const uint32_t g_rgctx_RenderGraphResourcePool_1_t5E055FEA6264151065DFB816860C80E56DDE7400;
extern const uint32_t g_rgctx_RenderGraphResourcePool_1_GetSortIndex_m5F3E434117330E22DE6D184D66A9160D4A5ACC04;
extern const uint32_t g_rgctx_ValueTuple_2_t645DFB46DE4844F7991C90F15C4A71C02AD803D9;
extern const uint32_t g_rgctx_ValueTuple_2__ctor_m22E546AECFCCC2C71364E9B031CA16F20C47CE01;
extern const uint32_t g_rgctx_SortedList_2_Add_mF31408A3F8F4F9690EBC4E780C5951F8B6C8A964;
extern const uint32_t g_rgctx_SortedList_2_get_Count_m7497D192926EB69B65BCD0B67FBDBD17A092B399;
extern const uint32_t g_rgctx_SortedList_2_get_Values_mCC76CAEC3A45AFC03868DD5C37F824BA203E4E96;
extern const uint32_t g_rgctx_IList_1_t25CD692EAEF87050D0188A128027DA605844FA03;
extern const uint32_t g_rgctx_IList_1_get_Item_m9272FC976C7FC6884F0400E189AC571BB747C1DB;
extern const uint32_t g_rgctx_SortedList_2_RemoveAt_mA07103CF6BDA305C00FF791CF7C2844E8C914EF2;
extern const uint32_t g_rgctx_Dictionary_2_GetEnumerator_mA4711DAADF3A2C241E3D5FDB474D8CD64E21F9F1;
extern const uint32_t g_rgctx_Enumerator_get_Current_m5C2C1C6428371A787283BDF2EF46B9AF2F35B057;
extern const uint32_t g_rgctx_KeyValuePair_2_get_Value_m496DAB5128DA03A314CB3BA52C70A9D3C20683E6;
extern const uint32_t g_rgctx_SortedList_2_GetEnumerator_m22709706591A53D44CEC999ACB4CF8DD88DC4235;
extern const uint32_t g_rgctx_IEnumerator_1_t094B950D43DF8DFE277DC2D3FEAFC43030A53B95;
extern const uint32_t g_rgctx_IEnumerator_1_get_Current_m8AFDDF554C5060301FAD224750CF0DF6FEF28BF4;
extern const uint32_t g_rgctx_KeyValuePair_2_get_Value_m67D48BB94EB82867EC675BCFA319C10D454C76D7;
extern const uint32_t g_rgctx_RenderGraphResourcePool_1_ReleaseInternalResource_m0929BB85D5B73EB5AB3559586BDAB573E3ADB504;
extern const uint32_t g_rgctx_Enumerator_MoveNext_m6EA58C1200946DDF508308AA534907BD1BFFF807;
extern const uint32_t g_rgctx_Enumerator_t4E87A367969BB344801ED40B44CD58673B17A9FB;
extern const Il2CppRGCTXConstrainedData g_rgctx_Enumerator_t4E87A367969BB344801ED40B44CD58673B17A9FB_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7;
extern const uint32_t g_rgctx_ValueTuple_2_t9EEBDEB346660217CAD82A46C2AFA49812E5455B;
extern const uint32_t g_rgctx_ValueTuple_2__ctor_m97B3CB4A8A2E14CBD7F90BDF5DAD1E0E66699350;
extern const uint32_t g_rgctx_List_1_tAFEBCE04F82FE4D99DB0C596CC084DA3F0E8C69C;
extern const uint32_t g_rgctx_List_1_Add_mF731075A0A00B819DBEEA575C7000BE77B808C91;
extern const uint32_t g_rgctx_List_1_Remove_m5D90A5A0F12FBC3452CC7BF1F8D69C2BCFADCC87;
extern const uint32_t g_rgctx_List_1_get_Count_mF0803349A0A709A5B2F69716529CC5F4D8988194;
extern const uint32_t g_rgctx_RenderGraphResourcePool_1_GetResourceTypeName_m4BAC165420FEEA5F2B947673F9443C918ADFD826;
extern const uint32_t g_rgctx_List_1_GetEnumerator_m3DF13A3F58EF856A7352CBE8025C65858F318716;
extern const uint32_t g_rgctx_Enumerator_get_Current_m86863DCBBB8B55203FEE711C2DA02E5C2FC95745;
extern const uint32_t g_rgctx_RenderGraphResourcePool_1_GetResourceName_m0E156A2A3A779766A195DA1D4AEF6324ED66BD3A;
extern const uint32_t g_rgctx_RenderGraphResourcePool_1_ReleaseResource_mB6C32FB26147FDE6AB3BD409286C9844C52A52F2;
extern const uint32_t g_rgctx_Enumerator_MoveNext_m34B10031D1A919F3500EDD449A58B739727940E9;
extern const uint32_t g_rgctx_Enumerator_t6DE82E5121CD8124FD6FD4EAAADEE7EEC0CBA60C;
extern const Il2CppRGCTXConstrainedData g_rgctx_Enumerator_t6DE82E5121CD8124FD6FD4EAAADEE7EEC0CBA60C_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7;
extern const uint32_t g_rgctx_List_1_Clear_m67DD7D53AE236243E61BB37AC361A43BCB415796;
extern const uint32_t g_rgctx_List_1_t1252EAC946DB423AA47CAE098E2D8A6DAEBB6205;
extern const uint32_t g_rgctx_List_1__ctor_mFDC8B4BC4E9214AC2515D80CE7CA532B29A3E2DD;
extern const uint32_t g_rgctx_RenderGraphResourcePool_1_GetResourceSize_mBFECD3D78CDF7228CD4E0C0E2FC4D75446356D25;
extern const uint32_t g_rgctx_List_1_Add_mA243B31BF0872F986302B2DCA5ADE0296180194A;
extern const uint32_t g_rgctx_U3CU3Ec_tD51B2481C528C4EA6D94841BBA3F1175DA0B6A35;
extern const uint32_t g_rgctx_U3CU3Ec_U3CLogResourcesU3Eb__17_0_mE78BE1CC7F7DF8969C985FC62A4E4ADFA4B4AC09;
extern const uint32_t g_rgctx_Comparison_1_tED58B82FB7A2C91F98584913BF31F4EB22C457B0;
extern const uint32_t g_rgctx_Comparison_1__ctor_m70CC55E87D912336539DE0FC8DB67EC4B65C9FA8;
extern const uint32_t g_rgctx_List_1_Sort_mF58DE782592FCEE92E0759626B537A4790E42C9E;
extern const uint32_t g_rgctx_List_1_GetEnumerator_mCEDAF8C9622B37160BC54EDCC5550019722A0BE4;
extern const uint32_t g_rgctx_Enumerator_get_Current_m555100E8A3AFB0B4D82D0DF7151FD03F748C79F0;
extern const uint32_t g_rgctx_Enumerator_MoveNext_mA81F74037035D325BF170C11F7E1A62E89752BE3;
extern const uint32_t g_rgctx_Enumerator_t13D22151810F040F3F55E8252ACCBF9E54FBE707;
extern const Il2CppRGCTXConstrainedData g_rgctx_Enumerator_t13D22151810F040F3F55E8252ACCBF9E54FBE707_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7;
extern const uint32_t g_rgctx_Dictionary_2__ctor_mFAE5B73C8535E82E229A8EFF817A4DE18EFB0F97;
extern const uint32_t g_rgctx_List_1__ctor_m14C1FB3CE305A2F0B842155FF7C6C8CFF51CECF8;
extern const uint32_t g_rgctx_U3CU3Ec_t0DDAD394509E16640C8C77540D7A5D29E3BD4560;
extern const uint32_t g_rgctx_U3CU3Ec__ctor_mA30D55B80F6ACBBF1C23F8E4CFA2D71461430EEA;
extern const uint32_t g_rgctx_U3CU3Ec_t0DDAD394509E16640C8C77540D7A5D29E3BD4560;
extern const uint32_t g_rgctx_Activator_CreateInstance_TisResType_tD1FE7BB9C940E24F58C832D58865EFC4E5925ED4_m924AEB25762F06602422C7DAEF7CA26137190E72;
extern const uint32_t g_rgctx_ResType_tD1FE7BB9C940E24F58C832D58865EFC4E5925ED4;
extern const Il2CppRGCTXConstrainedData g_rgctx_ResType_tD1FE7BB9C940E24F58C832D58865EFC4E5925ED4_IRenderGraphResource_Reset_m81E9B60C6150975FDFED0428472E8A472FF30627;
extern const uint32_t g_rgctx_ResType_tD51FD186C1632D722EB7A57B61CC1B4F545F6487;
extern const uint32_t g_rgctx_ComponentSingleton_1_tAF66CB52D8E2FD91B45CFFB516383FB617F733A3;
extern const uint32_t g_rgctx_TType_tFB821001EA2FF99CA2D82A606100FDE37B2DB558;
extern const uint32_t g_rgctx_TType_tFB821001EA2FF99CA2D82A606100FDE37B2DB558;
extern const uint32_t g_rgctx_GameObject_AddComponent_TisTType_tFB821001EA2FF99CA2D82A606100FDE37B2DB558_m5FFDA4659C0F660D492241A6F0F8F75E7F0AF934;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_get_instance_mF26291329384686E3808A379D4045D3FA808570E;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_t7C92EB9183DA4562EF68C96B6ED86AF21B4BD7C7;
extern const uint32_t g_rgctx_ConstantBuffer_1_t76660BCB3420DA30872C837E3E3C3E1322372FE7;
extern const uint32_t g_rgctx_ConstantBuffer_1_t76660BCB3420DA30872C837E3E3C3E1322372FE7;
extern const uint32_t g_rgctx_ConstantBuffer_1_UpdateData_mEFFA50342E0BA45DBA78530CA80E27B76BCA678C;
extern const uint32_t g_rgctx_ConstantBuffer_1_SetGlobal_mCC1B42DB41DD4F939898F944AD5373790A4EE6B5;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_get_instance_mC941AEF60B269952845D81E05637C21AF46C5626;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_t0A0151F280E720B41E6E336D4A6E71F076A73C83;
extern const uint32_t g_rgctx_ConstantBuffer_1_t6A117CF4843F32EC1811934841FB49F4706637CB;
extern const uint32_t g_rgctx_ConstantBuffer_1_t6A117CF4843F32EC1811934841FB49F4706637CB;
extern const uint32_t g_rgctx_ConstantBuffer_1_UpdateData_m310C3B4313DEFCAB951F88501FCD5E8ABED116DF;
extern const uint32_t g_rgctx_ConstantBuffer_1_SetGlobal_m93F01A2708421627726831EE96B07E08422A9667;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_get_instance_mB01EA7039D1CC0127EB566DF9631FB01B13D8FB7;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_tB2E321DF87F01606E024A7ED3D60F12F58DAB33E;
extern const uint32_t g_rgctx_ConstantBuffer_1_tB201A99C351D384BB0E09559F066923E8E9C9DC9;
extern const uint32_t g_rgctx_ConstantBuffer_1_tB201A99C351D384BB0E09559F066923E8E9C9DC9;
extern const uint32_t g_rgctx_ConstantBuffer_1_UpdateData_mECCCAF567CF49841161F44EEB40AC7A0CAE59D51;
extern const uint32_t g_rgctx_ConstantBuffer_1_Set_m2D6601848664170FC7E1BF03F6F06CC5828AF7DD;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_get_instance_mC2B5E938202022FBB705D73926E9506C484DBDD8;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_t4CF342E4025AA6067C2684E9432D3ACE2211D333;
extern const uint32_t g_rgctx_ConstantBuffer_1_t68EDF6F6C593BD29565BAE20EE8157167DAAAD97;
extern const uint32_t g_rgctx_ConstantBuffer_1_t68EDF6F6C593BD29565BAE20EE8157167DAAAD97;
extern const uint32_t g_rgctx_ConstantBuffer_1_UpdateData_mA0DA55408A9AD22C9ABE84E3D7324258A21226E3;
extern const uint32_t g_rgctx_ConstantBuffer_1_Set_mF4C4D95E3D5CF404A939B1AB5390914FC5EA8CE2;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_get_instance_mDC8E160B0B9401DF1E78C3CDA97783E09D5BB865;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_tCB9AE60656168F3FA79C9CE4E9B857F9CBA7734F;
extern const uint32_t g_rgctx_ConstantBuffer_1_tCB5AF7BC465BB24134D158A9F2E3B9356413018A;
extern const uint32_t g_rgctx_ConstantBuffer_1_tCB5AF7BC465BB24134D158A9F2E3B9356413018A;
extern const uint32_t g_rgctx_ConstantBuffer_1_UpdateData_mDDFEEB74F80FC039DC2A64E89292D15B61E0B5CA;
extern const uint32_t g_rgctx_ConstantBuffer_1_Set_mBD2089F798581847E818D65A8722BA8140813435;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_get_instance_mE96D21C4704CE3694D5EE2C28E6E6C2810074F3E;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_tCBA93224460A809D7450599974DBAA8C37A415E9;
extern const uint32_t g_rgctx_ConstantBuffer_1_tD66A88B5B4679F71DF09E1225A8BAB247D80EB37;
extern const uint32_t g_rgctx_ConstantBuffer_1_tD66A88B5B4679F71DF09E1225A8BAB247D80EB37;
extern const uint32_t g_rgctx_ConstantBuffer_1_UpdateData_m376B499115BA87D5F3E4BA7D6363C0BFBE7FE4BE;
extern const uint32_t g_rgctx_ConstantBuffer_1_Set_m68728117892A33B456D6A2F6327ADB491DB35101;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_get_instance_m8D8336927586B73996A0595F6E1D6A2283B45E7E;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_t8189858956A05BBBB31E273C478FE08863950AE6;
extern const uint32_t g_rgctx_ConstantBuffer_1_tBE028519A42222ABF6462BCD6D894ED6CFB2D882;
extern const uint32_t g_rgctx_ConstantBuffer_1_tBE028519A42222ABF6462BCD6D894ED6CFB2D882;
extern const uint32_t g_rgctx_ConstantBuffer_1_UpdateData_mFC124F416A44CDD31512EB617ED684C5DB4D3CC6;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_get_instance_m2C537967E6C9D3974C39C22751102D3214CD6A80;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_tA51D7E28A089C1B22397369A470162A9E1C3D4D0;
extern const uint32_t g_rgctx_ConstantBuffer_1_t4115EC9DE8C69A61E45F252A36645D617ABB7512;
extern const uint32_t g_rgctx_ConstantBuffer_1_t4115EC9DE8C69A61E45F252A36645D617ABB7512;
extern const uint32_t g_rgctx_ConstantBuffer_1_UpdateData_m4831E1644024185ED5C4A3C94E73E7595179C785;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_get_instance_mC4C66B545FD39DF6BC44E0D1F02EF67A652B122B;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_tACBEB7B6F3CA610DA1CE4E4C33840DA30B4DD04F;
extern const uint32_t g_rgctx_ConstantBuffer_1_tF57A88056767C2767F6C911F7E96CE60B603BF3B;
extern const uint32_t g_rgctx_ConstantBuffer_1_tF57A88056767C2767F6C911F7E96CE60B603BF3B;
extern const uint32_t g_rgctx_ConstantBuffer_1_SetGlobal_m63CA119339CCF2F0560E1F5B5E528F2700510522;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_get_instance_mCA90A8F398303EE866B9E8ACB9676561E7522F51;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_t5EC23633CEAEF110F526B30D70AF29120932E509;
extern const uint32_t g_rgctx_ConstantBuffer_1_t20673CA9DF01B202051C9D33947D3BFE28B12EF5;
extern const uint32_t g_rgctx_ConstantBuffer_1_t20673CA9DF01B202051C9D33947D3BFE28B12EF5;
extern const uint32_t g_rgctx_ConstantBuffer_1_SetGlobal_m60FB777763AD55A6380AEB167A7D8B044205EEC7;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_get_instance_mDA6D6EA4A9E152489ADD9FE82BAD573D3799A5ED;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_t6F0FB5756DD3518E04B8A1EC09BF70F9D77BD4F5;
extern const uint32_t g_rgctx_ConstantBuffer_1_t3B468A09EB552700445DD3B0D722519EA2C6FBCC;
extern const uint32_t g_rgctx_ConstantBuffer_1_t3B468A09EB552700445DD3B0D722519EA2C6FBCC;
extern const uint32_t g_rgctx_ConstantBuffer_1_Set_mCBA77B286CE55AC0D6FB43671FDDC2E9873777FD;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_get_instance_m12CE8CE2014E153BF47DFFCA43BB92AED0376AAD;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_tB3DDF7A7EAF135D5D1B61AD02A88DE0C0DE276B4;
extern const uint32_t g_rgctx_ConstantBuffer_1_tABADEE242AF1F6EEACA11E91B66EF96DAF1B9773;
extern const uint32_t g_rgctx_ConstantBuffer_1_tABADEE242AF1F6EEACA11E91B66EF96DAF1B9773;
extern const uint32_t g_rgctx_ConstantBuffer_1_Set_m950F6090ABC935DA4C7B6B301EE5F0EE04A22B2C;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_get_instance_m51B90C902A981470330D82116544A049A45E2587;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_tB8DA3AA5009A05D79D5170EEF3EC3C9A19E3789E;
extern const uint32_t g_rgctx_ConstantBuffer_1_tAA00F7CB51FFEEB8A8F5ED8E1251A90512EE0758;
extern const uint32_t g_rgctx_ConstantBuffer_1_tAA00F7CB51FFEEB8A8F5ED8E1251A90512EE0758;
extern const uint32_t g_rgctx_ConstantBuffer_1_Set_mE81A696726D6C2ABE53F20880B1F2F81163797D4;
extern const uint32_t g_rgctx_CBTypeU5BU5D_tD091220AEB48AFD57DA21352C19BBF89B1941424;
extern const uint32_t g_rgctx_UnsafeUtility_SizeOf_TisCBType_t5964815BE6B450555FA4489A328C4E220A1B2720_mBCAFB2E15586C88EE977CC3C2EA26A47212F1936;
extern const uint32_t g_rgctx_ConstantBuffer_1_UpdateData_mB92BDF8E2F5D27970A818F9B33C7724D618E1767;
extern const uint32_t g_rgctx_ConstantBuffer_1_SetGlobal_m95E1FDBFC183CFD5F8D93239855895CCC83C2CD6;
extern const uint32_t g_rgctx_ConstantBuffer_1_UpdateData_m8FC97611FC4DB5C7069C603A25E3838B2AD02D97;
extern const uint32_t g_rgctx_ConstantBuffer_1_SetGlobal_m8EA330908A7A52235E57C8840D6219967A8755D8;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_t5D9C4BA8214CFE87FAE00A2B74B4E8C3064295F3;
extern const uint32_t g_rgctx_ConstantBuffer_1_tB2879B452D42593AFDBF1D28BA3B733B2ECE6898;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1_t5D9C4BA8214CFE87FAE00A2B74B4E8C3064295F3;
extern const uint32_t g_rgctx_ConstantBufferSingleton_1__ctor_m46330D2E623142C7BA029B7E2BB94E97C4A2C141;
extern const uint32_t g_rgctx_ConstantBuffer_1_Release_mC728E5851975D55A8CC45C6A184459085C93BDEE;
extern const uint32_t g_rgctx_ConstantBuffer_1__ctor_m8EA9912CA647DEEE2B2C2A4B9C94D3259BDD6BC4;
extern const uint32_t g_rgctx_List_1_t779D87623BF32357BDB1C1B1F8A8259E151651FB;
extern const uint32_t g_rgctx_List_1_get_Count_m81E3A35818B5FFCF78BB08E14F82D0FBD14A5CAA;
extern const uint32_t g_rgctx_List_1_get_Item_m2E42646CFDA96E9870354AA516960B1CCA3B6CEB;
extern const uint32_t g_rgctx_UnsafeUtility_WriteArrayElement_TisT_tB35451058E1BF98388E6357BF259AEEA805FAEEC_m29572C8B2BCC5452309576F3C8FFE82533FA86EC;
extern const uint32_t g_rgctx_UnsafeUtility_WriteArrayElement_TisT_t26ECB6BF6C0047BB1AD0335ACFC6F959C487D601_m593EF0BD738D469F424C53559C4C6B4993D09A38;
extern const uint32_t g_rgctx_CoreUnsafeUtils_QuickSort_TisT_t4744A7447EB6CB898F9C95ADB53D52D279CC0904_TisT_t4744A7447EB6CB898F9C95ADB53D52D279CC0904_TisDefaultKeyGetter_1_tCB3559102863F465B40B3A899698FE6AD6C6DB7F_mF7E031A10D6D6C7B5FB4AA707F3BCC1E08A27D7C;
extern const uint32_t g_rgctx_CoreUnsafeUtils_QuickSort_TisTValue_tAF621310047F4FBA4F826272EBA00BEBFC558426_TisTKey_t85A560E5076D6FA7684189A318432BA47C21C934_TisTGetter_t6AF3F80DC9B2ABED8AD1A41F526BBD6F7C0FF3E1_mC1C631DCE446096CB9EFBED74730BAB522215259;
extern const uint32_t g_rgctx_CoreUnsafeUtils_Partition_TisTValue_t68867E9E554E0547EDD2328992CC833CBB7BC345_TisTKey_t6AD31C65BDC8C152769939C384F7DFC079B8A833_TisTGetter_tA8D57B4438FFF4C21A14BD96F6C2D9FD3680849B_m77B54BE986D337E9B234D388E76D65898535CE1D;
extern const uint32_t g_rgctx_CoreUnsafeUtils_QuickSort_TisTValue_t68867E9E554E0547EDD2328992CC833CBB7BC345_TisTKey_t6AD31C65BDC8C152769939C384F7DFC079B8A833_TisTGetter_tA8D57B4438FFF4C21A14BD96F6C2D9FD3680849B_mF17BDB22B82B34FD72D8F5DFE150E7DB2D179122;
extern const uint32_t g_rgctx_UnsafeUtility_ReadArrayElement_TisT_t2A6748C61397A2356E716053A22676B44E22FC64_m816CBF34FFFA3596B4F8B7A482F8150C032F79C0;
extern const uint32_t g_rgctx_T_t2A6748C61397A2356E716053A22676B44E22FC64;
extern const uint32_t g_rgctx_IEquatable_1_t4F3DCF6B0D965FBF8DC57633AC12C723C4EF7164;
extern const Il2CppRGCTXConstrainedData g_rgctx_T_t2A6748C61397A2356E716053A22676B44E22FC64_IEquatable_1_Equals_mB272675BACF74389AF761E505A8DDB39F0D5F65C;
extern const uint32_t g_rgctx_Activator_CreateInstance_TisTOldGetter_tBEE13F46644C785B2966F439C4BEE5C5B18D42AB_m3E3A0DDE0542BD76D2DBE9FF77333156426FE053;
extern const uint32_t g_rgctx_Activator_CreateInstance_TisTNewGetter_t21B2B1171BF2FB315D6FCE0B8B7842D074A29CBD_m8FF72D3491A08A3820FA8AA287E6558CE71338C1;
extern const uint32_t g_rgctx_CoreUnsafeUtils_CombineHashes_TisTOldValue_tD32C6397F2F3CA202862AA1AFB219D53944A1293_TisTOldGetter_tBEE13F46644C785B2966F439C4BEE5C5B18D42AB_m8C4DBC55D5CCE05932B4B8D66DB5EFF3F53A4556;
extern const uint32_t g_rgctx_CoreUnsafeUtils_CombineHashes_TisTNewValue_tEF3863E8ECA50B75F1B0FFC325A8368B67A5D1D1_TisTNewGetter_t21B2B1171BF2FB315D6FCE0B8B7842D074A29CBD_m39B65A447FAA2C3C1A67777363F92B3409B16704;
extern const uint32_t g_rgctx_UnsafeUtility_ReadArrayElement_TisTNewValue_tEF3863E8ECA50B75F1B0FFC325A8368B67A5D1D1_m739CA84EB95E57DA20E20079A802E20952CEE60B;
extern const uint32_t g_rgctx_UnsafeUtility_ReadArrayElement_TisTOldValue_tD32C6397F2F3CA202862AA1AFB219D53944A1293_mFE839327B5391D0FD8E8632AA2C1CC5CCE66E274;
extern const uint32_t g_rgctx_TNewGetter_t21B2B1171BF2FB315D6FCE0B8B7842D074A29CBD;
extern const uint32_t g_rgctx_IKeyGetter_2_t7EB16529E81FF8DFE884AF324E33E88B877CC87F;
extern const Il2CppRGCTXConstrainedData g_rgctx_TNewGetter_t21B2B1171BF2FB315D6FCE0B8B7842D074A29CBD_IKeyGetter_2_Get_m96B45F1A5C1679C46B5199FAC4D5EF82C27F2FFD;
extern const uint32_t g_rgctx_TOldGetter_tBEE13F46644C785B2966F439C4BEE5C5B18D42AB;
extern const uint32_t g_rgctx_IKeyGetter_2_t0B2C72EDC39A2D8428C5DAD58C6CE9ECBCFD2F9E;
extern const Il2CppRGCTXConstrainedData g_rgctx_TOldGetter_tBEE13F46644C785B2966F439C4BEE5C5B18D42AB_IKeyGetter_2_Get_m56407B82607B9CF46D757C64A273690894F6BD2E;
extern const uint32_t g_rgctx_Activator_CreateInstance_TisTGetter_t928FCFF0DB16188D9CE4EB19E33F5B5C6B3D64E0_mE95F0D9E228CB35A29778DC4AB9B1320364FEDDA;
extern const uint32_t g_rgctx_UnsafeUtility_ReadArrayElement_TisTValue_t0E50ED21875B61D9BA6DB117058872C236EFCE95_mE1D6FF46ED841C4B8F71F8AFECF08E50D5264FBF;
extern const uint32_t g_rgctx_TGetter_t928FCFF0DB16188D9CE4EB19E33F5B5C6B3D64E0;
extern const uint32_t g_rgctx_IKeyGetter_2_t70139089067FF897E54325E32085A22D1EF770D6;
extern const Il2CppRGCTXConstrainedData g_rgctx_TGetter_t928FCFF0DB16188D9CE4EB19E33F5B5C6B3D64E0_IKeyGetter_2_Get_m46B03047F284A6BEFBEB044EEBD182A64C1F7268;
extern const uint32_t g_rgctx_UnsafeUtility_ReadArrayElement_TisTValue_tFAE97595138D9812BEA80E4F331EA07F163BBDF5_m14B075982208D9D262FC051784ABC971EEEB5F10;
extern const uint32_t g_rgctx_TGetter_t735A3AB48BAC01DAAB825085904633E640511371;
extern const uint32_t g_rgctx_IKeyGetter_2_t2D58A2ED3A07CF330D6525925CAC1736B11E63D8;
extern const Il2CppRGCTXConstrainedData g_rgctx_TGetter_t735A3AB48BAC01DAAB825085904633E640511371_IKeyGetter_2_Get_m1570E1970FEF688A895B1B33F40E8B174AE474B0;
extern const uint32_t g_rgctx_TKey_tFEA8742E8654FCA07F754A8F83C4610E1D1044B5;
extern const uint32_t g_rgctx_IComparable_1_t8BDF01E34FEA3221DA459EAFBDE5F076C63BEA30;
extern const Il2CppRGCTXConstrainedData g_rgctx_TKey_tFEA8742E8654FCA07F754A8F83C4610E1D1044B5_IComparable_1_CompareTo_mA73CB729E22D4308B47ED920AFC14946021D3371;
extern const uint32_t g_rgctx_UnsafeUtility_WriteArrayElement_TisTValue_tFAE97595138D9812BEA80E4F331EA07F163BBDF5_m0FB6EEC7F7DD4FF8D6F7AD09FB6BC9BA7D7C9D8A;
extern const uint32_t g_rgctx_TU5BU5D_t92D3D6C7EA6FBFDC2E1CDE4265327EEAF583E0BC;
extern const uint32_t g_rgctx_DynamicArray_1_set_size_m71C0C4E7472366190916A3BDFCC6CC408469F09F;
extern const uint32_t g_rgctx_DynamicArray_1_IndexOf_mE59D976A65E3F0D56E889F73E6A9777F6470E9DD;
extern const uint32_t g_rgctx_DynamicArray_1_get_size_m7EB4887059F6CF3FEAF667BBABF3428630FDCC2F;
extern const uint32_t g_rgctx_DynamicArray_1_tF0164E8C65F2CD1ADA1D652152285201761F17B7;
extern const uint32_t g_rgctx_DynamicArray_1_Reserve_m489C952D55362D83E4D04A7F305E75BEBA1ACBCA;
extern const uint32_t g_rgctx_DynamicArray_1_get_Item_m1A04B4E38EB2F420DED302F4531679C08944B85E;
extern const uint32_t g_rgctx_DynamicArray_1_RemoveAt_m007CDFB85824A43B8CC0359B288D19625DC3C9C3;
extern const uint32_t g_rgctx_Predicate_1_t9317675707087082A17CF2728A544746CEAAA3B4;
extern const uint32_t g_rgctx_Predicate_1_Invoke_m2DD6557D95C4D3ABB7021DB413B1D76E6CBE02AE;
extern const uint32_t g_rgctx_T_t680F3D5C3D02D13D214B173A3711D8C59D75B69D;
extern const Il2CppRGCTXConstrainedData g_rgctx_T_t680F3D5C3D02D13D214B173A3711D8C59D75B69D_Object_Equals_m07105C4585D3FE204F2A80D58523D001DC43F63B;
extern const uint32_t g_rgctx_DynamicArray_1_IndexOf_mB8346F1913597FAA2E47C8056B8C576824548260;
extern const uint32_t g_rgctx_T_tDEE9F78A5EF56768AA0C40D8EDC0F352EAE25850;
extern const uint32_t g_rgctx_IComparable_1_t77EE7C9392228A07ED0F661060BEA8DAC923285C;
extern const Il2CppRGCTXConstrainedData g_rgctx_T_tDEE9F78A5EF56768AA0C40D8EDC0F352EAE25850_IComparable_1_CompareTo_m5183A7430AC0FEB4A0D4B01D8E42B97294596CC3;
extern const uint32_t g_rgctx_DynamicArrayExtensions_Partition_TisT_tF1371A513C9C13C2358102FD96D57BE84A6E3D3F_m27F863AC91AFDC44A015A8E009AC794A1E0192BC;
extern const uint32_t g_rgctx_DynamicArrayExtensions_QuickSort_TisT_tF1371A513C9C13C2358102FD96D57BE84A6E3D3F_mF447CA019719F688526DE501B96CC4F116B620F6;
extern const uint32_t g_rgctx_DynamicArray_1_op_Implicit_mE3D789169134B0FACB955BE42A0AA76BC5406A01;
extern const uint32_t g_rgctx_DynamicArray_1_t8DA1BA74A0D3D45E3366DB0C804CC16B94FFB662;
extern const uint32_t g_rgctx_DynamicArray_1_t8DA1BA74A0D3D45E3366DB0C804CC16B94FFB662;
extern const uint32_t g_rgctx_DynamicArray_1_get_size_mE126CD3F138951D83DE4E6E2B40BEA44048643F0;
extern const uint32_t g_rgctx_DynamicArrayExtensions_QuickSort_TisT_t9C2399CC9329628BADFB26622DFC946E209D5493_mC8E5576D55C73F0EC4A8872AF701B8A9F58ABB1D;
extern const uint32_t g_rgctx_ListBuffer_1_get_Count_mBF5B70BD773EB056FDE8AD226B90E143049DD3B2;
extern const uint32_t g_rgctx_T_t02DCCCA1CABD8F1284FE95DA832FF891AA965E97;
extern const uint32_t g_rgctx_UnsafeUtility_SizeOf_TisT_t02DCCCA1CABD8F1284FE95DA832FF891AA965E97_mBF2720F48A95DAF4BF188B45FC35A07D2BCD1242;
extern const uint32_t g_rgctx_ListBuffer_1_get_Count_m17A0872E8E01FCCB33E6E02D74CC640AB3D4C44B;
extern const uint32_t g_rgctx_ListBuffer_1_get_BufferPtr_mF2BCBE00A0A5C71C73156605248360387874FBEE;
extern const uint32_t g_rgctx_ObjectPool_1_get_countAll_mB98B96A35C683BEAEC934902A93FBEA08DAE5B3F;
extern const uint32_t g_rgctx_ObjectPool_1_get_countInactive_mE77B0A5342B00D246867817E0EF6C925DFCB4D01;
extern const uint32_t g_rgctx_Stack_1_t4E6255F1200764B1F9BEF118237E5E93EC7FCBB7;
extern const uint32_t g_rgctx_Stack_1_get_Count_m51F70B59F566B839C558D640D2BFFEF13564FA08;
extern const uint32_t g_rgctx_Stack_1__ctor_mD7EB29759A543D49FE20C4DD351B55BB1A09D880;
extern const uint32_t g_rgctx_Activator_CreateInstance_TisT_t0D8036F6FEC93D79CC76B41CB3C41F9849087B2D_m99194D8D857E68EE9C3EEFC08E520CBFA9277713;
extern const uint32_t g_rgctx_ObjectPool_1_set_countAll_m58640AFAC889339E70A96C0B95B5764C716DE9A9;
extern const uint32_t g_rgctx_Stack_1_Pop_m2D023D47A7E90FA14703B44E890D5A48E4407275;
extern const uint32_t g_rgctx_UnityAction_1_tA6E547A663C3EEA8EDED071484A0CF6955148049;
extern const uint32_t g_rgctx_UnityAction_1_Invoke_m3F21D9DD27AF031854D34B153B387458B273ECA8;
extern const uint32_t g_rgctx_ObjectPool_1_Get_mCFA2B80A1C48D806618BAA8D5CF0A604CCE52910;
extern const uint32_t g_rgctx_PooledObject_t9B23BE39F2452452BC4064E84415EFDEA27255BF;
extern const uint32_t g_rgctx_PooledObject__ctor_m77F18E393DB532FD146A6E86DAFEF334E9A88E69;
extern const uint32_t g_rgctx_Stack_1_Push_m10AA0F614BD6B715EE243196D8E2C3CBA32BB8AF;
extern const uint32_t g_rgctx_ObjectPool_1_tC2D72FC258A50D9A53BFD9CD6E7F110A4F8DE6BE;
extern const uint32_t g_rgctx_ObjectPool_1_Release_m5666A0F88833C0528CDC5C6AA5CFF9A82F9C01BF;
extern const uint32_t g_rgctx_GenericPool_1_t6941943A3281B958203958D744C281A13069D3C6;
extern const uint32_t g_rgctx_ObjectPool_1_t4DB897013B135B2A297C5DC20D567F1A7163A6F5;
extern const uint32_t g_rgctx_ObjectPool_1_Get_m99592F5B7B2EF828E5C5508695938AF049594D21;
extern const uint32_t g_rgctx_ObjectPool_1_Get_mC90C2364FED4279AC623BAA531C521F8F0529D4D;
extern const uint32_t g_rgctx_ObjectPool_1_Release_m384FD232D2125269AB749C946A165E0F67DD167E;
extern const uint32_t g_rgctx_ObjectPool_1__ctor_m0C1762B4D321A6FBBD44E33A9731330E6935661B;
extern const uint32_t g_rgctx_UnsafeGenericPool_1_t4D243EE700AAAB782492A0718A011AD909B06BFE;
extern const uint32_t g_rgctx_ObjectPool_1_tA443864065D38ECEBA458785F2FB1C366C379CA7;
extern const uint32_t g_rgctx_ObjectPool_1_Get_m36B17AD6AA38E847E4915B76460C8DC27C6E5B62;
extern const uint32_t g_rgctx_ObjectPool_1_Get_mCB6E07FFA08C5DC7210E0CCFC6927A3384766E39;
extern const uint32_t g_rgctx_ObjectPool_1_Release_mEC3CDC64D9A04792173DC0037F2083ED2BD67A50;
extern const uint32_t g_rgctx_ObjectPool_1__ctor_m14C50679FC6879830D466B99732C31AD8A9933C5;
extern const uint32_t g_rgctx_ListPool_1_t6223F616BA3B8DBE7E059F8E3FA7BAAFB9218A8D;
extern const uint32_t g_rgctx_ObjectPool_1_tC0C22C8BFFCB15F90DB8C98719853139D9E19FE5;
extern const uint32_t g_rgctx_ObjectPool_1_Get_mA2F6C45BD1C088B1D523E8C8BB2FCF2988331C6B;
extern const uint32_t g_rgctx_ObjectPool_1_Get_m76EF23395F5F067FD3909745FE66DE29BAE28DE8;
extern const uint32_t g_rgctx_ObjectPool_1_Release_m130F1550E52E2B06F0ABF976FA09EF7890FB5731;
extern const uint32_t g_rgctx_U3CU3Ec_tBA9743671FBAC96AA206135721CFF91C8F372F14;
extern const uint32_t g_rgctx_U3CU3Ec_U3C_cctorU3Eb__4_0_mDEDFE721F9368EBD8AC71DC3E2CABF586E440300;
extern const uint32_t g_rgctx_UnityAction_1_t38F30AC7A00F6AD93B29C007D7162BAA579609F2;
extern const uint32_t g_rgctx_UnityAction_1__ctor_mE1BD8D8A3F6DEB0B18FA8F332AF1ECD232D99894;
extern const uint32_t g_rgctx_ObjectPool_1__ctor_mAE8740BADF4E9CEB531EC461D28730470B73717E;
extern const uint32_t g_rgctx_U3CU3Ec_t3A3F35D952D43B5681534794220D43DAA0CAEC9B;
extern const uint32_t g_rgctx_U3CU3Ec__ctor_m1B8510029051E169383A8B4F6889ACF4F6FD1B93;
extern const uint32_t g_rgctx_U3CU3Ec_t3A3F35D952D43B5681534794220D43DAA0CAEC9B;
extern const uint32_t g_rgctx_List_1_t74642046F802269A530559D5C5DE7AEC12D79769;
extern const uint32_t g_rgctx_List_1_Clear_m0B5C1D345C11BF21E84BF4B46F109AE38912408C;
extern const uint32_t g_rgctx_HashSetPool_1_t6E1F0A3C618746CD2652CD1D2B5019950C080D86;
extern const uint32_t g_rgctx_ObjectPool_1_t9A9C2B65D1CC81D81561583A9F71BB4590E2CCB4;
extern const uint32_t g_rgctx_ObjectPool_1_Get_m375495A52E0F4DC359A8EC6EF3504361529885B3;
extern const uint32_t g_rgctx_ObjectPool_1_Get_mB6C3FF42276A04C899E29FE7EFDB39735CB0D7C8;
extern const uint32_t g_rgctx_ObjectPool_1_Release_m1E5A51C6C98208912C29BF4C8B31F7DC5A1C8EF2;
extern const uint32_t g_rgctx_U3CU3Ec_tC25A6FA319E71E5C9DC585592EB36EC9F5EB02D8;
extern const uint32_t g_rgctx_U3CU3Ec_U3C_cctorU3Eb__4_0_m4994A44EEAE82045F8F5934079E8076499995AED;
extern const uint32_t g_rgctx_UnityAction_1_tAB9CFF61AE62D68553824687BC7E336586BAD8B0;
extern const uint32_t g_rgctx_UnityAction_1__ctor_mD6D982DB1DD4E9F776983E3C0895C9F2EBD8520F;
extern const uint32_t g_rgctx_ObjectPool_1__ctor_m54DCCBE475872A64AAFB91E3186E71DB9FCF8084;
extern const uint32_t g_rgctx_U3CU3Ec_tFB17DF3D62339E36BD3B5E7ED50F66E374CE4FA2;
extern const uint32_t g_rgctx_U3CU3Ec__ctor_mF16067314465472FC747E5B88957771ADCF2E759;
extern const uint32_t g_rgctx_U3CU3Ec_tFB17DF3D62339E36BD3B5E7ED50F66E374CE4FA2;
extern const uint32_t g_rgctx_HashSet_1_t38A58F8B18667A727E9725053F506D5DFA7036E9;
extern const uint32_t g_rgctx_HashSet_1_Clear_m6BC337B37B19BD4773F2340607837F5DC270E16A;
extern const uint32_t g_rgctx_DictionaryPool_2_t08056220DFADF3969DFA2CFB9CEAE6FC8D707676;
extern const uint32_t g_rgctx_ObjectPool_1_t781E01D4328DCC742473BB991B696971FB2BD4FB;
extern const uint32_t g_rgctx_ObjectPool_1_Get_mE849E5BE7D3DC7D0A6BD9A4A179FDB9AA0098D7A;
extern const uint32_t g_rgctx_ObjectPool_1_Get_m1088974EC3F733A37FB498BCD6F5232099CD27EB;
extern const uint32_t g_rgctx_ObjectPool_1_Release_m6B0491E4DAC74F86F4DC6AB80A36F8A71F90E529;
extern const uint32_t g_rgctx_U3CU3Ec_t12171AE4C8145C70D97ABF478F6E34688B2EA070;
extern const uint32_t g_rgctx_U3CU3Ec_U3C_cctorU3Eb__4_0_m1ED30CF58D65F1C56CEB5342F9BEAE3B3D9087D3;
extern const uint32_t g_rgctx_UnityAction_1_t57D5B4D1AD828EFDA90561D1907CCEF1497133ED;
extern const uint32_t g_rgctx_UnityAction_1__ctor_m40E129600B30DE8E3986054B79B9A014861FA102;
extern const uint32_t g_rgctx_ObjectPool_1__ctor_m667B0D553AA456F4030C5D5CE58B09C6ED6B6E4F;
extern const uint32_t g_rgctx_U3CU3Ec_t8EBC4FF595CEB8E04B2AEF597860103187A32AD6;
extern const uint32_t g_rgctx_U3CU3Ec__ctor_m589A7431724484B162A593F84424B7B8DADB7BA5;
extern const uint32_t g_rgctx_U3CU3Ec_t8EBC4FF595CEB8E04B2AEF597860103187A32AD6;
extern const uint32_t g_rgctx_Dictionary_2_t445BB1E618457723FAED2CF88E436649AD306855;
extern const uint32_t g_rgctx_Dictionary_2_Clear_m1EF68D758F9B35B0378F971C6DF876F958D9C49A;
extern const uint32_t g_rgctx_ListChangedEventHandler_1_tF13479C4BD2CF664153E64E38914D439158D0052;
extern const uint32_t g_rgctx_IList_1_tADDE9E206B899D2E721BF2D39D4639529509C2EA;
extern const uint32_t g_rgctx_IList_1_get_Item_mA1570CD813B9096758D53A2ED339957C87C7DCF3;
extern const uint32_t g_rgctx_ObservableList_1_OnEvent_mA17C7E7827FC97210B627F6CC7B748487300F2B7;
extern const uint32_t g_rgctx_IList_1_set_Item_m705E44D852E0D8E932CD69359DEC35E82A72B467;
extern const uint32_t g_rgctx_ICollection_1_t65A09CE74C2E925B3F0E480DCBDF064CA83F6C64;
extern const uint32_t g_rgctx_ICollection_1_get_Count_m07A1ED30CC1D4E9F74D131D3657EC89BCD9DC3CA;
extern const uint32_t g_rgctx_ObservableList_1__ctor_m80B3548827A252BF9BB4D4234DB83C7EF5F51532;
extern const uint32_t g_rgctx_List_1_t1EC2049826741F4E3D4FF66D3E71C79E65A0AF91;
extern const uint32_t g_rgctx_List_1__ctor_m222F46D36A43FD6D6B50E0733E1604CA6652F746;
extern const uint32_t g_rgctx_List_1__ctor_mE2C4222AD28995459DC9F84A54BE77D763F41303;
extern const uint32_t g_rgctx_ListChangedEventArgs_1_t954C1FB02ADD7657C3A34D7517A42605CD9BDA6F;
extern const uint32_t g_rgctx_ListChangedEventArgs_1__ctor_m83FB3A14954E43E80E9D78E33F62692CA5F7AAFD;
extern const uint32_t g_rgctx_ListChangedEventHandler_1_Invoke_mC7613C5C42057AD9D01D376006F3947838ECA3EE;
extern const uint32_t g_rgctx_ICollection_1_Contains_m254313386E5BE54AFF34173C9589BFA3BD75A410;
extern const uint32_t g_rgctx_IList_1_IndexOf_m4AE90CCDE1CF5C49BCF2AABCD68F2D29C32B50C4;
extern const uint32_t g_rgctx_ICollection_1_Add_mDE216D9E853EF6ED8958269D1D93D4A4AED288AE;
extern const uint32_t g_rgctx_ObservableList_1_Add_m18C1DFBC105CFA613C3BC08A6A5FEA55C5670FE7;
extern const uint32_t g_rgctx_IList_1_Insert_m9A2C756262C85227B7AF650EAF911CDD1CC19887;
extern const uint32_t g_rgctx_ICollection_1_Remove_m611D2AEFCC07CCB4CC8FD8CE7E29BE32A8A139C5;
extern const uint32_t g_rgctx_ObservableList_1_Remove_m1CF80CCD393858774CDBC0D9A26E73C021D08A36;
extern const uint32_t g_rgctx_IList_1_RemoveAt_m7B902EAFF2B76B5124FD531940AC2F332E040E71;
extern const uint32_t g_rgctx_ObservableList_1_RemoveAt_m262784BC5D703324DADCB5FC43F7A9F84287DEF7;
extern const uint32_t g_rgctx_ObservableList_1_get_Count_mC86BC374BDE350A421BE0D1F5316AB97656DD80A;
extern const uint32_t g_rgctx_ICollection_1_CopyTo_m35A8DBE9CF49985AC37FF1CD3CAF554FA4AE6274;
extern const uint32_t g_rgctx_IEnumerable_1_tB17703EF50CBB7DDDD59F4F909BC433389957102;
extern const uint32_t g_rgctx_IEnumerable_1_GetEnumerator_mC34663B8AAA7FCCDA7FD695CA441AC9ADAE8FEEB;
extern const uint32_t g_rgctx_ObservableList_1_GetEnumerator_m8652475F0BFE66E82ECF04501FA24721254D1760;
extern const uint32_t g_rgctx_SerializedDictionary_4__ctor_m93AF45C4C10A55D9D09E79C7390737769113B670;
extern const uint32_t g_rgctx_SerializedDictionary_4_tE2783C0B6A4968B91F6222A3123B304F5A334F00;
extern const uint32_t g_rgctx_Dictionary_2_t094655324611484DB804651B4DB36003D155D99D;
extern const uint32_t g_rgctx_List_1_t1B772F8004907E91C14DE320308E300D4383CEEA;
extern const uint32_t g_rgctx_List_1_Clear_m54C88AC8E2061F3946BE90B673C8DD69AE7EB3DF;
extern const uint32_t g_rgctx_List_1_t73CA8BB266930AB63D8E2586AEEC971482CAA8AD;
extern const uint32_t g_rgctx_List_1_Clear_m3E53B7E3AFC3C8D7646E33E4913C2D45B0DC22E0;
extern const uint32_t g_rgctx_Dictionary_2_GetEnumerator_mAE42DBF2A51B8D990D685895A63020DFAFEACFC2;
extern const uint32_t g_rgctx_Enumerator_get_Current_m83F43262C89B8CFD96603F3A2962AF89D36DCA1B;
extern const uint32_t g_rgctx_KeyValuePair_2_get_Key_m33FF678D1FABDC95993F23A83E428AB204766AF4;
extern const uint32_t g_rgctx_SerializedDictionary_4_t4A730F998FDB7FCA9ADD6E9C5F40B1D52D9284D9;
extern const uint32_t g_rgctx_SerializedDictionary_4_SerializeKey_m10F9766DF9F024573B83A3D639A90A41614656A4;
extern const uint32_t g_rgctx_List_1_Add_m49E33716E9E1431D354D9383823584A2A44E27A4;
extern const uint32_t g_rgctx_KeyValuePair_2_get_Value_m002F78CBAFB19464B454D13B2E7E12139F423173;
extern const uint32_t g_rgctx_SerializedDictionary_4_SerializeValue_mA5C288713EB481D3E6AB7295A1019A460B3E930F;
extern const uint32_t g_rgctx_List_1_Add_m66A29CEFA75A687A036F892CFF7FE63E4FC2CD65;
extern const uint32_t g_rgctx_Enumerator_MoveNext_mBF169A34B9E71FA3BACC157F0C8BD9C8970C2A1B;
extern const uint32_t g_rgctx_Enumerator_t683B460C190EA15A1E133E880DA0D3786608A06D;
extern const Il2CppRGCTXConstrainedData g_rgctx_Enumerator_t683B460C190EA15A1E133E880DA0D3786608A06D_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7;
extern const uint32_t g_rgctx_List_1_get_Item_mFED712ADBEDB7A6655DECF21C185736019FEDDAC;
extern const uint32_t g_rgctx_SerializedDictionary_4_DeserializeKey_mDCDC769BE37985E8A3BF67CCBDEDCBF6844F01D7;
extern const uint32_t g_rgctx_List_1_get_Item_mF8E86772FCD20FAC7DD957F8A4C59D89A8A6A679;
extern const uint32_t g_rgctx_SerializedDictionary_4_DeserializeValue_m80AAC76D3FFD5A671173322A1399EA7D541F1B0A;
extern const uint32_t g_rgctx_Dictionary_2_Add_m17817F59D59257EB71A22A2A31AB0BF2603598AE;
extern const uint32_t g_rgctx_List_1_get_Count_mD9EB3DC1FF41414935DA9B5302A550A3C699CB50;
extern const uint32_t g_rgctx_List_1__ctor_m51C3776A7DF472862EACCFD6864F8D1296D6FAF8;
extern const uint32_t g_rgctx_List_1__ctor_m2EE7A07223732A9C52F1019281B378A667083F8C;
extern const uint32_t g_rgctx_Dictionary_2__ctor_m9B925A89B599BA8BCAEA33F5EFB6E08A5A2F95AE;
extern const uint32_t g_rgctx_Dictionary_2_tE3B43C2B070ED99ACBD252C485D125CBF550BE45;
extern const uint32_t g_rgctx_T_t26CC53AEAFD25035943D16224BEF5BE64BAB4C90;
extern const uint32_t g_rgctx_Field_1_tD418C612A305A78AC208BCD8DED6A3B61FB92B97;
extern const uint32_t g_rgctx_Field_1_ValidateValue_m4A7D2686A817F10452B498D8282433D9D39240F1;
extern const uint32_t g_rgctx_Field_1_GetValue_mA26E190F06D8BFCDF8EC9CFCAEB2FCC9932A9209;
extern const uint32_t g_rgctx_Field_1_get_getter_m0B70E3395A5F3EE9D97852913640F06F0F8D9A76;
extern const uint32_t g_rgctx_Func_1_t62EC3ED648C6028D451C378830FD121EB4FA7611;
extern const uint32_t g_rgctx_Func_1_Invoke_m5EA4140B193EAB0A9D43B21E47A39515118F6746;
extern const uint32_t g_rgctx_Field_1_SetValue_mD8A4EE1562DB7D0877CC71808BF6CAE357352E87;
extern const Il2CppRGCTXConstrainedData g_rgctx_T_t26CC53AEAFD25035943D16224BEF5BE64BAB4C90_Object_Equals_m07105C4585D3FE204F2A80D58523D001DC43F63B;
extern const uint32_t g_rgctx_Field_1_get_setter_mD473751526042624878EB0FFB5AF21CA125E6401;
extern const uint32_t g_rgctx_Action_1_tDEF046DC219119B8A91BB1DB06DC5F20BCC1FC69;
extern const uint32_t g_rgctx_Action_1_Invoke_m2E92EF61B67FB5CAADBD321CEBC1FE67CB9B967F;
extern const uint32_t g_rgctx_Action_2_t36B30ABD6F5141C433C79501DB436B88878836EA;
extern const uint32_t g_rgctx_Action_2_Invoke_m5B614DA27D3C50CA217FF9D4DCCC10C4EA5F2117;
extern const uint32_t g_rgctx_Dictionary_2_tC8CCEB8E79BC02F0789B42BF33ADBB85415CB4CB;
extern const uint32_t g_rgctx_Dictionary_2__ctor_mCA04BE9372EDBBD63FB265999E339FD8BFEE8D7E;
extern const uint32_t g_rgctx_TProfilingSampler_1_t65290618F3B57B18C4BDC714B6543EB6E6DA41D9;
extern const uint32_t g_rgctx_TEnum_t2AE3EBB2263205A87E0B5B08C0CC4E2699461412;
extern const uint32_t g_rgctx_TProfilingSampler_1_t65290618F3B57B18C4BDC714B6543EB6E6DA41D9;
extern const uint32_t g_rgctx_TProfilingSampler_1__ctor_m5033A67D8216E4CB911D58B9F127A9D39844D114;
extern const uint32_t g_rgctx_TEnum_t2AE3EBB2263205A87E0B5B08C0CC4E2699461412;
extern const uint32_t g_rgctx_Dictionary_2_Add_mAC2ECA573660B260320E45477451EF77E774B8A5;
extern const uint32_t g_rgctx_TProfilingSampler_1_t3E8F47C89F02CC35EBF2CAB3D893C0BA34111F09;
extern const uint32_t g_rgctx_Dictionary_2_tF3D1CDCBF77E29578FF6CD634BC7ACBCC55D51FD;
extern const uint32_t g_rgctx_Dictionary_2_TryGetValue_mE6A365B92FD3CA50BADB78A31E5F8365FFA6D152;
extern const uint32_t g_rgctx_TEnum_t2FD04B0EB72B3C80C45E3B7402CC3A423C1817E6;
extern const Il2CppRGCTXConstrainedData g_rgctx_TEnum_t2FD04B0EB72B3C80C45E3B7402CC3A423C1817E6_Object_GetType_mE10A8FC1E57F3DF29972CCBC026C2DC3942263B3;
extern const uint32_t g_rgctx_NativeArray_1__ctor_m1148A54380581B701CC862B5050D94B9259C1F95;
extern const uint32_t g_rgctx_NativeArray_1_get_IsCreated_m269B99B7A939B0D7A41692DDAFAA9F77844A6679;
extern const uint32_t g_rgctx_NativeArray_1_Copy_m084E053EC143095F22C0C86DE11D08BE9DCB488F;
extern const uint32_t g_rgctx_NativeArray_1_tCD3D8A7A4BF79EAA79EA7E0DA89F99868235B7B9;
extern const uint32_t g_rgctx_NativeArray_1_Dispose_mEB4BD40B96877D644ADEB41A4949DA461F3098F4;
extern const uint32_t g_rgctx_TU5BU5D_t8CADBADBA566ABBAF369C22955B0E86F5E2C00A5;
extern const uint32_t g_rgctx_Array_Resize_TisT_t204800E20079C684B2ADB298B75E35161424A624_m4B528E27EE3398F43B609A4DCD544CB86ACB6997;
extern const uint32_t g_rgctx_T_tF07567C78439016ABF0ACBC2B82B6C49F6EC7BF9;
extern const Il2CppRGCTXConstrainedData g_rgctx_T_tF07567C78439016ABF0ACBC2B82B6C49F6EC7BF9_IConvertible_ToUInt32_mD56F031D945955896F6C4D8E735794A72AC8141B;
extern const uint32_t g_rgctx_U3CU3Ec__82_1_t0C163997F29BB04A9B290E19D01E9957905B8122;
extern const uint32_t g_rgctx_U3CU3Ec__82_1_U3CGetAllTypesDerivedFromU3Eb__82_0_m4484CB63E1F991C8712DC70C4938FCBEC9BA1CF3;
extern const uint32_t g_rgctx_T_t028669B2F5A4E1715738479271B5642C431DFEAD;
extern const uint32_t g_rgctx_Enumerable_Cast_TisT_t028669B2F5A4E1715738479271B5642C431DFEAD_m1BC2EBC6ABFF1864D790062B4651DDAB94B3EB77;
extern const uint32_t g_rgctx_Enumerable_Last_TisT_t028669B2F5A4E1715738479271B5642C431DFEAD_mE5AB7D7EBCF0E78B67DABA3E1BCB8E133D85B136;
extern const uint32_t g_rgctx_U3CU3Ec__82_1_tE671CF03C5305EE89A318559F3942817FECBC01A;
extern const uint32_t g_rgctx_U3CU3Ec__82_1__ctor_mC04F2E89955679567C855FFBAA0A5EE271DACA5A;
extern const uint32_t g_rgctx_U3CU3Ec__82_1_tE671CF03C5305EE89A318559F3942817FECBC01A;
extern const uint32_t g_rgctx_T_t34AEFC60C87159398705753AB3949E9F7EF38E6B;
extern const uint32_t g_rgctx_VolumeProfile_TryGet_TisT_tF3D68ED9398B623EDC636AF8EECE175896F2B764_mE7E4FCBFC37AE5C385FA87B1C05E1C8BB4EFE206;
extern const uint32_t g_rgctx_T_tF3D68ED9398B623EDC636AF8EECE175896F2B764;
extern const uint32_t g_rgctx_VolumeParameter_1_t62DBE65CE2DD11362CEFAA62CDFE766C1C47AAD7;
extern const uint32_t g_rgctx_VolumeParameter_1_get_value_m8414ABD41447786F0A8A2B2CCC214DA97B3BCB29;
extern const uint32_t g_rgctx_VolumeParameter_1__ctor_m2CB876A14B8962612809165C02F949A687C06FE9;
extern const uint32_t g_rgctx_VolumeParameter_GetValue_TisT_t6F7A42E482B273BE8680284FFC0EA16E6A955CD7_mB1A14C399EC384BB29A503708C7D06AB7694DF00;
extern const uint32_t g_rgctx_VolumeParameter_1_tD29515A1C38D91B1DB9888E60CCD244CE0D5411C;
extern const uint32_t g_rgctx_VolumeParameter_1_Interp_mA2B63CC5EF641D67034EFA5DD77529889320A597;
extern const uint32_t g_rgctx_EqualityComparer_1_get_Default_m63725B6669D7C2E44F01D13F4EE477F1985D6466;
extern const uint32_t g_rgctx_EqualityComparer_1_t548082EFF5C0A29C1FEC4EB08C670049011D006E;
extern const uint32_t g_rgctx_VolumeParameter_1_get_value_m4B6EB123585A9DB460EC85BCF2A00AE1088BE699;
extern const uint32_t g_rgctx_EqualityComparer_1_t548082EFF5C0A29C1FEC4EB08C670049011D006E;
extern const uint32_t g_rgctx_EqualityComparer_1_Equals_mDEBC7DD15CC581A3EC396845845424C9C6032D81;
extern const uint32_t g_rgctx_T_t6F7A42E482B273BE8680284FFC0EA16E6A955CD7;
extern const Il2CppRGCTXConstrainedData g_rgctx_T_t6F7A42E482B273BE8680284FFC0EA16E6A955CD7_Object_GetHashCode_m372C5A7AB16CAC13307C11C4256D706CE57E090C;
extern const Il2CppRGCTXConstrainedData g_rgctx_T_t6F7A42E482B273BE8680284FFC0EA16E6A955CD7_Object_Equals_m07105C4585D3FE204F2A80D58523D001DC43F63B;
extern const uint32_t g_rgctx_VolumeParameter_1_op_Equality_m460EFFE098A41E1117844EB74F79E91AD707D6A5;
extern const uint32_t g_rgctx_VolumeParameter_1_tD29515A1C38D91B1DB9888E60CCD244CE0D5411C;
extern const uint32_t g_rgctx_VolumeParameter_1_Equals_m583564C794AE8BCC10737B2E1161E54280EBCCE6;
extern const uint32_t g_rgctx_T_t6C0397962A8AC97F08436002C08ABC346B1E6545;
extern const uint32_t g_rgctx_ObjectParameter_1_set_parameters_m0B8E1DD2F4626A9C0F591B17EDD45A8B2ACAAA03;
extern const Il2CppRGCTXConstrainedData g_rgctx_T_t6C0397962A8AC97F08436002C08ABC346B1E6545_Object_GetType_mE10A8FC1E57F3DF29972CCBC026C2DC3942263B3;
extern const uint32_t g_rgctx_U3CU3Ec_t285777F3546BC5A7B9BA7349F88ADBC0AF5FF00B;
extern const uint32_t g_rgctx_U3CU3Ec_U3Cset_valueU3Eb__9_0_m5BCCB5F25B35E861FB4F28F7468108849B4741DF;
extern const uint32_t g_rgctx_U3CU3Ec_U3Cset_valueU3Eb__9_1_mB06A4A33E49F70F146D16521E093431C5873795E;
extern const uint32_t g_rgctx_ObjectParameter_1_U3Cset_valueU3Eb__9_2_m09F4A9DDA36800CBB711F246CB91ED02DEA5219A;
extern const uint32_t g_rgctx_VolumeParameter_1__ctor_m65285A3978EE1BF12AB76A49E8C77A7F44D17AE9;
extern const uint32_t g_rgctx_VolumeParameter_1_tBD8FED943C80D98EC5A3CAC114E550B6014A7EF1;
extern const uint32_t g_rgctx_VolumeParameter_1_tBD8FED943C80D98EC5A3CAC114E550B6014A7EF1;
extern const uint32_t g_rgctx_VolumeParameter_1_set_value_m1F669FA969F5B93E853B4F41D4E4BEEFC690EF54;
extern const uint32_t g_rgctx_ObjectParameter_1_get_parameters_m20973595FD069E4CE9A286218645A9EA9DC7E0AA;
extern const uint32_t g_rgctx_ObjectParameter_1_t41E805E26779A221A457A33131EF7A079BA846AE;
extern const uint32_t g_rgctx_U3CU3Ec_t29B394078CAB71E61EE63D5EF29B2AB33E91965B;
extern const uint32_t g_rgctx_U3CU3Ec__ctor_mFD43D0C2BBA9A8C6FE384122CE15596038BC5358;
extern const uint32_t g_rgctx_U3CU3Ec_t29B394078CAB71E61EE63D5EF29B2AB33E91965B;
extern const uint32_t g_rgctx_T_tB5FBED418E93CC320398596B8E4E604D96C48794;
extern const uint32_t g_rgctx_T_tB5FBED418E93CC320398596B8E4E604D96C48794;
extern const uint32_t g_rgctx_T_tC66A4D0D8F85AFED27AA5D32E0C17EDB7207B833;
extern const uint32_t g_rgctx_T_tE556E299BB00733101BB00402BB3DE976CA00804;
extern const uint32_t g_rgctx_T_tB3C0C5C166FD73A50A9CD77B6030FBCD800A3F52;
extern const uint32_t g_rgctx_VolumeProfile_TryGet_TisT_tB3C0C5C166FD73A50A9CD77B6030FBCD800A3F52_m0088EB3E2698B1C6F30D4C66320C4D53D3F8C166;
extern const uint32_t g_rgctx_T_tC6400D8DBAD530961588DAC6B08267907F518F3A;
extern const uint32_t g_rgctx_T_t43F14DE2A8C16558A2D5E40E29195535EBB4D9BB;
extern const uint32_t g_rgctx_List_1_t4467BCCC7001BD00F931FC1D8BE5EE0A3C5C5966;
extern const uint32_t g_rgctx_List_1_get_Count_m961A124AA26C5EBC756071A4A9792FC70F3136EF;
extern const uint32_t g_rgctx_T_t6FD7774D198991CE9196F1CA24259D4C8F2CE3B2;
extern const uint32_t g_rgctx_List_1_Add_m6B827EA9BD4674EFCB49D70207AC5870889C2E00;
extern const uint32_t g_rgctx_T_t45618DD40C279D3C6893AE5959943714F5AC9052;
extern const uint32_t g_rgctx_T_t45618DD40C279D3C6893AE5959943714F5AC9052;
extern const uint32_t g_rgctx_T_t9B26B094ECAD86EC4D7787341446C66F40C66A27;
extern const uint32_t g_rgctx_T_t9B26B094ECAD86EC4D7787341446C66F40C66A27;
static const Il2CppRGCTXDefinition s_rgctxValues[476] = 
{
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_RenderGraphObjectPool_Get_TisRenderGraphPass_1_tDC90C59CC338BB2CC653882FCA1F7C536EEBA9A8_m5628FEE192C9BEC08EAE0435BFA0062B5380DAC6 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_RenderGraphObjectPool_Get_TisPassData_t823F07F4AC750F4DEA0E82381DE4B2C813603150_mC2B4BD996C7B16FA145521C429F0E901F020744C },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_RenderGraphPass_1_tDC90C59CC338BB2CC653882FCA1F7C536EEBA9A8 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_RenderGraphPass_1_Initialize_m0D82E782F02566FBF49022010BD7065DC2308842 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_RenderGraph_AddRenderPass_TisPassData_t432E687CF081DF0D1EBD2C694958053F9D8B4BEB_m4A4F9AC8FAAED9F9A3FAB2F50F46906589A11A0A },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_RenderGraphPass_1_tE194D95486305E70BA99AF068E7DA3512CDB026A },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_T_tE29376B6432210CCFA9181A49EC711B45BD09B5D },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TU5BU5D_tDE182CBD876CFABA6A5828DFA4A4CB2DC87C19B5 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TU5BU5D_tDE182CBD876CFABA6A5828DFA4A4CB2DC87C19B5 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_SharedObjectPool_1_get_sharedPool_m44CE2BC5C8DE3664FF51C3707527A077319543FB },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_SharedObjectPool_1_t9CB85AC4741292D974C13893C1C5EC9372105FE5 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_SharedObjectPool_1_t9CB85AC4741292D974C13893C1C5EC9372105FE5 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_SharedObjectPool_1_Get_m287E7F688FD8D2F9464F5C5C8D230D6DE3C6E756 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_SharedObjectPool_1_get_sharedPool_m116673394BA0174F02B048DEB8A1DB259DA08C71 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_SharedObjectPool_1_t8C83EE07258A11E3D8B0634DA81CA3381C174178 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_SharedObjectPool_1_t8C83EE07258A11E3D8B0634DA81CA3381C174178 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_SharedObjectPool_1_Release_m3E2BD09F712ADD49ADDEFC8AC54A86FE7593BDF2 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Stack_1_t10EB99ED4EA3A7497E32E58AB1DC775AC6014020 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Stack_1_get_Count_m739D92AC7CD1F758D15006701D95B88E33387B2C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Stack_1_Pop_m09A1A74982679EA0CFEF895BA6D2E641E96120D5 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Activator_CreateInstance_TisT_tD48A4C3976026E7C220D92069E0BF8F9F7B82A92_m6B7D6F8C8AEC1E942660C1093F8A7ECF567FCC72 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Stack_1_Push_m4CD3E89966D24AF04F9F8D6257F4816B9D9BDF03 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_SharedObjectPool_1_tF8653AC83BA4C5DF8D83BB1739DD70FCD34DA5B6 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Lazy_1_t7FBF48A4244E5E338B5BA7037970303838271FAF },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Lazy_1_get_Value_m1D0FCCA1D10AE121EBF5973DA85273CBBF1563FE },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Stack_1__ctor_m7E6BD85E00F9321CB5D8AD6B88FED08AACE92140 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Lazy_1__ctor_mACCEDE053C678184B6553ABF3EAE384F3D696BFB },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_RenderGraphPass_1_tD0D1B77C9D3C8283C0533D8D661B1883F6A84B5A },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_RenderGraphPass_GetExecuteDelegate_TisPassData_tFD22933B2D440EDF944F5286F065793D14B4EC06_m477B199C562376FAF3371639A3655831BE3E33B3 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_RenderFunc_1_tFF0A13FDF71DB262147EE1F7E05F281628F6FA79 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_RenderFunc_1_Invoke_mA6C1F089A3A9D7E58C8D72E66526CDB6730B94D3 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_RenderGraphObjectPool_Release_TisPassData_tFD22933B2D440EDF944F5286F065793D14B4EC06_m1D63FE9D1BC5D717DD339678B8A1AC6FF3345AD2 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_RenderGraphObjectPool_Release_TisRenderGraphPass_1_tC3A1193C00578D2A046CD2B932927CEA72D0241C_m723CB0597ED95A75F1E49089F5265478ED4D430A },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Dictionary_2_t38B3F769B17A1D6165E1BC28AB65106A3597FDCD },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2_TryGetValue_mEFD9065F0CC536AB84128615225F4820A60E2E27 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_SortedList_2_t6BB9341A97CE606331DE55711A473F8693325779 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_SortedList_2__ctor_mB5E039AE28151F12156FCC893D1FE72FE5378F08 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2_Add_mC4B270B3EF7F38431EC1329BC8A2FB30147F8767 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_RenderGraphResourcePool_1_t5E055FEA6264151065DFB816860C80E56DDE7400 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_RenderGraphResourcePool_1_GetSortIndex_m5F3E434117330E22DE6D184D66A9160D4A5ACC04 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ValueTuple_2_t645DFB46DE4844F7991C90F15C4A71C02AD803D9 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ValueTuple_2__ctor_m22E546AECFCCC2C71364E9B031CA16F20C47CE01 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_SortedList_2_Add_mF31408A3F8F4F9690EBC4E780C5951F8B6C8A964 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_SortedList_2_get_Count_m7497D192926EB69B65BCD0B67FBDBD17A092B399 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_SortedList_2_get_Values_mCC76CAEC3A45AFC03868DD5C37F824BA203E4E96 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IList_1_t25CD692EAEF87050D0188A128027DA605844FA03 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IList_1_get_Item_m9272FC976C7FC6884F0400E189AC571BB747C1DB },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_SortedList_2_RemoveAt_mA07103CF6BDA305C00FF791CF7C2844E8C914EF2 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2_GetEnumerator_mA4711DAADF3A2C241E3D5FDB474D8CD64E21F9F1 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_get_Current_m5C2C1C6428371A787283BDF2EF46B9AF2F35B057 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_KeyValuePair_2_get_Value_m496DAB5128DA03A314CB3BA52C70A9D3C20683E6 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_SortedList_2_GetEnumerator_m22709706591A53D44CEC999ACB4CF8DD88DC4235 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IEnumerator_1_t094B950D43DF8DFE277DC2D3FEAFC43030A53B95 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IEnumerator_1_get_Current_m8AFDDF554C5060301FAD224750CF0DF6FEF28BF4 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_KeyValuePair_2_get_Value_m67D48BB94EB82867EC675BCFA319C10D454C76D7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_RenderGraphResourcePool_1_ReleaseInternalResource_m0929BB85D5B73EB5AB3559586BDAB573E3ADB504 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_MoveNext_m6EA58C1200946DDF508308AA534907BD1BFFF807 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Enumerator_t4E87A367969BB344801ED40B44CD58673B17A9FB },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_Enumerator_t4E87A367969BB344801ED40B44CD58673B17A9FB_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ValueTuple_2_t9EEBDEB346660217CAD82A46C2AFA49812E5455B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ValueTuple_2__ctor_m97B3CB4A8A2E14CBD7F90BDF5DAD1E0E66699350 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_tAFEBCE04F82FE4D99DB0C596CC084DA3F0E8C69C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Add_mF731075A0A00B819DBEEA575C7000BE77B808C91 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Remove_m5D90A5A0F12FBC3452CC7BF1F8D69C2BCFADCC87 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Count_mF0803349A0A709A5B2F69716529CC5F4D8988194 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_RenderGraphResourcePool_1_GetResourceTypeName_m4BAC165420FEEA5F2B947673F9443C918ADFD826 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_GetEnumerator_m3DF13A3F58EF856A7352CBE8025C65858F318716 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_get_Current_m86863DCBBB8B55203FEE711C2DA02E5C2FC95745 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_RenderGraphResourcePool_1_GetResourceName_m0E156A2A3A779766A195DA1D4AEF6324ED66BD3A },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_RenderGraphResourcePool_1_ReleaseResource_mB6C32FB26147FDE6AB3BD409286C9844C52A52F2 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_MoveNext_m34B10031D1A919F3500EDD449A58B739727940E9 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Enumerator_t6DE82E5121CD8124FD6FD4EAAADEE7EEC0CBA60C },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_Enumerator_t6DE82E5121CD8124FD6FD4EAAADEE7EEC0CBA60C_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Clear_m67DD7D53AE236243E61BB37AC361A43BCB415796 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_t1252EAC946DB423AA47CAE098E2D8A6DAEBB6205 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1__ctor_mFDC8B4BC4E9214AC2515D80CE7CA532B29A3E2DD },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_RenderGraphResourcePool_1_GetResourceSize_mBFECD3D78CDF7228CD4E0C0E2FC4D75446356D25 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Add_mA243B31BF0872F986302B2DCA5ADE0296180194A },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec_tD51B2481C528C4EA6D94841BBA3F1175DA0B6A35 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec_U3CLogResourcesU3Eb__17_0_mE78BE1CC7F7DF8969C985FC62A4E4ADFA4B4AC09 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Comparison_1_tED58B82FB7A2C91F98584913BF31F4EB22C457B0 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Comparison_1__ctor_m70CC55E87D912336539DE0FC8DB67EC4B65C9FA8 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Sort_mF58DE782592FCEE92E0759626B537A4790E42C9E },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_GetEnumerator_mCEDAF8C9622B37160BC54EDCC5550019722A0BE4 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_get_Current_m555100E8A3AFB0B4D82D0DF7151FD03F748C79F0 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_MoveNext_mA81F74037035D325BF170C11F7E1A62E89752BE3 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Enumerator_t13D22151810F040F3F55E8252ACCBF9E54FBE707 },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_Enumerator_t13D22151810F040F3F55E8252ACCBF9E54FBE707_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2__ctor_mFAE5B73C8535E82E229A8EFF817A4DE18EFB0F97 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1__ctor_m14C1FB3CE305A2F0B842155FF7C6C8CFF51CECF8 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec_t0DDAD394509E16640C8C77540D7A5D29E3BD4560 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec__ctor_mA30D55B80F6ACBBF1C23F8E4CFA2D71461430EEA },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec_t0DDAD394509E16640C8C77540D7A5D29E3BD4560 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Activator_CreateInstance_TisResType_tD1FE7BB9C940E24F58C832D58865EFC4E5925ED4_m924AEB25762F06602422C7DAEF7CA26137190E72 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ResType_tD1FE7BB9C940E24F58C832D58865EFC4E5925ED4 },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_ResType_tD1FE7BB9C940E24F58C832D58865EFC4E5925ED4_IRenderGraphResource_Reset_m81E9B60C6150975FDFED0428472E8A472FF30627 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ResType_tD51FD186C1632D722EB7A57B61CC1B4F545F6487 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ComponentSingleton_1_tAF66CB52D8E2FD91B45CFFB516383FB617F733A3 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TType_tFB821001EA2FF99CA2D82A606100FDE37B2DB558 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_TType_tFB821001EA2FF99CA2D82A606100FDE37B2DB558 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_GameObject_AddComponent_TisTType_tFB821001EA2FF99CA2D82A606100FDE37B2DB558_m5FFDA4659C0F660D492241A6F0F8F75E7F0AF934 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBufferSingleton_1_get_instance_mF26291329384686E3808A379D4045D3FA808570E },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBufferSingleton_1_t7C92EB9183DA4562EF68C96B6ED86AF21B4BD7C7 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_t76660BCB3420DA30872C837E3E3C3E1322372FE7 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_t76660BCB3420DA30872C837E3E3C3E1322372FE7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_UpdateData_mEFFA50342E0BA45DBA78530CA80E27B76BCA678C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_SetGlobal_mCC1B42DB41DD4F939898F944AD5373790A4EE6B5 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBufferSingleton_1_get_instance_mC941AEF60B269952845D81E05637C21AF46C5626 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBufferSingleton_1_t0A0151F280E720B41E6E336D4A6E71F076A73C83 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_t6A117CF4843F32EC1811934841FB49F4706637CB },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_t6A117CF4843F32EC1811934841FB49F4706637CB },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_UpdateData_m310C3B4313DEFCAB951F88501FCD5E8ABED116DF },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_SetGlobal_m93F01A2708421627726831EE96B07E08422A9667 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBufferSingleton_1_get_instance_mB01EA7039D1CC0127EB566DF9631FB01B13D8FB7 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBufferSingleton_1_tB2E321DF87F01606E024A7ED3D60F12F58DAB33E },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_tB201A99C351D384BB0E09559F066923E8E9C9DC9 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_tB201A99C351D384BB0E09559F066923E8E9C9DC9 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_UpdateData_mECCCAF567CF49841161F44EEB40AC7A0CAE59D51 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_Set_m2D6601848664170FC7E1BF03F6F06CC5828AF7DD },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBufferSingleton_1_get_instance_mC2B5E938202022FBB705D73926E9506C484DBDD8 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBufferSingleton_1_t4CF342E4025AA6067C2684E9432D3ACE2211D333 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_t68EDF6F6C593BD29565BAE20EE8157167DAAAD97 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_t68EDF6F6C593BD29565BAE20EE8157167DAAAD97 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_UpdateData_mA0DA55408A9AD22C9ABE84E3D7324258A21226E3 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_Set_mF4C4D95E3D5CF404A939B1AB5390914FC5EA8CE2 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBufferSingleton_1_get_instance_mDC8E160B0B9401DF1E78C3CDA97783E09D5BB865 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBufferSingleton_1_tCB9AE60656168F3FA79C9CE4E9B857F9CBA7734F },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_tCB5AF7BC465BB24134D158A9F2E3B9356413018A },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_tCB5AF7BC465BB24134D158A9F2E3B9356413018A },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_UpdateData_mDDFEEB74F80FC039DC2A64E89292D15B61E0B5CA },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_Set_mBD2089F798581847E818D65A8722BA8140813435 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBufferSingleton_1_get_instance_mE96D21C4704CE3694D5EE2C28E6E6C2810074F3E },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBufferSingleton_1_tCBA93224460A809D7450599974DBAA8C37A415E9 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_tD66A88B5B4679F71DF09E1225A8BAB247D80EB37 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_tD66A88B5B4679F71DF09E1225A8BAB247D80EB37 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_UpdateData_m376B499115BA87D5F3E4BA7D6363C0BFBE7FE4BE },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_Set_m68728117892A33B456D6A2F6327ADB491DB35101 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBufferSingleton_1_get_instance_m8D8336927586B73996A0595F6E1D6A2283B45E7E },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBufferSingleton_1_t8189858956A05BBBB31E273C478FE08863950AE6 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_tBE028519A42222ABF6462BCD6D894ED6CFB2D882 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_tBE028519A42222ABF6462BCD6D894ED6CFB2D882 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_UpdateData_mFC124F416A44CDD31512EB617ED684C5DB4D3CC6 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBufferSingleton_1_get_instance_m2C537967E6C9D3974C39C22751102D3214CD6A80 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBufferSingleton_1_tA51D7E28A089C1B22397369A470162A9E1C3D4D0 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_t4115EC9DE8C69A61E45F252A36645D617ABB7512 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_t4115EC9DE8C69A61E45F252A36645D617ABB7512 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_UpdateData_m4831E1644024185ED5C4A3C94E73E7595179C785 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBufferSingleton_1_get_instance_mC4C66B545FD39DF6BC44E0D1F02EF67A652B122B },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBufferSingleton_1_tACBEB7B6F3CA610DA1CE4E4C33840DA30B4DD04F },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_tF57A88056767C2767F6C911F7E96CE60B603BF3B },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_tF57A88056767C2767F6C911F7E96CE60B603BF3B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_SetGlobal_m63CA119339CCF2F0560E1F5B5E528F2700510522 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBufferSingleton_1_get_instance_mCA90A8F398303EE866B9E8ACB9676561E7522F51 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBufferSingleton_1_t5EC23633CEAEF110F526B30D70AF29120932E509 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_t20673CA9DF01B202051C9D33947D3BFE28B12EF5 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_t20673CA9DF01B202051C9D33947D3BFE28B12EF5 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_SetGlobal_m60FB777763AD55A6380AEB167A7D8B044205EEC7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBufferSingleton_1_get_instance_mDA6D6EA4A9E152489ADD9FE82BAD573D3799A5ED },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBufferSingleton_1_t6F0FB5756DD3518E04B8A1EC09BF70F9D77BD4F5 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_t3B468A09EB552700445DD3B0D722519EA2C6FBCC },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_t3B468A09EB552700445DD3B0D722519EA2C6FBCC },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_Set_mCBA77B286CE55AC0D6FB43671FDDC2E9873777FD },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBufferSingleton_1_get_instance_m12CE8CE2014E153BF47DFFCA43BB92AED0376AAD },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBufferSingleton_1_tB3DDF7A7EAF135D5D1B61AD02A88DE0C0DE276B4 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_tABADEE242AF1F6EEACA11E91B66EF96DAF1B9773 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_tABADEE242AF1F6EEACA11E91B66EF96DAF1B9773 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_Set_m950F6090ABC935DA4C7B6B301EE5F0EE04A22B2C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBufferSingleton_1_get_instance_m51B90C902A981470330D82116544A049A45E2587 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBufferSingleton_1_tB8DA3AA5009A05D79D5170EEF3EC3C9A19E3789E },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_tAA00F7CB51FFEEB8A8F5ED8E1251A90512EE0758 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_tAA00F7CB51FFEEB8A8F5ED8E1251A90512EE0758 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_Set_mE81A696726D6C2ABE53F20880B1F2F81163797D4 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_CBTypeU5BU5D_tD091220AEB48AFD57DA21352C19BBF89B1941424 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_UnsafeUtility_SizeOf_TisCBType_t5964815BE6B450555FA4489A328C4E220A1B2720_mBCAFB2E15586C88EE977CC3C2EA26A47212F1936 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_UpdateData_mB92BDF8E2F5D27970A818F9B33C7724D618E1767 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_SetGlobal_m95E1FDBFC183CFD5F8D93239855895CCC83C2CD6 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_UpdateData_m8FC97611FC4DB5C7069C603A25E3838B2AD02D97 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_SetGlobal_m8EA330908A7A52235E57C8840D6219967A8755D8 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBufferSingleton_1_t5D9C4BA8214CFE87FAE00A2B74B4E8C3064295F3 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBuffer_1_tB2879B452D42593AFDBF1D28BA3B733B2ECE6898 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ConstantBufferSingleton_1_t5D9C4BA8214CFE87FAE00A2B74B4E8C3064295F3 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBufferSingleton_1__ctor_m46330D2E623142C7BA029B7E2BB94E97C4A2C141 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1_Release_mC728E5851975D55A8CC45C6A184459085C93BDEE },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ConstantBuffer_1__ctor_m8EA9912CA647DEEE2B2C2A4B9C94D3259BDD6BC4 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_t779D87623BF32357BDB1C1B1F8A8259E151651FB },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Count_m81E3A35818B5FFCF78BB08E14F82D0FBD14A5CAA },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Item_m2E42646CFDA96E9870354AA516960B1CCA3B6CEB },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_UnsafeUtility_WriteArrayElement_TisT_tB35451058E1BF98388E6357BF259AEEA805FAEEC_m29572C8B2BCC5452309576F3C8FFE82533FA86EC },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_UnsafeUtility_WriteArrayElement_TisT_t26ECB6BF6C0047BB1AD0335ACFC6F959C487D601_m593EF0BD738D469F424C53559C4C6B4993D09A38 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_CoreUnsafeUtils_QuickSort_TisT_t4744A7447EB6CB898F9C95ADB53D52D279CC0904_TisT_t4744A7447EB6CB898F9C95ADB53D52D279CC0904_TisDefaultKeyGetter_1_tCB3559102863F465B40B3A899698FE6AD6C6DB7F_mF7E031A10D6D6C7B5FB4AA707F3BCC1E08A27D7C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_CoreUnsafeUtils_QuickSort_TisTValue_tAF621310047F4FBA4F826272EBA00BEBFC558426_TisTKey_t85A560E5076D6FA7684189A318432BA47C21C934_TisTGetter_t6AF3F80DC9B2ABED8AD1A41F526BBD6F7C0FF3E1_mC1C631DCE446096CB9EFBED74730BAB522215259 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_CoreUnsafeUtils_Partition_TisTValue_t68867E9E554E0547EDD2328992CC833CBB7BC345_TisTKey_t6AD31C65BDC8C152769939C384F7DFC079B8A833_TisTGetter_tA8D57B4438FFF4C21A14BD96F6C2D9FD3680849B_m77B54BE986D337E9B234D388E76D65898535CE1D },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_CoreUnsafeUtils_QuickSort_TisTValue_t68867E9E554E0547EDD2328992CC833CBB7BC345_TisTKey_t6AD31C65BDC8C152769939C384F7DFC079B8A833_TisTGetter_tA8D57B4438FFF4C21A14BD96F6C2D9FD3680849B_mF17BDB22B82B34FD72D8F5DFE150E7DB2D179122 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_UnsafeUtility_ReadArrayElement_TisT_t2A6748C61397A2356E716053A22676B44E22FC64_m816CBF34FFFA3596B4F8B7A482F8150C032F79C0 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t2A6748C61397A2356E716053A22676B44E22FC64 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IEquatable_1_t4F3DCF6B0D965FBF8DC57633AC12C723C4EF7164 },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_T_t2A6748C61397A2356E716053A22676B44E22FC64_IEquatable_1_Equals_mB272675BACF74389AF761E505A8DDB39F0D5F65C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Activator_CreateInstance_TisTOldGetter_tBEE13F46644C785B2966F439C4BEE5C5B18D42AB_m3E3A0DDE0542BD76D2DBE9FF77333156426FE053 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Activator_CreateInstance_TisTNewGetter_t21B2B1171BF2FB315D6FCE0B8B7842D074A29CBD_m8FF72D3491A08A3820FA8AA287E6558CE71338C1 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_CoreUnsafeUtils_CombineHashes_TisTOldValue_tD32C6397F2F3CA202862AA1AFB219D53944A1293_TisTOldGetter_tBEE13F46644C785B2966F439C4BEE5C5B18D42AB_m8C4DBC55D5CCE05932B4B8D66DB5EFF3F53A4556 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_CoreUnsafeUtils_CombineHashes_TisTNewValue_tEF3863E8ECA50B75F1B0FFC325A8368B67A5D1D1_TisTNewGetter_t21B2B1171BF2FB315D6FCE0B8B7842D074A29CBD_m39B65A447FAA2C3C1A67777363F92B3409B16704 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_UnsafeUtility_ReadArrayElement_TisTNewValue_tEF3863E8ECA50B75F1B0FFC325A8368B67A5D1D1_m739CA84EB95E57DA20E20079A802E20952CEE60B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_UnsafeUtility_ReadArrayElement_TisTOldValue_tD32C6397F2F3CA202862AA1AFB219D53944A1293_mFE839327B5391D0FD8E8632AA2C1CC5CCE66E274 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TNewGetter_t21B2B1171BF2FB315D6FCE0B8B7842D074A29CBD },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IKeyGetter_2_t7EB16529E81FF8DFE884AF324E33E88B877CC87F },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_TNewGetter_t21B2B1171BF2FB315D6FCE0B8B7842D074A29CBD_IKeyGetter_2_Get_m96B45F1A5C1679C46B5199FAC4D5EF82C27F2FFD },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TOldGetter_tBEE13F46644C785B2966F439C4BEE5C5B18D42AB },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IKeyGetter_2_t0B2C72EDC39A2D8428C5DAD58C6CE9ECBCFD2F9E },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_TOldGetter_tBEE13F46644C785B2966F439C4BEE5C5B18D42AB_IKeyGetter_2_Get_m56407B82607B9CF46D757C64A273690894F6BD2E },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Activator_CreateInstance_TisTGetter_t928FCFF0DB16188D9CE4EB19E33F5B5C6B3D64E0_mE95F0D9E228CB35A29778DC4AB9B1320364FEDDA },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_UnsafeUtility_ReadArrayElement_TisTValue_t0E50ED21875B61D9BA6DB117058872C236EFCE95_mE1D6FF46ED841C4B8F71F8AFECF08E50D5264FBF },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TGetter_t928FCFF0DB16188D9CE4EB19E33F5B5C6B3D64E0 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IKeyGetter_2_t70139089067FF897E54325E32085A22D1EF770D6 },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_TGetter_t928FCFF0DB16188D9CE4EB19E33F5B5C6B3D64E0_IKeyGetter_2_Get_m46B03047F284A6BEFBEB044EEBD182A64C1F7268 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_UnsafeUtility_ReadArrayElement_TisTValue_tFAE97595138D9812BEA80E4F331EA07F163BBDF5_m14B075982208D9D262FC051784ABC971EEEB5F10 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TGetter_t735A3AB48BAC01DAAB825085904633E640511371 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IKeyGetter_2_t2D58A2ED3A07CF330D6525925CAC1736B11E63D8 },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_TGetter_t735A3AB48BAC01DAAB825085904633E640511371_IKeyGetter_2_Get_m1570E1970FEF688A895B1B33F40E8B174AE474B0 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TKey_tFEA8742E8654FCA07F754A8F83C4610E1D1044B5 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IComparable_1_t8BDF01E34FEA3221DA459EAFBDE5F076C63BEA30 },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_TKey_tFEA8742E8654FCA07F754A8F83C4610E1D1044B5_IComparable_1_CompareTo_mA73CB729E22D4308B47ED920AFC14946021D3371 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_UnsafeUtility_WriteArrayElement_TisTValue_tFAE97595138D9812BEA80E4F331EA07F163BBDF5_m0FB6EEC7F7DD4FF8D6F7AD09FB6BC9BA7D7C9D8A },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TU5BU5D_t92D3D6C7EA6FBFDC2E1CDE4265327EEAF583E0BC },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_DynamicArray_1_set_size_m71C0C4E7472366190916A3BDFCC6CC408469F09F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_DynamicArray_1_IndexOf_mE59D976A65E3F0D56E889F73E6A9777F6470E9DD },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_DynamicArray_1_get_size_m7EB4887059F6CF3FEAF667BBABF3428630FDCC2F },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_DynamicArray_1_tF0164E8C65F2CD1ADA1D652152285201761F17B7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_DynamicArray_1_Reserve_m489C952D55362D83E4D04A7F305E75BEBA1ACBCA },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_DynamicArray_1_get_Item_m1A04B4E38EB2F420DED302F4531679C08944B85E },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_DynamicArray_1_RemoveAt_m007CDFB85824A43B8CC0359B288D19625DC3C9C3 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Predicate_1_t9317675707087082A17CF2728A544746CEAAA3B4 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Predicate_1_Invoke_m2DD6557D95C4D3ABB7021DB413B1D76E6CBE02AE },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t680F3D5C3D02D13D214B173A3711D8C59D75B69D },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_T_t680F3D5C3D02D13D214B173A3711D8C59D75B69D_Object_Equals_m07105C4585D3FE204F2A80D58523D001DC43F63B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_DynamicArray_1_IndexOf_mB8346F1913597FAA2E47C8056B8C576824548260 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_tDEE9F78A5EF56768AA0C40D8EDC0F352EAE25850 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IComparable_1_t77EE7C9392228A07ED0F661060BEA8DAC923285C },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_T_tDEE9F78A5EF56768AA0C40D8EDC0F352EAE25850_IComparable_1_CompareTo_m5183A7430AC0FEB4A0D4B01D8E42B97294596CC3 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_DynamicArrayExtensions_Partition_TisT_tF1371A513C9C13C2358102FD96D57BE84A6E3D3F_m27F863AC91AFDC44A015A8E009AC794A1E0192BC },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_DynamicArrayExtensions_QuickSort_TisT_tF1371A513C9C13C2358102FD96D57BE84A6E3D3F_mF447CA019719F688526DE501B96CC4F116B620F6 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_DynamicArray_1_op_Implicit_mE3D789169134B0FACB955BE42A0AA76BC5406A01 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_DynamicArray_1_t8DA1BA74A0D3D45E3366DB0C804CC16B94FFB662 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_DynamicArray_1_t8DA1BA74A0D3D45E3366DB0C804CC16B94FFB662 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_DynamicArray_1_get_size_mE126CD3F138951D83DE4E6E2B40BEA44048643F0 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_DynamicArrayExtensions_QuickSort_TisT_t9C2399CC9329628BADFB26622DFC946E209D5493_mC8E5576D55C73F0EC4A8872AF701B8A9F58ABB1D },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ListBuffer_1_get_Count_mBF5B70BD773EB056FDE8AD226B90E143049DD3B2 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t02DCCCA1CABD8F1284FE95DA832FF891AA965E97 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_UnsafeUtility_SizeOf_TisT_t02DCCCA1CABD8F1284FE95DA832FF891AA965E97_mBF2720F48A95DAF4BF188B45FC35A07D2BCD1242 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ListBuffer_1_get_Count_m17A0872E8E01FCCB33E6E02D74CC640AB3D4C44B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ListBuffer_1_get_BufferPtr_mF2BCBE00A0A5C71C73156605248360387874FBEE },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_get_countAll_mB98B96A35C683BEAEC934902A93FBEA08DAE5B3F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_get_countInactive_mE77B0A5342B00D246867817E0EF6C925DFCB4D01 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Stack_1_t4E6255F1200764B1F9BEF118237E5E93EC7FCBB7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Stack_1_get_Count_m51F70B59F566B839C558D640D2BFFEF13564FA08 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Stack_1__ctor_mD7EB29759A543D49FE20C4DD351B55BB1A09D880 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Activator_CreateInstance_TisT_t0D8036F6FEC93D79CC76B41CB3C41F9849087B2D_m99194D8D857E68EE9C3EEFC08E520CBFA9277713 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_set_countAll_m58640AFAC889339E70A96C0B95B5764C716DE9A9 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Stack_1_Pop_m2D023D47A7E90FA14703B44E890D5A48E4407275 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_UnityAction_1_tA6E547A663C3EEA8EDED071484A0CF6955148049 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_UnityAction_1_Invoke_m3F21D9DD27AF031854D34B153B387458B273ECA8 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_Get_mCFA2B80A1C48D806618BAA8D5CF0A604CCE52910 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_PooledObject_t9B23BE39F2452452BC4064E84415EFDEA27255BF },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_PooledObject__ctor_m77F18E393DB532FD146A6E86DAFEF334E9A88E69 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Stack_1_Push_m10AA0F614BD6B715EE243196D8E2C3CBA32BB8AF },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ObjectPool_1_tC2D72FC258A50D9A53BFD9CD6E7F110A4F8DE6BE },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_Release_m5666A0F88833C0528CDC5C6AA5CFF9A82F9C01BF },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_GenericPool_1_t6941943A3281B958203958D744C281A13069D3C6 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ObjectPool_1_t4DB897013B135B2A297C5DC20D567F1A7163A6F5 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_Get_m99592F5B7B2EF828E5C5508695938AF049594D21 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_Get_mC90C2364FED4279AC623BAA531C521F8F0529D4D },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_Release_m384FD232D2125269AB749C946A165E0F67DD167E },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1__ctor_m0C1762B4D321A6FBBD44E33A9731330E6935661B },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_UnsafeGenericPool_1_t4D243EE700AAAB782492A0718A011AD909B06BFE },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ObjectPool_1_tA443864065D38ECEBA458785F2FB1C366C379CA7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_Get_m36B17AD6AA38E847E4915B76460C8DC27C6E5B62 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_Get_mCB6E07FFA08C5DC7210E0CCFC6927A3384766E39 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_Release_mEC3CDC64D9A04792173DC0037F2083ED2BD67A50 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1__ctor_m14C50679FC6879830D466B99732C31AD8A9933C5 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ListPool_1_t6223F616BA3B8DBE7E059F8E3FA7BAAFB9218A8D },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ObjectPool_1_tC0C22C8BFFCB15F90DB8C98719853139D9E19FE5 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_Get_mA2F6C45BD1C088B1D523E8C8BB2FCF2988331C6B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_Get_m76EF23395F5F067FD3909745FE66DE29BAE28DE8 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_Release_m130F1550E52E2B06F0ABF976FA09EF7890FB5731 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec_tBA9743671FBAC96AA206135721CFF91C8F372F14 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec_U3C_cctorU3Eb__4_0_mDEDFE721F9368EBD8AC71DC3E2CABF586E440300 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_UnityAction_1_t38F30AC7A00F6AD93B29C007D7162BAA579609F2 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_UnityAction_1__ctor_mE1BD8D8A3F6DEB0B18FA8F332AF1ECD232D99894 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1__ctor_mAE8740BADF4E9CEB531EC461D28730470B73717E },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec_t3A3F35D952D43B5681534794220D43DAA0CAEC9B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec__ctor_m1B8510029051E169383A8B4F6889ACF4F6FD1B93 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec_t3A3F35D952D43B5681534794220D43DAA0CAEC9B },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_t74642046F802269A530559D5C5DE7AEC12D79769 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Clear_m0B5C1D345C11BF21E84BF4B46F109AE38912408C },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_HashSetPool_1_t6E1F0A3C618746CD2652CD1D2B5019950C080D86 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ObjectPool_1_t9A9C2B65D1CC81D81561583A9F71BB4590E2CCB4 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_Get_m375495A52E0F4DC359A8EC6EF3504361529885B3 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_Get_mB6C3FF42276A04C899E29FE7EFDB39735CB0D7C8 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_Release_m1E5A51C6C98208912C29BF4C8B31F7DC5A1C8EF2 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec_tC25A6FA319E71E5C9DC585592EB36EC9F5EB02D8 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec_U3C_cctorU3Eb__4_0_m4994A44EEAE82045F8F5934079E8076499995AED },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_UnityAction_1_tAB9CFF61AE62D68553824687BC7E336586BAD8B0 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_UnityAction_1__ctor_mD6D982DB1DD4E9F776983E3C0895C9F2EBD8520F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1__ctor_m54DCCBE475872A64AAFB91E3186E71DB9FCF8084 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec_tFB17DF3D62339E36BD3B5E7ED50F66E374CE4FA2 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec__ctor_mF16067314465472FC747E5B88957771ADCF2E759 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec_tFB17DF3D62339E36BD3B5E7ED50F66E374CE4FA2 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_HashSet_1_t38A58F8B18667A727E9725053F506D5DFA7036E9 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_HashSet_1_Clear_m6BC337B37B19BD4773F2340607837F5DC270E16A },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_DictionaryPool_2_t08056220DFADF3969DFA2CFB9CEAE6FC8D707676 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ObjectPool_1_t781E01D4328DCC742473BB991B696971FB2BD4FB },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_Get_mE849E5BE7D3DC7D0A6BD9A4A179FDB9AA0098D7A },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_Get_m1088974EC3F733A37FB498BCD6F5232099CD27EB },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1_Release_m6B0491E4DAC74F86F4DC6AB80A36F8A71F90E529 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec_t12171AE4C8145C70D97ABF478F6E34688B2EA070 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec_U3C_cctorU3Eb__4_0_m1ED30CF58D65F1C56CEB5342F9BEAE3B3D9087D3 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_UnityAction_1_t57D5B4D1AD828EFDA90561D1907CCEF1497133ED },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_UnityAction_1__ctor_m40E129600B30DE8E3986054B79B9A014861FA102 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectPool_1__ctor_m667B0D553AA456F4030C5D5CE58B09C6ED6B6E4F },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec_t8EBC4FF595CEB8E04B2AEF597860103187A32AD6 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec__ctor_m589A7431724484B162A593F84424B7B8DADB7BA5 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec_t8EBC4FF595CEB8E04B2AEF597860103187A32AD6 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Dictionary_2_t445BB1E618457723FAED2CF88E436649AD306855 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2_Clear_m1EF68D758F9B35B0378F971C6DF876F958D9C49A },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ListChangedEventHandler_1_tF13479C4BD2CF664153E64E38914D439158D0052 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IList_1_tADDE9E206B899D2E721BF2D39D4639529509C2EA },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IList_1_get_Item_mA1570CD813B9096758D53A2ED339957C87C7DCF3 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObservableList_1_OnEvent_mA17C7E7827FC97210B627F6CC7B748487300F2B7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IList_1_set_Item_m705E44D852E0D8E932CD69359DEC35E82A72B467 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ICollection_1_t65A09CE74C2E925B3F0E480DCBDF064CA83F6C64 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ICollection_1_get_Count_m07A1ED30CC1D4E9F74D131D3657EC89BCD9DC3CA },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObservableList_1__ctor_m80B3548827A252BF9BB4D4234DB83C7EF5F51532 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_t1EC2049826741F4E3D4FF66D3E71C79E65A0AF91 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1__ctor_m222F46D36A43FD6D6B50E0733E1604CA6652F746 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1__ctor_mE2C4222AD28995459DC9F84A54BE77D763F41303 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ListChangedEventArgs_1_t954C1FB02ADD7657C3A34D7517A42605CD9BDA6F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ListChangedEventArgs_1__ctor_m83FB3A14954E43E80E9D78E33F62692CA5F7AAFD },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ListChangedEventHandler_1_Invoke_mC7613C5C42057AD9D01D376006F3947838ECA3EE },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ICollection_1_Contains_m254313386E5BE54AFF34173C9589BFA3BD75A410 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IList_1_IndexOf_m4AE90CCDE1CF5C49BCF2AABCD68F2D29C32B50C4 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ICollection_1_Add_mDE216D9E853EF6ED8958269D1D93D4A4AED288AE },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObservableList_1_Add_m18C1DFBC105CFA613C3BC08A6A5FEA55C5670FE7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IList_1_Insert_m9A2C756262C85227B7AF650EAF911CDD1CC19887 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ICollection_1_Remove_m611D2AEFCC07CCB4CC8FD8CE7E29BE32A8A139C5 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObservableList_1_Remove_m1CF80CCD393858774CDBC0D9A26E73C021D08A36 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IList_1_RemoveAt_m7B902EAFF2B76B5124FD531940AC2F332E040E71 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObservableList_1_RemoveAt_m262784BC5D703324DADCB5FC43F7A9F84287DEF7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObservableList_1_get_Count_mC86BC374BDE350A421BE0D1F5316AB97656DD80A },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ICollection_1_CopyTo_m35A8DBE9CF49985AC37FF1CD3CAF554FA4AE6274 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_IEnumerable_1_tB17703EF50CBB7DDDD59F4F909BC433389957102 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IEnumerable_1_GetEnumerator_mC34663B8AAA7FCCDA7FD695CA441AC9ADAE8FEEB },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObservableList_1_GetEnumerator_m8652475F0BFE66E82ECF04501FA24721254D1760 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_SerializedDictionary_4__ctor_m93AF45C4C10A55D9D09E79C7390737769113B670 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_SerializedDictionary_4_tE2783C0B6A4968B91F6222A3123B304F5A334F00 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Dictionary_2_t094655324611484DB804651B4DB36003D155D99D },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_t1B772F8004907E91C14DE320308E300D4383CEEA },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Clear_m54C88AC8E2061F3946BE90B673C8DD69AE7EB3DF },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_t73CA8BB266930AB63D8E2586AEEC971482CAA8AD },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Clear_m3E53B7E3AFC3C8D7646E33E4913C2D45B0DC22E0 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2_GetEnumerator_mAE42DBF2A51B8D990D685895A63020DFAFEACFC2 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_get_Current_m83F43262C89B8CFD96603F3A2962AF89D36DCA1B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_KeyValuePair_2_get_Key_m33FF678D1FABDC95993F23A83E428AB204766AF4 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_SerializedDictionary_4_t4A730F998FDB7FCA9ADD6E9C5F40B1D52D9284D9 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_SerializedDictionary_4_SerializeKey_m10F9766DF9F024573B83A3D639A90A41614656A4 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Add_m49E33716E9E1431D354D9383823584A2A44E27A4 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_KeyValuePair_2_get_Value_m002F78CBAFB19464B454D13B2E7E12139F423173 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_SerializedDictionary_4_SerializeValue_mA5C288713EB481D3E6AB7295A1019A460B3E930F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Add_m66A29CEFA75A687A036F892CFF7FE63E4FC2CD65 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerator_MoveNext_mBF169A34B9E71FA3BACC157F0C8BD9C8970C2A1B },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Enumerator_t683B460C190EA15A1E133E880DA0D3786608A06D },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_Enumerator_t683B460C190EA15A1E133E880DA0D3786608A06D_IDisposable_Dispose_m3C902735BE731EE30AC1185E7AEF6ACE7A9D9CC7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Item_mFED712ADBEDB7A6655DECF21C185736019FEDDAC },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_SerializedDictionary_4_DeserializeKey_mDCDC769BE37985E8A3BF67CCBDEDCBF6844F01D7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Item_mF8E86772FCD20FAC7DD957F8A4C59D89A8A6A679 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_SerializedDictionary_4_DeserializeValue_m80AAC76D3FFD5A671173322A1399EA7D541F1B0A },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2_Add_m17817F59D59257EB71A22A2A31AB0BF2603598AE },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Count_mD9EB3DC1FF41414935DA9B5302A550A3C699CB50 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1__ctor_m51C3776A7DF472862EACCFD6864F8D1296D6FAF8 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1__ctor_m2EE7A07223732A9C52F1019281B378A667083F8C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2__ctor_m9B925A89B599BA8BCAEA33F5EFB6E08A5A2F95AE },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Dictionary_2_tE3B43C2B070ED99ACBD252C485D125CBF550BE45 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t26CC53AEAFD25035943D16224BEF5BE64BAB4C90 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Field_1_tD418C612A305A78AC208BCD8DED6A3B61FB92B97 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Field_1_ValidateValue_m4A7D2686A817F10452B498D8282433D9D39240F1 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Field_1_GetValue_mA26E190F06D8BFCDF8EC9CFCAEB2FCC9932A9209 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Field_1_get_getter_m0B70E3395A5F3EE9D97852913640F06F0F8D9A76 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Func_1_t62EC3ED648C6028D451C378830FD121EB4FA7611 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Func_1_Invoke_m5EA4140B193EAB0A9D43B21E47A39515118F6746 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Field_1_SetValue_mD8A4EE1562DB7D0877CC71808BF6CAE357352E87 },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_T_t26CC53AEAFD25035943D16224BEF5BE64BAB4C90_Object_Equals_m07105C4585D3FE204F2A80D58523D001DC43F63B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Field_1_get_setter_mD473751526042624878EB0FFB5AF21CA125E6401 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Action_1_tDEF046DC219119B8A91BB1DB06DC5F20BCC1FC69 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Action_1_Invoke_m2E92EF61B67FB5CAADBD321CEBC1FE67CB9B967F },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Action_2_t36B30ABD6F5141C433C79501DB436B88878836EA },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Action_2_Invoke_m5B614DA27D3C50CA217FF9D4DCCC10C4EA5F2117 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Dictionary_2_tC8CCEB8E79BC02F0789B42BF33ADBB85415CB4CB },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2__ctor_mCA04BE9372EDBBD63FB265999E339FD8BFEE8D7E },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TProfilingSampler_1_t65290618F3B57B18C4BDC714B6543EB6E6DA41D9 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_TEnum_t2AE3EBB2263205A87E0B5B08C0CC4E2699461412 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TProfilingSampler_1_t65290618F3B57B18C4BDC714B6543EB6E6DA41D9 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_TProfilingSampler_1__ctor_m5033A67D8216E4CB911D58B9F127A9D39844D114 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TEnum_t2AE3EBB2263205A87E0B5B08C0CC4E2699461412 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2_Add_mAC2ECA573660B260320E45477451EF77E774B8A5 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TProfilingSampler_1_t3E8F47C89F02CC35EBF2CAB3D893C0BA34111F09 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Dictionary_2_tF3D1CDCBF77E29578FF6CD634BC7ACBCC55D51FD },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2_TryGetValue_mE6A365B92FD3CA50BADB78A31E5F8365FFA6D152 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TEnum_t2FD04B0EB72B3C80C45E3B7402CC3A423C1817E6 },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_TEnum_t2FD04B0EB72B3C80C45E3B7402CC3A423C1817E6_Object_GetType_mE10A8FC1E57F3DF29972CCBC026C2DC3942263B3 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_NativeArray_1__ctor_m1148A54380581B701CC862B5050D94B9259C1F95 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_NativeArray_1_get_IsCreated_m269B99B7A939B0D7A41692DDAFAA9F77844A6679 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_NativeArray_1_Copy_m084E053EC143095F22C0C86DE11D08BE9DCB488F },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_NativeArray_1_tCD3D8A7A4BF79EAA79EA7E0DA89F99868235B7B9 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_NativeArray_1_Dispose_mEB4BD40B96877D644ADEB41A4949DA461F3098F4 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TU5BU5D_t8CADBADBA566ABBAF369C22955B0E86F5E2C00A5 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Array_Resize_TisT_t204800E20079C684B2ADB298B75E35161424A624_m4B528E27EE3398F43B609A4DCD544CB86ACB6997 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_tF07567C78439016ABF0ACBC2B82B6C49F6EC7BF9 },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_T_tF07567C78439016ABF0ACBC2B82B6C49F6EC7BF9_IConvertible_ToUInt32_mD56F031D945955896F6C4D8E735794A72AC8141B },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec__82_1_t0C163997F29BB04A9B290E19D01E9957905B8122 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec__82_1_U3CGetAllTypesDerivedFromU3Eb__82_0_m4484CB63E1F991C8712DC70C4938FCBEC9BA1CF3 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_T_t028669B2F5A4E1715738479271B5642C431DFEAD },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerable_Cast_TisT_t028669B2F5A4E1715738479271B5642C431DFEAD_m1BC2EBC6ABFF1864D790062B4651DDAB94B3EB77 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Enumerable_Last_TisT_t028669B2F5A4E1715738479271B5642C431DFEAD_mE5AB7D7EBCF0E78B67DABA3E1BCB8E133D85B136 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec__82_1_tE671CF03C5305EE89A318559F3942817FECBC01A },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec__82_1__ctor_mC04F2E89955679567C855FFBAA0A5EE271DACA5A },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec__82_1_tE671CF03C5305EE89A318559F3942817FECBC01A },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_T_t34AEFC60C87159398705753AB3949E9F7EF38E6B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_VolumeProfile_TryGet_TisT_tF3D68ED9398B623EDC636AF8EECE175896F2B764_mE7E4FCBFC37AE5C385FA87B1C05E1C8BB4EFE206 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_tF3D68ED9398B623EDC636AF8EECE175896F2B764 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_VolumeParameter_1_t62DBE65CE2DD11362CEFAA62CDFE766C1C47AAD7 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_VolumeParameter_1_get_value_m8414ABD41447786F0A8A2B2CCC214DA97B3BCB29 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_VolumeParameter_1__ctor_m2CB876A14B8962612809165C02F949A687C06FE9 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_VolumeParameter_GetValue_TisT_t6F7A42E482B273BE8680284FFC0EA16E6A955CD7_mB1A14C399EC384BB29A503708C7D06AB7694DF00 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_VolumeParameter_1_tD29515A1C38D91B1DB9888E60CCD244CE0D5411C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_VolumeParameter_1_Interp_mA2B63CC5EF641D67034EFA5DD77529889320A597 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_EqualityComparer_1_get_Default_m63725B6669D7C2E44F01D13F4EE477F1985D6466 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_EqualityComparer_1_t548082EFF5C0A29C1FEC4EB08C670049011D006E },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_VolumeParameter_1_get_value_m4B6EB123585A9DB460EC85BCF2A00AE1088BE699 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_EqualityComparer_1_t548082EFF5C0A29C1FEC4EB08C670049011D006E },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_EqualityComparer_1_Equals_mDEBC7DD15CC581A3EC396845845424C9C6032D81 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t6F7A42E482B273BE8680284FFC0EA16E6A955CD7 },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_T_t6F7A42E482B273BE8680284FFC0EA16E6A955CD7_Object_GetHashCode_m372C5A7AB16CAC13307C11C4256D706CE57E090C },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_T_t6F7A42E482B273BE8680284FFC0EA16E6A955CD7_Object_Equals_m07105C4585D3FE204F2A80D58523D001DC43F63B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_VolumeParameter_1_op_Equality_m460EFFE098A41E1117844EB74F79E91AD707D6A5 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_VolumeParameter_1_tD29515A1C38D91B1DB9888E60CCD244CE0D5411C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_VolumeParameter_1_Equals_m583564C794AE8BCC10737B2E1161E54280EBCCE6 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t6C0397962A8AC97F08436002C08ABC346B1E6545 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectParameter_1_set_parameters_m0B8E1DD2F4626A9C0F591B17EDD45A8B2ACAAA03 },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_T_t6C0397962A8AC97F08436002C08ABC346B1E6545_Object_GetType_mE10A8FC1E57F3DF29972CCBC026C2DC3942263B3 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec_t285777F3546BC5A7B9BA7349F88ADBC0AF5FF00B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec_U3Cset_valueU3Eb__9_0_m5BCCB5F25B35E861FB4F28F7468108849B4741DF },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec_U3Cset_valueU3Eb__9_1_mB06A4A33E49F70F146D16521E093431C5873795E },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectParameter_1_U3Cset_valueU3Eb__9_2_m09F4A9DDA36800CBB711F246CB91ED02DEA5219A },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_VolumeParameter_1__ctor_m65285A3978EE1BF12AB76A49E8C77A7F44D17AE9 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_VolumeParameter_1_tBD8FED943C80D98EC5A3CAC114E550B6014A7EF1 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_VolumeParameter_1_tBD8FED943C80D98EC5A3CAC114E550B6014A7EF1 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_VolumeParameter_1_set_value_m1F669FA969F5B93E853B4F41D4E4BEEFC690EF54 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ObjectParameter_1_get_parameters_m20973595FD069E4CE9A286218645A9EA9DC7E0AA },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_ObjectParameter_1_t41E805E26779A221A457A33131EF7A079BA846AE },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec_t29B394078CAB71E61EE63D5EF29B2AB33E91965B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CU3Ec__ctor_mFD43D0C2BBA9A8C6FE384122CE15596038BC5358 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CU3Ec_t29B394078CAB71E61EE63D5EF29B2AB33E91965B },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_T_tB5FBED418E93CC320398596B8E4E604D96C48794 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_tB5FBED418E93CC320398596B8E4E604D96C48794 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_T_tC66A4D0D8F85AFED27AA5D32E0C17EDB7207B833 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_T_tE556E299BB00733101BB00402BB3DE976CA00804 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_T_tB3C0C5C166FD73A50A9CD77B6030FBCD800A3F52 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_VolumeProfile_TryGet_TisT_tB3C0C5C166FD73A50A9CD77B6030FBCD800A3F52_m0088EB3E2698B1C6F30D4C66320C4D53D3F8C166 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_tC6400D8DBAD530961588DAC6B08267907F518F3A },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t43F14DE2A8C16558A2D5E40E29195535EBB4D9BB },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_t4467BCCC7001BD00F931FC1D8BE5EE0A3C5C5966 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Count_m961A124AA26C5EBC756071A4A9792FC70F3136EF },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t6FD7774D198991CE9196F1CA24259D4C8F2CE3B2 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Add_m6B827EA9BD4674EFCB49D70207AC5870889C2E00 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_T_t45618DD40C279D3C6893AE5959943714F5AC9052 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t45618DD40C279D3C6893AE5959943714F5AC9052 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t9B26B094ECAD86EC4D7787341446C66F40C66A27 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_T_t9B26B094ECAD86EC4D7787341446C66F40C66A27 },
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_Unity_RenderPipelines_Core_Runtime_CodeGenModule;
const Il2CppCodeGenModule g_Unity_RenderPipelines_Core_Runtime_CodeGenModule = 
{
	"Unity.RenderPipelines.Core.Runtime.dll",
	2333,
	s_methodPointers,
	193,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	81,
	s_rgctxIndices,
	476,
	s_rgctxValues,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
