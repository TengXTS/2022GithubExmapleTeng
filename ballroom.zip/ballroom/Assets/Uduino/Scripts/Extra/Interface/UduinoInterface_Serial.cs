﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Uduino
{
    public class UduinoInterface_Serial : UduinoInterface
    {
       
    }
}