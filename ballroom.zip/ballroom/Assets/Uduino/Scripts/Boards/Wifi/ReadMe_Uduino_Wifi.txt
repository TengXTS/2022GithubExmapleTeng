﻿Thanks for purchasing Uduino Wifi.

The documentation for Uduino Wifi can be found on this page: 
https://marcteyssier.com/uduino/plugins/wifi

You can find more informations and tutorials on Uduino's webpage : 
http://marcteyssier.com/uduino/

You are stuck? Ask on the forum:
http://marcteyssier.com/uduino/forum/

IMPORTANT: 
- To use Uduino Wifi, you first need to import Uduino package.
- If you are Upgrading from Uduino 2.x to Uduino 3.x, please delete the /Uduino/ before importing the new one. 